package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
public interface GenesisDao {
	public int insertTrfCntrlData(List<SAPUserAccessModel> dataList)throws SQLException, DataAccessException;
	int insertUser2RoleData(List<SapGaaUser2RoleModel> dataList) throws SQLException, DataAccessException;
	int insertUser2SodData(List<SapUser2SodModel> dataList) throws SQLException, DataAccessException;

	public List<SapDataTransferReportMdl> getGenesisTransferCtrlReportData()throws SQLException, DataAccessException;
	public List<String> getGenesisUser2RoleSysData() throws SQLException, DataAccessException;
	public List<SapUser2RoleReportMdl> getGenesisUser2RoleReportData() throws SQLException, DataAccessException;
	public List<SapUser2RoleReportMdl> getGenesisUser2RolePlatformReportData(String platform) throws SQLException, DataAccessException;

	public List<SapUser2RoleDeltaMdl> getGenesisUser2RoleData(List<String> users) throws SQLException, DataAccessException;
	public int checkUser2RoleReportRecord(String userId, String primaryReviewInfo3, String additionalInfo3)throws SQLException, DataAccessException;

	public List<SapU2RDeltaSummaryMdl> getGenesisUserWiseCounts(String type) throws SQLException, DataAccessException;//Method to Query USER2ROLE Record counts

	//USER2SOD
	public List<SapU2RDeltaSummaryMdl> getGenesisUser2SodDataCounts(String type) throws SQLException, DataAccessException;//Method to Query USER2SOD Record counts
	public List<SapUser2SodDeltaMdl> getGenesisUser2SodData(List<String> users) throws SQLException, DataAccessException;
	public List<SapUser2SodReportMdl> getGenesisUser2SodReportData() throws SQLException, DataAccessException;


}
