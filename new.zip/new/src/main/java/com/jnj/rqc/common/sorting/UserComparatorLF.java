package com.jnj.rqc.common.sorting;

import java.util.Comparator;

import com.jnj.rqc.models.User;

public class UserComparatorLF implements Comparator<User> {

	@Override
	public int compare(User u1, User u2) {

		int lNmCmp = u1.getLasttName().compareTo(u2.getLasttName());
        int fNmCmp = u1.getFirstName().compareTo(u2.getFirstName());

        if (lNmCmp == 0) {
            return ((fNmCmp == 0) ? lNmCmp : fNmCmp);
        } else {
            return lNmCmp;
        }
	}
}
