package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSIFunctionPermModel {

	private String disp;
	private String appScp;
	private String funcId;
	private String funcDesc;
	private String tCode;
	private String tCodeDesc;
	private String authObj;
	private String authObjDesc;
	private String field;
	private String fieldDesc;
	private String fromVal;
	private String toVal;
	private String logicalOptr;
	private String status;
	private String source;
	private String changeCmnt;

	@Override
	public String toString() {
		return "CSIFunctionPermModel [disp=" + disp + ", appScp=" + appScp + ", funcId=" + funcId + ", funcDesc="
				+ funcDesc + ", tCode=" + tCode + ", tCodeDesc=" + tCodeDesc + ", authObj=" + authObj + ", authObjDesc="
				+ authObjDesc + ", field=" + field + ", fieldDesc=" + fieldDesc + ", fromVal=" + fromVal + ", toVal="
				+ toVal + ", logicalOptr=" + logicalOptr + ", status=" + status + ", source=" + source + ", changeCmnt="
				+ changeCmnt + "]";
	}

	public String getData() {
		return  disp + "~" + appScp + "~" + funcId + "~" + funcDesc + "~" + tCode + "~" + tCodeDesc + "~" + authObj + "~" + authObjDesc
				+ "~" + field + "~" + fieldDesc + "~" + fromVal + "~" + toVal + "~" + logicalOptr + "~" + status + "~" + source + "~" + changeCmnt ;
	}


}
