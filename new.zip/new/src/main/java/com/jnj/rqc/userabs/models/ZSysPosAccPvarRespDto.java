package com.jnj.rqc.userabs.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.masterdata.dto.ZPosVariantMdl;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ZSysPosAccPvarRespDto {
		private int statusCode;
		private String message;
		private String datetimeStamp;
		private String statusDesc;
		private String developerMessage;
		private List<ZSysPosAccPvarMdl> accPvar;
		private List<ZPosVariantMdl> accPvarDD;


}
