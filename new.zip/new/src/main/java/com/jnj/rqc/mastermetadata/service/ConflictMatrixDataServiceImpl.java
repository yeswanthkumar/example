package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.mastermetadata.controller.ConflictData;
import com.jnj.rqc.mastermetadata.dao.ConflictMatrixRepository;

@Service
public class ConflictMatrixDataServiceImpl implements ConflictMatrixDataService {
	static final Logger log = LoggerFactory.getLogger(ConflictMatrixDataServiceImpl.class);

private final ConflictMatrixRepository conflictRepository;

    @Autowired
    public ConflictMatrixDataServiceImpl(ConflictMatrixRepository conflictRepository) {
        this.conflictRepository = conflictRepository;
    }

    @Override
	public void insertMultipleRecords(List<ConflictData> records) {
    	log.debug("enter into the method");
    	conflictRepository.insertMultipleRecords(records);
    	log.debug("end of the method");
    }
    @Override
	public void deleteAllRows() {
    	log.debug("enter into the method");
    	conflictRepository.deleteAllRows();
    	log.debug("end of the method");
    }
}
