package com.jnj.rqc.sodrefresh.service;

import java.util.Map;





/**
 * File    : <b>SodRefreshService.java</b>
 * @author : DChauras @Created : Nov 9, 2021 12:51:02 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface SodRefreshService {

	public Map<String, Object> runSodRefresh(String serverEnv, Map<String, Object> errorMap);
	public Map<String, Object> refreshAllMVs(String serverEnv, Map<String, Object> errorMap);
	public Map<String, Object> loadAllStagingData(String envName, Map<String, Object> errorMap);
	public Map<String, Object> refreshNamedMV(String serverEnv, String viewName, Map<String, Object> errorMap);
	public Map<String, Object> refreshSodMailer(String serverEnv, Map<String, Object> errorMap);


}
