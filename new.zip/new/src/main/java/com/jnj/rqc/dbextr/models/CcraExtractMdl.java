package com.jnj.rqc.dbextr.models;

import lombok.Data;


@Data
public class CcraExtractMdl {
	private String userId;
	private String userFirstNm;
	private String userLastNm;
	private String stat;
	private String roleNm;

	public String getData() {
		return   userId + "~" + userFirstNm + "~" +userLastNm + "~" + stat + "~"+roleNm  ;
	}

}
