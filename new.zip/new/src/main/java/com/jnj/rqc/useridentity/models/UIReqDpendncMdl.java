package com.jnj.rqc.useridentity.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UIReqDpendncMdl {
	private int reqId;
	private String sysId;
	private String posIds;
	private String acsIds;
	private String pvIds;
	private String adIds;
	private Date dtCreated;
}
