package com.jnj.rqc.terminations.models;

import java.util.List;

import lombok.Data;

@Data
public class TerminationModel {
	String crName;
	String appName;
	String reqType;
	String accOwner;
	String accName;
	String accStatus;
	String resourceName;
	String groupName;
	String crStatus;
	String crDateOpen;
	String crDateCompleted;
	String notes;
	String nagsStatus;
	List<AppStatusModel> appstat;
	@Override
	public String toString() {
		return "TerminationModel [crName=" + crName + ", appName=" + appName + ", reqType=" + reqType + ", accOwner="
				+ accOwner + ", accName=" + accName + ", accStatus=" + accStatus + ", resourceName=" + resourceName
				+ ", groupName=" + groupName + ", crStatus=" + crStatus + ", crDateOpen=" + crDateOpen
				+ ", crDateCompleted=" + crDateCompleted + ", notes=" + notes + ", nagsStatus=" + nagsStatus
				+ ", appstat=" + appstat + "]";
	}


	public String getData() {
		return crName+"~"+appName+"~"+reqType+"~"+accOwner+"~"+accName+"~"+accStatus+"~"+resourceName+"~"+groupName+"~"+crStatus+"~"+crDateOpen+"~"+crDateCompleted+"~"+notes;
	}


}
