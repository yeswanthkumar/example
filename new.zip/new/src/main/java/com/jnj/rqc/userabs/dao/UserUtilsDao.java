package com.jnj.rqc.userabs.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMultiUserMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.useridentity.models.EmailItem;



public interface UserUtilsDao {

	public List<RoleADGrpMdl> getMstDataForADGrp(String ldapADGroup) throws SQLException, DataAccessException;
	public List<RoleADGrpMdl> getCFINMstDataForRole(String techRle) throws SQLException, DataAccessException;
	public List<RoleADGrpMdl> getAnaplanMstDataForRole(String techRle) throws SQLException, DataAccessException;
	public List<UserAbsConflictMdl> getAbsConflictsForPosVariants(String query) throws SQLException, DataAccessException;


	/**
	 * Method  : UserUtilsDao.java.getAllSystemPosVarIds()
	 *		   :<b>@param sysId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 31, 2023 1:18:27 PM
	 * Purpose : Get All Position Variant ID's for Given System
	 * @return : List<String>
	*/
	public List<String> getAllSystemPosVarIds(String sysId) throws SQLException, DataAccessException;

	/**
		 * Method  : UserUtilsDao.java.getMstRolesDataForADGrp()
		 *		   :<b>@param ldapADGroup
		 *		   :<b>@param sysId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 5, 2023 4:57:39 PM
		 * Purpose : Get Role Details for LDAP Group and System Combination
		 * @return : List<RoleADGrpMdl>
		 */
	public List<RoleADGrpMdl> getMstRolesDataForADGrp(String ldapADGroup, String sysId) throws SQLException, DataAccessException;
	
	public List<RoleADGrpMdl> getAllMstRolesDataForADGrp(String ldapADGroup, String sysId) throws SQLException, DataAccessException;


	public List<IAMRolesADGrpMdl> getAnaplanHistDataForUser(String userId) throws SQLException, DataAccessException;

	public List<RoleADGrpMdl> getAllSectorWiseSysPvData(String sysId, String[] acsIds) throws SQLException, DataAccessException;

	//public List<RoleADGrpMdl> getSectorWiseSysPvsData(String[] pvIds, String sysId) throws SQLException, DataAccessException;
	public List<RoleADGrpMdl> getSectorWiseSysPvsData(String[] pvIds, String[] posIds, String[] acsIds, String sysId) throws SQLException, DataAccessException;
	/**
		 * Method  : UserUtilsDao.java.insertDimensionsData()
		 *		   :<b>@param dataList
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jun 9, 2023 3:13:04 PM
		 * Purpose : Save Dimensions Data for Users
		 * @return : int
		 */
	public int insertDimensionsData(List<EmailItem> dataList) throws SQLException, DataAccessException;

	/**
		 * Method  : UserUtilsDao.java.getDimensionIdForUserEmail()
		 *		   :<b>@param emailId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jun 12, 2023 9:51:53 AM
		 * Purpose : Get Dimension ID for User Emil
		 * @return : String
		 */
	public String getDimensionIdForUserEmail(String emailId) throws SQLException, DataAccessException;


	/**
		 * Method  : UserUtilsDao.java.getAllSectorWiseSysPosPvData()
		 *		   :<b>@param sysId
		 *		   :<b>@param posIds
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jun 21, 2023 11:13:25 PM
		 * Purpose : Get All System Position Variants
		 * @return : List<RoleADGrpMdl>
		 */
	public List<RoleADGrpMdl> getAllSectorWiseSysPosPvData(String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException;
	List<RoleADGrpMultiUserMdl> getAllMstDataForMultiUserADGrp() throws SQLException, DataAccessException;




}
