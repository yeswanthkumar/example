package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.terminations.models.AppStatusModel;
import com.jnj.rqc.terminations.models.TerminationModel;

public interface TerminationsDao {
	public List<AppStatusModel> findTermUserData(String accName, String appName) throws SQLException, DataAccessException;
	public List<AppStatusModel> findTermNagsData(String accName, String appName) throws SQLException, DataAccessException;
	public  List<AppStatusModel> getUserJJEDSData(String uid, String appName) throws SQLException, DataAccessException;
	public List<AppStatusModel> findTermMissingUserData(String accName, String appName) throws SQLException, DataAccessException;
	public String insertMissingData(TerminationModel termMdl) throws SQLException, DataAccessException;

}
