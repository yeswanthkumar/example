package com.jnj.rqc.useridentity.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdGrpMdl {
	private String adId;
	private String adName;
}
