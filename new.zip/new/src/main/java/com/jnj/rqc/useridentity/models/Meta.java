package com.jnj.rqc.useridentity.models;

import lombok.Data;

@Data
public class Meta{
	String schema;
}