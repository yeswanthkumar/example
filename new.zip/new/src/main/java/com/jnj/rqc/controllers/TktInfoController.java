package com.jnj.rqc.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jnj.rqc.common.sorting.RQCReportComparatorDesc;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.service.TktInfoService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;

@Controller
public class TktInfoController {

	static final Logger log = LoggerFactory.getLogger(TktInfoController.class);

	@Autowired
	private TktInfoService tktInfoService;

	@Autowired
	UserSearchService userSearchService;

	@GetMapping("/rqcTktInfo")
    public String loadReportForm(Model model) {
    	log.info("Routing to RQC Ticket Info page.");
    	List<KeyValPair> searchBy = Utility.getSearchByList();
    	model.addAttribute("searchBy",searchBy);
    	return "tickets/rqcTktInfo";
    }




	@PostMapping("/searchRQCTkts")
	public String searchRQCTktsDetails(@RequestParam("searchBy") int srchParam,  @RequestParam("empId") String empId, Model model, HttpServletRequest request) {
    	log.info(" searchRQCTkts  searchBy :"+srchParam+"   Data:"+empId);
    	model.addAttribute("srchParam",srchParam);
    	List<KeyValPair> searchBy = Utility.getSearchByList();

        model.addAttribute("searchBy",searchBy);
        model.addAttribute("empIdParam",empId);

    	if(srchParam == 0 || StringUtils.isEmpty(empId)) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter "+((srchParam==0)?" Search By ":" ID "));
            return "tickets/rqcTktInfo";
    	}
    	try{
    		List<UserSearchModel> userSearchList = userSearchService.getUserData(srchParam, empId, 0);
    		if(srchParam<5 && (userSearchList == null || userSearchList.isEmpty())) {
    			model.addAttribute("message", "True");
        		model.addAttribute("error", "Status: to  Invalid Associate info or RQC Ticket Not Found ");
    		}else {
    			Map<String, ReportDataModel> dataMap = new HashMap<>();
    			if(srchParam == 5) {
    				dataMap =  tktInfoService.searchTktInfo(empId);
    			}else {
    				String[] wwids = new String[userSearchList.size()];
        			for(int i=0;i<userSearchList.size();i++) {
        				wwids[i] = userSearchList.get(i).getWwId();
        			}
        			if(wwids.length > 999) {
        				wwids = Arrays.copyOfRange(wwids, 0, 999);
        			}
        			dataMap =  tktInfoService.getUserTktInfo(wwids);
    			}

    			HttpSession session = request.getSession();
        		if(dataMap != null && !dataMap.isEmpty()) {
        			ArrayList<ReportDataModel> valueList = new ArrayList<>(dataMap.values());
        			Collections.sort(valueList, new RQCReportComparatorDesc());
        			session.setAttribute("REPORTData", valueList);
        			model.addAttribute("REPORTData", valueList);

        		}
        		model.addAttribute("message", "True");
        		log.debug("User RQC total count : "+((dataMap==null)?  "0":dataMap.size()));

        		String msg  = "Status: Associate RQC total count : "+ ((dataMap == null || dataMap.isEmpty() ) ?  "0": dataMap.size()+"");
        		model.addAttribute("success", msg);
    		}

        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "tickets/rqcTktInfo";
    }

	/*

	@ResponseBody
    @GetMapping("/downloadTktExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Excel Ticket Data");
		String fileNm ="RQCReport_"+request.getSession().getAttribute("DateRange");
		//List<Foo> newList = srcCollection.stream().collect(toList());
		List<ReportDataModel> repDataList = (List<ReportDataModel>) ((Collection)request.getSession().getAttribute("REPORTData")).stream().collect(Collectors.toList());

		String filePath = rqcReportService.createRQCCsvReport(fileNm, repDataList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

*/




}
