package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDAMenuItemMdl {
	private String 	role;
	private String 	menuItem;

	public String getData() {
		return  role + "~" + menuItem ;
	}



	@Override
	public String toString() {
		return "PersonalSysModel [role=" + role + ", menuItem=" + menuItem + "]";
	}

}
