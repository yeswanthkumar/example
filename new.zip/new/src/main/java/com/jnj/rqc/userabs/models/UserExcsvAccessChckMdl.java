package com.jnj.rqc.userabs.models;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class UserExcsvAccessChckMdl {
	private String 	userid;
	private Map<String, List<RoleADGrpMdl>> existingAccess;
	private Map<String, List<RoleADGrpMdl>> newAccess;
}
