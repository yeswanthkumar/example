package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.HanaRoleUserPrivilegeMdl;
import com.jnj.rqc.conflictModel.HanaUserGrantModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.dao.HANADataDao;
import com.jnj.rqc.dbconfig.TemplateFactory;




@Service
public class HANADataDaoImpl  extends TemplateFactory implements HANADataDao {
	static final Logger log = LoggerFactory.getLogger(HANADataDaoImpl.class);


	@Override
	public List<HanaUserGrantModel> getUserGrants(String templSysParam) throws SQLException, DataAccessException {
		log.info("Hana User to Role Data for Template Name : "+templSysParam);
		List<HanaUserGrantModel> grntData = new ArrayList<>();
		if(templSysParam.equalsIgnoreCase("NA_HANA_Production_BTBHANAHPG") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONEmptyTenantDBPEA")
				|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONTenantDBPB1") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONSYSTEMDBPEA")
				|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONEmptyTenantDBPEB")
				|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONTenantDBPEC") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONSYSTEMDBPEB")) {

				grntData = getBTBAndFusionUserGrants(templSysParam);
		}else if(templSysParam.equalsIgnoreCase("NA_BOBJ_Production_BTBBOBJBPG")) {
			grntData = getBTBBOBJBPGUserGrants(templSysParam);
		}else if(templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANASystemDB") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANASystemDB")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANAHPM") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANABPM")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANA") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANASystemDB")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANAHPC") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANABPC")
				|| templSysParam.equalsIgnoreCase("EMEA_HANA_Production_EMEAHANASYNTHES") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_EMEAHANASYNTHES1")) {
			grntData = getGalaxyAndSTFUserGrants(templSysParam);
		}
		else {
				grntData = getCommonUserGrants(templSysParam);
		}

		/*StringBuilder sqlB = new StringBuilder();
		sqlB.append(" SELECT a.GRANTEE AS wwId, a.GRANTEE_TYPE as type, b.ROLE_NAME as roleName, ");
		sqlB.append(" c.GRANTEE, c.GRANTEE_TYPE, c.OBJECT_TYPE AS objType, c.OBJECT_NAME AS objName, ");
		sqlB.append(" c.COLUMN_NAME AS colName, c.PRIVILEGE, c.IS_VALID AS valid   ");
		sqlB.append(" FROM  SYS.GRANTED_ROLES a LEFT OUTER JOIN SYS.GRANTED_ROLES b ON a.ROLE_NAME = b.GRANTEE ");
		sqlB.append(" LEFT JOIN SYS.GRANTED_PRIVILEGES c ON b.ROLE_NAME = c.GRANTEE ");
		sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND b.GRANTEE_TYPE='ROLE' AND b.ROLE_NAME <> 'PUBLIC' ");
		sqlB.append(" ORDER BY a.GRANTEE, b.ROLE_NAME, c.PRIVILEGE ");
			//ADD FACTORY METHOD FOR JDBC TEMPLATE
		if(null==templSysParam || templSysParam.length()== 0) {
			//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
			grntData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
		}else {
			grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
		}*/

		log.info("Total rows returned : "+((grntData !=null) ? grntData.size():"0"));
		return grntData;
	}


	private List<HanaUserGrantModel> getGalaxyAndSTFUserGrants(String templSysParam) throws SQLException, DataAccessException {
		List<HanaUserGrantModel> grntData = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();
		sqlB.append(" SELECT GRANTEE  AS wwId, GRANTEE_TYPE as type, ROLE_NAME as roleName ");
		sqlB.append(" FROM SYS.GRANTED_ROLES WHERE GRANTEE_TYPE = 'USER' AND ROLE_NAME NOT LIKE '%sap%' AND (GRANTEE NOT LIKE '%_SYS%') AND (GRANTEE NOT LIKE '%XSSQL%') ");
		sqlB.append(" AND (GRANTEE NOT LIKE 'SYSTEM') AND (GRANTEE NOT LIKE '%SAPDB%') AND (GRANTEE NOT LIKE '%CR5%') AND (GRANTEE NOT LIKE '%MONITOR%') ");
		sqlB.append(" AND (GRANTEE NOT LIKE '%COCKPIT%') AND (GRANTEE NOT LIKE '%SAPSUP%') AND (GRANTEE NOT LIKE '%SAPDAT%') AND (ROLE_NAME NOT LIKE 'PUBLIC') ");

		/*OLD Query -- sqlB.append(" SELECT distinct a.GRANTEE AS wwId, a.GRANTEE_TYPE as type, a.ROLE_NAME as roleName, c.GRANTEE, c.GRANTEE_TYPE, ");
		sqlB.append(" '' AS objType, '' AS objName, '' AS colName, '' AS PRIVILEGE, c.IS_VALID AS valid ");
		sqlB.append(" FROM SYS.GRANTED_ROLES a LEFT JOIN SYS.GRANTED_PRIVILEGES c ON a.ROLE_NAME = c.GRANTEE ");
		sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND a.ROLE_NAME <> 'PUBLIC' ");*/

		grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaUserGrantModel.class));
		log.info("Total rows returned : "+((grntData !=null) ? grntData.size():"0"));
		return grntData;
	}

	private List<HanaUserGrantModel> getBTBBOBJBPGUserGrants(String templSysParam) throws SQLException, DataAccessException {
		List<HanaUserGrantModel> grntData = new ArrayList<>();
		Map<String, List<String>> usrRoleMap = new HashMap<>();
		StringBuilder sqlB = new StringBuilder();
		//sqlB.append(" SELECT SI_NAME,SI_DESCRIPTION FROM ci_systemobjects WHERE si_kind = 'UserGroup'");
		sqlB.append(" SELECT SI_NAME FROM ci_systemobjects WHERE si_kind = 'UserGroup'");
		List<String> roleList = getJdbcTemplateFact(templSysParam).queryForList(sqlB.toString(), String.class);
		if(roleList != null && !roleList.isEmpty()) {
			int i=0;
			for(String role : roleList) {
				System.out.println(++i+".Role: "+role);
				StringBuilder sql2 = new StringBuilder();
				//sql2.append(" SELECT SI_KIND, SI_NAME, SI_EMAIL_ADDRESS,SI_USERFULLNAME ");
				sql2.append(" SELECT SI_NAME  FROM ci_systemobjects ");
				sql2.append(" WHERE descendants(\"SI_NAME\" ='Usergroup-User', \"SI_NAME\"='"+role+"' ");
				List<String> userList = getJdbcTemplateFact(templSysParam).queryForList(sql2.toString(), String.class);
				if(userList != null && !userList.isEmpty()) {
					List<String> rlsLst = null;
					for(String usrId : userList) {
						if(usrRoleMap.containsKey(usrId)) {
							rlsLst = usrRoleMap.get(usrId);
							rlsLst.add(role);
						}else {
							rlsLst = new ArrayList<>();
							rlsLst.add(role);
						}
						usrRoleMap.put(usrId, rlsLst);
					}
				}
			}
		}

		if(!usrRoleMap.isEmpty() && usrRoleMap.size() > 0 ) {
			for(Map.Entry<String, List<String>> entry : usrRoleMap.entrySet()) {
				String usrId = entry.getKey();
				List<String> usrRols = entry.getValue();
				for(String rlId : usrRols) {
					HanaUserGrantModel ugm = new HanaUserGrantModel();
					ugm.setWwId(usrId);
					ugm.setRoleName(rlId);
					ugm.setValid("Y");
					grntData.add(ugm);
				}
			}
		}

		return grntData;
	}


	private List<HanaUserGrantModel> getBTBAndFusionUserGrants(String templSysParam) throws SQLException, DataAccessException {
		List<HanaUserGrantModel> grntData = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();

		sqlB.append(" SELECT distinct a.GRANTEE AS wwId, a.GRANTEE_TYPE as type, a.ROLE_NAME as roleName, c.GRANTEE, c.GRANTEE_TYPE, ");
		sqlB.append(" '' AS objType, '' AS objName, '' AS colName, '' AS PRIVILEGE, c.IS_VALID AS valid ");
		sqlB.append(" FROM SYS.GRANTED_ROLES a LEFT JOIN SYS.GRANTED_PRIVILEGES c ON a.ROLE_NAME = c.GRANTEE ");
		sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND a.ROLE_NAME <> 'PUBLIC' ");

		grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaUserGrantModel.class));
		log.info("Total rows returned : "+((grntData !=null) ? grntData.size():"0"));
		return grntData;
	}

	private List<HanaUserGrantModel> getCommonUserGrants(String templSysParam) throws SQLException, DataAccessException {
		List<HanaUserGrantModel> grntData = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();
		sqlB.append(" SELECT a.GRANTEE AS wwId, a.GRANTEE_TYPE as type, b.ROLE_NAME as roleName, ");
		sqlB.append(" c.GRANTEE, c.GRANTEE_TYPE, c.OBJECT_TYPE AS objType, c.OBJECT_NAME AS objName, ");
		sqlB.append(" c.COLUMN_NAME AS colName, c.PRIVILEGE, c.IS_VALID AS valid   ");
		sqlB.append(" FROM  SYS.GRANTED_ROLES a LEFT OUTER JOIN SYS.GRANTED_ROLES b ON a.ROLE_NAME = b.GRANTEE ");
		sqlB.append(" LEFT JOIN SYS.GRANTED_PRIVILEGES c ON b.ROLE_NAME = c.GRANTEE ");
		sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND b.GRANTEE_TYPE='ROLE' AND b.ROLE_NAME <> 'PUBLIC' ");
		sqlB.append(" ORDER BY a.GRANTEE, b.ROLE_NAME, c.PRIVILEGE ");
		//ADD FACTORY METHOD FOR JDBC TEMPLATE
		/*if(null==templSysParam || templSysParam.length()== 0) {
			//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
			grntData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
		}else {*/
			grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaUserGrantModel.class));
		//}
		return grntData;
	}



	@Override
	public List<SAPUserAccessModel> getUserTrfContrlData(String templSysParam) throws SQLException, DataAccessException {
		log.info("Get Hana Grants for User for Template Name : "+templSysParam);
		List<SAPUserAccessModel> grntData = new ArrayList<>();
		if(templSysParam.equalsIgnoreCase("NA_HANA_Production_BTBHANAHPG") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONEmptyTenantDBPEA")
			|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONTenantDBPB1") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONSYSTEMDBPEA")
			|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONEmptyTenantDBPEB")
			|| templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONTenantDBPEC") || templSysParam.equalsIgnoreCase("NA_HANA_Production_FUSIONSYSTEMDBPEB")) {

			grntData = getBTBFUSIONHANAHPGUserTrfContrlData(templSysParam);
		}else if(templSysParam.equalsIgnoreCase("NA_BOBJ_Production_BTBBOBJBPG")) {
			grntData = getBTBBOBJBPGUserTrfContrlData(templSysParam);
		}else if(templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANASystemDB") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANASystemDB")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANAHPM") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_GALAXYHANABPM")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANA") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANASystemDB")
				||templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANAHPC") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_STFHANABPC")
				|| templSysParam.equalsIgnoreCase("EMEA_HANA_Production_EMEAHANASYNTHES") || templSysParam.equalsIgnoreCase("EMEA_HANA_Production_EMEAHANASYNTHES1")) {
			grntData = getGalaxyAndSTFHANATrfContrlData(templSysParam);
		}else {
			grntData = getCommonUserTrfContrlData(templSysParam);
		}
		log.info("Total rows returned : "+((grntData !=null) ? grntData.size():"0"));
		return grntData;
	}

	private List<SAPUserAccessModel> getGalaxyAndSTFHANATrfContrlData(String templSysParam) throws SQLException, DataAccessException {
		List<SAPUserAccessModel> grntData = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();
		sqlB.append(" SELECT GRANTEE AS wwId, GRANTEE AS NT_ID, GRANTEE AS SAP_ID ");
		sqlB.append(" FROM SYS.GRANTED_ROLES WHERE GRANTEE_TYPE = 'USER' AND ROLE_NAME NOT LIKE '%sap%' AND (GRANTEE NOT LIKE '%_SYS%') ");
		sqlB.append(" AND (GRANTEE NOT LIKE '%XSSQL%') AND (GRANTEE NOT LIKE 'SYSTEM') AND (GRANTEE NOT LIKE '%SAPDB%') AND (GRANTEE NOT LIKE '%CR5%') ");
		sqlB.append(" AND (GRANTEE NOT LIKE '%MONITOR%') AND (GRANTEE NOT LIKE '%COCKPIT%') AND (GRANTEE NOT LIKE '%SAPSUP%') AND (GRANTEE NOT LIKE '%SAPDAT%') ");
		sqlB.append(" AND (ROLE_NAME NOT LIKE 'PUBLIC') ");
		grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return grntData;
	}
	private List<SAPUserAccessModel> getBTBBOBJBPGUserTrfContrlData(String templSysParam) throws SQLException, DataAccessException {
		List<SAPUserAccessModel> grntData = new ArrayList<>();
		List<String> allUsers = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();
		//sqlB.append(" SELECT SI_NAME,SI_DESCRIPTION FROM ci_systemobjects WHERE si_kind = 'UserGroup'");
		sqlB.append(" SELECT SI_NAME FROM ci_systemobjects WHERE si_kind = 'UserGroup'");
		List<String> roleList = getJdbcTemplateFact(templSysParam).queryForList(sqlB.toString(), String.class);
		if(roleList != null && !roleList.isEmpty()) {
			for(String role : roleList) {
				StringBuilder sql2 = new StringBuilder();
				//sql2.append(" SELECT SI_KIND, SI_NAME, SI_EMAIL_ADDRESS,SI_USERFULLNAME ");
				sql2.append(" SELECT SI_NAME  FROM ci_systemobjects ");
				sql2.append(" WHERE descendants(\"SI_NAME\" ='Usergroup-User', \"SI_NAME\"='"+role+"' ");
				List<String> userList = getJdbcTemplateFact(templSysParam).queryForList(sql2.toString(), String.class);
				if(userList != null && !userList.isEmpty()) {
					for(String usrId : userList) {
						usrId = usrId.trim();
						if(!allUsers.contains(usrId)) {
							allUsers.add(usrId);
							SAPUserAccessModel usrMdl = new SAPUserAccessModel();
							usrMdl.setWwid(usrId);
							usrMdl.setNtId(usrId);
							usrMdl.setSapId(usrId);
							grntData.add(usrMdl);
						}
					}
				}
			}
		}
		return grntData;
	}


	private List<SAPUserAccessModel> getBTBFUSIONHANAHPGUserTrfContrlData(String templSysParam) throws SQLException, DataAccessException {
		List<SAPUserAccessModel> grntData = new ArrayList<>();
		StringBuilder sqlB = new StringBuilder();
		sqlB.append(" SELECT distinct a.GRANTEE AS wwId, a.GRANTEE AS NT_ID, a.GRANTEE AS SAP_ID ");
		sqlB.append(" FROM SYS.GRANTED_ROLES a ");
		sqlB.append(" LEFT JOIN SYS.GRANTED_PRIVILEGES c ON a.ROLE_NAME = c.GRANTEE ");
		sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND a.ROLE_NAME <> 'PUBLIC' ");
		grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return grntData;
	}

	private List<SAPUserAccessModel> getCommonUserTrfContrlData(String templSysParam) throws SQLException, DataAccessException {
		//log.info("Template Name : "+templSysParam);
		List<SAPUserAccessModel> grntData = new ArrayList<>();
			StringBuilder sqlB = new StringBuilder();
			sqlB.append(" SELECT a.GRANTEE AS wwId, a.GRANTEE AS NT_ID, a.GRANTEE AS SAP_ID ");
			/*,a.GRANTEE_TYPE as type, b.ROLE_NAME as roleName, ");
			sqlB.append(" c.GRANTEE, c.GRANTEE_TYPE, c.OBJECT_TYPE AS objType, c.OBJECT_NAME AS objName, ");
			sqlB.append(" c.COLUMN_NAME AS colName, c.PRIVILEGE, c.IS_VALID AS valid   ");*/
			sqlB.append(" FROM  SYS.GRANTED_ROLES a LEFT OUTER JOIN SYS.GRANTED_ROLES b ON a.ROLE_NAME = b.GRANTEE ");
			sqlB.append(" LEFT JOIN SYS.GRANTED_PRIVILEGES c ON b.ROLE_NAME = c.GRANTEE ");
			sqlB.append(" WHERE a.GRANTEE_TYPE='USER' AND b.GRANTEE_TYPE='ROLE' AND b.ROLE_NAME <> 'PUBLIC' ");
			sqlB.append(" ORDER BY a.GRANTEE ");
			//ADD FACTORY METHOD FOR JDBC TEMPLATE
			if(null==templSysParam || templSysParam.length()== 0) {
				//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
				grntData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
			}else {
				grntData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
			}

			log.info("Total rows returned : "+((grntData !=null) ? grntData.size():"0"));
			return grntData;
	}

	@Override
	public List<HanaRoleUserPrivilegeMdl> getRolePrivilegeData(String templSysParam, String roleNames) throws SQLException, DataAccessException {
		log.info("Gathering ROLE + PRIVILEGE Data for : roleNames : "+roleNames+" templSysParam: "+templSysParam);
		String[] newRoleNames=null;

		List<HanaRoleUserPrivilegeMdl> rlPrivData = new ArrayList<>();
			StringBuilder sqlB = new StringBuilder();
			sqlB.append(" SELECT GRANTEE_SCHEMA_NAME, GRANTEE, GRANTEE_TYPE, GRANTOR, OBJECT_TYPE, SCHEMA_NAME, OBJECT_NAME, COLUMN_NAME, PRIVILEGE, IS_GRANTABLE, IS_VALID ");
			sqlB.append(" FROM SYS.GRANTED_PRIVILEGES ");
			sqlB.append(" WHERE GRANTEE_TYPE='ROLE' AND GRANTEE <> 'PUBLIC' ");
			if(null !=roleNames && roleNames.length() >0) {
				newRoleNames = roleNames.split(",");
				if(newRoleNames != null ) {
					if(newRoleNames.length == 1) {
						sqlB.append(" AND GRANTEE='"+newRoleNames[0]+"' ");
					}else {
						sqlB.append(" AND GRANTEE in (");
						for(int i=0; i<newRoleNames.length;i++) {
							sqlB.append(" '"+newRoleNames[i]+"' ");
							if(i<(newRoleNames.length -1)) {
								sqlB.append(", ");
							}
						}
						sqlB.append(" )");
					}
				}
			}
			sqlB.append(" ORDER BY GRANTEE_TYPE ");
			if(null==templSysParam || templSysParam.length()== 0) {
				//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
				rlPrivData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaRoleUserPrivilegeMdl.class));
			}else {
				rlPrivData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaRoleUserPrivilegeMdl.class));
			}
			log.info("Total rows returned : "+((rlPrivData !=null) ? rlPrivData.size():"0"));
			//rlPrivData.forEach(c->{System.out.println(c);});
			return rlPrivData;

	}


	@Override
	public List<HanaRoleUserPrivilegeMdl> getUserDirectPrivilegeData(String templSysParam) throws SQLException, DataAccessException {
		log.info("Gathering ROLE + PRIVILEGE Data for USER on System:  "+templSysParam);
		List<HanaRoleUserPrivilegeMdl> rlPrivData = new ArrayList<>();
			StringBuilder sqlB = new StringBuilder();
			sqlB.append(" SELECT GRANTEE_SCHEMA_NAME, GRANTEE, GRANTEE_TYPE, GRANTOR, OBJECT_TYPE, SCHEMA_NAME, OBJECT_NAME, COLUMN_NAME, PRIVILEGE, IS_GRANTABLE, IS_VALID ");
			sqlB.append(" FROM SYS.GRANTED_PRIVILEGES ");
			sqlB.append(" WHERE GRANTEE_TYPE='USER' AND GRANTEE NOT LIKE '%SYS%' ");
			sqlB.append(" ORDER BY GRANTEE ");
			if(null==templSysParam || templSysParam.length()== 0) {
				//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
				rlPrivData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaRoleUserPrivilegeMdl.class));
			}else {
				rlPrivData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<>(HanaRoleUserPrivilegeMdl.class));
			}
			log.info("Total User rows returned : "+((rlPrivData !=null) ? rlPrivData.size():"0"));
			//rlPrivData.forEach(c->{System.out.println(c);});
			return rlPrivData;
	}





}
