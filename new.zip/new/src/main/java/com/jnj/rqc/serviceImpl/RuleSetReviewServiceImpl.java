package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.RuleSetReviewDao;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.ruleset.models.RuleSetModel;
import com.jnj.rqc.ruleset.models.RuleSetSmryModel;
import com.jnj.rqc.service.RuleSetReviewService;
import com.jnj.rqc.util.Utility;

@Service
public class RuleSetReviewServiceImpl implements RuleSetReviewService {
	static final Logger log = LoggerFactory.getLogger(RuleSetReviewServiceImpl.class);

	@Autowired
	RuleSetReviewDao ruleSetReviewDao;

	@Autowired
	CSVReportWriter cSVReportWriter;

	@Override
	public List<RuleSetSmryModel> getRuleSetSummary() {
		List<RuleSetSmryModel> summaryList = new ArrayList<>();
		try{
			summaryList =  ruleSetReviewDao.getRuleSetSummary();
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}


		return summaryList;
	}


	@Override
	public Map<String, List<RuleSetModel>> getRuleSetData(List<RuleSetSmryModel> summaryList) {
		Map<String, List<RuleSetModel>> reuleSetDataMap = new HashMap<>();
		List<RuleSetModel> dataList = new ArrayList<>();
		String app1 = "";
		String app2 = "";
		try{
			for(RuleSetSmryModel rlsMdl : summaryList) {
				app1 = rlsMdl.getApp1();
				app2 = rlsMdl.getApp2();
				rlsMdl.setQuery("SELECT APP1, APP2, substr(CONFLICT, 0, (instr(CONFLICT, '\\')-1)) as ROLE1,  substr(CONFLICT, instr(CONFLICT, '\\')+1) as ROLE2, MITIGATING_CONTROL  FROM SOD_EXTR.CONFLICT_MATRIX  WHERE APP1=? and APP2 = ?");
				dataList = ruleSetReviewDao.getRuleSetData(app1, app2);
				rlsMdl.setCreated(new Date());
				if(!dataList.isEmpty()) {
					reuleSetDataMap.put(app1.replace("/", "_")+"-"+app2.replace("/", "_"), dataList);
				}
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return reuleSetDataMap;
	}


	@Override
	public Map<String, String> generateRuleSetFiles(Map<String, List<RuleSetModel>> dataMap, String strDate, HttpServletRequest request) {
		Map<String, String> fileMap = new HashMap<>();
		String outFile = "";
		String dirPath = Constants.RULESET_OUT_LOC+"RuleSet_"+strDate;
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("RULESETDIR", dirPath);
		for (Map.Entry<String, List<RuleSetModel>> fileData : dataMap.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_"+strDate+".csv";
			outFile = createCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;
	}

	@Override
	public String createCSV(List<RuleSetModel> data, String fileName) {
		String filePath = cSVReportWriter.writeRuleSetCSVReport(data, fileName);
		return filePath;
	}

	@Override
	public String createSummaryCSV(List<RuleSetSmryModel> data, String fileName) {
		String filePath = cSVReportWriter.writeRuleSetSummaryReport(data, fileName);
		return filePath;
	}


	@Override
	public void updateFileLocation(List<RuleSetSmryModel> summaryList, Map<String, String> ruleSetFileMap) {

		if(summaryList != null && !summaryList.isEmpty()) {
			String app1 = "";
			String app2 = "";
			String key  = "";
			for(RuleSetSmryModel smry : summaryList)  {
				app1 = smry.getApp1();
				app2 = smry.getApp2();
				key = app1.replace("/", "_")+"-"+app2.replace("/", "_");
				if(ruleSetFileMap.containsKey(key)) {
					smry.setFileLoc(ruleSetFileMap.get(key));
				}
			}
		}

	}


}
