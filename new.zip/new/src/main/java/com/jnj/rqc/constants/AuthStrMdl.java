package com.jnj.rqc.constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthStrMdl {
	//String str ="{\"AuthString\":  \"Module=RoleBasedManualADS;User=JNJ\\\\SA-HCS-SOD_DB_USER; Password=System#321\"}";
	//private String AuthString = "Module=RoleBasedManualADS;User=JNJ\\SA-HCS-SOD_DB_USER;Password=System#321";
	private String AuthString;
}
