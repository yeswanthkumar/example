package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.CSIFunctionActionModel;
import com.jnj.rqc.conflictModel.CSIFunctionPermModel;
import com.jnj.rqc.conflictModel.CSISodCriticalActRiskModel;
import com.jnj.rqc.conflictModel.CSISodRiskModel;
import com.jnj.rqc.conflictModel.RoleToSodModel;
import com.jnj.rqc.conflictModel.UserToSodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.service.CSIDataService;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

@Controller
public class CSIDataController {
	static final Logger log = LoggerFactory.getLogger(CSIDataController.class);

	@Autowired
	private RqcSapConflictService RqcSapConflictService;

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	CSIDataService csiDataService;

	@Autowired
	EmailUtil emailUtil;

	String BASE_PLTFRM = "PLATFORM";

    @GetMapping("/loadCSIUserToSODPage")
    public String loadCSIUserToSOD(Model model, HttpServletRequest request) {
    	List<String> platformNames = Utility.loadCSIProperty(BASE_PLTFRM);
    	model.addAttribute("Platforms", platformNames );
    	return "csi/csiUsertoSod";
    }

    	/**
    	 * Method  : CSIDataController.java.getEnvironmentData()
    	 *		   :<b>@param model
    	 *		   :<b>@param dBSchema
    	 *		   :<b>@param req
    	 *		   :<b>@return</b>
    	 * @author : DChauras  @Created :Dec 14, 2020 4:10:13 PM
    	 * Purpose :Loading Drop down values when user makes a selection on Platform,Environment, Sub Environments
    	 * @return : ResponseEntity<TableRespDto>
    	 */
    @PostMapping("/getEnvironmentData")
    public ResponseEntity<TableRespDto> getEnvironmentData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Property name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = csiDataService.getEnvData(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping("/loadCSIUserToSOD")
    public String loadCSIUserToSOD(Model model, @RequestParam("Platform") String Platform, @RequestParam("envNames") String envNames,
    		@RequestParam("subEnvNames") String subEnvNames, @RequestParam("empId") String empId, @RequestParam("roleIds") String roleIds, HttpServletRequest request) {
    	log.info("Platform: "+Platform+"  envNames: "+envNames+"  subEnvNames: "+subEnvNames+"  empId: "+empId);
    	String pltParam 	= Platform;
    	String selEnvs 		= envNames;
    	String selSubEnvs 	= subEnvNames;
    	String empIdParam 	= empId;
    	String roleIdsParam 	= roleIds;

    	List<String> platformLst = Utility.loadCSIProperty(BASE_PLTFRM);
    	model.addAttribute("pltParam", pltParam);
    	model.addAttribute("Platforms", platformLst);

    	List<String> envLst = Utility.loadCSIProperty(pltParam);
    	model.addAttribute("selEnvs", selEnvs);
    	model.addAttribute("environmentNames", envLst);

    	List<String> subEnvLst = Utility.loadCSIProperty(pltParam+"_"+selEnvs);
    	model.addAttribute("selSubEnvs", selSubEnvs);
    	model.addAttribute("subEnvNames", subEnvLst);

    	model.addAttribute("empIdParam", empIdParam);
    	model.addAttribute("roleIdsParam", roleIdsParam);

    	String filePath = Constants.CSI_BASE_LOC_USR2SOD + "/" + Platform + "/" + envNames + "/" + subEnvNames ;
    	String latestFile = getLatestFile(filePath);
    	if(null==latestFile || latestFile.length() <=0) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for USER2SOD Report, please check the values and try again.") ;
             return "csi/csiUsertoSod";
    	}

    	Map<String, List<UserToSodModel>> usr2Sod = csiDataService.readUserToSodData(filePath+"/"+latestFile, empIdParam, roleIds);
    	request.getSession().setAttribute("USER2SOD", usr2Sod.get("USER2SOD"));
    	model.addAttribute("USER2SOD", usr2Sod.get("USER2SOD"));
    	List<UserToSodModel> nwRls = usr2Sod.get("NEWROLESSODLIST");
    	if(nwRls != null && !nwRls.isEmpty()) {
    		request.getSession().setAttribute("NEWROLESSODLIST", nwRls);
        	model.addAttribute("NEWROLESSODLIST", nwRls);
    	}


    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((usr2Sod.get("USER2SOD")==null || usr2Sod.get("USER2SOD").isEmpty())? "0":(usr2Sod.get("USER2SOD")).size()+""));
		model.addAttribute("success1" , "Total Records retrieved: "+((nwRls==null || nwRls.isEmpty())? "0":nwRls.size()+""));
    	return "csi/csiUsertoSod";
    }


	@ResponseBody
    @GetMapping("/downCSIUser2SodExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downCSIUser2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSIUser2SodExcel ");
		String fileNm ="User2Sod";
		List<UserToSodModel> usr2SodLst = (List<UserToSodModel>)request.getSession().getAttribute("USER2SOD");
		String filePath = csiDataService.writeCSIUser2SodCsvReport(usr2SodLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downCSIUserNewRoleSodExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downCSIUserNewRoleSodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSIUser2SodExcel ");
		String fileNm ="NewRolesUser2Sod";
		List<UserToSodModel> usr2SodLst = (List<UserToSodModel>)request.getSession().getAttribute("NEWROLESSODLIST");
		String filePath = csiDataService.writeCSIUser2SodCsvReport(usr2SodLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }
		/**
		 * Method  : CSIDataController.java.getLatestFile()
		 *		   :<b>@param dirPath
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Dec 15, 2020 5:08:11 PM
		 * Purpose :List the files in a directory and finds the latest file based on Date modified attribute of files
		 * @return : String
		 */
	private String getLatestFile(String dirPath) {
		File folder = new File(dirPath);
    	File[] files = folder.listFiles();
    	long modDt = 0;
    	String latestFile ="";
    	if(files != null && files.length > 0) {
    		for(File fl:files) {
        		long lstMdDt = fl.lastModified();
        		if(lstMdDt > modDt ) {
        			modDt = lstMdDt;
        			latestFile=fl.getName();
        		}
        	}
    	}
    	log.info("Selected Latest file :"+latestFile);
    	return latestFile;
	}


	@GetMapping("/loadCSIRoleToSODPage")
    public String loadCSIRoleToSODPage(Model model, HttpServletRequest request) {
    	List<String> platformNames = Utility.loadCSIProperty(BASE_PLTFRM);
    	model.addAttribute("Platforms", platformNames );
    	return "csi/csiRoletoSod";
    }

	@PostMapping("/loadCSIRoleToSOD")
    public String loadCSIRoleToSOD(Model model, @RequestParam("Platform") String Platform, @RequestParam("envNames") String envNames, @RequestParam("subEnvNames") String subEnvNames, @RequestParam("rlsId") String rlsId, HttpServletRequest request) {
    	log.info("Platform: "+Platform+"  envNames: "+envNames+"  subEnvNames: "+subEnvNames+"  roleId: "+rlsId);
    	String pltParam 	= Platform;
    	String selEnvs 		= envNames;
    	String selSubEnvs 	= subEnvNames;
    	String rlsIdParam 	= rlsId;

    	List<String> platformLst = Utility.loadCSIProperty(BASE_PLTFRM);
    	model.addAttribute("pltParam", pltParam);
    	model.addAttribute("Platforms", platformLst);

    	List<String> envLst = Utility.loadCSIProperty(pltParam);
    	model.addAttribute("selEnvs", selEnvs);
    	model.addAttribute("environmentNames", envLst);

    	List<String> subEnvLst = Utility.loadCSIProperty(pltParam+"_"+selEnvs);
    	model.addAttribute("selSubEnvs", selSubEnvs);
    	model.addAttribute("subEnvNames", subEnvLst);

    	model.addAttribute("rlsIdParam", rlsIdParam);
    	String filePath = Constants.CSI_BASE_LOC_ROLE2SOD + "/" + Platform + "/" + envNames + "/" + subEnvNames ;
    	String latestFile = getLatestFile(filePath);
    	if(null==latestFile || latestFile.length() <=0) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for ROLE2SOD Report, please check the values and try again.") ;
             return "csi/csiRoletoSod";
    	}

    	List<RoleToSodModel> role2Sod = csiDataService.readRoleToSodData(filePath+"/"+latestFile, rlsIdParam);
    	model.addAttribute("ROLE2SOD", role2Sod);
    	request.getSession().setAttribute("ROLE2SOD", role2Sod);

    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((role2Sod==null || role2Sod.isEmpty())? "0":role2Sod.size()+""));

    	return "csi/csiRoletoSod";
    }


	@ResponseBody
    @GetMapping("/downCSIRole2SodExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downCSIRole2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSIRole2SodExcel ");
		String fileNm ="Role2Sod";
		List<RoleToSodModel> rls2SodLst = (List<RoleToSodModel>)request.getSession().getAttribute("ROLE2SOD");
		String filePath = csiDataService.writeCSIRole2SodCsvReport(rls2SodLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	@GetMapping("/loadCSISodRisk")
    public String loadCSISodRisk(Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI SOD RISK ");
    	String filePath = Constants.CSI_BASE_LOC_MATRIX + "/"+Constants.CSI_SOD_RISK_TABLE ;
    	File latestFile = new File(filePath);
    	if(!(latestFile.exists() && latestFile.isFile())) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for CSI SOD RISK, File does not exists/data corrupted.") ;
             return "csi/csiSodRiskPage";
    	}

    	List<CSISodRiskModel> sodRiskLst = csiDataService.readSodRiskData(filePath);
    	model.addAttribute("SODRISKDATA", sodRiskLst);
    	request.getSession().setAttribute("SODRISKDATA", sodRiskLst);

    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((sodRiskLst==null || sodRiskLst.isEmpty())? "0":sodRiskLst.size()+""));

    	return "csi/csiSodRiskPage";
    }


	@ResponseBody
    @GetMapping("/downCSISodRiskExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downCSISodRiskExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSISodRiskExcel ");
		String fileNm ="CSISodRisk";
		List<CSISodRiskModel> sodRskLst = (List<CSISodRiskModel>)request.getSession().getAttribute("SODRISKDATA");
		String filePath = csiDataService.writeCSISodRiskCsvReport(sodRskLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@GetMapping("/loadCSICriticalActRisk")
    public String loadCSICriticalActRisk(Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI SOD CRITICAL ACTION RISK DATA");
    	String filePath = Constants.CSI_BASE_LOC_MATRIX + "/"+Constants.CSI_CRITICAL_RISK_ACT_TABLE ;
    	File latestFile = new File(filePath);
    	if(!(latestFile.exists() && latestFile.isFile())) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for CSI SOD CRITICAL ACTION RISK, File does not exists/data corrupted.") ;
             return "csi/csiCriticalActionRiskPage";
    	}

    	List<CSISodCriticalActRiskModel> sodCriRiskLst = csiDataService.readSodCriticalActRiskData(filePath);
    	model.addAttribute("CRITICALACTDATA", sodCriRiskLst);
    	request.getSession().setAttribute("CRITICALACTDATA", sodCriRiskLst);

    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((sodCriRiskLst==null || sodCriRiskLst.isEmpty())? "0":sodCriRiskLst.size()+""));

    	return "csi/csiCriticalActionRiskPage";
    }


	@ResponseBody
    @GetMapping("/csiCriticalActionRiskExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> csiCriticalActionRiskExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSI Critical Action Risk Excel ");
		String fileNm ="CSICriticalActionRisk";
		List<CSISodCriticalActRiskModel> criRskLst = (List<CSISodCriticalActRiskModel>)request.getSession().getAttribute("CRITICALACTDATA");
		String filePath = csiDataService.writeCSISodCriticalActRiskCsvReport(criRskLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }




	@GetMapping("/loadCSIFunctionAction")
    public String loadCSIFunctionAction(Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI FUNCTION ACTION DATA");
    	String filePath = Constants.CSI_BASE_LOC_MATRIX + "/"+Constants.CSI_FUNCTION_ACT_TABLE ;
    	File latestFile = new File(filePath);
    	if(!(latestFile.exists() && latestFile.isFile())) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for CSI SOD FUNCTION ACTION DATA, File does not exists/data corrupted.") ;
             return "csi/functionActionPage";
    	}
    	List<CSIFunctionActionModel> funcActLst = csiDataService.readSodFunctionActData(filePath);
    	model.addAttribute("FUNCTIONACTIONDATA", funcActLst);
    	request.getSession().setAttribute("FUNCTIONACTIONDATA", funcActLst);

    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((funcActLst==null || funcActLst.isEmpty())? "0":funcActLst.size()+""));

    	return "csi/functionActionPage";
    }


	@ResponseBody
    @GetMapping("/csiFunctionActionExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> csiFunctionActionExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSI Function Action Excel ");
		String fileNm ="CSIFunctionActionData";
		List<CSIFunctionActionModel> funcActLst = (List<CSIFunctionActionModel>)request.getSession().getAttribute("FUNCTIONACTIONDATA");
		String filePath = csiDataService.writeCSISodFunctionActCsvReport(funcActLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@SuppressWarnings("all")
	@GetMapping("/loadCSIFunctionPermission")
    public String loadCSIFunctionPermission(Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI FUNCTION PERMISSION DATA");
    	String filePath = Constants.CSI_BASE_LOC_MATRIX + "/"+Constants.CSI_FUNCTION_PERMISSIONS_TABLE ;
    	File latestFile = new File(filePath);
    	if(!(latestFile.exists() && latestFile.isFile())) {
    		 model.addAttribute("message", "True");
             model.addAttribute("error", "No Data found for CSI SOD FUNCTION PERMISSION DATA, File does not exists/data corrupted.") ;
             return "csi/functionPermissionPage";
    	}
    	HttpSession sess = request.getSession();
    	List<CSIFunctionPermModel> funcPermLst = null;
    	if(Utility.getCache("FUNCTIONPERMDATA") == null) {
    		funcPermLst = csiDataService.readSodFunctionPermData(filePath);
    		Utility.setCache("FUNCTIONPERMDATA", funcPermLst);
    	}else {
    		funcPermLst = (List<CSIFunctionPermModel>)Utility.getCache("FUNCTIONPERMDATA");
    	}
    	Map<Integer, List<CSIFunctionPermModel>> pagedMap = Utility.paginateData(funcPermLst, Constants.CSI_PAGE_LIMIT);
    	Utility.setCache("FUNCTIONPERMDATAPGDATA", pagedMap);
    	int currentPage = 1;
    	int totalPages = pagedMap.size();
    	List<Integer> pgList = Utility.getPageList(totalPages);
    	sess.setAttribute("LISTOFPAGES", pgList);
    	model.addAttribute("LISTOFPAGES", pgList);
    	List<CSIFunctionPermModel> currPageData = pagedMap.get(currentPage);
    	model.addAttribute("FUNCTIONPERMDATA", currPageData);
    	model.addAttribute("currentPage", currentPage);
    	sess.setAttribute("currentPage", currentPage);
    	model.addAttribute("totalPages", totalPages);
    	sess.setAttribute("totalPages", totalPages);
    	model.addAttribute("totalRecords", funcPermLst.size());
    	sess.setAttribute("totalRecords", funcPermLst.size());
    	model.addAttribute("totalRecordsInPage", currPageData.size());
    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+((funcPermLst==null || funcPermLst.isEmpty())? "0":funcPermLst.size()+""));
    	return "csi/functionPermissionPage";
    }

	@SuppressWarnings("all")
	@GetMapping("/loadCSIFunctionPermissionPaging/{prevNext}")
    public String loadCSIFuncPermissionPaginate(@PathVariable String prevNext, Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI FUNCTION PERMISSION DATA prevNext:"+prevNext);
    	Map<Integer, List<CSIFunctionPermModel>> pagedMap = (Map<Integer, List<CSIFunctionPermModel>>)Utility.getCache("FUNCTIONPERMDATAPGDATA");
    	HttpSession sess = request.getSession();
    	int currentPage = 0;
    	int totalPages = 1;
    	try {
    		totalPages =Integer.parseInt(sess.getAttribute("totalPages").toString());
    		currentPage = Integer.parseInt(sess.getAttribute("currentPage").toString());
    		if("NEXT".equals(prevNext) && currentPage < totalPages) {
    			currentPage ++;
    		}else if("PREV".equals(prevNext) && currentPage > 1) {
    			currentPage--;
    		}
    		sess.setAttribute("currentPage", currentPage);
    	} catch (Exception e) {
			log.error("Error navigating pages:"+e.getMessage(),e);
			currentPage = 1;
		}
    	List<Integer> pgList = Utility.getPageList(totalPages);
    	sess.setAttribute("LISTOFPAGES", pgList);
    	model.addAttribute("LISTOFPAGES", pgList);

    	List<CSIFunctionPermModel> currPageData = pagedMap.get(currentPage);
    	model.addAttribute("FUNCTIONPERMDATA", currPageData);
    	model.addAttribute("currentPage", currentPage);
    	model.addAttribute("totalPages", totalPages);
    	model.addAttribute("totalRecordsInPage", currPageData.size());
    	model.addAttribute("totalRecords", sess.getAttribute("totalRecords"));
    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+(sess.getAttribute("totalRecords")));
    	return "csi/functionPermissionPage";
    }

	@SuppressWarnings("all")
	@GetMapping("/loadCSIFunctionPermission/{pgNo}")
    public String loadCSIFuncPermissionPages(@PathVariable int pgNo, Model model, HttpServletRequest request) {
    	log.info("Loading Data for CSI FUNCTION PERMISSION Page Number:"+pgNo);
    	Map<Integer, List<CSIFunctionPermModel>> pagedMap = (Map<Integer, List<CSIFunctionPermModel>>)Utility.getCache("FUNCTIONPERMDATAPGDATA");
    	HttpSession sess = request.getSession();
    	int currentPage = 0;
    	int totalPages = 0;
    	try {
    		totalPages =Integer.parseInt(sess.getAttribute("totalPages").toString());
    		sess.setAttribute("currentPage", pgNo);
    	} catch (Exception e) {
			log.error("Error navigating pages:"+e.getMessage(),e);
		}
    	List<Integer> pgList = Utility.getPageList(totalPages);
    	sess.setAttribute("LISTOFPAGES", pgList);
    	model.addAttribute("LISTOFPAGES", pgList);
    	List<CSIFunctionPermModel> currPageData = pagedMap.get(pgNo);
    	model.addAttribute("FUNCTIONPERMDATA", currPageData);
    	model.addAttribute("currentPage", pgNo);
    	model.addAttribute("totalPages", totalPages);
    	model.addAttribute("totalRecordsInPage", currPageData.size());
    	model.addAttribute("totalRecords", sess.getAttribute("totalRecords"));
    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records retrieved: "+(sess.getAttribute("totalRecords")));
    	return "csi/functionPermissionPage";
    }




	@ResponseBody
    @GetMapping("/dwnldCsiFunctionPermExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnldCsiFunctionPermExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download CSI Function Permission Excel ");
		String fileNm ="CSIFunctionPermissionData";
		List<CSIFunctionPermModel> funcActLst = (List<CSIFunctionPermModel>)Utility.getCache("FUNCTIONPERMDATA");
		String filePath = csiDataService.writeCSISodFunctionPermCsvReport(funcActLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }





}
