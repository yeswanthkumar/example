package com.jnj.rqc.mastermetadata.controller;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MasterData {
	@JsonProperty("BF_ID")
	private int BF_ID;
	@JsonProperty("BF_NAME")
    private String BF_NAME;
	@JsonProperty("SEC_ID")
    private int SEC_ID;
	@JsonProperty("SEC_NAME")
    private String SEC_NAME;
	@JsonProperty("REG_ID")
    private int REG_ID;
	@JsonProperty("REG_NAME")
    private String REG_NAME;
    @JsonProperty("SYS_ID")
    private int SYS_ID;
    @JsonProperty("SYS_NAME")
    private String SYS_NAME;
    @JsonProperty("POS_ID")
    private int POS_ID;
    @JsonProperty("POS_NAME")
    private String POS_NAME;
    @JsonProperty("POS_DESC")
    private String POS_DESC;
    @JsonProperty("ACS_ID")
    private int ACS_ID;
    @JsonProperty("ACS_NAME")
    private String ACS_NAME;
    @JsonProperty("PV_ID")
    private int PV_ID;
    @JsonProperty("PV_NAME")
    private String PV_NAME;
    @JsonProperty("AD_ID")
    private int AD_ID;
    @JsonProperty("AD_NAME")
    private String AD_NAME;
    @JsonProperty("IS_RESTRICTED")
    private String IS_RESTRICTED;

    // Getters and Setters
    public int getBF_ID() {
        return BF_ID;
    }

    public void setBF_ID(int BF_ID) {
        this.BF_ID = BF_ID;
    }

    public String getBF_NAME() {
        return BF_NAME;
    }

    public void setBF_NAME(String BF_NAME) {
        this.BF_NAME = BF_NAME;
    }

    public int getSEC_ID() {
        return SEC_ID;
    }

    public void setSEC_ID(int SEC_ID) {
        this.SEC_ID = SEC_ID;
    }

    public String getSEC_NAME() {
        return SEC_NAME;
    }

    public void setSEC_NAME(String SEC_NAME) {
        this.SEC_NAME = SEC_NAME;
    }

    public int getREG_ID() {
        return REG_ID;
    }

    public void setREG_ID(int REG_ID) {
        this.REG_ID = REG_ID;
    }

    public String getREG_NAME() {
        return REG_NAME;
    }

    public void setREG_NAME(String REG_NAME) {
        this.REG_NAME = REG_NAME;
    }

    public int getSYS_ID() {
        return SYS_ID;
    }

    public void setSYS_ID(int SYS_ID) {
        this.SYS_ID = SYS_ID;
    }

    public String getSYS_NAME() {
        return SYS_NAME;
    }

    public void setSYS_NAME(String SYS_NAME) {
        this.SYS_NAME = SYS_NAME;
    }

    public int getPOS_ID() {
        return POS_ID;
    }

    public void setPOS_ID(int POS_ID) {
        this.POS_ID = POS_ID;
    }

    public String getPOS_NAME() {
        return POS_NAME;
    }

    public void setPOS_NAME(String POS_NAME) {
        this.POS_NAME = POS_NAME;
    }

    public String getPOS_DESC() {
        return POS_DESC;
    }

    public void setPOS_DESC(String POS_DESC) {
        this.POS_DESC = POS_DESC;
    }

    public int getACS_ID() {
        return ACS_ID;
    }

    public void setACS_ID(int ACS_ID) {
        this.ACS_ID = ACS_ID;
    }

    public String getACS_NAME() {
        return ACS_NAME;
    }

    public void setACS_NAME(String ACS_NAME) {
        this.ACS_NAME = ACS_NAME;
    }

    public int getPV_ID() {
        return PV_ID;
    }

    public void setPV_ID(int PV_ID) {
        this.PV_ID = PV_ID;
    }

    public String getPV_NAME() {
        return PV_NAME;
    }

    public void setPV_NAME(String PV_NAME) {
        this.PV_NAME = PV_NAME;
    }

    public int getAD_ID() {
        return AD_ID;
    }

    public void setAD_ID(int AD_ID) {
        this.AD_ID = AD_ID;
    }

    public String getAD_NAME() {
        return AD_NAME;
    }

    public void setAD_NAME(String AD_NAME) {
        this.AD_NAME = AD_NAME;
    }

    public String getIS_RESTRICTED() {
        return IS_RESTRICTED;
    }

    public void setIS_RESTRICTED(String IS_RESTRICTED) {
        this.IS_RESTRICTED = IS_RESTRICTED;
    }

	@Override
	public String toString() {
		return "MyData [BF_ID=" + BF_ID + ", BF_NAME=" + BF_NAME + ", SEC_ID=" + SEC_ID + ", SEC_NAME=" + SEC_NAME
				+ ", REG_ID=" + REG_ID + ", REG_NAME=" + REG_NAME + ", SYS_ID=" + SYS_ID + ", SYS_NAME=" + SYS_NAME
				+ ", POS_ID=" + POS_ID + ", POS_NAME=" + POS_NAME + ", POS_DESC=" + POS_DESC + ", ACS_ID=" + ACS_ID
				+ ", ACS_NAME=" + ACS_NAME + ", PV_ID=" + PV_ID + ", PV_NAME=" + PV_NAME + ", AD_ID=" + AD_ID
				+ ", AD_NAME=" + AD_NAME + ", IS_RESTRICTED=" + IS_RESTRICTED + "]";
	}
}
