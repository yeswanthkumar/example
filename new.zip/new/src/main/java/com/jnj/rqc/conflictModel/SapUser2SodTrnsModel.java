package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapUser2SodTrnsModel {
	private String region;
	private String platform;
	private String environment;
	private String system;
	private String revUserId;
	private String userId;
	private String primaryReviewInfo1;
	private String additionalInfo1;
	private String additionalInfo2;
	private String mitigatingId;
	private String additionalInfo3;
	private String platformName;
	private String riskIdAndRiskDescription;
	private String reviewerDescription;
	private String userStatus;


	public String getData() {
		return revUserId + "~" + userId + "~" + primaryReviewInfo1 + "~" + additionalInfo1 + "~" + additionalInfo2 + "~" + mitigatingId +
				"~" + additionalInfo3 + "~" + platformName + "~" + riskIdAndRiskDescription + "~" + reviewerDescription ;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		SapUser2SodTrnsModel other = (SapUser2SodTrnsModel) obj;
		if (additionalInfo1 == null) {
			if (other.additionalInfo1 != null)
				return false;
		} else if (!additionalInfo1.equals(other.additionalInfo1))
			return false;
		if (additionalInfo2 == null) {
			if (other.additionalInfo2 != null)
				return false;
		} else if (!additionalInfo2.equals(other.additionalInfo2))
			return false;
		if (additionalInfo3 == null) {
			if (other.additionalInfo3 != null)
				return false;
		} else if (!additionalInfo3.equals(other.additionalInfo3))
			return false;
		if (environment == null) {
			if (other.environment != null)
				return false;
		} else if (!environment.equals(other.environment))
			return false;
		if (mitigatingId == null) {
			if (other.mitigatingId != null)
				return false;
		} else if (!mitigatingId.equals(other.mitigatingId))
			return false;
		if (platform == null) {
			if (other.platform != null)
				return false;
		} else if (!platform.equals(other.platform))
			return false;
		if (platformName == null) {
			if (other.platformName != null)
				return false;
		} else if (!platformName.equals(other.platformName))
			return false;
		if (primaryReviewInfo1 == null) {
			if (other.primaryReviewInfo1 != null)
				return false;
		} else if (!primaryReviewInfo1.equals(other.primaryReviewInfo1))
			return false;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (revUserId == null) {
			if (other.revUserId != null)
				return false;
		} else if (!revUserId.equals(other.revUserId))
			return false;
		if (reviewerDescription == null) {
			if (other.reviewerDescription != null)
				return false;
		} else if (!reviewerDescription.equals(other.reviewerDescription))
			return false;
		if (riskIdAndRiskDescription == null) {
			if (other.riskIdAndRiskDescription != null)
				return false;
		} else if (!riskIdAndRiskDescription.equals(other.riskIdAndRiskDescription))
			return false;
		if (system == null) {
			if (other.system != null)
				return false;
		} else if (!system.equals(other.system))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (userStatus == null) {
			if (other.userStatus != null)
				return false;
		} else if (!userStatus.equals(other.userStatus))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((additionalInfo1 == null) ? 0 : additionalInfo1.hashCode());
		result = prime * result + ((additionalInfo2 == null) ? 0 : additionalInfo2.hashCode());
		result = prime * result + ((additionalInfo3 == null) ? 0 : additionalInfo3.hashCode());
		result = prime * result + ((environment == null) ? 0 : environment.hashCode());
		result = prime * result + ((mitigatingId == null) ? 0 : mitigatingId.hashCode());
		result = prime * result + ((platform == null) ? 0 : platform.hashCode());
		result = prime * result + ((platformName == null) ? 0 : platformName.hashCode());
		result = prime * result + ((primaryReviewInfo1 == null) ? 0 : primaryReviewInfo1.hashCode());
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result + ((revUserId == null) ? 0 : revUserId.hashCode());
		result = prime * result + ((reviewerDescription == null) ? 0 : reviewerDescription.hashCode());
		result = prime * result + ((riskIdAndRiskDescription == null) ? 0 : riskIdAndRiskDescription.hashCode());
		result = prime * result + ((system == null) ? 0 : system.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((userStatus == null) ? 0 : userStatus.hashCode());
		return result;
	}






}
