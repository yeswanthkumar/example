package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapMitiCntrlModel {
	private String riskId;
	private String controlId;
	private String controlDesc;




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		SapMitiCntrlModel other = (SapMitiCntrlModel) obj;
		if (riskId == null) {
			if (other.riskId != null)
				return false;
		} else if (!riskId.equals(other.riskId))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((controlDesc == null) ? 0 : controlDesc.hashCode());
		result = prime * result + ((controlId == null) ? 0 : controlId.hashCode());
		result = prime * result + ((riskId == null) ? 0 : riskId.hashCode());
		return result;
	}

}
