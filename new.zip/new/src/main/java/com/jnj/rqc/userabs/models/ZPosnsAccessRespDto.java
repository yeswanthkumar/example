package com.jnj.rqc.userabs.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.masterdata.dto.ZAccessTypeMdl;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ZPosnsAccessRespDto {
	private int 	statusCode;
	private String	message;
	private String 	datetimeStamp;
	private String 	statusDesc;
	private String 	developerMessage;
	private List<ZSysPosAccessMdl> posAccess;
	private List<ZAccessTypeMdl> posAccessDD;
}
