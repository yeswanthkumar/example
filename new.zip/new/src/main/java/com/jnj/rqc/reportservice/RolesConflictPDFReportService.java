package com.jnj.rqc.reportservice;

import java.util.List;

import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;

public interface RolesConflictPDFReportService {

	public String writeUserRolesReport(String fileNm, List<PersonalSysModel> userRoles) ;
	public String writeUserConflictsReport(String title, String fileNm, List<MatrixModel> roleConflictList) ;

}
