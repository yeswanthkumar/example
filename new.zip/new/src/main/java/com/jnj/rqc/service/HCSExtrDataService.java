package com.jnj.rqc.service;

import java.util.List;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.dbextr.models.TableRespDto;


/**
 * File    : <b>JDEExtrDataService.java</b>
 * @author : DChauras @Created : Jun 17, 2021 4:47:52 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

public interface HCSExtrDataService {
	public TableRespDto getEnvData(String propName);
	public List<SapGaaUser2RoleModel> readUser2RoleData(String templSysParam, String calledBy);
	public List<SapGaaUser2RoleModel> readHcsBravoActData(String templSysParam);
	//public List<SapGaaUser2RoleModel> readUser2RoleActData(String templSysParam);



	/*USER TO ROLE

		public List<SapGaaUser2RoleModel> readUser2RoleActData(String templSysParam);//Only Active and Transfers
		public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser);

		*/

	/*
	public List<SAPUserAccessModel> readTransferCntrlData(String templSysParam);
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam);
	public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName);

	public String writeJdeUserAccessCSV(List<SAPUserAccessModel> data, String fileName);
	public String writeLogData(StringBuilder data, String fileName) ;

	//Region Wise
	public Map<String, LinkedList<SAPUserAccessModel>> readSAPTrfContolRegionData(List<String> templSysParam);
	public Map<String, List<SAPUserAccessModel>> startTrfContolRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String> templSysParam);

	public int insertTransferTransactions(List<SAPUserAccessModel> trfUserData, String sysTemp, String createdUser) ;
	//Region Wise
	public String writeRegTrfCntrlCSV(Map<String, LinkedList<SAPUserAccessModel>> data, String fileName);

	//Export Data
	public int exportTrfCntrlDataGenesis(Map<String, LinkedList<SAPUserAccessModel>> regDataMap, HttpServletRequest request);
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) ;
	public Map<String, List<SAPUserAccessModel>> startExportTrfContolRegionSch(TrfCntrlSchModel activeSchedule);
	public int exportTrfCntrlDataToGenesis(List<SAPUserAccessModel> dataList, String sysDetail);
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);
	//GENESIS Transfer Control Report
	public Map <String, Map<String, List<SapDataTransferReportMdl>>> getGenesisTransferReportData();
	*/
}
