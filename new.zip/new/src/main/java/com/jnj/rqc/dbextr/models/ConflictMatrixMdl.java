package com.jnj.rqc.dbextr.models;

import lombok.Data;


@Data
public class ConflictMatrixMdl {
	private String role1;
	private String role2;
	private String app1;
	private String app2;
	private String conflict;
	private String mitigatingControl;

	public String getData() {
		return   app1 + "~" + app2 + "~" +role1 + "~" + role2 + "~" + conflict + "~" + mitigatingControl ;
	}


	@Override
	public String toString() {
		return "ConflictModel [ role1=" + role1 + ", role2=" + role2 + ", app1=" + app1 + ", app2=" + app2 + ", conflict=" + conflict + ", mitigatingControl=" + mitigatingControl + "]";
	}
}
