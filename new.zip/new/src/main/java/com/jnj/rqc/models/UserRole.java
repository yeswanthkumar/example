package com.jnj.rqc.models;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserRole {
	private String userName;
	private List<String> Roles;
}
