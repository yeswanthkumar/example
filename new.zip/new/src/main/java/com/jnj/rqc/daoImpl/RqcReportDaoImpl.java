package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.RqcReportDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.reportmodels.AppRoles;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.reportmodels.ReqLogModel;




@Service
public class RqcReportDaoImpl  extends BaseDao implements RqcReportDao {
	static final Logger log = LoggerFactory.getLogger(RqcReportDaoImpl.class);





	@Override
	public List<ReportDataModel> getRqcReportData(String startDt, String endDt)	throws SQLException, DataAccessException {
		List<ReportDataModel> reportData = new ArrayList<>();
		log.info("Query Data for Start date:"+startDt + "and  End Date: "+endDt);

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.TICKT_NO, c.FMLY_NM||','||c.GIVEN_NM AS REQ_NM, a.REQSTOR_ID AS REQ_WWID, b.FMLY_NM||','||b.GIVEN_NM AS ASSOC_NM, a.CLI_ID AS ASSOC_WWID, b.JNJ_MSFT_USRNM_TXT AS ASSOC_NT_ID, ");
		sql.append(" b.JNJ_SUPVR_WW_ID AS MGR_WWID, d.FMLY_NM||','||d.GIVEN_NM AS MGR_NM, a.REQST_DT AS DT_CREATED, e.BUSN_JUSTN AS BUSN_JSTN, a.APPLN_CMNTS AS ADD_CMNTS ");
		sql.append(" FROM TIPTOP.TICKT_REQSTOR a, SOD_EXTR.JJEDS_EMP_EXTR_MV b, SOD_EXTR.JJEDS_EMP_EXTR_MV c, SOD_EXTR.JJEDS_EMP_EXTR_MV d, TIPTOP.CLI_INFO e ");
		sql.append(" Where a.CLI_ID = b.WW_ID AND a.REQSTOR_ID = c.ww_id AND b.JNJ_SUPVR_WW_ID = d.WW_ID AND a.TICKT_NO = e.TICKT_NO ");
		sql.append(" AND a.REQST_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') order by a.TICKT_NO ");

		reportData = getJdbcTemplate().query(sql.toString(), new Object[] {startDt, endDt}, new BeanPropertyRowMapper<>(ReportDataModel.class));
		log.info("Total rows returned : "+((reportData !=null) ? reportData.size():"0"));
		return reportData;
	}





	@Override
	public List<AppRoles> getTktRoles(String[] ticketNo) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}


	@Override
	public List<AppRoles> getTktAppRoles(String[] ticketNo, List<Integer> appIds ) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		if(appIds != null && !appIds.isEmpty()) {
			sql.append(" AND a.APPLN_GRP_ID in ( ");
			for(int j=0;j<appIds.size();j++) {
				if(j==0) {
					sql.append(" "+appIds.get(j));
				}else {
					sql.append(", "+appIds.get(j));
				}
			}
			sql.append(" ) ");
		}

		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}



	@Override
	public List<ReqLogModel> getTktReqLogs(String[] ticketNo) throws SQLException, DataAccessException {
		List<ReqLogModel> appData = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" select a.TICKT_NO, a.CLI_ID AS USER_ID, b.JNJ_MSFT_USRNM_TXT as NT_ID, b.GIVEN_NM|| ' '||FMLY_NM AS USER_NM, ");
		sql.append(" a.ROW_ADD_TMS as COM_DATE, to_char(a.ROW_ADD_TMS, 'hh24:mi:ss') as COM_TIME, CMNTS ");
		sql.append(" from tiptop.TICKT_REQSTOR_LOG a, SOD_EXTR.JJEDS_EMP_EXTR_MV b ");
		sql.append(" where a.CLI_ID = b.ww_id ");
		sql.append(" AND a.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" order by a.TICKT_NO, a.LOG_SEQ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<>(ReqLogModel.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}





	/*@Override
	public List<MatrixModel> getCurrentRolesConflict(String[] roles, String wwid ) throws SQLException, DataAccessException {
		List<MatrixModel> confInExistingRoles = new ArrayList<MatrixModel>();

		for(String roleId : roles) {
			List<MatrixModel> tmp = getLRConflicts(roleId,  wwid);
			if(tmp != null && !tmp.isEmpty()) {
				confInExistingRoles.addAll(tmp);
			}
		}

		log.info("Total Conflicts in NEW-EXISTING :"+confInExistingRoles.size());

		return confInExistingRoles;
	}


	@Override
	public List<MatrixModel> getNewRolesConflict(String sql) throws SQLException, DataAccessException {
		List<MatrixModel> roleMatrixList = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<MatrixModel>(MatrixModel.class));
		log.info("roleMatrix size : "+((roleMatrixList !=null)? roleMatrixList.size(): 0)+" ");
		return roleMatrixList;
	}








	@Override
	public List<PersonalSysModel> getUsersExistingRoles(String wwid)throws SQLException, DataAccessException {
		log.info("User ID Received:"+ wwid);
		String sql = " SELECT a.WWID, a.USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " +
				" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b" +
				" WHERE a.CODE = b.SOD_CODE AND a.WWID = ? ORDER BY a.CODE ";

		final List<PersonalSysModel> userRoles = getJdbcTemplate().query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<PersonalSysModel>(PersonalSysModel.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


	@Override
	public List<SystemCodeModel> getSystemCodes() throws SQLException, DataAccessException {
		log.info("QUERY SYSTEM_CODE");
		String sql = " SELECT SRC_SYSTEM, ACCESS_ROLE, SOD_CODE FROM SOD_EXTR.SYSTEM_CODE ORDER BY SRC_SYSTEM ";

		final List<SystemCodeModel> sysCdLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<SystemCodeModel>(SystemCodeModel.class));
		log.info("Total Rows : "+((sysCdLst !=null)? sysCdLst.size(): 0)+"  .......END");
		return sysCdLst;
	}


	@Override
	public List<PersonalSysModel> getUsersExistingRoles(List<String> empIds) throws SQLException, DataAccessException {
		log.info("User ID Received:"+ empIds);
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.WWID, UPPER(a.USER_ID) AS USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " );
		sql.append(" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b " );
		sql.append(" WHERE a.CODE = b.SOD_CODE AND a.WWID in ( ");
		String vars="";

		for(int i=0; i<empIds.size(); i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" ORDER BY a.WWID,  a.CODE ");

		final List<PersonalSysModel> userRoles = getJdbcTemplate().query(sql.toString(), empIds.toArray(), new BeanPropertyRowMapper<PersonalSysModel>(PersonalSysModel.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


*/




}
