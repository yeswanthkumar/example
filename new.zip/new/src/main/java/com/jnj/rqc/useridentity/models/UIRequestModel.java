package com.jnj.rqc.useridentity.models;

import java.util.Date;

import lombok.Data;

@Data
public class UIRequestModel {
	private int 	reqId;
	private int 	reqTyp;
	private Date   	reqDt;
	private String 	reqBy;
	private String 	userId;
	private String 	mgrWwid;
	private int 	bfId;
	private String 	secIds;
	private String 	regIds;
	private int 	reqStatus;
	private String  conflFound;
	private String  conflResolved;
	private String  routedToCompl;
	private Date   	conflUpdated;
	private Date   	dtUpdated;
	private String  updtBy;
	private String  comments;
	private String  isExces;

	@Override
	public String toString() {
		return "UIRequestModel [reqId=" + reqId + ", reqTyp=" + reqTyp + ", reqDt=" + reqDt + ", reqBy=" + reqBy
				+ ", userId=" + userId + ", mgrWwid=" + mgrWwid + ", bfId=" + bfId + ", secIds=" + secIds + ", regIds="
				+ regIds + ", reqStatus=" + reqStatus + ", conflFound=" + conflFound + ", conflResolved="
				+ conflResolved + ", routedToCompl=" + routedToCompl + ", conflUpdated=" + conflUpdated + ", dtUpdated="
				+ dtUpdated + ", updtBy=" + updtBy + ", comments=" + comments +  ", isExces=" + isExces + "]";
	}




















}
