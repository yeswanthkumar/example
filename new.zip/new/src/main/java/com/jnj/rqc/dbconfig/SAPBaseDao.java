package com.jnj.rqc.dbconfig;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;

import com.sap.conn.jco.JCoDestination;



public abstract class SAPBaseDao implements ApplicationContextAware {
	private JCoDestination destNA_SAPSANDBOX_Sandbox_R3P700;
	//ATLAS
	private JCoDestination destNA_ATLAS_Production_ECCProductionRPVCLNT100;
	private JCoDestination destNA_ATLAS_Production_APOProductionAPVCLNT100;
	private JCoDestination destNA_ATLAS_Production_BIProductionBPVCLNT100;
	//Tech Clients
	private JCoDestination destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000;
	private JCoDestination destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000;
	private JCoDestination destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000;


	//BIOSENSE
	private JCoDestination destNA_BIOSENSE_Production_BWIILCLNT400;

	//USROTC
	private JCoDestination destNA_USROTC_Production_ECCProductionMP2CLNT100;
	private JCoDestination destNA_USROTC_Production_CRMProductionMP8CLNT100;

	//CONCOURSE
	private JCoDestination destNA_Concourse_Production_ATTProductionP23CLNT100;
	private JCoDestination destNA_Concourse_Production_ATTProductionP24CLNT100;
	private JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000;
	private JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000;

	private JCoDestination destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000;
	private JCoDestination destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000;

	//CROSSROAD
	private JCoDestination destNA_CROSSROAD_Production_ECCProductionRPUCLNT100;
	private JCoDestination destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000;
	//BTBGLOBAL
	private JCoDestination destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300;
	private JCoDestination destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550;
	private JCoDestination destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400;
	private JCoDestination destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650;
	private JCoDestination destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220;
	private JCoDestination destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750;
	private JCoDestination destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600;
	private JCoDestination destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200;

	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000;
	private JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000;
	//BTB LERCAN
	private JCoDestination destNA_BTBLERCAN_Production_CRMProductionP51CLNT500;
	private JCoDestination destNA_BTBLERCAN_Production_ECCProductionP50CLNT100;
	private JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000;
	private JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000;

	// FUSION
	private JCoDestination destNA_FUSION_Production_ECCProductionPR1CLNT100;
	private JCoDestination destNA_FUSION_Production_CRMProductionPC1CLNT100;
	private JCoDestination destNA_FUSION_Production_BWProductionPB1CLNT100;
	private JCoDestination destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000;
	private JCoDestination destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000;
	private JCoDestination destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000;

	//ANSPACH
	private JCoDestination destNA_ANSPACH_Production_ECCProductionR3PCLNT700;
	private JCoDestination destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000;

	//SOLMAN
	private JCoDestination destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230;
	private JCoDestination destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000;

	// JJSV
	private JCoDestination destNA_JJSV_Production_ECCProductionPA2CLNT050;
	private JCoDestination destNA_JJSV_Production_SCMProductionAPPCLNT050;
	private JCoDestination destNA_JJSV_Production_BWProductionBWPCLNT050;

	private JCoDestination destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000;
	private JCoDestination destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000;
	private JCoDestination destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000;

	//LYNX - START
	private JCoDestination destNA_LYNX_Production_ECCProductionMP1CLNT010;
	private JCoDestination destNA_LYNX_Production_BIProductionGP5CLNT010;
	private JCoDestination destNA_LYNX_Production_ECCProductionFP3CLNT010;
	private JCoDestination destNA_LYNX_Production_BIProductionFP5CLNT010;

	private JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000;
	private JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000;
	private JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000;
	private JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000;
	//LYNX - END

	//MERCURY - Production -STARTS
	private JCoDestination destNA_MERCURY_Production_SCMProductionSPNCLNT400;
	private JCoDestination destNA_MERCURY_Production_ECCProductionRPNCLNT120;
	private JCoDestination destNA_MERCURY_Production_BWProductionBPNCLNT300;
	private JCoDestination destNA_MERCURY_Production_PIProductionXPNCLNT200;

	private JCoDestination destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000;
	private JCoDestination destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000;
	private JCoDestination destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000;
	private JCoDestination destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000;

	//MERCURY - Production -END

	// MITEK - Production
	private JCoDestination destNA_MITEK_Production_ECCProductionRPOCLNT777;
	private JCoDestination destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000;

	//OURSOURCE
	private JCoDestination destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280;
	private JCoDestination destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280;
	private JCoDestination destNA_OURSOURCE_Production_BIProductionPJ5CLNT280;

	private JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000;
	private JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000;
	private JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000;
	//LATAM_LATAMPROJECTONE
	private JCoDestination destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520;
	private JCoDestination destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620;
	private JCoDestination destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120;

	private JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000;
	private JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000;
	private JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000;
	//BTBLATAM - START
	private JCoDestination destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500;
	private JCoDestination destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100;
	private JCoDestination destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300;
	private JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000;
	private JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000;
	private JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000;
	//BTBLATAM - END

	//SYNTHES
	private JCoDestination destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600;

	//BTBJAPAN
	private JCoDestination destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100;
	private JCoDestination destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000;
	//ConsumerASPAC
	private JCoDestination destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888;
	private JCoDestination destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100;
	private JCoDestination destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888;

	private JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000;
	private JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000;
	private JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000;

	//MARS
	private JCoDestination destASPAC_MARS_Production_ECCProductionEJ1CLNT100;
	private JCoDestination destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000;

	//Panda
	private JCoDestination destASPAC_Panda_Production_BIProductionBP1CLNT600;
	private JCoDestination destASPAC_Panda_Production_ECCProductionEP1CLNT800;
	private JCoDestination destASPAC_Panda_Production_PIProductionXP1CLNT800;

	private JCoDestination destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000;
	private JCoDestination destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000;
	private JCoDestination destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000;

	//TAISHAN
	private JCoDestination destASPAC_Taishan_Production_ECCProductionRPDCLNT800;
	private JCoDestination destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000;

	// EMEA - START
	//EUROPE2
	private JCoDestination destEMEA_EUROPE2_Production_APOProductionAPECLNT050;
	private JCoDestination destEMEA_EUROPE2_Production_BIProductionBPECLNT050;
	private JCoDestination destEMEA_EUROPE2_Production_FSFProductionBPICLNT050;
	private JCoDestination destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050;
	private JCoDestination destEMEA_EUROPE2_Production_ECCProductionRPECLNT050;

	private JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000;
	private JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000;
	private JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000;
	private JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000;
	private JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000;

	private JCoDestination destEMEA_EUROPE2_Production_EWMProductionPJECLNT050;

	//Galaxy
	private JCoDestination destEMEA_Galaxy_Production_BIProductionBPMCLNT172;
	private JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT232;
	private JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT050;

	private JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000;
	private JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000;

	//GMED
	private JCoDestination destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050;
	private JCoDestination destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000;
	//IML
	private JCoDestination destEMEA_ILM_Production_BIProductionB3TCLNT050;
	private JCoDestination destEMEA_ILM_Production_BIProductionB4TCLNT050;
	private JCoDestination destEMEA_ILM_Production_BIProductionBPTCLNT050;
	private JCoDestination destEMEA_ILM_Production_ECCProductionR3TCLNT050;
	private JCoDestination destEMEA_ILM_Production_ECCProductionR4TCLNT050;
	private JCoDestination destEMEA_ILM_Production_ECCProductionRPTCLNT050;

	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000;
	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000;
	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000;
	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000;
	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000;
	private JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000;


	//SNC
	private JCoDestination destEMEA_SNC_Production_SNCProductionQPECLNT050;
	private JCoDestination destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000;
	//STF - START
	private JCoDestination destEMEA_STF_Production_APOProductionAPCCLNT430;
	private JCoDestination destEMEA_STF_Production_BIProductionBPCCLNT330;
	private JCoDestination destEMEA_STF_Production_CRMProductionCPCCLNT100;
	private JCoDestination destEMEA_STF_Production_MDGProductionOPCCLNT050;
	private JCoDestination destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050;
	private JCoDestination destEMEA_STF_Production_ECCProductionRPCCLNT130;
	private JCoDestination destEMEA_STF_Production_PIProductionXPGCLNT050;

	private JCoDestination destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000;
	private JCoDestination destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000;

	//STF - END

	//SUSTAIN
	private JCoDestination destEMEA_Sustain_Sandbox_RSB910;
	private JCoDestination destEMEA_Sustain_Production_BIProductionBPBCLNT050;
	private JCoDestination destEMEA_Sustain_Production_ECCProductionRPBCLNT910;
	private JCoDestination destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000;
	private JCoDestination destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000;
	//SYMPHONY
	private JCoDestination destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200;
	private JCoDestination destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000;
	//SYNTHES
	private JCoDestination destEMEA_SYNTHES_Production_GRCProductionACPCLNT001;
	private JCoDestination destEMEA_SYNTHES_Production_BIProductionBIPCLNT020;
	private JCoDestination destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001;
	private JCoDestination destEMEA_SYNTHES_Production_ECCProductionP01CLNT020;
	private JCoDestination destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001;
	private JCoDestination destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600;

	private JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000;
	private JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000;
	private JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000;
	private JCoDestination destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000;
	private JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000;
	private JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000;


	//VDR
	private JCoDestination destEMEA_VDR_Production_ECCProductionFRPCLNT382;
	private JCoDestination destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000;
	// EMEA - END

	//PFBPFI(BW4PFB, S4PFI)
	private JCoDestination destBW4PFB;
	private JCoDestination destS4PFI;
	private JCoDestination destGRCSYS;

	//CFIN PFI/PFQ CLNT
	private JCoDestination destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000;
	private JCoDestination destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000;


	ApplicationContext appContextSAP;


	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.appContextSAP= arg0;
	}

	@Bean
	public ApplicationContext getApplicationContextSAP() {
		return appContextSAP;
	}

	//SANDBOX
	@Autowired
	public void setDestNA_SAPSANDBOX_Sandbox_R3P700(final JCoDestination destNA_SAPSANDBOX_Sandbox_R3P700) {
		this.destNA_SAPSANDBOX_Sandbox_R3P700 = destNA_SAPSANDBOX_Sandbox_R3P700;
	}

	public JCoDestination getDestNA_SAPSANDBOX_Sandbox_R3P700() {
		return destNA_SAPSANDBOX_Sandbox_R3P700;
	}

	//ATLAS - START

	@Autowired
	public void setDestNA_ATLAS_Production_ECCProductionRPVCLNT100(final JCoDestination destNA_ATLAS_Production_ECCProductionRPVCLNT100) {
		this.destNA_ATLAS_Production_ECCProductionRPVCLNT100 = destNA_ATLAS_Production_ECCProductionRPVCLNT100;
	}

	public JCoDestination getDestNA_ATLAS_Production_ECCProductionRPVCLNT100() {
		return destNA_ATLAS_Production_ECCProductionRPVCLNT100;
	}

	@Autowired
	public void setDestNA_ATLAS_Production_APOProductionAPVCLNT100(final JCoDestination destNA_ATLAS_Production_APOProductionAPVCLNT100) {
		this.destNA_ATLAS_Production_APOProductionAPVCLNT100 = destNA_ATLAS_Production_APOProductionAPVCLNT100;
	}

	public JCoDestination getDestNA_ATLAS_Production_APOProductionAPVCLNT100() {
		return destNA_ATLAS_Production_APOProductionAPVCLNT100;
	}


	@Autowired
	public void setDestNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000(final JCoDestination destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000) {
		this.destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000 = destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000;
	}

	public JCoDestination getDestNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000() {
		return destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000;
	}

	@Autowired
	public void setDestNA_ATLAS_Production_BIProductionBPVCLNT100(final JCoDestination destNA_ATLAS_Production_BIProductionBPVCLNT100) {
		this.destNA_ATLAS_Production_BIProductionBPVCLNT100 = destNA_ATLAS_Production_BIProductionBPVCLNT100;
	}

	public JCoDestination getDestNA_ATLAS_Production_BIProductionBPVCLNT100() {
		return destNA_ATLAS_Production_BIProductionBPVCLNT100;
	}

	//NA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000
	@Autowired
	public void setDestNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000(final JCoDestination destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000) {
		this.destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000 = destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000;
	}

	public JCoDestination getDestNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000() {
		return destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000;
	}

	//NA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000
	@Autowired
	public void setDestNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000(final JCoDestination destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000) {
		this.destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000 = destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000;
	}

	public JCoDestination getDestNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000() {
		return destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000;
	}

	//ATLAS - END

	//BIOSENSE

	@Autowired
	public void setDestNA_BIOSENSE_Production_BWIILCLNT400(final JCoDestination destNA_BIOSENSE_Production_BWIILCLNT400) {
		this.destNA_BIOSENSE_Production_BWIILCLNT400 = destNA_BIOSENSE_Production_BWIILCLNT400;
	}

	public JCoDestination getDestNA_BIOSENSE_Production_BWIILCLNT400() {
		return destNA_BIOSENSE_Production_BWIILCLNT400;
	}
	//BIOSENSE

	//USROTC - START
	@Autowired
	public void setDestNA_USROTC_Production_ECCProductionMP2CLNT100(final JCoDestination destNA_USROTC_Production_ECCProductionMP2CLNT100) {
		this.destNA_USROTC_Production_ECCProductionMP2CLNT100 = destNA_USROTC_Production_ECCProductionMP2CLNT100;
	}

	public JCoDestination getDestNA_USROTC_Production_ECCProductionMP2CLNT100() {
		return destNA_USROTC_Production_ECCProductionMP2CLNT100;
	}

	@Autowired
	public void setDestNA_USROTC_Production_CRMProductionMP8CLNT100(final JCoDestination destNA_USROTC_Production_CRMProductionMP8CLNT100) {
		this.destNA_USROTC_Production_CRMProductionMP8CLNT100 = destNA_USROTC_Production_CRMProductionMP8CLNT100;
	}

	public JCoDestination getDestNA_USROTC_Production_CRMProductionMP8CLNT100() {
		return destNA_USROTC_Production_CRMProductionMP8CLNT100;
	}

	//NA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000
	@Autowired
	public void setDestNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000(final JCoDestination destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000) {
		this.destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000 = destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000;
	}

	public JCoDestination getDestNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000() {
		return destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000;
	}

	//NA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000
	@Autowired
	public void setDestNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000(final JCoDestination destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000) {
		this.destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000 = destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000;
	}

	public JCoDestination getDestNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000() {
		return destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000;
	}

	//USROTC - END

	//CROSSROAD - START
	// 1. RPU
	@Autowired
	public void setDestNA_CROSSROAD_Production_ECCProductionRPUCLNT100(final JCoDestination destNA_CROSSROAD_Production_ECCProductionRPUCLNT100) {
		this.destNA_CROSSROAD_Production_ECCProductionRPUCLNT100 = destNA_CROSSROAD_Production_ECCProductionRPUCLNT100;
	}

	public JCoDestination getDestNA_CROSSROAD_Production_ECCProductionRPUCLNT100() {
		return destNA_CROSSROAD_Production_ECCProductionRPUCLNT100;
	}

	//NA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000
	@Autowired
	public void setDestNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000(final JCoDestination destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000) {
		this.destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000 = destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000;
	}

	public JCoDestination getDestNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000() {
		return destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000;
	}

	//CROSSROAD - END

	// CONCOURSE - START
	@Autowired
	public void setDestNA_Concourse_Production_ATTProductionP23CLNT100(final JCoDestination destNA_Concourse_Production_ATTProductionP23CLNT100) {
		this.destNA_Concourse_Production_ATTProductionP23CLNT100 = destNA_Concourse_Production_ATTProductionP23CLNT100;
	}

	public JCoDestination getDestNA_Concourse_Production_ATTProductionP23CLNT100() {
		return destNA_Concourse_Production_ATTProductionP23CLNT100;
	}

	@Autowired
	public void setDestNA_Concourse_Production_ATTProductionP24CLNT100(final JCoDestination destNA_Concourse_Production_ATTProductionP24CLNT100) {
		this.destNA_Concourse_Production_ATTProductionP24CLNT100 = destNA_Concourse_Production_ATTProductionP24CLNT100;
	}

	public JCoDestination getDestNA_Concourse_Production_ATTProductionP24CLNT100() {
		return destNA_Concourse_Production_ATTProductionP24CLNT100;
	}

	//NA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000
	@Autowired
	public void setDestNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000(final JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000) {
		this.destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000 = destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000;
	}

	public JCoDestination getDestNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000() {
		return destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000;
	}

	//NA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000
	@Autowired
	public void setDestNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000(final JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000) {
		this.destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000 = destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000;
	}

	public JCoDestination getDestNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000() {
		return destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000;
	}

	// CONCOURSE - END

	//BTB GLOBAL - START

	@Autowired
	public void setDestNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300(final JCoDestination destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300) {
		this.destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300 = destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300() {
		return destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000
	@Autowired
	public void setDestNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000;
	}

	@Autowired
	public void setNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550(final JCoDestination destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550) {
		this.destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550 = destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550() {
		return destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000;
	}


	@Autowired
	public void setNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400(final JCoDestination destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400) {
		this.destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400 = destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400() {
		return destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000;
	}

	@Autowired
	public void setNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650(final JCoDestination destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650) {
		this.destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650 = destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650() {
		return destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000;
	}


	@Autowired
	public void setNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220(final JCoDestination destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220) {
		this.destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220 = destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220() {
		return destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000;
	}

	@Autowired
	public void setNA_BTBGLOBAL_Production_MDGProductionP53CLNT750(final JCoDestination destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750) {
		this.destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750 = destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_MDGProductionP53CLNT750() {
		return destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000;
	}

	@Autowired
	public void setNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600(final JCoDestination destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600) {
		this.destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600 = destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600() {
		return destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000;
	}


	@Autowired
	public void setNA_BTBGLOBAL_Production_PIProductionXPUCLNT200(final JCoDestination destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200) {
		this.destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200 = destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200;
	}

	public JCoDestination getDestNA_BTBGLOBAL_Production_PIProductionXPUCLNT200() {
		return destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000
	@Autowired
	public void setNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000(final JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000) {
		this.destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000 = destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000;
	}

	public JCoDestination getDestNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000() {
		return destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000;
	}

	//BTBGLOBAL - END

	//BTB LERCAN - START
	@Autowired
	public void setDestNA_BTBLERCAN_Production_CRMProductionP51CLNT500(final JCoDestination destNA_BTBLERCAN_Production_CRMProductionP51CLNT500) {
		this.destNA_BTBLERCAN_Production_CRMProductionP51CLNT500 = destNA_BTBLERCAN_Production_CRMProductionP51CLNT500;
	}

	public JCoDestination getDestNA_BTBLERCAN_Production_CRMProductionP51CLNT500() {
		return destNA_BTBLERCAN_Production_CRMProductionP51CLNT500;
	}

	@Autowired
	public void setDestNA_BTBLERCAN_Production_ECCProductionP50CLNT100(final JCoDestination destNA_BTBLERCAN_Production_ECCProductionP50CLNT100) {
		this.destNA_BTBLERCAN_Production_ECCProductionP50CLNT100 = destNA_BTBLERCAN_Production_ECCProductionP50CLNT100;
	}

	public JCoDestination getDestNA_BTBLERCAN_Production_ECCProductionP50CLNT100() {
		return destNA_BTBLERCAN_Production_ECCProductionP50CLNT100;
	}

	//NA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000
	@Autowired
	public void setDestNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000(final JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000) {
		this.destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000 = destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000;
	}

	public JCoDestination getDestNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000() {
		return destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000;
	}

	//NA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000;
	@Autowired
	public void setDestNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000(final JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000) {
		this.destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000 = destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000;
	}

	public JCoDestination getDestNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000() {
		return destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000;
	}


	//BTB LERCAN - END

	// FUSION - START

	@Autowired
	public void setDestNA_FUSION_Production_ECCProductionPR1CLNT100(final JCoDestination destNA_FUSION_Production_ECCProductionPR1CLNT100) {
		this.destNA_FUSION_Production_ECCProductionPR1CLNT100 = destNA_FUSION_Production_ECCProductionPR1CLNT100;
	}

	public JCoDestination getDestNA_FUSION_Production_ECCProductionPR1CLNT100() {
		return destNA_FUSION_Production_ECCProductionPR1CLNT100;
	}

	@Autowired
	public void setDestNA_FUSION_Production_CRMProductionPC1CLNT100(final JCoDestination destNA_FUSION_Production_CRMProductionPC1CLNT100) {
		this.destNA_FUSION_Production_CRMProductionPC1CLNT100 = destNA_FUSION_Production_CRMProductionPC1CLNT100;
	}

	public JCoDestination getDestNA_FUSION_Production_CRMProductionPC1CLNT100() {
		return destNA_FUSION_Production_CRMProductionPC1CLNT100;
	}

	@Autowired
	public void setDestNA_FUSION_Production_BWProductionPB1CLNT100(final JCoDestination destNA_FUSION_Production_BWProductionPB1CLNT100) {
		this.destNA_FUSION_Production_BWProductionPB1CLNT100 = destNA_FUSION_Production_BWProductionPB1CLNT100;
	}

	public JCoDestination getDestNA_FUSION_Production_BWProductionPB1CLNT100() {
		return destNA_FUSION_Production_BWProductionPB1CLNT100;
	}

	//NA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000
	@Autowired
	public void setDestNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000(final JCoDestination destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000) {
		this.destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000 = destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000;
	}

	public JCoDestination getDestNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000() {
		return destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000;
	}

	//NA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000
	@Autowired
	public void setDestNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000(final JCoDestination destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000) {
		this.destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000 = destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000;
	}

	public JCoDestination getDestNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000() {
		return destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000;
	}

	//NA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000
	@Autowired
	public void setDestNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000(final JCoDestination destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000) {
		this.destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000 = destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000;
	}

	public JCoDestination getDestNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000() {
		return destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000;
	}

	// FUSION - END

	//ANSPACH - START

	@Autowired
	public void setDestNA_ANSPACH_Production_ECCProductionR3PCLNT700(final JCoDestination destNA_ANSPACH_Production_ECCProductionR3PCLNT700) {
		this.destNA_ANSPACH_Production_ECCProductionR3PCLNT700 = destNA_ANSPACH_Production_ECCProductionR3PCLNT700;
	}

	public JCoDestination getDestNA_ANSPACH_Production_ECCProductionR3PCLNT700() {
		return destNA_ANSPACH_Production_ECCProductionR3PCLNT700;
	}

	//NA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000
	@Autowired
	public void setDestNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000(final JCoDestination destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000) {
		this.destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000 = destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000;
	}

	public JCoDestination getDestNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000() {
		return destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000;
	}
	//END ANSPACH

	//GLOBAL SOLMAN - START

	@Autowired
	public void setDestNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230(final JCoDestination destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230) {
		this.destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230 = destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230;
	}

	public JCoDestination getDestNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230() {
		return destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230;
	}

	@Autowired
	public void setDestNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000(final JCoDestination destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000) {
		this.destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000 = destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000;
	}

	public JCoDestination getDestNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000() {
		return destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000;
	}

	// GLABAL SOLMAN - END

	// JJSV - START
	@Autowired
	public void setDestNA_JJSV_Production_ECCProductionPA2CLNT050(final JCoDestination destNA_JJSV_Production_ECCProductionPA2CLNT050) {
		this.destNA_JJSV_Production_ECCProductionPA2CLNT050 = destNA_JJSV_Production_ECCProductionPA2CLNT050;
	}

	public JCoDestination getDestNA_JJSV_Production_ECCProductionPA2CLNT050() {
		return destNA_JJSV_Production_ECCProductionPA2CLNT050;
	}

	@Autowired
	public void setDestNA_JJSV_Production_SCMProductionAPPCLNT050(final JCoDestination destNA_JJSV_Production_SCMProductionAPPCLNT050) {
		this.destNA_JJSV_Production_SCMProductionAPPCLNT050 = destNA_JJSV_Production_SCMProductionAPPCLNT050;
	}

	public JCoDestination getDestNA_JJSV_Production_SCMProductionAPPCLNT050() {
		return destNA_JJSV_Production_SCMProductionAPPCLNT050;
	}

	@Autowired
	public void setDestNA_JJSV_Production_BWProductionBWPCLNT050(final JCoDestination destNA_JJSV_Production_BWProductionBWPCLNT050) {
		this.destNA_JJSV_Production_BWProductionBWPCLNT050 = destNA_JJSV_Production_BWProductionBWPCLNT050;
	}

	public JCoDestination getDestNA_JJSV_Production_BWProductionBWPCLNT050() {
		return destNA_JJSV_Production_BWProductionBWPCLNT050;
	}

	//NA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000
	@Autowired
	public void setDestNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000(final JCoDestination destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000) {
		this.destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000 = destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000;
	}

	public JCoDestination getDestNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000() {
		return destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000;
	}

	//NA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000
	@Autowired
	public void setDestNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000(final JCoDestination destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000) {
		this.destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000 = destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000;
	}

	public JCoDestination getDestNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000() {
		return destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000;
	}

	//NA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000
	@Autowired
	public void setDestNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000(final JCoDestination destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000) {
		this.destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000 = destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000;
	}

	public JCoDestination getDestNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000() {
		return destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000;
	}

	//JJSV - END

	//LYNX - START

	@Autowired
	public void setDestNA_LYNX_Production_ECCProductionMP1CLNT010(final JCoDestination destNA_LYNX_Production_ECCProductionMP1CLNT010) {
		this.destNA_LYNX_Production_ECCProductionMP1CLNT010 = destNA_LYNX_Production_ECCProductionMP1CLNT010;
	}

	public JCoDestination getDestNA_LYNX_Production_ECCProductionMP1CLNT010() {
		return destNA_LYNX_Production_ECCProductionMP1CLNT010;
	}

	@Autowired
	public void setDestNA_LYNX_Production_BIProductionGP5CLNT010(final JCoDestination destNA_LYNX_Production_BIProductionGP5CLNT010) {
		this.destNA_LYNX_Production_BIProductionGP5CLNT010 = destNA_LYNX_Production_BIProductionGP5CLNT010;
	}

	public JCoDestination getDestNA_LYNX_Production_BIProductionGP5CLNT010() {
		return destNA_LYNX_Production_BIProductionGP5CLNT010;
	}

	@Autowired
	public void setDestNA_LYNX_Production_ECCProductionFP3CLNT010(final JCoDestination destNA_LYNX_Production_ECCProductionFP3CLNT010) {
		this.destNA_LYNX_Production_ECCProductionFP3CLNT010 = destNA_LYNX_Production_ECCProductionFP3CLNT010;
	}

	public JCoDestination getDestNA_LYNX_Production_ECCProductionFP3CLNT010() {
		return destNA_LYNX_Production_ECCProductionFP3CLNT010;
	}

	@Autowired
	public void setDestNA_LYNX_Production_BIProductionFP5CLNT010(final JCoDestination destNA_LYNX_Production_BIProductionFP5CLNT010) {
		this.destNA_LYNX_Production_BIProductionFP5CLNT010 = destNA_LYNX_Production_BIProductionFP5CLNT010;
	}

	public JCoDestination getDestNA_LYNX_Production_BIProductionFP5CLNT010() {
		return destNA_LYNX_Production_BIProductionFP5CLNT010;
	}

	//NA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000
	@Autowired
	public void setDestNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000(final JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000) {
		this.destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000 = destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000;
	}

	public JCoDestination getDestNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000() {
		return destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000;
	}

	//NA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000
	@Autowired
	public void setDestNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000(final JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000) {
		this.destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000 = destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000;
	}

	public JCoDestination getDestNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000() {
		return destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000;
	}

	//NA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000
	@Autowired
	public void setDestNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000(final JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000) {
		this.destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000 = destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000;
	}

	public JCoDestination getDestNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000() {
		return destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000;
	}
	//NA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000
	@Autowired
	public void setDestNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000(final JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000) {
		this.destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000 = destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000;
	}

	public JCoDestination getDestNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000() {
		return destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000;
	}

	//LYNX - END

	//MERCURY - Production -STARTS
	@Autowired
	public void setDestNA_MERCURY_Production_SCMProductionSPNCLNT400(final JCoDestination destNA_MERCURY_Production_SCMProductionSPNCLNT400) {
		this.destNA_MERCURY_Production_SCMProductionSPNCLNT400 = destNA_MERCURY_Production_SCMProductionSPNCLNT400;
	}

	public JCoDestination getDestNA_MERCURY_Production_SCMProductionSPNCLNT400() {
		return destNA_MERCURY_Production_SCMProductionSPNCLNT400;
	}

	@Autowired
	public void setDestNA_MERCURY_Production_ECCProductionRPNCLNT120(final JCoDestination destNA_MERCURY_Production_ECCProductionRPNCLNT120) {
		this.destNA_MERCURY_Production_ECCProductionRPNCLNT120 = destNA_MERCURY_Production_ECCProductionRPNCLNT120;
	}

	public JCoDestination getDestNA_MERCURY_Production_ECCProductionRPNCLNT120() {
		return destNA_MERCURY_Production_ECCProductionRPNCLNT120;
	}

	@Autowired
	public void setDestNA_MERCURY_Production_BWProductionBPNCLNT300(final JCoDestination destNA_MERCURY_Production_BWProductionBPNCLNT300) {
		this.destNA_MERCURY_Production_BWProductionBPNCLNT300 = destNA_MERCURY_Production_BWProductionBPNCLNT300;
	}

	public JCoDestination getDestNA_MERCURY_Production_BWProductionBPNCLNT300() {
		return destNA_MERCURY_Production_BWProductionBPNCLNT300;
	}

	@Autowired
	public void setDestNA_MERCURY_Production_PIProductionXPNCLNT200(final JCoDestination destNA_MERCURY_Production_PIProductionXPNCLNT200) {
		this.destNA_MERCURY_Production_PIProductionXPNCLNT200 = destNA_MERCURY_Production_PIProductionXPNCLNT200;
	}

	public JCoDestination getDestNA_MERCURY_Production_PIProductionXPNCLNT200() {
		return destNA_MERCURY_Production_PIProductionXPNCLNT200;
	}

	//NA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000
	@Autowired
	public void setDestNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000(final JCoDestination destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000) {
		this.destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000 = destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000;
	}

	public JCoDestination getDestNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000() {
		return destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000;
	}

	//NA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000
	@Autowired
	public void setDestNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000(final JCoDestination destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000) {
		this.destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000 = destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000;
	}

	public JCoDestination getDestNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000() {
		return destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000;
	}

	//NA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000
	@Autowired
	public void setDestNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000(final JCoDestination destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000) {
		this.destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000 = destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000;
	}

	public JCoDestination getDestNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000() {
		return destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000;
	}

	//NA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000
	@Autowired
	public void setDestNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000(final JCoDestination destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000) {
		this.destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000 = destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000;
	}

	public JCoDestination getDestNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000() {
		return destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000;
	}

	//MERCURY - Production -END

	// MITEK  - START
	@Autowired
	public void setDestNA_MITEK_Production_ECCProductionRPOCLNT777(final JCoDestination destNA_MITEK_Production_ECCProductionRPOCLNT777) {
		this.destNA_MITEK_Production_ECCProductionRPOCLNT777 = destNA_MITEK_Production_ECCProductionRPOCLNT777;
	}

	public JCoDestination getDestNA_MITEK_Production_ECCProductionRPOCLNT777() {
		return destNA_MITEK_Production_ECCProductionRPOCLNT777;
	}

	//NA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000
	@Autowired
	public void setDestNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000(final JCoDestination destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000) {
		this.destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000 = destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000;
	}

	public JCoDestination getDestNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000() {
		return destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000;
	}
	// MITEK  - END

	//OURSOURCE - START
	@Autowired
	public void setDestNA_OURSOURCE_Production_ECCProductionPJ1CLNT280(final JCoDestination destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280) {
		this.destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280 = destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280;
	}

	public JCoDestination getDestNA_OURSOURCE_Production_ECCProductionPJ1CLNT280() {
		return destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280;
	}

	@Autowired
	public void setDestNA_OURSOURCE_Production_NGWProductionPJ2CLNT280(final JCoDestination destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280) {
		this.destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280 = destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280;
	}

	public JCoDestination getDestNA_OURSOURCE_Production_NGWProductionPJ2CLNT280() {
		return destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280;
	}

	@Autowired
	public void setDestNA_OURSOURCE_Production_BIProductionPJ5CLNT280(final JCoDestination destNA_OURSOURCE_Production_BIProductionPJ5CLNT280) {
		this.destNA_OURSOURCE_Production_BIProductionPJ5CLNT280 = destNA_OURSOURCE_Production_BIProductionPJ5CLNT280;
	}

	public JCoDestination getDestNA_OURSOURCE_Production_BIProductionPJ5CLNT280() {
		return destNA_OURSOURCE_Production_BIProductionPJ5CLNT280;
	}

	//NA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000
	@Autowired
	public void setDestNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000(final JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000) {
		this.destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000 = destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000;
	}

	public JCoDestination getDestNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000() {
		return destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000;
	}

	//NA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000
	@Autowired
	public void setDestNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000(final JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000) {
		this.destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000 = destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000;
	}

	public JCoDestination getDestNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000() {
		return destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000;
	}

	//NA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000
	@Autowired
	public void setDestNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000(final JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000) {
		this.destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000 = destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000;
	}

	public JCoDestination getDestNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000() {
		return destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000;
	}


	//OURSOURCE - END

	//LATAM_LATAMPROJECTONE - START
	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520(final JCoDestination destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520) {
		this.destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520 = destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520() {
		return destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520;
	}

	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620(final JCoDestination destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620) {
		this.destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620 = destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620() {
		return destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620;
	}

	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120(final JCoDestination destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120) {
		this.destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120 = destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120() {
		return destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120;
	}

	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000
	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000(final JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000) {
		this.destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000 = destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000() {
		return destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000;
	}
	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000
	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000(final JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000) {
		this.destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000 = destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000() {
		return destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000;
	}
	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000
	@Autowired
	public void setDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000(final JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000) {
		this.destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000 = destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000;
	}

	public JCoDestination getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000() {
		return destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000;
	}
	//LATAM_LATAMPROJECTONE - END

	//BTBLATAM - START
	@Autowired
	public void setDestLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500(final JCoDestination destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500) {
		this.destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500 = destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500;
	}

	public JCoDestination getDestLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500() {
		return destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500;
	}

	@Autowired
	public void setDestLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100(final JCoDestination destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100) {
		this.destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100 = destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100;
	}

	public JCoDestination getDestLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100() {
		return destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100;
	}

	@Autowired
	public void setDestLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300(final JCoDestination destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300) {
		this.destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300 = destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300;
	}

	public JCoDestination getDestLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300() {
		return destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300;
	}

	//LATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000
	@Autowired
	public void setDestLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000(final JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000) {
		this.destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000 = destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000;
	}

	public JCoDestination getDestLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000() {
		return destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000;
	}
	//LATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000
	@Autowired
	public void setDestLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000(final JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000) {
		this.destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000 = destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000;
	}

	public JCoDestination getDestLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000() {
		return destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000;
	}
	//LATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000
	@Autowired
	public void setDestLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000(final JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000) {
		this.destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000 = destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000;
	}

	public JCoDestination getDestLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000() {
		return destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000;
	}


	//BTBLATAM - END

	//ASPAC - START

	//ASPAC_SYNTHES_Production_ECCProductionMBPCLNT600
	@Autowired
	public void setDestASPAC_SYNTHES_Production_ECCProductionMBPCLNT600(final JCoDestination destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600) {
		this.destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600 = destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600;
	}

	public JCoDestination getDestASPAC_SYNTHES_Production_ECCProductionMBPCLNT600() {
		return destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600;
	}


	@Autowired
	public void setDestASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100(final JCoDestination destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100) {
		this.destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100 = destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100;
	}

	public JCoDestination getDestASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100() {
		return destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100;
	}

	//ASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000
	@Autowired
	public void setDestASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000(final JCoDestination destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000) {
		this.destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000 = destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000;
	}

	public JCoDestination getDestASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000() {
		return destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000;
	}


	//ConsumerASPAC

	@Autowired
	public void setDestASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888(final JCoDestination destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888) {
		this.destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888 = destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888() {
		return destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888;
	}

	@Autowired
	public void setDestASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100(final JCoDestination destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100) {
		this.destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100 = destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100() {
		return destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100;
	}

	@Autowired
	public void setDestASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888(final JCoDestination destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888) {
		this.destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888 = destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888() {
		return destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000
	@Autowired
	public void setDestASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000(final JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000) {
		this.destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000 = destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000() {
		return destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000
	@Autowired
	public void setDestASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000(final JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000) {
		this.destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000 = destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000() {
		return destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000
	@Autowired
	public void setDestASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000(final JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000) {
		this.destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000 = destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000;
	}

	public JCoDestination getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000() {
		return destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000;
	}


	//MARS
	@Autowired
	public void setDestASPAC_MARS_Production_ECCProductionEJ1CLNT100(final JCoDestination destASPAC_MARS_Production_ECCProductionEJ1CLNT100) {
		this.destASPAC_MARS_Production_ECCProductionEJ1CLNT100 = destASPAC_MARS_Production_ECCProductionEJ1CLNT100;
	}

	public JCoDestination getDestASPAC_MARS_Production_ECCProductionEJ1CLNT100() {
		return destASPAC_MARS_Production_ECCProductionEJ1CLNT100;
	}

	//ASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000
	@Autowired
	public void setDestASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000(final JCoDestination destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000) {
		this.destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000 = destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000;
	}

	public JCoDestination getDestASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000() {
		return destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000;
	}

	//Panda

	@Autowired
	public void setDestASPAC_Panda_Production_BIProductionBP1CLNT600(final JCoDestination destASPAC_Panda_Production_BIProductionBP1CLNT600) {
		this.destASPAC_Panda_Production_BIProductionBP1CLNT600 = destASPAC_Panda_Production_BIProductionBP1CLNT600;
	}

	public JCoDestination getDestASPAC_Panda_Production_BIProductionBP1CLNT600() {
		return destASPAC_Panda_Production_BIProductionBP1CLNT600;
	}

	@Autowired
	public void setDestASPAC_Panda_Production_ECCProductionEP1CLNT800(final JCoDestination destASPAC_Panda_Production_ECCProductionEP1CLNT800) {
		this.destASPAC_Panda_Production_ECCProductionEP1CLNT800 = destASPAC_Panda_Production_ECCProductionEP1CLNT800;
	}

	public JCoDestination getDestASPAC_Panda_Production_ECCProductionEP1CLNT800() {
		return destASPAC_Panda_Production_ECCProductionEP1CLNT800;
	}

	@Autowired
	public void setDestASPAC_Panda_Production_PIProductionXP1CLNT800(final JCoDestination destASPAC_Panda_Production_PIProductionXP1CLNT800) {
		this.destASPAC_Panda_Production_PIProductionXP1CLNT800 = destASPAC_Panda_Production_PIProductionXP1CLNT800;
	}

	public JCoDestination getDestASPAC_Panda_Production_PIProductionXP1CLNT800() {
		return destASPAC_Panda_Production_PIProductionXP1CLNT800;
	}

	//ASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000
	@Autowired
	public void setDestASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000(final JCoDestination destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000) {
		this.destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000 = destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000;
	}

	public JCoDestination getDestASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000() {
		return destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000;
	}

	//ASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000
	@Autowired
	public void setDestASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000(final JCoDestination destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000) {
		this.destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000 = destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000;
	}

	public JCoDestination getDestASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000() {
		return destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000;
	}

	//ASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000
	@Autowired
	public void setDestASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000(final JCoDestination destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000) {
		this.destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000 = destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000;
	}

	public JCoDestination getDestASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000() {
		return destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000;
	}

	//TAISHAN
	@Autowired
	public void setDestASPAC_Taishan_Production_ECCProductionRPDCLNT800(final JCoDestination destASPAC_Taishan_Production_ECCProductionRPDCLNT800) {
		this.destASPAC_Taishan_Production_ECCProductionRPDCLNT800 = destASPAC_Taishan_Production_ECCProductionRPDCLNT800;
	}

	public JCoDestination getDestASPAC_Taishan_Production_ECCProductionRPDCLNT800() {
		return destASPAC_Taishan_Production_ECCProductionRPDCLNT800;
	}

	//ASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000
	@Autowired
	public void setDestASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000(final JCoDestination destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000) {
		this.destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000 = destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000;
	}

	public JCoDestination getDestASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000() {
		return destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000;
	}


	//ASPAC - END

	// EMEA - START

	//EUROPE2
	@Autowired
	public void setDestEMEA_EUROPE2_Production_APOProductionAPECLNT050(final JCoDestination destEMEA_EUROPE2_Production_APOProductionAPECLNT050) {
		this.destEMEA_EUROPE2_Production_APOProductionAPECLNT050 = destEMEA_EUROPE2_Production_APOProductionAPECLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_APOProductionAPECLNT050() {
		return destEMEA_EUROPE2_Production_APOProductionAPECLNT050;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_Production_BIProductionBPECLNT050(final JCoDestination destEMEA_EUROPE2_Production_BIProductionBPECLNT050) {
		this.destEMEA_EUROPE2_Production_BIProductionBPECLNT050 = destEMEA_EUROPE2_Production_BIProductionBPECLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_BIProductionBPECLNT050() {
		return destEMEA_EUROPE2_Production_BIProductionBPECLNT050;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_Production_FSFProductionBPICLNT050(final JCoDestination destEMEA_EUROPE2_Production_FSFProductionBPICLNT050) {
		this.destEMEA_EUROPE2_Production_FSFProductionBPICLNT050 = destEMEA_EUROPE2_Production_FSFProductionBPICLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_FSFProductionBPICLNT050() {
		return destEMEA_EUROPE2_Production_FSFProductionBPICLNT050;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_Production_EWMProductionQPJCLNT050(final JCoDestination destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050) {
		this.destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050 = destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_EWMProductionQPJCLNT050() {
		return destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_Production_ECCProductionRPECLNT050(final JCoDestination destEMEA_EUROPE2_Production_ECCProductionRPECLNT050) {
		this.destEMEA_EUROPE2_Production_ECCProductionRPECLNT050 = destEMEA_EUROPE2_Production_ECCProductionRPECLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_ECCProductionRPECLNT050() {
		return destEMEA_EUROPE2_Production_ECCProductionRPECLNT050;
	}


	@Autowired
	public void setDestEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000(final JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000) {
		this.destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000 = destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000;
	}

	public JCoDestination getDestEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000() {
		return destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000(final JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000) {
		this.destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000 = destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000;
	}

	public JCoDestination getDestEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000() {
		return destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000(final JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000) {
		this.destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000 = destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000;
	}

	public JCoDestination getDestEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000() {
		return destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000(final JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000) {
		this.destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000 = destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000;
	}

	public JCoDestination getDestEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000() {
		return destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000;
	}

	@Autowired
	public void setDestEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000(final JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000) {
		this.destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000 = destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000;
	}

	public JCoDestination getDestEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000() {
		return destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000;
	}



	//EMEA_EUROPE2_Production_EWMProductionPJECLNT050
	@Autowired
	public void setDestEMEA_EUROPE2_Production_EWMProductionPJECLNT050(final JCoDestination destEMEA_EUROPE2_Production_EWMProductionPJECLNT050) {
		this.destEMEA_EUROPE2_Production_EWMProductionPJECLNT050 = destEMEA_EUROPE2_Production_EWMProductionPJECLNT050;
	}

	public JCoDestination getDestEMEA_EUROPE2_Production_EWMProductionPJECLNT050() {
		return destEMEA_EUROPE2_Production_EWMProductionPJECLNT050;
	}



	//Galaxy

	@Autowired
	public void setDestEMEA_Galaxy_Production_BIProductionBPMCLNT172(final JCoDestination destEMEA_Galaxy_Production_BIProductionBPMCLNT172) {
		this.destEMEA_Galaxy_Production_BIProductionBPMCLNT172 = destEMEA_Galaxy_Production_BIProductionBPMCLNT172;
	}

	public JCoDestination getDestEMEA_Galaxy_Production_BIProductionBPMCLNT172() {
		return destEMEA_Galaxy_Production_BIProductionBPMCLNT172;
	}

	@Autowired
	public void setDestEMEA_Galaxy_Production_ECCProductionRPMCLNT232(final JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT232) {
		this.destEMEA_Galaxy_Production_ECCProductionRPMCLNT232 = destEMEA_Galaxy_Production_ECCProductionRPMCLNT232;
	}

	public JCoDestination getDestEMEA_Galaxy_Production_ECCProductionRPMCLNT232() {
		return destEMEA_Galaxy_Production_ECCProductionRPMCLNT232;
	}

	@Autowired
	public void setDestEMEA_Galaxy_Production_ECCProductionRPMCLNT050(final JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT050) {
		this.destEMEA_Galaxy_Production_ECCProductionRPMCLNT050 = destEMEA_Galaxy_Production_ECCProductionRPMCLNT050;
	}

	public JCoDestination getDestEMEA_Galaxy_Production_ECCProductionRPMCLNT050() {
		return destEMEA_Galaxy_Production_ECCProductionRPMCLNT050;
	}


	@Autowired
	public void setDestEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000(final JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000) {
		this.destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000 = destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000;
	}

	public JCoDestination getDestEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000() {
		return destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000;
	}

	@Autowired
	public void setDestEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000(final JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000) {
		this.destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000 = destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000;
	}

	public JCoDestination getDestEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000() {
		return destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000;
	}

	//GMED
	@Autowired
	public void setDestEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050(final JCoDestination destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050) {
		this.destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050 = destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050;
	}

	public JCoDestination getDestEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050() {
		return destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050;
	}

	@Autowired
	public void setDestEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000(final JCoDestination destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000) {
		this.destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000 = destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000;
	}

	public JCoDestination getDestEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000() {
		return destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000;
	}

	//IML

	@Autowired
	public void setDestEMEA_ILM_Production_BIProductionB3TCLNT050(final JCoDestination destEMEA_ILM_Production_BIProductionB3TCLNT050) {
		this.destEMEA_ILM_Production_BIProductionB3TCLNT050 = destEMEA_ILM_Production_BIProductionB3TCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_BIProductionB3TCLNT050() {
		return destEMEA_ILM_Production_BIProductionB3TCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_Production_BIProductionB4TCLNT050(final JCoDestination destEMEA_ILM_Production_BIProductionB4TCLNT050) {
		this.destEMEA_ILM_Production_BIProductionB4TCLNT050 = destEMEA_ILM_Production_BIProductionB4TCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_BIProductionB4TCLNT050() {
		return destEMEA_ILM_Production_BIProductionB4TCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_Production_BIProductionBPTCLNT050(final JCoDestination destEMEA_ILM_Production_BIProductionBPTCLNT050) {
		this.destEMEA_ILM_Production_BIProductionBPTCLNT050 = destEMEA_ILM_Production_BIProductionBPTCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_BIProductionBPTCLNT050() {
		return destEMEA_ILM_Production_BIProductionBPTCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_Production_ECCProductionR3TCLNT050(final JCoDestination destEMEA_ILM_Production_ECCProductionR3TCLNT050) {
		this.destEMEA_ILM_Production_ECCProductionR3TCLNT050 = destEMEA_ILM_Production_ECCProductionR3TCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_ECCProductionR3TCLNT050() {
		return destEMEA_ILM_Production_ECCProductionR3TCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_Production_ECCProductionR4TCLNT050(final JCoDestination destEMEA_ILM_Production_ECCProductionR4TCLNT050) {
		this.destEMEA_ILM_Production_ECCProductionR4TCLNT050 = destEMEA_ILM_Production_ECCProductionR4TCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_ECCProductionR4TCLNT050() {
		return destEMEA_ILM_Production_ECCProductionR4TCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_Production_ECCProductionRPTCLNT050(final JCoDestination destEMEA_ILM_Production_ECCProductionRPTCLNT050) {
		this.destEMEA_ILM_Production_ECCProductionRPTCLNT050 = destEMEA_ILM_Production_ECCProductionRPTCLNT050;
	}

	public JCoDestination getDestEMEA_ILM_Production_ECCProductionRPTCLNT050() {
		return destEMEA_ILM_Production_ECCProductionRPTCLNT050;
	}

	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000 = destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000;
	}
	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000 = destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000;
	}
	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000 = destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000;
	}
	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000 = destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000;
	}
	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000 = destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000;
	}
	@Autowired
	public void setDestEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000(final JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000) {
		this.destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000 = destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000;
	}

	public JCoDestination getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000() {
		return destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000;
	}

	//SNC
	@Autowired
	public void setDestEMEA_SNC_Production_SNCProductionQPECLNT050(final JCoDestination destEMEA_SNC_Production_SNCProductionQPECLNT050) {
		this.destEMEA_SNC_Production_SNCProductionQPECLNT050 = destEMEA_SNC_Production_SNCProductionQPECLNT050;
	}

	public JCoDestination getDestEMEA_SNC_Production_SNCProductionQPECLNT050() {
		return destEMEA_SNC_Production_SNCProductionQPECLNT050;
	}

	//EMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000
	@Autowired
	public void setDestEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000(final JCoDestination destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000) {
		this.destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000 = destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000;
	}

	public JCoDestination getDestEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000() {
		return destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000;
	}
	//STF - START
	//EMEA_STF_Production_APOProductionAPCCLNT430
	@Autowired
	public void setDestEMEA_STF_Production_APOProductionAPCCLNT430(final JCoDestination destEMEA_STF_Production_APOProductionAPCCLNT430) {
		this.destEMEA_STF_Production_APOProductionAPCCLNT430 = destEMEA_STF_Production_APOProductionAPCCLNT430;
	}

	public JCoDestination getDestEMEA_STF_Production_APOProductionAPCCLNT430() {
		return destEMEA_STF_Production_APOProductionAPCCLNT430;
	}
	//EMEA_STF_Production_BIProductionBPCCLNT330
	@Autowired
	public void setDestEMEA_STF_Production_BIProductionBPCCLNT330(final JCoDestination destEMEA_STF_Production_BIProductionBPCCLNT330) {
		this.destEMEA_STF_Production_BIProductionBPCCLNT330 = destEMEA_STF_Production_BIProductionBPCCLNT330;
	}

	public JCoDestination getDestEMEA_STF_Production_BIProductionBPCCLNT330() {
		return destEMEA_STF_Production_BIProductionBPCCLNT330;
	}
	//EMEA_STF_Production_CRMProductionCPCCLNT100
	@Autowired
	public void setDestEMEA_STF_Production_CRMProductionCPCCLNT100(final JCoDestination destEMEA_STF_Production_CRMProductionCPCCLNT100) {
		this.destEMEA_STF_Production_CRMProductionCPCCLNT100 = destEMEA_STF_Production_CRMProductionCPCCLNT100;
	}

	public JCoDestination getDestEMEA_STF_Production_CRMProductionCPCCLNT100() {
		return destEMEA_STF_Production_CRMProductionCPCCLNT100;
	}
	//EMEA_STF_Production_MDGProductionOPCCLNT050
	@Autowired
	public void setDestEMEA_STF_Production_MDGProductionOPCCLNT050(final JCoDestination destEMEA_STF_Production_MDGProductionOPCCLNT050) {
		this.destEMEA_STF_Production_MDGProductionOPCCLNT050 = destEMEA_STF_Production_MDGProductionOPCCLNT050;
	}

	public JCoDestination getDestEMEA_STF_Production_MDGProductionOPCCLNT050() {
		return destEMEA_STF_Production_MDGProductionOPCCLNT050;
	}
	//EMEA_STF_Production_NetweaverGatewayProductionP05CLNT050
	@Autowired
	public void setDestEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050(final JCoDestination destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050) {
		this.destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050 = destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050;
	}

	public JCoDestination getDestEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050() {
		return destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050;
	}
	//EMEA_STF_Production_ECCProductionRPCCLNT130
	@Autowired
	public void setDestEMEA_STF_Production_ECCProductionRPCCLNT130(final JCoDestination destEMEA_STF_Production_ECCProductionRPCCLNT130) {
		this.destEMEA_STF_Production_ECCProductionRPCCLNT130 = destEMEA_STF_Production_ECCProductionRPCCLNT130;
	}

	public JCoDestination getDestEMEA_STF_Production_ECCProductionRPCCLNT130() {
		return destEMEA_STF_Production_ECCProductionRPCCLNT130;
	}
	//EMEA_STF_Production_PIProductionXPGCLNT050
	@Autowired
	public void setDestEMEA_STF_Production_PIProductionXPGCLNT050(final JCoDestination destEMEA_STF_Production_PIProductionXPGCLNT050) {
		this.destEMEA_STF_Production_PIProductionXPGCLNT050 = destEMEA_STF_Production_PIProductionXPGCLNT050;
	}

	public JCoDestination getDestEMEA_STF_Production_PIProductionXPGCLNT050() {
		return destEMEA_STF_Production_PIProductionXPGCLNT050;
	}


	//EMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000 = destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000 = destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000 = destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000 = destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000 = destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000
	@Autowired
	public void setDestEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000 = destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000;
	}
	//EMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000
	@Autowired
	public void setDeEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT00000(final JCoDestination destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000) {
		this.destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000 = destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000;
	}

	public JCoDestination getDestEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000() {
		return destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000;
	}


	//STF - END

	//SUSTAIN
	//EMEA_Sustain_Sandbox_RSB910;
	@Autowired
	public void setDestEMEA_Sustain_Sandbox_RSB910(final JCoDestination destEMEA_Sustain_Sandbox_RSB910) {
		this.destEMEA_Sustain_Sandbox_RSB910 = destEMEA_Sustain_Sandbox_RSB910;
	}

	public JCoDestination getDestEMEA_Sustain_Sandbox_RSB910() {
		return destEMEA_Sustain_Sandbox_RSB910;
	}
	//EMEA_Sustain_Production_BIProductionBPBCLNT050
	@Autowired
	public void setDestEMEA_Sustain_Production_BIProductionBPBCLNT050(final JCoDestination destEMEA_Sustain_Production_BIProductionBPBCLNT050) {
		this.destEMEA_Sustain_Production_BIProductionBPBCLNT050 = destEMEA_Sustain_Production_BIProductionBPBCLNT050;
	}

	public JCoDestination getDestEMEA_Sustain_Production_BIProductionBPBCLNT050() {
		return destEMEA_Sustain_Production_BIProductionBPBCLNT050;
	}

	//EMEA_Sustain_Production_ECCProductionRPBCLNT910
	@Autowired
	public void setDestEMEA_Sustain_Production_ECCProductionRPBCLNT910(final JCoDestination destEMEA_Sustain_Production_ECCProductionRPBCLNT910) {
		this.destEMEA_Sustain_Production_ECCProductionRPBCLNT910 = destEMEA_Sustain_Production_ECCProductionRPBCLNT910;
	}

	public JCoDestination getDestEMEA_Sustain_Production_ECCProductionRPBCLNT910() {
		return destEMEA_Sustain_Production_ECCProductionRPBCLNT910;
	}

	//EMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000
	@Autowired
	public void setDestEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000(final JCoDestination destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000) {
		this.destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000 = destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000;
	}

	public JCoDestination getDestEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000() {
		return destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000;
	}
	//EMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000
	@Autowired
	public void setDeEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT00010(final JCoDestination destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000) {
		this.destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000 = destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000;
	}

	public JCoDestination getDestEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000() {
		return destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000;
	}


	//SYMPHONY
	//EMEA_SYMPHONY_Production_ECCProductionP30CLNT200
	@Autowired
	public void setDestEMEA_SYMPHONY_Production_ECCProductionP30CLNT200(final JCoDestination destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200) {
		this.destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200 = destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200;
	}

	public JCoDestination getDestEMEA_SYMPHONY_Production_ECCProductionP30CLNT200() {
		return destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200;
	}

	//EMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000
	@Autowired
	public void setDestEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000(final JCoDestination destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000) {
		this.destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000 = destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000;
	}

	public JCoDestination getDestEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000() {
		return destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000;
	}

	//SYNTHES
	//EMEA_SYNTHES_Production_GRCProductionACPCLNT001
	@Autowired
	public void setDestEMEA_SYNTHES_Production_GRCProductionACPCLNT001(final JCoDestination destEMEA_SYNTHES_Production_GRCProductionACPCLNT001) {
		this.destEMEA_SYNTHES_Production_GRCProductionACPCLNT001 = destEMEA_SYNTHES_Production_GRCProductionACPCLNT001;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_GRCProductionACPCLNT001() {
		return destEMEA_SYNTHES_Production_GRCProductionACPCLNT001;
	}
	//EMEA_SYNTHES_Production_BIProductionBIPCLNT020
	@Autowired
	public void setDestEMEA_SYNTHES_Production_BIProductionBIPCLNT020(final JCoDestination destEMEA_SYNTHES_Production_BIProductionBIPCLNT020) {
		this.destEMEA_SYNTHES_Production_BIProductionBIPCLNT020 = destEMEA_SYNTHES_Production_BIProductionBIPCLNT020;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_BIProductionBIPCLNT020() {
		return destEMEA_SYNTHES_Production_BIProductionBIPCLNT020;
	}
	//EMEA_SYNTHES_Production_GTSProductionGTPCLNT001
	@Autowired
	public void setDestEMEA_SYNTHES_Production_GTSProductionGTPCLNT001(final JCoDestination destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001) {
		this.destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001 = destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_GTSProductionGTPCLNT001() {
		return destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001;
	}

	//EMEA_SYNTHES_Production_ECCProductionP01CLNT020
	@Autowired
	public void setDestEMEA_SYNTHES_Production_ECCProductionP01CLNT020(final JCoDestination destEMEA_SYNTHES_Production_ECCProductionP01CLNT020) {
		this.destEMEA_SYNTHES_Production_ECCProductionP01CLNT020 = destEMEA_SYNTHES_Production_ECCProductionP01CLNT020;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_ECCProductionP01CLNT020() {
		return destEMEA_SYNTHES_Production_ECCProductionP01CLNT020;
	}
	//EMEA_SYNTHES_Production_SOLMANProductionS01CLNT001
	@Autowired
	public void setDestEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001(final JCoDestination destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001) {
		this.destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001 = destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001() {
		return destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001;
	}
	//EMEA_SYNTHES_Production_ECCProductionMBPCLNT600
	@Autowired
	public void setDestEMEA_SYNTHES_Production_ECCProductionMBPCLNT600(final JCoDestination destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600) {
		this.destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600 = destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600;
	}

	public JCoDestination getDestEMEA_SYNTHES_Production_ECCProductionMBPCLNT600() {
		return destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000
	@Autowired
	public void setDestEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000(final JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000) {
		this.destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000 = destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000;
	}

	public JCoDestination getDestEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000() {
		return destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000
	@Autowired
	public void setDestEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000(final JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000) {
		this.destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000 = destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000;
	}

	public JCoDestination getDestEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000() {
		return destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000
	@Autowired
	public void setDestEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000(final JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000) {
		this.destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000 = destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000;
	}

	public JCoDestination getDestEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000() {
		return destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000;
	}
	//ASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000
	@Autowired
	public void setDestASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000(final JCoDestination destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000) {
		this.destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000 = destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000;
	}

	public JCoDestination getDestASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000() {
		return destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000
	@Autowired
	public void setDestEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000(final JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000) {
		this.destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000 = destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000;
	}

	public JCoDestination getDestEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000() {
		return destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000
	@Autowired
	public void setDestEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000(final JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000) {
		this.destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000 = destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000;
	}

	public JCoDestination getDestEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000() {
		return destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000;
	}


	//VDR
	//EMEA_VDR_Production_ECCProductionFRPCLNT382
	@Autowired
	public void setDestEMEA_VDR_Production_ECCProductionFRPCLNT382(final JCoDestination destEMEA_VDR_Production_ECCProductionFRPCLNT382) {
		this.destEMEA_VDR_Production_ECCProductionFRPCLNT382 = destEMEA_VDR_Production_ECCProductionFRPCLNT382;
	}

	public JCoDestination getDestEMEA_VDR_Production_ECCProductionFRPCLNT382() {
		return destEMEA_VDR_Production_ECCProductionFRPCLNT382;
	}

	//EMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000
	@Autowired
	public void setDestEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000(final JCoDestination destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000) {
		this.destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000 = destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000;
	}

	public JCoDestination getDestEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000() {
		return destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000;
	}
	// EMEA - END



	//BW4PFB
	@Autowired
	public void setDestBW4PFB(final JCoDestination destBW4PFB) {
		this.destBW4PFB = destBW4PFB;
	}

	public JCoDestination getDestBW4PFB() {
		return destBW4PFB;
	}

	//S4PFI
	@Autowired
	public void setDestS4PFI(final JCoDestination destS4PFI) {
		this.destS4PFI = destS4PFI;
	}

	public JCoDestination getDestS4PFI() {
		return destS4PFI;
	}


	//GRCSYS
	@Autowired
	public void setDestGRCSYS(final JCoDestination destGRCSYS) {
		this.destGRCSYS = destGRCSYS;
	}

	public JCoDestination getDestGRCSYS() {
		return destGRCSYS;
	}

	//CFIN PFI/PFQ

	public JCoDestination getDestNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000() {
		return destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000;
	}

	@Autowired
	public void setDestNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000(final JCoDestination destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000) {
		this.destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000 = destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000;
	}

	public JCoDestination getDestNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000() {
		return destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000;
	}

	@Autowired
	public void setDestNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000(final JCoDestination destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000) {
		this.destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000 = destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000;
	}

}
