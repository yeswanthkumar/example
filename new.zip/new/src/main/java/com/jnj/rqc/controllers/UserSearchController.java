package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.models.JJEDsUserLookupMdl;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;


@Controller
public class UserSearchController {
	static final Logger log = LoggerFactory.getLogger(UserSearchController.class);

	@Autowired
	private UserSearchService userSearchService;

	List<KeyValPair> searchBy;



	@GetMapping("/allUserSearchJJEDS")
    public String allUserSearchJJEDS(Model model, HttpServletRequest request) {
    	log.info("Manual User Lookup in JJED's");
    	return "search/manualUserSearch";
    }



	@PostMapping("/allUserSearchResults")
    public String allUserSearchResults(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected Excel File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the right file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "search/manualUserSearch";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel file/Document...!");
            return "search/manualUserSearch";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<String> usrIds = userSearchService.readUserIdExcel(path);
    		if(usrIds == null || usrIds.isEmpty()) {
    			log.info("NOT a Valid Excel file.");
        		model.addAttribute("message", "True");
        		model.addAttribute("error", "Status: No Data found in Excel file/Document is empty.!");
                return "search/manualUserSearch";
    		}
    		List<JJEDsUserLookupMdl> userData = userSearchService.getAllUserData(usrIds);
    		HttpSession session = request.getSession();
    		session.removeAttribute("ALL_USER_DATA");
    		if(userData != null && !userData.isEmpty()) {
    			session.setAttribute("USER_FILENAME", file.getOriginalFilename());
    			session.setAttribute("ALL_USER_DATA", userData);
        		model.addAttribute("ALL_USER_DATA", userData);
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((userData != null && !userData.isEmpty())? userData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "search/manualUserSearch";
    }

	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/downloadAllUserData")
	public ResponseEntity<InputStreamResource> downloadAllUserData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		List<JJEDsUserLookupMdl> userDataLst = (List<JJEDsUserLookupMdl>)request.getSession().getAttribute("ALL_USER_DATA");
		String filePath = userSearchService.writeAllUserCSVReport(userDataLst);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }





	@GetMapping("/userSearchJJEDS")
    public String loadSearchForm(Model model) {
    	log.info("Routing to User search page.");
    	searchBy = Utility.getSearchByList();
    	model.addAttribute("searchBy",searchBy);
		return "search/jjedsUserSearch";
    }


	@PostMapping("/searchUserDetails")
    public String searchUserDetails(@RequestParam("searchBy") int srchParam,  @RequestParam("data") String data, Model model, HttpServletRequest request) {
    	log.info(" searchUserDetails  searchBy :"+srchParam+"   Data:"+data);
    	model.addAttribute("params",data);
    	if(searchBy == null) {
        	searchBy = Utility.getSearchByList();
        }
        model.addAttribute("searchBy",searchBy);
        model.addAttribute("srchParam",srchParam);

    	if(srchParam == 0 || StringUtils.isEmpty(data)) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter "+((srchParam==0)?" Search By ":" ID's "));
            return "search/jjedsUserSearch";
    	}
    	try{
    		List<UserSearchModel> userSearchList = userSearchService.getUserData(srchParam, data, 0);
    		HttpSession session = request.getSession();
    		session.removeAttribute("userSearchList");
    		session.setAttribute("userSearchList", userSearchList);
    		model.addAttribute("userSearchList", userSearchList);
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Search successful... total records:"+((userSearchList != null)? userSearchList.size(): '0'));
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "search/jjedsUserSearch";
    }


	@ResponseBody
    @GetMapping("/downloadUserExcel")
    public ResponseEntity<InputStreamResource> downloadTermExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		List<UserSearchModel> userSearchList = (List<UserSearchModel>)request.getSession().getAttribute("userSearchList");
		String filePath = userSearchService.writeUserCSVReport(userSearchList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }






}
