package com.jnj.rqc.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CRUnitADGroupMdl {
	private String crCode;
	private String adgroup;
	private String position;
	private String type;

	@Override
	public String toString() {
		return "CRUnitADGroupMdl [crCode=" + crCode + ", adgroup=" + adgroup + ", position=" + position + ", type="
				+ type + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		CRUnitADGroupMdl other = (CRUnitADGroupMdl) obj;
		if (adgroup == null) {
			if (other.adgroup != null)
				return false;
		} else if (!adgroup.equals(other.adgroup))
			return false;
		if (crCode == null) {
			if (other.crCode != null)
				return false;
		} else if (!crCode.equals(other.crCode))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adgroup == null) ? 0 : adgroup.hashCode());
		result = prime * result + ((crCode == null) ? 0 : crCode.hashCode());
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}










}
