package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZPosVariantMdl {
	private int 	posvarid;
	private int 	accid;
	private String 	posvarname;
	private String 	posvardesc;
	private String 	isactive;
	private  String createdby;
	private Date 	createdon;
	private  String cchangedby;
	private Date 	changedon;

	@Override
	public String toString() {
		return "ZPosVariantMdl [posvarid=" + posvarid + ", accid=" + accid + ", posvarname=" + posvarname
				+ ", posvardesc=" + posvardesc + ", isactive=" + isactive + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZPosVariantMdl other = (ZPosVariantMdl) obj;
		if (accid != other.accid)
			return false;
		if (posvardesc == null) {
			if (other.posvardesc != null)
				return false;
		} else if (!posvardesc.equals(other.posvardesc))
			return false;
		if (posvarid != other.posvarid)
			return false;
		if (posvarname == null) {
			if (other.posvarname != null)
				return false;
		} else if (!posvarname.equals(other.posvarname))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accid;
		result = prime * result + ((posvardesc == null) ? 0 : posvardesc.hashCode());
		result = prime * result + posvarid;
		result = prime * result + ((posvarname == null) ? 0 : posvarname.hashCode());
		return result;
	}







}
