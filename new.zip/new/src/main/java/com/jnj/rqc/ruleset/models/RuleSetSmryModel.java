package com.jnj.rqc.ruleset.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RuleSetSmryModel {
	private String app1;
	private String app2;
	private int count;
	private String fileLoc;
	private String query;
	private Date created;

	@Override
	public String toString() {
		return "RuleSetSmryModel [app1=" + app1 + ", app2=" + app2 + ", count=" + count + "]";
	}

	public String getData() {
		return  app1 + "~" + app2 + "~" + count + "~" + fileLoc + "~" +Utility.fmtMMDDYYYYTime(created) + "~" + query;
	}

}
