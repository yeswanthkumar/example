package com.jnj.rqc.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleFunction {
	private int funcId;
	private String funcName;
	private String funcDescn;
	private List<FuncTransaction> transactions;


	@Override
	public String toString() {
		return "RoleFunction [funcId=" + funcId + ", funcName=" + funcName + ", funcDescn=" + funcDescn + "]";
	}

}
