package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.models.AppRoutingModel;
import com.jnj.rqc.reportmodels.ReportDataModel;


public interface RqcReportService {
	public Map<String, ReportDataModel> processRQCReport(String startDate, String endDate, int status, String appName);
	public void getRoleDetails(Map<String, ReportDataModel> repDataMap, String appName);
	public String createRQCCsvReport(String fileName, List<ReportDataModel> repDataList);
	public String createRoutingFile(String fileName, List<AppRoutingModel> rtModel);
}
