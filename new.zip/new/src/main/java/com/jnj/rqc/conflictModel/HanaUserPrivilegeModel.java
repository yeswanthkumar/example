package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class HanaUserPrivilegeModel {
	private String roleName;
	private String objType;
	private String objName;
	private String colName;
	private String privilege;
	private String valid;



	public String getData() {
		return roleName + "~" + objType + "~" + objName + "~" + colName + "~" + privilege + "~" + valid ;
	}


	@Override
	public String toString() {
		return "HanaUserPrivilegeModel [roleName=" + roleName + ", objType=" + objType + ", objName=" + objName
				+ ", colName=" + colName + ", privilege=" + privilege + ", valid=" + valid + "]";
	}

}
