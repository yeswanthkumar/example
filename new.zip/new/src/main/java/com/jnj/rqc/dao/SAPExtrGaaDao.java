package com.jnj.rqc.dao;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.sap.conn.jco.JCoException;

public interface SAPExtrGaaDao {
	public List<String> getAllValidUsers(String templSysParam) throws JCoException  ;
	public List<String> getUsersRoles(String user, String templSysParam) throws JCoException;
	public String getRoleDescription(String role, String templSysParam) throws JCoException;

	public List<SAPUserAccessModel> getValidUsersWithDate(String templSysParam) throws JCoException  ;
	public String getUsersPersonNumber(String user, String templSysParam) throws JCoException;
	public String getUsersWwId(String prsnNumber, String templSysParam) throws JCoException;

	//Dialog Users
	public Map<String, String> getDialogUsers(String templSysParam) throws JCoException;

	//Method to get User ROLE/AD Groups from GRC system
	public List<IAMRolesADGrpMdl> getPFBUserRoleADGrps(String sysTempl, String userId) throws JCoException;
	public List<String> getPFIUserRoleADGrps(String templSysParam, String user) throws JCoException;
	public List<String> getGRCUserRoleADGrps(String templSysParam, String user) throws JCoException;


}
