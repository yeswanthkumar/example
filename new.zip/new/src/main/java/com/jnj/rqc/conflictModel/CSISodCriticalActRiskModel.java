package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSISodCriticalActRiskModel {

	private String disp;
	private String bussProc;
	private String riskId;
	private String funcId1;
	private String funcDesc1;
	private String shrtDescRisk;
	private String longDescRisk;
	private String riskLevel;
	private String changeCmnt;
	private String status;

	@Override
	public String toString() {
		return "CSISodCriticalActRiskModel [disp=" + disp + ", bussProc=" + bussProc + ", riskId=" + riskId
				+ ", funcId1=" + funcId1 + ", funcDesc1=" + funcDesc1 + ", shrtDescRisk=" + shrtDescRisk
				+ ", longDescRisk=" + longDescRisk + ", riskLevel=" + riskLevel + ", changeCmnt=" + changeCmnt
				+ ", status=" + status + "]";
	}


	public String getData() {
		return disp + "~" + bussProc + "~" + riskId + "~" + funcId1 + "~" + funcDesc1 + "~" + shrtDescRisk
				+ "~" + longDescRisk + "~" + riskLevel + "~" + changeCmnt + "~" + status;
	}



}
