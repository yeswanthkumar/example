package com.jnj.rqc.mastermetadata.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MitigationData {
	private String mid;	
    private String mcntrl;
    private String mdesc;
    private String isActive;
    private String type;
    private String createdBy;
    private Date createdOn;
    private String changedBy;
    private Date changedOn;
    }
