package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.UserSearchDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.UserSearchModel;


/**
 * File    : <b>UserSearchDaoImpl.java</b>
 * @author : DChauras @Created : Dec 12, 2019 11:02:05 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class UserSearchDaoImpl  extends BaseDao implements UserSearchDao {
	static final Logger log = LoggerFactory.getLogger(UserSearchDaoImpl.class);



	@Override
	public List<UserSearchModel> getAllUsersByWWId(List<Object> ids, int status)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);

		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where WW_ID in (:wids) ");
		if(status == 1) {
			 sql.append(" AND EMP_STAT_TXT ='ACTIVE' ");
		 }else if(status == 2) {
			 sql.append(" AND EMP_STAT_TXT ='TERMINATED' ");
		 }
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		//String params = StringUtils.join(ids, ",");
		Map<String, Object> params = new HashMap<>();
		params.put("wids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		//final List<UserSearchModel> userData = getJdbcTemplate().query(sql, new Object[] {params}, new BeanPropertyRowMapper<UserSearchModel>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}
	
	@Override
	public List<UserSearchModel> getAllUsersByWWIdReport(List<Object> ids, int status)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);

		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where WW_ID in (:wids) ");
		/*if(status == 1) {
			 sql.append(" AND EMP_STAT_TXT ='ACTIVE' ");
		 }else if(status == 2) {
			 sql.append(" AND EMP_STAT_TXT ='TERMINATED' ");
		 }*/
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		//String params = StringUtils.join(ids, ",");
		Map<String, Object> params = new HashMap<>();
		params.put("wids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		//final List<UserSearchModel> userData = getJdbcTemplate().query(sql, new Object[] {params}, new BeanPropertyRowMapper<UserSearchModel>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}




	@Override
	public List<UserSearchModel> getAllUsersByNTId(List<Object> ids, int status)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);
		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where JNJ_MSFT_USRNM_TXT in (:ids) ");
		 if(status == 1) {
			 sql.append(" AND EMP_STAT_TXT ='ACTIVE' ");
		 }else if(status == 2) {
			 sql.append(" AND EMP_STAT_TXT ='TERMINATED' ");
		 }
		 sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		Map<String, Object> params = new HashMap<>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}




	@Override
	public List<UserSearchModel> getAllUsersByFmlyNm(List<Object> ids)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);
		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where FMLY_NM in (:ids) ");
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		Map<String, Object> params = new HashMap<>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}


	@Override
	public List<UserSearchModel> getAllUsersByFirstNm(List<Object> ids)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);
		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where GIVEN_NM in (:ids) ");
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		Map<String, Object> params = new HashMap<>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}

	@Override
	public List<UserSearchModel> getAllUsersByEmail(List<Object> emailIds, int status)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ emailIds);

		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, ");
		sql.append(" POSN_TITL_TXT, JOB_ID, POSN_ID, PREFD_LANG_TXT, RM_NO_TXT, LGL_ENT_CATG_CD, JNJ_CO_CD ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where upper(JNJ_EMAIL_ADDR_TXT) in (:emailIds) ");
		if(status == 1) {
			sql.append(" AND EMP_STAT_TXT ='ACTIVE' ");
		}else if(status == 2) {
			sql.append(" AND EMP_STAT_TXT ='TERMINATED' ");
		}
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		Map<String, Object> params = new HashMap<>();
		params.put("emailIds", emailIds);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql.toString(), params, new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}





	@Override
	public List<UserSearchModel> getAllUsersByFirstNmLstNm(String firstNm, String lstNm, int status)throws SQLException, DataAccessException {
		log.info("ID's Received firstNm :"+ firstNm +"  lstNm: "+lstNm);
		StringBuilder sql = new StringBuilder();
		sql.append(" Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, ");
		sql.append(" EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID, LGL_ENT_CATG_CD, JNJ_CO_CD  ");
		sql.append(" From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where upper(GIVEN_NM) = '"+firstNm+"'  AND upper(FMLY_NM) = '"+lstNm+"'");
		if(status == 1) {
			sql.append(" AND EMP_STAT_TXT ='ACTIVE' ");
		}else if(status == 2) {
			sql.append(" AND EMP_STAT_TXT ='TERMINATED' ");
		}
		sql.append(" ORDER BY JNJ_MSFT_USRNM_TXT, EMP_STAT_TXT ");
		final List<UserSearchModel> userData = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}

	@Override
	public List<UserSearchModel> getUserByWWIdFromJJEDS(String userId) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" Select employeeid WW_ID, UPPER (givenname) GIVEN_NM, UPPER (sn) FMLY_NM, UPPER (mail) JNJ_EMAIL_ADDR_TXT, UPPER (manager) JNJ_SUPVR_WW_ID, UPPER (jnjmsusername) JNJ_MSFT_USRNM_TXT, ");
		sql.append(" UPPER (employeetype) EMP_STAT_TXT, jnjstopdate TERMNN_DT, jnjstartdate LAST_HIRE_DT, UPPER (department) JNJ_DEPTM_CD, UPPER (jnjdepartmentdescription) JNJ_DEPTM_DESCN_TXT, UPPER (telephonenumber) BUSN_TEL_NO, UPPER (l) LOCN_ID, ");
		sql.append(" UPPER (title) POSN_TITL_TXT, UPPER (jnjjobcode) JOB_ID, UPPER (jnjjobcode) POSN_ID, UPPER (preferredlanguage) PREFD_LANG_TXT, UPPER (roomnumber) RM_NO_TXT, UPPER (legalentitycategory) LGL_ENT_CATG_CD, UPPER (jnjbusinessunit) JNJ_CO_CD ");
		sql.append(" From jjeds_admin.persn_all@jjeds Where employeeid IN ('"+userId+"')");		
		sql.append(" ORDER BY jnjmsusername, employeetype ");
		List<UserSearchModel> userData = getJdbcTemplatePRODSodRefresh().query(sql.toString(), new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}

	@Override
	public List<UserSearchModel> getUserByEMailIdFromJJEDS(String mailId) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" Select employeeid WW_ID, UPPER (givenname) GIVEN_NM, UPPER (sn) FMLY_NM, UPPER (mail) JNJ_EMAIL_ADDR_TXT, UPPER (manager) JNJ_SUPVR_WW_ID, UPPER (jnjmsusername) JNJ_MSFT_USRNM_TXT, ");
		sql.append(" UPPER (employeetype) EMP_STAT_TXT, jnjstopdate TERMNN_DT, jnjstartdate LAST_HIRE_DT, UPPER (department) JNJ_DEPTM_CD, UPPER (jnjdepartmentdescription) JNJ_DEPTM_DESCN_TXT, UPPER (telephonenumber) BUSN_TEL_NO, UPPER (l) LOCN_ID, ");
		sql.append(" UPPER (title) POSN_TITL_TXT, UPPER (jnjjobcode) JOB_ID, UPPER (jnjjobcode) POSN_ID, UPPER (preferredlanguage) PREFD_LANG_TXT, UPPER (roomnumber) RM_NO_TXT, UPPER (legalentitycategory) LGL_ENT_CATG_CD, UPPER (jnjbusinessunit) JNJ_CO_CD ");
		sql.append(" From jjeds_admin.persn_all@jjeds Where UPPER(mail) IN (UPPER('"+mailId+"'))");		
		sql.append(" ORDER BY jnjmsusername, employeetype ");
		List<UserSearchModel> userData = getJdbcTemplatePRODSodRefresh().query(sql.toString(), new BeanPropertyRowMapper<>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}

	/*@Override
	public String insertUserActivityData(List<UserActivityModel> dataList)throws SQLException, DataAccessException{
		 SimpleJdbcInsert devJdbcInsert = getUserSimpleJdbcInsert459();
	        List<Map<String, Object>> batchValues = new ArrayList<>(dataList.size());
	        Date addedDate = new Date();
	        for (UserActivityModel actMdl : dataList) {
	            Map<String, Object> map = new HashMap<String, Object>();
	            String userId = actMdl.getUserId();
	            if(userId != null && userId.length() > 16) {
	            	userId = userId.substring(0,15);
	            }
	            map.put("USER_ID", userId);
	            map.put("FIRST_NAME", actMdl.getFirstName());
	            map.put("LAST_NAME", actMdl.getLastName());
	            map.put("ROLE", actMdl.getRole());
	            map.put("SRC_SYS", actMdl.getSrcSys());
	            map.put("EMP_ACTIVE", actMdl.getEmpActive());
	            map.put("DT_UPDATED", actMdl.getDtUpdated());
	            map.put("DT_ADDED", addedDate);
	            batchValues.add(map);
	        }

	        if (!devJdbcInsert.isCompiled()) {
	        	devJdbcInsert.includeSynonymsForTableColumnMetaData()
	        	.withSchemaName("SOD_EXTR")
	        	.withTableName("USER_STAT_DATA");
	        }
	        int[] status = devJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));
	        return status.length == batchValues.size() ? "Success" : "Failed";
	}


	public boolean clearUserCache()throws SQLException, DataAccessException{
		//String sql = " DELETE FROM SOD_EXTR.USER_STAT_DATA WHERE SRC_SYS <> 'CARSMA' ";
		String sql = " DELETE SOD_EXTR.USER_STAT_DATA";
	 	int count =   getJdbcTemplate0459().update(sql);
	 	return (count > 0) ? true:false;
	}
*/

}
