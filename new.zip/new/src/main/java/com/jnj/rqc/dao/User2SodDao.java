package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.models.StrKeyValPair;



public interface User2SodDao {

	public int insertUser2SodMitiData(List<SapMitiCntrlModel> dataList) throws SQLException, DataAccessException;
	public List<SapMitiCntrlModel> loadMitiCntrlDBData() throws SQLException, DataAccessException;
	public int insertUser2SodRevrData(List<SapPlatformReviwerMdl> dataList) throws SQLException, DataAccessException;
	public int insertMercuryUser2SodRevrData(List<StrKeyValPair> dataList) throws SQLException, DataAccessException;
	public List<SapPlatformReviwerMdl> loadReviewerDBData() throws SQLException, DataAccessException;
	public List<StrKeyValPair> loadMercuryReviewerDBData() throws SQLException, DataAccessException;
}
