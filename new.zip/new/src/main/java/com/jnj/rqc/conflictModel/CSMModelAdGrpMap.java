package com.jnj.rqc.conflictModel;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSMModelAdGrpMap {
	private String 	adgroup;
	private String 	modelname;
	private Date 	updatedDate;
	private String 	updatedBy;




	public String getData() {
		return adgroup + "~" + modelname + "~" + Utility.fmtCsmDt2Str(updatedDate) + "~" + updatedBy ;
	}


	@Override
	public String toString() {
		return "CSMModelAdGrpMap [adgroup=" + adgroup + ", modelName=" + modelname + ", updatedDate=" + updatedDate
				+ ", updatedBy=" + updatedBy + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		CSMModelAdGrpMap other = (CSMModelAdGrpMap) obj;
		if (adgroup == null) {
			if (other.adgroup != null)
				return false;
		} else if (!adgroup.equals(other.adgroup))
			return false;
		if (modelname == null) {
			if (other.modelname != null)
				return false;
		} else if (!modelname.equals(other.modelname))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adgroup == null) ? 0 : adgroup.hashCode());
		result = prime * result + ((modelname == null) ? 0 : modelname.hashCode());
		return result;
	}






}
