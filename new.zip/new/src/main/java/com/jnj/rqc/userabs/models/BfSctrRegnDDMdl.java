package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BfSctrRegnDDMdl {
	String regid;
	String regname;
	String regdesc;
	String regimg;
	String regloc;


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BfSctrRegnDDMdl other = (BfSctrRegnDDMdl) obj;
		if (regdesc == null) {
			if (other.regdesc != null)
				return false;
		} else if (!regdesc.equals(other.regdesc))
			return false;
		if (regid == null) {
			if (other.regid != null)
				return false;
		} else if (!regid.equals(other.regid))
			return false;
		if (regname == null) {
			if (other.regname != null)
				return false;
		} else if (!regname.equals(other.regname))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((regdesc == null) ? 0 : regdesc.hashCode());
		result = prime * result + ((regid == null) ? 0 : regid.hashCode());
		result = prime * result + ((regname == null) ? 0 : regname.hashCode());
		return result;
	}



}