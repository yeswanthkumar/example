package com.jnj.rqc.sch;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SchAdminModel {
	private String region;
	private int runSch;
	private Date createdDt;
	private String createdBy;
	private Date updatedDt;
	private String updatedBy;



	@Override
	public String toString() {
		return "SchAdminModel [region=" + region + ", runSch=" + runSch + ", createdDt=" + createdDt + ", createdBy="
				+ createdBy + ", updatedDt=" + updatedDt + ", updatedBy=" + updatedBy + "]";
	}





}


