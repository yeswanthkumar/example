package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.ApplDataDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.AppDataModel;
import com.jnj.rqc.models.PosRoles;
import com.jnj.rqc.util.Utility;

@Service
public class ApplDataDaoImpl extends BaseDao implements ApplDataDao {


	@Override
	public List<AppDataModel> getApplicationDataList(int tktNum) throws SQLException, DataAccessException {

		String sql = " SELECT DISTINCT c.appln_id, c.appln_nm, c.appln_descn, c.display, c.helpfull_tip, "+
	    " DECODE(d.appln_id, null, 'Unchecked', DECODE(d.rmvd, null, 'Checked', 0, 'Checked', 1, 'UnChecked')) chk, "+
	    " DECODE(d.appln_id, null, 'Unchecked', DECODE(d.rmvd, null, 'Unchecked', 1, 'Checked', 0, 'UnChecked')) rem_chk, "+
	    " a.appln_grp_id grp_id, NVL(a.appln_cat_id, 0) appln_cat_id, NVL(a.appln_sub_cat_id, 0) appln_sub_cat_id, appln_grp_descn grp_nm, disply_ordnl app_ord "+
	    " FROM   TIPTOP.cli_appln d, TIPTOP.V_APPLN_CERT c, TIPTOP.appln_grp a " +
	    " WHERE  d.appln_id(+) = c.appln_id AND d.tickt_no(+) = ? "+
	    " AND c.appln_grp_id = a.appln_grp_id AND a.sftw_ind = 'N' AND a.Display = 1 "+
	    " order by a.APPLN_GRP_DESCN, grp_id, app_ord, c.appln_nm ";

		final List<AppDataModel> appdata = getJdbcTemplate().query(sql, new Object[] {tktNum}, new BeanPropertyRowMapper<>(AppDataModel.class));
		return appdata;
	}


	@Override
	public Map<String, List<AppDataModel>> queryAppsData(int tktNum) throws SQLException, DataAccessException {
		final List<AppDataModel> appdata = getApplicationDataList(tktNum);
		Map<String, List<AppDataModel>> dataMap = new LinkedHashMap<>();
		appdata.forEach(appMdl ->{
			String grpKey = appMdl.getGrpId()+"_"+appMdl.getGrpNm();
			//List<PosRoles> roles = getPosRoles(appMdl.getApplnId());
			//appMdl.setRoles(roles);
			if(dataMap.containsKey(grpKey)) {
				List<AppDataModel> tmp = dataMap.get(grpKey);
				tmp.add(appMdl);
				dataMap.put(grpKey, tmp);
			}else {
				List<AppDataModel> apLst = new ArrayList<>();
				apLst.add(appMdl);
				dataMap.put(grpKey, apLst);
			}
		});
		return dataMap;
	}

	public List<PosRoles> getPosRoles(int applnId) {
		return Utility.getPosRole(applnId);

	}


}
