package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.termdata.models.TermDataSmryModel;

public interface UserRoleActivityDao {
	public List<UserActivityModel> getCcraUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getCoreUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getGpsUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getIcsUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getHcsop02UserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getHcsop17UserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getMdmUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getWmsMlcUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getWmsSdcUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getHcsop50UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException;
	public List<UserActivityModel> getHcsop53UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException;
	public List<UserActivityModel> getHcsop40UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException;
	//public List<UserActivityModel> getCarsIsUserData()throws SQLException, DataAccessException;
	//public List<UserActivityModel> getCarsMaUserData() throws SQLException, DataAccessException ;
	public String insertUserActivityData(List<UserActivityModel> dataList)throws SQLException, DataAccessException;
	public int clearUserCache()throws SQLException, DataAccessException;
	public List<String> getActiveUniqueIdsForSystem(String systemNm)throws SQLException, DataAccessException;
	//Non-SOX
	public int clearNonSoxUserCache() throws SQLException, DataAccessException;
	public List<UserActivityModel> get340BR2UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException;
	public List<UserActivityModel> getEmsNextGenUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getFalconUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getFomUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getFTCCUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getPVCSUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getRMSJAPANUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;
	public List<UserActivityModel> getTMUserData(List<TermDataSmryModel> sysList)throws SQLException, DataAccessException;

	public String insertNonSoxUserActivityData(List<UserActivityModel> dataList) throws SQLException, DataAccessException;
	public List<String> getActiveUniqueIdsForNonSoxSystem(String systemNm) throws SQLException, DataAccessException;




}
