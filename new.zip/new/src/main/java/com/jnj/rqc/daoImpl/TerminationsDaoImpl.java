package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.TerminationsDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.terminations.models.AppStatusModel;
import com.jnj.rqc.terminations.models.TerminationModel;



/**
 * File    : <b>TerminationsDaoImpl.java</b>
 * @author : DChauras @Created : Jul 25, 2019 2:14:10 PM
 * Purpose : USER Termination Data
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class TerminationsDaoImpl extends BaseDao implements TerminationsDao {
	static final Logger log = LoggerFactory.getLogger(TerminationsDaoImpl.class);


	@Override
	public List<AppStatusModel> findTermUserData(String accName, String appName) throws SQLException, DataAccessException{
		StringBuilder sql = new StringBuilder();
		log.info("Checking USER_STAT_DATA  for accName: "+accName+" - SRC_SYS:"+appName);

		sql.append("SELECT DISTINCT b.WW_ID, a.USER_ID, a.DT_UPDATED as UPDATE_DT, a.SRC_SYS, a.EMP_ACTIVE as EMP_STATUS, ");
		sql.append("b.EMP_STAT_TXT as JJEDS_STATUS, b.JJEDS_LAST_CHGD_TMS as JJEDS_CHANGE_TMS, b.TERMNN_DT AS JJEDS_TERM_DT ");
		sql.append("FROM SOD_EXTR.USER_STAT_DATA a, SOD_EXTR.JJEDS_EMP_EXTR_MV b ");
		if("ICS".equals(appName)) {
			 sql.append("WHERE a.USER_ID = b.WW_ID ");
			 sql.append("AND a.USER_ID = '"+accName+"' ");
		 }else{
			 if (accName.matches("[0-9]+")){
				 sql.append("WHERE a.USER_ID = b.WW_ID ");
				 sql.append("AND a.USER_ID = '"+accName+"' ");
			 }else {
				 sql.append("WHERE a.USER_ID = b.JNJ_MSFT_USRNM_TXT ");
				 sql.append("AND Upper(a.USER_ID) = '"+accName+"' ");
			 }
		}
		if(appName.contains("WMS") || appName.contains("HCSOP50") || appName.contains("HCSOP53")) {
			sql.append("AND a.SRC_SYS in( 'WMS', 'WMSMLC', 'WMSSDC') ");
		}else if(appName.contains("HCSOP08")){
			sql.append("AND a.SRC_SYS in ('CARSIS') ");
		}else if(appName.contains("HCSOP44")){
			sql.append("AND a.SRC_SYS in ('CARSMA') ");
		}
		else {
			sql.append("AND a.SRC_SYS = '"+appName+"' ");
		}
		sql.append( "ORDER BY USER_ID ASC, DT_UPDATED DESC ");
		//PROD : List<AppStatusModel> appStat = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<AppStatusModel>(AppStatusModel.class));
		List<AppStatusModel> appStat = getJdbcTemplate0459().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AppStatusModel.class));
		return appStat;
	}

	/* (non-Javadoc)
	 * @see com.jnj.rqc.dao.TerminationsDao#findTermUserData(java.lang.String, java.lang.String)
	 */
	@Override
	public List<AppStatusModel> findTermNagsData(String accName, String appName) throws SQLException, DataAccessException{
		StringBuilder sql = new StringBuilder();
		log.info("Checking NAGS_DATA for accName: "+accName+" - SRC_SYS:"+appName);
		sql.append("SELECT DISTINCT a.WWID, a.USERID, a.UPDATE_DT, a.SRC_SYS, a.EMP_STATUS, b.EMP_STAT_TXT as JJEDS_STATUS, b.JJEDS_LAST_CHGD_TMS as JJEDS_CHANGE_TMS, b.TERMNN_DT AS JJEDS_TERM_DT  ");
		sql.append("FROM SOD_EXTR.NAGS_DATA a, SOD_EXTR.JJEDS_EMP_EXTR_MV b ");
		if("ICS".equals(appName)) {
			 sql.append("WHERE a.WWID = b.WW_ID ");
			 sql.append("AND a.WWID = '"+accName+"' ");
		 }else {
			 if(accName.matches("[0-9]+")){
				 sql.append("WHERE a.WWID = b.WW_ID ");
				 sql.append("AND a.WWID = '"+accName+"' ");
			 }else {
				 sql.append("WHERE a.USERID = b.JNJ_MSFT_USRNM_TXT ");
				 sql.append( "AND Upper(a.USERID) = '"+accName+"' ");
			 }
		 }
		if(appName.contains("HCSOP50") || appName.contains("HCSOP53")) {
			sql.append("AND a.SRC_SYS in( 'WMS', 'WMSMLC', 'WMSSDC') ");
		}else if(appName.contains("HCSOP08")){
			sql.append("AND a.SRC_SYS in ('CARSIS') ");
		}else if(appName.contains("HCSOP44")){
			sql.append("AND a.SRC_SYS in ('CARSMA') ");
		}
		else {
			sql.append("AND a.SRC_SYS = '"+appName+"' ");
		}
		sql.append( "ORDER BY WWID ASC, UPDATE_DT DESC ");

		List<AppStatusModel> appStat = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AppStatusModel.class));

		return appStat;
	}

	@Override
	public List<AppStatusModel> findTermMissingUserData(String accName, String appName) throws SQLException, DataAccessException{
		StringBuilder sql = new StringBuilder();
		log.info("Checking MISSING_USER_STAT_DATA  for accName: "+accName+" - SRC_SYS:"+appName);
		String srcSys = (appName.contains(":")) ? appName.split(":")[1]:appName;
		srcSys = srcSys.trim();

		sql.append("SELECT DISTINCT b.WW_ID, a.USER_ID, a.DT_UPDATED as UPDATE_DT, a.SRC_SYS, a.EMP_ACTIVE as EMP_STATUS, ");
		sql.append("b.EMP_STAT_TXT as JJEDS_STATUS, b.JJEDS_LAST_CHGD_TMS as JJEDS_CHANGE_TMS, b.TERMNN_DT AS JJEDS_TERM_DT ");
		sql.append("FROM SOD_EXTR.MISSING_USER_STAT_DATA a, SOD_EXTR.JJEDS_EMP_EXTR_MV b ");
		if("ICS".equals(srcSys)) {
			 sql.append("WHERE a.USER_ID = b.WW_ID ");
			 sql.append("AND a.USER_ID = '"+accName+"' ");
		 }else{
			 if (accName.matches("[0-9]+")){
				 sql.append("WHERE a.USER_ID = b.WW_ID ");
				 sql.append("AND a.USER_ID = '"+accName+"' ");
			 }else {
				 sql.append("WHERE a.USER_ID = b.JNJ_MSFT_USRNM_TXT ");
				 sql.append("AND Upper(a.USER_ID) = '"+accName+"' ");
			 }
		}
		if(appName.contains("WMS") || appName.contains("HCSOP50") || appName.contains("HCSOP53")) {
			sql.append("AND a.SRC_SYS in( 'WMS', 'WMSMLC', 'WMSSDC') ");
		}else if(appName.contains("HCSOP08")){
			sql.append("AND a.SRC_SYS in ('CARSIS') ");
		}else if(appName.contains("HCSOP44")){
			sql.append("AND a.SRC_SYS in ('CARSMA') ");
		}else {
			sql.append("AND a.SRC_SYS = '"+srcSys+"' ");
		}
		sql.append( "ORDER BY USER_ID ASC, DT_UPDATED DESC ");
		//PROD : List<AppStatusModel> appStat = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<AppStatusModel>(AppStatusModel.class));
		List<AppStatusModel> appStat = getJdbcTemplate0459().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AppStatusModel.class));
		return appStat;
	}


	@Override
	public List<AppStatusModel> getUserJJEDSData(String accName, String appNm) throws SQLException, DataAccessException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT WW_ID AS WWID, JNJ_MSFT_USRNM_TXT AS USER_ID, EMP_STAT_TXT as JJEDS_STATUS, ");
		sql.append("JJEDS_LAST_CHGD_TMS as JJEDS_CHANGE_TMS, TERMNN_DT AS JJEDS_TERM_DT  FROM SOD_EXTR.JJEDS_EMP_EXTR_MV ");
		if(accName.matches("[0-9]+")){
			 sql.append("WHERE WW_ID = '"+accName+"'");
		}else {
			sql.append("WHERE JNJ_MSFT_USRNM_TXT ='"+accName+"'");
		}
		List<AppStatusModel> appStat = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AppStatusModel.class));
		return appStat;
	 }


	@Override
	public String insertMissingData(TerminationModel termMdl) throws SQLException, DataAccessException{
		String sql = "INSERT INTO SOD_EXTR.MISSING_USER_STAT_DATA ( USER_ID, FIRST_NAME, LAST_NAME, ROLE, SRC_SYS, EMP_ACTIVE, "
					+"DT_UPDATED, DT_ADDED, COMMENTS, ADD_BY_USER ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		String resource = (termMdl.getResourceName() == null)? "" : termMdl.getResourceName().trim();
		String srcSys = (resource.contains(":")) ? resource.split(":")[1]:resource;
		log.info("Checking USER_STAT_DATA  for accName: "+termMdl.getAccName()+" - SRC_SYS : "+srcSys);
		String fname = termMdl.getAccOwner().split(",")[1];
		String lname = termMdl.getAccOwner().split(",")[0];

		int result = getJdbcTemplate0459().update(sql, new Object[] {termMdl.getAccName(), fname.toUpperCase(), lname.toUpperCase(), "", srcSys.trim(), "R", new Date(), new Date(), "SYSTEM DECOMISSIONED HCSOP62", "DCHAURAS"});
		return (result > 0 ? "SUCCESS" : "FAILED");
	}



	/*public List<RQCTktData> queryRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException {
		String sql = " SELECT a.TICKT_NO as tktNo, a.CLI_ID as wwid"+
				//+ ", b.CLI_LAST_NM, b.CLI_FIRST_NM, a.REQST_DT, a.REQST_TYP, a.STAT_CD " +
				" , c.EVNT_DESCN as evtDesc" +   //", c.SCHDD_DT, c.APRVL_DT " +
				" FROM TIPTOP.TICKT_REQSTOR a, TIPTOP.CLI_INFO_VW b, TIPTOP.V_TICKET_DETAIL_INFO c " +
				" where a.TICKT_NO = b.TICKT_NO and a.CLI_ID = b.CLI_ID " +
				" AND a.TICKT_NO = c.TICKT_NO  AND a.REQST_DT >= to_date('"+Utility.backDate3M(MON, YEAR)+"', 'MM/DD/YYYY') " +
				" ORDER BY a.TICKT_NO DESC ";
		final List<RQCTktData> tktdata = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<RQCTktData>(RQCTktData.class));
		return tktdata;
	}
*/


	/*public Map<String, String> getRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException{
		Map<String, String> tableData = new HashMap<String, String>();
		List<RQCTktData> dbData = queryRQCTktDetails(MON, YEAR);
		dbData.forEach(tktData ->{
			int tktNo 		= tktData.getTktNo();
			String wwid 	= tktData.getWwid().trim();
			String evtDesc = tktData.getEvtDesc().trim().toUpperCase();
			String keyStr = evtDesc+"~"+wwid;

			if(!tableData.containsKey(keyStr)) {//Only read the latest TICKET Number
				tableData.put(keyStr, tktNo+"");
			}
		});

		return tableData;

	}*/



}


