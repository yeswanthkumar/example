package com.jnj.rqc.service;

import java.util.Map;

import com.jnj.rqc.reportmodels.ReportDataModel;

public interface TktInfoService {
	public Map<String, ReportDataModel> getUserTktInfo(String[] wwid);
	public Map<String, ReportDataModel> searchTktInfo(String tktNo);
	public void getRoleDetails(Map<String, ReportDataModel> repDataMap, String appName);
	//public String createRQCCsvReport(String fileName, List<ReportDataModel> repDataList);


}
