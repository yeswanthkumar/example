package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.conflictModel.TMUploadDataMdl;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.models.UserTerminationReportModel;
import com.jnj.rqc.termdata.models.TermDataSmryModel;

public interface UserRoleActivityService {

	public Map<String, List<UserActivityModel>> getUserData(List<TermDataSmryModel> sysList);
	public Map<String, String> generateTermExcelFiles(Map<String, List<UserActivityModel>>userData, String fileDir, HttpServletRequest request);
	public void insertUserData(List<UserActivityModel> dataList, String system);
	public int clearUserActCache();
	public Map<String, List<UserTerminationReportModel>> processTerminationReport(Map<String, List<UserActivityModel>> userData);
	public Map<String, String> generateTermReportFiles(Map<String, List<UserTerminationReportModel>> userData, String fileDir, HttpServletRequest request);

	//NON-SOX
	public Map<String, List<UserActivityModel>> getNonSoxUserData(List<TermDataSmryModel> sysList);
	public int clearNonSoxUserActCache();
	public void insertNonSoxUserData(List<UserActivityModel> dataList, String system);
	public Map<String, List<UserTerminationReportModel>> processNonSoxTerminationReport(Map<String, List<UserActivityModel>> userData);
	public Map<String, String> generateNonSoxTermReportFiles(Map<String, List<UserTerminationReportModel>> userData, String fileDir, HttpServletRequest request);
	public Map<String, String> generateNonSoxTermExcelFiles(Map<String, List<UserActivityModel>> userData, String fileDir,	HttpServletRequest request);
	public List<TMUploadDataMdl> readTMExcel(String path, HttpServletRequest request);



}
