package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.HanaDBRiskModel;
import com.jnj.rqc.conflictModel.HanaRole2SodModel;
import com.jnj.rqc.conflictModel.HanaUser2SodModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.service.HANADataService;
import com.jnj.rqc.service.JDEExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

@Controller
public class HANADataController {
	static final Logger log = LoggerFactory.getLogger(HANADataController.class);

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	HANADataService hANADataService;
	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;
	@Autowired
	JDEExtrDataService jDEExtrDataService;

	@Autowired
	EmailUtil emailUtil;

	String BASE_SYSTEM = "SYSTEMS";

	//Start User to Role
	@GetMapping("/loadHanaUser2RolePage")
	public String loadHanaUser2RolePage(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("riskLvls", riskLvls );
    	model.addAttribute("sysNames", sysNames );
    	return "sapextraction/hanaextruser2rolepage";
    }


	@PostMapping("/loadHanaUser2RoleData")
    public String loadHanaUser2RoleData(@RequestParam("systems") String systems, @RequestParam("envNames") String envNames, @RequestParam("systemId") String systemId, Model model, HttpServletRequest request) {
    	log.info("systems: "+systems+" envNames: "+envNames+" systemId: "+systemId);
    	String sysParam = systems;
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("sysNames", sysNames );
    	model.addAttribute("sysParam", sysParam );

    	String selEnvs = envNames;
    	List<String> environmentNames = Utility.loadHANAProperty(sysParam);
    	model.addAttribute("environmentNames", environmentNames );
    	model.addAttribute("selEnvs", selEnvs );

    	String sysIdParam = systemId;
    	List<String> systemIds = Utility.loadHANAProperty(sysParam+"_"+selEnvs);
    	model.addAttribute("sysIdNames", systemIds );
    	model.addAttribute("sysIdParam", sysIdParam );

    	if("0".equals(systems) || "0".equals(envNames) || "0".equals(systemId)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: System/Environment/System ID.");
            return "sapextraction/hanaextruser2rolepage";
    	}
    	String templSysParam = sysParam+"_"+selEnvs+"_"+systemId;
    	String[]sysArr = templSysParam.split("_");
    	log.info("TemplateName: "+templSysParam);
    	List<SapGaaUser2RoleModel> user2RoleData = hANADataService.readHanaUserGrantDispData(templSysParam, "I");

    	//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();
    	for(SapGaaUser2RoleModel mdl:user2RoleData) {
    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
    				activeTrfData.add(mdl);
    			}
    		}else {
    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
    				incompleteData.add(mdl);
    			}
    		}
    	}
    	if(!incompleteData.isEmpty()) {
    		for(SapGaaUser2RoleModel mdl : incompleteData) {
    			UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getUserId(), 0);
    			if(srchUsr != null) {
    				mdl.setUserStatus(srchUsr.getEmpStatTxt());
    			}else {
    				mdl.setUserStatus("NO DATA FOUND");
    			}
    		}
    		request.getSession().setAttribute("INVALID_HANA_USER2ROLE", incompleteData);
    		log.info("Total USER-ROLE(INCOMPLETE DATA) : "+incompleteData.size());
    	}

    	request.getSession().setAttribute("HANA_USER2ROLE", activeTrfData);
    	request.getSession().setAttribute("PLATFORM", sysArr[1]);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	model.addAttribute("HANA_USER2ROLE", activeTrfData);

    	//TODO - Added flag for export
    	model.addAttribute("EXPORT_ALLOWED", "Y");
    	//END flag
    	String msg  = "Status: Total USER TO ROLE Data: "+ ((user2RoleData == null || user2RoleData.isEmpty() ) ?  "0": user2RoleData.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/hanaextruser2rolepage";
    }

	@ResponseBody
    @GetMapping("/downHanaUser2RoleExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downJdeUser2RoleExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading JDE User to Role Excel ");
		String fileNm ="UsertoRole_Review_"+request.getSession().getAttribute("PLATFORM");
		String invldFlNm ="INCOMPLETE_UsertoRole_Review_"+request.getSession().getAttribute("PLATFORM");
		List<SapGaaUser2RoleModel> actTrfData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("HANA_USER2ROLE");
		List<SapGaaUser2RoleModel> incompleteData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("INVALID_HANA_USER2ROLE");
		String filePath = jDEExtrDataService.writeSapGaaUser2RoleCSV(actTrfData, fileNm);
		String invldFlPath = jDEExtrDataService.writeSapGaaUser2RoleCSV(incompleteData, invldFlNm);

		String zipfilePath = Utility.createZip(Arrays.asList(filePath,invldFlPath), Constants.REPO_OUT_LOC+fileNm+"_"+Utility.fmtMDY(new Date())+".zip");
    	File fl = new File(zipfilePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	 @SuppressWarnings("all")
	 @ResponseBody
	 @GetMapping("/exportHANAUser2RoleData")
	 public ResponseEntity<InputStreamResource> exportHANAUser2RoleData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		String template = (String) request.getSession().getAttribute("TEMPLATE");
		log.info("Export Hana User to Role Data for: "+template);
		StringBuilder actions= new StringBuilder();
		actions.append("Export Hana User to Role Data for:"+template+"\n");
		actions.append("Checking Export Status\n");
		String[] tmplArr=template.split("_");
		synchronized (tmplArr) {
			int count = sAPExtrRegionWiseService.getExistingScheduleCount(tmplArr[0], "E", "U");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
			if(count > 0) {
				actions.append("User to Role Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
			}else {
				UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
				List<SapGaaUser2RoleModel> userAccessData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("HANA_USER2ROLE");
				actions.append("Total Records to be replaced : "+userAccessData.size()+" \n Clearing records from Table.\n");
				int delRec = sAPExtrRegionWiseService.deleteUser2RoleTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
				actions.append("Total records deleted : "+delRec+"\n\n");
				actions.append("Inserting "+userAccessData.size()+" Records\n");
				int insRecords = jDEExtrDataService.insertUser2RoleTransactions(userAccessData, template, curUser.getJnjMsftUsrnmTxt());
				actions.append("Total Records inserted : "+insRecords+"\n" );
				try {
					//Building Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					sumMdl.setRegion(tmplArr[0]);
					sumMdl.setPlatform(tmplArr[1]);
					sumMdl.setEnvironment(tmplArr[2]);
					sumMdl.setSystem(tmplArr[3]);
					sumMdl.setCreatedRecCount(insRecords);
					sumMdl.setCreatedDt(new Date());
					sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
					sumMdl.setCollStatus("C");
					actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
					sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
					actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
				} catch (Exception e) {
					log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
				}
			}
		}
		String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
		String filePath = jDEExtrDataService.writeLogData(actions, fileNm);
  	File fl = new File(filePath);
  	log.info("Download File name:"+fl.getName());
  	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
  	return ResponseEntity.ok()
  		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
      	.contentType(MediaType.TEXT_PLAIN)
      	.contentLength(fl.length())
      	.body(resource);
  }

    //START - TRansfer Control

	@GetMapping("/loadHanaTrfControl")
	public String loadHanaTrfControl(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("riskLvls", riskLvls );
    	model.addAttribute("sysNames", sysNames );
    	return "sapextraction/hanaextrtrfcontrolpage";
    }


	@PostMapping("/loadHanaTrfControlData")
    public String loadHanaTrfControlData(@RequestParam("systems") String systems, @RequestParam("envNames") String envNames, @RequestParam("systemId") String systemId, Model model, HttpServletRequest request) {
    	log.info("systems: "+systems+" envNames: "+envNames+" systemId: "+systemId);
    	String sysParam = systems;
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("sysNames", sysNames );
    	model.addAttribute("sysParam", sysParam );

    	String selEnvs = envNames;
    	List<String> environmentNames = Utility.loadHANAProperty(sysParam);
    	model.addAttribute("environmentNames", environmentNames );
    	model.addAttribute("selEnvs", selEnvs );

    	String sysIdParam = systemId;
    	List<String> systemIds = Utility.loadHANAProperty(sysParam+"_"+selEnvs);
    	model.addAttribute("sysIdNames", systemIds );
    	model.addAttribute("sysIdParam", sysIdParam );

    	if("0".equals(systems) || "0".equals(envNames) || "0".equals(systemId)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: System/Environment/System ID.");
            return "sapextraction/hanaextrtrfcontrolpage";
    	}
    	String templSysParam = sysParam+"_"+selEnvs+"_"+systemId;
    	String[]sysArr = templSysParam.split("_");
    	log.info("TemplateName: "+templSysParam);
       	List<SAPUserAccessModel> userAccessData = hANADataService.readUserTrfContrlData(templSysParam);
    	request.getSession().setAttribute("HANA_USER_ACCESSDATA", userAccessData);
    	request.getSession().setAttribute("PLATFORM", sysArr[1]);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	model.addAttribute("HANA_USER_ACCESSDATA", userAccessData);

    	//TODO - Added flag for export
    	model.addAttribute("EXPORT_ALLOWED", "Y");
    	//END flag
    	String msg  = "Status: Total USER-ACCESS Data: "+ ((userAccessData == null || userAccessData.isEmpty() ) ?  "0": userAccessData.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/hanaextrtrfcontrolpage";
    }

	@ResponseBody
    @GetMapping("/downHanaTrnsCntrlExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downHanaTrnsCntrlExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading HANA Transfer Control Excel ");
		String fileNm ="Career_Change_"+request.getSession().getAttribute("PLATFORM");
		List<SAPUserAccessModel> userAccessData = (List<SAPUserAccessModel>)request.getSession().getAttribute("HANA_USER_ACCESSDATA");
		String filePath = hANADataService.writeJdeUserAccessCSV(userAccessData, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	 @SuppressWarnings("all")
	 @ResponseBody
	 @GetMapping("/exportHANAIndiSystemTrfData")
	 public ResponseEntity<InputStreamResource> exportHANAIndiSystemTrfData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		String template = (String) request.getSession().getAttribute("TEMPLATE");
		log.info("Export Transfer Control Data for: "+template);
		StringBuilder actions= new StringBuilder();
		actions.append("Export Transfer Control Data for:"+template+"\n");
		actions.append("Checking Export Status\n");
		String[] tmplArr=template.split("_");
		synchronized (tmplArr) {
			int count = sAPExtrRegionWiseService.getExistingScheduleCount(tmplArr[0], "E", "T");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
			if(count > 0) {
				actions.append("Transfer Control Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
			}else {
				UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
				List<SAPUserAccessModel> userAccessData = (List<SAPUserAccessModel>)request.getSession().getAttribute("HANA_USER_ACCESSDATA");
				actions.append("Total Records to be replaced : "+userAccessData.size()+" \n Clearing records from Table.\n");
				int delRec = sAPExtrRegionWiseService.deleteTrfTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
				actions.append("Total records deleted : "+delRec+"\n\n");
				actions.append("Inserting "+userAccessData.size()+" Records\n");
				int insRecords = jDEExtrDataService.insertTransferTransactions(userAccessData, template, curUser.getJnjMsftUsrnmTxt());
				actions.append("Total Records inserted : "+insRecords+"\n" );
				try {
					//Building Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					sumMdl.setRegion(tmplArr[0]);
					sumMdl.setPlatform(tmplArr[1]);
					sumMdl.setEnvironment(tmplArr[2]);
					sumMdl.setSystem(tmplArr[3]);
					sumMdl.setCreatedRecCount(insRecords);
					sumMdl.setCreatedDt(new Date());
					sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
					sumMdl.setCollStatus("C");
					actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
					sAPExtrRegionWiseDao.saveTrfDataSummary(sumMdl);
					actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
				} catch (Exception e) {
					log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
				}
			}
		}
		String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
		String filePath = jDEExtrDataService.writeLogData(actions, fileNm);
   	File fl = new File(filePath);
   	log.info("Download File name:"+fl.getName());
   	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
   	return ResponseEntity.ok()
   		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
       	.contentType(MediaType.TEXT_PLAIN)
       	.contentLength(fl.length())
       	.body(resource);
   }




	//END - Transfer Control






	@GetMapping("/loadHanaUserToSODPage")
    public String loadHanaUserToSODPage(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("riskLvls", riskLvls );
    	model.addAttribute("sysNames", sysNames );
    	return "csi/hanaUsertoSod";
    }

    @PostMapping("/loadHanaUserToSODPage")
    public String loadHANAUserToSOD(@RequestParam("systems") String systems, @RequestParam("envNames") String envNames, @RequestParam("systemId") String systemId, @RequestParam("newRoles") String newRoles,
    		@RequestParam("empId") String empId, @RequestParam("riskLvl") String riskLvl, Model model, HttpServletRequest request) {
    	log.info("systems: "+systems+" envNames: "+envNames+" systemId: "+systemId+" empId Recd: "+empId+"  Risk :"+riskLvl+" newRoles: "+newRoles);
    	String sysParam = systems;
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("sysNames", sysNames );
    	model.addAttribute("sysParam", sysParam );

    	String selEnvs = envNames;
    	List<String> environmentNames = Utility.loadHANAProperty(sysParam);
    	model.addAttribute("environmentNames", environmentNames );
    	model.addAttribute("selEnvs", selEnvs );

    	String sysIdParam = systemId;
    	List<String> systemIds = Utility.loadHANAProperty(sysParam+"_"+selEnvs);
    	model.addAttribute("sysIdNames", systemIds );
    	model.addAttribute("sysIdParam", sysIdParam );

    	if("0".equals(systems) || "0".equals(envNames) || "0".equals(systemId)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: System/Environment/System ID.");
            return "csi/hanaUsertoSod";
    	}
    	String empIdParam = empId;
    	model.addAttribute("empIdParam", empIdParam);

    	String rskNmParam = riskLvl;
    	model.addAttribute("rskNmParam", rskNmParam );
    	List<String> riskLvls = Utility.loadRiskLevel();
    	model.addAttribute("riskLvls", riskLvls );

    	String newRolesParam = newRoles;
    	model.addAttribute("newRolesParam", newRolesParam );

    	if(!Utility.isEmpty(newRolesParam) && Utility.isEmpty(empId) ) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Please enter WWID ID/User ID to Check Sod Conflicts");
            return "csi/hanaUsertoSod";
    	}

    	String templSysParam = sysParam+"_"+selEnvs+"_"+systemId;
    	log.info("TemplateName: "+templSysParam);

    	Map<String, List<HanaUser2SodModel>> usr2SodMap = hANADataService.readHanaUserData(empId, riskLvl, templSysParam, newRoles);
    	request.getSession().setAttribute("USER2SOD", usr2SodMap);
    	List<HanaUser2SodModel> user2SodList = usr2SodMap.get("USER2SODLIST");
    	model.addAttribute("HANAUSER2SOD", user2SodList);
    	List<HanaUser2SodModel> newRolesSodList =  usr2SodMap.get("NEWROLESUSER2SODLIST");
    	if(newRolesSodList != null) {
    		model.addAttribute("NEWROLESHANAUSER2SOD", newRolesSodList);
    		String msg1  = "Status: Total SOD Conflicts with NEW-ROLE : "+ ((newRolesSodList == null || newRolesSodList.isEmpty() ) ?  "0": newRolesSodList.size()+"");
    		model.addAttribute("success1", msg1);
    	}
    	String msg  = "Status: Total USER-SOD Conflicts: "+ ((user2SodList == null || user2SodList.isEmpty() ) ?  "0": user2SodList.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "csi/hanaUsertoSod";
    }



	@ResponseBody
    @GetMapping("/downHanaUser2SodExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downHANAUser2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download HANAUser2SodExcel ");
		String fileNm ="User2Sod";
		Map<String, List<HanaUser2SodModel>> hUsr2SodMap = (Map<String, List<HanaUser2SodModel>>)request.getSession().getAttribute("USER2SOD");
		List<HanaUser2SodModel>hUsr2SodLst = hUsr2SodMap.get("USER2SODLIST");
		String filePath = hANADataService.writeHanaUser2SodCsvReport(hUsr2SodLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downNewHanaUser2SodExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downNewRolesHANAUser2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading download HANAUser2SodExcel ");
		String fileNm ="User2SodNewRoleConflicts";
		Map<String, List<HanaUser2SodModel>> hUsr2SodMap = (Map<String, List<HanaUser2SodModel>>)request.getSession().getAttribute("USER2SOD");
		List<HanaUser2SodModel>hUsr2SodLst = hUsr2SodMap.get("NEWROLESUSER2SODLIST");
		String filePath = hANADataService.writeHanaUser2SodCsvReport(hUsr2SodLst, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@GetMapping("/loadHanaRolesToSODPage")
    public String loadHanaRoles2SODPage(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
    	model.addAttribute("sysNames", sysNames );
    	model.addAttribute("riskLvls", riskLvls );
		return "csi/hanaRoles2Sod";
    }


	 @PostMapping("/loadHanaRolesToSODPage")
	    public String loadHANARoles2SODData(@RequestParam("systems") String systems, @RequestParam("envNames") String envNames, @RequestParam("systemId") String systemId,
	    		@RequestParam("roleName") String roleName, @RequestParam("riskLvl") String riskLvl, Model model, HttpServletRequest request) {
	    	log.info("systems: "+systems+" envNames: "+envNames+" systemId: "+systemId+"Role Names Recd: "+roleName+" riskLvl: "+riskLvl);

	    	String sysParam = systems;
	    	List<String> sysNames = Utility.loadHANAProperty(BASE_SYSTEM);
	    	model.addAttribute("sysNames", sysNames );
	    	model.addAttribute("sysParam", sysParam );

	    	String selEnvs = envNames;
	    	List<String> environmentNames = Utility.loadHANAProperty(sysParam);
	    	model.addAttribute("environmentNames", environmentNames );
	    	model.addAttribute("selEnvs", selEnvs );

	    	String sysIdParam = systemId;
	    	List<String> systemIds = Utility.loadHANAProperty(sysParam+"_"+selEnvs);
	    	model.addAttribute("sysIdNames", systemIds );
	    	model.addAttribute("sysIdParam", sysIdParam );

	    	String roleNameParam = roleName;
	    	String rskNmParam = riskLvl;
	    	String templSysParam = sysParam+"_"+selEnvs+"_"+systemId;
	    	log.info("TemplateName: "+templSysParam);
	    	List<HanaRole2SodModel> role2Sod = hANADataService.readHanaRolesData(roleName, riskLvl, templSysParam);
	    	request.getSession().setAttribute("HANAROLE2SOD", role2Sod);
	    	model.addAttribute("HANAROLE2SOD", role2Sod);
	    	List<String> riskLvls = Utility.loadRiskLevel();
	    	model.addAttribute("riskLvls", riskLvls );
	    	model.addAttribute("roleNameParam", roleNameParam);
	    	model.addAttribute("rskNmParam", rskNmParam);
	    	String msg  = "Status: Total ROLE-SOD Conflicts: "+ ((role2Sod == null || role2Sod.isEmpty() ) ?  "0": role2Sod.size()+"");
	    	model.addAttribute("message", "True");
	    	model.addAttribute("success", msg);
	    	return "csi/hanaRoles2Sod";
	    }


	 @ResponseBody
	 @GetMapping("/downHanaRole2SodExcel")
	 @SuppressWarnings("all")
	 public ResponseEntity<InputStreamResource> downHANARole2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		 log.info("Downloading download HANARole2SodExcel ");
		 String fileNm ="Role2Sod";
		 List<HanaRole2SodModel> hRle2SodLst = (List<HanaRole2SodModel>)request.getSession().getAttribute("HANAROLE2SOD");
		 String filePath = hANADataService.writeHanaRole2SodCsvReport(hRle2SodLst, fileNm);
		 File fl = new File(filePath);
		 log.info("Download File name:"+fl.getName());
		 InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		 return ResponseEntity.ok()
	    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	        	.contentType(MediaType.TEXT_PLAIN)
	        	.contentLength(fl.length())
	        	.body(resource);
	 }

   @PostMapping("/getHanaEnvironmentData")
    public ResponseEntity<TableRespDto> getHanaEnvironmentData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Property name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = hANADataService.getEnvData(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping("/loadHanaConflictMatrix")
    public String loadCSIUserToSOD(Model model, HttpServletRequest request) {
    	log.info("Loading HANA Conflict Matrix");
    	Map<String, HanaDBRiskModel> dbRiskMap = null;
		if(Utility.getCache(Constants.HANA_DB_RISK) == null) {
			dbRiskMap = hANADataService.getHanaDBRiskData("");
			Utility.setCache(Constants.HANA_DB_RISK, dbRiskMap);
		}else {
			dbRiskMap = (Map<String, HanaDBRiskModel>)Utility.getCache(Constants.HANA_DB_RISK);
		}
    	model.addAttribute("HANACONFMATRIX", dbRiskMap.values());
    	model.addAttribute("message", "True");
		model.addAttribute("success" , "Total Records in DB Risk Map: "+((dbRiskMap.values()==null || dbRiskMap.values().isEmpty())? "0":dbRiskMap.values().size()+""));
    	return "hana/hanaConflictMatrix";
    }

    @PostMapping("/loadHanaConflictMatrix")
    public String loadCSIUserToSODPost(Model model, HttpServletRequest request) {
    	return loadCSIUserToSOD(model, request);
    }



    @ResponseBody
    @GetMapping("/downHanaConflictExcel")
    @SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downHANAConflictExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Downloading download HANA Conflict Matrix Excel ");
    	String fileNm ="HanaConflictMatrix";
    	Map<String, HanaDBRiskModel> hConfMatric = (Map<String, HanaDBRiskModel>)Utility.getCache(Constants.HANA_DB_RISK);
    	String filePath = hANADataService.writeHanaConflictMatrixCsvReport(new ArrayList<>(hConfMatric.values()), fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	        .contentType(MediaType.TEXT_PLAIN)
	        .contentLength(fl.length())
	        .body(resource);
	 }





	private String getLatestFile(String dirPath) {
		File folder = new File(dirPath);
    	File[] files = folder.listFiles();
    	long modDt = 0;
    	String latestFile ="";
    	if(files != null && files.length > 0) {
    		for(File fl:files) {
        		long lstMdDt = fl.lastModified();
        		if(lstMdDt > modDt ) {
        			modDt = lstMdDt;
        			latestFile=fl.getName();
        		}
        	}
    	}
    	log.info("Selected Latest file :"+latestFile);
    	return latestFile;
	}



}
