package com.jnj.rqc.service;

import java.util.List;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;



/**
 * File    : <b>SAPExtrGaaDataService.java</b>
 * @author : DChauras @Created : May 10, 2021 11:32:52 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface SAPDialogUserDataService {
	public List<SapGaaUser2RoleModel> readDiagUserToRoleData(String templSysParam);
	public List<SapGaaUser2RoleModel> readDiagUserToRoleActData(String templSysParam);

	/*public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName);
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String> templSysParam);
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) ;
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);
	//Incomplete Data Email
	public void sendInvldDataEmail(String sysTemp, List<SapGaaUser2RoleModel> dataList);
	//GENESIS Transfer Control Report
	public Map<String, Map<String, List<SapUser2RoleReportMdl>>> getGenesisUser2RoleReportData();
	public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser);
	public Map<String, List<SapUser2RoleDeltaMdl>> getGenesisUser2RoleData(List<String> users);//Data For comparing Delta information
	public int checkDeltaRecord(SapUser2RoleDeltaMdl rec2Check);
	public List<SapU2RDeltaSummaryMdl> getUser2RoleSummaryDeltaData(String type);
	public String clearUser2RoleDelta();
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn);
	public String writeSapGaaUser2RoleXLS(List<SapGaaUser2RoleModel> data, String fileName, String sheetNm);
	public List<UserSearchModel> getUserListFromJJEDS(String userId, int active);
	*/
}
