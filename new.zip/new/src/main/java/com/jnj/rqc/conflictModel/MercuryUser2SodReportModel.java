package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MercuryUser2SodReportModel {
	private String sodConflict;
	private String confDesc;
	private String reasonCode;
	private String definition;
	private String expression;
	private String userId;
	private String isSuper;
	private String group;
	private String type;
	private String logicalSystem;
	private String qry1;
	private String qry1Name;
	private String qry1Desc;
	private String norm1;
	private String causingTCode1;
	private String qryTCode1;
	private String qry2;
	private String qry2Name;
	private String qry2Desc;
	private String norm2;
	private String causingTCode2;
	private String qryTCode2;
	//Additional fields to store user info
	private String userName;
	private String userStatus;
	private String role;
	private String apprListId;


	@Override
	public String toString() {
		return "MercuryUser2SodReportModel [sodConflict=" + sodConflict + ", confDesc=" + confDesc + ", reasonCode="
				+ reasonCode + ", definition=" + definition + ", expression=" + expression + ", userId=" + userId
				+ ", isSuper=" + isSuper + ", group=" + group + ", type=" + type + ", logicalSystem=" + logicalSystem
				+ ", qry1=" + qry1 + ", qry1Name=" + qry1Name + ", qry1Desc=" + qry1Desc + ", norm1=" + norm1
				+ ", causingTCode1=" + causingTCode1 + ", qryTCode1=" + qryTCode1 + ", qry2=" + qry2 + ", qry2Name="
				+ qry2Name + ", qry2Desc=" + qry2Desc + ", norm2=" + norm2 + ", causingTCode2=" + causingTCode2
				+ ", qryTCode2=" + qryTCode2 + ", userName=" + userName + ", userStatus=" + userStatus + ", role="
				+ role + ", apprListId=" + apprListId + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		MercuryUser2SodReportModel other = (MercuryUser2SodReportModel) obj;
		if (apprListId == null) {
			if (other.apprListId != null)
				return false;
		} else if (!apprListId.equals(other.apprListId))
			return false;
		if (causingTCode1 == null) {
			if (other.causingTCode1 != null)
				return false;
		} else if (!causingTCode1.equals(other.causingTCode1))
			return false;
		if (causingTCode2 == null) {
			if (other.causingTCode2 != null)
				return false;
		} else if (!causingTCode2.equals(other.causingTCode2))
			return false;
		if (confDesc == null) {
			if (other.confDesc != null)
				return false;
		} else if (!confDesc.equals(other.confDesc))
			return false;
		if (definition == null) {
			if (other.definition != null)
				return false;
		} else if (!definition.equals(other.definition))
			return false;
		if (expression == null) {
			if (other.expression != null)
				return false;
		} else if (!expression.equals(other.expression))
			return false;
		if (group == null) {
			if (other.group != null)
				return false;
		} else if (!group.equals(other.group))
			return false;
		if (isSuper == null) {
			if (other.isSuper != null)
				return false;
		} else if (!isSuper.equals(other.isSuper))
			return false;
		if (logicalSystem == null) {
			if (other.logicalSystem != null)
				return false;
		} else if (!logicalSystem.equals(other.logicalSystem))
			return false;
		if (norm1 == null) {
			if (other.norm1 != null)
				return false;
		} else if (!norm1.equals(other.norm1))
			return false;
		if (norm2 == null) {
			if (other.norm2 != null)
				return false;
		} else if (!norm2.equals(other.norm2))
			return false;
		if (qry1 == null) {
			if (other.qry1 != null)
				return false;
		} else if (!qry1.equals(other.qry1))
			return false;
		if (qry1Desc == null) {
			if (other.qry1Desc != null)
				return false;
		} else if (!qry1Desc.equals(other.qry1Desc))
			return false;
		if (qry1Name == null) {
			if (other.qry1Name != null)
				return false;
		} else if (!qry1Name.equals(other.qry1Name))
			return false;
		if (qry2 == null) {
			if (other.qry2 != null)
				return false;
		} else if (!qry2.equals(other.qry2))
			return false;
		if (qry2Desc == null) {
			if (other.qry2Desc != null)
				return false;
		} else if (!qry2Desc.equals(other.qry2Desc))
			return false;
		if (qry2Name == null) {
			if (other.qry2Name != null)
				return false;
		} else if (!qry2Name.equals(other.qry2Name))
			return false;
		if (qryTCode1 == null) {
			if (other.qryTCode1 != null)
				return false;
		} else if (!qryTCode1.equals(other.qryTCode1))
			return false;
		if (qryTCode2 == null) {
			if (other.qryTCode2 != null)
				return false;
		} else if (!qryTCode2.equals(other.qryTCode2))
			return false;
		if (reasonCode == null) {
			if (other.reasonCode != null)
				return false;
		} else if (!reasonCode.equals(other.reasonCode))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		if (sodConflict == null) {
			if (other.sodConflict != null)
				return false;
		} else if (!sodConflict.equals(other.sodConflict))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		if (userStatus == null) {
			if (other.userStatus != null)
				return false;
		} else if (!userStatus.equals(other.userStatus))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apprListId == null) ? 0 : apprListId.hashCode());
		result = prime * result + ((causingTCode1 == null) ? 0 : causingTCode1.hashCode());
		result = prime * result + ((causingTCode2 == null) ? 0 : causingTCode2.hashCode());
		result = prime * result + ((confDesc == null) ? 0 : confDesc.hashCode());
		result = prime * result + ((definition == null) ? 0 : definition.hashCode());
		result = prime * result + ((expression == null) ? 0 : expression.hashCode());
		result = prime * result + ((group == null) ? 0 : group.hashCode());
		result = prime * result + ((isSuper == null) ? 0 : isSuper.hashCode());
		result = prime * result + ((logicalSystem == null) ? 0 : logicalSystem.hashCode());
		result = prime * result + ((norm1 == null) ? 0 : norm1.hashCode());
		result = prime * result + ((norm2 == null) ? 0 : norm2.hashCode());
		result = prime * result + ((qry1 == null) ? 0 : qry1.hashCode());
		result = prime * result + ((qry1Desc == null) ? 0 : qry1Desc.hashCode());
		result = prime * result + ((qry1Name == null) ? 0 : qry1Name.hashCode());
		result = prime * result + ((qry2 == null) ? 0 : qry2.hashCode());
		result = prime * result + ((qry2Desc == null) ? 0 : qry2Desc.hashCode());
		result = prime * result + ((qry2Name == null) ? 0 : qry2Name.hashCode());
		result = prime * result + ((qryTCode1 == null) ? 0 : qryTCode1.hashCode());
		result = prime * result + ((qryTCode2 == null) ? 0 : qryTCode2.hashCode());
		result = prime * result + ((reasonCode == null) ? 0 : reasonCode.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		result = prime * result + ((sodConflict == null) ? 0 : sodConflict.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((userStatus == null) ? 0 : userStatus.hashCode());
		return result;
	}



}
