package com.jnj.rqc.useridentity.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GRCAdGrpResponse3 {
	private String requestId;
	private String requestNo;
	private String roleStatus;
	private String roleStatusType;
	private String roleStatusCount;
	private String requestReason;
	private long   lastUpdated;
	private int    roleCount;
	private String requestCreated;
	private String roleCountText;
	private String requestFor;
	private String createdByOrFor;
	private String stage;
	private String parentReqno;
	private String parentGuid;
	private String pendingWith;
	private String validFrom;
	private String validTo;
	private String reqtype;
	private String createdBy;
	private String createdByWwid;
}
