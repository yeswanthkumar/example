package com.jnj.rqc.mastermetadata.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.mastermetadata.controller.ConflictData;

@Repository
public class ConflictMatrixRepository extends BaseDao {
	static final Logger log = LoggerFactory.getLogger(ConflictMatrixRepository.class);
	public void insertMultipleRecords(List<ConflictData> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<ConflictData> batch = records.subList(i, endIndex);
	                insertBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertBatchAsync(List<ConflictData> masterList) {
		String insQry = "INSERT INTO ZUSER_CONFLICT_MATRIX (RISKID, RISKDESC, APP1, APPNAME1, POSV1, POSVNAME1, APP2, APPNAME2, POSV2, POSVNAME2, CONFLICT, RISK_LEVEL, MIT_ID, MIT_DESC, CREATEDON) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, masterList.get(i).getRISKID());
				ps.setString(2, masterList.get(i).getRISKDESC());
				ps.setString(3, masterList.get(i).getAPP1());
				ps.setString(4, masterList.get(i).getAPPNAME1());
				ps.setString(5, masterList.get(i).getPOSV1());
				ps.setString(6, masterList.get(i).getPOSVNAME1());
				ps.setString(7, masterList.get(i).getAPP2());
				ps.setString(8, masterList.get(i).getAPPNAME2());
				ps.setString(9, masterList.get(i).getPOSV2());
				ps.setString(10, masterList.get(i).getPOSVNAME2());
				ps.setString(11, masterList.get(i).getCONFLICT());
				ps.setString(12, masterList.get(i).getRISK_LEVEL());
				ps.setString(13, masterList.get(i).getMIT_ID());
				ps.setString(14, masterList.get(i).getMIT_DESC());
				ps.setDate(15, new java.sql.Date(masterList.get(i).getCREATEDON().getTime()));

			}
			@Override
			public int getBatchSize() {
				return masterList.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == masterList.size() ? "Success-"+masterList.size() : "Failed-"+(masterList.size() - status.length)));
	}
	public void deleteAllRows() {
		log.debug("enter into the method");
		try {
			String sql = "DELETE FROM ZUSER_CONFLICT_MATRIX";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
}
