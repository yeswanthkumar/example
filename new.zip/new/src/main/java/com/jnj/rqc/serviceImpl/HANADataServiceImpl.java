package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.HanaDBRiskModel;
import com.jnj.rqc.conflictModel.HanaRole2SodModel;
import com.jnj.rqc.conflictModel.HanaRoleUserPrivilegeMdl;
import com.jnj.rqc.conflictModel.HanaUser2SodModel;
import com.jnj.rqc.conflictModel.HanaUserGrantModel;
import com.jnj.rqc.conflictModel.HanaUserPrivilegeModel;
import com.jnj.rqc.conflictModel.HanaUserRoleModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.HANADataDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.HANADataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;



@Service
public class HANADataServiceImpl implements HANADataService{

	static final Logger log = LoggerFactory.getLogger(HANADataServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;

	@Autowired
	HANADataDao hANADataDao;
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;

	@Override
	public List<SAPUserAccessModel> readUserTrfContrlData(String templSysParam) {
		List<SAPUserAccessModel> allUserData = new ArrayList<>();
		try {
			List<SAPUserAccessModel> userLst = hANADataDao.getUserTrfContrlData(templSysParam);
			log.info("Total Data for System: "+templSysParam+"  :"+userLst.size());
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			for(SAPUserAccessModel usrMdl:userLst) {
				usrMdl.setWwid(usrMdl.getWwid().trim());
				usrMdl.setNtId(usrMdl.getNtId().trim());
				if(!(usrMdl.getWwid().length() > 16 || usrMdl.getWwid().length() <= 1 || usrMdl.getWwid().contains("SYS") || usrMdl.getWwid().contains("_"))) {

					usrMdl.setSapPlatform(Utility.getSapClientName(systemInfo[1]));
					usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
					usrMdl.setDescription("Access has been granted in the "+Utility.getSapClientName(systemInfo[3])+"-"+systemInfo[2]+" System application. If the user no longer needs access to this system then please select REVOKE");
					String pltInfo =Utility.getSapClientName(systemInfo[3]).equals(systemInfo[3])? "Access is Granted in "+systemInfo[3]:"Access is Granted in "+Utility.getSapClientName(systemInfo[3]) ;
					usrMdl.setDetails(pltInfo);
					usrMdl.setSapId(usrMdl.getNtId());
					if(!allUserData.contains(usrMdl)) {
						allUserData.add(usrMdl);
					}
				}
				//}
			}
			log.info("All User ROLE Data for "+templSysParam+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error reading transfer Control Data for System : "+templSysParam+"  MSG:"+e.getMessage(), e);
		}
		return allUserData;
	}




	@SuppressWarnings("all")
	@Override
	public Map<String, List<HanaUser2SodModel>> readHanaUserData(String empId, String riskLevel, String templSysParam, String newRoles){
		log.info("empId :"+empId);
		 Map<String, List<HanaUser2SodModel>> outputMap = new HashMap<>();
		List<HanaUser2SodModel> usr2SodLst = new LinkedList<>();
		List<HanaUser2SodModel> usr2SodLstNewRoles = new LinkedList<>();
		Map<String, List<HanaUserPrivilegeModel>> newRolePrivilegeMap = null;
		Map<String, List<HanaUserPrivilegeModel>> userDirectAssingmentPrivilegeMap = null;

		Map<String, HanaUserRoleModel> roleMap = readUserGrantData(templSysParam); //Reading User Privileges
		userDirectAssingmentPrivilegeMap = readUserDirectAssignmentData(templSysParam);

		if(!(null == newRoles || newRoles.isEmpty() || null == empId || empId.isEmpty())) {
			newRolePrivilegeMap = readNewRolesData(newRoles, templSysParam);
		}
		Map<String, HanaDBRiskModel> dbRiskMap = null;
		if(Utility.getCache(Constants.HANA_DB_RISK) == null) {
			dbRiskMap = getHanaDBRiskData("");
			Utility.setCache(Constants.HANA_DB_RISK, dbRiskMap);
		}else {
			dbRiskMap = (Map<String, HanaDBRiskModel>)Utility.getCache(Constants.HANA_DB_RISK);
		}

		if(empId == null || empId.length() <= 0) {//All USERS
			for (Map.Entry<String, HanaUserRoleModel> entry : roleMap.entrySet()) {
				String wwId = entry.getKey();
				HanaUserRoleModel rlMdl = entry.getValue();
				List<HanaUserPrivilegeModel> privList = readAllPrivileges(rlMdl);
				//START - Adding Direct Assignments of User
				if(null != userDirectAssingmentPrivilegeMap && !userDirectAssingmentPrivilegeMap.isEmpty() && userDirectAssingmentPrivilegeMap.get(wwId) != null) {
					privList.addAll(readAllPrivileges(userDirectAssingmentPrivilegeMap, wwId));
				}
				//END - Adding Direct Assignments of User
				usr2SodLst.addAll(getUserToSOD(wwId, privList, dbRiskMap)) ;
			}
		}else{
			String[] empArr = empId.split(",");
			for(String emp : empArr) {
				if(roleMap.get(emp) != null){
					HanaUserRoleModel rlMdl = roleMap.get(emp);
					log.info("rlMdl.empId: "+emp);
					List<HanaUserPrivilegeModel> privList = readAllPrivileges(rlMdl);
					//START - Adding Direct Assignments of User
					if(null != userDirectAssingmentPrivilegeMap && !userDirectAssingmentPrivilegeMap.isEmpty() && userDirectAssingmentPrivilegeMap.get(emp) != null) {
						privList.addAll(readAllPrivileges(userDirectAssingmentPrivilegeMap, emp));
					}
					//END - Adding Direct Assignments of User
					usr2SodLst.addAll(getUserToSOD(emp, privList, dbRiskMap));

					//Checking for NEW ROLES TO ADD for SOD CONFLICTS
					if(newRoles != null && newRoles.length() > 0) {
						usr2SodLstNewRoles.addAll(getUserToSOD(emp, readAllPrivileges(newRolePrivilegeMap, ""), dbRiskMap));
						for (Map.Entry<String, List<HanaUserPrivilegeModel>> rpEntry : newRolePrivilegeMap.entrySet()) {
							usr2SodLstNewRoles.addAll(getConflictsWithNewRoles(emp, rpEntry.getValue(), privList, dbRiskMap));
						}
						outputMap.put("NEWROLESUSER2SODLIST", usr2SodLstNewRoles);
					}

				}
			}
		}
		if(riskLevel !="0" && riskLevel.length() >1) {
			usr2SodLst = filterOnRiskLvl(riskLevel, usr2SodLst);
		}
		outputMap.put("USER2SODLIST", usr2SodLst);
		return outputMap;
	}


	private List<HanaUser2SodModel> filterOnRiskLvl(String riskLevel, List<HanaUser2SodModel>usr2SodLst){
		List<HanaUser2SodModel> lst=new LinkedList<>();
		for(HanaUser2SodModel mdl:usr2SodLst) {
			if(mdl.getRiskLevel().equals(riskLevel)) {
				lst.add(mdl);
			}
		}
		return lst;
	}

	@Override
	public List<SapGaaUser2RoleModel> readHanaUserGrantDispData(String templSysParam, String calledBy) {
		log.info("templSysParam :"+templSysParam);
		//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();

		List<SapGaaUser2RoleModel> userRoleData = readHanaUserGrantData(templSysParam, calledBy);

		if(userRoleData != null && !userRoleData.isEmpty()) {
			for(SapGaaUser2RoleModel mdl:userRoleData) {
	    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
	    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
	    				activeTrfData.add(mdl);
	    			}
	    		}else {
	    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
	    				//List<UserSearchModel> usrList= null;
	    				String usrId = mdl.getUserId();
	    				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getUserId(), 0);
	    				if(srchUsr != null) {
							mdl.setUserStatus(srchUsr.getEmpStatTxt());
						}else {
							mdl.setUserStatus("NO DATA FOUND");
						}
						incompleteData.add(mdl);
	    			}
	    		}
	    	}
		}

		if(incompleteData != null && !incompleteData.isEmpty()) {
			//sAPExtrGaaDataService.sendInvldDataEmail(templSysParam, incompleteData);
		}
		return activeTrfData;
	}



	@Override
	public List<SapGaaUser2RoleModel> readHanaUserGrantActData(String templSysParam) {
		log.info("templSysParam :"+templSysParam);
		//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();

		List<SapGaaUser2RoleModel> userRoleData = readHanaUserGrantData(templSysParam, "R");
		if(userRoleData != null && !userRoleData.isEmpty()) {
			//START -  SAVE ALL RAW DATA
			sAPExtrGaaDataService.saveUser2RoleAllRawData(userRoleData, templSysParam);
			//END -  SAVE ALL RAW DATA
			for(SapGaaUser2RoleModel mdl:userRoleData) {
	    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
	    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
	    				activeTrfData.add(mdl);
	    			}
	    		}else {
	    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
	    				String usrId = mdl.getUserId();
	    				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getUserId(), 0);
	    				if(srchUsr != null) {
							mdl.setUserStatus(srchUsr.getEmpStatTxt());
						}else {
							mdl.setUserStatus("NO DATA FOUND");
						}
	    				incompleteData.add(mdl);
	    			}
	    		}
	    	}
		}

		if(incompleteData != null && !incompleteData.isEmpty()) {
			sAPExtrGaaDataService.sendInvldDataEmail(templSysParam, incompleteData);
		}
		return activeTrfData;
	}


	@Override
	public List<SapGaaUser2RoleModel> readHanaUserGrantData(String templSysParam, String calledBy) {
		List<SapGaaUser2RoleModel> allUserData = new ArrayList<>();
		try {
			List<HanaUserGrantModel> grntData = hANADataDao.getUserGrants(templSysParam);
			if(grntData != null && !grntData.isEmpty()) {
				// START - Store Raw Data into USER2ROLE_RAWDATA
				if("R".equals(calledBy)) {
					saveUser2RoleRawData(grntData, templSysParam);
				}
				// END - Store Raw Data into USER2ROLE_RAWDATA

				String[]systemInfo = templSysParam.split("_");
				for(HanaUserGrantModel grntMdl:grntData ) {
					String usrId = grntMdl.getWwId().trim().toUpperCase();
					if(!(usrId.length() > 16 || usrId.length() <= 1 || usrId.contains("SYS") || usrId.contains("_"))) {
						UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usrId, 1);
						SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
						usrMdl.setRevUserId("");
						usrMdl.setUserId((srchUsr != null)?srchUsr.getWwId():usrId);
						usrMdl.setFirstName((srchUsr != null)?srchUsr.getGivenNm():"");
						usrMdl.setLastName((srchUsr != null)?srchUsr.getFmlyNm():"");
						usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
						usrMdl.setPrimaryReviewInfo2(grntMdl.getRoleName());
						usrMdl.setPrimaryReviewInfo3(" Within "+Utility.getSapClientName(systemInfo[3]));
						usrMdl.setAdditionalInfo1(Utility.getSapClientName(systemInfo[3]));
						usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
						usrMdl.setAdditionalInfo3(grntMdl.getRoleName());
						usrMdl.setUserStatus((srchUsr != null)?srchUsr.getEmpStatTxt():"NOT FOUND");
						allUserData.add(usrMdl);
					}
				}
			}
		} catch (Exception e) {
			log.error("ERROR Getting USER-ROLE information ("+templSysParam+") :"+e.getMessage(), e);
		}

		return allUserData;
	}

	private void saveUser2RoleRawData(List<HanaUserGrantModel> grntData, String templSysParam) {
		List<User2RoleRawDataMdl> allUserData = new ArrayList<>();
		String[] sysInfoArr = templSysParam.split("_");
		for(HanaUserGrantModel usrRlMdl : grntData){
			User2RoleRawDataMdl usrMdl = new User2RoleRawDataMdl();
			usrMdl.setRegion(sysInfoArr[0]);
			usrMdl.setPlatform(sysInfoArr[1]);
			usrMdl.setEnvironment(sysInfoArr[2]);
			usrMdl.setSystem(sysInfoArr[3]);
			usrMdl.setUserId(usrRlMdl.getWwId());
			usrMdl.setRoleId(usrRlMdl.getRoleName());
			usrMdl.setRoleDesc(usrRlMdl.getRoleName());
			allUserData.add(usrMdl);
		}
		//Insert Data
		if(!allUserData.isEmpty()) {
			int totalRec = sAPExtrGaaDataService.insertUser2RoleRawData(allUserData);
			log.info("TOTAL RAW DATA for System ("+templSysParam+") :"+allUserData.size()+"  INSERTED: "+totalRec);
		}

	}




	@Override
	public Map<String, HanaUserRoleModel> readUserGrantData(String templSysParam) {
		Map<String, HanaUserRoleModel> roleMap = new HashMap<>();
		try {
			List<HanaUserGrantModel> grntData = hANADataDao.getUserGrants(templSysParam);

			if(grntData != null) {
				int i=1;
				for(HanaUserGrantModel grntMdl:grntData) {
					System.out.println("USER GRANTS :"+grntMdl);

					if(Utility.isNumeric(grntMdl.getWwId())) {
						//log.info(i+". "+grntMdl);
						String wwid =  grntMdl.getWwId();
						if(roleMap.containsKey(wwid)) {
							HanaUserRoleModel rlMdl =  roleMap.get(wwid);
							String rlName = grntMdl.getRoleName();
							Map<String, List<HanaUserPrivilegeModel>> privMap = rlMdl.getRoles();
							if(privMap.containsKey(rlName)) {
								List<HanaUserPrivilegeModel> rivLst = privMap.get(rlName);
								HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
								newPriv.setRoleName(grntMdl.getRoleName());
								newPriv.setObjType(grntMdl.getObjType());
								newPriv.setObjName(grntMdl.getObjName());
								newPriv.setColName(grntMdl.getColName());
								newPriv.setPrivilege(grntMdl.getPrivilege());
								newPriv.setValid(grntMdl.getValid());
								rivLst.add(newPriv);
								privMap.put(rlName, rivLst);
							}else {
								List<HanaUserPrivilegeModel> rivLst = new ArrayList<>();
								HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
								newPriv.setRoleName(grntMdl.getRoleName());
								newPriv.setObjType(grntMdl.getObjType());
								newPriv.setObjName(grntMdl.getObjName());
								newPriv.setColName(grntMdl.getColName());
								newPriv.setPrivilege(grntMdl.getPrivilege());
								newPriv.setValid(grntMdl.getValid());
								rivLst.add(newPriv);
								privMap.put(rlName, rivLst);
							}
							rlMdl.setRoles(privMap);
							roleMap.put(wwid, rlMdl);
						}else {
							HanaUserRoleModel rlMdl =  new HanaUserRoleModel();
							rlMdl.setWwId(grntMdl.getWwId());
							rlMdl.setType(grntMdl.getType());

							List<HanaUserPrivilegeModel> privLst = new ArrayList<>();
							HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
							newPriv.setRoleName(grntMdl.getRoleName());
							newPriv.setObjType(grntMdl.getObjType());
							newPriv.setObjName(grntMdl.getObjName());
							newPriv.setColName(grntMdl.getColName());
							newPriv.setPrivilege(grntMdl.getPrivilege());
							newPriv.setValid(grntMdl.getValid());
							privLst.add(newPriv);

							Map<String, List<HanaUserPrivilegeModel>> privMap = new HashMap<>();
							privMap.put(grntMdl.getRoleName(), privLst);
							rlMdl.setRoles(privMap);
							roleMap.put(grntMdl.getWwId(), rlMdl);
						}
					}
					i++;
				}
				log.info("User Grants - Total Records filtered : "+i +" Total Unique User Records collected: "+roleMap.size());

			}
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return roleMap;
	}


	@SuppressWarnings("all")
	@Override
	public List<HanaRole2SodModel> readHanaRolesData(String roleNames, String riskLevel, String templSysParam){
		log.info("roleNames :"+roleNames);
		List<HanaRole2SodModel> rl2SodLst = new LinkedList<>();
		Map<String, List<HanaUserPrivilegeModel>> roleMap =  readRolePrivilegeData(templSysParam);
		Map<String, HanaDBRiskModel> dbRiskMap = null;
		if(Utility.getCache(Constants.HANA_DB_RISK) == null) {
			dbRiskMap = getHanaDBRiskData("");
			Utility.setCache(Constants.HANA_DB_RISK, dbRiskMap);
		}else {
			dbRiskMap = (Map<String, HanaDBRiskModel>)Utility.getCache(Constants.HANA_DB_RISK);
		}

		List<HanaRole2SodModel> indLst = new LinkedList<>();
		List<HanaRole2SodModel> comLst = new LinkedList<>();

		if(roleNames == null || roleNames.length() <= 0) {
			List<String> keyLst = new ArrayList<>(roleMap.keySet());
			if(keyLst != null && keyLst.size() > 0) {
				for (int i = 0; i < keyLst.size(); i++) {
					indLst.addAll(getRoleToSOD(keyLst.get(i), roleMap.get(keyLst.get(i)), dbRiskMap));
					for (int j = i+1; j < keyLst.size(); j++) {
						String roleNm1 = keyLst.get(i);
						String roleNm2 = keyLst.get(j);
						comLst.addAll(getMultiRole2SOD(roleNm1, roleNm2, roleMap.get(roleNm1), roleMap.get(roleNm2), dbRiskMap));
					}
				}
			}
		}else{

			List<String> keyLst = Arrays.asList(roleNames.split(","));
			for (int i = 0; i < keyLst.size(); i++) {
				indLst.addAll(getRoleToSOD(keyLst.get(i), roleMap.get(keyLst.get(i)), dbRiskMap));
				for (int j = i+1; j < keyLst.size(); j++) {
					String roleNm1 = keyLst.get(i);
					String roleNm2 = keyLst.get(j);
					comLst.addAll(getMultiRole2SOD(roleNm1, roleNm2, roleMap.get(roleNm1), roleMap.get(roleNm2), dbRiskMap));
				}
			}
		}
		//Combine all
		rl2SodLst.addAll(indLst);
		rl2SodLst.addAll(comLst);
		if(riskLevel !="0" && riskLevel.length() >1){
			rl2SodLst = filterRolesOnRiskLvl(riskLevel, rl2SodLst);
		}

		return rl2SodLst;
	}


	private List<HanaRole2SodModel> filterRolesOnRiskLvl(String riskLevel, List<HanaRole2SodModel>rle2SodLst){
		List<HanaRole2SodModel> lst=new LinkedList<>();
		for(HanaRole2SodModel mdl:rle2SodLst) {
			if(mdl.getRiskLevel().equals(riskLevel)) {
				lst.add(mdl);
			}
		}
		return lst;
	}



	@Override
	public Map<String, List<HanaUserPrivilegeModel>> readRolePrivilegeData(String templSysParam) {
		Map<String, List<HanaUserPrivilegeModel>> rolesMap = new HashMap<>();
		try {
			List<HanaUserGrantModel> grntData = hANADataDao.getUserGrants(templSysParam);//TODO
			if(grntData != null) {
				int i=1;
				for(HanaUserGrantModel grntMdl:grntData) {
					if(Utility.isNumeric(grntMdl.getWwId())) {
						String rlName = grntMdl.getRoleName();
						List<HanaUserPrivilegeModel> privLst = null;
						if(rolesMap.get(rlName) == null) {
							privLst = new ArrayList<>() ;
							HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
							newPriv.setRoleName(grntMdl.getRoleName());
							newPriv.setObjType(grntMdl.getObjType());
							newPriv.setObjName(grntMdl.getObjName());
							newPriv.setColName(grntMdl.getColName());
							newPriv.setPrivilege(grntMdl.getPrivilege());
							newPriv.setValid(grntMdl.getValid());
							privLst.add(newPriv);
						}else {
							privLst = rolesMap.get(rlName);
							HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
							newPriv.setRoleName(grntMdl.getRoleName());
							newPriv.setObjType(grntMdl.getObjType());
							newPriv.setObjName(grntMdl.getObjName());
							newPriv.setColName(grntMdl.getColName());
							newPriv.setPrivilege(grntMdl.getPrivilege());
							newPriv.setValid(grntMdl.getValid());
							if(!privLst.contains(newPriv)) {//Cheking the duplicate Privilege returned by DB
								privLst.add(newPriv);
							}

						}
						rolesMap.put(rlName, privLst);
					}
					i++;
				}
				log.info("User Grants - Total Records filtered : "+i +" Total Unique User Records collected: "+rolesMap.size());
			}
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return rolesMap;
	}


	private List<HanaUser2SodModel> getUserToSOD(String empId, List<HanaUserPrivilegeModel> privList, Map<String, HanaDBRiskModel> dbRiskMap) {
		log.info("*******Comparing Data for User :"+empId+ "*******");
		log.info("********Total Number of Privileges User Has:"+privList.size()+"********");
		List<HanaUser2SodModel> usr2SodLst = new LinkedList<>();
		String rolei=null;
		String rolej=null;
		for (int i = 0; i < privList.size(); i++) {
			for (int j = i+1; j < privList.size(); j++) {
				rolei=privList.get(i).getRoleName();
				rolej=privList.get(j).getRoleName();
				String key = privList.get(i).getPrivilege() +"~"+privList.get(j).getPrivilege();
				String key1 = privList.get(j).getPrivilege() +"~"+privList.get(i).getPrivilege();
				if(dbRiskMap.get(key) !=null) {
					usr2SodLst.add(fillData(empId, dbRiskMap.get(key), rolei, rolej));
					log.info(i+" - "+j+". SOD FOUND:"+key+" : "+dbRiskMap.get(key));
				}else if(dbRiskMap.get(key1) !=null) {
					usr2SodLst.add(fillData(empId, dbRiskMap.get(key1), rolej, rolei));
					log.info(i+" - "+j+". SOD FOUND:"+key1+" : "+dbRiskMap.get(key1));
				}else {
					//log.info(i+" - "+j+". SOD Record not Found for Key:"+key +"   key1: "+key1);
				}
			}
		}
		return usr2SodLst;
	}


	private List<HanaUser2SodModel>getConflictsWithNewRoles(String empId, List<HanaUserPrivilegeModel> newRolePrivs,
			List<HanaUserPrivilegeModel> privList, Map<String, HanaDBRiskModel> dbRiskMap) {

		log.info("*******Comparing Data for User :"+empId+ " Total Privileges Existing:"+privList.size()+" NEW Role: "+newRolePrivs.size()+"********");
		List<HanaUser2SodModel> usr2SodLst = new LinkedList<>();
		String rolei=null;
		String rolej=null;
		for (int i = 0; i < newRolePrivs.size(); i++) {
			for (int j = 0; j < privList.size(); j++) {
				rolei=newRolePrivs.get(i).getRoleName();
				rolej=privList.get(j).getRoleName();
				String key = newRolePrivs.get(i).getPrivilege() +"~"+privList.get(j).getPrivilege();
				String key1 = privList.get(j).getPrivilege() +"~"+newRolePrivs.get(i).getPrivilege();
				if(dbRiskMap.get(key) !=null) {
					usr2SodLst.add(fillData(empId, dbRiskMap.get(key), rolei, rolej));
					log.info(i+" - "+j+". SOD FOUND:"+key+" : "+dbRiskMap.get(key));
				}else if(dbRiskMap.get(key1) !=null) {
					usr2SodLst.add(fillData(empId, dbRiskMap.get(key1), rolej, rolei));
					log.info(i+" - "+j+". SOD FOUND:"+key1+" : "+dbRiskMap.get(key1));
				}
			}
		}
		return usr2SodLst;
	}


	private List<HanaRole2SodModel> getRoleToSOD(String roleName1, List<HanaUserPrivilegeModel> privList, Map<String, HanaDBRiskModel> dbRiskMap) {
		log.info("*******Comparing ROLE2SOD for ROLE :"+roleName1+ "*******");
		log.info("********Total Number of Privileges Role Has:"+privList.size()+"********");
		List<HanaRole2SodModel> rl2SodLst = new LinkedList<>();
		for (int i = 0; i < privList.size(); i++) {
			for (int j = i+1; j < privList.size(); j++) {
				String key = privList.get(i).getPrivilege() +"~"+privList.get(j).getPrivilege();
				String key1 = privList.get(j).getPrivilege() +"~"+privList.get(i).getPrivilege();
				if(dbRiskMap.get(key) !=null) {
					rl2SodLst.add(fillRolesData(roleName1, roleName1, dbRiskMap.get(key)));
					log.info(i+" - "+j+". SOD FOUND:"+key+" : "+dbRiskMap.get(key));
				}else if(dbRiskMap.get(key1) !=null) {
					rl2SodLst.add(fillRolesData(roleName1, roleName1, dbRiskMap.get(key1)));
					log.info(i+" - "+j+". SOD FOUND:"+key1+" : "+dbRiskMap.get(key1));
				}
			}
		}
		return rl2SodLst;
	}


	private List<HanaRole2SodModel> getMultiRole2SOD(String roleName1, String roleName2, List<HanaUserPrivilegeModel> privList1, List<HanaUserPrivilegeModel> privList2, Map<String, HanaDBRiskModel> dbRiskMap) {
		log.info("*******Comparing ROLE2SOD for ROLE1-ROLE2 :"+roleName1+ " - "+roleName2+"*******");
		log.info("********Total Number of Privileges  ROLE1-ROLE2 Have:"+privList1.size()+" - "+privList2.size()+"********");
		List<HanaRole2SodModel> rl2SodLst = new LinkedList<>();
		for (int i = 0; i < privList1.size(); i++) {
			for (int j = i+1; j < privList2.size(); j++) {
				String key = privList1.get(i).getPrivilege() +"~"+privList2.get(j).getPrivilege();
				String key1 = privList2.get(j).getPrivilege() +"~"+privList1.get(i).getPrivilege();
				if(dbRiskMap.get(key) !=null) {
					rl2SodLst.add(fillRolesData(roleName1, roleName2, dbRiskMap.get(key)));
					log.info(i+" - "+j+". SOD FOUND:"+key+" : "+dbRiskMap.get(key));
				}else if(dbRiskMap.get(key1) !=null) {
					rl2SodLst.add(fillRolesData(roleName2, roleName1, dbRiskMap.get(key1)));
					log.info(i+" - "+j+". SOD FOUND:"+key1+" : "+dbRiskMap.get(key1));
				}
			}
		}
		return rl2SodLst;
	}





	@Override
	public Map<String, HanaDBRiskModel> getHanaDBRiskData(String riskIdFilter){
		//String path = "D:/Users/DChauras/CSI/HANA/CONFLICT_MATRIX/HNDB_Risks.xlsx";
		log.info("Loding file :"+Constants.HANA_DBRISK_FILEPATH);
		Workbook nFile = Utility.loadFile(Constants.HANA_DBRISK_FILEPATH);
		Sheet dsheet = nFile.getSheetAt(0);
		Map<String, HanaDBRiskModel> dataMap = new HashMap<>();
		Map<String, HanaDBRiskModel> outMap = new HashMap<>();

		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				HanaDBRiskModel rskMdl	= new HanaDBRiskModel();
				String riskId	 		= Utility.getCellValue(rw.getCell(0));
				rskMdl.setRiskId(riskId);
				String riskDesc 		= Utility.getCellValue(rw.getCell(1));
				rskMdl.setRiskDesc(riskDesc);
				String funcA 			= Utility.getCellValue(rw.getCell(2));
				rskMdl.setFuncA(funcA);
				String funcADesc  		= Utility.getCellValue(rw.getCell(3));
				rskMdl.setFuncADesc(funcADesc);
				String funcB 			= Utility.getCellValue(rw.getCell(4));
				rskMdl.setFuncB(funcB);
				String funcBDesc	  	= Utility.getCellValue(rw.getCell(5));
				rskMdl.setFuncBDesc(funcBDesc);
				String riskLevel  		= Utility.getCellValue(rw.getCell(6));
				rskMdl.setRiskLevel(riskLevel);
				String regulation		= Utility.getCellValue(rw.getCell(7));
				rskMdl.setRegulation(regulation);
				String trgtCon	 		= Utility.getCellValue(rw.getCell(8));
				rskMdl.setTrgtCon(trgtCon);
				String mitiCntrl		= Utility.getCellValue(rw.getCell(9));
				rskMdl.setMitiCntrl(mitiCntrl);
				String complMgr			= Utility.getCellValue(rw.getCell(10));
				rskMdl.setComplMgr(complMgr);
				String rulesetGpo 		= Utility.getCellValue(rw.getCell(11));
				rskMdl.setRulesetGpo(rulesetGpo);

				dataMap.put(rskMdl.getFuncADesc()+"~"+rskMdl.getFuncBDesc(), rskMdl);
				i++;
			}
		}

		//Filter User level Data
		if(riskIdFilter != null && riskIdFilter.length() > 0) {
			for(HanaDBRiskModel rls:dataMap.values()) {
				if(rls.getRiskId().equals(riskIdFilter)) {
					outMap.put(rls.getFuncADesc()+"~"+rls.getFuncBDesc(), rls);
				}
			}
		}else {
			outMap = dataMap;
		}
		log.info("DB Risk Total Records for Processed(outLst) : "+outMap.size());
		return outMap;
	}

	private HanaUser2SodModel fillData(String empId, HanaDBRiskModel mdl, String role1, String role2) {
		HanaUser2SodModel sodMdl = new HanaUser2SodModel();
		sodMdl.setWwId(empId);
		sodMdl.setRiskId(mdl.getRiskId());
		sodMdl.setRiskDesc(mdl.getRiskDesc());
		sodMdl.setRole1(role1);
		sodMdl.setRole2(role2);
		sodMdl.setFuncA(mdl.getFuncA());
		sodMdl.setFuncADesc(mdl.getFuncADesc());
		sodMdl.setFuncB(mdl.getFuncB());
		sodMdl.setFuncBDesc(mdl.getFuncBDesc());
		sodMdl.setRiskLevel(mdl.getRiskLevel());
		sodMdl.setRegulation(mdl.getRegulation());
		sodMdl.setTrgtCon(mdl.getTrgtCon());
		sodMdl.setMitiCntrl(mdl.getMitiCntrl());
		sodMdl.setComplMgr(mdl.getComplMgr());
		sodMdl.setRulesetGpo(mdl.getRulesetGpo());
		return sodMdl;
	}


	private HanaRole2SodModel fillRolesData(String role1, String role2, HanaDBRiskModel mdl) {
		HanaRole2SodModel roleMdl = new HanaRole2SodModel();
		roleMdl.setRole1(role1);
		roleMdl.setRole2(role2);
		roleMdl.setRiskId(mdl.getRiskId());
		roleMdl.setRiskDesc(mdl.getRiskDesc());
		roleMdl.setFuncA(mdl.getFuncA());
		roleMdl.setFuncADesc(mdl.getFuncADesc());
		roleMdl.setFuncB(mdl.getFuncB());
		roleMdl.setFuncBDesc(mdl.getFuncBDesc());
		roleMdl.setRiskLevel(mdl.getRiskLevel());
		roleMdl.setRegulation(mdl.getRegulation());
		roleMdl.setTrgtCon(mdl.getTrgtCon());
		roleMdl.setMitiCntrl(mdl.getMitiCntrl());
		roleMdl.setComplMgr(mdl.getComplMgr());
		roleMdl.setRulesetGpo(mdl.getRulesetGpo());
		return roleMdl;
	}

	private List<HanaUserPrivilegeModel> readAllPrivileges(HanaUserRoleModel rlMdl){
		List<HanaUserPrivilegeModel> outLst = new ArrayList<>();
		List<HanaUserPrivilegeModel> finalLst = new ArrayList<>();
		Map<String, List<HanaUserPrivilegeModel>> pMap= rlMdl.getRoles();
		for(Map.Entry<String, List<HanaUserPrivilegeModel>> entry:pMap.entrySet()) {
			List<HanaUserPrivilegeModel> lst = entry.getValue();
			outLst.addAll(lst);
		}

		for(HanaUserPrivilegeModel mdl : outLst) {
			if(!finalLst.contains(mdl)) {
				finalLst.add(mdl);
			}
		}
		log.info("User Privileges - Total Records : "+outLst.size()+"  Final List : "+finalLst.size());
		return finalLst;
	}

	private List<HanaUserPrivilegeModel> readAllPrivileges(Map<String, List<HanaUserPrivilegeModel>> rlPrivMdl, String id){
		List<HanaUserPrivilegeModel> outLst = new ArrayList<>();
		List<HanaUserPrivilegeModel> finalLst = new ArrayList<>();

		if(Utility.isEmpty(id)) {
			for(Map.Entry<String, List<HanaUserPrivilegeModel>> entry:rlPrivMdl.entrySet()) {
				List<HanaUserPrivilegeModel> lst = entry.getValue();
				outLst.addAll(lst);
			}
		}else {
			outLst.addAll(rlPrivMdl.get(id));
		}

		for(HanaUserPrivilegeModel mdl : outLst) {
			if(!finalLst.contains(mdl)) {
				finalLst.add(mdl);
			}
		}
		log.info("User Privileges - Total Records : "+outLst.size()+"  Final List : "+finalLst.size());
		return finalLst;
	}


	@Override
	public String writeHanaUser2SodCsvReport(List<HanaUser2SodModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeHanaUser2SodCSV(data, "HANA_"+fileName+".csv");
		return filePath;
	}

	@Override
	public String writeHanaRole2SodCsvReport(List<HanaRole2SodModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeHanaRole2SodCSV(data, "HANA_"+fileName+".csv");
		return filePath;
	}


	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadHANAProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}


	@Override
	public Map<String, List<HanaUserPrivilegeModel>> readNewRolesData(String newRoles, String templSysParam) {
		Map<String, List<HanaUserPrivilegeModel>> rolePrivMap = new HashMap<>();
		try {
			List<HanaRoleUserPrivilegeMdl> rolePrivData = hANADataDao.getRolePrivilegeData(templSysParam, newRoles);
			if(rolePrivData != null && !rolePrivData.isEmpty()) {
				List<HanaUserPrivilegeModel> prvLst = null;
				for(HanaRoleUserPrivilegeMdl rpMdl: rolePrivData) {
					String roleNm = rpMdl.getGrantee();
					if(rolePrivMap.get(roleNm)==null) {
						prvLst = new ArrayList<>();
						HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
						newPriv.setRoleName(roleNm);
						newPriv.setObjType(rpMdl.getObjectType());
						newPriv.setObjName(rpMdl.getObjectName());
						newPriv.setColName(rpMdl.getColumnName());
						newPriv.setPrivilege(rpMdl.getPrivilege());
						newPriv.setValid(rpMdl.getIsValid());
						prvLst.add(newPriv);

					}else {
						prvLst = rolePrivMap.get(roleNm);
						HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
						newPriv.setRoleName(roleNm);
						newPriv.setObjType(rpMdl.getObjectType());
						newPriv.setObjName(rpMdl.getObjectName());
						newPriv.setColName(rpMdl.getColumnName());
						newPriv.setPrivilege(rpMdl.getPrivilege());
						newPriv.setValid(rpMdl.getIsValid());
						prvLst.add(newPriv);
					}
					rolePrivMap.put(roleNm, prvLst);
				}
			}
		} catch (Exception e) {
			log.error("Error Role Addition Data :"+e.getMessage(), e);
		}
		return rolePrivMap;
	}



		/**
		 * Method  : HANADataServiceImpl.java.readUserDirectAssignmentData()
		 *		   :<b>@param templSysParam
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Jan 29, 2021 2:14:43 AM
		 * Purpose :Read Users Direct Assignment of Privileges
		 * @return : Map<String,List<HanaUserPrivilegeModel>>
		 */
	@Override
	public Map<String, List<HanaUserPrivilegeModel>> readUserDirectAssignmentData(String templSysParam) {
		Map<String, List<HanaUserPrivilegeModel>> rolePrivMap = new HashMap<>();
		try {
			List<HanaRoleUserPrivilegeMdl> rolePrivData = hANADataDao.getUserDirectPrivilegeData(templSysParam);
			if(rolePrivData != null && !rolePrivData.isEmpty()) {
				List<HanaUserPrivilegeModel> prvLst = null;
				for(HanaRoleUserPrivilegeMdl rpMdl: rolePrivData) {
					String userWwid = rpMdl.getGrantee();
					if(Utility.isNumeric(userWwid)) {
						HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
						newPriv.setRoleName("INVALID");
						if(rolePrivMap.get(userWwid)==null) {
							prvLst = new ArrayList<>();
							newPriv.setObjType(rpMdl.getObjectType());
							newPriv.setObjName(rpMdl.getObjectName());
							newPriv.setColName(rpMdl.getColumnName());
							newPriv.setPrivilege(rpMdl.getPrivilege());
							newPriv.setValid(rpMdl.getIsValid());
							prvLst.add(newPriv);
						}else {
							prvLst = rolePrivMap.get(userWwid);
							newPriv.setObjType(rpMdl.getObjectType());
							newPriv.setObjName(rpMdl.getObjectName());
							newPriv.setColName(rpMdl.getColumnName());
							newPriv.setPrivilege(rpMdl.getPrivilege());
							newPriv.setValid(rpMdl.getIsValid());
							prvLst.add(newPriv);
						}
						rolePrivMap.put(userWwid, prvLst);
					}
				}
			}
		} catch (Exception e) {
			log.error("Error Reading User Direct Assignment Data :"+e.getMessage(), e);
		}
		return rolePrivMap;
	}


		@Override
		public String writeHanaConflictMatrixCsvReport(List<HanaDBRiskModel> data, String fileName) {
			String filePath = "";
			filePath = csvReportWriter.writeHanaConflictMatrixCSV(data, "HANA_"+fileName+".csv");
			return filePath;
		}

		@Override
		public String writeJdeUserAccessCSV(List<SAPUserAccessModel> data, String fileName) {
			String filePath = "";
			filePath = csvReportWriter.writeSapGaaUserAccessCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
			return filePath;
		}








}
