package com.jnj.rqc.userreq.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.AbsCancelRejectRequestModel;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSecExcesvRestrictedAccsMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.IAMReqRoleMdl;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.ReqSrchConstMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.useridentity.models.ConflictRequestedModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;

public interface AbsUserRequesDao {

	/**
	 * Method  : AbsUserRequesDao.java.getAllSavedUserRequests()
	 *		   :<b>@param startDate
	 *		   :<b>@param endDate
	 *		   :<b>@param paramType
	 *		   :<b>@param paramValue
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 5, 2023 4:43:06 PM
	 * Purpose : Get All Request Data
	 * @return : List<AbsUserReqMdl>
	*/
	public List<AbsUserReqMdl> getAllSavedUserRequests(String startDate, String endDate, int paramType, String paramValue) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getRequestRoleStatus()
	 *		   :<b>@param reqId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 21, 2023 3:49:03 PM
	 * Purpose : Gives Role Status for Requested Roles
	 * @return : List<IAMReqRoleMdl>
	*/
	public List<IAMReqRoleMdl> getRequestRoleStatus(String reqId) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.saveAbsUserRequest()
	 *		   :<b>@param reqModel
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 22, 2023 3:39:37 PM
	 * Purpose : Method to Save Request Data submitted by the User
	 * @return : int
	*/
	public int saveAbsUserRequest(UserReqCompMdl reqModel) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.saveAbsUserConflicts()
	 *		   :<b>@param requestId
	 *		   :<b>@param assocUser
	 *		   :<b>@param confList
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 23, 2023 11:33:15 AM
	 * Purpose : Saving User Level Conflicts
	 * @return : int
	*/
	public int saveAbsUserConflicts(int requestId, UserSearchModel assocUser, List<UserAbsConflictMdl> confList) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.saveAbsExcsvAccess()
	 *		   :<b>@param requestId
	 *		   :<b>@param assocUser
	 *		   :<b>@param exList
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 24, 2023 11:06:55 AM
	 * Purpose : Saving Excessive Access Details
	 * @return : int
	*/
	public int saveAbsExcsvAccess(int requestId, UserSearchModel assocUser, List<AbsExcesvAccsMdl> exList) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getAllSrchConstants()
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 4, 2023 5:20:24 PM
	 * Purpose : Return all Search Constants
	 * @return : List<ReqSrchConstMdl>
	*/
	public List<ReqSrchConstMdl> getAllSrchConstants() throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getCountOfPendingRequest()
	 *		   :<b>@param userId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 7, 2023 3:42:34 PM
	 * Purpose : Get Count of Pending Requests
	 * @return : int
	*/
	int getCountOfPendingRequest(String userId) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getTktDependencies()
	 *		   :<b>@param reqId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 13, 2023 9:46:16 AM
	 * Purpose : Get Child Dependencies for Request
	 * @return : List<ReqDpendncMdl>
	*/
	public List<ReqDpendncMdl> getTktDependencies(String reqId) throws SQLException, DataAccessException;

	//getTktDependenciesByConflict(String reqId, String sysid1, String sysid2, String posid1, String posid2) throws SQLException, DataAccessException
	//public List<ReqDpendncMdl> getTktDependenciesByConflict(String reqId, String sysid1, String sysid2, String posid1, String posid2) throws SQLException, DataAccessException;
	//public List<String> getTktDependenciesByConflict(String reqId, String sysid1, String sysid2,  String posid1,  String posid2) throws SQLException, DataAccessException;
	public List<String> getTktDependenciesByConflict(String reqId, String sysid1, String sysid2,  String posid1,  String posid2) throws SQLException, DataAccessException;
	//public List<ConflictRequestedModel>

	public List<RawSysDpendncMdl> getSysDependencies(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr) throws SQLException, DataAccessException;

	public List<AbsUserReqMdl> getRequestDataByReqID(String reqId) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getRequestLvlConflicts()
	 *		   :<b>@param reqId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 14, 2023 10:41:36 AM
	 * Purpose : Get All Conflicts
	 * @return : List<UserAbsConflictMdl>
	*/
	public List<UserAbsConflictMdl> getRequestLvlConflicts(String reqId) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getRequestLvlExcData()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 14, 2023 10:41:52 AM
	 * Purpose : Get Accessive Data for Request ID
	 * @return : List<AbsExcesvAccsMdl>
	*/
	public List<AbsExcesvAccsMdl> getRequestLvlExcData(String reqId) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.getMitigatingControls()
	 *		   :<b>@param id
	 *		   :<b>@param type
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 17, 2023 3:28:06 PM
	 * Purpose : Get All Mitigating Controls
	 * @return : List<StrKeyValPair>
	*/
	public List<StrKeyValPair> getMitigatingControls(String id, String type) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.updReqConflictStatus()
	 *		   :<b>@param confList
	 *		   :<b>@param approveUser
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 18, 2023 3:59:34 PM
	 * Purpose : Updating Conflict Status
	 * @return : int
	*/
	int updReqConflictStatus(List<UserAbsConflictMdl> confList, UserSearchModel approveUser) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.updReqExcsvAccessStatus()
	 *		   :<b>@param excessiveApprovalList
	 *		   :<b>@param approveUser
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 18, 2023 4:35:26 PM
	 * Purpose :Update Excessive Access Status
	 * @return : int
	*/
	public int updReqExcsvAccessStatus(List<AbsExcesvAccsMdl> excessiveApprovalList, UserSearchModel approveUser) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.confUpdateRequestStatus()
	 *		   :<b>@param requestId
	 *		   :<b>@param status
	 *		   :<b>@param confResolved
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 18, 2023 11:35:52 PM
	 * Purpose : Update Conflict Approval Status
	 * @return : int
	*/
	public int confUpdateRequestStatus(String requestId, int status, String confResolved) throws SQLException, DataAccessException;

	/**
	 * Method  : AbsUserRequesDao.java.saveVariantApprovalStatus()
	 *		   :<b>@param variantDetails
	 *		   :<b>@param reqid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 19, 2023 3:15:10 PM
	 * Purpose :Saving Variant Approval State to Database
	 * @return : int
	*/
	public int saveVariantApprovalStatus(List<RawSysDpendncMdl> variantDetails, String reqid) throws SQLException, DataAccessException;


	/**
		 * Method  : AbsUserRequesDao.java.getApproverCategoryEmails()
		 *		   :<b>@param sysList
		 *		   :<b>@param catCd
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Apr 28, 2023 12:06:37 PM
		 * Purpose :
		 * @return : List<String>
		 */
	public List<String> getApproverCategoryEmails(List<String> sysList, int catCd)throws SQLException, DataAccessException;


	/**
		 * Method  : AbsUserRequesDao.java.getEligibleApprovedRequests()
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Apr 28, 2023 12:06:44 PM
		 * Purpose : Get All Approved request, which are eligible for Submission.
		 * @return : List<AbsUserReqMdl>
		 */
	public List<AbsUserReqMdl> getEligibleApprovedRequests() throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.saveIamReqstedDataHubRoles()
		 *		   :<b>@param reqMdlLst
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 12:34:08 AM
		 * Purpose :Saving All IAM requested roles to database
		 * @return : int
		 */
	public int saveIamReqstedDataHubAnaplanRoles(List<IAMRequestedRoleModel> reqMdlLst) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.updateIamGrcRequestStatus()
		 *		   :<b>@param requestId
		 *		   :<b>@param status
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 12:49:33 AM
		 * Purpose :  Update Request Status for the given Request ID
		 * @return : int
		 */
	public int updateIamGrcRequestStatus(int requestId, int status) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getZadGrpById()
		 *		   :<b>@param adGrpId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 1:00:42 AM
		 * Purpose : Query AD Group by ID
		 * @return : String
		 */
	public String getZadGrpById(String adGrpId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getAllADGrpBySystem()
		 *		   :<b>@param sysid
		 *		   :<b>@param posnIdArr
		 *		   :<b>@param accIdArr
		 *		   :<b>@param pvarIdArr
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 2:14:20 AM
		 * Purpose : Get All AD Group ID's Comma seperated
		 * @return : String
		 */
	public String getAllADGrpBySystem(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr)	throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getAllEDALIamSubmittedRequests()
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 4:06:39 PM
		 * Purpose : Query All Submitted Request to get Status from IAM
		 * @return : List<AbsUserReqMdl>
		 */
	public List<AbsUserReqMdl> getAllEDALIamSubmittedRequests() throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getEdalIamReqSubmittedRoles()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 5:39:20 PM
		 * Purpose : Get All the pending roles on IAM
		 * @return : List<IAMRequestedRoleModel>
		 */
	public List<IAMRequestedRoleModel> getEdalIamReqSubmittedRoles(String reqId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.updateEdalIamReqstedRolesStatus()
		 *		   :<b>@param apiStatus
		 *		   :<b>@param apiMsg
		 *		   :<b>@param apiErrMsg
		 *		   :<b>@param updDt
		 *		   :<b>@param detailNum
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 5:55:16 PM
		 * Purpose : Update Role Status
		 * @return : int
		 */
	public int updateEdalIamReqstedRolesStatus(String apiStatus, String apiMsg, String apiErrMsg, Date updDt, IAMRequestedRoleModel detailNum) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getRequestChildCount()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 6:25:15 PM
		 * Purpose : Child request count
		 * @return : int
		 */
	public int getRequestChildCount(String reqId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getCompletedReqStatus()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 6:29:32 PM
		 * Purpose : Completed request count
		 * @return : List<String>
		 */
	public List<String> getCompletedReqStatus(String reqId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.updateIamRequestStatus()
		 *		   :<b>@param requestId
		 *		   :<b>@param status
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 1, 2023 6:39:29 PM
		 * Purpose :
		 * @return : int
		 */
	public int updateIamRequestStatus(String requestId, int status) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getExcessiveAccessDeniedVariants()
		 *		   :<b>@param reqId
		 *		   :<b>@param sysId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 3, 2023 5:38:36 PM
		 * Purpose : Get all Denied Excessive Variants
		 * @return : List<String>
		 */
	public List<String> getExcessiveAccessDeniedVariants(String reqId, String sysId) throws SQLException, DataAccessException;


	/**
	 * Method  : AbsUserRequesDao.java.saveAbsRestExcsvAccessSystemData()
	 *		   :<b>@param requestId
	 *		   :<b>@param assocUser
	 *		   :<b>@param sectorDataList
	 *		   :<b>@param seletedVars
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 24, 2023 2:32:22 PM
	 * Purpose : To Save Restricted/Accessive Data
	 * @return : int[]
	 */
	public int[] saveAbsRestExcsvAccessSystemData(int requestId, UserSearchModel assocUser, List<AbsSecExcesvRestrictedAccsMdl> sectorDataList, List<RoleADGrpMdl> seletedVars) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.saveSectorRestExcsvAccessData()
		 *		   :<b>@param requestId
		 *		   :<b>@param assocUser
		 *		   :<b>@param sectorDataList
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 24, 2023 5:29:10 PM
		 * Purpose : Save Sector/System Level Excessive/Restricted Data
		 * @return : int
		 */
	public int saveSectorRestExcsvAccessData(int requestId, UserSearchModel assocUser, List<AbsSecExcesvRestrictedAccsMdl> sectorDataList) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.saveRestExcsvAccessRolesData()
		 *		   :<b>@param requestId
		 *		   :<b>@param assocUser
		 *		   :<b>@param seletedVars
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 24, 2023 5:30:06 PM
		 * Purpose : Save Roles for Restrictive/Excessive Access Data
		 * @return : int
		 */
	public int saveRestExcsvAccessRolesData(int requestId, UserSearchModel assocUser, List<RoleADGrpMdl> seletedVars) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getRequestLvlRestExcSecData()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 25, 2023 2:46:23 PM
		 * Purpose :Getting Data for SYSTEM/SECTOR for Excessive limit
		 * @return : List<AbsSecExcesvRestrictedAccsMdl>
		 */
	public List<AbsSecExcesvRestrictedAccsMdl> getRequestLvlRestExcSecData(String reqId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.getRequestLvlRestExcRoleData()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 25, 2023 3:47:28 PM
		 * Purpose : All Excessive/Restricted Roles for given Request ID
		 * @return : List<RoleADGrpMdl>
		 */
	public List<RoleADGrpMdl> getRequestLvlRestExcRoleData(String reqId) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.updReqExcsvRestrictiveAccessStatus()
		 *		   :<b>@param excsvRestApprovalList
		 *		   :<b>@param approveUser
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 30, 2023 4:50:20 PM
		 * Purpose : Save Approval Status for Restrictive/Excessive Access
		 * @return : int
		 */
	public int updReqExcsvRestrictiveAccessStatus(List<RoleADGrpMdl> excsvRestApprovalList, UserSearchModel approveUser) throws SQLException, DataAccessException;

	/**
		 * Method  : AbsUserRequesDao.java.updReqCancelRejectStatus()
		 *		   :<b>@param absCancelRejectRequestModel
		 *		   :<b>@param approveUser
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jun 16, 2023 7:08:01 PM
		 * Purpose : Cancel/Reject Request
		 * @return : int
		 */
	public int updReqCancelRejectStatus(AbsCancelRejectRequestModel absCancelRejectRequestModel, UserSearchModel approveUser) throws SQLException, DataAccessException;


	/**
		 * Method  : AbsUserRequesDao.java.getConflictsDeniedPositions()
		 *		   :<b>@param reqId
		 *		   :<b>@param sysId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jul 6, 2023 10:24:27 AM
		 * Purpose : Method to Filter Conflicts Denied
		 * @return : List<String>
		 */
	//public List<String> getConflictsDeniedPositions(String reqId, String sysId) throws SQLException, DataAccessException;
	public List<ConflictRequestedModel> getConflictsDeniedPositions(String reqId, String sysId) throws SQLException, DataAccessException;

	public List<ConflictRequestedModel> getConflictCount(String reqId, String sysId) throws SQLException, DataAccessException;
	/**
	 * Method  : AbsUserRequesDao.java.updateReqCancelRejectStatusChildTable()
	 *		   :<b>@param excsvRestApprovalList
	 *		   :<b>@param approveUser
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 30, 2023 4:50:20 PM
	 * Purpose : Save Approval Status for Restrictive/Excessive Access
	 * @return : int
	 */
	public int updateReqCancelRejectStatusChildTable(AbsCancelRejectRequestModel absCancelRejectRequestModel,
			UserSearchModel approveUser) throws SQLException, DataAccessException;
	public int updateIamReqstedDataHubAnaplanRoles(List<IAMRequestedRoleModel> reqMdlLst) throws SQLException, DataAccessException;
	public List<IAMRequestedRoleModel> getEdalIamReqSubmittedErrorRoles(int reqId, String sysid ) throws SQLException, DataAccessException;
	public List<AbsUserReqMdl> getRequestedDetailsFromHeader(String ReqId) throws SQLException, DataAccessException;
}
