package com.jnj.rqc.daoImpl;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.JDEExtrDao;
import com.jnj.rqc.dbconfig.TemplateFactory;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;




@Service
public class JDEExtrDaoImpl  extends TemplateFactory implements JDEExtrDao {
	static final Logger log = LoggerFactory.getLogger(JDEExtrDaoImpl.class);


	@Override
	public List<SapGaaUser2RoleModel> getJDEUser2RoleData(String templSysParam) throws SQLException, DataAccessException{
		log.info("Template Name : "+templSysParam);
		List<SapGaaUser2RoleModel> usrData = new ArrayList<>();
		if("NA_JDEPLATFORM_Production_JDEANIMAS".equals(templSysParam)) {
			usrData =  getJDEANIMASUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEBWI".equals(templSysParam)) {
			usrData =  getJDEBWIUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDCF92".equals(templSysParam)) {
			usrData =  getJDEDCF92User2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYEMEA".equals(templSysParam)) {
			usrData =  getJDEDEPUYEMEAUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYUS".equals(templSysParam)) {
			usrData =  getJDEDEPUYUSUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEEES".equals(templSysParam)) {
			usrData =  getJDEEESUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEETHICON".equals(templSysParam)) {
			usrData =  getJDEETHICONUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEGMED".equals(templSysParam)) {
			usrData =  getJDEGMEDUser2RoleData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_DSIBWI".equals(templSysParam)) {
			usrData =  getJDEDSIBWIUser2RoleData(templSysParam);
		}


		log.info("Total User Records returned for ("+templSysParam+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}

	private List<SapGaaUser2RoleModel> getJDEDSIBWIUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		List<String> lines = Collections.emptyList();
		 try{
			 lines = Files.readAllLines(Paths.get(Constants.JDE_DSIBWI_USERROLE_FILEPATH), StandardCharsets.UTF_8);
			 if(lines != null && !lines.isEmpty()) {
				 int i=0;
				 for(String str:lines) {
					 if(i>0) {
						 String[]dataArr = str.split(",");
						 SapGaaUser2RoleModel sapRlMdl = new SapGaaUser2RoleModel();
						 sapRlMdl.setUserId(dataArr[0].trim());
						 sapRlMdl.setRoleId(dataArr[1].trim());
						 sapRlMdl.setRoleDesc(dataArr[1].trim());
						 lstData.add(sapRlMdl);
					 }
					 i++;
				 }
			 }
			}catch (Exception e)
			{
				log.error("ERROR:"+e.getMessage(), e);
			}
		return lstData;
	}


	private List<SapGaaUser2RoleModel> getJDEGMEDUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " select b.abtax as USER_ID, d.rlfrrole as ROLE_ID,e.auroledesc as ROLE_DESC "+ /* ,a.uluser as UserID */
					 " from sy812.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sy812.f98owsec c on a.uluser = c.scuser "+
					 " left join Sy812.F95921 d on a.uluser = d.rltorole left join sy812.F00926 e on d.rlfrrole = e.auuser "+
					 " where a.uluser not in( 'BIDSSCHED','EMEA_DSI','JDE_PROD','OASRTE','OVISBE','PSPSCHED10','PSPSCHED11','PSPSCHED13','PSPSCHED14', "+
					 " 'PSPSCHED15','PSPSCHED2','PSPSCHED3','PSPSCHED4','PSPSCHED5','PSPSCHED6','PSPSCHED7','PSPSCHED8','PSPSCHED9','SAPPD01','SCHEDULE', "+
					 " 'SCHEDULE1','SCHEDULE2','SOAPE1PD','WME1PD','WME1PDH','WMRTPD','WMSNPPD','_LDAPDEFLT') order by USER_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}

	private List<SapGaaUser2RoleModel> getJDEETHICONUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " select b.abalky as USER_ID, a.ulugrp ROLE_ID, e.abalph as ROLE_DESC "+ /*, a.uluser UserID */
					 " from sys7333.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sys7333.f98owsec c on a.uluser = c.scuser "+
					 " left join sys7333.f0092 d on a.ulugrp = d.uluser left join proddta.f0101 e on d.ulan8 = e.aban8 "+
					 " where a.ulugrp not in ('*GROUP') and a.uluser not in('JDEUSER','JDE','JDEPWR','OWSVCS','SCHEDULER','DSIUSER','DSIUSERP','DSIUSERQ', "+
					 " 'LSTPOWER','MAESTRO','FINPOWER','MFGPOWER','PROPOWER','PLNPOWER','BPPOWER','APSPOWER','UNCPOWER','STCPOWER','MRPPOWER','SAMFGPWR', "+
					 " 'SLMFGPWR','SOMFGPWR','COMFGPWR','JZMFGPWR','MONITOR','YMRPPOWER') order by USER_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}


	private List<SapGaaUser2RoleModel> getJDEEESUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " select a.uluser as USER_ID, d.rlfrrole as ROLE_ID, e.auroledesc as ROLE_DESC "+ /*, b.abalky as WWID */
					 " from sy810.F0092 a left join pddta.F0101 b on a.ulan8 = b.aban8 inner join sy810.f98owsec c on a.uluser = c.scuser "+
					 " left join Sy810.F95921 d on a.uluser = d.rltorole left join sy810.F00926 e on d.rlfrrole = e.auuser "+
					 " where a.uluser not in('DSI_DV    ','DSI_PD    ','DSI_QA    ','EESOWSVC  ','JDEPWR    ','JOBSCH01  ','JOBSCH01  ','JOBSCHMRP ', "+
					 " 'JOBSCHMRP ','MONITORING','MONITORJUA','PSFT','TST00WMX02','WMJABPI_DV','WMJABPI_PD','WMJABPI_QA','WMXPI ','WMXPI_DV ') order by USER_ID asc ";

		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}

	private List<SapGaaUser2RoleModel> getJDEDEPUYUSUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " select b.abalky as USER_ID, a.ulugrp as ROLE_ID,e.abalph as ROLE_DESC "+ /*, a.uluser as USERID1 */
					 " from sys7333.F0092 a left join pddta.F0101 b on a.ulan8=b.aban8 inner join sys7333.f98owsec c on a.uluser=c.scuser "+
					 " left join sys7333.f0092 d on a.ulugrp=d.uluser left join pddta.f0101 e on d.ulan8=e.aban8 "+
					 " where a.ulugrp not in ('*GROUP') and a.uluser not in('BPMDPYUSBR','BPMDPYUSRY','BPMDPYUSWA','BRDCE01   ','BRDCE02   ','BRDCE03   ', "+
					 " 'BRDCE04   ','BRDCE05   ','BRDCE06   ','BRDCE07   ','BRDCE08   ','BRDCE09   ','BRDCE10   ','BRDCE11   ','BRDCE12   ','BRDCE13   ', "+
					 " 'BRDCE14   ','BRDCE15   ','BRDCE16   ','BRDCE17   ','BRDCE18   ','DPYOWSVCS ','JDE       ','JOBSCHDL  ','PWRTOOL   ','SADSTEST1 ', "+
					 " 'SADSTEST2 ','SADSTEST3 ','SADSTEST4 ','SADSTEST5 ','WADVDCE1  ','WADVDCE10 ','WADVDCE11 ','WADVDCE12 ','WADVDCE13 ','WADVDCE14 ', "+
					 " 'WADVDCE15 ','WADVDCE16 ','WADVDCE17 ','WADVDCE18 ','WADVDCE2  ','WADVDCE3  ','WADVDCE4  ','WADVDCE5  ','WADVDCE6  ','WADVDCE7  ', "+
					 " 'WADVDCE8  ','WADVDCE9  ','WEBMETHDEV','WEBMETHODS','WEBMTHCRD ','WEBMTHCRP ','WEBMTHOTCD','WEBMTHOTCP') order by user_id ";

		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}

	private List<SapGaaUser2RoleModel> getJDEDEPUYEMEAUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " select b.abtx2 as USER_ID, a.ulugrp as ROLE_ID, '' as ROLE_DESC "+ /* e.abalph as ROLE_DESC, a.uluser as UserID */
					 " from SYS7333.F0092 a left join PRODDTA.F0101 b on a.ulan8 = b.aban8 inner join SYS7333.F98OWSEC c on a.uluser = c.scuser "+
					 " left join SYS7333.f0092 d on a.ulugrp=d.uluser left join PRODDTA.F0101 e on d.ulan8 = e.aban8 "+
					 " Where a.ulugrp not in('*GROUP') and a.uluser not in('BPMONITOR','CMWSCHED','CRYSTAL','DSI_PROD','GBPOST1','GXRSIE','JDEPWR','JDE_PROD', "+
					 " 'PDVIEW','SCHEDDRP1','SCHEDPSP1','SCHEDPSP2','SCHEDPSP3','SCHEDULER')order by USER_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}

	private List<SapGaaUser2RoleModel> getJDEDCF92User2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> lstData = new ArrayList<>();
		String qry = " Select a.uluser as USER_ID, d.rlfrrole as ROLE_ID, e.auroledesc as ROLE_DESC "+ /*, b.abtax as WWID  */
					 " from sy920.f0092 a left join proddta.f0101 b on a.ulan8 = b.aban8 inner join sy920.f98owsec c on a.uluser = c.scuser "+
					 " left join sy920.f95921 d on a.uluser = d.rltorole left join sy920.f00926 e on d.rlfrrole =  e.auuser "+
					 " where d.rlfrrole <> '+LF00DIS01' and a.uluser not in ( '-CH09CSS02', '-GB31BAT01', '-LF00AFF01', 'SUBSYS_US','SUBSYSTEM', "+
					 " 'SA-DCF-BPM', '-SSSDEMO01', 'TWSQA', 'TWSDV','-LF00WDS01', 'WMETHODS', '-US42SCH01', '-US43PSB01', '-SCH_APS', '-SCH_OTC', "+
					 " '-SCH_PAL','-US31BAT01','JDE', '-SCH_OTC2', '@SCH_LEO', '-SCH_LEO', '-SCH_MFG', 'JDEPWR', 'LFSOWSVCS', "+
					 " '-SCH_FIN','-USSCH_FIN', 'TAU42EMC01', 'TLF09GDI01', 'TCH09OFA01','TLF09GAN02') ORDER BY USER_ID ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return lstData;
	}

	private List<SapGaaUser2RoleModel> getJDEBWIUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> bwiData = new ArrayList<>();
		String qry = " select a.uluser as USER_ID, d.rlfrrole as ROLE_ID, e.auroledesc as ROLE_DESC "+  /*, b.abtax as WWID */
					 " from sy920.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sy920.f98owsec c on a.uluser = c.scuser "+
					 " left join sy920.F95921 d on a.uluser = d.rltorole left join sy920.F00926 e on d.rlfrrole = e.auuser "+
					 " where d.rlfrrole not in ('_LDAPROLE') and a.uluser not in('SABWIE1SVC','SABWIMEPDV','SABWIMEPPD','SABWIMEPPY','SABWIMEPQA','SABWIMON', "+
					 " 'SABWIMRP1','SABWISCH01','SABWISCH02','SABWITEST1','SABWITEST2','SABWITEST3','SABWITEST4','SABWITEST5','SABWITEST6','SABWITEST9', "+
					 " 'SABWITST10','SABWITST11','SABWITST12','SABWIWM01','SABWIWM02','SABWIWM03', 'SABWIWM04','SABWIWM05','SABWIWMSUP','PFTEST001','PFTEST002','PFTEST003', "+
					 " 'PFTEST004','PFTEST005','PFTEST006','PFTEST007','PFTEST008','PFTEST009', 'SABWIWMDEV','CNCTL','CNDTA','JDE' )order by USER_ID asc ";
		bwiData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return bwiData;
	}
	private List<SapGaaUser2RoleModel> getJDEANIMASUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> anmData = new ArrayList<>();
		String qry = " Select b.abalky as USER_ID, a.ulugrp as ROLE_ID, '' as ROLE_DESC  "+ /* , e.abalph as ROLE_DESC, a.uluser as UserID */
					 " from sys7334.f0092 a left join proddta.f0101 b on a.ulan8 = b.aban8  inner join sys7334.f98owsec c on a.uluser = c.scuser "+
					 " left join proddta.f0101 e on a.ulan8 = e.aban8 where a.ulugrp <> '+LF00DIS01' and ulugrp <> '*GROUP' and a.uluser not in ('JDE','SUBSYSTEM','TSCH_APS','-LF00AFF01', "+
					 " '-LF00IML01','-LF00WDS01','-GB31BAT01','-CH09CSS02','TLF09GAN02','+SCH_PAL','+SCH_OTC', '+SCH_MFG','+SCH_FIN','TLF00ENQ01','+SCH_APS','DCLINKTS','DCLINKPD','DCLINKQA','WMETHODS', "+
					 " '+USSCH_FIN','TBE42ISO01','+US43PSB01','+US42SCH01','TUS42SCH01','TUS43PSB01','TUS09INQ01', 	'TUSSCH_FIN','TSCH_APS02','TML03ARA01','TML03ARD01','TML03CBS01','TEU42LOG01','+US31BAT01', "+
					 " 'WMETHODS1','TEU090901','TUS09PCA01','-SCH_MFG','-SCH_FIN','-SCH_OTC','-SCH_APS','-SCH_PAL', 'TML03CSP01','US00WME01','TGB09ICA01','TLF00TWS01','TLF00AFF01','TLF00DEV03','+SCH_LEO', "+
					 " '-SCH_LEO','TWSQA','TWSPD','@SCH_LEO','TSCH_MFG','TSCH_LEO','TLF00SUB01','TLF00WME01', 'TEU00ITS01','TLF00DEV01','TWSDV','TSCH_OTC','TAU41WHL01','TAU41WHO01','LFSOWSVCS', "+
					 " 'TCNCADMIN1','TCNCADMIN2','SUBSYS_US','TLF00HLP01','TML03CAR01','TLF09GAN01', 'TLF09GIN01','TLF09GFA01','TLF09GDI01','TLF00DSI02','TLF00SQA02','TLF00SEC01', "+
					 " 'TLF00DSI03','TLF09QDI01','TLF00BAS01','TLF00SEC02','TLF00IML01','TCH09CSS02', 'TLF00WDS01','TGB31BAT01','TCNCADMIND','TAU43SSS01','-SSSDEMO01','TLF00SUP01', "+
					 " 'TLF00SOX01','TSCH_QFIN','TSCH_QLEO','TSCH_QMFG','TSCH_QOTC','TEST12','TEST15','TEST16', 'TEST22','TEST26','TEST28','TEST35','TEST36','TEST37','WINTWSPD','WINTWSQA','SA-DCF-BPM', "+
					 " 'TCH00INQ01','TLF00DMO02','TEST34','TEST06','TEST11','TEST20','TCNCADMIN3','TCNCADMIN4', 'JDEPWR','TEST07','TEST30','TEST08','TEST01','TEST02','TEST09','TEST13','TEST21','TEST24', "+
					 " 'TEST29','TEST33','TUS31BAT01','TAU42MCL01','TAU42EMC01','TCH09FNZ01','TCH09OFA01','TCH09FMZ01', 'TLF00DMO03','TSCH_PAL','TAU31PMA01','TLF00QAB01','-SCH_OTC2','TSCH_FIN','TLFSNSITAS', "+
					 " 'TEST03','TEST04','TEST05','TEST10','TEST14','TEST17','TEST18','TEST23','TEST25','TEST27', 'TEST31','TEST32','TEST38','TEST39','TEST40','AJHA121','AJHA122','TLF00ANA01') "+
					 " order by USER_ID asc ";

		anmData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		return anmData;
	}



	@Override
	public List<SAPUserAccessModel> getJDEUserData(String templSysParam) throws SQLException, DataAccessException{
		log.info("Template Name : "+templSysParam);
		List<SAPUserAccessModel> usrData = new ArrayList<>();
		if("NA_JDEPLATFORM_Production_JDEANIMAS".equals(templSysParam)) {
			usrData =  getJDEANIMASData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEBWI".equals(templSysParam)) {
			usrData =  getJDEBWIData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDCF92".equals(templSysParam)) {
			usrData =  getJDEDCF92Data(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYEMEA".equals(templSysParam)) {
			usrData =  getJDEDEPUYEMEAData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYUS".equals(templSysParam)) {
			usrData =  getJDEDEPUYUSData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEEES".equals(templSysParam)) {
			usrData =  getJDEEESData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEETHICON".equals(templSysParam)) {
			usrData =  getJDEETHICONData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_JDEGMED".equals(templSysParam)) {
			usrData =  getJDEGMEDData(templSysParam);
		}else if("NA_JDEPLATFORM_Production_DSIBWI".equals(templSysParam)) {
			usrData =  getJDEDSIBWIData(templSysParam);
		}

		log.info("Total User Records returned for ("+templSysParam+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}

	private List<SAPUserAccessModel> getJDEDSIBWIData(String templSysParam) {
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		List<String> lines = Collections.emptyList();
		 try{
			 lines = Files.readAllLines(Paths.get(Constants.JDE_DSIBWI_USER_FILEPATH), StandardCharsets.UTF_8);
			 if(lines != null && !lines.isEmpty()) {
				 int i=0;
				 for(String str:lines) {
					 if(i>0) {
						 String[]dataArr = str.split(",");
						 SAPUserAccessModel sapMdl=new SAPUserAccessModel();
						 String wwid=dataArr[0].trim();
						 if(wwid.length() > 16  ) {
							 wwid=wwid.substring(0,15);
						 }
						 sapMdl.setWwid(wwid);
						 sapMdl.setNtId(wwid);
						 lstData.add(sapMdl);
					 }
					 i++;
				 }
			 }
		    }catch (Exception e)
		    {
		    	log.error("ERROR:"+e.getMessage(), e);
		    }

		return lstData;
	}

	private List<SAPUserAccessModel> getJDEGMEDData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = " select TO_CHAR(TRIM(' ' from b.abtax)) as WWID, a.uluser as NT_ID "+ /*, d.rlfrrole as GroupNamer,e.auroledesc as Description */
					 " from sy812.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sy812.f98owsec c on a.uluser = c.scuser "+
					 " left join Sy812.F95921 d on a.uluser = d.rltorole left join sy812.F00926 e on d.rlfrrole = e.auuser "+
					 " where a.uluser not in ('BIDSSCHED ', 'EMEA_DSI  ', 'JDE_PROD  ', 'OASRTE    ', 'OVISBE    ', 'PSPSCHED10', 'PSPSCHED11', 'PSPSCHED13', "+
					 " 'PSPSCHED14', 'PSPSCHED15', 'PSPSCHED2 ', 'PSPSCHED3 ', 'PSPSCHED4 ', 'PSPSCHED5 ', 'PSPSCHED6 ', 'PSPSCHED7 ', 'PSPSCHED8 ','PSPSCHED9 ', "+
					 " 'SAPPD01   ', 'SCHEDULE  ', 'SCHEDULE1 ', 'SCHEDULE2 ', 'SOAPE1PD  ', 'WME1PD    ', 'WME1PDH   ', 'WMRADIUSPD','WMRTPD    ', 'WMSNPPD   ') "+
					 " order by NT_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}

	private List<SAPUserAccessModel> getJDEETHICONData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = " select TO_CHAR(TRIM(' ' from b.abalky)) as WWID, a.uluser NT_ID "+ /*,a.ulugrp Groupname,e.abalph as Description */
					 " from sys7333.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sys7333.f98owsec c on a.uluser = c.scuser "+
					 " left join sys7333.f0092 d on a.ulugrp = d.uluser left join proddta.f0101 e on d.ulan8 = e.aban8 "+
					 " where a.ulugrp not in ('*GROUP') and a.uluser not in ('APSPOWER  ', 'BPPOWER   ', 'COMFGPWR  ', 'DSIUSER   ', 'DSIUSERP  ', "+
					 " 'DSIUSERQ  ', 'FINPOWER  ', 'JDE       ', 'JDEPWR    ', 'JDEUSER   ', 'JZMFGPWR  ', 'LSTPOWER  ', 'MAESTRO   ', 'MFGPOWER  ', "+
					 " 'MONITOR   ', 'MRPPOWER  ', 'OWSVCS    ', 'PLNPOWER  ', 'PROPOWER  ', 'SAETTST01 ', 'SAETTST02 ', 'SAMFGPWR  ', 'SCHEDULER ', "+
					 " 'SLMFGPWR  ', 'SOMFGPWR  ', 'STCPOWER  ', 'UNCPOWER  ', 'YMRPPOWER ') order by NT_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}

	private List<SAPUserAccessModel> getJDEEESData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = " select TO_CHAR(TRIM(' ' from TRIM(LEADING 'E' FROM b.abalky))) as WWID, TO_CHAR(TRIM(' ' from a.uluser)) as NT_ID "+ /*, d.rlfrrole as GroupName,e.auroledesc as Description */
					 " from sy810.F0092 a left join pddta.F0101 b on a.ulan8 = b.aban8 inner join sy810.f98owsec c on a.uluser = c.scuser "+
					 " left join Sy810.F95921 d on a.uluser = d.rltorole left join sy810.F00926 e on d.rlfrrole = e.auuser "+
					 " where a.uluser not in ('WMXPI_DV', 'WMXPI', 'DSI_QA', 'TST00WMX02', 'JOBSCH01', 'DSI_DV', 'JOBSCHMRP', 'JOBSCHMRP', 'EESOWSVC', "+
					 " 'DSI_PD', 'PSFT', 'PSFT', 'PSFT', 'PSFT', 'MONITORING', 'MONITORJUA', 'JOBSCH01', 'WMJABPI_PD', 'WMJABPI_DV', 'JDEPWR', 'WMJABPI_QA') ";

		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}

	private List<SAPUserAccessModel> getJDEDEPUYUSData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = " select a.abalky WWID, b.uluser NT_ID "+ /*, a.abalph Username, b.ulugrp GROUPNAME,a.aban8 AddressBookNum */
					 " from pddta.F0101 a,sys7333.F0092 b,sys7333.F98owsec c "+
					 " where a.aban8=b.ulan8 and b.uluser=c.scuser and a.abalky!=' ' and b.ulugrp not in ('*GROUP') ";

		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}

	private List<SAPUserAccessModel> getJDEDEPUYEMEAData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = " select b.abtx2 as WWID, a.uluser as NT_ID "+ /*, a.ulugrp as GroupName, e.abalph as Description */
					 " from SYS7333.F0092 a left join PRODDTA.F0101 b on a.ulan8 = b.aban8 inner join SYS7333.F98OWSEC c on a.uluser = c.scuser "+
					 " left join SYS7333.f0092 d on a.ulugrp=d.uluser left join PRODDTA.F0101 e on d.ulan8 = e.aban8 "+
					 " Where a.ulugrp not in('*GROUP') "+
					 " and a.uluser not in('BPMONITOR','CMWSCHED','DSI_PROD','GBPOST1','JDEPWR','JDE_PROD','SCHEDDRP1','SCHEDULER') "+
					 " order by NT_ID asc ";
		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}


	private List<SAPUserAccessModel> getJDEDCF92Data(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> lstData = new ArrayList<>();
		String qry = "  Select b.abtax as WWID, a.uluser as NT_ID "+ /*, d.rlfrrole as GroupName, e.auroledesc as Description */
					 " from sy920.f0092 a left join proddta.f0101 b on a.ulan8 = b.aban8 inner join sy920.f98owsec c on a.uluser = c.scuser "+
					 " left join sy920.f95921 d on a.uluser = d.rltorole left join sy920.f00926 e on d.rlfrrole =  e.auuser where d.rlfrrole <> '+LF00DIS01'  "+
					 " and a.uluser not in ('-LF00WDS01','SUBSYS_US','TGB55MIN01','TAU03CAR01','TAU41WHO01','TAU42DRS01', 'TAU42WSO01','TCNCADMIN3','TCNCADMIN4','TSCH_PAL','TSCH_QLEO','TSCH_QMFG','TUK42CUS01', "+
					 " 'TUS09HIS01','TUS09INQ01','TML03ARD01','TPR41WHS01','TPR43SSS01','TPT09FAS01','TGB43SSS01', 'TIB09FIN01','TIB42CSS01','TIT09FAS02','TIT09FIN01','TLF00IML01','TLF00SQA02','TLF00SUB01', "+
					 " 'TLF00QAB01','TLF09GDI01','TLFSNSITAS','SA-DCF-BPM','-SCH_OTC2','-CH09CSS02','-SCH_LEO', '-SCH_PAL','TEST19','TAF43CPM01','TLF09GIN01','TPR09FIN01','TCH09FAZ01','TAG30MPL01', "+
					 " 'TEST16','TEST20','TEST23','TEST31','LFSOWSVCS','LFSOWSVCS','LFSOWSVCS','TAG43APV01', 'LFSOWSVCS','LFSOWSVCS','LFSOWSVCS','LFSOWSVCS','TAG30MFO01','TAG43IQC02','TAU41WHL01', "+
					 " 'TAG43QOC01','TAU31MOP01','TAU31PMA01','TAU42AOO01','TAU42CSS01','TBL09FIN01','TSCH_MFG', 'TSCH_QFIN', 'TUK09FAS01', 'TUK09FIN01', 'TUS31BAT01', "+
					 " 'TUS42SCH01', 'TUS43PSB01', 'TUSSCH_FIN', 'TEU00ITS01', 'TEU090901', 'TEU09FAS01', 'TEU42LOG01', 'TFR09FIN01', 'TGB09FNM01', 'TWSDV', "+
					 " 'TEST22', 'TLF00SUP01', 'TSCH_OTC', 'TGB09ICA01', 'TEST37', 'TSCH_QOTC', 'TEST35', 'TEST36', 'TEST39', 'TEST40', 'TGB30HQS01', 'TGB31BAT01', "+
					 " 'TLF09GAN02', 'TEST30', 'JDEPWR', '-SCH_APS', '-SSSDEMO01', 'TEST21', 'WMETHODS', 'TES09FAS03', 'TEST02', 'TEST03', 'TEST06', 'TEST07', "+
					 " 'TEST12', 'TAU43PPR01','TLF00DMO03','TAU43QTY01','-SCH_FIN','-SCH_MFG','TEST27','TCH09CSS02','-SCH_OTC','@SCH_LEO','TEST11','TAU09FIM01', "+
					 " 'TLF00DMO02','JDE','TML03CBS01','-US43PSB01','-USSCH_FIN','TEST10','TEST01','-GB31BAT01','-US42SCH01','TCZ09FIN01','TES42CUS01','TEST05', "+
					 " 'TEST09','TAU31MSU01','TAU42DRG01','TAG30STT01','TAU31MIN01','TAU42WSL01','TAU43SSS01','TBE42ISO01','TBE42LSI01','TPT09FIN01','TPT42CUS01', "+
					 " 'TLF00AFF01','TLF00ENQ01','TLF00SEC02','TLF00TWS01','TLF00WDS01','TLF00WME01','TLF09GAN01','TLF09HIS01','TLF30INQ01','TLF43QTC01','TML03ARA01', "+
					 " 'TCH09OFA01','TCH09FMZ01','TAF09OFA01','TCH09FNZ01','TEST13','TEST15','TEST17','TEST18','TEST32','-US31BAT01','TEST29','TEST26','TEST38', "+
					 " 'TSCH_LEO','TGB09FSA01','TGB30HQF01','TLF00DSI03','TLF00HLP01','TCH43CPM01','-LF00AFF01','TSCH_APS','TCH43PLB03','TEST33','TEST24','TEST34', "+
					 " 'TEST28','SUBSYSTEM','TLF00SOX01','TWSQA','TAU42EMC01','TLF00DEV03','TLF00DEV01','TLF00BAS01','TUK42CSS01','TUS38ACS01','TML03CAR01','TML03CSP01', "+
					 " 'TPA42CUS01','TPR41WHL01','TPR41WHO01','TPR43BPL01','TPR43PLB02','TPT00INQ01','TSCH_APS02','TLF00ANA01','TLF00DSI02','TLF09GFA01','TLF00SEC01', "+
					 " 'TEST14','TEST25','TCZ00INQ01','TEST04','TEST08','TSCH_FIN','WINTWSPD','TWSPD','-LF00IML01','TAF43PLB03','US00WME01','WMETHODS1','WINTWSQA') ";

		lstData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return lstData;
	}

	private List<SAPUserAccessModel> getJDEBWIData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> bwiData = new ArrayList<>();
		String qry = " select TO_CHAR(trim(LEADING '0' from TRIM(' ' from TRIM(LEADING 'W' FROM b.abtax)))) as WWID, a.uluser as NT_ID "+ /*,  d.rlfrrole as GroupNamer,e.auroledesc as Description */
					 " from sy920.F0092 a left join proddta.F0101 b on a.ulan8 = b.aban8 inner join sy920.f98owsec c on a.uluser = c.scuser "+
					 " left join sy920.F95921 d on a.uluser = d.rltorole left join sy920.F00926 e on d.rlfrrole = e.auuser "+
					 " where d.rlfrrole not in ('_LDAPROLE') "+
					 " and a.uluser not in ('CNCTL     ', 'CNDTA     ', 'JDE       ', 'JDE       ', 'PFTEST001 ', 'PFTEST002 ', 'PFTEST003 ', 'PFTEST004 ', 'PFTEST005 ', 'PFTEST006 ', 'PFTEST007 ', 'PFTEST008 ', 'PFTEST009 ', 'SABWIMEPDV', 'SABWIMEPPD', 'SABWIMEPPY', 'SABWIMEPQA', 'SABWIMON  ', 'SABWIMRP1 ', 'SABWISCH01', 'SABWISCH02', 'SABWITEST1', 'SABWITEST2', 'SABWITEST3', 'SABWITEST4', 'SABWITEST5', 'SABWITEST6', 'SABWITEST7', 'SABWITEST7', 'SABWITEST8', 'SABWITEST8', 'SABWITEST9', 'SABWITST10', 'SABWITST11', 'SABWITST12', 'SABWIWM01 ', 'SABWIWM02 ', 'SABWIWM03 ', 'SABWIWM04 ', 'SABWIWM05 ', 'SABWIWMDEV', 'SABWIWMSUP') "+
					 " order by NT_ID asc ";
		bwiData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return bwiData;
	}


	private List<SAPUserAccessModel> getJDEANIMASData(String templSysParam) throws SQLException, DataAccessException{
		List<SAPUserAccessModel> anmData = new ArrayList<>();
		String qry = " Select b.abalky as WWID,a.uluser as NT_ID "+ /*, a.ulugrp as GroupName, e.abalph as Description*/
					 " from sys7334.f0092 a left join proddta.f0101 b on a.ulan8 = b.aban8 "+
					 " inner join sys7334.f98owsec c on a.uluser = c.scuser "+
					 " left join proddta.f0101 e on a.ulan8 = e.aban8 where a.ulugrp <> '+LF00DIS01' and ulugrp <> '*GROUP' "+
					 " and a.uluser not in ('@SCH_LEO','+SCH_APS','+SCH_FIN','+SCH_LEO','+SCH_MFG','+SCH_OTC','+SCH_PAL','+US31BAT01', "+
					 " '+US42SCH01','+US43PSB01','+USSCH_FIN','-CH09CSS02','-GB31BAT01','-LF00AFF01','-LF00WDS01','-SCH_APS','-SCH_FIN', "+
					 " '-SCH_LEO','-SCH_MFG','-SCH_OTC','-SCH_OTC2','-SCH_PAL','-SSSDEMO01','TWSDV','TWSPD','TWSQA','US00WME01','WINTWSPD', "+
					 " 'WINTWSQA','WMETHODS','WMETHODS1','DCLINKPD','DCLINKQA','DCLINKTS','JDE','JDEPWR','LFSOWSVCS','SA-DCF-BPM', 'SUBSYSTEM','SUBSYS_US') ";
		anmData = getJdbcTemplateFact(templSysParam).query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SAPUserAccessModel.class));
		return anmData;
	}



	@Override
	public List<String> getAllValidUsers(String templSysParam) throws JCoException {
		log.info("Gell All Users for Template Name : "+templSysParam);
		List<String> usrData = new ArrayList<>();
		JCoDestination destination = null;//getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR02");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        //log.debug("Setting OPTIONS");
        Date date = new Date(1410152400000L);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = formatter.format(date);
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USTYP EQ 'A'");
        log.debug("Setting QUERY FIELDS");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGV");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGB");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USTYP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "CLASS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UFLAG");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "ERDAT");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                /*Object sValue = sMessage.trim();
                if ((sValue instanceof Date)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
                    sValue = sdf.format(sValue);
                }*/
                String[] dataArr = sMessage.trim().split(",");
                if(!usrData.contains(dataArr[0].trim())) {
                	usrData.add(dataArr[0].trim());
                }
                //log.info("BNAME > " + dataArr[0]+" GLTGV > "+dataArr[1]+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]);
            }
        }
        log.info("Total User Records returned(SAP-USR02 - "+"templSysParam"+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}


	@Override
	public List<String> getUsersRoles(String user, String templSysParam) throws JCoException {
		//log.info("getUsersRoles() for Template Name : "+templSysParam+ " - User :"+user);
		List<String> rlsData = new ArrayList<>();
		JCoDestination destination = null;//getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                if(!rlsData.contains(dataArr[1].trim())) {
                	rlsData.add(dataArr[1].trim());
                }
                //log.info("UNAME > " + dataArr[0]+" AGR_NAME > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}


	@Override
	public String getRoleDescription(String role, String templSysParam) throws JCoException {
		//log.info("ROLE NAME: "+role+"  Template Name : "+templSysParam);
		String rlsdesc = "";
		JCoDestination destination =null;// getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        //function.getImportParameterList().setValue("QUERY_TABLE", "AGR_DEFINE");
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_TEXTS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AGR_NAME EQ '"+role+"'");

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
       /* returnFields.appendRow();
          returnFields.setValue("FIELDNAME", "\'TEXT\'");*/

        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.debug("getRoleDescription() Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
        	for (int iRow = 0; iRow < numRows; iRow++) {
        		jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                //log.debug(1+". AGR_NAME & ROLE DESC  > "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                if(dataArr != null && dataArr.length >0) {
                	if(dataArr.length>3 && dataArr[3].equals("00000"))
                	rlsdesc = dataArr[(dataArr.length - 1)].trim();
                	break;
                }
                //log.info("AGR_NAME > " + dataArr[0]+" PARENT_AGR > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
        }
       }
        //log.debug("ROLE: "+role+" ROLE DESC : "+rlsdesc);
		return rlsdesc;
	}






	@Override
	public String getUsersPersonNumber(String user, String templSysParam) throws JCoException {
		//log.info("Template Name : "+templSysParam+" User:"+user);
		String usrPrsn = "";
		JCoDestination destination = null;//getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR21");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "BNAME EQ '"+user+"'");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        /*returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");*/
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "PERSNUMBER");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                usrPrsn= sMessage.trim();

            }
        }
        //log.info("User Records : "+user+" : "+usrPrsn);
        return usrPrsn;
	}

	@Override
	public String getUsersWwId(String prsnNumber, String templSysParam) throws JCoException	{
		//log.info("Template Name : "+templSysParam+" prsnNumber:"+prsnNumber);
		String wwid = "";
		JCoDestination destination = null;//getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "ADRP");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "PERSNUMBER EQ '"+prsnNumber+"'");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "SORT1");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "SORT2");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                ///ADD A condition to check both fields for Data
                String[] msgArr =sMessage.split(",");
                if(msgArr[0].trim().length() > 0) {
                	wwid= msgArr[0].trim();
                }else if(msgArr.length > 1) {
                	wwid= msgArr[1].trim();
                }
            }
        }
        //log.info("User Person Number: "+prsnNumber+" WWID: "+wwid);
        return wwid;
	}













	/*public List<HanaRoleUserPrivilegeMdl> getRolePrivilegeData(String templSysParam, String roleNames) throws SQLException, DataAccessException {
		log.info("Gathering ROLE + PRIVILEGE Data for : roleNames : "+roleNames+" templSysParam: "+templSysParam);
		String[] newRoleNames=null;

		List<HanaRoleUserPrivilegeMdl> rlPrivData = new ArrayList<HanaRoleUserPrivilegeMdl>();
			StringBuilder sqlB = new StringBuilder();
			sqlB.append(" SELECT GRANTEE_SCHEMA_NAME, GRANTEE, GRANTEE_TYPE, GRANTOR, OBJECT_TYPE, SCHEMA_NAME, OBJECT_NAME, COLUMN_NAME, PRIVILEGE, IS_GRANTABLE, IS_VALID ");
			sqlB.append(" FROM SYS.GRANTED_PRIVILEGES ");
			sqlB.append(" WHERE GRANTEE_TYPE='ROLE' AND GRANTEE <> 'PUBLIC' ");
			if(null !=roleNames && roleNames.length() >0) {
				newRoleNames = roleNames.split(",");
				if(newRoleNames != null ) {
					if(newRoleNames.length == 1) {
						sqlB.append(" AND GRANTEE='"+newRoleNames[0]+"' ");
					}else {
						sqlB.append(" AND GRANTEE in (");
						for(int i=0; i<newRoleNames.length;i++) {
							sqlB.append(" '"+newRoleNames[i]+"' ");
							if(i<(newRoleNames.length -1)) {
								sqlB.append(", ");
							}
						}
						sqlB.append(" )");
					}
				}
			}
			sqlB.append(" ORDER BY GRANTEE_TYPE ");
			if(null==templSysParam || templSysParam.length()== 0) {
				//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
				rlPrivData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaRoleUserPrivilegeMdl>(HanaRoleUserPrivilegeMdl.class));
			}else {
				rlPrivData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaRoleUserPrivilegeMdl>(HanaRoleUserPrivilegeMdl.class));
			}
			log.info("Total rows returned : "+((rlPrivData !=null) ? rlPrivData.size():"0"));
			//rlPrivData.forEach(c->{System.out.println(c);});
			return rlPrivData;

	}


	@Override
	public List<HanaRoleUserPrivilegeMdl> getUserDirectPrivilegeData(String templSysParam) throws SQLException, DataAccessException {
		log.info("Gathering ROLE + PRIVILEGE Data for USER on System:  "+templSysParam);
		List<HanaRoleUserPrivilegeMdl> rlPrivData = new ArrayList<HanaRoleUserPrivilegeMdl>();
			StringBuilder sqlB = new StringBuilder();
			sqlB.append(" SELECT GRANTEE_SCHEMA_NAME, GRANTEE, GRANTEE_TYPE, GRANTOR, OBJECT_TYPE, SCHEMA_NAME, OBJECT_NAME, COLUMN_NAME, PRIVILEGE, IS_GRANTABLE, IS_VALID ");
			sqlB.append(" FROM SYS.GRANTED_PRIVILEGES ");
			sqlB.append(" WHERE GRANTEE_TYPE='USER' AND GRANTEE NOT LIKE '%SYS%' ");
			sqlB.append(" ORDER BY GRANTEE ");
			if(null==templSysParam || templSysParam.length()== 0) {
				//grntData = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaUserGrantModel>(HanaUserGrantModel.class));
				rlPrivData = getJdbcTemplateSANDBOX_Sandbox_Sandbox1().query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaRoleUserPrivilegeMdl>(HanaRoleUserPrivilegeMdl.class));
			}else {
				rlPrivData = getJdbcTemplateFact(templSysParam).query(sqlB.toString(), new Object[] {}, new BeanPropertyRowMapper<HanaRoleUserPrivilegeMdl>(HanaRoleUserPrivilegeMdl.class));
			}
			log.info("Total User rows returned : "+((rlPrivData !=null) ? rlPrivData.size():"0"));
			//rlPrivData.forEach(c->{System.out.println(c);});
			return rlPrivData;
	}


*/


}
