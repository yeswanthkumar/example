package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;

@Data
public class ProjectApprCatgMdl {
	private int 	projId;
	private int 	seqId;
	private String 	projCatgDesc;
	private String  approverId;
	private String 	email;
	private String 	ownerApprReqd;
	private Date   	updatedDt;

	@Override
	public String toString() {
		return "ProjectApprCatgMdl [projId=" + projId + ", seqId=" + seqId + ", projCatgDesc=" + projCatgDesc
				+ ", approverId=" + approverId + ", email=" + email + ", ownerApprReqd=" + ownerApprReqd
				+ ", updatedDt=" + updatedDt + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ProjectApprCatgMdl other = (ProjectApprCatgMdl) obj;
		if (approverId == null) {
			if (other.approverId != null)
				return false;
		} else if (!approverId.equals(other.approverId))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (ownerApprReqd == null) {
			if (other.ownerApprReqd != null)
				return false;
		} else if (!ownerApprReqd.equals(other.ownerApprReqd))
			return false;
		if (projCatgDesc == null) {
			if (other.projCatgDesc != null)
				return false;
		} else if (!projCatgDesc.equals(other.projCatgDesc))
			return false;
		if (projId != other.projId)
			return false;
		if (seqId != other.seqId)
			return false;
		if (updatedDt == null) {
			if (other.updatedDt != null)
				return false;
		} else if (!updatedDt.equals(other.updatedDt))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((approverId == null) ? 0 : approverId.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((ownerApprReqd == null) ? 0 : ownerApprReqd.hashCode());
		result = prime * result + ((projCatgDesc == null) ? 0 : projCatgDesc.hashCode());
		result = prime * result + projId;
		result = prime * result + seqId;
		result = prime * result + ((updatedDt == null) ? 0 : updatedDt.hashCode());
		return result;
	}






















}
