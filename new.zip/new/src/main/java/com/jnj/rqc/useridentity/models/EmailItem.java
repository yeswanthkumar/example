package com.jnj.rqc.useridentity.models;

import lombok.Data;

@Data
public class EmailItem {
	private String code;
	private String id;
	private String name;
}
