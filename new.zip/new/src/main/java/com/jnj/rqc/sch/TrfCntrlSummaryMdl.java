package com.jnj.rqc.sch;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TrfCntrlSummaryMdl {
	private String 	region;
	private String 	platform;
	private String 	environment;
	private String 	system;
	private int 	createdRecCount;
	private Date 	createdDt;
	private String 	createdBy;
	private String 	collStatus;
	private String  expStatus;
	private Date	expDt;
	private int		expRecCount;
	private String	expBy;
	private String comments;


	@Override
	public String toString() {
		return "TrfCntrlSummaryMdl [region=" + region + ", platform=" + platform + ", environment=" + environment
				+ ", system=" + system + ", createdRecCount=" + createdRecCount + ", createdDt=" + createdDt
				+ ", createdBy=" + createdBy + ", collStatus=" + collStatus + ", expStatus=" + expStatus + ", expDt="
				+ expDt + ", expRecCount=" + expRecCount + ", expBy=" + expBy + " , comments=" + comments + "]";
	}



}


