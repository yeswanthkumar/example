package com.jnj.rqc.reportwriter;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.CSIFunctionActionModel;
import com.jnj.rqc.conflictModel.CSIFunctionPermModel;
import com.jnj.rqc.conflictModel.CSISodCriticalActRiskModel;
import com.jnj.rqc.conflictModel.CSISodRiskModel;
import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.conflictModel.HanaDBRiskModel;
import com.jnj.rqc.conflictModel.HanaRole2SodModel;
import com.jnj.rqc.conflictModel.HanaUser2SodModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.conflictModel.RoleToSodModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.UserToSodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.AppRoutingModel;
import com.jnj.rqc.models.BstMetricsModel;
import com.jnj.rqc.models.JJEDsUserLookupMdl;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.models.UserTerminationReportModel;
import com.jnj.rqc.reportmodels.AppRoles;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.reportmodels.ReqLogModel;
import com.jnj.rqc.ruleset.models.RuleSetModel;
import com.jnj.rqc.ruleset.models.RuleSetSmryModel;
import com.jnj.rqc.terminations.models.AppStatusModel;
import com.jnj.rqc.terminations.models.TerminationModel;

import au.com.bytecode.opencsv.CSVWriter;

@Service
public class CSVReportWriter {
	static final Logger log = LoggerFactory.getLogger(CSVReportWriter.class);

	public String writeCSVReview(List<MemRevieModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "ACCOUNT NAME,ACC FIRST COLLECTED,LAST CCOLLECTED,WWID,FULL NAME,NETWORK ID,EMAIL ADDRESS,TITLE,DEPARTMENT,GRP SHORT NAME,GROUP NAME,GROUP,ROLE,DATE ADDED, SOD CODE,TICKET NUMBER, ASSIGNER NAME, SELF ADMIN, MEM SEC TEAM, ROLES MATCH TKT".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeCSVBstReview(List<BstMetricsModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "DATE,USER ID, FIRST VARIABLE VALUE FOR EVENT".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



	public String writeCSV(List<SrcSysMemRoleModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "SRC_SYS,MEM WWID,FIRST NAME,LAST NAME,NETWORK ID,MGR WWID,APPL ROLE,SOD CODE,RQC TKT,ASSIGNER NAME".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeCSIUser2SodCSV(List<UserToSodModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_USER2SOD.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeCSIRole2SodCSV(List<RoleToSodModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_ROLE2SOD.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeHanaUser2SodCSV(List<HanaUser2SodModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.HANA_USER2SOD.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeHanaRole2SodCSV(List<HanaRole2SodModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.HANA_ROLE2SOD.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeHanaConflictMatrixCSV(List<HanaDBRiskModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.HANA_CONF_MATRIX.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeCSISodRiskCSV(List<CSISodRiskModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_SODRISK.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



	public String writeCSISodCriticalActRiskCSV(List<CSISodCriticalActRiskModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_CRI_ACT_RISK.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeCSISodFunctionActCSV(List<CSIFunctionActionModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_FUNC_ACT_DATA.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeCSISodFuncPermissionCSV(List<CSIFunctionPermModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.CSI_FUNC_PERM_DATA.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeTerminationCSVReport(List<TerminationModel> data, String fileName) {
		String filePath = "";
		try {
		 File csvFile = new File(fileName);
		 filePath = csvFile.getAbsolutePath();
		 log.info("Writing CSV file :"+filePath);
		 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
		 //String [] header = "CR Name,Nags Application,Request Type,Account Owner,Account Name,Account Status,Resource Name,Group Name,CR Status,CR Date Opened,CR Date Completed,NOTES, APP ROLE,SRC_SYS,DATE UPDATED,STATUS, JJEDS UPDT DT,JJEDS STATUS".split(",");
		 String [] header = "CR Name,Nags Application,Request Type,Account Owner,Account Name,Account Status,Resource Name,Group Name,CR Status,CR Date Opened,CR Date Completed,NOTES, SRC_SYS,DATE UPDATED,STATUS, JJEDS UPDT DT,JJEDS STATUS,JJEDS_TERM_DT".split(",");
		 writer.writeNext(header);
		 for(TerminationModel cd: data){
			 List<AppStatusModel> appLst = cd.getAppstat();
			 String [] mstArr = cd.getData().split("~");
			 if(appLst == null || appLst.isEmpty()) {
			 	 AppStatusModel amdl = new AppStatusModel();
				 //amdl.setApplRole("");
				 amdl.setUpdateDt(null);
				 amdl.setSrcSys("");
				 amdl.setEmpStatus("NOT FOUND");
				 amdl.setJjedsStatus("NOT FOUND");
				 appLst.add(amdl);

			 }
			 for(AppStatusModel appMdl : appLst) {
				 String[] childArr = appMdl.getData().split("~");
				 String [] combined = ArrayUtils.addAll(mstArr, childArr);
				 writer.writeNext(combined);
				 break;

			 }
		 }
		 writer.close();
		} catch (Exception e) {
			log.error("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeUserCSVReport(List<UserSearchModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "WWID,NETWORK ID,FIRST NAME,LAST NAME,EMPSTATUS,HIRE DATE,TERMINATION DATE,EMAIL,DEPT CD,DEPT NAME,TELEPHONE,LOCATION,MGR WWID ".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeAllUserCSVReport(List<JJEDsUserLookupMdl> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "USER WWID,USER NTID,USER NAME,USER EMAIL,MGR WWID,MGR NTID,MGR NAME,MGR EMAIL,STATUS".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



	public String writeConfCSVReport(String fileName, List<MatrixModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "WWID,SOD CD1,SOD CD2,APP1,APP2,CONFLICTING ROLES,MITIGATING CONTROL".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeUserRolesCSVReport(String fileName, List<PersonalSysModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "WWID,USER ID,FIRST NAME,LAST NAME,SOD CODE,ACCESS ROLE,CO,SRC SYSTEM,USER TYPE,JOB,WAIVERS".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeSystemCdCSVReport(String fileName, List<SystemCodeModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "SOURCE SYSTEM,ACCESS ROLE,SOD CODE".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeConflictMatrixCSVReport(String fileName, List<MatrixModel> matrixList) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "SR NO,ROLE1,ROLE2,APP2,APP2,CONFLICT,MITIGATING CONTROL".split(",");
			 writer.writeNext(header);
			 matrixList.forEach(cd ->{
				 String [] record = cd.getData().split("~");
				 record[0]="";
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }




	public String createRQCCSVReport(String fileName, List<ReportDataModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 //dtCreated + "~" +ticktNo + "~" + reqNm + "~" + reqWwid + "~"	+ assocNm + "~" + assocWwid + "~" + assocNtId + "~" + mgrWwid+ "~" + mgrNm + "~" + busnJstn + "~" + addCmnts;
			 String [] header = "DATE CREATED,TICKET NUMBER,REQUESTOR NAME,REQUESTOR WWID,ASSOC NAME, ASSOC WWID,ASSOC NTID, MGR WWID,ASSOC MGR,BUSINESS JUSTIFICATION,ADDITIONAL COMMENTS,ROLES,ADDITIONAL INFO, CMNT DATE,CMNT USERID,CMNT NAME,COMMENTS".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
				 String [] empty = new String[record.length]; //Used to represent empty rows
				 List<AppRoles> roles = (cd.getRoles() == null || cd.getRoles().isEmpty())? new ArrayList<>() : cd.getRoles();
				 List<ReqLogModel> reqLogs =(cd.getReqLogs() == null || cd.getReqLogs().isEmpty())? new ArrayList<>() : cd.getReqLogs();
				 String [] cRolData = new String[2];
				 String[] cLogData  = new String[4];
				 if(roles.size() > reqLogs.size()){
					 for(int i=0; i<roles.size();i++) {
						 cRolData = roles.get(i).getDataCSV().split("~");
						 cLogData = (reqLogs.size() >=(i+1)) ? reqLogs.get(i).getDataCSV().split("~"):new String[4] ;
						 String[] tktData = (i==0)? ArrayUtils.addAll(ArrayUtils.addAll(record,cRolData), cLogData):ArrayUtils.addAll(ArrayUtils.addAll(empty,cRolData), cLogData);
						 writer.writeNext(tktData);
					 }
				 }else if(reqLogs.size() > roles.size()){
					 for(int i=0; i<reqLogs.size();i++) {
						 cLogData = reqLogs.get(i).getDataCSV().split("~");
						 cRolData = (roles.size() >=(i+1))?roles.get(i).getDataCSV().split("~") : new String[2];
						 String[] tktData = (i==0)? ArrayUtils.addAll(ArrayUtils.addAll(record,cRolData), cLogData) : ArrayUtils.addAll(ArrayUtils.addAll(empty,cRolData), cLogData);
						 writer.writeNext(tktData);
					 }
				}else if(reqLogs.size() == roles.size()){
					if(roles.size() > 0) {
						for(int i=0; i<roles.size();i++) {
							 cRolData = roles.get(i).getDataCSV().split("~");
							 cLogData = (reqLogs.size() >=(i+1)) ? reqLogs.get(i).getDataCSV().split("~"):new String[4] ;
							 String[] tktData = (i==0)? ArrayUtils.addAll(ArrayUtils.addAll(record,cRolData), cLogData):ArrayUtils.addAll(ArrayUtils.addAll(empty,cRolData), cLogData);
							 writer.writeNext(tktData);
						 }
					}else {
						 String[] tktData = ArrayUtils.addAll(ArrayUtils.addAll(record,new String[2]), new String[4]);
						 writer.writeNext(tktData);
					}
				}
			 });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeRuleSetCSVReport(List<RuleSetModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "APP1,APP2,ROLE1,ROLE2,MITIGATING CONTROL".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


		/**
		 * Method  : CSVReportWriter.java.writeRuleSetSummaryReport()
		 *		   :<b>@param data
		 *		   :<b>@param fileName
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Sep 7, 2022 11:47:57 AM
		 * Purpose : Writing RuleSet Review Summary
		 * @return : String
		 */
	public String writeRuleSetSummaryReport(List<RuleSetSmryModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "APP1,APP2,REC COUNT,FILE,DATE CREATED, QUERY, ".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String createRoutingCSVReport(String fileName, List<AppRoutingModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing Routing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "CATEGORY,ROLE,ROLE_ACTION,EMAILs".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }




	public String writeTerminationMonthlyCSVReport(List<UserActivityModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "USER_ID,FIRST_NAME,LAST_NAME,ROLE,SRC_SYS,EMP_ACTIVE, DT_UPDATED".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeUserTermCSVReport(List<UserTerminationReportModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 //String [] header = "APP NAME,USER ID,WWID, NAME,TOTAL RECORDS (Duplicates),UNIQUE RECORDS,USER STATUS, DUPLICATES (Y/N),COMMENTS".split(",");
			 //String [] header = "APP NAME,USER ID,WWID, NAME,TOTAL RECORDS (with Duplicates),USER STATUS,DUPLICATES (Y/N),RECORD FROM APPLICATION(Y/N),COMMENTS".split(",");
			 String [] header = "APPLICATION NAME,USER ID,WWID,FULL NAME IN JJEDS,TOTAL RECORDS (with Duplicates),USER STATUS(JJEDS),DATA/RECORD FROM APPLICATION(Y/N),FULL NAME IN APPLICATION,COMMENTS".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	//START JDA CSV REPORTS

	public String writeJDATechRolesCSVReport(String fileName, List<StrKeyValPair> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "ROLE_NAME, TECH_NAME".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeJDAUserRolesCSVReport(String fileName, List<JDAPersonalSysMdl> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.JDA_USER_ROLES_HEADER.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeJDAConfCSVReport(String fileName, List<JDAUser2SodModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.JDA_INTRA_CONFLICT_HEADER.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeJDACrossAppConfCSVReport(String fileName, List<JDACrossAppMatrixModel> data) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.JDA_CROSSAPP_CONFLICT_HEADER.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeJDAItraMatrixCSVReport(String fileName, List<JDADBRiskModel> matrixList) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.JDA_INTRA_CONFMATRIX_HEADER.split(",");
			 writer.writeNext(header);
			 matrixList.forEach(cd ->{
				 String [] record = cd.getData().split("~");
				 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeJDACrossAppMatrixCSVReport(String fileName, List<JDACrossAppMatrixModel> matrixList) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.JDA_CROSSAPP_CONFLICT_HEADER.split(",");
			 writer.writeNext(header);
			 matrixList.forEach(cd ->{
				 String [] record = cd.getData().split("~");
				 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	//END JDA CSV


	//SAP GAA CSV START

	public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.SAP_GAA_USER2ROLE.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeSapGaaUserAccessCSV(List<SAPUserAccessModel> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.SAP_GAA_TRFCNTRL.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public String writeGenesisSignedOfCSV(List<SapDataTransferReportMdl> data, String fileName) {
		String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.GEN_SO_TRFREPORT.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	}


	public String writeGenesisU2RSignedOfCSV(List<SapUser2RoleReportMdl> data, String fileName) {
		String filePath = "";
		 try{
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.GEN_SO_U2RREPORT.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
	 return filePath;
	}

	public String writeGenesisU2RDeltaCSV(List<SapUser2RoleDeltaMdl> data, String fileName) {
		String filePath = "";
		 try{
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = Constants.GEN_DELTA_U2RREPORT.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
	 return filePath;
	}


	public String writeCSMArchieveCSV(List<CSMHistDataMdl> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSM CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "Display Name,Parent,Code, First Name,Last Name,WwId,Email,Status, AD Group,Effective Date, Valid From,Valid To".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }

	public String writeCSMModelCSV(List<CSMModelAdGrpMap> data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CSM CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "AD Group,Model Name,Updated Date,Updated By".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }




}
