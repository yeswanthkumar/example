package com.jnj.rqc.dbextr.models;


import lombok.Data;


@Data
public class F983051Mdl {
	private String  vRPID;
	private String  vRVERS;
	private String  vRREPORTID;
	private String  vRVERSIONID;
	private String  vRJD;
	private String  vREXCL;
	private String  vRUSER;
	private String  vRVCD;
	private String  vRVED;
	private String  vRPROPTMID;
	private String  vRPOID;
	private String  vROPCR;
	private String  vRVLISTMODE;
	private String  vRVERTXTID;
	private String  vRCHKOUTSTS;
	private String  vRCHKOUTDAT;
	private String  vRUSR0;
	private String  vRVRSAVAIL;
	private String  vRENHV;
	private String  vRMKEY;
	private String  vRPODATA;
	private String  vRDSTNM;
	private String  vRVCC1;
	private String  vRVCC2;
	private String  vRVCC3;
	private String  vRVCC4;
	private String  vRVCC5;
	private String  vRFRMTSTR;

	public String getData() {
		return  vRPID + "~" +vRVERS + "~" + vRREPORTID + "~" +vRVERSIONID + "~" + vRJD + "~"+vREXCL+"~"+vRUSER+"~"+vRVCD+"~"+vRVED+"~"+vRPROPTMID
				+"~"+vRPOID+"~"+vROPCR+"~"+vRVLISTMODE+"~"+vRVERTXTID+"~"+ vRCHKOUTSTS+"~"+vRCHKOUTDAT+"~"+vRUSR0+"~"+vRVRSAVAIL+"~"+vRENHV+"~"+vRMKEY
				+"~"+vRPODATA+"~"+vRDSTNM+"~"+vRVCC1+"~"+vRVCC2+"~"+vRVCC3+"~"+vRVCC4+"~"+vRVCC5+"~"+vRFRMTSTR;
	}

}
