package com.jnj.rqc.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppRoutingModel implements Serializable, Comparable<AppRoutingModel>{
	private static final long serialVersionUID = 1L;
	private int grpDisplay;
	private int roleDisplay;
	private String category;
	private String role;
	private String roleAction;
	private String email;

	public String getData() {
		return category + "~"+ role + "~" + roleAction + "~" + email ;
	}

	@Override
	public int compareTo(AppRoutingModel o) {
		return this.getCategory().compareTo( o.getCategory());
	}


	@Override
	public String toString() {
		return "AppRoutingModel [grpDisplay=" + grpDisplay + ", roleDisplay=" + roleDisplay + ", category=" + category
				+ ", role=" + role + ", roleAction=" + roleAction + ", email=" + email + "]";
	}
}
