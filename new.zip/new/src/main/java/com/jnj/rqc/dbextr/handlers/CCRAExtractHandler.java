package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.CcraExtractMdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class CCRAExtractHandler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(CCRAExtractHandler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: SOD_EXTR.CCRA_EXTR_MV ");
		String filePath = "";
		List<CcraExtractMdl> dataList = getCCRAExtrData();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("CCRA_CONVERSION", dataList);
		}
		return filePath;
	}


	private List<CcraExtractMdl> getCCRAExtrData() throws SQLException, DataAccessException{
		List<CcraExtractMdl> dataList = dBExtrDao.getCCRAExtractData();
		return dataList;
	}


	private String createCSVReport(String fileName, List<CcraExtractMdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CCRA_CONVERSION CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "USER ID,USER FIRST NM,USER LAST NM,STAT,ROLE NM".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
