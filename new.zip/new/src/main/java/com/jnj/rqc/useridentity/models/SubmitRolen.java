package com.jnj.rqc.useridentity.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubmitRolen {
	private String ROLE_ID = "";
	private String ROLE_TYPE = "";
	private String ROLE_TYPE_DESC = "";
	private String ACCESS_TYPE = "";
	private String ROLE_NAME = "";
	private String SYSTEM = "";
	private String BUSINESS_PROCESS = "";
	private String FUNCTIONAL_AREA = "";
	private String COMPANY = "";
	private String PREREQUISITE = "";
	private String SHORT_DESCRIPTION = "";
	private String LONG_DESCRIPTION = "";
	private String ACTION_COUNT = "";
	private String VALID_FROM = "";
	private String VALID_TO = "";
	private String REQUEST_NUMBER = "";
    private String RISK_COUNT = "";
    private String BPROC = "FINANCE";
    private String FUNAREA = "";
    private String CAN_APPROVE = "";
    private String DUMMY_ROLE_DETL_INCL = "";
    private int    PROV_ACTION;
    private String POSITION = "";
    private String PLATFORM = "CENTRAL FINANCE";
    private String PROV_ITEM_TYPE = "";
    private String FF_OWNER = "";
    private String PROV_TYPE = "";
    private String ASSIGNMENT_TYPE = "";
    private String ENVIRONMENT="";
    private String ROLE_TYPE_ = "";
    private String CONNECTOR_DESCN = "";
    private String COMMENTS = "";
    private String VALID = "";
    private String REFERENCE_ROLE_NAME = "";
}
