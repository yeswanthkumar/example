package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.ConflictMatrixMdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class ConflictMatrixHandler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(ConflictMatrixHandler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: SOD_EXTR.CONFLICT_MATRIX ");
		String filePath = "";
		List<ConflictMatrixMdl> dataList = getConflictData();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("CONFLICT_MATRIX", dataList);
		}
		return filePath;
	}


	private List<ConflictMatrixMdl> getConflictData() throws SQLException, DataAccessException{
		List<ConflictMatrixMdl> dataList = dBExtrDao.getConflictMatrixData();
		return dataList;
	}


	private String createCSVReport(String fileName, List<ConflictMatrixMdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CONFLICT_MATRIX CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String [] header = "ROLE1,ROLE2,APP1,APP2,CONFLICT,MITIGATING CONTROL".split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
