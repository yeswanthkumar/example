package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZPositionMdl {
	private int posid;
	private String posname;
	private String posdesc;
	private String isactive;
	private  String createdby;
	private Date createdon;
	private  String cchangedby;
	private Date changedon;


	@Override
	public String toString() {
		return "ZPositionMdl [posid=" + posid + ", posname=" + posname + ", posdesc=" + posdesc + ", isactive="
				+ isactive + ", createdby=" + createdby + ", createdon=" + createdon + ", cchangedby=" + cchangedby
				+ ", changedon=" + changedon + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZPositionMdl other = (ZPositionMdl) obj;
		if (posdesc == null) {
			if (other.posdesc != null)
				return false;
		} else if (!posdesc.equals(other.posdesc))
			return false;
		if (posid != other.posid)
			return false;
		if (posname == null) {
			if (other.posname != null)
				return false;
		} else if (!posname.equals(other.posname))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((posdesc == null) ? 0 : posdesc.hashCode());
		result = prime * result + posid;
		result = prime * result + ((posname == null) ? 0 : posname.hashCode());
		return result;
	}





}
