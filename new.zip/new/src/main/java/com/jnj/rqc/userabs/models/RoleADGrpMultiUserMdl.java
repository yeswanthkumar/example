package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleADGrpMultiUserMdl implements Serializable{
	private static final long serialVersionUID = -1108320057625924930L;

	private int reqId;
	private String userId;
	private String secId;
	private String secName;
	private String sysId;
	private String sysName;
	private String posId;
	private String posName;
	private String accId;
	private String accName;
	private String pvId;
	private String pvName;
	private String adgrpId;
	private String adgrpName;
	private String isRestricted;
	private String region;	
	private String lineManagerWWID;
	private String lineManagerEmail;
	private String lineManagerName;
	private String userEmail;
	private String userFirstName;
	private String userLastName;
	


}