package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSIFunctionActionModel {

	private String disp;
	private String appScp;
	private String funcId;
	private String funcDesc;
	private String tCode;
	private String tCodeDesc;
	private String status;
	private String source;
	private String changeCmnt;

	@Override
	public String toString() {
		return "CSIFunctionActionModel [disp=" + disp + ", appScp=" + appScp + ", funcId=" + funcId + ", funcDesc="
				+ funcDesc + ", tCode=" + tCode + ", tCodeDesc=" + tCodeDesc + ", status=" + status + ", source="
				+ source + ", changeCmnt=" + changeCmnt + "]";
	}


	public String getData() {
		return disp + "~" + appScp + "~" + funcId + "~" + funcDesc + "~" + tCode + "~" + tCodeDesc + "~" + status + "~" + source + "~" + changeCmnt ;
	}



}
