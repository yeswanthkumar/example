package com.jnj.rqc.reportmodels;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ReqLogModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private String ticktNo;
	private String userId;
	private String ntId;
	private String userNm;
	private Date comDate;
	private String comTime;
	private String cmnts;



	public String getData() {
		return  ticktNo + "~" + userId + "~" + ntId + "~" + userNm + "~" + comDate + "~" + comTime + "~" + cmnts;
	}

	public String getDataCSV() {
		return  comDate + "~" + ntId  + "~" + userNm + "~" + cmnts;
	}


	@Override
	public String toString() {
		return "ReqLogModel [ticktNo=" + ticktNo + ", userId=" + userId + ", ntId=" + ntId + ", userNm=" + userNm
				+ ", comDate=" + comDate + ", comTime=" + comTime + ", cmnts=" + cmnts + "]";
	}


}
