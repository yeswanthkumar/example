package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;

@Data
public class UserRequestDispMdl {
	private int 	reqId;
	private int 	reqTyp;
	private String  reqTypName;
	private Date   	reqDt;
	private String 	reqBy;
	private String 	reqByName;
	private String 	reqByNtId;
	private String 	userId;
	private String 	userNtId;
	private String 	userName;
	private String 	mgrWwid;
	private String 	mgrNtId;
	private String 	mgrName;
	private int 	prjId;
	private String 	prjName;
	private String  personaIds;
	private String  positionIds;
	private String  roleIds;
	private String 	secIds;
	private String 	accfIds;
	private String 	regIds;
	private String 	cntryIds;
	private String 	consIds;
	private String 	respIds;
	private String  conflictFound;
	private int 	reqStatus;
	private String 	reqStatusDesc;
	private Date   	dtUpdated;
	private String  updtBy;
	private String comments;

	@Override
	public String toString() {
		return "UserRequestDispMdl [reqId=" + reqId + ", reqTyp=" + reqTyp + ", reqTypName=" + reqTypName + ", reqDt="
				+ reqDt + ", reqBy=" + reqBy + ", reqByName=" + reqByName + ", reqByNtId=" + reqByNtId + ", userId="
				+ userId + ", userNtId=" + userNtId + ", userName=" + userName + ", mgrWwid=" + mgrWwid + ", mgrNtId="
				+ mgrNtId + ", mgrName=" + mgrName + ", prjId=" + prjId + ", prjName=" + prjName + ", personaIds="
				+ personaIds + ", positionIds=" + positionIds + ", roleIds=" + roleIds + ", secIds=" + secIds
				+ ", accfIds=" + accfIds + ", regIds=" + regIds + ", cntryIds=" + cntryIds + ", consIds=" + consIds
				+ ", respIds=" + respIds + ", conflictFound=" + conflictFound + ", reqStatus=" + reqStatus
				+ ", reqStatusDesc=" + reqStatusDesc + ", dtUpdated=" + dtUpdated + ", updtBy=" + updtBy + ", comments="
				+ comments + "]";
	}
















}
