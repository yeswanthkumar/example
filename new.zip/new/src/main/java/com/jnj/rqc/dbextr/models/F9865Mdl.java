package com.jnj.rqc.dbextr.models;


import lombok.Data;


@Data
public class F9865Mdl {
	private String sWFMNM;
	private String sWFMID;
	private String sWMD;
	private String sWFMPT;
	private String sWRLS;
	private String sWENTRYPT;
	private String sWSY;
	private String sWFUNO;
	private String sWOBNM;
	private String sWAPPLID;
	private String sWHELPID1;
	private String sWHFNAME;
	private String sWJDEVERS;
	private String sWMRGMOD;
	private String sWMRGOPT;
	private String sWFMC1;
	private String sWFMC2;
	private String sWFMC3;
	private String sWFMC4;
	private String sWFMC5;
	private String sWUSER;
	private String sWPID;
	private String sWJOBN;
	private String sWUPMJ;
	private String sWUPMT;

	public String getData() {
		return  sWFMNM + "~" +sWFMID + "~" + sWMD + "~" +sWFMPT + "~" + sWRLS + "~"+sWENTRYPT+"~"+sWSY+"~"+sWFUNO+"~"+sWOBNM+"~"+sWAPPLID
				+"~"+sWHELPID1+"~"+sWHFNAME+"~"+sWJDEVERS+"~"+sWMRGMOD+"~"+ sWMRGOPT+"~"+sWFMC1+"~"+sWFMC2+"~"+sWFMC3+"~"+sWFMC4+"~"+sWFMC5
				+"~"+sWUSER+"~"+sWPID+"~"+sWJOBN+"~"+sWUPMJ+"~"+sWUPMT;
	}

}
