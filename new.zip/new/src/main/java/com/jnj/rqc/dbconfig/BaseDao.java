package com.jnj.rqc.dbconfig;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import oracle.jdbc.pool.OracleDataSource;



/**
 * File    : <b>BaseDao.java</b>
 * @author : DChauras @Created : Apr 23, 2019 5:29:56 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public abstract class BaseDao implements ApplicationContextAware {
	private JdbcTemplate jdbcTemplate;       //PROD
	private JdbcTemplate jdbcTemplate0335;   //0335
	private JdbcTemplate jdbcTemplate0459;   //0459
	private JdbcTemplate jdbcTemplateCcra;   //CCRA
	private JdbcTemplate jdbcTemplateCore;    //CORE
	private JdbcTemplate jdbcTemplateGps;    //GPS
	private JdbcTemplate jdbcTemplateHcsop11;   //HCSOP11
	private JdbcTemplate jdbcTemplateIcs;    //ICS
	private JdbcTemplate jdbcTemplateMdm;    //MDM
	private JdbcTemplate jdbcTemplateWmsMlc; //WMS-MLC
	private JdbcTemplate jdbcTemplateWmsSdc; //WMS-SDC

	//SOD REFRESH
	private JdbcTemplate jdbcTemplateQASodRefresh;
	private JdbcTemplate jdbcTemplatePRODSodRefresh;
	private JdbcTemplate jdbcTemplateMrap0561;//MRAP0561

	//RQCUtils DEV DB
	private JdbcTemplate jdbcTemplateSRADUtils;//MRAP0561

	//BRAVO Template
	private JdbcTemplate jdbcTemplateNA_BRAVO_Development_BRAVO;
	private JdbcTemplate jdbcTemplateNA_BRAVO_Quality_BRAVO;
	private JdbcTemplate jdbcTemplateNA_BRAVO_Production_BRAVO;
	//END BRAVO

	//private JdbcTemplate jdbcTemplateCarsIs; //CARSIS
	//private JdbcTemplate jdbcTemplateCarsMa; //CARSMa
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private SimpleJdbcInsert userSimpleJdbcInsert459;
	private SimpleJdbcInsert userSimpleJdbcInsert;

	ApplicationContext appContext;

	//HANA Templates
	private JdbcTemplate jdbcTemplateSANDBOX_Sandbox_Sandbox1;     //HanaSandBox; //HANA
	//DEV
	private JdbcTemplate jdbcTemplateBOBI_Development_Dfx_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Development_DFY_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Development_DFY_System_DB;
	//DEV N+1
	private JdbcTemplate jdbcTemplateBOBI_Development_N_1_xfx_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Development_N_1_xfy_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Development_N_1_xfy_System_DB;
	//PROD
	private JdbcTemplate jdbcTemplateBOBI_Production_pfx_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Production_Pfy_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Production_Pfy_System_DB;

	//BOBI_QA
	private JdbcTemplate jdbcTemplateBOBI_QA_QFX_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_QA_QFY_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_QA_QFY_System_DB;

	//BOBI_QA N+1
	private JdbcTemplate jdbcTemplateBOBI_QA_N_1_yfx_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_QA_N_1_yfy_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_QA_N_1_yfy_System_DB;

	//BOBIPre-PRD
	private JdbcTemplate jdbcTemplateBOBI_Pre_PRD_yfx_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Pre_PRD_yfy_Tenant_DB;
	private JdbcTemplate jdbcTemplateBOBI_Pre_PRD_yfy_System_DB;

	//BODS PROD
	private JdbcTemplate jdbcTemplateBODS_Production_PFF_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Production_PFE_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Production_PFE_System_DB;
	//BODS DEV
	private JdbcTemplate jdbcTemplateBODS_Development_DFF_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Development_DFE_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Development_DFE_System_DB;
	//QA1
	private JdbcTemplate jdbcTemplateBODS_Quality_QA1_QFF_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Quality_QA1_QFE_Tenant_DB;
	private JdbcTemplate jdbcTemplateBODS_Quality_QA1_QFE_System_DB;

	//CTS DEV
	private JdbcTemplate jdbcTemplateCTS_Development_DFU_DFU;
	private JdbcTemplate jdbcTemplateCTS_Development_DFT_DFU;
	private JdbcTemplate jdbcTemplateCTS_Development_SYSTEMDB_DFU;
	//CTS PROD
	private JdbcTemplate jdbcTemplateCTS_Production_PFU_PFU;
	private JdbcTemplate jdbcTemplateCTS_Production_PFT_PFU;
	private JdbcTemplate jdbcTemplateCTS_Production_SYSTEMDB_PFU;

	//BW PROD
	private JdbcTemplate jdbcTemplateBW_Production_PFA_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_Production_PFB_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_Production_PFA_System_DB;
	//BW DEV N+1
	private JdbcTemplate jdbcTemplateBW_Development_N_1_XFA_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_Development_N_1_XFB_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_Development_N_1_XFA_System_DB;
	//DEV
	private JdbcTemplate jdbcTemplateBW_Development_DFA_Teanat_DB;
	private JdbcTemplate jdbcTemplateBW_Development_DFB_Teanant_DB;
	private JdbcTemplate jdbcTemplateBW_Development_DFA_System_DB;
	//QA
	private JdbcTemplate jdbcTemplateBW_QA_QFA_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_QA_QFB_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_QA_QFA_System_DB;
	//QA N+1/PRE-PROD
	private JdbcTemplate jdbcTemplateBW_QA_N_1_YFA_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_QA_N_1_YFB_Tenant_DB;
	private JdbcTemplate jdbcTemplateBW_QA_N_1_YFA_System_DB;
	//S4
	//PROD
	private JdbcTemplate jdbcTemplateS4_Production_PFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Production_PFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Production_PFH_System_DB;
	//DEV N+1
	private JdbcTemplate jdbcTemplateS4_Development_N_1_XFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Development_N_1_XFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Development_N_1_XFH_System_DB;
	//QA3
	private JdbcTemplate jdbcTemplateS4_Quality_QA3_YFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA3_YFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA3_YFH_System_DB;
	//DEV
	private JdbcTemplate jdbcTemplateS4_Development_DFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Development_DFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Development_DFH_System_DB;
	//QA1
	private JdbcTemplate jdbcTemplateS4_Quality_QA1_QFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA1_QFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA1_QFH_System_DB;
	//QA2
	private JdbcTemplate jdbcTemplateS4_Quality_QA2_AFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA2_AFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Quality_QA2_AFH_System_DB;
	//Pre-QA
	private JdbcTemplate jdbcTemplateS4_Pre_QA_UFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Pre_QA_UFI_Teanant_DB;
	private JdbcTemplate jdbcTemplateS4_Pre_QA_UFH_System_DB;
	//Pre Prod
	private JdbcTemplate jdbcTemplateS4_Pre_Production_TFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Pre_Production_TFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_Pre_Production_TFH_System_DB;
	//QA N+1
	private JdbcTemplate jdbcTemplateS4_QA_N_1_RFH_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_QA_N_1_RFI_Tenant_DB;
	private JdbcTemplate jdbcTemplateS4_QA_N_1_RFH_System_DB;
	//SLT
	//DEV
	private JdbcTemplate jdbcTemplateSLT_Development_DFM_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Development_DFQ_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Development_DFM_System_DB;
	//QA1
	private JdbcTemplate jdbcTemplateSLT_Quality_QA1_QFM_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA1_QFQ_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA1_QFM_System_DB;
	//QA2
	private JdbcTemplate jdbcTemplateSLT_Quality_QA2_QFN_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA2_QFR_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA2_QFN_System_DB;
	//QA3
	private JdbcTemplate jdbcTemplateSLT_Quality_QA3_QFS_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA3_QFO_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Quality_QA3_QFO_System_DB;
	//PROD
	private JdbcTemplate jdbcTemplateSLT_Production_PFM_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Production_PFQ_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Production_PFM_System_DB;
	//DEV N+1
	private JdbcTemplate jdbcTemplateSLT_Development_N_1_DFN_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Development_N_1_DFR_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Development_N_1_DFN_System_DB;
	//Pre-QA
	private JdbcTemplate jdbcTemplateSLT_Pre_QA_UFQ_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Pre_QA_UFM_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Pre_QA_UFM_System_DB;
	//PRE PROD
	private JdbcTemplate jdbcTemplateSLT_Pre_Production_TFM_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Pre_Production_TFQ_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_Pre_Production_TFM_System_DB;
	//QA N+1
	private JdbcTemplate jdbcTemplateSLT_QA_N_1_YFN_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_QA_N_1_YFR_Tenant_DB;
	private JdbcTemplate jdbcTemplateSLT_QA_N_1_YFN_System_DB;

	//NA_BOBJ_Production_BTBBOBJBPG
	private JdbcTemplate jdbcTemplateNA_BOBJ_Production_BTBBOBJBPG;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_BTBHANAHPG;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEA;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONTenantDBPB1;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEA;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEB;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONTenantDBPEC;
	private JdbcTemplate jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEB;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_GALAXYHANA;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_GALAXYHANASystemDB;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_GALAXYHANAHPM;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_GALAXYHANABPM;

	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_STFHANA;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_STFHANASystemDB;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_STFHANAHPC;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_STFHANABPC;

	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES;
	private JdbcTemplate jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES1;
	//END HANA

	//START JDA DEV EXTRACT DB
	private JdbcTemplate jdbcTemplateJDADevelopment;
	private JdbcTemplate jdbcTemplateJDAQuality;
	private JdbcTemplate jdbcTemplateJDAPreQuality;
	private JdbcTemplate jdbcTemplateJDAProduction;
	//END JDA DEV EXTRACT DB

	//GENESIS DEV
	private JdbcTemplate jdbcTemplateGenesisDev;


	//JDE - START

	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEANIMAS;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEBWI;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEDCF92;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYEMEA;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYUS;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEEES;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEETHICON;
	private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEGMED;
	//private JdbcTemplate jdbcTemplateNA_JDEPLATFORM_Production_JDEMENTOR; - NO TNS

	//JDE - END

	private SimpleJdbcInsert genesisTrfSimpleJdbcInsert;

	@Autowired
	public void setDataSourceNm(final DataSource dataSource) {				
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);		
	}

	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	public void setDataSource0335(final DataSource dataSource0335) {
		jdbcTemplate0335 = new JdbcTemplate(dataSource0335);
	}


	@Autowired
	public void setDataSource0459(final DataSource dataSource0459) {
		jdbcTemplate0459 = new JdbcTemplate(dataSource0459);
	}

	@Autowired
	public void setDataSourceCcra(final DataSource dataSourceCcra) {
		jdbcTemplateCcra = new JdbcTemplate(dataSourceCcra);
	}

	@Autowired
	public void setDataSourceCore(final DataSource dataSourceCore) {
		jdbcTemplateCore = new JdbcTemplate(dataSourceCore);
	}


	@Autowired
	public void setDataSourceGps(final DataSource dataSourceGps) {
		jdbcTemplateGps = new JdbcTemplate(dataSourceGps);
	}

	@Autowired
	public void setDataSourceHcsop11(final DataSource dataSourceHcsop11) {
		jdbcTemplateHcsop11 = new JdbcTemplate(dataSourceHcsop11);
	}

	@Autowired
	public void setDataSourceIcs(final DataSource dataSourceIcs) {
		jdbcTemplateIcs = new JdbcTemplate(dataSourceIcs);
	}

	@Autowired
	public void setDataSourceMdm(final DataSource dataSourceMdm) {
		jdbcTemplateMdm = new JdbcTemplate(dataSourceMdm);
	}

	@Autowired
	public void setDataSourceWmsMlc(final DataSource dataSourceWmsMlc) {
		jdbcTemplateWmsMlc = new JdbcTemplate(dataSourceWmsMlc);
	}

	@Autowired
	public void setDataSourceWmsSdc(final DataSource dataSourceWmsSdc) {
		jdbcTemplateWmsSdc = new JdbcTemplate(dataSourceWmsSdc);
	}

	@Autowired
	public void setDataSourceQASodRefresh(final DataSource dataSourceQASodRefresh) {
		jdbcTemplateQASodRefresh = new JdbcTemplate(dataSourceQASodRefresh);
	}

	@Autowired
	public void setDataSourcePRODSodRefresh(final DataSource dataSourcePRODSodRefresh) {
		jdbcTemplatePRODSodRefresh = new JdbcTemplate(dataSourcePRODSodRefresh);
	}

	@Autowired
	public void setDataSourceMrap0561(final DataSource dataSourceMrap0561) {
		jdbcTemplateMrap0561 = new JdbcTemplate(dataSourceMrap0561);
	}

	@Autowired
	public void setDataSourceSRADUtils(final DataSource dataSourceSRADUtils) {
		jdbcTemplateSRADUtils = new JdbcTemplate(dataSourceSRADUtils);
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate0335() {
		return jdbcTemplate0335;
	}
	public JdbcTemplate getJdbcTemplate0459() {
		return jdbcTemplate0459;
	}

	public JdbcTemplate getJdbcTemplateCcra() {
		return jdbcTemplateCcra;
	}

	public JdbcTemplate getJdbcTemplateCore() {
		return jdbcTemplateCore;
	}

	public JdbcTemplate getJdbcTemplateGps() {
		return jdbcTemplateGps;
	}

	public JdbcTemplate getJdbcTemplateHcsop11() {
		return jdbcTemplateHcsop11;
	}
	public JdbcTemplate getJdbcTemplateIcs() {
		return jdbcTemplateIcs;
	}

	public JdbcTemplate getJdbcTemplateMdm() {
		return jdbcTemplateMdm;
	}

	public JdbcTemplate getJdbcTemplateWmsMlc() {
		return jdbcTemplateWmsMlc;
	}

	public JdbcTemplate getJdbcTemplateMrap0561() {
		return jdbcTemplateMrap0561;
	}

	public JdbcTemplate getJdbcTemplateSRADUtils() {
		return jdbcTemplateSRADUtils;
	}

	public JdbcTemplate getJdbcTemplateWmsSdc() {
		return jdbcTemplateWmsSdc;
	}

	public JdbcTemplate getJdbcTemplateQASodRefresh() {
		return jdbcTemplateQASodRefresh;
	}

	public JdbcTemplate getJdbcTemplatePRODSodRefresh() {
		return jdbcTemplatePRODSodRefresh;
	}


	public NamedParameterJdbcTemplate getJdbcTemplateNm() {
		return namedParameterJdbcTemplate;
	}



	/*


	public JdbcTemplate getJdbcTemplateCarsMa() {
		return jdbcTemplateCarsMa;
	}
	@Autowired
	public void setDataSourceCarsIs(final DataSource dataSourceCarsIs) {
		jdbcTemplateCarsIs = new JdbcTemplate(dataSourceCarsIs);
	}*/

	/*@Autowired
	public void setDataSourceCarsMa(final DataSource dataSourceCarsMa) {
		jdbcTemplateCarsMa = new JdbcTemplate(dataSourceCarsMa);
	}*/


	@Autowired
	public void setUserSimpleJdbcInsert459(final DataSource dataSource0459) {
		userSimpleJdbcInsert459 = new SimpleJdbcInsert(dataSource0459);
	}

	public SimpleJdbcInsert getUserSimpleJdbcInsert459() {
		return userSimpleJdbcInsert459;
	}

	@Autowired
	public void setUserSimpleJdbcInsert(final DataSource dataSource) {
		userSimpleJdbcInsert = new SimpleJdbcInsert(dataSource);
	}

	public SimpleJdbcInsert getUserSimpleJdbcInsert() {
		return userSimpleJdbcInsert;
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.appContext= arg0;
	}


	@Bean
	public ApplicationContext getApplicationContext() {
		return appContext;
	}

	//HANA TEMPLATES START

	@Autowired
	public void setDataSourceSANDBOX_Sandbox_Sandbox1(final DataSource dataSourceSANDBOX_Sandbox_Sandbox1) {
		jdbcTemplateSANDBOX_Sandbox_Sandbox1 = new JdbcTemplate(dataSourceSANDBOX_Sandbox_Sandbox1);
	}

	public JdbcTemplate getJdbcTemplateSANDBOX_Sandbox_Sandbox1() {
		return jdbcTemplateSANDBOX_Sandbox_Sandbox1;
	}


	@Autowired
	public void setDataSourceBOBI_Development_Dfx_Tenant_DB(final DataSource dataSourceBOBI_Development_Dfx_Tenant_DB) {
		jdbcTemplateBOBI_Development_Dfx_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Development_Dfx_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_Dfx_Tenant_DB() {
		return jdbcTemplateBOBI_Development_Dfx_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Development_DFY_Tenant_DB(final DataSource dataSourceBOBI_Development_DFY_Tenant_DB) {
		jdbcTemplateBOBI_Development_DFY_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Development_DFY_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_DFY_Tenant_DB() {
		return jdbcTemplateBOBI_Development_DFY_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Development_DFY_System_DB(final DataSource dataSourceBOBI_Development_DFY_System_DB) {
		jdbcTemplateBOBI_Development_DFY_System_DB = new JdbcTemplate(dataSourceBOBI_Development_DFY_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_DFY_System_DB() {
		return jdbcTemplateBOBI_Development_DFY_System_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Development_N_1_xfx_Tenant_DB(final DataSource dataSourceBOBI_Development_N_1_xfx_Tenant_DB) {
		jdbcTemplateBOBI_Development_N_1_xfx_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Development_N_1_xfx_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_N_1_xfx_Tenant_DB() {
		return jdbcTemplateBOBI_Development_N_1_xfx_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Development_N_1_xfy_Tenant_DB(final DataSource dataSourceBOBI_Development_N_1_xfy_Tenant_DB) {
		jdbcTemplateBOBI_Development_N_1_xfy_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Development_N_1_xfy_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_N_1_xfy_Tenant_DB() {
		return jdbcTemplateBOBI_Development_N_1_xfy_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Development_N_1_xfy_System_DB(final DataSource dataSourceBOBI_Development_N_1_xfy_System_DB) {
		jdbcTemplateBOBI_Development_N_1_xfy_System_DB = new JdbcTemplate(dataSourceBOBI_Development_N_1_xfy_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Development_N_1_xfy_System_DB() {
		return jdbcTemplateBOBI_Development_N_1_xfy_System_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Production_pfx_Tenant_DB(final DataSource dataSourceBOBI_Production_pfx_Tenant_DB) {
		jdbcTemplateBOBI_Production_pfx_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Production_pfx_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Production_pfx_Tenant_DB() {
		return jdbcTemplateBOBI_Production_pfx_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Production_Pfy_Tenant_DB(final DataSource dataSourceBOBI_Production_Pfy_Tenant_DB) {
		jdbcTemplateBOBI_Production_Pfy_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Production_Pfy_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Production_Pfy_Tenant_DB() {
		return jdbcTemplateBOBI_Production_Pfy_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Production_Pfy_System_DB(final DataSource dataSourceBOBI_Production_Pfy_System_DB) {
		jdbcTemplateBOBI_Production_Pfy_System_DB = new JdbcTemplate(dataSourceBOBI_Production_Pfy_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Production_Pfy_System_DB() {
		return jdbcTemplateBOBI_Production_Pfy_System_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_QFX_Tenant_DB(final DataSource dataSourceBOBI_QA_QFX_Tenant_DB) {
		jdbcTemplateBOBI_QA_QFX_Tenant_DB = new JdbcTemplate(dataSourceBOBI_QA_QFX_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_QFX_Tenant_DB() {
		return jdbcTemplateBOBI_QA_QFX_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_QFY_Tenant_DB(final DataSource dataSourceBOBI_QA_QFY_Tenant_DB) {
		jdbcTemplateBOBI_QA_QFY_Tenant_DB = new JdbcTemplate(dataSourceBOBI_QA_QFY_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_QFY_Tenant_DB() {
		return jdbcTemplateBOBI_QA_QFY_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_QFY_System_DB(final DataSource dataSourceBOBI_QA_QFY_System_DB) {
		jdbcTemplateBOBI_QA_QFY_System_DB = new JdbcTemplate(dataSourceBOBI_QA_QFY_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_QFY_System_DB() {
		return jdbcTemplateBOBI_QA_QFY_System_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_N_1_yfx_Tenant_DB(final DataSource dataSourceBOBI_QA_N_1_yfx_Tenant_DB) {
		jdbcTemplateBOBI_QA_N_1_yfx_Tenant_DB = new JdbcTemplate(dataSourceBOBI_QA_N_1_yfx_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_N_1_yfx_Tenant_DB() {
		return jdbcTemplateBOBI_QA_N_1_yfx_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_N_1_yfy_Tenant_DB(final DataSource dataSourceBOBI_QA_N_1_yfy_Tenant_DB) {
		jdbcTemplateBOBI_QA_N_1_yfy_Tenant_DB = new JdbcTemplate(dataSourceBOBI_QA_N_1_yfy_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_N_1_yfy_Tenant_DB() {
		return jdbcTemplateBOBI_QA_N_1_yfy_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_QA_N_1_yfy_System_DB(final DataSource dataSourceBOBI_QA_N_1_yfy_System_DB) {
		jdbcTemplateBOBI_QA_N_1_yfy_System_DB = new JdbcTemplate(dataSourceBOBI_QA_N_1_yfy_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_QA_N_1_yfy_System_DB() {
		return jdbcTemplateBOBI_QA_N_1_yfy_System_DB;
	}


	@Autowired
	public void setDataSourceBOBI_Pre_PRD_yfx_Tenant_DB(final DataSource dataSourceBOBI_Pre_PRD_yfx_Tenant_DB) {
		jdbcTemplateBOBI_Pre_PRD_yfx_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Pre_PRD_yfx_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Pre_PRD_yfx_Tenant_DB() {
		return jdbcTemplateBOBI_Pre_PRD_yfx_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Pre_PRD_yfy_Tenant_DB(final DataSource dataSourceBOBI_Pre_PRD_yfy_Tenant_DB) {
		jdbcTemplateBOBI_Pre_PRD_yfy_Tenant_DB = new JdbcTemplate(dataSourceBOBI_Pre_PRD_yfy_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Pre_PRD_yfy_Tenant_DB() {
		return jdbcTemplateBOBI_Pre_PRD_yfy_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBOBI_Pre_PRD_yfy_System_DB(final DataSource dataSourceBOBI_Pre_PRD_yfy_System_DB) {
		jdbcTemplateBOBI_Pre_PRD_yfy_System_DB = new JdbcTemplate(dataSourceBOBI_Pre_PRD_yfy_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBOBI_Pre_PRD_yfy_System_DB() {
		return jdbcTemplateBOBI_Pre_PRD_yfy_System_DB;
	}

	@Autowired
	public void setDataSourceBODS_Production_PFF_Tenant_DB(final DataSource dataSourceBODS_Production_PFF_Tenant_DB) {
		jdbcTemplateBODS_Production_PFF_Tenant_DB = new JdbcTemplate(dataSourceBODS_Production_PFF_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Production_PFF_Tenant_DB() {
		return jdbcTemplateBODS_Production_PFF_Tenant_DB;
	}


	@Autowired
	public void setDataSourceBODS_Production_PFE_Tenant_DB(final DataSource dataSourceBODS_Production_PFE_Tenant_DB) {
		jdbcTemplateBODS_Production_PFE_Tenant_DB = new JdbcTemplate(dataSourceBODS_Production_PFE_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Production_PFE_Tenant_DB() {
		return jdbcTemplateBODS_Production_PFE_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBODS_Production_PFE_System_DB(final DataSource dataSourceBODS_Production_PFE_System_DB) {
		jdbcTemplateBODS_Production_PFE_System_DB = new JdbcTemplate(dataSourceBODS_Production_PFE_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Production_PFE_System_DB() {
		return jdbcTemplateBODS_Production_PFE_System_DB;
	}

	@Autowired
	public void setDataSourceBODS_Development_DFF_Tenant_DB(final DataSource dataSourceBODS_Development_DFF_Tenant_DB) {
		jdbcTemplateBODS_Development_DFF_Tenant_DB = new JdbcTemplate(dataSourceBODS_Development_DFF_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Development_DFF_Tenant_DB() {
		return jdbcTemplateBODS_Development_DFF_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBODS_Development_DFE_Tenant_DB(final DataSource dataSourceBODS_Development_DFE_Tenant_DB) {
		jdbcTemplateBODS_Development_DFE_Tenant_DB = new JdbcTemplate(dataSourceBODS_Development_DFE_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Development_DFE_Tenant_DB() {
		return jdbcTemplateBODS_Development_DFE_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBODS_Development_DFE_System_DB(final DataSource dataSourceBODS_Development_DFE_System_DB) {
		jdbcTemplateBODS_Development_DFE_System_DB = new JdbcTemplate(dataSourceBODS_Development_DFE_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Development_DFE_System_DB() {
		return jdbcTemplateBODS_Development_DFE_System_DB;
	}

	@Autowired
	public void setDataSourceBODS_Quality_QA1_QFF_Tenant_DB(final DataSource dataSourceBODS_Quality_QA1_QFF_Tenant_DB) {
		jdbcTemplateBODS_Quality_QA1_QFF_Tenant_DB = new JdbcTemplate(dataSourceBODS_Quality_QA1_QFF_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Quality_QA1_QFF_Tenant_DB() {
		return jdbcTemplateBODS_Quality_QA1_QFF_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBODS_Quality_QA1_QFE_Tenant_DB(final DataSource dataSourceBODS_Quality_QA1_QFE_Tenant_DB) {
		jdbcTemplateBODS_Quality_QA1_QFE_Tenant_DB = new JdbcTemplate(dataSourceBODS_Quality_QA1_QFE_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Quality_QA1_QFE_Tenant_DB() {
		return jdbcTemplateBODS_Quality_QA1_QFE_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBODS_Quality_QA1_QFE_System_DB(final DataSource dataSourceBODS_Quality_QA1_QFE_System_DB) {
		jdbcTemplateBODS_Quality_QA1_QFE_System_DB = new JdbcTemplate(dataSourceBODS_Quality_QA1_QFE_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBODS_Quality_QA1_QFE_System_DB() {
		return jdbcTemplateBODS_Quality_QA1_QFE_System_DB;
	}

	@Autowired
	public void setDataSourceCTS_Development_DFU_DFU(final DataSource dataSourceCTS_Development_DFU_DFU) {
		jdbcTemplateCTS_Development_DFU_DFU = new JdbcTemplate(dataSourceCTS_Development_DFU_DFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Development_DFU_DFU() {
		return jdbcTemplateCTS_Development_DFU_DFU;
	}

	@Autowired
	public void setDataSourceCTS_Development_DFT_DFU(final DataSource dataSourceCTS_Development_DFT_DFU) {
		jdbcTemplateCTS_Development_DFT_DFU = new JdbcTemplate(dataSourceCTS_Development_DFT_DFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Development_DFT_DFU() {
		return jdbcTemplateCTS_Development_DFT_DFU;
	}

	@Autowired
	public void setDataSourceCTS_Development_SYSTEMDB_DFU(final DataSource dataSourceCTS_Development_SYSTEMDB_DFU) {
		jdbcTemplateCTS_Development_SYSTEMDB_DFU = new JdbcTemplate(dataSourceCTS_Development_SYSTEMDB_DFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Development_SYSTEMDB_DFU() {
		return jdbcTemplateCTS_Development_SYSTEMDB_DFU;
	}

	@Autowired
	public void setDataSourceCTS_Production_PFU_PFU(final DataSource dataSourceCTS_Production_PFU_PFU) {
		jdbcTemplateCTS_Production_PFU_PFU = new JdbcTemplate(dataSourceCTS_Production_PFU_PFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Production_PFU_PFU() {
		return jdbcTemplateCTS_Production_PFU_PFU;
	}

	@Autowired
	public void setDataSourceCTS_Production_PFT_PFU(final DataSource dataSourceCTS_Production_PFT_PFU) {
		jdbcTemplateCTS_Production_PFT_PFU = new JdbcTemplate(dataSourceCTS_Production_PFT_PFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Production_PFT_PFU() {
		return jdbcTemplateCTS_Production_PFT_PFU;
	}

	@Autowired
	public void setDataSourceCTS_Production_SYSTEMDB_PFU(final DataSource dataSourceCTS_Production_SYSTEMDB_PFU) {
		jdbcTemplateCTS_Production_SYSTEMDB_PFU = new JdbcTemplate(dataSourceCTS_Production_SYSTEMDB_PFU);
	}

	public JdbcTemplate getJdbcTemplateCTS_Production_SYSTEMDB_PFU() {
		return jdbcTemplateCTS_Production_SYSTEMDB_PFU;
	}


	@Autowired
	public void setDataSourceBW_Production_PFA_Tenant_DB(final DataSource dataSourceBW_Production_PFA_Tenant_DB) {
		jdbcTemplateBW_Production_PFA_Tenant_DB = new JdbcTemplate(dataSourceBW_Production_PFA_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Production_PFA_Tenant_DB() {
		return jdbcTemplateBW_Production_PFA_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_Production_PFB_Tenant_DB(final DataSource dataSourceBW_Production_PFB_Tenant_DB) {
		jdbcTemplateBW_Production_PFB_Tenant_DB = new JdbcTemplate(dataSourceBW_Production_PFB_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Production_PFB_Tenant_DB() {
		return jdbcTemplateBW_Production_PFB_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_Production_PFA_System_DB(final DataSource dataSourceBW_Production_PFA_System_DB) {
		jdbcTemplateBW_Production_PFA_System_DB = new JdbcTemplate(dataSourceBW_Production_PFA_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Production_PFA_System_DB() {
		return jdbcTemplateBW_Production_PFA_System_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_N_1_XFA_Tenant_DB(final DataSource dataSourceBW_Development_N_1_XFA_Tenant_DB) {
		jdbcTemplateBW_Development_N_1_XFA_Tenant_DB = new JdbcTemplate(dataSourceBW_Development_N_1_XFA_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_N_1_XFA_Tenant_DB() {
		return jdbcTemplateBW_Development_N_1_XFA_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_N_1_XFB_Tenant_DB(final DataSource dataSourceBW_Development_N_1_XFB_Tenant_DB) {
		jdbcTemplateBW_Development_N_1_XFB_Tenant_DB = new JdbcTemplate(dataSourceBW_Development_N_1_XFB_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_N_1_XFB_Tenant_DB() {
		return jdbcTemplateBW_Development_N_1_XFB_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_N_1_XFA_System_DB(final DataSource dataSourceBW_Development_N_1_XFA_System_DB) {
		jdbcTemplateBW_Development_N_1_XFA_System_DB = new JdbcTemplate(dataSourceBW_Development_N_1_XFA_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_N_1_XFA_System_DB() {
		return jdbcTemplateBW_Development_N_1_XFA_System_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_DFA_Teanat_DB(final DataSource dataSourceBW_Development_DFA_Teanat_DB) {
		jdbcTemplateBW_Development_DFA_Teanat_DB = new JdbcTemplate(dataSourceBW_Development_DFA_Teanat_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_DFA_Teanat_DB() {
		return jdbcTemplateBW_Development_DFA_Teanat_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_DFB_Teanant_DB(final DataSource dataSourceBW_Development_DFB_Teanant_DB) {
		jdbcTemplateBW_Development_DFB_Teanant_DB = new JdbcTemplate(dataSourceBW_Development_DFB_Teanant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_DFB_Teanant_DB() {
		return jdbcTemplateBW_Development_DFB_Teanant_DB;
	}

	@Autowired
	public void setDataSourceBW_Development_DFA_System_DB(final DataSource dataSourceBW_Development_DFA_System_DB) {
		jdbcTemplateBW_Development_DFA_System_DB = new JdbcTemplate(dataSourceBW_Development_DFA_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_Development_DFA_System_DB() {
		return jdbcTemplateBW_Development_DFA_System_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_QFA_Tenant_DB(final DataSource dataSourceBW_QA_QFA_Tenant_DB) {
		jdbcTemplateBW_QA_QFA_Tenant_DB = new JdbcTemplate(dataSourceBW_QA_QFA_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_QFA_Tenant_DB() {
		return jdbcTemplateBW_QA_QFA_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_QFB_Tenant_DB(final DataSource dataSourceBW_QA_QFB_Tenant_DB) {
		jdbcTemplateBW_QA_QFB_Tenant_DB = new JdbcTemplate(dataSourceBW_QA_QFB_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_QFB_Tenant_DB() {
		return jdbcTemplateBW_QA_QFB_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_QFA_System_DB(final DataSource dataSourceBW_QA_QFA_System_DB) {
		jdbcTemplateBW_QA_QFA_System_DB = new JdbcTemplate(dataSourceBW_QA_QFA_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_QFA_System_DB() {
		return jdbcTemplateBW_QA_QFA_System_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_N_1_YFA_Tenant_DB(final DataSource dataSourceBW_QA_N_1_YFA_Tenant_DB) {
		jdbcTemplateBW_QA_N_1_YFA_Tenant_DB = new JdbcTemplate(dataSourceBW_QA_N_1_YFA_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_N_1_YFA_Tenant_DB() {
		return jdbcTemplateBW_QA_N_1_YFA_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_N_1_YFB_Tenant_DB(final DataSource dataSourceBW_QA_N_1_YFB_Tenant_DB) {
		jdbcTemplateBW_QA_N_1_YFB_Tenant_DB = new JdbcTemplate(dataSourceBW_QA_N_1_YFB_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_N_1_YFB_Tenant_DB() {
		return jdbcTemplateBW_QA_N_1_YFB_Tenant_DB;
	}

	@Autowired
	public void setDataSourceBW_QA_N_1_YFA_System_DB(final DataSource dataSourceBW_QA_N_1_YFA_System_DB) {
		jdbcTemplateBW_QA_N_1_YFA_System_DB = new JdbcTemplate(dataSourceBW_QA_N_1_YFA_System_DB);
	}

	public JdbcTemplate getJdbcTemplateBW_QA_N_1_YFA_System_DB() {
		return jdbcTemplateBW_QA_N_1_YFA_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Production_PFH_Tenant_DB(final DataSource dataSourceS4_Production_PFH_Tenant_DB) {
		jdbcTemplateS4_Production_PFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Production_PFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Production_PFH_Tenant_DB() {
		return jdbcTemplateS4_Production_PFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Production_PFI_Tenant_DB(final DataSource dataSourceS4_Production_PFI_Tenant_DB) {
		jdbcTemplateS4_Production_PFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Production_PFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Production_PFI_Tenant_DB() {
		return jdbcTemplateS4_Production_PFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Production_PFH_System_DB(final DataSource dataSourceS4_Production_PFH_System_DB) {
		jdbcTemplateS4_Production_PFH_System_DB = new JdbcTemplate(dataSourceS4_Production_PFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Production_PFH_System_DB() {
		return jdbcTemplateS4_Production_PFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Development_N_1_XFH_Tenant_DB(final DataSource dataSourceS4_Development_N_1_XFH_Tenant_DB) {
		jdbcTemplateS4_Development_N_1_XFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Development_N_1_XFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_N_1_XFH_Tenant_DB() {
		return jdbcTemplateS4_Development_N_1_XFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Development_N_1_XFI_Tenant_DB(final DataSource dataSourceS4_Development_N_1_XFI_Tenant_DB) {
		jdbcTemplateS4_Development_N_1_XFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Development_N_1_XFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_N_1_XFI_Tenant_DB() {
		return jdbcTemplateS4_Development_N_1_XFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Development_N_1_XFH_System_DB(final DataSource dataSourceS4_Development_N_1_XFH_System_DB) {
		jdbcTemplateS4_Development_N_1_XFH_System_DB = new JdbcTemplate(dataSourceS4_Development_N_1_XFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_N_1_XFH_System_DB() {
		return jdbcTemplateS4_Development_N_1_XFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA3_YFH_Tenant_DB(final DataSource dataSourceS4_Quality_QA3_YFH_Tenant_DB) {
		jdbcTemplateS4_Quality_QA3_YFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA3_YFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA3_YFH_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA3_YFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA3_YFI_Tenant_DB(final DataSource dataSourceS4_Quality_QA3_YFI_Tenant_DB) {
		jdbcTemplateS4_Quality_QA3_YFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA3_YFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA3_YFI_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA3_YFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA3_YFH_System_DB(final DataSource dataSourceS4_Quality_QA3_YFH_System_DB) {
		jdbcTemplateS4_Quality_QA3_YFH_System_DB = new JdbcTemplate(dataSourceS4_Quality_QA3_YFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA3_YFH_System_DB() {
		return jdbcTemplateS4_Quality_QA3_YFH_System_DB;
	}


	@Autowired
	public void setDataSourceS4_Development_DFH_Tenant_DB(final DataSource dataSourceS4_Development_DFH_Tenant_DB) {
		jdbcTemplateS4_Development_DFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Development_DFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_DFH_Tenant_DB() {
		return jdbcTemplateS4_Development_DFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Development_DFI_Tenant_DB(final DataSource dataSourceS4_Development_DFI_Tenant_DB) {
		jdbcTemplateS4_Development_DFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Development_DFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_DFI_Tenant_DB() {
		return jdbcTemplateS4_Development_DFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Development_DFH_System_DB(final DataSource dataSourceS4_Development_DFH_System_DB) {
		jdbcTemplateS4_Development_DFH_System_DB = new JdbcTemplate(dataSourceS4_Development_DFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Development_DFH_System_DB() {
		return jdbcTemplateS4_Development_DFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA1_QFH_Tenant_DB(final DataSource dataSourceS4_Quality_QA1_QFH_Tenant_DB) {
		jdbcTemplateS4_Quality_QA1_QFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA1_QFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA1_QFH_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA1_QFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA1_QFI_Tenant_DB(final DataSource dataSourceS4_Quality_QA1_QFI_Tenant_DB) {
		jdbcTemplateS4_Quality_QA1_QFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA1_QFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA1_QFI_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA1_QFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA1_QFH_System_DB(final DataSource dataSourceS4_Quality_QA1_QFH_System_DB) {
		jdbcTemplateS4_Quality_QA1_QFH_System_DB = new JdbcTemplate(dataSourceS4_Quality_QA1_QFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA1_QFH_System_DB() {
		return jdbcTemplateS4_Quality_QA1_QFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA2_AFI_Tenant_DB(final DataSource dataSourceS4_Quality_QA2_AFI_Tenant_DB) {
		jdbcTemplateS4_Quality_QA2_AFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA2_AFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA2_AFI_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA2_AFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA2_AFH_Tenant_DB(final DataSource dataSourceS4_Quality_QA2_AFH_Tenant_DB) {
		jdbcTemplateS4_Quality_QA2_AFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Quality_QA2_AFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA2_AFH_Tenant_DB() {
		return jdbcTemplateS4_Quality_QA2_AFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Quality_QA2_AFH_System_DB(final DataSource dataSourceS4_Quality_QA2_AFH_System_DB) {
		jdbcTemplateS4_Quality_QA2_AFH_System_DB = new JdbcTemplate(dataSourceS4_Quality_QA2_AFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Quality_QA2_AFH_System_DB() {
		return jdbcTemplateS4_Quality_QA2_AFH_System_DB;
	}


	@Autowired
	public void setDataSourceS4_Pre_QA_UFH_Tenant_DB(final DataSource dataSourceS4_Pre_QA_UFH_Tenant_DB) {
		jdbcTemplateS4_Pre_QA_UFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Pre_QA_UFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_QA_UFH_Tenant_DB() {
		return jdbcTemplateS4_Pre_QA_UFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Pre_QA_UFI_Teanant_DB(final DataSource dataSourceS4_Pre_QA_UFI_Teanant_DB) {
		jdbcTemplateS4_Pre_QA_UFI_Teanant_DB = new JdbcTemplate(dataSourceS4_Pre_QA_UFI_Teanant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_QA_UFI_Teanant_DB() {
		return jdbcTemplateS4_Pre_QA_UFI_Teanant_DB;
	}

	@Autowired
	public void setDataSourceS4_Pre_QA_UFH_System_DB(final DataSource dataSourceS4_Pre_QA_UFH_System_DB) {
		jdbcTemplateS4_Pre_QA_UFH_System_DB = new JdbcTemplate(dataSourceS4_Pre_QA_UFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_QA_UFH_System_DB() {
		return jdbcTemplateS4_Pre_QA_UFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_Pre_Production_TFH_Tenant_DB(final DataSource dataSourceS4_Pre_Production_TFH_Tenant_DB) {
		jdbcTemplateS4_Pre_Production_TFH_Tenant_DB = new JdbcTemplate(dataSourceS4_Pre_Production_TFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_Production_TFH_Tenant_DB() {
		return jdbcTemplateS4_Pre_Production_TFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Pre_Production_TFI_Tenant_DB(final DataSource dataSourceS4_Pre_Production_TFI_Tenant_DB) {
		jdbcTemplateS4_Pre_Production_TFI_Tenant_DB = new JdbcTemplate(dataSourceS4_Pre_Production_TFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_Production_TFI_Tenant_DB() {
		return jdbcTemplateS4_Pre_Production_TFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_Pre_Production_TFH_System_DB(final DataSource dataSourceS4_Pre_Production_TFH_System_DB) {
		jdbcTemplateS4_Pre_Production_TFH_System_DB = new JdbcTemplate(dataSourceS4_Pre_Production_TFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_Pre_Production_TFH_System_DB() {
		return jdbcTemplateS4_Pre_Production_TFH_System_DB;
	}

	@Autowired
	public void setDataSourceS4_QA_N_1_RFH_Tenant_DB(final DataSource dataSourceS4_QA_N_1_RFH_Tenant_DB) {
		jdbcTemplateS4_QA_N_1_RFH_Tenant_DB = new JdbcTemplate(dataSourceS4_QA_N_1_RFH_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_QA_N_1_RFH_Tenant_DB() {
		return jdbcTemplateS4_QA_N_1_RFH_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_QA_N_1_RFI_Tenant_DB(final DataSource dataSourceS4_QA_N_1_RFI_Tenant_DB) {
		jdbcTemplateS4_QA_N_1_RFI_Tenant_DB = new JdbcTemplate(dataSourceS4_QA_N_1_RFI_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_QA_N_1_RFI_Tenant_DB() {
		return jdbcTemplateS4_QA_N_1_RFI_Tenant_DB;
	}

	@Autowired
	public void setDataSourceS4_QA_N_1_RFH_System_DB(final DataSource dataSourceS4_QA_N_1_RFH_System_DB) {
		jdbcTemplateS4_QA_N_1_RFH_System_DB = new JdbcTemplate(dataSourceS4_QA_N_1_RFH_System_DB);
	}

	public JdbcTemplate getJdbcTemplateS4_QA_N_1_RFH_System_DB() {
		return jdbcTemplateS4_QA_N_1_RFH_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_Development_DFM_Tenant_DB(final DataSource dataSourceSLT_Development_DFM_Tenant_DB) {
		jdbcTemplateSLT_Development_DFM_Tenant_DB = new JdbcTemplate(dataSourceSLT_Development_DFM_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_DFM_Tenant_DB() {
		return jdbcTemplateSLT_Development_DFM_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Development_DFQ_Tenant_DB(final DataSource dataSourceSLT_Development_DFQ_Tenant_DB) {
		jdbcTemplateSLT_Development_DFQ_Tenant_DB = new JdbcTemplate(dataSourceSLT_Development_DFQ_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_DFQ_Tenant_DB() {
		return jdbcTemplateSLT_Development_DFQ_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Development_DFM_System_DB(final DataSource dataSourceSLT_Development_DFM_System_DB) {
		jdbcTemplateSLT_Development_DFM_System_DB = new JdbcTemplate(dataSourceSLT_Development_DFM_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_DFM_System_DB() {
		return jdbcTemplateSLT_Development_DFM_System_DB;
	}


	@Autowired
	public void setDataSourceSLT_Quality_QA1_QFM_Tenant_DB(final DataSource dataSourceSLT_Quality_QA1_QFM_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA1_QFM_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA1_QFM_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA1_QFM_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA1_QFM_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA1_QFQ_Tenant_DB(final DataSource dataSourceSLT_Quality_QA1_QFQ_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA1_QFQ_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA1_QFQ_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA1_QFQ_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA1_QFQ_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA1_QFM_System_DB(final DataSource dataSourceSLT_Quality_QA1_QFM_System_DB) {
		jdbcTemplateSLT_Quality_QA1_QFM_System_DB = new JdbcTemplate(dataSourceSLT_Quality_QA1_QFM_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA1_QFM_System_DB() {
		return jdbcTemplateSLT_Quality_QA1_QFM_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA2_QFN_Tenant_DB(final DataSource dataSourceSLT_Quality_QA2_QFN_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA2_QFN_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA2_QFN_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA2_QFN_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA2_QFN_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA2_QFR_Tenant_DB(final DataSource dataSourceSLT_Quality_QA2_QFR_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA2_QFR_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA2_QFR_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA2_QFR_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA2_QFR_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA2_QFN_System_DB(final DataSource dataSourceSLT_Quality_QA2_QFN_System_DB) {
		jdbcTemplateSLT_Quality_QA2_QFN_System_DB = new JdbcTemplate(dataSourceSLT_Quality_QA2_QFN_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA2_QFN_System_DB() {
		return jdbcTemplateSLT_Quality_QA2_QFN_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA3_QFS_Tenant_DB(final DataSource dataSourceSLT_Quality_QA3_QFS_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA3_QFS_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA3_QFS_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA3_QFS_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA3_QFS_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA3_QFO_Tenant_DB(final DataSource dataSourceSLT_Quality_QA3_QFO_Tenant_DB) {
		jdbcTemplateSLT_Quality_QA3_QFO_Tenant_DB = new JdbcTemplate(dataSourceSLT_Quality_QA3_QFO_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA3_QFO_Tenant_DB() {
		return jdbcTemplateSLT_Quality_QA3_QFO_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Quality_QA3_QFO_System_DB(final DataSource dataSourceSLT_Quality_QA3_QFO_System_DB) {
		jdbcTemplateSLT_Quality_QA3_QFO_System_DB = new JdbcTemplate(dataSourceSLT_Quality_QA3_QFO_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Quality_QA3_QFO_System_DB() {
		return jdbcTemplateSLT_Quality_QA3_QFO_System_DB;
	}


	@Autowired
	public void setDataSourceSLT_Production_PFM_Tenant_DB(final DataSource dataSourceSLT_Production_PFM_Tenant_DB) {
		jdbcTemplateSLT_Production_PFM_Tenant_DB = new JdbcTemplate(dataSourceSLT_Production_PFM_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Production_PFM_Tenant_DB() {
		return jdbcTemplateSLT_Production_PFM_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Production_PFQ_Tenant_DB(final DataSource dataSourceSLT_Production_PFQ_Tenant_DB) {
		jdbcTemplateSLT_Production_PFQ_Tenant_DB = new JdbcTemplate(dataSourceSLT_Production_PFQ_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Production_PFQ_Tenant_DB() {
		return jdbcTemplateSLT_Production_PFQ_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Production_PFM_System_DB(final DataSource dataSourceSLT_Production_PFM_System_DB) {
		jdbcTemplateSLT_Production_PFM_System_DB = new JdbcTemplate(dataSourceSLT_Production_PFM_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Production_PFM_System_DB() {
		return jdbcTemplateSLT_Production_PFM_System_DB;
	}


	@Autowired
	public void setDataSourceSLT_Development_N_1_DFN_Tenant_DB(final DataSource dataSourceSLT_Development_N_1_DFN_Tenant_DB) {
		jdbcTemplateSLT_Development_N_1_DFN_Tenant_DB = new JdbcTemplate(dataSourceSLT_Development_N_1_DFN_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_N_1_DFN_Tenant_DB() {
		return jdbcTemplateSLT_Development_N_1_DFN_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Development_N_1_DFR_Tenant_DB(final DataSource dataSourceSLT_Development_N_1_DFR_Tenant_DB) {
		jdbcTemplateSLT_Development_N_1_DFR_Tenant_DB = new JdbcTemplate(dataSourceSLT_Development_N_1_DFR_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_N_1_DFR_Tenant_DB() {
		return jdbcTemplateSLT_Development_N_1_DFR_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Development_N_1_DFN_System_DB(final DataSource dataSourceSLT_Development_N_1_DFN_System_DB) {
		jdbcTemplateSLT_Development_N_1_DFN_System_DB = new JdbcTemplate(dataSourceSLT_Development_N_1_DFN_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Development_N_1_DFN_System_DB() {
		return jdbcTemplateSLT_Development_N_1_DFN_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_QA_UFQ_Tenant_DB(final DataSource dataSourceSLT_Pre_QA_UFQ_Tenant_DB) {
		jdbcTemplateSLT_Pre_QA_UFQ_Tenant_DB = new JdbcTemplate(dataSourceSLT_Pre_QA_UFQ_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_QA_UFQ_Tenant_DB() {
		return jdbcTemplateSLT_Pre_QA_UFQ_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_QA_UFM_Tenant_DB(final DataSource dataSourceSLT_Pre_QA_UFM_Tenant_DB) {
		jdbcTemplateSLT_Pre_QA_UFM_Tenant_DB = new JdbcTemplate(dataSourceSLT_Pre_QA_UFM_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_QA_UFM_Tenant_DB() {
		return jdbcTemplateSLT_Pre_QA_UFM_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_QA_UFM_System_DB(final DataSource dataSourceSLT_Pre_QA_UFM_System_DB) {
		jdbcTemplateSLT_Pre_QA_UFM_System_DB = new JdbcTemplate(dataSourceSLT_Pre_QA_UFM_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_QA_UFM_System_DB() {
		return jdbcTemplateSLT_Pre_QA_UFM_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_Production_TFM_Tenant_DB(final DataSource dataSourceSLT_Pre_Production_TFM_Tenant_DB) {
		jdbcTemplateSLT_Pre_Production_TFM_Tenant_DB = new JdbcTemplate(dataSourceSLT_Pre_Production_TFM_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_Production_TFM_Tenant_DB() {
		return jdbcTemplateSLT_Pre_Production_TFM_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_Production_TFQ_Tenant_DB(final DataSource dataSourceSLT_Pre_Production_TFQ_Tenant_DB) {
		jdbcTemplateSLT_Pre_Production_TFQ_Tenant_DB = new JdbcTemplate(dataSourceSLT_Pre_Production_TFQ_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_Production_TFQ_Tenant_DB() {
		return jdbcTemplateSLT_Pre_Production_TFQ_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_Pre_Production_TFM_System_DB(final DataSource dataSourceSLT_Pre_Production_TFM_System_DB) {
		jdbcTemplateSLT_Pre_Production_TFM_System_DB = new JdbcTemplate(dataSourceSLT_Pre_Production_TFM_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_Pre_Production_TFM_System_DB() {
		return jdbcTemplateSLT_Pre_Production_TFM_System_DB;
	}

	@Autowired
	public void setDataSourceSLT_QA_N_1_YFN_Tenant_DB(final DataSource dataSourceSLT_QA_N_1_YFN_Tenant_DB) {
		jdbcTemplateSLT_QA_N_1_YFN_Tenant_DB = new JdbcTemplate(dataSourceSLT_QA_N_1_YFN_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_QA_N_1_YFN_Tenant_DB() {
		return jdbcTemplateSLT_QA_N_1_YFN_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_QA_N_1_YFR_Tenant_DB(final DataSource dataSourceSLT_QA_N_1_YFR_Tenant_DB) {
		jdbcTemplateSLT_QA_N_1_YFR_Tenant_DB = new JdbcTemplate(dataSourceSLT_QA_N_1_YFR_Tenant_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_QA_N_1_YFR_Tenant_DB() {
		return jdbcTemplateSLT_QA_N_1_YFR_Tenant_DB;
	}

	@Autowired
	public void setDataSourceSLT_QA_N_1_YFN_System_DB(final DataSource dataSourceSLT_QA_N_1_YFN_System_DB) {
		jdbcTemplateSLT_QA_N_1_YFN_System_DB = new JdbcTemplate(dataSourceSLT_QA_N_1_YFN_System_DB);
	}

	public JdbcTemplate getJdbcTemplateSLT_QA_N_1_YFN_System_DB() {
		return jdbcTemplateSLT_QA_N_1_YFN_System_DB;
	}

	//NA_BOBJ_Production_BTBBOBJBPG
	@Autowired
	public void setDataSourceNA_BOBJ_Production_BTBBOBJBPG(final DataSource dataSourceNA_BOBJ_Production_BTBBOBJBPG) {
		jdbcTemplateNA_BOBJ_Production_BTBBOBJBPG = new JdbcTemplate(dataSourceNA_BOBJ_Production_BTBBOBJBPG);
	}

	public JdbcTemplate getJdbcTemplateNA_BOBJ_Production_BTBBOBJBPG() {
		return jdbcTemplateNA_BOBJ_Production_BTBBOBJBPG;
	}

	//NA_HANA_Production_BTBHANAHPG
	@Autowired
	public void setDataSourceNA_HANA_Production_BTBHANAHPG(final DataSource dataSourceNA_HANA_Production_BTBHANAHPG) {
		jdbcTemplateNA_HANA_Production_BTBHANAHPG = new JdbcTemplate(dataSourceNA_HANA_Production_BTBHANAHPG);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_BTBHANAHPG() {
		return jdbcTemplateNA_HANA_Production_BTBHANAHPG;
	}

	//NA_HANA_Production_FUSIONEmptyTenantDBPEA
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEA(final DataSource dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEA) {
		jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEA = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEA);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEA() {
		return jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEA;
	}

	//NA_HANA_Production_FUSIONTenantDBPB1
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONTenantDBPB1(final DataSource dataSourceNA_HANA_Production_FUSIONTenantDBPB1) {
		jdbcTemplateNA_HANA_Production_FUSIONTenantDBPB1 = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONTenantDBPB1);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONTenantDBPB1() {
		return jdbcTemplateNA_HANA_Production_FUSIONTenantDBPB1;
	}

	//NA_HANA_Production_FUSIONSYSTEMDBPEA
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONSYSTEMDBPEA(final DataSource dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEA) {
		jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEA = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEA);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEA() {
		return jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEA;
	}

	//NA_HANA_Production_FUSIONEmptyTenantDBPEB
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEB(final DataSource dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEB) {
		jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEB = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEB);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEB() {
		return jdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEB;
	}

	//NA_HANA_Production_FUSIONTenantDBPEC
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONTenantDBPEC(final DataSource dataSourceNA_HANA_Production_FUSIONTenantDBPEC) {
		jdbcTemplateNA_HANA_Production_FUSIONTenantDBPEC = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONTenantDBPEC);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONTenantDBPEC() {
		return jdbcTemplateNA_HANA_Production_FUSIONTenantDBPEC;
	}

	//NA_HANA_Production_FUSIONSYSTEMDBPEB
	@Autowired
	public void setDataSourceNA_HANA_Production_FUSIONSYSTEMDBPEB(final DataSource dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEB) {
		jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEB = new JdbcTemplate(dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEB);
	}

	public JdbcTemplate getJdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEB() {
		return jdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEB;
	}


	//EMEA_HANA_Production_GALAXYHANA
	@Autowired
	public void setDataSourceEMEA_HANA_Production_GALAXYHANA(final DataSource dataSourceEMEA_HANA_Production_GALAXYHANA) {
		jdbcTemplateEMEA_HANA_Production_GALAXYHANA = new JdbcTemplate(dataSourceEMEA_HANA_Production_GALAXYHANA);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_GALAXYHANA() {
		return jdbcTemplateEMEA_HANA_Production_GALAXYHANA;
	}

	//EMEA_HANA_Production_GALAXYHANASystemDB
	@Autowired
	public void setDataSourceEMEA_HANA_Production_GALAXYHANASystemDB(final DataSource dataSourceEMEA_HANA_Production_GALAXYHANASystemDB) {
		jdbcTemplateEMEA_HANA_Production_GALAXYHANASystemDB = new JdbcTemplate(dataSourceEMEA_HANA_Production_GALAXYHANASystemDB);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_GALAXYHANASystemDB() {
		return jdbcTemplateEMEA_HANA_Production_GALAXYHANASystemDB;
	}

	//EMEA_HANA_Production_GALAXYHANAHPM
	@Autowired
	public void setDataSourceEMEA_HANA_Production_GALAXYHANAHPM(final DataSource dataSourceEMEA_HANA_Production_GALAXYHANAHPM) {
		jdbcTemplateEMEA_HANA_Production_GALAXYHANAHPM = new JdbcTemplate(dataSourceEMEA_HANA_Production_GALAXYHANAHPM);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_GALAXYHANAHPM() {
		return jdbcTemplateEMEA_HANA_Production_GALAXYHANAHPM;
	}

	//EMEA_HANA_Production_GALAXYHANABPM
	@Autowired
	public void setDataSourceEMEA_HANA_Production_GALAXYHANABPM(final DataSource dataSourceEMEA_HANA_Production_GALAXYHANABPM) {
		jdbcTemplateEMEA_HANA_Production_GALAXYHANABPM = new JdbcTemplate(dataSourceEMEA_HANA_Production_GALAXYHANABPM);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_GALAXYHANABPM() {
		return jdbcTemplateEMEA_HANA_Production_GALAXYHANABPM;
	}


	//EMEA_HANA_Production_STFHANA
	@Autowired
	public void setDataSourceEMEA_HANA_Production_STFHANA(final DataSource dataSourceEMEA_HANA_Production_STFHANA) {
		jdbcTemplateEMEA_HANA_Production_STFHANA = new JdbcTemplate(dataSourceEMEA_HANA_Production_STFHANA);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_STFHANA() {
		return jdbcTemplateEMEA_HANA_Production_STFHANA;
	}

	//EMEA_HANA_Production_STFHANASystemDB
	@Autowired
	public void setDataSourceEMEA_HANA_Production_STFHANASystemDB(final DataSource dataSourceEMEA_HANA_Production_STFHANASystemDB) {
		jdbcTemplateEMEA_HANA_Production_STFHANASystemDB = new JdbcTemplate(dataSourceEMEA_HANA_Production_STFHANASystemDB);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_STFHANASystemDB() {
		return jdbcTemplateEMEA_HANA_Production_STFHANASystemDB;
	}
	//EMEA_HANA_Production_STFHANAHPC
	@Autowired
	public void setDataSourceEMEA_HANA_Production_STFHANAHPC(final DataSource dataSourceEMEA_HANA_Production_STFHANAHPC) {
		jdbcTemplateEMEA_HANA_Production_STFHANAHPC = new JdbcTemplate(dataSourceEMEA_HANA_Production_STFHANAHPC);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_STFHANAHPC() {
		return jdbcTemplateEMEA_HANA_Production_STFHANAHPC;
	}

	//EMEA_HANA_Production_STFHANABPC
	@Autowired
	public void setDataSourceEMEA_HANA_Production_STFHANABPC(final DataSource dataSourceEMEA_HANA_Production_STFHANABPC) {
		jdbcTemplateEMEA_HANA_Production_STFHANABPC = new JdbcTemplate(dataSourceEMEA_HANA_Production_STFHANABPC);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_STFHANABPC() {
		return jdbcTemplateEMEA_HANA_Production_STFHANABPC;
	}

	@Autowired
	public void setDataSourceEMEA_HANA_Production_EMEAHANASYNTHES(final DataSource dataSourceEMEA_HANA_Production_EMEAHANASYNTHES) {
		jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES = new JdbcTemplate(dataSourceEMEA_HANA_Production_EMEAHANASYNTHES);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES() {
		return jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES;
	}

	@Autowired
	public void setDataSourceEMEA_HANA_Production_EMEAHANASYNTHES1(final DataSource dataSourceEMEA_HANA_Production_EMEAHANASYNTHES1) {
		jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES1 = new JdbcTemplate(dataSourceEMEA_HANA_Production_EMEAHANASYNTHES1);
	}

	public JdbcTemplate getJdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES1() {
		return jdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES1;
	}

	//END HANA


	//SAP EXTRACT DBSAPSANDBOX_Sandbox_Sandbox1

	//JDA DEV
	@Autowired
	public void setDataSourceJDADevelopment(final DataSource dataSourceJDADevelopment) {
		jdbcTemplateJDADevelopment = new JdbcTemplate(dataSourceJDADevelopment);
	}

	public JdbcTemplate getJdbcTemplateJDADevelopment() {
		return jdbcTemplateJDADevelopment;
	}

	//JDA Quality
	@Autowired
	public void setDataSourceJDAQuality(final DataSource dataSourceJDAQuality) {
		jdbcTemplateJDAQuality = new JdbcTemplate(dataSourceJDAQuality);
	}

	public JdbcTemplate getJdbcTemplateJDAQuality() {
		return jdbcTemplateJDAQuality;
	}
	//JDA PreQuality
	@Autowired
	public void setDataSourceJDAPreQuality(final DataSource dataSourceJDAPreQuality) {
		jdbcTemplateJDAPreQuality = new JdbcTemplate(dataSourceJDAPreQuality);
	}

	public JdbcTemplate getJdbcTemplateJDAPreQuality() {
		return jdbcTemplateJDAPreQuality;
	}
	//JDA PROD
	@Autowired
	public void setDataSourceJDAProduction(final DataSource dataSourceJDAProduction) {
		jdbcTemplateJDAProduction = new JdbcTemplate(dataSourceJDAProduction);
	}

	public JdbcTemplate getJdbcTemplateJDAProduction() {
		return jdbcTemplateJDAProduction;
	}

	//END

	//GENESIS DEV
	@Autowired
	public void setDataSourceGenesisDev(final DataSource dataSourceGenesisDev) {
		jdbcTemplateGenesisDev = new JdbcTemplate(dataSourceGenesisDev);
	}

	public JdbcTemplate getJdbcTemplateGenesisDev() {
		return jdbcTemplateGenesisDev;
	}

	@Autowired
	public void setGenesisTrfSimpleJdbcInsert(final DataSource dataSourceGenesisDev) {
		genesisTrfSimpleJdbcInsert = new SimpleJdbcInsert(dataSourceGenesisDev);
	}

	public SimpleJdbcInsert getGenesisTrfSimpleJdbcInsert() {
		return genesisTrfSimpleJdbcInsert;
	}


	//JDE - START
	//1. NA_JDEPLATFORM_Production_JDEANIMAS
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEANIMAS(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEANIMAS) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEANIMAS = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEANIMAS);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEANIMAS() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEANIMAS;
	}

	//2. NA_JDEPLATFORM_Production_JDEBWI
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEBWI(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEBWI) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEBWI = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEBWI);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEBWI() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEBWI;
	}

	// 3. NA_JDEPLATFORM_Production_JDEDCF92
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEDCF92(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEDCF92) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEDCF92 = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEDCF92);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEDCF92() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEDCF92;
	}

	// 4. NA_JDEPLATFORM_Production_JDEDEPUYEMEA
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEDEPUYEMEA(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEDEPUYEMEA) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYEMEA = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEDEPUYEMEA);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYEMEA() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYEMEA;
	}

	// 5. NA_JDEPLATFORM_Production_JDEDEPUYUS
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEDEPUYUS(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEDEPUYUS) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYUS = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEDEPUYUS);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYUS() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYUS;
	}

	// 6. NA_JDEPLATFORM_Production_JDEEES
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEEES(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEEES) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEEES = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEEES);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEEES() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEEES;
	}

	// 7. NA_JDEPLATFORM_Production_JDEETHICON
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEETHICON(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEETHICON) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEETHICON = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEETHICON);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEETHICON() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEETHICON;
	}

	// 8. NA_JDEPLATFORM_Production_JDEGMED
	@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEGMED(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEGMED) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEGMED = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEGMED);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEGMED() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEGMED;
	}

	//9. NA_JDEPLATFORM_Production_JDEMENTOR - NO TNS
	/*@Autowired
	public void setDataSourceNA_JDEPLATFORM_Production_JDEMENTOR(final DataSource dataSourceNA_JDEPLATFORM_Production_JDEMENTOR) {
		jdbcTemplateNA_JDEPLATFORM_Production_JDEMENTOR = new JdbcTemplate(dataSourceNA_JDEPLATFORM_Production_JDEMENTOR);
	}

	public JdbcTemplate getJdbcTemplateNA_JDEPLATFORM_Production_JDEMENTOR() {
		return jdbcTemplateNA_JDEPLATFORM_Production_JDEMENTOR;
	}*/
	//JDE - END

	//BRAVO Templates
	//1. NA_BRAVO_Development_BRAVO
	@Autowired
	public void setDataSourceNA_BRAVO_Development_BRAVO(final DataSource dataSourceNA_BRAVO_Development_BRAVO) {
		jdbcTemplateNA_BRAVO_Development_BRAVO = new JdbcTemplate(dataSourceNA_BRAVO_Development_BRAVO);
	}

	public JdbcTemplate getJdbcTemplateNA_BRAVO_Development_BRAVO() {
		return jdbcTemplateNA_BRAVO_Development_BRAVO;
	}

	//2. NA_BRAVO_Quality_BRAVO
	@Autowired
	public void setDataSourceNA_BRAVO_Quality_BRAVO(final DataSource dataSourceNA_BRAVO_Quality_BRAVO) {
		jdbcTemplateNA_BRAVO_Quality_BRAVO = new JdbcTemplate(dataSourceNA_BRAVO_Quality_BRAVO);
	}

	public JdbcTemplate getJdbcTemplateNA_BRAVO_Quality_BRAVO() {
		return jdbcTemplateNA_BRAVO_Quality_BRAVO;
	}

	//3. NA_BRAVO_Production_BRAVO
	@Autowired
	public void setDataSourceNA_BRAVO_Production_BRAVO(final DataSource dataSourceNA_BRAVO_Production_BRAVO) {
		jdbcTemplateNA_BRAVO_Production_BRAVO = new JdbcTemplate(dataSourceNA_BRAVO_Production_BRAVO);
	}

	public JdbcTemplate getJdbcTemplateNA_BRAVO_Production_BRAVO() {
		return jdbcTemplateNA_BRAVO_Production_BRAVO;
	}
	//END BRAVO




}
