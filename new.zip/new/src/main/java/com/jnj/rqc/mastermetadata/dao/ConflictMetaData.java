package com.jnj.rqc.mastermetadata.dao;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.ConflictData;

public class ConflictMetaData {
	private List<ConflictData> records;

    public List<ConflictData> getRecords() {
        return records;
    }

    public void setRecords(List<ConflictData> records) {
        this.records = records;
    }

	@Override
	public String toString() {
		return "MyDataInput [records=" + records + ", getRecords()=" + getRecords() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
