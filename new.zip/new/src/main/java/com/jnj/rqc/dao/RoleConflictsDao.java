package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;


public interface RoleConflictsDao {
		/**
		 * Method  : RoleConflictsDao.java.getCurrentRolesConflict()
		 *		   :<b>@param roles
		 *		   :<b>@param wwid
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jan 15, 2020 4:27:45 PM
		 * Purpose :
		 * @return : List<MatrixModel>
		 */
	public List<MatrixModel> getCurrentRolesConflict(String[] roles, String wwid ) throws SQLException, DataAccessException ;

		/**
		 * Method  : RoleConflictsDao.java.getNewRolesConflict()
		 *		   :<b>@param sql
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jan 15, 2020 4:27:48 PM
		 * Purpose :
		 * @return : List<MatrixModel>
		 */
	public List<MatrixModel> getNewRolesConflict(String sql) throws SQLException, DataAccessException ;

		/**
		 * Method  : RoleConflictsDao.java.getUsersExistingRoles()
		 *		   :<b>@param empWwid
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jan 15, 2020 4:27:52 PM
		 * Purpose :
		 * @return : List<PersonalSysModel>
		 */
	public List<PersonalSysModel> getUsersExistingRoles(String empWwid)throws SQLException, DataAccessException;



		/**
		 * Method  : RoleConflictsDao.java.getUsersExistingRoles()
		 *		   :<b>@param empIds
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jan 30, 2020 4:51:07 PM
		 * Purpose :
		 * @return : List<PersonalSysModel>
		 */
	public List<PersonalSysModel> getUsersExistingRoles(List<String>empIds)throws SQLException, DataAccessException;


		/**
		 * Method  : RoleConflictsDao.java.getSystemCodes()
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jan 30, 2020 4:46:53 PM
		 * Purpose :
		 * @return : List<SystemCodeModel>
		 */
	public List<SystemCodeModel> getSystemCodes()throws SQLException, DataAccessException;



	public List<MatrixModel> getConflictMatrix()throws SQLException, DataAccessException;






}
