package com.jnj.rqc.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.dao.User2SodDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.StrKeyValPair;



@Service
public class User2SodDaoImpl  extends BaseDao implements User2SodDao {
	static final Logger log = LoggerFactory.getLogger(User2SodDaoImpl.class);

	@SuppressWarnings("all")
	@Override
	public int insertUser2SodMitiData(List<SapMitiCntrlModel> dataList)throws SQLException, DataAccessException{
		String delQry = "DELETE SOD_DB_USER.GRAC_MITICTRL";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		int recUpdated=0;
	 	if(count > 0) {
	 		String qry=" Insert into SOD_DB_USER.GRAC_MITICTRL ( RISK_ID, CTRL_ID, CTRL_DESC ) Values (?, ?, ?) ";
			log.debug("Inserting Data to Genesis, Query: "+qry);
			int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, dataList.get(i).getRiskId());
					ps.setString(2, dataList.get(i).getControlId());
					ps.setString(3, dataList.get(i).getControlDesc());
				}

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return dataList.size();
				}
			});
			recUpdated =  status.length;
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
	 	}
	 	return recUpdated;
	}

	@Override
	public List<SapMitiCntrlModel> loadMitiCntrlDBData() throws SQLException, DataAccessException {
		List<SapMitiCntrlModel> dataList = new ArrayList<>();
		String qry = " Select RISK_ID, CTRL_ID AS controlId, CTRL_DESC as controlDesc " +
					 "  FROM SOD_DB_USER.GRAC_MITICTRL "+
					 " ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapMitiCntrlModel.class));
		log.info("MITIGATING CNTROL Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}


	@Override
	public int insertUser2SodRevrData(List<SapPlatformReviwerMdl> dataList) throws SQLException, DataAccessException {
		String delQry = " DELETE SOD_DB_USER.REVIEWER_DETAILS ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.REVIEWER_DETAILS ( PLATFORM, RISK_ID, REVR_ID ) VALUES (?, ?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, dataList.get(i).getPlatform());
				ps.setString(2, dataList.get(i).getRiskId());
				ps.setString(3, dataList.get(i).getReviewerId());
			}

			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				return dataList.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return status.length;
	}

	@Override
	public int insertMercuryUser2SodRevrData(List<StrKeyValPair> dataList) throws SQLException, DataAccessException {
		String delQry = " DELETE SOD_DB_USER.REVIEWER_DETAILS_MERCURY ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.REVIEWER_DETAILS_MERCURY ( APPR_LIST_ID, REVR_ID ) VALUES (?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, dataList.get(i).getKey());
				ps.setString(2, dataList.get(i).getVal());
			}

			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				return dataList.size();
			}
		});
		log.info("MERCURY Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return status.length;
	}




	@Override
	public List<SapPlatformReviwerMdl> loadReviewerDBData() throws SQLException, DataAccessException {
		List<SapPlatformReviwerMdl> dataList = new ArrayList<>();
		String qry = " Select PLATFORM, RISK_ID, REVR_ID as reviewerId " +
					 "  FROM SOD_DB_USER.REVIEWER_DETAILS "+
					 " ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapPlatformReviwerMdl.class));
		log.info("REVIEWER Data Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	@Override
	public List<StrKeyValPair> loadMercuryReviewerDBData() throws SQLException, DataAccessException {
		List<StrKeyValPair> dataList = new ArrayList<>();
		String qry = " Select APPR_LIST_ID as key, REVR_ID as val " +
					 "  FROM SOD_DB_USER.REVIEWER_DETAILS_MERCURY "+
					 " ORDER BY 1,2 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Mercury REVIEWER Data Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}


}
