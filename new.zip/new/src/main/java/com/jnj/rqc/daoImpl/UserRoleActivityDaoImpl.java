package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.UserRoleActivityDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.termdata.models.TermDataSmryModel;

/**
 * File    : <b>UserRoleActivityDaoImpl.java</b>
 * @author : DChauras @Created : Sep 10, 2019 10:41:47 AM
 * Purpose : Get USER Data from All SOX Systems.
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class UserRoleActivityDaoImpl  extends BaseDao implements UserRoleActivityDao {
	static final Logger log = LoggerFactory.getLogger(UserRoleActivityDaoImpl.class);

	@Override
	public List<UserActivityModel> getCcraUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query CCRA Data.......START");
		Date startTm = new Date();
		String sql ="SELECT USER_ID, USER_FIRST_NM as FIRST_NAME, USER_LAST_NM as LAST_NAME, " +
				"'' AS ROLE, 'CCRA' as SRC_SYS, DECODE(STAT,'A','Y','I','N') as EMP_ACTIVE, ROW_UPDT_TMS as DT_UPDATED " +
				"FROM CCRA.USER_SEC WHERE USER_ID is not null ";
		final List<UserActivityModel> ccraData = getJdbcTemplateCcra().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("CCRA", (ccraData != null)? ccraData.size():0, sql, startTm, endTm));
		log.info("CCRA Data Total Rows: "+((ccraData != null)? ccraData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return ccraData;
	}

	@Override
	public List<UserActivityModel> getCoreUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query CORE Data.......START");
		Date startTm = new Date();
		String sql ="SELECT upper(username) as USER_ID, upper(firstname) as FIRST_NAME, upper(lastname) as LAST_NAME, " +
					"' ' as ROLE, 'CORE' as SRC_SYS, DECODE(isaccountdisabled,0,'Y',1,'N') as EMP_ACTIVE, lastupdts as DT_UPDATED " +
					"FROM  FLEX.TECMF_USER WHERE username is not null ";
		final List<UserActivityModel> coreData = getJdbcTemplateCore().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("CORE", (coreData != null)? coreData.size():0, sql, startTm, endTm));
		log.info("CORE Data Total Rows: "+((coreData != null)? coreData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return coreData;
	}

	@Override
	public List<UserActivityModel> getGpsUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query GPS Data.......START");
		Date startTm = new Date();
		String sql ="SELECT UPPER(USER_ID) as USER_ID, FIRST_NAME, LAST_NAME, ' ' as ROLE, 'GPS' as SRC_SYS, VALID as EMP_ACTIVE, LAST_LOGIN_ATTEMPT as DT_UPDATED " +
				"FROM  GP.NR_USER_PROFILE WHERE USER_ID is not null";
		final List<UserActivityModel> gpsData = getJdbcTemplateGps().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("GPS", (gpsData != null)? gpsData.size():0, sql, startTm, endTm));
		log.info("GPS Data Total Rows: "+((gpsData != null)? gpsData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return gpsData;
	}

	@Override
	public List<UserActivityModel> getHcsop02UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query HCSOP02 Data.......START");
		Date startTm = new Date();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select USERNAME as USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME,  decode(DB_DLET,'Y','N','Y') as EMP_ACTIVE , ");
		sql.append(" ''  as ROLE, 'HCSOP02' as SRC_SYS, sysdate as DT_UPDATED FROM DBA_AUD.USER_AUDT ");
		sql.append(" WHERE SID ='OP02' and profile in('ENDUSER_PROFILE', 'POWER_PROFILE', 'CLM_USER_PROFILE', 'PWDEXPIRE', 'INACTIVE_LEVEL1', 'INACTIVE_LEVEL2', ");
		sql.append(" 'INACTIVE_ACCOUNT', 'SQL_PROFILE') AND USERNAME is not null ");

		final List<UserActivityModel> op2Data = getJdbcTemplateHcsop11().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("HCSOP02", (op2Data != null)? op2Data.size():0, sql.toString(), startTm, endTm));
		log.info("HCSOP02 Data Total Rows: "+((op2Data != null)? op2Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return op2Data;
	}

	@Override
	public List<UserActivityModel> getHcsop17UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query HCSOP17 Data.......START");
		Date startTm = new Date();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select USERNAME as USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME, decode(DB_DLET,'Y','N','Y') as EMP_ACTIVE , ");
		sql.append(" ''  as ROLE, 'HCSOP17' as SRC_SYS, sysdate as DT_UPDATED FROM DBA_AUD.USER_AUDT ");
		sql.append(" WHERE SID ='HCSOP17' and profile in ('ENDUSER_PROFILE', 'POWER_PROFILE', 'CLM_USER_PROFILE', 'PWDEXPIRE', 'INACTIVE_LEVEL1', 'INACTIVE_LEVEL2', ");
		sql.append(" 'INACTIVE_ACCOUNT', 'SQL_PROFILE' ) AND USERNAME is not null ");

		final List<UserActivityModel> op17Data = getJdbcTemplateHcsop11().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("HCSOP17", (op17Data != null)? op17Data.size():0, sql.toString(), startTm, endTm));
		log.info("HCSOP17 Data Total Rows: "+((op17Data != null)? op17Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return op17Data;
	}


	//OP50
	@Override
	public List<UserActivityModel> getHcsop50UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query HCSOP50 Data.......START");
		Date startTm = new Date();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select USERNAME as USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME, decode(DB_DLET,'Y','N','Y') as EMP_ACTIVE , ");
		sql.append(" ''  as ROLE, 'HCSOP50' as SRC_SYS, sysdate as DT_UPDATED FROM DBA_AUD.USER_AUDT ");
		sql.append(" WHERE SID ='HCSOP50' and profile in ('ENDUSER_PROFILE', 'POWER_PROFILE', 'CLM_USER_PROFILE', 'PWDEXPIRE', 'INACTIVE_LEVEL1', 'INACTIVE_LEVEL2', ");
		sql.append(" 'INACTIVE_ACCOUNT', 'SQL_PROFILE' ) AND USERNAME is not null ");

		final List<UserActivityModel> op50Data = getJdbcTemplateHcsop11().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("HCSOP50", (op50Data != null)? op50Data.size():0, sql.toString(), startTm, endTm));
		log.info("HCSOP50 Data Total Rows: "+((op50Data != null)? op50Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return op50Data;
	}

	//OP53
	@Override
	public List<UserActivityModel> getHcsop53UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query HCSOP53 Data.......START");
		Date startTm = new Date();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select USERNAME as USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME, decode(DB_DLET,'Y','N','Y') as EMP_ACTIVE , ");
		sql.append(" ''  as ROLE, 'HCSOP53' as SRC_SYS, sysdate as DT_UPDATED FROM DBA_AUD.USER_AUDT ");
		sql.append(" WHERE SID ='HCSOP53' and profile in ('ENDUSER_PROFILE', 'POWER_PROFILE', 'CLM_USER_PROFILE', 'PWDEXPIRE', 'INACTIVE_LEVEL1', 'INACTIVE_LEVEL2', ");
		sql.append(" 'INACTIVE_ACCOUNT', 'SQL_PROFILE' ) AND USERNAME is not null ");

		final List<UserActivityModel> op53Data = getJdbcTemplateHcsop11().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("HCSOP53", (op53Data != null)? op53Data.size():0, sql.toString(), startTm, endTm));
		log.info("HCSOP53 Data Total Rows: "+((op53Data != null)? op53Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return op53Data;
	}
	//OP40

	@Override
	public List<UserActivityModel> getHcsop40UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query HCSOP40 Data.......START");
		Date startTm = new Date();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select USERNAME as USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME, decode(DB_DLET,'Y','N','Y') as EMP_ACTIVE , ");
		sql.append(" ''  as ROLE, 'HCSOP40' as SRC_SYS, sysdate as DT_UPDATED FROM DBA_AUD.USER_AUDT ");
		sql.append(" WHERE SID ='HCSOP40' and profile in ('ENDUSER_PROFILE', 'POWER_PROFILE', 'CLM_USER_PROFILE', 'PWDEXPIRE', 'INACTIVE_LEVEL1', 'INACTIVE_LEVEL2', ");
		sql.append(" 'INACTIVE_ACCOUNT', 'SQL_PROFILE' ) AND USERNAME is not null ");

		final List<UserActivityModel> op40Data = getJdbcTemplateHcsop11().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("HCSOP40", (op40Data != null)? op40Data.size():0, sql.toString(), startTm, endTm));
		log.info("HCSOP40 Data Total Rows: "+((op40Data != null)? op40Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return op40Data;
	}


	@Override
	public List<UserActivityModel> getIcsUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query ICS Data.......START");
		Date startTm = new Date();
		String sql ="SELECT USER_ID, FIRST_NAME, LAST_NAME, ROLE, 'ICS' as SRC_SYS, USER_STATUS as EMP_ACTIVE , ROLE_GRANTED_DATE as DT_UPDATED FROM ( " +
				"SELECT org.org_name, mem_user.member_name AS user_id, per.FName as FIRST_NAME, per.LName as LAST_NAME, mem_role.member_name AS role, " +
				"DECODE(mem_user.status_flg_vector,0,'Y',1,'N') AS user_status, edge.date_created AS role_granted_date " +
				"FROM  modeln.mn_member mem_user " +
				"INNER JOIN modeln.mn_cmty_edge edge ON edge.source_id = mem_user.member_id " +
				"INNER JOIN modeln.mn_member mem_role ON (edge.dest_id = mem_role.member_id and mem_role.mgr_id = '50135') " +
				"INNER JOIN modeln.mn_user_account usr ON usr.member_id = mem_user.member_id " +
				"INNER JOIN modeln.mn_person per ON per.pers_id = usr.pers_id LEFT OUTER JOIN modeln.mn_org org " +
				"ON (usr.default_org_unit_id = org.org_id) WHERE edge.edge_type = 2 AND dag_id = 0  " +
				"UNION " +
				"SELECT org.org_name, mem_user.member_name, per.FName, per.LName, mem_grp.member_name, " +
				"DECODE(mem_user.status_flg_vector,0,'Y',1,'N'), edge.date_created " +
				"FROM modeln.mn_member mem_user " +
				"INNER JOIN modeln.mn_user_account usr ON usr.member_id = mem_user.member_id  " +
				"INNER JOIN modeln.mn_person per ON per.pers_id = usr.pers_id  " +
				"LEFT OUTER JOIN modeln.mn_org org ON (usr.default_org_unit_id = org.org_id)  " +
				"INNER JOIN modeln.mn_cmty_edge edge ON edge.source_id = mem_user.member_id  " +
				"INNER JOIN modeln.mn_member mem_grp ON (edge.dest_id = mem_grp.member_id and mem_grp.mgr_id = '50107')  " +
				"WHERE edge.edge_type = 1 AND dag_id = 0 ORDER BY 6 DESC NULLS LAST) ics WHERE USER_ID is not null ";
		final List<UserActivityModel> icsData = getJdbcTemplateIcs().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("ICS", (icsData != null)? icsData.size():0, sql.toString(), startTm, endTm));
		log.info("ICS Data Total Rows: "+((icsData != null)? icsData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return icsData;
	}


	@Override
	public List<UserActivityModel> getMdmUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query MDM Data.......START");
		Date startTm = new Date();
		String sql ="Select upper(USER_NAME) as USER_ID, upper(FIRST_NAME) as FIRST_NAME, upper(LAST_NAME) as LAST_NAME, ' ' as ROLE, 'MDM' as SRC_SYS, " +
				"DECODE(USER_ENABLED_IND,1,'Y',0,'N') as EMP_ACTIVE, LAST_UPDATE_DATE as DT_UPDATED from CMX_SYSTEM.C_REPOS_USER WHERE USER_NAME is not null ";
		final List<UserActivityModel> mdmData = getJdbcTemplateMdm().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("MDM", (mdmData != null)? mdmData.size():0, sql, startTm, endTm));
		log.info("MDM Data Total Rows: "+((mdmData != null)? mdmData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return mdmData;
	}


	@Override
	public List<UserActivityModel> getWmsMlcUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query WMS-MLC Data.......START");
		Date startTm = new Date();
		String sql ="SELECT emp_name as USER_ID, ls_emp_first_name as FIRST_NAME, ls_emp_last_name as LAST_NAME, " +
					"menu_id as ROLE, 'WMSMLC' as SRC_SYS, emp_active_flg as EMP_ACTIVE, date_hired as DT_UPDATED from MARC.emp WHERE emp_name is not null ";
		final List<UserActivityModel> wmsMlcData = getJdbcTemplateWmsMlc().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("WMSMLC", (wmsMlcData != null)? wmsMlcData.size():0, sql, startTm, endTm));
		log.info("WMS-MLC Data Total Rows: "+((wmsMlcData != null)? wmsMlcData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return wmsMlcData;
	}

	@Override
	public List<UserActivityModel> getWmsSdcUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query WMS-SDC Data.......START");
		Date startTm = new Date();
		String sql ="SELECT emp_name as USER_ID, ls_emp_first_name as FIRST_NAME, ls_emp_last_name as LAST_NAME, " +
				"menu_id as ROLE, 'WMSSDC' as SRC_SYS, emp_active_flg as EMP_ACTIVE, date_hired as DT_UPDATED from MARC.emp WHERE emp_name is not null ";
		final List<UserActivityModel> wmsSdcData = getJdbcTemplateWmsSdc().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("WMSSDC", (wmsSdcData != null)? wmsSdcData.size():0, sql, startTm, endTm));
		log.info("WMS-SDC Data Total Rows: "+((wmsSdcData != null)? wmsSdcData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return wmsSdcData;
	}



	@Override
	public List<String> getActiveUniqueIdsForSystem(String systemNm) throws SQLException, DataAccessException {
		//String sql = " SELECT DISTINCT USER_ID FROM SOD_EXTR.USER_STAT_DATA " +
		String sql = " SELECT DISTINCT USER_ID||'~'||LAST_NAME||', '||FIRST_NAME FROM SOD_EXTR.USER_STAT_DATA " +
				" WHERE SRC_SYS ='"+systemNm+"' AND EMP_ACTIVE='Y' ORDER BY 1 ";
		final List<String> allSysIds = getJdbcTemplate0459().queryForList(sql, String.class);
		return allSysIds;
	}

	@Override
	public List<String> getActiveUniqueIdsForNonSoxSystem(String systemNm) throws SQLException, DataAccessException {
		String sql = " SELECT DISTINCT USER_ID||'~'||LAST_NAME||', '||FIRST_NAME FROM SOD_EXTR.USER_STAT_NSDATA " +
				" WHERE SRC_SYS ='"+systemNm+"' AND EMP_ACTIVE='Y' ORDER BY 1 ";
		final List<String> allSysIds = getJdbcTemplate0459().queryForList(sql, String.class);
		return allSysIds;
	}

	/*@Override
	public List<UserActivityModel> getCarsIsUserData() throws SQLException, DataAccessException {
		log.info("Query CARSIS Data.......START");
		String sql =" Select upper(TXT_OPR_ID) as USER_ID, SUBSTR(TXT_OPR_NME_LST, 1, (INSTR(TXT_OPR_NME_LST, ' ') - 1)) AS FIRST_NAME, " +
					" SUBSTR(TXT_OPR_NME_LST, (INSTR(TXT_OPR_NME_LST, ' ')+1)) AS LAST_NAME , DECODE(CDE_OPR_STAT,'a','Y','N') as EMP_ACTIVE " +
					",'' as ROLE, 'CARSIS' as SRC_SYS, sysdate as DT_UPDATED from CARS_PROD.TOPR" ;

		final List<UserActivityModel> carsIsData = getJdbcTemplateCarsIs().query(sql, new Object[] {}, new BeanPropertyRowMapper<UserActivityModel>(UserActivityModel.class));
		log.info("CARSIS Data Total Rows: "+carsIsData.size()+"  .......END");
		return carsIsData;
	}

	@Override
	public List<UserActivityModel> getCarsMaUserData() throws SQLException, DataAccessException {
		log.info("Query CARSMA Data.......START");
		String sql ="SELECT  UPPER(TXT_OPR_ID) as USER_ID, SUBSTR(TXT_OPR_NME_LST, 1, (INSTR(TXT_OPR_NME_LST, ' ') - 1)) AS FIRST_NAME, " +
					"SUBSTR(TXT_OPR_NME_LST, (INSTR(TXT_OPR_NME_LST, ' ')+1)) AS LAST_NAME, TOPR_ACT_FLG AS EMP_ACTIVE, " +
					"'' as ROLE, 'CARSMA' as SRC_SYS, LASTMOD as DT_UPDATED FROM  CARSMA.TOPR " ;

		final List<UserActivityModel> carsMaData = getJdbcTemplateCarsMa().query(sql, new Object[] {}, new BeanPropertyRowMapper<UserActivityModel>(UserActivityModel.class));
		log.info("CARSIS Data Total Rows: "+carsMaData.size()+"  .......END");
		return carsMaData;
	}*/




	@Override
	public String insertUserActivityData(List<UserActivityModel> dataList)throws SQLException, DataAccessException{
		 SimpleJdbcInsert devJdbcInsert = getUserSimpleJdbcInsert459();
	        List<Map<String, Object>> batchValues = new ArrayList<>(dataList.size());
	        Date addedDate = new Date();
	        for (UserActivityModel actMdl : dataList) {
	            Map<String, Object> map = new HashMap<>();
	            String userId = actMdl.getUserId();
	            if(userId != null && userId.length() > 16) {
	            	userId = userId.substring(0,15);
	            }
	            map.put("USER_ID", userId);
	            map.put("FIRST_NAME", actMdl.getFirstName());
	            map.put("LAST_NAME", actMdl.getLastName());
	            map.put("ROLE", actMdl.getRole());
	            map.put("SRC_SYS", actMdl.getSrcSys());
	            map.put("EMP_ACTIVE", actMdl.getEmpActive());
	            map.put("DT_UPDATED", actMdl.getDtUpdated());
	            map.put("DT_ADDED", addedDate);
	            batchValues.add(map);
	        }

	        if (!devJdbcInsert.isCompiled()) {
	        	devJdbcInsert.includeSynonymsForTableColumnMetaData()
	        	.withSchemaName("SOD_EXTR")
	        	.withTableName("USER_STAT_DATA");
	        }
	        int[] status = devJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));
	        return status.length == batchValues.size() ? "Success" : "Failed";
	}

	@Override
	public int clearUserCache()throws SQLException, DataAccessException{
		//String sql = " DELETE FROM SOD_EXTR.USER_STAT_DATA WHERE SRC_SYS <> 'CARSMA' ";
		String sql = " DELETE SOD_EXTR.USER_STAT_DATA";
	 	int count =   getJdbcTemplate0459().update(sql);
	 	return count;
	}


	@Override
	public int clearNonSoxUserCache()throws SQLException, DataAccessException{
		String sql = " DELETE SOD_EXTR.USER_STAT_NSDATA";
	 	int count =   getJdbcTemplate0459().update(sql);
	 	return count;
	}

	private TermDataSmryModel buildLog(String appNm, int count, String sql, Date startTm, Date endTm) {
		TermDataSmryModel mdl = new TermDataSmryModel();
		mdl.setAppNm(appNm);
		mdl.setCount(count);
		mdl.setSql(sql);
		mdl.setStartTm(startTm);
		mdl.setEndTm(endTm);
		mdl.setTotalTime(endTm.getTime() - startTm.getTime());
		return mdl;
	}

	/*NON-SOX SYSTEMS - Reading Data from MRAP0751 SOD Database*/

	@Override
	public List<UserActivityModel> get340BR2UserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query 340B-R2 Data.......START");
		Date startTm = new Date();
		String sql =" SELECT USER_NAME AS USER_ID, USER_FIRST_NM as FIRST_NAME, USER_LAST_NM as LAST_NAME, '' AS ROLE, '340BR2' as SRC_SYS, "+
					" USER_STAT as EMP_ACTIVE, SYSDATE as DT_UPDATED "+
					" FROM SOD_EXTR.JJ340B_EXTR_MV WHERE USER_ID is not null ";
		final List<UserActivityModel> br2340Data = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("340BR2", (br2340Data != null)? br2340Data.size():0, sql, startTm, endTm));
		log.info("340BR2 Data Total Rows: "+((br2340Data != null)? br2340Data.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return br2340Data;
	}



	@Override
	public List<UserActivityModel> getEmsNextGenUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query EMSNEXTGEN Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_NAME AS USER_ID, FIRST_NAME, LAST_NAME, '' AS ROLE, 'EMSNEXTGEN' as SRC_SYS, 'Y' as EMP_ACTIVE, ADD_DATE as DT_UPDATED "+
					 " FROM SOD_EXTR.ENG_EXTR_MV WHERE USER_NAME is not null ";
		final List<UserActivityModel> engData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("EMSNEXTGEN", (engData != null)? engData.size():0, sql, startTm, endTm));
		log.info("EMSNEXTGEN Data Total Rows: "+((engData != null)? engData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return engData;
	}

	@Override
	public List<UserActivityModel> getFalconUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query FALCON Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_NAME AS USER_ID, USER_FIRST_NM AS FIRST_NAME, USER_LAST_NM AS LAST_NAME, '' AS ROLE, 'FALCON' AS SRC_SYS, "+
					 " 'Y' AS EMP_ACTIVE, sysdate as DT_UPDATED "+
					 " FROM SOD_EXTR.FALCON_EXTR_MV WHERE USER_NAME is not null ";
		final List<UserActivityModel> falconData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("FALCON", (falconData != null)? falconData.size():0, sql, startTm, endTm));
		log.info("FALCON Data Total Rows: "+((falconData != null)? falconData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return falconData;
	}

	@Override
	public List<UserActivityModel> getFomUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query FOM Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_ID, FNAME AS FIRST_NAME, LNAME AS LAST_NAME, '' AS ROLE, 'FOM' AS SRC_SYS, DECODE(STATUS,'ACTIVE','Y','N') AS EMP_ACTIVE, " +
				 	 " sysdate as DT_UPDATED FROM SOD_EXTR.FOM_EXTR WHERE USER_ID is not null ";
		final List<UserActivityModel> fomData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("FOM", (fomData != null)? fomData.size():0, sql, startTm, endTm));
		log.info("FOM Data Total Rows: "+((fomData != null)? fomData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return fomData;
	}

	@Override
	public List<UserActivityModel> getFTCCUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query FTCC Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_ID, SUBSTR(USER_NM, 1, INSTR(USER_NM, ' ')) AS FIRST_NAME, SUBSTR(USER_NM, INSTR(USER_NM, ' ')) AS LAST_NAME, "+
					 " '' AS ROLE, 'FTCC' AS SRC_SYS, USER_STAT_CD AS EMP_ACTIVE, sysdate as DT_UPDATED "+
					 " FROM SOD_EXTR.FTCC_EXTR_MV WHERE USER_ID is not null ";
		final List<UserActivityModel> ftccData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("FTCC", (ftccData != null)? ftccData.size():0, sql, startTm, endTm));
		log.info("FTCC Data Total Rows: "+((ftccData != null)? ftccData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return ftccData;
	}


	@Override
	public List<UserActivityModel> getPVCSUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query PVCS Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USERNAME AS USER_ID, '' AS FIRST_NAME, '' AS LAST_NAME, ROLENAME AS ROLE, 'PVCS' AS SRC_SYS, 'Y' AS EMP_ACTIVE, sysdate as DT_UPDATED " +
					 " FROM SOD_EXTR.PVCS_EXTR WHERE USERNAME is not null ";
		final List<UserActivityModel> pvcsData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("PVCS", (pvcsData != null)? pvcsData.size():0, sql, startTm, endTm));
		log.info("PVCS Data Total Rows: "+((pvcsData != null)? pvcsData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return pvcsData;
	}

	@Override
	public List<UserActivityModel> getRMSJAPANUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query RMSJAPAN Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_ID, SUBSTR(USERNAME, 1, INSTR(USERNAME, ' ')) AS FIRST_NAME, SUBSTR(USERNAME, INSTR(USERNAME, ' ')) AS LAST_NAME, " +
					 " ROLE, 'RMSJAPAN' AS SRC_SYS, DECODE(USER_STATUS,'Active','Y','N') AS EMP_ACTIVE, sysdate as DT_UPDATED " +
					 " FROM SOD_EXTR.RMSJAPAN_EXTR  WHERE USER_ID is not null ";
		final List<UserActivityModel> rmsData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("RMSJAPAN", (rmsData != null)? rmsData.size():0, sql, startTm, endTm));
		log.info("RMSJAPAN Data Total Rows: "+((rmsData != null)? rmsData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return rmsData;
	}

	@Override
	public List<UserActivityModel> getTMUserData(List<TermDataSmryModel> sysList) throws SQLException, DataAccessException {
		log.info("Query TM Data.......START");
		Date startTm = new Date();
		String sql = " SELECT USER_ID, SUBSTR(NAME, 1, INSTR(NAME, ' ')) AS FIRST_NAME, SUBSTR(NAME, INSTR(NAME, ' ')) AS LAST_NAME, " +
					 " ROLE, 'TM' AS SRC_SYS, 'Y' AS EMP_ACTIVE, sysdate as DT_UPDATED " +
					 " FROM SOD_EXTR.TM_EXTR  WHERE USER_ID is not null " ;
		final List<UserActivityModel> tmData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UserActivityModel.class));
		Date endTm = new Date();
		sysList.add(buildLog("TM", (tmData != null)? tmData.size():0, sql, startTm, endTm));
		log.info("TM Data Total Rows: "+((tmData != null)? tmData.size():0)+"  .......END"+ " Total time : "+(endTm.getTime() - startTm.getTime()));
		return tmData;
	}


	@Override
	public String insertNonSoxUserActivityData(List<UserActivityModel> dataList)throws SQLException, DataAccessException{
		 SimpleJdbcInsert devJdbcInsert = getUserSimpleJdbcInsert459();
	        List<Map<String, Object>> batchValues = new ArrayList<>(dataList.size());
	        Date addedDate = new Date();
	        for (UserActivityModel actMdl : dataList) {
	            Map<String, Object> map = new HashMap<>();
	            String userId = actMdl.getUserId();
	            if(userId != null && userId.length() > 16) {
	            	userId = userId.substring(0,15);
	            }
	            map.put("USER_ID", userId);
	            map.put("FIRST_NAME", actMdl.getFirstName());
	            map.put("LAST_NAME", actMdl.getLastName());
	            map.put("ROLE", actMdl.getRole());
	            map.put("SRC_SYS", actMdl.getSrcSys());
	            map.put("EMP_ACTIVE", actMdl.getEmpActive());
	            map.put("DT_UPDATED", actMdl.getDtUpdated());
	            map.put("DT_ADDED", addedDate);
	            batchValues.add(map);
	        }

	        if (!devJdbcInsert.isCompiled()) {
	        	devJdbcInsert.includeSynonymsForTableColumnMetaData()
	        	.withSchemaName("SOD_EXTR")
	        	.withTableName("USER_STAT_NSDATA");
	        }
	        int[] status = devJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));
	        return status.length == batchValues.size() ? "Success" : "Failed";
	}




}
