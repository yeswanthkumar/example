package com.jnj.rqc.userabs.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSodConflictRespDto;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RolesRespDto;
import com.jnj.rqc.useridentity.models.EmailItem;


public interface UserAccessDataService {

	public RolesRespDto getExistingRoles(String userId);

	//Individual Systems
	public List<IAMRolesADGrpMdl> getPFBSystemRolesADGrpData(String templSysParam, String userId);
	public List<IAMRolesADGrpMdl> readPFICFINRolesPosnData(String templSysParam, String userId);
	public List<IAMRolesADGrpMdl> readGRCSYSUserRolesPosnData(String templSysParam, String userId);


	//Common Method
	public List<RoleADGrpMdl> getSystemDetail(String ldapADGroup);
	public List<RoleADGrpMdl> getCFINRoleDetail(String tchRole);
	public List<RoleADGrpMdl> getAnaplanRoleDetail(String tchRole);


	/**
	 * Method  : UserAccessDataService.java.checkAbsSodConflicts()
	 *		   :<b>@param wwId
	 *		   :<b>@param newRoles
	 *		   :<b>@param extRoles
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 30, 2023 10:36:16 AM
	 * Purpose : SOD CONFLICTS
	 * @return : AbsSodConflictRespDto
	*/
	public AbsSodConflictRespDto checkAbsSodConflicts(String wwId, List<RoleADGrpMdl> newRoles, List<RoleADGrpMdl> extRoles);

	/**
	 * Method  : UserAccessDataService.java.checkExcessiveAccess()
	 *		   :<b>@param assocUser
	 *		   :<b>@param extRoles
	 *		   :<b>@param newRoles
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 30, 2023 3:25:57 PM
	 * Purpose : EXCESSIVE ACCESS CHECK PER SYSTEM
	 * @return : List<AbsExcesvAccsMdl>
	 * @throws Exception
	*/
	public List<AbsExcesvAccsMdl> checkExcessiveAccess(UserSearchModel assocUser, Map<String, List<RoleADGrpMdl>> exstRoles, Map<String, List<RoleADGrpMdl>> newRoles) throws Exception;

	/**
		 * Method  : UserAccessDataService.java.getSystemRoleDetail()
		 *		   :<b>@param ldapADGroup
		 *		   :<b>@param sysId
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 5, 2023 4:55:11 PM
		 * Purpose :
		 * @return : List<RoleADGrpMdl>
		 */
	public List<RoleADGrpMdl> getSystemRoleDetail(String ldapADGroup, String sysId);
	
	public List<RoleADGrpMdl> getAllSystemRoleDetail(String ldapADGroup, String sysId);

	public Map<String, List<RoleADGrpMdl>> getSystemsExistingRoles(String userId);

	public Map<String, List<RoleADGrpMdl>> getSectorWiseSysPvData(List<RoleADGrpMdl> selectedAdgrps, String sysId);

	public List<AbsSysLeveExcsvRestrMdl> checkRestrtvExcessiveAccess(UserSearchModel assocUser, Map<String, List<RoleADGrpMdl>> exstRoles, Map<String, List<RoleADGrpMdl>> newRoles, Boolean isReport) throws Exception;

	public List<EmailItem> loadAllEmailDimensionsFromAnaPlan();










}
