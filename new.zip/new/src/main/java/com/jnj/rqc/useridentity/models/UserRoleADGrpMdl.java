package com.jnj.rqc.useridentity.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleADGrpMdl {
	private int reqId;
	private String userId;
	private String sysId;
	private String sysName;
	private String posId;
	private String posName;
	private String pvId;
	private String pvName;
	private String adgrpId;
	private String adgrpName;
	private String reqBy;
	private Date reqDate;
	private Date updDate ;
	private String isExisting;
}
