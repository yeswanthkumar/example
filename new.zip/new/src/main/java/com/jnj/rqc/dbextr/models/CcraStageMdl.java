package com.jnj.rqc.dbextr.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;


@Data
public class CcraStageMdl {
	private String wwid;
	private String userid;
	private String firstNm;
	private String lastNm;
	private String co;
	private String applRole;
	private Date addDt;
	private Date updateDt;

	public String getData() {
		return   wwid + "~" +userid + "~" + firstNm + "~" +lastNm + "~" + co + "~"+applRole+"~"+Utility.fmtMMDDYYYY(addDt)+"~"+Utility.fmtMMDDYYYY(updateDt) ;
	}

}
