package com.jnj.rqc.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppDataModel {
	private int applnId;
	private String applnNm;
	private String applnDescn;
	private int display;
	private String helpfullTip;
	private String chk;
	private String remChk;
    private int grpId;
    private int applnCatId;
    private int applnSubCatId;
    private String grpNm;
    private String appOrd;
    private List<PosRoles> roles;

	@Override
	public String toString() {
		return "AppDataModel [applnId=" + applnId + ", applnNm=" + applnNm + ", applnDescn=" + applnDescn + ", display="
				+ display + ", helpfullTip=" + helpfullTip + ", chk=" + chk + ", remChk=" + remChk + ", grpId=" + grpId
				+ ", applnCatId=" + applnCatId + ", applnSubCatId=" + applnSubCatId + ", grpNm=" + grpNm + ", appOrd="
				+ appOrd + "]";
	}


}
