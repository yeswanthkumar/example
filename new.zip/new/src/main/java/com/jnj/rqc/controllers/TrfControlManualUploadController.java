package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.ManualUploadDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


@Controller
public class TrfControlManualUploadController {
	static final Logger log = LoggerFactory.getLogger(TrfControlManualUploadController.class);
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;

	@Autowired
	ManualUploadDataService manualUploadDataService;

	@Autowired
	GenesisDao genesisDao;
	@Autowired
	EmailUtil emailUtil;



	@GetMapping("/uploadManualUser2SodData")
    public String uploadManualUser2SodData(Model model, HttpServletRequest request) {
    	log.info("User to Sod Manual Upload Page");
    	return "sapextraction/manualUploadUser2Sod";
    }

	@PostMapping("/manualUploadUser2SodProcess")
    public String manualUploadUser2SodProcess(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected User to Sod File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the right file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "sapextraction/manualUploadUser2Sod";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel File/Document...!");
            return "sapextraction/manualUploadUser2Sod";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<SapUser2SodModel> u2sData = manualUploadDataService.readUser2SodExcel(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("U2S_MANUAL_FILEDATA");
    		if(u2sData != null && !u2sData.isEmpty()) {
    			SapUser2SodModel mdl=u2sData.get(0);
    			session.setAttribute("U2S_FILENAME", file.getOriginalFilename());
    			session.setAttribute("U2S_PLATFORM", mdl.getPlatformName());
    			//session.setAttribute("U2S_CLIENT", mdl.getPlatformName());
    			session.setAttribute("U2S_MANUAL_FILEDATA", u2sData);
        		model.addAttribute("U2S_MANUAL_FILEDATA", u2sData);
    		}

    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((u2sData != null && !u2sData.isEmpty())? u2sData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/manualUploadUser2Sod";
    }


	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/exportManualUser2SodData")
    public ResponseEntity<InputStreamResource> exportManualUser2SodData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Exporting Manual User to SOD Data to GENESIS");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "MANUALSOD_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("U2S_FILENAME");
        	String platfrm = (String)sess.getAttribute("U2S_PLATFORM");
        	int recordsIns = 0;
    		logData.append("Exporting Manual User to Sod Data to GENESIS for : "+platfrm);
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<SapUser2SodModel> u2sData = (List<SapUser2SodModel>)request.getSession().getAttribute("U2S_MANUAL_FILEDATA");
        	logData.append("Total Records in file : "+u2sData.size()+"\n");
        	logData.append("Exporting "+u2sData.size()+" Records to GENESIS \n");
        	try {
        		recordsIns = genesisDao.insertUser2SodData(u2sData);
    		} catch (Exception e) {
    			logData.append("Total Records exported to GENESIS : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for :"+platfrm+" - "+e.getMessage(), e);
    		}
        	logData.append("Total User to Sod Records exported to GENESIS : "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "MANUAL_"+platfrm+"_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	String envName = Utility.getServerProp("ENVIRONMENT");
        	String subject = " MANUAL ERP USER TO SOD Data Export to GENESIS for SYSTEM: "+platfrm+" @DateTime: "+Utility.fmtMMDDYYYYTime(new Date());
        	try {
				emailUtil.sendProcessingEmail(envName+" - "+subject, platfrm, flNm, u2sData.size(), recordsIns, user, "M");
			} catch (Exception e) {
				log.error("Error Sending USER TO SOD Manual Upload Email :"+e.getMessage(), e);
			}
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@GetMapping("/uploadManualUser2RoleData")
    public String uploadManualUser2RoleData(Model model, HttpServletRequest request) {
    	log.info("User to Role Manual Upload Page");
    	return "sapextraction/manualUploadUser2Role";
    }


	@PostMapping("/manualUploadUser2RoleProcess")
    public String manualUploadUser2RoleProcess(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected User to Role File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the right file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "sapextraction/manualUploadUser2Role";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel file/Document...!");
            return "sapextraction/manualUploadUser2Role";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<SapGaaUser2RoleModel> u2rData = manualUploadDataService.readUser2RoleExcel(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("U2R_MANUAL_FILEDATA");
    		if(u2rData != null && !u2rData.isEmpty()) {
    			SapGaaUser2RoleModel mdl=u2rData.get(0);
    			session.setAttribute("U2R_FILENAME", file.getOriginalFilename());
    			session.setAttribute("U2R_PLATFORM", mdl.getAdditionalInfo1());
    			String client = mdl.getPrimaryReviewInfo3().replaceAll("Within ", "");
    			session.setAttribute("U2R_CLIENT", client);
    			session.setAttribute("U2R_MANUAL_FILEDATA", u2rData);
        		model.addAttribute("U2R_MANUAL_FILEDATA", u2rData);
    		}

    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((u2rData != null && !u2rData.isEmpty())? u2rData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/manualUploadUser2Role";
    }

	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/exportManualUser2RoleData")
    public ResponseEntity<InputStreamResource> exportManualUser2RoleData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Exporting Manual User to Role Data to GENESIS");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "MANUAL_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("U2R_FILENAME");
        	String platfrm = (String)sess.getAttribute("U2R_PLATFORM")+"_"+(String)sess.getAttribute("U2R_CLIENT");
        	int recordsIns = 0;
    		logData.append("Exporting Manual User to Role Data to GENESIS for : "+platfrm);
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<SapGaaUser2RoleModel> u2rData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("U2R_MANUAL_FILEDATA");
        	logData.append("Total Records in file : "+u2rData.size()+"\n");
        	logData.append("Exporting "+u2rData.size()+" Records to GENESIS \n");
        	try {
        		recordsIns = genesisDao.insertUser2RoleData(u2rData);
    		} catch (Exception e) {
    			logData.append("Total Records exported to GENESIS : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for :"+platfrm+" - "+e.getMessage(), e);
    		}
        	logData.append("Total User to Role Records exported to GENESIS : "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "MANUAL_"+platfrm+"_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	sendManualProcessEmail(platfrm, flNm, u2rData.size(), recordsIns, "U", user);
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


    @GetMapping("/uploadManualTrfContrlData")
    public String uploadManualTrfContrlData(Model model, HttpServletRequest request) {
    	log.info("Transfer Control Manual Upload Page");
    	return "sapextraction/manualUploadTrfCntrl";
    }

    @PostMapping("/manualUploadTrfCntrlProcess")
    public String manualUploadTrfCntrlProcess(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected Tranfer Control File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the right file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload XLS file is required!");
            return "sapextraction/manualUploadTrfCntrl";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel file/Document...!");
            return "sapextraction/manualUploadTrfCntrl";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<SAPUserAccessModel> trfData = manualUploadDataService.readTrfControlExcel(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("TRF_MANUAL_FILEDATA");
    		if(trfData != null && !trfData.isEmpty()) {
    			SAPUserAccessModel mdl=trfData.get(0);
    			session.setAttribute("SYS_FILENAME", file.getOriginalFilename());
    			session.setAttribute("SYS_PLATFORM", mdl.getSapPlatform());
    			session.setAttribute("SYS_CLIENT", mdl.getSystemClient());
    			session.setAttribute("TRF_MANUAL_FILEDATA", trfData);
        		model.addAttribute("TRF_MANUAL_FILEDATA", trfData);
    		}

    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((trfData != null && !trfData.isEmpty())? trfData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/manualUploadTrfCntrl";
    }



    @ResponseBody
    @GetMapping("/exportManualTransferCntrlData")
    public ResponseEntity<InputStreamResource> exportManualTransferCntrlData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Exporting Manual Transfer Control Data to GENESIS");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "MANUAL_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("SYS_FILENAME");
        	String platfrm = (String)sess.getAttribute("SYS_PLATFORM")+"_"+(String)sess.getAttribute("SYS_CLIENT");
        	int recordsIns = 0;
    		logData.append("Exporting Manual Transfer Control Data to GENESIS for : "+platfrm);
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<SAPUserAccessModel> trfData = (List<SAPUserAccessModel>)request.getSession().getAttribute("TRF_MANUAL_FILEDATA");
        	logData.append("Total Records in file : "+trfData.size()+"\n");
        	logData.append("Exporting "+trfData.size()+" Records to GENESIS \n");
        	try {
        		recordsIns = genesisDao.insertTrfCntrlData(trfData);
    		} catch (Exception e) {
    			logData.append("Total Records exported to GENESIS : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for :"+platfrm+" - "+e.getMessage(), e);
    		}
        	logData.append("Total Records exported to GENESIS : "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "MANUAL_"+platfrm+"_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	sendManualProcessEmail(platfrm, flNm, trfData.size(), recordsIns, "T", user);
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	private String sendManualProcessEmail(String platform, String fileName, int totRecs, int exportRec, String sType, UserSearchModel user ) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String subject=("T".equals(sType))? "MANUAL ERP TRANSFER CONTROL Data Export to GENESIS for SYSTEM: ":"MANUAL ERP USER TO ROLE Data Export to GENESIS for SYSTEM: ";
			subject+=" "+platform+" @DateTime: "+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendProcessingEmail(envName+" - "+subject, platform, fileName, totRecs, exportRec, user, sType);
		} catch (Exception e) {
			log.error("ERROR Sending "+envName+" Transfer Control message: "+e.getMessage(), e);
		}
		return null;
	}

    /*
    @ResponseBody
    @GetMapping("/downloadMemPdf")
    public ResponseEntity<InputStreamResource> downloadPdf(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<MemRevieModel> result = (List<MemRevieModel>)request.getSession().getAttribute("NAGSREVIEWDATA");
    	int mon = (Integer)request.getSession().getAttribute("MON");
    	int yrs = (Integer)request.getSession().getAttribute("YRS");
    	String filePath = memberReviewService.writePdfOrCsv("PDF", mon, yrs, result);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.APPLICATION_PDF)
        	.contentLength(fl.length())
        	.body(resource);
    }


    //Method Created for Getting SRC_SYS wise Member Role Assignments
    @GetMapping("/srcMemWiseAppRoles")
    public String memReport(Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Starting srcMemWiseAppRoles ");

    		List<String> srcSystem = Utility.getSourceSystems();
    		srcSystem.forEach(sysID ->{
    			try{
    				log.info("<======== Starting Report for SRC_SYS :"+sysID+" ========>");
    				List<SrcSysMemRoleModel> result = memberReviewService.processMemReport(sysID);
    				String filePath = memberReviewService.writeCsvReport(result, sysID);
    				log.info("filePath: "+filePath);
    				log.info("<======== Completed Report for SRC_SYS :"+sysID+" ========>");
    				//redirectAttributes.addFlashAttribute("result", result);

    			} catch (Exception e) {
    	            log.error("Error uploading file :"+e.getMessage(), e);
    	        	e.printStackTrace();
    	        }
    		});
    		redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("success", "Status: SUCCESS");

        return "";
    }

 */



}