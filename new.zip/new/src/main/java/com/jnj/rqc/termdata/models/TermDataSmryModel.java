package com.jnj.rqc.termdata.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TermDataSmryModel {
	private String appNm;
	private int count;
	private String sql;
	private Date startTm;
	private Date endTm;
	private long totalTime;
	String fileName;

	@Override
	public String toString() {
		return "TermDataSmryModel [appNm=" + appNm + ", count=" + count + ", sql=" + sql + ", startTm=" + startTm
				+ ", endTm=" + endTm + ", fileName"+fileName+"]";
	}


}
