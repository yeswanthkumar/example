package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.models.AppRoutingModel;

public interface AppEmailRoutingService {
	public Map<String, List<AppRoutingModel>> getAllAppRoutingDetails(HttpServletRequest request);
	public List<AppRoutingModel> filterAppRoutingCategory(String category, Map<String, List<AppRoutingModel>> dataMap);
}
