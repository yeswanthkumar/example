package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapPlatformReviwerMdl {
	private String platform;
	private String riskId;
	private String reviewerId;


	@Override
	public String toString() {
		return "SapPlatformReviverMdl [platform=" + platform + ", riskId=" + riskId + ", reviewerId=" + reviewerId
				+ "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		SapPlatformReviwerMdl other = (SapPlatformReviwerMdl) obj;
		if (platform == null) {
			if (other.platform != null)
				return false;
		} else if (!platform.equals(other.platform))
			return false;
		if (riskId == null) {
			if (other.riskId != null)
				return false;
		} else if (!riskId.equals(other.riskId))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((platform == null) ? 0 : platform.hashCode());
		result = prime * result + ((reviewerId == null) ? 0 : reviewerId.hashCode());
		result = prime * result + ((riskId == null) ? 0 : riskId.hashCode());
		return result;
	}





}
