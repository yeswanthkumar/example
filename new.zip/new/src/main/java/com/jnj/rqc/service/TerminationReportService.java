package com.jnj.rqc.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.jnj.rqc.terminations.models.TerminationModel;

public interface TerminationReportService {
	public String saveFile(MultipartFile file) throws IOException;
	public List<TerminationModel> processTerminationReport(String path, HttpServletRequest request);
	//public Map<String, TerminationModel> loadTerminationFile(String path);
	public List<TerminationModel> loadTerminationFile(String path);
	//public List<TerminationModel> populateTermDBData(Map<String, TerminationModel> dataMap);
	public List<TerminationModel> populateTermDBData(List<TerminationModel> dataList);
	public String writeTerminationCSVReview(String type, List<TerminationModel>data);

}
