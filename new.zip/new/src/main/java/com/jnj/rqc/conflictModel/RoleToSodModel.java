package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RoleToSodModel {

	private String sodConflict;
	private String description;
	private String normId;
	private String newNormId;
	private String reasonCode;
	private String normReasonCode;
	private String definition;
	private String expression;
	private String variant;
	private String role;
	private String roleDescription;
	private String c;
	private String isSuper;
	private String logicalSystem;
	private String query1;
	private String queryName1;
	private String queryDescription1;
	private String norm1;//2nd norm field
	private String normId1;
	private String authorization1;
	private String tCode1;
	private String executed1;
	private String query2;//2nd Query field
	private String queryName2;
	private String queryDescription2;
	private String norm2;
	private String normId2;
	private String authorization2;
	private String tCode2;
	private String executed2;

	@Override
	public String toString() {
		return "RoleToSodModel [sodConflict=" + sodConflict + ", description=" + description + ", normId=" + normId
				+ ", newNormId=" + newNormId + ", reasonCode=" + reasonCode + ", normReasonCode=" + normReasonCode
				+ ", definition=" + definition + ", expression=" + expression + ", variant=" + variant + ", role="
				+ role + ", roleDescription=" + roleDescription + ", c=" + c + ", isSuper=" + isSuper
				+ ", logicalSystem=" + logicalSystem + ", query1=" + query1 + ", queryName1=" + queryName1
				+ ", queryDescription1=" + queryDescription1 + ", norm1=" + norm1 + ", normId1=" + normId1
				+ ", authorization1=" + authorization1 + ", tCode1=" + tCode1 + ", executed1=" + executed1 + ", query2="
				+ query2 + ", queryName2=" + queryName2 + ", queryDescription2=" + queryDescription2 + ", norm2="
				+ norm2 + ", normId2=" + normId2 + ", authorization2=" + authorization2 + ", tCode2=" + tCode2
				+ ", executed2=" + executed2 + "]";
	}

	public String getData() {
		return sodConflict + "~" + description + "~" + normId+ "~" + newNormId + "~" + reasonCode + "~" + normReasonCode
				+ "~" + definition + "~" + expression + "~" + variant + "~" + role + "~" + roleDescription + "~" + c + "~" + isSuper
				+ "~" + logicalSystem + "~" + query1 + "~" + queryName1 + "~" + queryDescription1 + "~" + norm1 + "~" + normId1
				+ "~" + authorization1 + "~" + tCode1 + "~" + executed1 + "~" + query2 + "~" + queryName2 + "~" + queryDescription2
				+ "~" + norm2 + "~" + normId2 + "~" + authorization2 + "~" + tCode2 + "~" + executed2;
	}






}
