package com.jnj.rqc.useridentity.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusinessProcessModel {
	String bpId;
	String bpName;
	String bpDescription;
	String isActive;


	@Override
	public String toString() {
		return "BusinessProcessModel [bpId=" + bpId + ", bpName=" + bpName + ", bpDescription=" + bpDescription
				+ ", isActive=" + isActive + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BusinessProcessModel other = (BusinessProcessModel) obj;
		if (bpDescription == null) {
			if (other.bpDescription != null)
				return false;
		} else if (!bpDescription.equals(other.bpDescription))
			return false;
		if (bpId == null) {
			if (other.bpId != null)
				return false;
		} else if (!bpId.equals(other.bpId))
			return false;
		if (bpName == null) {
			if (other.bpName != null)
				return false;
		} else if (!bpName.equals(other.bpName))
			return false;
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bpDescription == null) ? 0 : bpDescription.hashCode());
		result = prime * result + ((bpId == null) ? 0 : bpId.hashCode());
		result = prime * result + ((bpName == null) ? 0 : bpName.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		return result;
	}





}
