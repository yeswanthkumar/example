package com.jnj.rqc.useridentity.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamAdGrpRequestDTO {
	private String CCC_ActionType ;
	private String CCC_Reason;
	private String CCC_Recipient;
	private String CCC_Requestor;
	private String CCC_RequestType;
	private String CCC_ResourceName;
	private String CCC_ExpiresInHours; //Optional Hours to expire access
 	//private boolean CCC_IsTempAccess; //Optiona True/False
}
