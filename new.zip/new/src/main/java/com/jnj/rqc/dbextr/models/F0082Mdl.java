package com.jnj.rqc.dbextr.models;


import lombok.Data;


@Data
public class F0082Mdl {
	private String mNMNI;
	private String mNSY;
	private String mNXMN;
	private String mNOCMN;
	private String mNLOD;
	private String mNDSST;
	private String mNTXIC;
	private String mNMNUT;
	private String mNUSER;
	private String mNPID;
	private String mNUPMJ;
	private String mNJOBN;
	private String mNUPMT;
	private String mNMSKA;
	private String mNMSKJ;
	private String mNMSKK;
	private String mNMSKD;
	private String mNMSKF;

	public String getData() {
		return  mNMNI+"~"+mNSY+"~"+mNXMN+"~"+mNOCMN+"~"+mNLOD+"~"+mNDSST+"~"+mNTXIC+"~"+mNMNUT+"~"+mNUSER+"~"+mNPID+"~"
				+mNUPMJ+"~"+mNJOBN+"~"+mNUPMT+"~"+mNMSKA+"~"+mNMSKJ+"~"+mNMSKK+"~"+mNMSKD+"~"+mNMSKF;
	}

}
