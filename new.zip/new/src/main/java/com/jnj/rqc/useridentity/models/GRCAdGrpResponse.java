package com.jnj.rqc.useridentity.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GRCAdGrpResponse {
	private String REQUEST_ID;
	private String REQUEST_NO;
	private String ROLE_STATUS;
	private String ROLE_STATUS_TYPE;
	private String ROLE_STATUS_COUNT;
	private String REQUEST_REASON;
	private long LAST_UPDATED;
	private int ROLE_COUNT;
	private String REQUEST_CREATED;
	private String ROLE_COUNT_TEXT;
	private String REQUEST_FOR;
	private String CREATED_BY_OR_FOR;
	private String STAGE;
	private String PARENT_REQNO;
	private String PARENT_GUID;
	private String PENDING_WITH;
	private String VALID_FROM;
	private String VALID_TO;
	private String REQTYPE;
	private String CREATED_BY;
	private String CREATED_BY_WWID;
}
