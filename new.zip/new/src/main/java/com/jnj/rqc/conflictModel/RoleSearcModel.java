package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RoleSearcModel {
	private int idType;
	private String userId;
	private String data;
}
