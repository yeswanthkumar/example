package com.jnj.rqc;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchResult;

public class TestLDAPLogin {
      static boolean Result = false;

      /**
      * @param args
      */
      public static void main(String[] args) {
            // TODO Auto-generated method stub
            try {
                String jnjmsusername = null;
                String password = null;
                String LDAP_URL = "ldap://jnjdir.jnj.com:389";
                Hashtable<String, String> sysEnv = new Hashtable<>();
                jnjmsusername = "DCHAURAS@its.jnj.com";//"lkodavat@na.jnj.com";
                password = "Shlok3012#";
				sysEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
                sysEnv.put(Context.PROVIDER_URL, LDAP_URL);
                sysEnv.put(Context.REFERRAL, "ignore");
                sysEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
                sysEnv.put(Context.SECURITY_PRINCIPAL, jnjmsusername);
                sysEnv.put(Context.SECURITY_CREDENTIALS, password);
                DirContext ldapDir = new InitialDirContext(sysEnv);
                Result = true;

                String searchBase = "OU=memberOf,DC=jnj,DC=com";//"DC=jnj,DC=com";//"OU=Accounts,DC=jnj,DC=com" ;//"OU=Service Accounts,DC=jnj,DC=com"
    			NamingEnumeration<SearchResult> enumeration = ldapDir.search( searchBase, null);
    			int j=1;
    			while (enumeration.hasMoreElements()) {
    				SearchResult result = enumeration.next();
    				Attributes attribs = result.getAttributes();
    				System.out.println(j+". Attributes:"+attribs);
    				System.out.println(j+". Object:"+result.getClassName());
    				//NamingEnumeration<String> attribsIDs = attribs.getIDs();
    				j++;
    	        }
    		} catch (AuthenticationNotSupportedException authNE) {
				Result = false;
				System.out.print("Bad Authentication" + authNE.getStackTrace());
				authNE.printStackTrace();
            } catch (AuthenticationException e) {
                 System.out.print("AuthenticationException   :   Incorrect password or username");
                 e.printStackTrace();
            } catch (NamingException ne) {
                  Result = false;
                  System.out.print("Exception" + ne.getStackTrace());
                  ne.printStackTrace();
            }
            System.out.print("Result   : " + Result);
      }

}

