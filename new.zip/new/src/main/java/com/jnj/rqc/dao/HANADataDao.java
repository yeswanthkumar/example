package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.HanaRoleUserPrivilegeMdl;
import com.jnj.rqc.conflictModel.HanaUserGrantModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;

public interface HANADataDao {
	public List<HanaUserGrantModel> getUserGrants(String templSysParam) throws SQLException, DataAccessException ;
	public List<HanaRoleUserPrivilegeMdl> getRolePrivilegeData(String templSysParam, String roleNames) throws SQLException, DataAccessException;
	public List<HanaRoleUserPrivilegeMdl> getUserDirectPrivilegeData(String templSysParam)  throws SQLException, DataAccessException;
	public List<SAPUserAccessModel> getUserTrfContrlData(String templSysParam) throws SQLException, DataAccessException;

}
