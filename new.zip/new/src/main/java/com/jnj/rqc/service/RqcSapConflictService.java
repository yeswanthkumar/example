package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;


public interface RqcSapConflictService {
	public List<MatrixModel> getCurConflictDetails(String empWwid, String[] data);
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data);
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data, String[] data2);

	public List<PersonalSysModel> getUserExistingRoles(String empWwid);
	//Multi User
	public Map<String, List<PersonalSysModel>> getMultiUserExistingRoles(List<String> empWwid);


	//END

	public String[] getRoleIdsPersonalSys(List<PersonalSysModel> psList);
	public List<MatrixModel> getUserLevelConflictingRoles(String empWwid, String[] data);
	public Map<String, List<String>> getSystemCodes(String data);
	public Map<String, List<String>> getSystemCodes(String[] data);

	public String writeConfCSVReport(String fileNm, List<MatrixModel> roleConflictList);
	public String writeSystemCodeCSVReport(String fileNm, List<SystemCodeModel> sysCdLst);
	public String writeConflictMatrixCSVReport(String fileNm, List<MatrixModel> matrixList);
	public String writeUserRoleCSVReport(String fileNm, List<PersonalSysModel> userRoles);
	//Multi User
	public String writeMultiUserRolePDFCSVReport(String type, String fileNm, Map<String, List<PersonalSysModel>> userRoles);
	public String writeMultiConfPDFCSVReport(String type, String fileNm, Map<String, List<MatrixModel>> userConflicts);

	public String writeUserRolePDFReport(String fileNm, List<PersonalSysModel> userRoles);
	public String writeConfPDFReport(String title, String fileNm, List<MatrixModel> roleConflictList);

	public Map<String, SystemCodeModel> getSystemCodes();

	public List<MatrixModel> getConflictMatrix();
}
