package com.jnj.rqc.constants;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthRespMdl {
	private Object claims ;
	private boolean passwordBased;
	private String moduleDisplay;
	private String sessionId;
	private String userName;
	private Object responseStatus;
}
