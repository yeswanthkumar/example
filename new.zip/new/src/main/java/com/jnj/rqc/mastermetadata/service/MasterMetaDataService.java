package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.MasterData;

public interface MasterMetaDataService {
	public void insertMultipleRecords(List<MasterData> records);
	public void deleteAllRows();
}
