package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.ConflictData;

public interface ConflictMatrixDataService {
	public void insertMultipleRecords(List<ConflictData> records);
	public void deleteAllRows();
}
