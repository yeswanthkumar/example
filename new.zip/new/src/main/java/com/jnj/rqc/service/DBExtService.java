package com.jnj.rqc.service;

import com.jnj.rqc.dbextr.models.TableRespDto;


public interface DBExtService {
	public TableRespDto getSchemaTables(String schemaNm);
	public String createExcelData(String tblName);




}
