package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDAPersonalSysMdl {
	private String 	userId;
	private String 	wwid;
	private String 	firstName;
	private String 	lastName;
	private String 	usrSts;
	private String 	role;
	private String 	srcSystem;
	private String 	sodCode;
	private String 	action;

	public String getData() {
		return  wwid + "~" + userId + "~" + firstName + "~" + lastName + "~" + sodCode + "~" +  role + "~" + usrSts+ "~" + srcSystem+"~"+action  ;
	}





	@Override
	public String toString() {
		return "PersonalSysModel [wwid=" + wwid + ", userId=" + userId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", usrSts=" + usrSts +", role=" + role + ", srcSystem=" + srcSystem +" ,action="+action+ "]";
	}

}
