package com.jnj.rqc.mastermetadata.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.mastermetadata.service.MasterDataInMemoryService;
import com.jnj.rqc.mastermetadata.service.UserAccessRequestReportService;

@RestController
@RequestMapping("/v2/api/useraccessrequestreport")
public class UserAccessRequestReportController {
	static final Logger log = LoggerFactory.getLogger(UserAccessRequestReportController.class);
	
	@Autowired
	private UserAccessRequestReportService userAccessRequestReportService;
	
	@Autowired
	private MasterDataInMemoryService masterDataInMemoryService;
	
	 @GetMapping("/getuseraccessrequestreport")
	    public ResponseEntity<UserAccessReqRepDTO> getUserAccessRequestReport() {
	        log.debug("enter into the method");
	        UserAccessReqRepDTO reportDTO = new UserAccessReqRepDTO();
	        try {
	            reportDTO = userAccessRequestReportService.getUserAccessRequestResults();
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
		
		@GetMapping("/getuseraccessrequestreport/byCriteria")
		public ResponseEntity<UserAccessReqRepDTO> getUserAccessRequestReportBycriteria(
				@RequestParam("criteria") String criteria, @RequestParam("value") String value) {
			log.debug("enter into the method");
			UserAccessReqRepDTO reportDTO = new UserAccessReqRepDTO();
			try {
				reportDTO = userAccessRequestReportService.getUserAccessRequestResults(criteria, value);
				if (reportDTO.getStatusCode() == 200) {
					return new ResponseEntity<>(reportDTO, HttpStatus.OK);
				} else if (reportDTO.getStatusCode() == 500) {
					return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
				} else {
					return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
				}
			} catch (Exception e) {
				log.error("Exception: " + e.getMessage());
				return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		 
	 
	 @GetMapping("/getexcessiveaccessreport")
	    public ResponseEntity<UserExcessiveReqRepDTO> getexcessiveaccessreport() {
	        log.debug("enter into the method");
	        UserExcessiveReqRepDTO reportDTO = new UserExcessiveReqRepDTO();
	        try {
	            reportDTO = userAccessRequestReportService.getUserExcessiveRequestResults();
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/getexcessiveaccessreport/byCriteria")
	    public ResponseEntity<UserExcessiveReqRepDTO> getexcessiveaccessreportBycriteria(
				@RequestParam("criteria") String criteria, @RequestParam("value") String value) {
	        log.debug("enter into the method");
	        UserExcessiveReqRepDTO reportDTO = new UserExcessiveReqRepDTO();
	        try {
	            reportDTO = userAccessRequestReportService.getUserExcessiveRequestResults(criteria, value);
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/getinappsodreport")
	    public ResponseEntity<InAppSODRepDTO> getInAppSODreport(@RequestParam("reqUserId") String reqUserId) {
	        log.debug("enter into the method");
	        InAppSODRepDTO reportDTO = new InAppSODRepDTO();
	        try {
	            userAccessRequestReportService.getInAppSODReportResults(reqUserId);
	            reportDTO.setStatusCode(200);
	            reportDTO.setMessage("Report has been scheduled in the background Successfully.  You will be notified once it is completed.");
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/getcrossappsodreport")
	    public ResponseEntity<CrossAppSODRepDTO> getCrossAppSODreport(@RequestParam("reqUserId") String reqUserId) {
	        log.debug("enter into the method");
	        CrossAppSODRepDTO reportDTO = new CrossAppSODRepDTO();
	        try {
	        	masterDataInMemoryService.loadMasterData();
	            userAccessRequestReportService.getCrossAppSODReportResults(reqUserId);
	            reportDTO.setStatusCode(200);
	            reportDTO.setMessage("Report has been scheduled in the background Successfully.  You will be notified once it is completed.");
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/getmultiuserreport")
	    public ResponseEntity<CrossAppSODRepDTO> getMultiUserReport(@RequestParam("reqUserId") String reqUserId) {
	        log.debug("enter into the method");
	        CrossAppSODRepDTO reportDTO = new CrossAppSODRepDTO();
	        try {
	        	masterDataInMemoryService.loadMasterData();
	            userAccessRequestReportService.getMultiUserReportResults(reqUserId);
	            reportDTO.setStatusCode(200);
	            reportDTO.setMessage("Report has been scheduled in the background Successfully.  You will be notified once it is completed.");
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/getthresholdreport")
	    public ResponseEntity<CrossAppSODRepDTO> getThresholdreport(@RequestParam("reqUserId") String reqUserId) {
	        log.debug("enter into the method");
	        CrossAppSODRepDTO reportDTO = new CrossAppSODRepDTO();
	        try {
	        	masterDataInMemoryService.loadMasterData();
	            userAccessRequestReportService.getThresholdReportResults(reqUserId);
	            reportDTO.setStatusCode(200);
	            reportDTO.setMessage("Report has been scheduled in the background Successfully.  You will be notified once it is completed.");
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 
}
