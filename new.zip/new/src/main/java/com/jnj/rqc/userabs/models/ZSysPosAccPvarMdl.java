package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZSysPosAccPvarMdl {
	String sysid;
	String posid;
	String posname;
	String accid;
	String posvarid;
	String posvarname;
	String posvardesc;
	String adid;
	String adname;


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZSysPosAccPvarMdl other = (ZSysPosAccPvarMdl) obj;
		if (accid == null) {
			if (other.accid != null)
				return false;
		} else if (!accid.equals(other.accid))
			return false;
		if (posid == null) {
			if (other.posid != null)
				return false;
		} else if (!posid.equals(other.posid))
			return false;
		if (posvardesc == null) {
			if (other.posvardesc != null)
				return false;
		} else if (!posvardesc.equals(other.posvardesc))
			return false;
		if (posvarid == null) {
			if (other.posvarid != null)
				return false;
		} else if (!posvarid.equals(other.posvarid))
			return false;
		if (posvarname == null) {
			if (other.posvarname != null)
				return false;
		} else if (!posvarname.equals(other.posvarname))
			return false;
		if (sysid == null) {
			if (other.sysid != null)
				return false;
		} else if (!sysid.equals(other.sysid))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accid == null) ? 0 : accid.hashCode());
		result = prime * result + ((posid == null) ? 0 : posid.hashCode());
		result = prime * result + ((posvardesc == null) ? 0 : posvardesc.hashCode());
		result = prime * result + ((posvarid == null) ? 0 : posvarid.hashCode());
		result = prime * result + ((posvarname == null) ? 0 : posvarname.hashCode());
		result = prime * result + ((sysid == null) ? 0 : sysid.hashCode());
		return result;
	}







}