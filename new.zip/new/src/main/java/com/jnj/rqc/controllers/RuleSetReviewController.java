package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.ruleset.models.RuleSetModel;
import com.jnj.rqc.ruleset.models.RuleSetSmryModel;
import com.jnj.rqc.service.RqcReportService;
import com.jnj.rqc.service.RuleSetReviewService;
import com.jnj.rqc.util.Utility;

@Controller
public class RuleSetReviewController {

	static final Logger log = LoggerFactory.getLogger(RuleSetReviewController.class);

	@Autowired
	private RuleSetReviewService ruleSetReviewService;

	@Autowired
	RqcReportService rqcReportService;

	@GetMapping("/loadRuleSetPage")
    public String loadReportForm(Model model) {
    	log.info("Routing to RQC Ticket Info page.");
    	List<KeyValPair> logParam = Utility.getLogParamList();
    	model.addAttribute("logParam",logParam);
    	return "ruleSet/ruleSetInfoPage";
    }




	@PostMapping("/genRuleSetFiles")
	public String genRuleSetDetails(@RequestParam("logParam") int logParam,  @RequestParam("reportDate") String reportDate, Model model, HttpServletRequest request) {
    	log.info(" RuleSet Params  logParam :"+logParam+"   reportDate:"+reportDate);
    	List<KeyValPair> logList = Utility.getLogParamList();
    	model.addAttribute("logParam",logList);
    	model.addAttribute("logVal",logParam);
    	model.addAttribute("repParam", reportDate);

    	if(logParam == 0 || StringUtils.isEmpty(reportDate)) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter "+((logParam==0)?" Save Log File ":" Report Date "));
            return "ruleSet/ruleSetInfoPage";
    	}
    	try{

    		Date repDt = Utility.fmtStrToDate(reportDate);
    		String strDate = Utility.fmtMDY(repDt);
    		List<RuleSetSmryModel> summaryList = ruleSetReviewService.getRuleSetSummary();
    		if(summaryList == null || summaryList.isEmpty()) {
    			model.addAttribute("message", "True");
        		model.addAttribute("error", "Status: Cannot get summary information for RuleSet ");
    		}else{
    			Map<String, List<RuleSetModel>> ruleSetDadaMap = ruleSetReviewService.getRuleSetData(summaryList);
    			Map<String, String> ruleSetFileMap = ruleSetReviewService.generateRuleSetFiles(ruleSetDadaMap, strDate, request);
    			ruleSetReviewService.updateFileLocation(summaryList, ruleSetFileMap);

    			HttpSession session = request.getSession();
    			session.setAttribute("SUMMARYDATA", summaryList);
    			model.addAttribute("SUMMARYDATA", summaryList);
    			session.setAttribute("ruleSetDadaMap", ruleSetDadaMap);
    			session.setAttribute("ruleSetFileMap", ruleSetFileMap);
    			model.addAttribute("message", "True");
        		log.debug("Total number of Records : "+((summaryList==null)?  "0":summaryList.size()));
        		String msg  = "Status: Total Source System Combinations : "+ ((summaryList == null || summaryList.isEmpty() ) ?  "0": summaryList.size()+"");
        		model.addAttribute("success", msg);
    		}
    	} catch (Exception e) {
            log.error("Error generating RuleSet Review files :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "ruleSet/ruleSetInfoPage";
    }


	@ResponseBody
    @GetMapping("/downloadsummary")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadsummary(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading RuleSet Summary ");
		String fileName = "SUMMARYData_"+Utility.fmtYMD(new Date())+".csv";
		List<RuleSetSmryModel> summaryModel = (List<RuleSetSmryModel>)request.getSession().getAttribute("SUMMARYDATA");
		String filePath = ruleSetReviewService.createSummaryCSV(summaryModel, fileName);

    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	@ResponseBody
    @GetMapping("/downloadRuleSetFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading RuleSet Files");
		String ruleSetFileDir =(String)request.getSession().getAttribute("RULESETDIR");
		//List<String> fileNames = ruleSetFileMap.values().stream().collect(Collectors.toList());

		String filePath = Utility.createZip(Arrays.asList(ruleSetFileDir), ruleSetFileDir+".zip");
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@ResponseBody
    @GetMapping("/downIndividualFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadIndividualExcel(@RequestParam String app1, @RequestParam String app2, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		//log.info("Downloading RuleSet Individual File: "+requestParams.get("app1")+"-"+requestParams.get("app2"));
		log.info("Downloading RuleSet Individual File: "+app1+"-"+app2);
		String ruleSetFileDir =(String)request.getSession().getAttribute("RULESETDIR");
		List<RuleSetSmryModel> summaryModel = (List<RuleSetSmryModel>)request.getSession().getAttribute("SUMMARYDATA");
		String filePath = "";
		for(RuleSetSmryModel mdl : summaryModel) {
			if(mdl.getApp1().equals(app1) && mdl.getApp2().equals(app2)) {
				filePath = mdl.getFileLoc();
				break;
			}
		}
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


}
