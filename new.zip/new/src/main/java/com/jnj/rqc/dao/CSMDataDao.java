package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.models.GrpUsrDateMdl;



public interface CSMDataDao {
	public int insertCSMArchiveData(List<CSMHistDataMdl> csmData) throws SQLException, DataAccessException;
	public int validateUserToAdGrpData(GrpUsrDateMdl userData, Date validDate) throws SQLException, DataAccessException;
	public int insertCSMModelData(List<CSMModelAdGrpMap> csmData) throws SQLException, DataAccessException;
	public int insertIAMDataForCMS(List<GrpUsrDateMdl> iamCsmData) throws SQLException, DataAccessException;
	public int compareExistingData(GrpUsrDateMdl userData) throws SQLException, DataAccessException;
	public List<GrpUsrDateMdl> getCSMIAMExportData() throws SQLException, DataAccessException;
	public int updateIAMDataForCMS() throws SQLException, DataAccessException;
	public int insertCSMCurrentData(List<GrpUsrDateMdl> csmData) throws SQLException, DataAccessException;


}
