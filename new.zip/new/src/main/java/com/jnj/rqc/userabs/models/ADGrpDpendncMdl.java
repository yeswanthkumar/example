package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ADGrpDpendncMdl {
	private String adid;
	private String adname;
}
