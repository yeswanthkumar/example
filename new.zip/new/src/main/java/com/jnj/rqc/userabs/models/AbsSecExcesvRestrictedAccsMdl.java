package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class AbsSecExcesvRestrictedAccsMdl implements Serializable {
	private static final long serialVersionUID = 7325776290150527238L;
	String userid;
	int    reqid;
	String secId;
	String secName;
	String sysid;
	String sysName;
	String isExcsv ;
	String isRestricted ;
	double excsvPrcntg;
	double limit;
	Date   createdon;
}