package com.jnj.rqc.userreq.service;

import java.util.List;

import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.AbsCancelRejectRequestModel;
import com.jnj.rqc.userabs.models.AbsComplianceRequest;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.AbsUserRequestRespDto;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ReqCountRespDto;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.ReqSrchConstDto;
import com.jnj.rqc.userabs.models.ReqSrchConstMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;

public interface AbsUserRequestService {

	/**
	 * Method  : AbsUserRequestService.java.getAllRequestData()
	 *		   :<b>@param startDate
	 *		   :<b>@param endDate
	 *		   :<b>@param userWwId
	 *		   :<b>@param status
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 21, 2023 11:43:24 AM
	 * Purpose : Query All request Data for a Date range
	 * @return : AbsUserRequestRespDto
	*/
	//public AbsUserRequestRespDto getAllRequestData(String startDate, String endDate, String userWwId, int status);


	/**
	 * Method  : AbsUserRequestService.java.getAllRequestData()
	 *		   :<b>@param startDate
	 *		   :<b>@param endDate
	 *		   :<b>@param paramType
	 *		   :<b>@param paramValue
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 5, 2023 4:06:39 PM
	 * Purpose : Query request for a Date Range and Parameter supplied.
	 * @return : AbsUserRequestRespDto
	*/
	public AbsUserRequestRespDto getAllRequestData(String startDate, String endDate, int paramType, String paramValue);

	/**
	 * Method  : AbsUserRequestService.java.saveAbsRequestData()
	 *		   :<b>@param reqModel
	 *		   :<b>@param curUser
	 *		   :<b>@param assocUser
	 *		   :<b>@param assocMgr
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 22, 2023 4:56:38 PM
	 * Purpose : Saving Request Submitted data to Database
	 * @return : int
	*/
	public int saveAbsRequestData(UserReqCompMdl reqModel, UserSearchModel curUser, UserSearchModel assocUser, UserSearchModel assocMgr)  throws Exception;

	/**
	 * Method  : AbsUserRequestService.java.searchPendingReqCount()
	 *		   :<b>@param userId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 7, 2023 3:03:15 PM
	 * Purpose :
	 * @return : ReqCountRespDto
	*/
	public ReqCountRespDto searchPendingReqCount(String userId);


	public ReqSrchConstDto getSearchConstants();
	public  List<ReqSrchConstMdl> getAllSrchConstants() throws Exception;

	/**
	 * Method  : AbsUserRequestService.java.getTktDependency()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 13, 2023 9:40:23 AM
	 * Purpose : Get all Dependent Data for Ticket
	 * @return : List<ReqDpendncMdl>
	*/
	public List<ReqDpendncMdl> getTktDependency(String reqId);


	/**
	 * Method  : AbsUserRequestService.java.getSysDependencies()
	 *		   :<b>@param sysid
	 *		   :<b>@param posnids
	 *		   :<b>@param accids
	 *		   :<b>@param posvarids
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 13, 2023 2:28:35 PM
	 * Purpose :
	 * @return : SysDpendncMdl
	*/
	//public SysDpendncMdl getSysDependencies(String sysid, String posnids, String accids, String posvarids);

	public List<RawSysDpendncMdl> getSysDependencies(String sysid, String posnids, String accids, String posvarids);


	/**
	 * Method  : AbsUserRequestService.java.getRequestDataByID()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 13, 2023 3:15:08 PM
	 * Purpose : Get Request Header Data by Req ID
	 * @return : List<AbsUserReqMdl>
	*/
	public AbsUserReqMdl getRequestDataByID(String reqId);

	/**
	 * Method  : AbsUserRequestService.java.getAllReqLvlConflicts()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 13, 2023 3:44:33 PM
	 * Purpose : Get All Conflicts for given Request ID
	 * @return : List<UserAbsConflictMdl>
	*/
	public List<UserAbsConflictMdl> getAllReqLvlConflicts(String reqId);

	/**
	 * Method  : AbsUserRequestService.java.getReqLvlExcData()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 14, 2023 10:37:14 AM
	 * Purpose : Method to get Excessive data for a request
	 * @return : List<AbsExcesvAccsMdl>
	*/
	public List<AbsExcesvAccsMdl> getReqLvlExcData(String reqId);

	/**
	 * Method  : AbsUserRequestService.java.getAllMitigatingControls()
	 *		   :<b>@param id
	 *		   :<b>@param type
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 17, 2023 2:59:21 PM
	 * Purpose : List all Mitigating Control Key/Value
	 * @return : List<KeyValPair>
	*/
	public List<StrKeyValPair> getAllMitigatingControls(String id, String type);

	/**
		 * Method  : AbsUserRequestService.java.saveComplApprovalData()
		 *		   :<b>@param approveUser
		 *		   :<b>@param absComlianceRequest
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 25, 2023 2:29:23 PM
		 * Purpose : Saving Compliance Approval Data
		 * @return : String
		 */
	public String saveComplApprovalData(UserSearchModel approveUser, AbsComplianceRequest absComlianceRequest);

	/**
		 * Method  : AbsUserRequestService.java.getReqLvlRestrExcsvData()
		 *		   :<b>@param reqId
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 25, 2023 11:31:30 AM
		 * Purpose : Get Restrictive/Accessive Data for the Ticket
		 * @return : List<AbsSysLeveExcsvRestrMdl>
		 */
	public List<AbsSysLeveExcsvRestrMdl> getReqLvlRestrExcsvData(String reqId);

	/**
		 * Method  : AbsUserRequestService.java.saveCancelRejectStatus()
		 *		   :<b>@param approveUser
		 *		   :<b>@param absComlianceRequest
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Jun 16, 2023 6:44:02 PM
		 * Purpose : Save Reject/Cancel Request Status
		 * @return : String
		 */
	public String saveCancelRejectStatus(UserSearchModel approveUser, AbsCancelRejectRequestModel absCancelRejectRequestModel);
	
	/**
	 * Method  : AbsUserRequestService.java.getDuplicateRecords()
	 *		   :<b>@param reqId
	 *		   :<b>@return</b>
	 * @author : rpandiya  @Created :Sep 09, 2023 9:44:33 PM
	 * Purpose : Get Duplicate records for given req id and user
	 * @return : List<UserAbsConflictMdl>
	*/
	public List<RoleADGrpMdl> getDuplicateRecords(String reqId, String userId);


}
