package com.jnj.rqc.models;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExcessiveAccessModel {
	UserSearchModel user;
	String userId;
	int reqId;
	String sysId;
	String sysName;
	double limit;
	String isExcessive="N";
	double exPercentage;
	String exVarIds;
	List<KeyValPair> exVariants;
	String selVarids;
	Date dtCreated;
	String resolved;
	String acceptDeny;
	String accVarids;
	String denVarids;
	int cntrlSel;
	String reslCmnts;
	String reslBy;
	Date dtResolved;
	List<KeyValPair> selVariants;
	List<KeyValDiffPair> userVars;
	List<KeyValPair> allAvailableVars;

}
