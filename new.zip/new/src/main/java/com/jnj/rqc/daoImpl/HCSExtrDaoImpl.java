package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.dao.HCSExtrDao;
import com.jnj.rqc.dbconfig.TemplateFactory;




@Service
public class HCSExtrDaoImpl  extends TemplateFactory implements HCSExtrDao {
	static final Logger log = LoggerFactory.getLogger(HCSExtrDaoImpl.class);


	@Override
	public List<SapGaaUser2RoleModel> getHCSUser2RoleData(String templSysParam) throws SQLException, DataAccessException{
		log.info("Template Name : "+templSysParam);
		List<SapGaaUser2RoleModel> usrData = new ArrayList<>();

		if("NA_HCS_Production_CCRA".equals(templSysParam)) {
			usrData =  getHCSCCRAUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_CORE".equals(templSysParam)) {
			usrData =  getHCSCOREUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_HCSOP50".equals(templSysParam)) {
			usrData =  getHCSHCSOP50User2RoleData(templSysParam);
		}else if("NA_HCS_Production_HCSOP53".equals(templSysParam)) {
			usrData =  getHCSHCSOP53User2RoleData(templSysParam);
		}else if("NA_HCS_Production_ICS".equals(templSysParam)) {
			usrData =  getHCSICSUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_MDM".equals(templSysParam)) {
			usrData =  getHCSMDMUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_WMSMLC".equals(templSysParam)) {
			usrData =  getHCSWMSMLCUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_WMSSDC".equals(templSysParam)) {
			usrData =  getHCSWMSSDCUser2RoleData(templSysParam);
		}
		/*Addind NON-SOX Systems*/
		else if("NA_HCS_Production_340BR2".equals(templSysParam)) {
			usrData =  getHCS340BR2User2RoleData(templSysParam);
		}else if("NA_HCS_Production_EMSNEXTGEN".equals(templSysParam)) {
			usrData =  getHCSEMSNEXTGENUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_FALCON".equals(templSysParam)) {
			usrData =  getHCSFALCONUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_FTCC".equals(templSysParam)) {
			usrData =  getHCSFTCCUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_FOM".equals(templSysParam)) {
			usrData =  getHCSFOMUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_GPS".equals(templSysParam)) {
			usrData =  getHCSGPSUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_TM".equals(templSysParam)) {
			usrData =  getHCSTMUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_RMSJAPAN".equals(templSysParam)) {
			usrData =  getHCSRMSJAPANUser2RoleData(templSysParam);
		}else if("NA_HCS_Production_PVCS".equals(templSysParam)) {
			usrData =  getHCSPVCSUser2RoleData(templSysParam);
		}


		/*BRAVO SYSTEMS*/
		else if("NA_BRAVO_Development_BRAVO".equals(templSysParam)) {
			usrData =  getBravoDevUser2RoleData(templSysParam);
		}else if("NA_BRAVO_Quality_BRAVO".equals(templSysParam)) {
			usrData =  getBravoQaUser2RoleData(templSysParam);
		}else if("NA_BRAVO_Production_BRAVO".equals(templSysParam)) {
			usrData =  getBravoProdUser2RoleData(templSysParam);
		}


		log.info("Total User Records returned for ("+templSysParam+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}

	private List<SapGaaUser2RoleModel> getBravoProdUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " Select DISTINCT OWNER_WWID AS USER_ID, RESP_KEY AS ROLE_ID, NAME as ROLE_DESC " +
					 " FROM BRVO.BRVO_COG_RESP " +
					 " WHERE UPPER(NAME) NOT LIKE UPPER('Company 00%') AND UPPER(NAME) NOT LIKE UPPER('System 00%') " +
					 " AND END_DATE IS NULL ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateNA_BRAVO_Production_BRAVO().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("BRAVO PROD Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getBravoQaUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " Select DISTINCT OWNER_WWID AS USER_ID, RESP_KEY AS ROLE_ID, NAME as ROLE_DESC " +
					 " FROM BRVO.BRVO_COG_RESP " +
					 " WHERE UPPER(NAME) NOT LIKE UPPER('Company 00%') AND UPPER(NAME) NOT LIKE UPPER('System 00%') " +
					 " AND END_DATE IS NULL ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateNA_BRAVO_Quality_BRAVO().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("BRAVO QA Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getBravoDevUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " Select DISTINCT OWNER_WWID AS USER_ID, RESP_KEY AS ROLE_ID, NAME as ROLE_DESC " +
					 " FROM BRVO.BRVO_COG_RESP " +
					 " WHERE UPPER(NAME) NOT LIKE UPPER('Company 00%') AND UPPER(NAME) NOT LIKE UPPER('System 00%') " +
					 " AND END_DATE IS NULL ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateNA_BRAVO_Development_BRAVO().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("BRAVO DEV Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}


	private List<SapGaaUser2RoleModel> getHCSPVCSUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USERNAME AS USER_ID, ROLENAME AS ROLE_ID FROM SOD_EXTR.PVCS_EXTR  ORDER BY USER_ID  ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("PVCS Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSRMSJAPANUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE AS ROLE_ID FROM SOD_EXTR.RMSJAPAN_EXTR ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("RMSJAPAN Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSTMUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE AS ROLE_ID FROM SOD_EXTR.TM_EXTR ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("TM Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSGPSUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE_NAME AS ROLE_ID FROM SOD_EXTR.GPS_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("GPS Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
	private List<SapGaaUser2RoleModel> getHCSFOMUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE AS ROLE_ID FROM SOD_EXTR.FOM_EXTR   ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("FOM Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
	private List<SapGaaUser2RoleModel> getHCSFTCCUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, SECUTY_TYP_CD AS ROLE_ID FROM SOD_EXTR.FTCC_EXTR_MV  ORDER BY USER_ID  ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("FTCC Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
	private List<SapGaaUser2RoleModel> getHCSFALCONUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_NAME AS USER_ID, ROLE_DESC AS ROLE_ID FROM SOD_EXTR.FALCON_EXTR_MV ORDER BY USER_ID  ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("FALCON Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSEMSNEXTGENUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_NAME AS USER_ID, GROUP_NAME AS ROLE_ID FROM SOD_EXTR.ENG_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("EMSNEXTGEN Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
	private List<SapGaaUser2RoleModel> getHCS340BR2User2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_NAME AS USER_ID, ROLE_DESC AS ROLE_ID FROM SOD_EXTR.JJ340B_EXTR_MV  ORDER BY USER_ID  ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("340BR2 Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}


	private List<SapGaaUser2RoleModel> getHCSWMSSDCUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT EMP AS USER_ID, MENU_ID AS ROLE_ID FROM SOD_EXTR.WMSSDC_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("WMSSDC Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}


	private List<SapGaaUser2RoleModel> getHCSWMSMLCUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT EMP AS USER_ID, MENU_ID AS ROLE_ID FROM SOD_EXTR.WMS_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("WMSMLC Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSMDMUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_NAME AS USER_ID, GROUP_NAME as ROLE_ID, DESCRIPTION as ROLE_DESC FROM SOD_EXTR.MDM_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("MDM Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSICSUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE AS ROLE_ID FROM SOD_EXTR.ICS_EXTR_MV " +
					 " WHERE UPPER(USERNAME) NOT LIKE 'DEL-%' ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("ICS Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSHCSOP53User2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT GRANTEE AS USER_ID, GRANTED_ROLE AS ROLE_ID FROM SOD_EXTR.DBROLE_EXTR_MV " +
					 " WHERE SID ='HCSOP53' ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("HCSOP53 Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSHCSOP50User2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT GRANTEE AS USER_ID, GRANTED_ROLE AS ROLE_ID FROM SOD_EXTR.DBROLE_EXTR_MV " +
					 " WHERE SID ='HCSOP50' ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("HCSOP50 Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
	private List<SapGaaUser2RoleModel> getHCSCOREUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USERNAME AS USER_ID, ROLENAME AS ROLE_ID FROM SOD_EXTR.CORE_EXTR_MV  ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("CORE Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}

	private List<SapGaaUser2RoleModel> getHCSCCRAUser2RoleData(String templSysParam) {
		List<SapGaaUser2RoleModel> dataList = new ArrayList<>();
		String qry = " SELECT DISTINCT USER_ID, ROLE_NM as ROLE_ID from SOD_EXTR.CCRA_EXTR_MV ORDER BY USER_ID ";
		dataList  = getJdbcTemplate().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(SapGaaUser2RoleModel.class));
		log.info("CCRA Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}



}
