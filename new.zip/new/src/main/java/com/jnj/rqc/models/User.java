package com.jnj.rqc.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {
	private String wwid;  //uid
	private String ntId;
	private String firstName;  //givenName
	private String lasttName;  //sn
	private String fullName;  //cn
	private String email;  //mail;  //jnjmsusername
	private String departmentDesc;  //jnjDepartmentDescription
	private String department;  //jnjDepartmentDescription
	private String tel;   //TELEPHONENUMBER
	private String businessUnit;   //jnjBusinessUnit
	private boolean valid;
	private Integer isActive;
	private String password;
	private String mgrId;
	private String mgrNm;
	private String cubeno;
	@Override
	public String toString() {
		return "User [wwid=" + wwid + ", ntId=" + ntId + ", firstName=" + firstName + ", lasttName=" + lasttName
				+ ", fullName=" + fullName + ", email=" + email + ", department=" + department + ", tel=" + tel
				+ ", businessUnit=" + businessUnit + ", valid=" + valid + ", isActive=" + isActive + "]";
	}




}
