package com.jnj.rqc.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.CRUnitADGroupMdl;
import com.jnj.rqc.models.ExcessiveAccessModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.PlatformProjectMdl;
import com.jnj.rqc.models.ProjectApprCatgMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.TktApprLogMdl;
import com.jnj.rqc.models.UETktModel;
import com.jnj.rqc.models.UserRequestDispMdl;
import com.jnj.rqc.models.UserRequestModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.useridentity.models.BusinessFunctionModel;
import com.jnj.rqc.useridentity.models.BusinessProcessModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.UIReqDpendncMdl;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.useridentity.models.UIRequestModel;
import com.jnj.rqc.useridentity.models.UserIdentityConflictMdl;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;
import com.jnj.rqc.util.Utility;




@Service
public class UserIdentityDaoImpl  extends BaseDao implements UserIdentityDao {
	static final Logger log = LoggerFactory.getLogger(UserIdentityDaoImpl.class);

	@Override
	public List<UserRoleADGrpMdl> getUserRoles(String userId, int type) throws SQLException, DataAccessException {
		List<UserRoleADGrpMdl> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT REQ_ID, USER_ID, SYSTEM_ID, POSITION, ADGROUP, REQ_BY, REQ_DATE, UPD_DATE ");
		if(2==type) {
			sql.append(" FROM SOD_DB_USER.USER_REQUESTED_ROLES ");
		}else{
			sql.append(" FROM SOD_DB_USER.USER_GRANTED_ROLES ");
		}
		sql.append(" WHERE USER_ID = ? ");
		sql.append(" ORDER BY USER_ID, SYSTEM_ID ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {userId}, new BeanPropertyRowMapper<>(UserRoleADGrpMdl.class));
		log.info("Roles size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getRequestTypes() throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT ID AS KEY, NAME AS VAL FROM SOD_DB_USER.REQ_TYPE "+
					" WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Request Type size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getProjectsKeyVal() throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT ID AS KEY, NAME AS VAL FROM SOD_DB_USER.PLATFORM_PROJECT "+
					" WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Request Type size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<BusinessFunctionModel> getBusinessFunctionVals(String bfId)throws SQLException, DataAccessException{
		List<BusinessFunctionModel> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT BF_ID, BF_NAME, BF_DESCRIPTION, IS_ACTIVE FROM SOD_DB_USER.BUSINESS_FUNCTION ");
		sql.append(" WHERE IS_ACTIVE='Y' ");
		if(!Utility.isEmpty(bfId)) {
			sql.append(" AND BF_ID = '"+bfId+"' ");
		}
		sql.append(" ORDER BY 1, 2 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(BusinessFunctionModel.class));
		log.info("Business Function size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<BusinessProcessModel> getBusinessProcessVals(String bfId)throws SQLException, DataAccessException{
		List<BusinessProcessModel> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();

		if(Utility.isEmpty(bfId)) {
			sql.append(" SELECT BP_ID, BP_NAME, BP_DESCRIPTION, IS_ACTIVE ");
			sql.append(" FROM SOD_DB_USER.BUSINESS_PROCESS ");
			sql.append(" ORDER BY 1, 2 ");
			dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(BusinessProcessModel.class));
		}else{
			sql.append(" SELECT b.BP_ID, b.BP_NAME, b.BP_DESCRIPTION, b.IS_ACTIVE ");
			sql.append(" FROM SOD_DB_USER.BUSSFUNC_PROCESS_MAP a, SOD_DB_USER.BUSINESS_PROCESS b ");
			sql.append(" WHERE a.BP_ID = b.BP_ID ");
			String[] bfArr = bfId.split(",");
			Object[] inParam = new Object[bfArr.length];
			if(bfArr.length == 1) {
				sql.append(" AND a.BF_ID = ? ");
				inParam[0]=bfArr[0];
			}else if(bfArr.length > 1){
				sql.append(" AND a.BF_ID in ( ");
				String qmrk="";
				for(int i=0; i<bfArr.length; i++) {
					inParam[i] = bfArr[i];
					if(qmrk.equals("")) {
						qmrk = " ? ";
					}else {
						qmrk +=", ? ";
					}
				}
				sql.append(qmrk+" )");
			}
			sql.append(" ORDER BY 1, 2 ");
			dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(BusinessProcessModel.class));
		}
		log.info("Business Process List size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getCntryAcctFuncKV(String cntId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.ACCF_ID as KEY, b.ACCF_NAME as VAL " +
					" FROM SOD_DB_USER.CNTRY_ACCF_MAP a, SOD_DB_USER.ACCOUNTABLE_FUNCTIONS b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.ACCF_ID = b.ACCF_ID ";
					if(cntId != null && cntId.length() > 0) {
						sql+= " AND a.CNTRY_ID = '"+cntId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Country Accountable functions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getReqStatusKeyVal() throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT STAT_ID AS KEY, STAT_NAME AS VAL FROM SOD_DB_USER.REQUEST_STATUS "+
					" WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Request Type size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<PlatformProjectMdl> getProjectsData(String prjId) throws SQLException, DataAccessException {
		List<PlatformProjectMdl> dataLst = new LinkedList<>();
		String sql= " SELECT ID, NAME, DESCRIPTION, RENDER_NEXT, IS_ACTIVE FROM SOD_DB_USER.PLATFORM_PROJECT "+
					" WHERE IS_ACTIVE='Y' ";
			if(!prjId.equals("0")) {
				sql+=" AND ID = "+ prjId;
			}
			sql+= " ORDER BY ID, NAME ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(PlatformProjectMdl.class));
		log.info("Projects Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getProjectSectors(String prjPlatformId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.SEC_ID as KEY, b.SEC_NAME as VAL " +
					" FROM SOD_DB_USER.PROJECT_SECTORS_MAP a, SOD_DB_USER.SECTORS b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.PRJ_ID = '"+prjPlatformId+"' AND a.SEC_ID = b.SEC_ID " +
					" ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Porject Sectors size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getAcctFuncKeyVal(String[] accfIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		Object[] inParam = new Object[accfIds.length];
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT ACCF_ID as KEY, ACCF_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.ACCOUNTABLE_FUNCTIONS ");
		sql.append("  WHERE IS_ACTIVE='Y' ");
		if(accfIds.length == 1) {
			sql.append(" AND ACCF_ID = ? ");
			inParam[0]=accfIds[0];
		}else if(accfIds.length > 1){
			sql.append(" AND ACCF_ID in ( ");
			String qmrk="";
			for(int i=0; i<accfIds.length; i++) {
				inParam[i] = accfIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Account functions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getPersonasKeyVal(String[] persIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[persIds.length];
		sql.append(" SELECT PER_ID as KEY, PER_NAME as VAL FROM USER_PERSONA WHERE IS_ACTIVE='Y' ");
		if(persIds.length == 1) {
			sql.append(" AND PER_ID = ? ");
			inParam[0]=persIds[0];
		}else if(persIds.length > 1){
			sql.append(" AND PER_ID in ( ");
			String qmrk="";
			for(int i=0; i<persIds.length; i++) {
				inParam[i]=persIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Personas size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getPositionsKeyVal(String[] posIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[posIds.length];
		sql.append(" SELECT POS_ID as KEY, POS_NAME as VAL FROM USER_POSITIONS WHERE IS_ACTIVE='Y' ");
		if(posIds.length == 1) {
			sql.append(" AND POS_ID = ? ");
			inParam[0]=posIds[0];
		}else if(posIds.length > 1){
			sql.append(" AND POS_ID in ( ");
			String qmrk="";
			for(int i=0; i<posIds.length; i++) {
				inParam[i]=posIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Positions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getRolesKeyVal(String[] roleIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[roleIds.length];
		sql.append(" SELECT RL_ID as KEY, RL_NAME as VAL FROM APPL_ROLES WHERE IS_ACTIVE='Y' ");
		if(roleIds.length == 1) {
			sql.append(" AND RL_ID = ? ");
			inParam[0]=roleIds[0];
		}else if(roleIds.length > 1){
			sql.append(" AND RL_ID in ( ");
			String qmrk="";
			for(int i=0; i<roleIds.length; i++) {
				inParam[i]=roleIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Roles size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getBussFuncSectorsKV(String bfId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT b.SEC_ID as KEY, b.SEC_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.BUSSFUNC_SECTOR_MAP a, SOD_DB_USER.SECTORS b ");
		sql.append(" where a.SEC_ID = b.SEC_ID AND a.BF_ID = ? ");
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {bfId}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned Sectors size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getProjSystemsKV(String prjId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT b.S_ID as KEY, b.S_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.PROJECT_SYSTEM_MAP a, SOD_DB_USER.SYSTEM_PLATFORM b ");
		sql.append(" where a.S_ID = b.S_ID AND a.PRJ_ID = ? ");
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {prjId}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned SYSTEMS size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getRegnSystemsKV(String regId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT b.S_ID as KEY, b.S_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.REGION_SYSTEM_MAP a, SOD_DB_USER.SYSTEM_PLATFORM b ");
		sql.append(" where a.S_ID = b.S_ID AND a.REG_ID = ? ");
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {regId}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned SYSTEMS size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<KeyValPair> getSysPositionsKeyVal(String sysIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT b.POS_ID as KEY, b.POS_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.SYSTEM_POSITION_MAP a, SOD_DB_USER.USER_POSITIONS b ");
		sql.append(" where a.POS_ID = b.POS_ID AND a.S_ID = ? ");
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {sysIds}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned POSITIONS size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getPosAccessTypesKV(String posId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		Object[] parmArr = null;
		sql.append(" SELECT ACS_ID as KEY, ACS_NAME as VAL FROM SOD_DB_USER.ACCESS_SELECTION ");
		if(!Utility.isEmpty(posId)) {
			sql.append(" WHERE POS_ID = ? ");
			parmArr = new Object[] {posId};
		}else {
			parmArr = new Object[] {};
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), parmArr, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned Access Types size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<KeyValPair> getAcsPosnVariantKV(String acsId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		Object[] parmArr = null;
		sql.append(" SELECT PVAR_ID as KEY, PVAR_NAME as VAL FROM SOD_DB_USER.POSITION_VARIANT ");
		if(!Utility.isEmpty(acsId)) {
			sql.append(" WHERE ACS_ID = ? ");
			parmArr = new Object[] {acsId};
		}else {
			parmArr = new Object[] {};
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), parmArr, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("returned Posn Variants size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getSectorsKeyVal(String[] secIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		if(secIds != null && secIds.length > 0) {
			Object[] inParam = new Object[secIds.length];
			sql.append(" SELECT SEC_ID as KEY, SEC_NAME as VAL FROM SOD_DB_USER.SECTORS WHERE IS_ACTIVE='Y' ");
			if(secIds.length == 1) {
				sql.append(" AND SEC_ID = ? ");
				inParam[0]=secIds[0];
			}else if(secIds.length > 1){
				sql.append(" AND SEC_ID in ( ");
				String qmrk="";
				for(int i=0; i<secIds.length; i++) {
					inParam[i]=secIds[i];
					if(qmrk.equals("")) {
						qmrk = " ? ";
					}else {
						qmrk +=", ? ";
					}
				}
				sql.append(qmrk+" )");
			}
			sql.append(" ORDER BY KEY, VAL ");
			dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		}else {
			sql.append(" SELECT SEC_ID as KEY, SEC_NAME as VAL FROM SOD_DB_USER.SECTORS WHERE IS_ACTIVE='Y' ");
			sql.append(" ORDER BY KEY, VAL ");
			dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		}

		log.info("Sectors size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getRegionsKeyVal(String[] regIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[regIds.length];
		sql.append(" SELECT REG_ID AS KEY, REG_NAME AS VAL FROM SOD_DB_USER.REGIONS ");
		sql.append(" WHERE IS_ACTIVE='Y' ") ;
		if(regIds.length == 1) {
			sql.append(" AND REG_ID = ? ");
			inParam[0]=regIds[0];
		}else if(regIds.length > 1){
			sql.append(" AND REG_ID in ( ");
			String qmrk="";
			for(int i=0; i<regIds.length; i++) {
				inParam[i]=regIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Regions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getCntrysKeyVal(String[] cntryIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[cntryIds.length];
		sql.append(" SELECT CNTRY_ID as KEY, CNTRY_NAME as VAL ");
		sql.append(" FROM SOD_DB_USER.COUNTRIES WHERE IS_ACTIVE='Y' ");
		if(cntryIds.length == 1) {
			sql.append(" AND CNTRY_ID = ? ");
			inParam[0]=cntryIds[0];
		}else if(cntryIds.length > 1){
			sql.append(" AND CNTRY_ID in ( ");
			String qmrk="";
			for(int i=0; i<cntryIds.length; i++) {
				inParam[i]=cntryIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Countries size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getConsUnitsKeyVal(String[] consIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[consIds.length];
		sql.append(" SELECT CU_CODE as KEY, CU_NAME as VAL FROM SOD_DB_USER.CONS_UNIT WHERE IS_ACTIVE='Y'  ");
		if(consIds.length == 1) {
			sql.append(" AND CU_CODE = ? ");
			inParam[0]=consIds[0];
		}else if(consIds.length > 1){
			sql.append(" AND CU_CODE in ( ");
			String qmrk="";
			for(int i=0; i<consIds.length; i++) {
				inParam[i]=consIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Consolidation Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<StrKeyValPair> getRespUnitsKeyVal(String[] respIds) throws SQLException, DataAccessException {
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[respIds.length];
		sql.append(" SELECT RU_CODE as KEY, RU_NAME as VAL FROM SOD_DB_USER.RESP_UNIT WHERE IS_ACTIVE='Y'  ");
		if(respIds.length == 1) {
			sql.append(" AND RU_CODE = ? ");
			inParam[0]=respIds[0];
		}else if(respIds.length > 1){
			sql.append(" AND RU_CODE in ( ");
			String qmrk="";
			for(int i=0; i<respIds.length; i++) {
				inParam[i]=respIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Responsiblity Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getPerRolesKV(String perId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.RL_ID as KEY, b.RL_NAME as VAL " +
					" FROM SOD_DB_USER.PERSONA_ROLES_MAP a, SOD_DB_USER.APPL_ROLES b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.RL_ID = b.RL_ID ";
					if(perId != null && perId.length() > 0) {
						sql+= " AND a.PER_ID = '"+perId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Person to Role Map.size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getPosRolesKV(String perId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.RL_ID as KEY, b.RL_NAME as VAL " +
					" FROM SOD_DB_USER.POSITION_ROLES_MAP a, SOD_DB_USER.APPL_ROLES b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.RL_ID = b.RL_ID ";
					if(perId != null && perId.length() > 0) {
						sql+= " AND a.POS_ID = '"+perId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Positions to Role Map.size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getSecAcctFuncKV(String secId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.ACCF_ID as KEY, b.ACCF_NAME as VAL " +
					" FROM SOD_DB_USER.SECTOR_ACCF_MAP a, SOD_DB_USER.ACCOUNTABLE_FUNCTIONS b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.ACCF_ID = b.ACCF_ID ";
					if(secId != null && secId.length() > 0) {
						sql+= " AND a.SEC_ID = '"+secId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Sector Account functions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getCountriesKeyVal(String regionId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT CNTRY_ID as KEY, CNTRY_NAME as VAL " +
					" FROM SOD_DB_USER.COUNTRIES WHERE IS_ACTIVE='Y' ";
					if(regionId != null && regionId.length() > 0) {
						sql+= " AND REG_ID = '"+regionId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Countries size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getfuncRegKV(String funcId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.REG_ID as KEY, b.REG_NAME as VAL " +
					" FROM  SOD_DB_USER.ACCFUNC_REGION_MAP a, SOD_DB_USER.REGIONS b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.REG_ID = b.REG_ID ";
					if(funcId != null && funcId.length() > 0) {
						sql+= " AND a.ACCF_ID = '"+funcId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Regions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getSectorRegionKV(String secId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT  b.REG_ID as KEY, b.REG_NAME as VAL " +
					" FROM  SOD_DB_USER.SECTOR_REGION_MAP a, SOD_DB_USER.REGIONS b " +
					" WHERE a.IS_ACTIVE='Y' AND b.IS_ACTIVE='Y' AND a.REG_ID = b.REG_ID " ;
					if(secId != null && secId.length() > 0) {
						sql+= " AND a.SEC_ID = '"+secId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Regions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public int saveUserRequest(UserRequestModel reqModel) throws SQLException, DataAccessException {
		log.info("Saving User Request for : "+reqModel.getUserId());
		int requestId = 0;
		String seqSql= " SELECT user_req_seq.nextval from dual";
		String reqSql = " INSERT INTO USER_REQUEST "+
				" (REQ_ID, REQ_TYP, REQ_DT, REQ_BY, USER_ID, MGR_WWID, PRJ_ID, PERSONA_IDS, POSITION_IDS, ROLE_IDS, SEC_IDS, ACCF_IDS, REG_IDS, CNTRY_IDS, "
				+ " CONS_IDS, RESP_IDS, REQ_STATUS, DT_UPDATED, UPDT_BY, COMMENTS) " +
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";

		int reqId = getJdbcTemplateSRADUtils().queryForObject(seqSql, Integer.class);
		if(reqId > 0) {
			int insResult = getJdbcTemplateSRADUtils().update(reqSql, new Object[] {reqId, reqModel.getReqTyp(), reqModel.getReqDt(), reqModel.getReqBy(),
					reqModel.getUserId(), reqModel.getMgrWwid(), reqModel.getPrjId(), reqModel.getPersonaIds(), reqModel.getPositionIds(), reqModel.getRoleIds(),
					reqModel.getSecIds(), reqModel.getAccfIds(), reqModel.getRegIds(), reqModel.getCntryIds(), reqModel.getConsIds(), reqModel.getRespIds(),
					reqModel.getReqStatus(), reqModel.getDtUpdated(), reqModel.getUpdtBy(), reqModel.getComments()});
			if(insResult > 0) {
				requestId = reqId;
			}else {
				log.error("Cannot Save User Request");
			}
		}
		log.info("Saved Request Data with ID ::"+requestId);
		return requestId;
	}


	@Override
	public int updateRequestStatus(String requestId, int status, int apprSeq) throws SQLException, DataAccessException {
			log.info("Update Request Status  REQID: "+requestId +" Status: "+status);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.USER_REQUEST SET ");
			if(status > 0) {
				sql.append(" REQ_STATUS = "+status);
				if(apprSeq > 0) {
					sql.append(", APPR_SEQ = "+apprSeq +" ");
				}
			}else {
				sql.append(" APPR_SEQ = "+apprSeq+" ");
			}
			sql.append(" WHERE REQ_ID = '"+ requestId+"' " );
			return  getJdbcTemplateSRADUtils().update(sql.toString());
	}

	@Override
	public int updateIamRequestStatus(String requestId, int status) throws SQLException, DataAccessException {
			log.info("Update Request Status  REQID: "+requestId +" Status: "+status);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.USER_REQUEST SET REQ_STATUS = ?  WHERE REQ_ID = ? " );
			return  getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {status, requestId });
	}

	@Override
	public List<KeyValPair> getProjectPersonas(String prjId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.PER_ID as KEY, b.PER_NAME as VAL " +
					" FROM SOD_DB_USER.PROJECT_PERSONA a, SOD_DB_USER.USER_PERSONA b " +
					" WHERE a.IS_ACTIVE='Y' AND a.PROJ_ID = '"+prjId+"' AND a.PER_ID = b.PER_ID " +
					" ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Porject Personas size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getProjectPositions(String prjId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.POS_ID as KEY, b.POS_NAME as VAL " +
					" FROM SOD_DB_USER.PROJECT_POSITION a, SOD_DB_USER.USER_POSITIONS b " +
					" WHERE a.IS_ACTIVE='Y' AND a.PROJ_ID = '"+prjId+"' AND a.POS_ID = b.POS_ID " +
					" ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Porject Personas size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}




	@Override
	public List<StrKeyValPair> getAccfRespUnitKeyVal(String cntryIds, String accfIds)throws SQLException, DataAccessException{
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT RU_CODE as key, RU_NAME as val FROM SOD_DB_USER.RESP_UNIT WHERE IS_ACTIVE='Y' ");
		String[] cntArr = cntryIds.split(",");
		if(cntArr.length == 1) {
			sql.append(" AND CNTRY_ID = "+ cntArr[0]);
		}else if(cntArr.length > 1) {
				String ids="";
				sql.append(" AND CNTRY_ID IN ( ");
				for (String element : cntArr) {
					if(ids.length()<= 0) {
						ids+= " "+ element;
					}else {
						ids+= ", "+ element;
					}
				}
				sql.append(" "+ids+" ) ");
		}
		String[] accfArr = accfIds.split(",");
		if(accfArr.length == 1) {
			sql.append(" AND ACCF_ID = "+accfArr[0]);
		}else if(accfArr.length > 1) {
			String ids="";
			sql.append(" AND ACCF_ID IN ( ");
			for (String element : accfArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Responsiblity Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<StrKeyValPair> getAccfConsUnitKeyVal(String cntryIds, String accfIds)throws SQLException, DataAccessException{
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT CU_CODE as key, CU_NAME as val FROM SOD_DB_USER.CONS_UNIT WHERE IS_ACTIVE='Y' ");
		String[] cntArr = cntryIds.split(",");
		if(cntArr.length == 1) {
			sql.append(" AND CNTRY_ID = "+ cntArr[0]);
		}else if(cntArr.length > 1) {
			String ids="";
			sql.append(" AND CNTRY_ID IN ( ");
			for (String element : cntArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		String[] accfArr = accfIds.split(",");
		if(accfArr.length == 1) {
			sql.append(" AND ACCF_ID = "+accfArr[0]);
		}else if(accfArr.length > 1) {
			String ids="";
			sql.append(" AND ACCF_ID IN ( ");
			for (String element : accfArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Consolidation Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<CRUnitADGroupMdl> getADGrpsforConsRespUnit(String cnsRspIds, String typ)throws SQLException, DataAccessException{
		List<CRUnitADGroupMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		String msg="";
		sql.append(" SELECT CR_CODE, ADGROUP, POSITION, TYPE FROM SOD_DB_USER.CRUNIT_ADGROUP_MAP WHERE IS_ACTIVE='Y' ");
		if("C".equals(typ)) {
			sql.append("AND TYPE= 'C' ");
			msg = "Consolidation Unit";
		}else {
			sql.append("AND TYPE= 'R' ");
			msg ="Responsiblity Unit";
		}
		String[] cnsRArr = cnsRspIds.split(",");
		if(cnsRArr.length == 1) {
			sql.append(" AND CR_CODE = '"+ cnsRArr[0]+"'");
		}else if(cnsRArr.length > 1) {
			String ids="";
			sql.append(" AND CR_CODE IN ( ");
			for (String element : cnsRArr) {
				if(ids.length()<= 0) {
					ids+= " '"+ element+"'";
				}else {
					ids+= ", '"+ element+"'";
				}
			}
			sql.append(" "+ids+" ) ");
		}
		sql.append(" ORDER BY POSITION, ADGROUP ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(CRUnitADGroupMdl.class));
		log.info(msg+" size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}




	///////////////////////////////////////////////////////////////////



	@Override
	public List<StrKeyValPair> getRespUnitKeyVal(String cntryIds, String secIds)throws SQLException, DataAccessException{
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT RU_CODE as key, RU_NAME as val FROM SOD_DB_USER.RESP_UNIT WHERE IS_ACTIVE='Y' ");
		String[] cntArr = cntryIds.split(",");
		if(cntArr.length == 1) {
			sql.append(" AND CNTRY_ID = "+ cntArr[0]);
		}else if(cntArr.length > 1) {
				String ids="";
				sql.append(" AND CNTRY_ID IN ( ");
				for (String element : cntArr) {
					if(ids.length()<= 0) {
						ids+= " "+ element;
					}else {
						ids+= ", "+ element;
					}
				}
				sql.append(" "+ids+" ) ");
		}
		String[] secArr = secIds.split(",");
		if(secArr.length == 1) {
			sql.append(" AND SEC_ID = "+secArr[0]);
		}else if(secArr.length > 1) {
			String ids="";
			sql.append(" AND SEC_ID IN ( ");
			for (String element : secArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Responsiblity Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<StrKeyValPair> getConsUnitKeyVal(String cntryIds, String secIds)throws SQLException, DataAccessException{
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT CU_CODE as key, CU_NAME as val FROM SOD_DB_USER.CONS_UNIT WHERE IS_ACTIVE='Y' ");
		String[] cntArr = cntryIds.split(",");
		if(cntArr.length == 1) {
			sql.append(" AND CNTRY_ID = "+ cntArr[0]);
		}else if(cntArr.length > 1) {
			String ids="";
			sql.append(" AND CNTRY_ID IN ( ");
			for (String element : cntArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		String[] secArr = secIds.split(",");
		if(secArr.length == 1) {
			sql.append(" AND SEC_ID = "+secArr[0]);
		}else if(secArr.length > 1) {
			String ids="";
			sql.append(" AND SEC_ID IN ( ");
			for (String element : secArr) {
				if(ids.length()<= 0) {
					ids+= " "+ element;
				}else {
					ids+= ", "+ element;
				}
			}
			sql.append(" "+ids+" ) ");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Consolidation Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getSectorKeyVal(String cntId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.SEC_ID as KEY, b.SEC_NAME as VAL " +
					" FROM SOD_DB_USER.COUNTRY_SECTORS a, SOD_DB_USER.SECTORS b "+
					"  WHERE a.IS_ACTIVE='Y' AND a.SEC_ID = b.SEC_ID ";
					if(cntId != null && cntId.length() > 0) {
						sql+= " AND a.CNTRY_ID = '"+cntId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Sectors size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getConsUnitKeyVal(String secId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.CU_ID as KEY, b.CU_NAME as VAL " +
					" FROM SOD_DB_USER.SECTOR_CONS_UNIT a, SOD_DB_USER.CONSOLIDATION_UNIT b "+
					"  WHERE a.IS_ACTIVE='Y' AND a.CU_ID = b.CU_ID ";
					if(secId != null && secId.length() > 0) {
						sql+= " AND a.SEC_ID = '"+secId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Cons Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getResponsiblityUnitKeyVal(String consId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT b.RU_ID as KEY, b.RU_NAME as VAL " +
					" FROM SOD_DB_USER.CONSUNIT_RESPUNIT a, SOD_DB_USER.RESPONSIBLITY_UNIT b "+
					"  WHERE a.IS_ACTIVE='Y' AND a.RU_ID = b.RU_ID ";
					if(consId != null && consId.length() > 0) {
						sql+= " AND a.CU_ID = '"+consId+"' ";
					}
					sql+= " ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Cons Unit size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UserRequestDispMdl> getUserSubmittedReqs(String startDate, String endDate, int projects, int status,  String userWwId) throws SQLException, DataAccessException {
		List<UserRequestDispMdl> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.PRJ_ID, c.NAME as prjName, a.PERSONA_IDS, a.POSITION_IDS, a.ROLE_IDS, a.SEC_IDS, a.ACCF_IDS, "+
					" a.REG_IDS, a.CNTRY_IDS, a.CONS_IDS, a.RESP_IDS, a.REQ_STATUS, d.STAT_NAME as reqStatusDesc,  a.DT_UPDATED, a.UPDT_BY, a.CONFLICT_FOUND, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.PLATFORM_PROJECT c, SOD_DB_USER.REQUEST_STATUS d  "+
					" WHERE a.REQ_TYP = b.ID  AND a.PRJ_ID = c.ID AND a.REQ_STATUS = d.STAT_ID "+
					" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') ";
		if(projects > 0) {
			sql += " AND a.PRJ_ID = '"+projects+"' ";
		}
		if(status > 0) {
			sql += " AND a.REQ_STATUS = '"+status+"' ";
		}

		if(userWwId != null && userWwId.length() > 0) {
			sql += " AND a.USER_ID = '"+userWwId+"' ";
		}
		sql += " ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UserRequestDispMdl.class));
		log.info("User Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}




	@Override
	public List<UserRequestDispMdl> getMyReqData(String startDate, String endDate, String userWwId)throws SQLException, DataAccessException {
		List<UserRequestDispMdl> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.PRJ_ID, c.NAME as prjName, a.PERSONA_IDS, a.POSITION_IDS, a.ROLE_IDS, a.SEC_IDS, a.ACCF_IDS, "+
					" a.REG_IDS, a.CNTRY_IDS, a.CONS_IDS, a.RESP_IDS, a.REQ_STATUS, d.STAT_NAME as reqStatusDesc,  a.DT_UPDATED, a.UPDT_BY, a.CONFLICT_FOUND, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.PLATFORM_PROJECT c, SOD_DB_USER.REQUEST_STATUS d  "+
					" WHERE a.REQ_TYP = b.ID  AND a.PRJ_ID = c.ID AND a.REQ_STATUS = d.STAT_ID "+
					" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') ";
		if(userWwId != null && userWwId.length() > 0) {
			sql += " AND a.USER_ID = '"+userWwId+"' ";
		}
		sql += " ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ";

		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UserRequestDispMdl.class));
		log.info("My Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<UETktModel> getUserTktData(String tktNum) throws SQLException, DataAccessException {
		List<UETktModel> dataLst = new ArrayList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.PRJ_ID, c.NAME as prjName, a.PERSONA_IDS, a.POSITION_IDS, a.ROLE_IDS, a.SEC_IDS, a.ACCF_IDS, "+
					" a.REG_IDS, a.CNTRY_IDS, a.CONS_IDS, a.RESP_IDS, a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.DT_UPDATED, a.UPDT_BY, a.CONFLICT_FOUND, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.PLATFORM_PROJECT c, SOD_DB_USER.REQUEST_STATUS d  "+
					" WHERE a.REQ_TYP = b.ID AND a.PRJ_ID = c.ID AND a.REQ_STATUS = d.STAT_ID AND a.REQ_ID = ? ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {tktNum}, new BeanPropertyRowMapper<>(UETktModel.class));
		log.info("Porject Personas size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UserRequestDispMdl> getMgrApprQueData(String startDate, String endDate, int projects, /*int status,*/	String mgrId) throws SQLException, DataAccessException {
		List<UserRequestDispMdl> dataLst = new LinkedList<>();
		String sql=	" SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.PRJ_ID, c.NAME as prjName, a.PERSONA_IDS, a.POSITION_IDS, a.ROLE_IDS, a.SEC_IDS, a.ACCF_IDS, "+
					" a.REG_IDS, a.CNTRY_IDS, a.CONS_IDS, a.RESP_IDS, a.REQ_STATUS, d.STAT_NAME as reqStatusDesc,  a.DT_UPDATED, a.UPDT_BY, a.CONFLICT_FOUND, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.PLATFORM_PROJECT c, SOD_DB_USER.REQUEST_STATUS d  "+
					" WHERE a.REQ_TYP = b.ID  AND a.PRJ_ID = c.ID AND a.REQ_STATUS = d.STAT_ID  AND a.REQ_STATUS = '1' "+
					" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss')  AND a.MGR_WWID = '"+mgrId+"'  ";
		if(projects > 0) {
			sql += " AND a.PRJ_ID = '"+projects+"' ";
		}
		sql += " ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UserRequestDispMdl.class));
		log.info("MGR APPR QUE("+mgrId+") Data size : "+((dataLst !=null)? dataLst.size(): 0));

		List<UserRequestDispMdl> l2dataLst = getMgrApprQueWithConflictsData(startDate, endDate, mgrId);
		if(l2dataLst != null && !l2dataLst.isEmpty()) {
			dataLst.addAll(l2dataLst);
		}

		return dataLst;
	}

	@Override
	public List<UserRequestDispMdl> getMgrApprQueWithConflictsData(String startDate, String endDate, String mgrId) throws SQLException, DataAccessException {
		List<UserRequestDispMdl> dataLst = new LinkedList<>();
		//Step 1- Get all projects that need L2 Approval in case of Conflicts
		String preSql = " SELECT PROJ_ID FROM SOD_DB_USER.PROJECT_APPR_CATG " +
						" Where SEQ_ID = 2 AND APPROVER_ID= ? ";
		List<String> prjLst = getJdbcTemplateSRADUtils().queryForList(preSql, new Object[] {mgrId}, String.class);
		//Step 2- Get all projects for queried project ID's
		if(prjLst != null && !prjLst.isEmpty()) {
			StringBuilder sql=	new StringBuilder(" SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.PRJ_ID, ");
			sql.append(" c.NAME as prjName, a.PERSONA_IDS, a.POSITION_IDS, a.ROLE_IDS, a.SEC_IDS, a.ACCF_IDS, a.REG_IDS, a.CNTRY_IDS, a.CONS_IDS, ");
			sql.append(" a.RESP_IDS, a.REQ_STATUS, d.STAT_NAME as reqStatusDesc,  a.DT_UPDATED, a.UPDT_BY, a.CONFLICT_FOUND, a.COMMENTS ");
			sql.append(" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.PLATFORM_PROJECT c, SOD_DB_USER.REQUEST_STATUS d  ");
			sql.append(" WHERE a.REQ_TYP = b.ID  AND a.PRJ_ID = c.ID AND a.REQ_STATUS = d.STAT_ID  AND a.CONFLICT_FOUND = 'Y' AND a.REQ_STATUS = '2' ");
			sql.append(" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') ");
			if(prjLst.size() == 1) {
				sql.append( " AND a.PRJ_ID = '"+prjLst.get(0)+"' ");
			}else {
				String ids="";
				sql.append(" AND a.PRJ_ID IN ( ");
				for (String element : prjLst) {
					if(ids.length()<= 0) {
						ids+= " "+ element;
					}else {
						ids+= ", "+ element;
					}
				}
				sql.append(" "+ids+" ) ");
			}
			sql.append(" ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ");
			dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UserRequestDispMdl.class));
		}
		log.info("L2 Appr MGR APPR QUE("+mgrId+") Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<ProjectApprCatgMdl> getProjectApprCategory(String projects, int seqId, int implId) throws SQLException, DataAccessException {
		List<ProjectApprCatgMdl> dataLst = new ArrayList<>();
		Object[] inParams=null;
		String sql= " SELECT  PROJ_ID, SEQ_ID, PROJ_CATG_DESC, APPROVER_ID, EMAIL, OWNER_APPR_REQD, UPDATED_DT FROM SOD_DB_USER.PROJECT_APPR_CATG "+
					" WHERE PROJ_ID ";
		if(implId >0) {
			sql+=" IN ( ?, ? ) AND SEQ_ID IN ( ?,  ?) ";
			inParams = new Object[] {projects, implId, seqId, 999} ;
		}else {
			sql+=" = ? AND SEQ_ID = ? ";
			inParams = new Object[] {projects, seqId} ;
		}
		sql+=" ORDER BY PROJ_ID, SEQ_ID ";

		dataLst = getJdbcTemplateSRADUtils().query(sql, inParams, new BeanPropertyRowMapper<>(ProjectApprCatgMdl.class));
		log.info("Project Approval Catg Email Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public int updateApprovalLog(TktApprLogMdl appLogData) throws SQLException, DataAccessException {
		int logId=0;
		log.info("Saving Approval Data for REQID: "+appLogData.getReqId());
		String seqSql= " SELECT SOD_DB_USER.TKT_APPRLOG_SEQ.nextval from dual";
		String qry = " INSERT INTO SOD_DB_USER.TKT_APPROVAL_LOG ( "+
						" APPR_LOG_ID, REQ_ID, APPROVER_ID, REQ_STATUS, APPROVAL_CATG, APPROVAL_STATUS, APPRD_CONS_UNITS, DENID_CONS_UNITS, APPRD_RESP_UNITS, "+
						" DENID_RESP_UNITS, APPR_REMARKS, UPD_DATE ) " +
						" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";

		int lgSeq = getJdbcTemplateSRADUtils().queryForObject(seqSql, Integer.class);
		if(lgSeq > 0) {
			int insResult = getJdbcTemplateSRADUtils().update(qry, new Object[] {lgSeq, appLogData.getReqId(), appLogData.getApproverId(), appLogData.getReqStatus(),
					appLogData.getApprovalCatg(), appLogData.getApprovalStatus(), appLogData.getApprdConsUnits(), appLogData.getDenidConsUnits(),
					appLogData.getApprdRespUnits(), appLogData.getDenidRespUnits(), appLogData.getApprRemarks(), new Date()});
			if(insResult > 0) {
				logId = lgSeq;
			}else {
				log.error("Cannot Save Approval Log");
			}
		}
		log.info("Saved Approval Data with ID ::"+logId);
		return logId;
	}



	@Override
	public List<TktApprLogMdl> getApprovalLogData(String reqId) throws SQLException, DataAccessException {
		List<TktApprLogMdl> apprLogData = new ArrayList<>();
		String sql= " Select APPR_LOG_ID, REQ_ID, APPROVER_ID, REQ_STATUS, APPROVAL_CATG, APPROVAL_STATUS, APPRD_CONS_UNITS, APPRD_RESP_UNITS, APPR_REMARKS, UPD_DATE " +
					" from  SOD_DB_USER.TKT_APPROVAL_LOG  WHERE REQ_ID= ?  ORDER BY APPR_LOG_ID DESC  ";
		apprLogData = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(TktApprLogMdl.class));
		log.info("Project Approval Catg Email Data size : "+((apprLogData !=null)? apprLogData.size(): 0));
		return apprLogData;
	}


/******MASTER DATA METHODS********************/


	@Override
	public List<KeyValPair> getMSectorRegionKV(String bfId, String[] secIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select DISTINCT REG_ID AS KEY, REG_NAME AS VAL from  SOD_DB_USER.MASTER_DATA " );
		sql.append(" WHERE BF_ID = ? ");

		Object[] inParam = new Object[(secIds.length+1)];
		inParam[0] = bfId;
		if(secIds.length == 1) {
			sql.append(" AND SEC_ID = ? ");
			inParam[1] = secIds[0];
		}else
		if(secIds.length > 1){
			sql.append(" AND SEC_ID  in ( ");
			String qmrk="";
			for(int i=0; i<secIds.length; i++) {
				inParam[(i+1)] = secIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY,VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Regions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}




	@Override
	public List<KeyValPair> getMRegionSystemsKV(String bfId, String[] secIds, String[] regIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT SYS_ID AS KEY, SYS_NAME AS VAL FROM  SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		//AND REG_ID=2
		int prmPos=0;
		Object[] inParam = new Object[(secIds.length+regIds.length+1)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" ORDER BY KEY,VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Regions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getMSystemPositionsKV(String bfId, String[] secIds, String[] regIds, String sysId) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT POS_ID AS KEY, POS_NAME AS VAL FROM  SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);

		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		sql.append(" ORDER BY KEY,VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Positions size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getMPosnsAccsTypKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds)throws SQLException, DataAccessException{
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT ACS_ID AS KEY, ACS_NAME AS VAL FROM SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1+posIds.length)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		sql.append(" ORDER BY KEY,VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Access Type size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getMAcsTypPosVarnKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsTypIds)throws SQLException, DataAccessException{
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT PV_ID AS KEY, PV_NAME AS VAL FROM SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1+posIds.length+acsTypIds.length)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		prmPos = buildQuery(prmPos, "ACS_ID", acsTypIds, inParam, sql);
		sql.append(" ORDER BY KEY,VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("POS Varnts size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UserRoleADGrpMdl> getMPosVarnADGrpKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsTypIds, String[] posVarIds)throws SQLException, DataAccessException{
		List<UserRoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT SYS_ID, SYS_NAME, PV_ID, PV_NAME, AD_ID as adgrpId, AD_NAME as adgrpName FROM SOD_DB_USER.MASTER_DATA ");
		//sql.append(" SELECT DISTINCT AD_ID as key, AD_NAME as val FROM SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1+posIds.length+acsTypIds.length+posVarIds.length)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		prmPos = buildQuery(prmPos, "ACS_ID", acsTypIds, inParam, sql);
		prmPos = buildQuery(prmPos, "PV_ID", posVarIds, inParam, sql);
		//sql.append(" ORDER BY key, val ");
		sql.append(" ORDER BY 1, 3, 5 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(UserRoleADGrpMdl.class));
		log.info("ADGRP's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	/**
	 * Method  : UserIdentityDaoImpl.java.buildQuery()
	 *		   :<b>@param counter
	 *		   :<b>@param varName
	 *		   :<b>@param recdArr
	 *		   :<b>@param inparams
	 *		   :<b>@param sql
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 2, 2022 9:38:01 AM
	 * Purpose : Method designed to build query and parameter array for JDBC template
	 * @return : int
	 */
	@Override
	public int buildQuery(int counter, String varName, String[] recdArr, Object [] inparams, StringBuilder sql ) {
		String qmrk="";
		if(recdArr.length == 1) {
			sql.append(" AND "+varName+" = ? ");
			inparams[counter] = recdArr[0];
			counter++;
		}else if(recdArr.length > 1){
			sql.append(" AND "+varName+"  in ( ");
			for (String element : recdArr) {
				inparams[counter] = element;
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
				counter++;
			}
			sql.append(qmrk+" )");
		}
		return counter;
	}

	@Override
	public List<UserRoleADGrpMdl> getMstDataForADGrp(String ldapADGroup) throws SQLException, DataAccessException{
		List<UserRoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select Distinct SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, AD_ID as adgrpId, AD_NAME as adgrpName ");
		sql.append(" from SOD_DB_USER.MASTER_DATA ");
		sql.append(" Where upper(AD_NAME) = UPPER('"+ldapADGroup.trim()+"') ");
		sql.append(" ORDER BY SYS_ID, SYS_NAME ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(UserRoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UserRoleADGrpMdl> getCFINMstDataForRole(String techRle) throws SQLException, DataAccessException{
		List<UserRoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select '1' as sysId, 'CFIN' as sysName, POS_ID, POS_NAME, PV_ID, PV_NAME, ROLE_ID as adgrpId, ROLE_ID as adgrpName ");
		sql.append(" FROM SOD_DB_USER.CFIN_ROLE2POSITION ");
		sql.append(" WHERE UPPER(ROLE_ID) = UPPER('"+techRle+"') ");
		sql.append(" ORDER BY 1, 2 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(UserRoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UserRoleADGrpMdl> getAnaplanMstDataForRole(String techRle) throws SQLException, DataAccessException{
		List<UserRoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select Distinct SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, AD_ID as adgrpId, AD_NAME as adgrpName ");
		sql.append(" from SOD_DB_USER.MASTER_DATA ");
		sql.append(" Where upper(AD_NAME) = UPPER('"+techRle.trim()+"') AND SYS_ID = '4' ");
		sql.append(" ORDER BY SYS_ID, SYS_NAME ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(UserRoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<String> getAnaplanHistDataForUser(String userId) throws SQLException, DataAccessException{
		List<String> dataLst = new LinkedList<>();
		String sql= " Select DISTINCT ADGROUP from SOD_DB_USER.CSMDATA_HIST WHERE WWID = ?  ";
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql, new Object[]{userId}, String.class);
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	/*@Override
	public List<String> getAnaplanIamDataForUser(String userId) throws SQLException, DataAccessException{
		List<String> dataLst = new LinkedList<String>();
		String sql= " Select DISTINCT ADGROUP from SOD_DB_USER.CSMDATA_HIST WHERE WWID = ?  ";
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql, new Object[]{userId}, String.class);
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}*/


	@Override
	public List<UserIdentityConflictMdl> getConflictsforPositions(String query)	throws SQLException, DataAccessException {
		List<UserIdentityConflictMdl> dataLst = getJdbcTemplateSRADUtils().query(query, new Object[]{}, new BeanPropertyRowMapper<>(UserIdentityConflictMdl.class));
		log.info("Conflict Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public int saveUIUserRequest(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst) throws SQLException, DataAccessException {
		log.info("Saving User Request for : "+reqModel.getUserId());
		int requestId = 0;
		String seqSql= " SELECT user_req_seq.nextval from dual";
		String reqSql = " INSERT INTO USER_REQUEST "+
				" (REQ_ID, REQ_TYP, REQ_DT, REQ_BY, USER_ID, MGR_WWID, BF_ID, SEC_IDS, REG_IDS, REQ_STATUS, CONFL_FOUND, DT_UPDATED, UPDT_BY, COMMENTS, IS_EXCES) " +
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? ) ";

		int reqId = getJdbcTemplateSRADUtils().queryForObject(seqSql, Integer.class);
		if(reqId > 0) {
			int insResult = getJdbcTemplateSRADUtils().update(reqSql, new Object[] {reqId, reqModel.getReqTyp(), reqModel.getReqDt(), reqModel.getReqBy(),
					reqModel.getUserId(), reqModel.getMgrWwid(), reqModel.getBfId(), reqModel.getSecIds(), reqModel.getRegIds(), reqModel.getReqStatus(),
					reqModel.getConflFound(), reqModel.getDtUpdated(), reqModel.getUpdtBy(), reqModel.getComments(), reqModel.getIsExces() });
			if(insResult > 0) {
				requestId = reqId;
				String detSql = " INSERT INTO SOD_DB_USER.REQUEST_DETAILS (REQ_ID, SYS_ID, POS_IDS, ACS_IDS, PV_IDS, AD_IDS, DT_CREATED ) VALUES (?, ?, ?, ?, ?, ?, ?) ";
				int[] status = getJdbcTemplateSRADUtils().batchUpdate(detSql,
			            new BatchPreparedStatementSetter() {
							@Override
							public void setValues(PreparedStatement ps, int i) throws SQLException {
								ps.setInt(1, reqId);
								ps.setString(2, dispModelLst.get(i).getSysId());
								ps.setString(3, dispModelLst.get(i).getPosIds());
								ps.setString(4, dispModelLst.get(i).getAscTypIds());
								ps.setString(5, dispModelLst.get(i).getPosVarIds());
								ps.setString(6, dispModelLst.get(i).getAdGrpIds());
								ps.setDate(7, new java.sql.Date(new Date().getTime()));
							}

							@Override
							public int getBatchSize() {
								return dispModelLst.size();
							}
						});
			}else {
				log.error("Cannot Save User Request");
			}
		}
		log.info("Saved Request Data with ID ::"+requestId);
		return requestId;
	}

	@Override
	public int saveUIUserConflicts(int requestId, UserSearchModel assocUser, List<UserIdentityConflictMdl> confList) throws SQLException, DataAccessException {
		log.info("Saving Conflicts for Request for : "+requestId);

		String detSql = " INSERT INTO USERREQUEST_CONFLICT "+
				" (USER_ID, REQ_ID, RISK_ID, RISK_DESC, APP1, APP_NAME1, APP2, APP_NAME2, POSV1, POSV_NAME1, POSV2, POSV_NAME2, CONFLICT, MITIGATING_CONTROL, DT_CREATED) "+
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(detSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, confList.get(i).getRiskId());
				ps.setString(4, confList.get(i).getRiskDesc());
				ps.setString(5, confList.get(i).getApp1());
				ps.setString(6, confList.get(i).getAppName1());
				ps.setString(7, confList.get(i).getApp2());
				ps.setString(8, confList.get(i).getAppName2());
				ps.setString(9, confList.get(i).getPosv1());
				ps.setString(10, confList.get(i).getPosvName1());
				ps.setString(11, confList.get(i).getPosv2());
				ps.setString(12, confList.get(i).getPosvName2());
				ps.setString(13, confList.get(i).getConflict());
				ps.setString(14, confList.get(i).getMitigatingControl());
				ps.setDate(15, new java.sql.Date(new Date().getTime()));
			}

			@Override
			public int getBatchSize() {
				return confList.size();
			}
		});
		log.info("Saved Conflicts Data for RequestID ::"+requestId+" Total Conflicts:"+rowsUpdated.length);
		return rowsUpdated.length;
	}

	//
	@Override
	public int saveUIExAccess(int requestId, UserSearchModel assocUser, List<ExcessiveAccessModel> exList) throws SQLException, DataAccessException {
		log.info("Saving Excessive Access info for Request for : "+requestId);

		String detSql = " INSERT INTO USERREQUEST_EX_ACCESS "+
				" (USER_ID, REQ_ID, SYS_ID, SYS_NAME, LIMIT, IS_EXCESSIVE, EX_PERCENTAGE, EX_VARIDS, SEL_VARIDS, DT_CREATED) "+
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(detSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, exList.get(i).getSysId());
				ps.setString(4, exList.get(i).getSysName());
				ps.setDouble(5, exList.get(i).getLimit());
				ps.setString(6, exList.get(i).getIsExcessive());
				ps.setDouble(7, exList.get(i).getExPercentage());
				ps.setString(8, exList.get(i).getExVarIds());
				ps.setString(9, exList.get(i).getSelVarids());
				ps.setDate(10, new java.sql.Date(new Date().getTime()));
			}

			@Override
			public int getBatchSize() {
				return exList.size();
			}
		});
		log.info("Saved Excessive Data for RequestID ::"+requestId+" Total Excessive data: "+rowsUpdated.length);
		return rowsUpdated.length;
	}


	@Override
	public List<UIRequestDispModel> getNewUserSubmittedReqs(String startDate, String endDate, String userWwId, int status)throws SQLException, DataAccessException {
		List<UIRequestDispModel> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.BF_ID, a.SEC_IDS, a.REG_IDS, "+
					" a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.CONFL_FOUND, a.DT_UPDATED, UPDT_BY, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.REQUEST_STATUS d "+
					" WHERE a.REQ_TYP = b.ID  AND a.REQ_STATUS = d.STAT_ID "+
 					" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') ";
		if(status > 0) {
			sql += " AND a.REQ_STATUS = '"+status+"' ";
		}
		if(userWwId != null && userWwId.length() > 0) {
			sql += " AND a.USER_ID = '"+userWwId+"' ";
		}
		sql += " ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UIRequestDispModel.class));
		log.info("User Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UIRequestDispModel> getNewUserApprovalReqs(String startDate, String endDate, String userWwId)throws SQLException, DataAccessException{
		List<UIRequestDispModel> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.BF_ID, a.SEC_IDS, a.REG_IDS, "+
					" a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.CONFL_FOUND, a.IS_EXCES, a.DT_UPDATED, UPDT_BY, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.REQUEST_STATUS d "+
					" WHERE a.REQ_TYP = b.ID  AND a.REQ_STATUS = d.STAT_ID "+
 					" AND a.REQ_DT between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') "+
					" AND a.REQ_STATUS IN (1,2) ";

		if(userWwId != null && userWwId.length() > 0) {
			sql += " AND a.USER_ID = '"+userWwId+"' ";
		}
		sql += " ORDER BY a.REQ_DT DESC, a.REQ_ID DESC ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(UIRequestDispModel.class));
		log.info("User Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<UIRequestDispModel> getUserSavedTktData(String tktNum) throws SQLException, DataAccessException {
		List<UIRequestDispModel> dataLst = new ArrayList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.BF_ID, a.SEC_IDS, a.REG_IDS,  "+
					" a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.CONFL_FOUND, a.IS_EXCES, a.DT_UPDATED, UPDT_BY, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.REQUEST_STATUS d  "+
					" WHERE a.REQ_TYP = b.ID  AND a.REQ_STATUS = d.STAT_ID  AND a.REQ_ID = ? ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {tktNum}, new BeanPropertyRowMapper<>(UIRequestDispModel.class));
		log.info("Ticket Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<UIReqDpendncMdl> getRequestDependencies(String reqId) throws SQLException, DataAccessException {
		List<UIReqDpendncMdl> dataLst = new ArrayList<>();
		String sql= " SELECT REQ_ID, SYS_ID, POS_IDS, ACS_IDS, PV_IDS, AD_IDS "+
					" FROM SOD_DB_USER.REQUEST_DETAILS "+
					" WHERE REQ_ID= ? ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(UIReqDpendncMdl.class));
		log.info("Dependencies size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<IAMRequestedRoleModel> getGRCIAMReqSubmDependencies(String reqId) throws SQLException, DataAccessException {
		List<IAMRequestedRoleModel> dataLst = new ArrayList<>();
		String sql= " Select REQ_ID, SEQ_ID, USER_ID, SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, ADGRP_ID, ADGRP_NAME, REQ_BY, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS " +
					" FROM  SOD_DB_USER.USER_REQUESTED_ROLES WHERE REQ_ID = ? AND SUBM_STATUS = 'N' AND (API_STATUS IS NULL or API_STATUS = 'P' ) " +
					" ORDER BY REQ_ID, SYS_ID, SEQ_ID " ;
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(IAMRequestedRoleModel.class));
		log.info("Submitted Request size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<UserIdentityConflictMdl> getRequestConflicts(String reqId) {
		List<UserIdentityConflictMdl> confLst = new ArrayList<>();
		String sql= " SELECT USER_ID, REQ_ID, RISK_ID, RISK_DESC, APP1, APP_NAME1, APP2, APP_NAME2, POSV1, POSV_NAME1, POSV2, POSV_NAME2, CONFLICT, MITIGATING_CONTROL, RESOL_STATUS, ACCEPT_DENY, NVL( MITI_CNTRL_SEL, 0 ) MITI_CNTRL_SEL, RESL_CMNTS, RESL_BY, DT_RESOLVED "+
					" FROM SOD_DB_USER.USERREQUEST_CONFLICT "+
					" WHERE REQ_ID= ? ";
		confLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(UserIdentityConflictMdl.class));
		log.info("Request Conflicts size : "+((confLst !=null)? confLst.size(): 0));
		return confLst;
	}

	@Override
	public List<ExcessiveAccessModel> getRequestExcData(String reqId) {
		List<ExcessiveAccessModel> excLst = new ArrayList<>();
		String sql= " SELECT USER_ID, REQ_ID, SYS_ID, SYS_NAME, LIMIT, IS_EXCESSIVE, EX_PERCENTAGE, SEL_VARIDS, DT_CREATED "+
					" FROM USERREQUEST_EX_ACCESS WHERE REQ_ID= ? ";
		excLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(ExcessiveAccessModel.class));
		log.info("Request Excessive Data size : "+((excLst !=null)? excLst.size(): 0));
		return excLst;
	}




	@Override
	public List<UserIdentityConflictMdl> getUserConflicts(String userId) {
		List<UserIdentityConflictMdl> confLst = new ArrayList<>();
		String sql= " SELECT USER_ID, REQ_ID, RISK_ID, RISK_DESC, APP1, APP_NAME1, APP2, APP_NAME2, POSV1, POSV_NAME1, POSV2, POSV_NAME2, CONFLICT, MITIGATING_CONTROL, RESOL_STATUS, ACCEPT_DENY, NVL( MITI_CNTRL_SEL, 0 ) MITI_CNTRL_SEL, RESL_CMNTS, RESL_BY, DT_RESOLVED "+
					" FROM SOD_DB_USER.USERREQUEST_CONFLICT "+
					" WHERE USER_ID = ? ";
		confLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {userId}, new BeanPropertyRowMapper<>(UserIdentityConflictMdl.class));
		log.info("User Conflicts size : "+((confLst !=null)? confLst.size(): 0));
		return confLst;
	}

	@Override
	public List<KeyValPair> getMitiControls(String id, String type) {
		List<KeyValPair> dataLst = new LinkedList<>();
		String sql= " SELECT MI_ID AS KEY, MI_CNTRL AS VAL FROM SOD_DB_USER.MITIGATING_CONTROLS "+
					" WHERE IS_ACTIVE='Y' AND TYPE= '"+type+"' ";
		if(!Utility.isEmpty(id)) {
			sql+=" AND MI_ID= '"+id+"' ";
		}
		sql+="ORDER BY KEY, VAL ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Mitigating Control size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public int updReqSodApprStatus(String requestId, int status, String resolved) throws SQLException, DataAccessException {
			log.info("Update Request Conflict approval Status  REQID: "+requestId +" Status: "+status);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.USER_REQUEST ");
			sql.append(" SET REQ_STATUS = ?,  CONFL_RESOLVED = ?, DT_RESOLVED= ? ");
			sql.append(" WHERE REQ_ID = ? ");
			int rowsUpdated = getJdbcTemplateSRADUtils().update(sql.toString(), new Object[]{status, resolved, new Date(), requestId});
			return rowsUpdated;
	}

	@Override
	public int saveTktConflictApproval(List<UserIdentityConflictMdl> resMdlLst) throws SQLException, DataAccessException {
		String detSql = " UPDATE SOD_DB_USER.USERREQUEST_CONFLICT "+
						" SET RESOL_STATUS = ?, ACCEPT_DENY = ?, MITI_CNTRL_SEL = ?, RESL_CMNTS = ?, RESL_BY = ?, DT_RESOLVED = ? "+
						" WHERE REQ_ID = ? AND RISK_ID = ? ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(detSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, resMdlLst.get(i).getResolStatus());
				ps.setString(2, resMdlLst.get(i).getAcceptDeny());
				ps.setInt(3, resMdlLst.get(i).getMitiCntrlSel());
				ps.setString(4, resMdlLst.get(i).getReslCmnts());
				ps.setString(5, resMdlLst.get(i).getReslBy());
				ps.setDate(6, new java.sql.Date(resMdlLst.get(i).getDtResolved().getTime()));
				ps.setString(7, resMdlLst.get(i).getReqId());
				ps.setString(8, resMdlLst.get(i).getRiskId());
			}

			@Override
			public int getBatchSize() {
				return resMdlLst.size();
			}
		});
		log.info("Saved Conflicts App Status for RequestID ::"+resMdlLst.get(0).getReqId()+" Total Conflicts updated:"+rowsUpdated.length);
		return rowsUpdated.length;
	}


	@Override
	public int saveTktExcesApproval(List<ExcessiveAccessModel> resMdlLst) throws SQLException, DataAccessException {
		String detSql = " UPDATE SOD_DB_USER.USERREQUEST_EX_ACCESS "+
						" SET RESOLVED = ?, ACCEPT_DENY = ?, CNTRL_SEL = ?, RESL_CMNTS = ?, RESL_BY = ?, DT_RESOLVED = ? "+
						" WHERE REQ_ID = ? AND SYS_ID = ? ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(detSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, resMdlLst.get(i).getResolved());
				ps.setString(2, resMdlLst.get(i).getAcceptDeny());
				ps.setInt(3, resMdlLst.get(i).getCntrlSel());
				ps.setString(4, resMdlLst.get(i).getReslCmnts());
				ps.setString(5, resMdlLst.get(i).getReslBy());
				ps.setDate(6, new java.sql.Date(resMdlLst.get(i).getDtResolved().getTime()));
				ps.setInt(7, resMdlLst.get(i).getReqId());
				ps.setString(8, resMdlLst.get(i).getSysId());
			}

			@Override
			public int getBatchSize() {
				return resMdlLst.size();
			}
		});
		log.info("Saved Excessive Access Status for RequestID ::"+resMdlLst.get(0).getReqId()+" Total Conflicts updated:"+rowsUpdated.length);
		return rowsUpdated.length;
	}



	@Override
	public List<UIRequestDispModel> getAllApprovedUserReqs()throws SQLException, DataAccessException {
		List<UIRequestDispModel> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.BF_ID, a.SEC_IDS, a.REG_IDS, "+
					" a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.CONFL_FOUND, a.DT_UPDATED, UPDT_BY, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.REQUEST_STATUS d "+
					" WHERE a.REQ_TYP = b.ID  AND a.REQ_STATUS = d.STAT_ID "+
 					" AND ((a.REQ_STATUS = 1 and a.CONFL_FOUND <> 'Y') OR (a.REQ_STATUS = 3 and a.CONFL_FOUND = 'Y')) "+
			   		" ORDER BY a.REQ_DT, a.REQ_ID  ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UIRequestDispModel.class));
		log.info("Approved Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<UIRequestDispModel> getAllIamSubmittedReqs()throws SQLException, DataAccessException {
		List<UIRequestDispModel> dataLst = new LinkedList<>();
		String sql= " SELECT a.REQ_ID, a.REQ_TYP, b.NAME as reqTypName, a.REQ_DT, a.REQ_BY, a.USER_ID, a.MGR_WWID, a.BF_ID, a.SEC_IDS, a.REG_IDS, "+
					" a.REQ_STATUS, d.STAT_NAME as reqStatusDesc, a.CONFL_FOUND, a.DT_UPDATED, UPDT_BY, a.COMMENTS "+
					" FROM SOD_DB_USER.USER_REQUEST a, SOD_DB_USER.REQ_TYPE b , SOD_DB_USER.REQUEST_STATUS d "+
					" WHERE a.REQ_TYP = b.ID  AND a.REQ_STATUS = d.STAT_ID "+
 					" AND a.REQ_STATUS = "+Constants.ROUTED_IAM_GRC +" ORDER BY a.REQ_DT, a.REQ_ID  ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UIRequestDispModel.class));
		log.info("IAM Submitted Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public String getAdGrpById(String adGrpId) throws SQLException, DataAccessException {
		String sql= " SELECT DISTINCT AD_NAME FROM SOD_DB_USER.MASTER_DATA " +
					" WHERE AD_ID = ? ";
		String adgroup = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {adGrpId}, String.class);
		return adgroup;
	}


	@Override
	public int saveIamReqstedRoles(List<IAMRequestedRoleModel> reqMdlLst ) throws SQLException, DataAccessException {
		log.info("Saving IAM Request");
		String reqSql = " INSERT INTO USER_REQUESTED_ROLES "+
						" (REQ_ID, SEQ_ID, USER_ID, SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, ADGRP_ID, ADGRP_NAME, REQ_BY, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS ) " +
						" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";

		int[] status = getJdbcTemplateSRADUtils().batchUpdate(reqSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setInt(1, reqMdlLst.get(i).getReqId());
				ps.setInt(2, (i+1));
				ps.setString(3, reqMdlLst.get(i).getUserId());
				ps.setString(4, reqMdlLst.get(i).getSysId());
				ps.setString(5, reqMdlLst.get(i).getSysName());
				ps.setString(6, reqMdlLst.get(i).getPosId());
				ps.setString(7, reqMdlLst.get(i).getPosName());
				ps.setString(8, reqMdlLst.get(i).getPvId());
				ps.setString(9, reqMdlLst.get(i).getPvName());
				ps.setString(10, reqMdlLst.get(i).getAdgrpId());
				ps.setString(11, reqMdlLst.get(i).getAdgrpName());
				ps.setString(12, reqMdlLst.get(i).getReqBy());
				ps.setString(13, reqMdlLst.get(i).getComments());
				ps.setString(14, reqMdlLst.get(i).getSubmUid());
				ps.setDate(15, new java.sql.Date(reqMdlLst.get(i).getSubmDate().getTime()));
				ps.setString(16, reqMdlLst.get(i).getSubmStatus());
			}

			@Override
			public int getBatchSize() {
				return reqMdlLst.size();
			}
		});
		log.info("Total Request Roles saved ::"+((status==null) ?"0":status.length+""));
		return (status==null) ?0:status.length;
	}

	@Override
	public int updateIamReqstedRolesStatus(String apiStatus, String apiMsg, String apiErrMsg, Date updDt, IAMRequestedRoleModel detailNum ) throws SQLException, DataAccessException {
		log.info("Update IAM Request Status");
		String reqSql = " UPDATE SOD_DB_USER.USER_REQUESTED_ROLES " +
						" SET API_STATUS = ?, API_MSG = ?, API_ERROR_MSG = ?, UPD_DATE= ? "+
						" WHERE  REQ_ID = ? AND SEQ_ID = ? AND SYS_ID = ? AND ADGRP_ID = ? " ;

		int recUpd = getJdbcTemplateSRADUtils().update(reqSql, new Object[] {apiStatus, apiMsg, apiErrMsg, updDt, detailNum.getReqId(), detailNum.getSeqId(), detailNum.getSysId(), detailNum.getAdgrpId()});
		log.info("Total Roles Status updated for ::"+recUpd);
		return recUpd;
	}

	@Override
	public int getRequestChildCount(String reqId) throws SQLException, DataAccessException{
		int count = 0;
		String sql = " SELECT COUNT(REQ_ID) FROM SOD_DB_USER.USER_REQUESTED_ROLES WHERE REQ_ID = ? ";
		count = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {reqId}, Integer.class);
		return count;
	}

	@Override
	public List<String> getCompletedReqStatus(String reqId) throws SQLException, DataAccessException{
		List<String> dataList = new ArrayList<>();
		String sql = " SELECT API_STATUS FROM SOD_DB_USER.USER_REQUESTED_ROLES " +
					 " WHERE REQ_ID = ? AND API_STATUS IS  NOT NULL AND API_STATUS <> 'P' ";
		dataList = getJdbcTemplateSRADUtils().queryForList(sql, new Object[] {reqId}, String.class);
		return dataList;
	}


		/**
		 * Method  : UserIdentityDaoImpl.java.getDBRoleReqstStatus()
		 *		   :<b>@param reqId
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :Jun 28, 2022 4:53:10 PM
		 * Purpose :Get Status for Completed/Rejected Roles
		 * @return : List<IAMRequestedRoleModel>
		 */
	@Override
	public List<IAMRequestedRoleModel> getDBRoleReqstStatus(String reqId) throws SQLException, DataAccessException {
		List<IAMRequestedRoleModel> dataLst = new ArrayList<>();
		/*String sql= " Select REQ_ID, SEQ_ID, USER_ID, SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, ADGRP_ID, ADGRP_NAME, REQ_BY, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS, API_STATUS, API_MSG, UPD_DATE, API_ERROR_MSG " +
					" FROM  SOD_DB_USER.USER_REQUESTED_ROLES WHERE REQ_ID = ? AND API_STATUS IS  NOT NULL AND API_STATUS <> 'P' " +
					" ORDER BY REQ_ID, SYS_ID, SEQ_ID " ;*/

		String sql = " Select a.REQ_ID, a.SEQ_ID, a.USER_ID, a.SYS_ID, b.S_NAME as sysName, a.POS_ID, a.POS_NAME, a.PV_ID, a.PV_NAME, a.ADGRP_ID, a.ADGRP_NAME, a.REQ_BY, a.COMMENTS, a.SUBM_UID, a.SUBM_DATE, "+
				 	 " a.SUBM_STATUS, a.API_STATUS, a.API_MSG, a.UPD_DATE, a.API_ERROR_MSG "+
				 	 " FROM  SOD_DB_USER.USER_REQUESTED_ROLES a, SOD_DB_USER.SYSTEM_PLATFORM b WHERE a.REQ_ID = ? AND a.API_STATUS IS  NOT NULL AND a.API_STATUS <> 'P' "+
				 	 " AND a.SYS_ID = b.S_ID "+
				 	 " ORDER BY a.REQ_ID, a.SYS_ID, a.SEQ_ID ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(IAMRequestedRoleModel.class));
		log.info("Submitted Request size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<String> getAllSystemPosVariants(String bfId, String[] secIds, String[] regIds, String sysId)throws SQLException, DataAccessException{
		List<String> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT PV_ID FROM SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		sql.append(" ORDER BY 1 ");
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql.toString(), inParam, String.class);
		log.info("POS Varnts size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<KeyValPair> getAllSystemPosVariantsKV(String bfId, String[] secIds, String[] regIds, String sysId)throws SQLException, DataAccessException{
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT PV_ID as KEY, PV_NAME as VAL FROM SOD_DB_USER.MASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1)];
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		sql.append(" ORDER BY 1,2 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("POS Varnts size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<KeyValPair> getPosVarKeyVal(String[] pvIds) throws SQLException, DataAccessException {
		List<KeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		Object[] inParam = new Object[pvIds.length];
		sql.append(" SELECT DISTINCT PV_ID AS KEY, PV_NAME AS VAL FROM SOD_DB_USER.MASTER_DATA ");
		if(pvIds.length == 1) {
			sql.append(" WHERE  PV_ID = ? ");
			inParam[0]=pvIds[0];
		}else if(pvIds.length > 1){
			sql.append(" WHERE PV_ID in ( ");
			String qmrk="";
			for(int i=0; i<pvIds.length; i++) {
				inParam[i]=pvIds[i];
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
			}
			sql.append(qmrk+" )");
		}
		sql.append(" ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(KeyValPair.class));
		log.info("Variant size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


}
