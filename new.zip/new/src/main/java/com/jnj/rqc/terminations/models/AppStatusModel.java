package com.jnj.rqc.terminations.models;

import java.util.Date;

import lombok.Data;

@Data
public class AppStatusModel {
	String	wwid;
	String 	userId;
	String	applRole;
	Date 	updateDt;
	String 	srcSys;
	String 	empStatus;
	String	jjedsStatus;
	Date	jjedsChangeTms;
	Date	jjedsTermDt;



	public String getData() {
		//return applRole+"~"+srcSys+"~"+updateDt+"~"+(("Y".equals(empStatus))?"ACTIVE":("N".equals(empStatus)?"TERMINATED":""+empStatus))+"~"+jjedsChangeTms+"~"+jjedsStatus;
		return srcSys+"~"+updateDt+"~"+(("Y".equals(empStatus))?"ACTIVE":("N".equals(empStatus)?"TERMINATED":("R".equals(empStatus)?"REMOVED":""+empStatus)))+"~"+jjedsChangeTms+"~"+jjedsStatus+"~"+jjedsTermDt;
	}



	@Override
	public String toString() {
		return "AppStatusModel [wwid=" + wwid + ", userId=" + userId + ", applRole=" + applRole + ", updateDt="
				+ updateDt + ", srcSys=" + srcSys + ", empStatus=" + empStatus + ", jjedsStatus=" + jjedsStatus
				+ ", jjedsChangeTms=" + jjedsChangeTms + "]";
	}

}
