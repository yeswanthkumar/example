package com.jnj.rqc.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.jnj.rqc.conflictModel.EmailInfoModel;
import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.U2RFinalSummaryMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.models.PlatformProjectMdl;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.useridentity.models.UIRequestModel;



@Component("EmailUtil")
public class EmailUtil{
	private static final Logger log = Logger.getLogger(EmailUtil.class);
	@Autowired
	Environment env;
	@Autowired
	UserMenuDao userMenuDao;

	private static String confidentiality = "<br><b><u>Confidentiality Notice:</b></u><br>"+
									 "This e-mail transmission may contain confidential or legally privileged information \n"+
									 "that is intended only for the individual or entity named in the e-mail address. \n"+
									 "If you are not the intended recipient, you are hereby notified that any disclosure, \n"+
									 "copying, distribution, or reliance upon the contents of this e-mail is strictly prohibited.\n"+
									 "If you have received this e-mail transmission in error, please reply to the sender, \n"+
									 "so that Johnson & Johnson can arrange for proper delivery, and then \n"+
									 "please delete the message from your inbox. Thank you.";
	private static Session session;

	//private static final DateFormat DATE_FORMATTER = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	/* Dharm :  */
	public static void main(String []args){
		EmailUtil em = new EmailUtil();
		try {
			em.sendEmail("Test Processing Status",  "Hi This is Dharm","D:\\Users\\DChauras\\RQC\\TERMINATIONS\\Terminations_08182020\\HCS_Applications_Termination_Requests_08-18-2020.xlsx", null);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public void sendEmail(String subject, String message, String filePath, List<String> invldRoles, String toAddress, String fromAddress) throws Exception {
		transport(subject, message, filePath, invldRoles, toAddress, fromAddress);
	}

	public void sendEmail(String subject, String message, String filePath, List<String> invldRoles) throws Exception {
		transport(subject, message, filePath, invldRoles);
	}

	private void transport( String subject, String message, String filePath, List<String> invldRoles) throws Exception {
		log.info("Sending Email in LOCAL subject: "+subject+ " AND message: "+message);
		getSession();
		message = buildMessage(message, invldRoles);
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		mimeMessage.setRecipients(Message.RecipientType.TO, getRecipient(env.getProperty("email.to")));
		mimeMessage.setSubject(subject);
		//create Multipart object and add MimeBodyPart objects to this object
		Multipart multipart = getMultipartData(filePath, message);
		//4) set the multiplart object to the message object
		mimeMessage.setContent(multipart);

		//send message
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}


	private void transport( String subject, String message, String filePath, List<String> invldRoles, String toAddress, String fromAddress) throws Exception {
		log.info("Sending Email in LOCAL subject: "+subject+ " AND message: "+message);
		getSession();
		message = buildMessage(message, invldRoles);
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(fromAddress));
		InternetAddress[] recipientAddress = getRecipient(toAddress);
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);

		Multipart multipart =  getMultipartData(filePath, message);

		//4) set the multiplart object to the message object
		mimeMessage.setContent(multipart );

		//5) send message
		// mimeMessage.setContent(message, "text/html; charset=utf-8");
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}

	private String buildMessage(String message, List<String> invldRoles) {
		message = message.replaceAll("CURRENTDATE", Utility.fmtMMDDYYYYTime(new Date())); //Adding current date to Message
		//message = "Attention: "+env.getProperty("email.toname")+",\n"+message+"\n";
		message = "<font face='Arial,Helvetica,sans-serif' color='Red' size='4' weight='bold'>Attention</font>: "+"<br>"+message+"<br>";
		if(null!=invldRoles && !invldRoles.isEmpty()) {
			String rlNms="";
			for(String rls:invldRoles) {
				rlNms+=rls+", ";
			}
			if(rlNms.length() > 0) {
				message+=" INVALID ROLES Entered : ["+rlNms+"]<br>";
			}
		}
		message+=Constants.ROLE_CONFLICT_MSG2;
		message+=confidentiality;
		return message;
	}

	private InternetAddress[] getRecipient(String toAddress) throws Exception {
		InternetAddress[] recipientAddress;
		if (toAddress.indexOf(',') != -1) {
			String[] recipientList = toAddress.split(",");
			recipientAddress = new InternetAddress[recipientList.length];
			int counter = 0;
			for (String recipient : recipientList) {
				recipientAddress[counter] = new InternetAddress(recipient.trim());
				counter++;
			}
		} else {
			recipientAddress = new InternetAddress[1];
			recipientAddress[0] =  new InternetAddress(toAddress);
		}

		return recipientAddress;
	}

	private Session getSession() {
		Properties props = System.getProperties();
		props.setProperty("mail.smtp.host", env.getProperty("email.host"));
		props.setProperty("mail.smtp.auth", "true");
		if(session == null) {
			//session = Session.getDefaultInstance(props, new Authenticator(){
			session = Session.getInstance(props, new Authenticator(){
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(env.getProperty("email.username"), env.getProperty("email.pwd"));
				}
			});
		}
		return session;
	}

	 private Multipart getMultipartData(String filePath, String message) throws Exception {
		 Multipart multipart = new MimeMultipart();

		//1) create MimeBodyPart object and set your message text
		 BodyPart messageBodyPart1 = new MimeBodyPart();
		 //messageBodyPart1.setText(message);
		 messageBodyPart1.setContent(message, "text/html; charset=utf-8");
		 multipart.addBodyPart(messageBodyPart1);

		 if(filePath != null && filePath.length() > 0) {
			 String[] filename = filePath.split(";");

			 if(filename.length > 0) {
				 DataSource source = new FileDataSource(filename[0]);
				 MimeBodyPart messageBodyPart2 = new MimeBodyPart();
				 messageBodyPart2.setDataHandler(new DataHandler(source));
				 messageBodyPart2.setFileName(new File(filename[0]).getName());
				 multipart.addBodyPart(messageBodyPart2);
			 }

	    	if(filename.length > 1) {
	    		DataSource source = new FileDataSource(filename[1]);
	    		MimeBodyPart messageBodyPart3 = new MimeBodyPart();
	    		messageBodyPart3.setDataHandler(new DataHandler(source));
			    messageBodyPart3.setFileName(new File(filename[1]).getName());
			    multipart.addBodyPart(messageBodyPart3);
	    	}
	    	if(filename.length > 2) {
	    		DataSource source = new FileDataSource(filename[2]);
	    		MimeBodyPart messageBodyPart4 = new MimeBodyPart();
	    		messageBodyPart4.setDataHandler(new DataHandler(source));
			    messageBodyPart4.setFileName(new File(filename[2]).getName());
			    multipart.addBodyPart(messageBodyPart4);
	    	}
		 }
		 return multipart;
	 }


	public EmailInfoModel getEmailInfo(String name) {
		EmailInfoModel mdl = new EmailInfoModel();
		mdl.setRecName(env.getProperty("email.toname"));
		mdl.setFrom(env.getProperty("email.from"));
		mdl.setTo(env.getProperty("email.to"));
		mdl.setSubject(Constants.EML_SUBJECT+" "+name);
		return mdl;
	}

	//EMAIL MESSAGES for USER TO CRITICAL ROLE
	public void sendSapUser2CriticalEmail(String subject, List<SAPTrfCntrlSummaryMdl> summary, UserSearchModel user, String fromAddress, String region, String sType) throws Exception {
		log.info("Sending User to Critical Roles Email with subject: "+subject);
		getSession();
		String message = buidlTransferControlMessage(summary, user, region, sType, "CR");//CR=CRITICAL ROLES
		message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
		message = message+ Utility.getServerProp("SERVER_URL")+" <br><br>";
		message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(fromAddress));
		InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");

		//5) send message
		// mimeMessage.setContent(message, "text/html; charset=utf-8");
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}

		//EMAIL MESSAGES for USER TO SOD
		public void sendSapUser2SodEmail(String subject, List<SAPTrfCntrlSummaryMdl> summary, UserSearchModel user, String fromAddress, String region, String sType) throws Exception {
			log.info("Sending User to Sod Email with subject: "+subject);
			getSession();
			String message = buidlTransferControlMessage(summary, user, region, sType, "US");//CR=CRITICAL ROLES
			message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
			message = message+ Utility.getServerProp("SERVER_URL")+" <br><br>";
			message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
			message+=confidentiality;
			MimeMessage mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(fromAddress));
			InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
			mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
			mimeMessage.setSubject(subject);
			mimeMessage.setContent(message, "text/html; charset=utf-8");

			//5) send message
			// mimeMessage.setContent(message, "text/html; charset=utf-8");
			log.info("Status Email Sent.........!");
			Transport.send(mimeMessage);
		}



	public void sendSapTrfEmail(String subject, List<SAPTrfCntrlSummaryMdl> summary, UserSearchModel user, String fromAddress, String region, String sType, String proc) throws Exception {
		transport(subject, summary, user, fromAddress, region, sType, proc);
	}

	private void transport(String subject, List<SAPTrfCntrlSummaryMdl> summary, UserSearchModel user, String fromAddress, String region, String sType, String proc) throws Exception {
		log.info("Sending Email with subject: "+subject);
		getSession();
		String message = buidlTransferControlMessage(summary, user, region, sType, proc);
		message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
		message = message+" "+Utility.getServerProp("SERVER_URL")+ " <br><br>";
		message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(fromAddress));
		InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");

		//5) send message
		// mimeMessage.setContent(message, "text/html; charset=utf-8");
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}

	private String buidlTransferControlMessage(List<SAPTrfCntrlSummaryMdl> summary, UserSearchModel user, String region, String sType, String proc){
		StringBuilder data = new StringBuilder();
		data.append("Hi "+user.getFmlyNm()+" "+user.getGivenNm()+",<br>") ;
		String process = "";
		if("CR".equals(proc)) {
			process="ERP USER TO CRITICAL ROLE";
		}else if("U".equals(proc)) {
			process="ERP USER TO ROLE";
		}else if("US".equals(proc)) {
			process="ERP USER TO SOD";
		}else {
			process="ERP TRANSFER CONTROL";
		}

		if("C".equals(sType)) {
			data.append("ERP data has been extracted or Created for "+process+" Region : "+region+" <br> ");
		}else {
			data.append("ERP data has been Exported to GENESIS for "+process+" Region : "+region+" <br> ");
		}
		data.append("<body>");
		data.append("<Table border ='0' width='80%;'> ");
		if("C".equals(sType)) {
			data.append("	<TR><TD colspan='1'> Summary of Data Created</td></tr>");
		}else {
			data.append("	<TR><TD colspan='1'> Summary of Unique Records Exported</td></tr>");
		}
		data.append("	<TR><TD>");
		data.append("		<TABLE border ='1' width='95%;'>");
		data.append("			<TR><TD>SR</TD><TD>REGION</TD><TD>PLATFORM</TD><TD>ENVIRONMENT</TD><TD>SYSTEM</TD><TD>RECORDS</TD></TR>");
					int total=0;
					int i=1;
					for(SAPTrfCntrlSummaryMdl mdl: summary) {
						data.append("<TR>");
						data.append(	"<TD>"+i+"</TD>");
						data.append(	"<TD>"+mdl.getRegion()+"</TD>");
						data.append(	"<TD>"+mdl.getPlatform()+"</TD>");
						data.append(	"<TD>"+mdl.getEnvironment()+"</TD>");
						data.append(	"<TD>"+mdl.getSystem()+"</TD>");
						if(mdl.getCount() > 0) {
							data.append(	"<TD>"+mdl.getCount()+"</TD>");
						}else {
							data.append(	"<TD bgcolor='red'>"+mdl.getCount()+"</TD>");
						}
						data.append("</TR>");
						total+=mdl.getCount();
						i++;
					}
		data.append("		</TABLE>");
		data.append("		</TD>");
		data.append("	</TR>");
		data.append("</Table>");
		if("C".equals(sType)) {
			data.append("<br><span>Total Number of records extracted or created : "+total+"</span><br>");
		}else {
			data.append("<br><span>Total Number of records exported to Genesis : "+total+"</span><br>");
		}
		return data.toString();
	}

	//Transfer Control Messages
	public void sendGenesisU2RReportEmail(String subject, String filePath, String toEmail, String type) throws Exception{
		transportGenesis(subject, filePath, toEmail, type);
	}


	public void sendGenesisTrfReportEmail(String subject, String filePath, String toEmail, String type) throws Exception{
		transportGenesis(subject, filePath, toEmail, type);
	}

	private void transportGenesis(String subject, String filePath, String toEmail, String type) throws Exception {
		log.info("Sending Email Trasnfer Report subject: "+subject);
		try {
			getSession();
			String message = "Hello Team, <br>";
			if("T".equals(type)) {
				message+=	"<br>"+"Please review the attached Weekly status update ERP TRANSFER CONTROL REPORT files <br><br>"+
						 	"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Platform team to action on the below</u></font> :<br><br>"+

						 	"This emails has 2 attachments:-<br><br>"+
						 	"1. <b>Signed off Items</b> - This file has the Signed off items from the NAGS (review which are Saved and Submitted by approvers). The team will have to review this file and take action on the Revoke items. 'Revoke' Items part of the Career transfer review is to remove the access completely for the user on the listed platform/system.<br>"+
							"Note: After the action is taken, the Platform team to store the evidence in a location specific to that platform and need not be provided to the Extended team. When needed we may reach out for evidence.<br><br>"+
							" 2. <b>Not Signed off Items</b> - These are unreviewed items in the review for the platform. The team can follow up with the pending approvers only after 2 weeks from the time the review is generated in Nags. As a monitor few associates will still have access in the NAGS to check this.<br>"+
							"Note: Please refrain from sending any mass communication to pending approvers, as NAGS is already doing this activity. Reach out to them separately over Email or Teams.<br><br>"+

							"<font face='Helvetica' color='Red' size='4' weight='bold'><u>General Instructions</u></font>:<br>"+
							"1. If the email received has only one file (either Signed off or Not Signed off), it only indicates that those are the available items for that platforms until that period.<br>"+
							"2. The attached files will be updated each week you receive them.<br>"+
							"3.For each review the Tool will send 4 Emails. The team has to be vigilant and act upon accordingly as they receive them.<br><br>"+

							"<b>All the remediations have to be completed</b> <font face='Helvetica' color='Red' size='4' >within 30 days</font> <b>from the date, the review is closed in Nags. Evidence should be in stored in the SharePoint</b>.<br>"+
							"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";
			}else if("U".equals(type) || "US".equals(type) ){
				String ttl = ("U".equals(type))?"ERP USER TO ROLE":"ERP USER TO SOD";
				message+=	"<br>"+"Please review the attached Weekly status update "+ttl+" REPORT files <br><br>"+
					 	"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Platform team to action on the below</u></font> :<br><br>"+

					 	"This emails has 2 attachments:-<br><br>"+
					 	"1. <b>Signed off Items</b> - This file has the Signed off items from the NAGS (review which are Saved and Submitted by approvers). The team will have to review this file and take action on the Revoke items. 'Revoke' Items part of the Career transfer review is to remove the access completely for the user on the listed platform/system.<br>"+
						"Note: After the action is taken, the Platform team to store the evidence in a location specific to that platform and need not be provided to the Extended team. When needed we may reach out for evidence.<br><br>"+
						" 2. <b>Not Signed off Items</b> - These are unreviewed items in the review for the platform. The team can follow up with the pending approvers only after 2 weeks from the time the review is generated in Nags. As a monitor few associates will still have access in the NAGS to check this.<br>"+
						"Note: Please refrain from sending any mass communication to pending approvers, as NAGS is already doing this activity. Reach out to them separately over Email or Teams.<br><br>"+

						"<font face='Helvetica' color='Red' size='4' weight='bold'><u>General Instructions</u></font>:<br>"+
						"1. If the email received has only one file (either Signed off or Not Signed off), it only indicates that those are the available items for that platforms until that period.<br>"+
						"2. The attached files will be updated each week you receive them.<br>"+
						"3.For each review the Tool will send 4 Emails. The team has to be vigilant and act upon accordingly as they receive them.<br><br>"+

						"<b>All the remediations have to be completed</b> <font face='Helvetica' color='Red' size='4' >within 30 days</font> <b>from the date, the review is closed in Nags. Evidence should be in stored in the SharePoint</b>.<br>"+
						"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";

			}else {
				String processType = ("DS".equals(type))? "ERP USER TO SOD":"ERP USER TO ROLE";
				message+= 	"<br>Please review the attached "+processType+" REPORT on the data which were rejected by NAGS at the time of review Generation.<br>"+
							"This file has all the entitlements for the platform where the user Status is either TERMINATED/INVALID/INACTIVE/PENDING or does not have a WWID associated.<br><br>"+
							"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Action item for the Team</u></font> - The team should be able to review these items and be sure to take the following action for each of the status below:<br><br>"+

							"1. <b>TERMINATED</b> - The termination job should have removed the roles, Please re-verify in the system and confirm.<br>"+
							"2. <b>INVALID/INACTIVE/PENDING</b> - Users of these status should be manually followed up with the current Supervisor as per the JJEDS and an email approval on the existence of account is mandatory. After the supervisor confirms that the account is needed, please get the SOD conflicts approved by the respective compliance manager offline in an email.<br>"+
							"3. <b>ACTIVE</b> - Ideally Active users are not part of this list, but may contain due to the status change from the time the data was generated and collected. Manual follow up with the Compliance manager over email is mandatory to secure the approval on the SOD conflicts.<br>"+
							"4. <b>NON WWID accounts</b> - Get the email approval on the entitlements with the respective Platform security Leads and secure the evidences. <br><br>"+
							"<font face='Helvetica' color='Red' size='4' weight='bold'>Kind Note</font> - <b>All the action has to be completed on these accounts by the platform security team</b> <font face='Helvetica' color='Red' size='4'>within 10 days</font> <b>from the data of receipt of the email. Evidence should be in stored in the SharePoint</b>.<br>"+
							"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";
			}
			message = message+"<br>With Regards,<br><b>Enterprise Application Security Tool (J&J)</b> <br><br>";
			message+=confidentiality;
			MimeMessage mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
			mimeMessage.setRecipients(Message.RecipientType.TO, getRecipient(toEmail));
			mimeMessage.setSubject(subject);
			//create Multipart object and add MimeBodyPart objects to this object
			Multipart multipart = getMultipartData(filePath, message);
			//4) set the multiplart object to the message object
			mimeMessage.setContent(multipart);
			//send message
			log.info("Status Email Sent.........!");
			Transport.send(mimeMessage);
		} catch (Exception e) {
			log.error("Error sending email : "+e.getMessage(), e);
			//throw e;
		}

	}


	public void sendPlatformEmail(String subject, String filePath, String toEmail, String type) throws Exception {
		log.info("Sending Email subject: "+subject);
		try {
			getSession();
			String tContent ="";
			if("T".equals(type)) {
				tContent = "ERP TRANSFER CONTROL" ;
			}else if("U".equals(type)) {
				tContent = "ERP USER TO ROLE";
			}else {
				tContent = "ERP USER TO SOD";
			}

			String message = "Hello Team, <br>";
			if("U".equals(type)) {
				message+= 	"Please review the attached Incomplete data part of the "+tContent+" Data Extraction for the Subjected Platform.<br><br>"+
							"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Action item for the team</u></font>:<br><br>"+
							"1. This file has all accounts other than the 'Active' Status in JJEDS.<br>"+
							"2. Review the file under status column and take the below action as applicable:<br>"+
							"&emsp;a. <b>ACTIVE</b> - should not be a part of the list. If it has accounts which are active in the JJEDS probably this could be due to the time difference in data extraction. Follow up with the listed Supervisor in an Email for approval and store the evidence in the SharePoint.<br>"+
							"&emsp;b. <b>TERMINATED</b> - Check the ID’s in SAP/NON SAP system and make sure that the accounts are locked and roles are removed. Screenshot evidence should be captured and stored in the SharePoint.<br>"+
							"&emsp;c. <b>INVALID/INACTIVE/PENDING</b> - These status should be followed up with the Supervisor as listed in JJEDS in an email and secure approval on these accounts. These could be either maintain or revoke. All email approval evidence should be updated in the SharePoint under the respective platform team folder.<br>"+
							"&emsp;d. <b>No DATA FOUND/No WWID</b> - follow up with the platform Security Lead and secure their approval on these non WWID accounts for the existence in the system.<br><br>"+
							"<font face='Helvetica' color='Red' weight='bold'>Kind Note</font> - <b>All the action has to be completed on these accounts by the platform security team</b> <font face='Helvetica' color='Red' weight='bold'>within 10 days</font> <b>from the data of receipt of the email. Evidence should be in stored in the SharePoint.</b><br>"+
							"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt;<br><br>";

			}if("US".equals(type) ) {
				message+= 	"Please review the attached Incomplete data part of the "+tContent+" Data Extraction for the Subjected Platform.<br><br>"+
						"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Action item for the team</u></font>:<br><br>"+
						"1. This file has all accounts other than the 'Active' Status in JJEDS.<br>"+
						"2. Review the file under status column and take the below action as applicable:<br>"+
						"&emsp;a. <b>ACTIVE</b> - should not be a part of the list. If it has accounts which are active in the JJEDS probably this could be due to the time difference in data extraction. Manual follow up with the Compliance manager over email is mandatory to secure the approval on the SOD conflicts.<br>"+
						"&emsp;b. <b>TERMINATED</b> - Check the ID’s in SAP/NON SAP system and make sure that the accounts are locked and roles are removed. Screenshot evidence should be captured and stored in the SharePoint.<br>"+
						"&emsp;c. <b>INVALID/INACTIVE/PENDING</b> - Users of these status should be manually followed up with the current Supervisor as per the JJEDS and an email approval on the existence of account is mandatory.  After the supervisor confirms that the account is needed, please get the SOD conflicts approved by the respective compliance manager offline in an email..<br>"+
						"&emsp;d. <b>No DATA FOUND/No WWID</b> - follow up with the platform Security Lead and secure their approval on these non WWID accounts for the existence in the system.<br><br>"+
						"<font face='Helvetica' color='Red' weight='bold'>Kind Note</font> - <b>All the action has to be completed on these accounts by the platform security team</b> <font face='Helvetica' color='Red' weight='bold'>within 10 days</font> <b>from the data of receipt of the email. Evidence should be in stored in the SharePoint.</b><br>"+
						"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt;<br><br>";

			}else {
				message+="<br>"+"Please review the attached "+tContent+" files<br><br><br>";
			}
			message = message+"<br>With Regards,<br><b>Enterprise Application Security Tool (J&J)<br><br> ";
			message+=confidentiality;
			MimeMessage mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
			mimeMessage.setRecipients(Message.RecipientType.TO, getRecipient(toEmail));
			mimeMessage.setSubject(subject);
			//create Multipart object and add MimeBodyPart objects to this object
			Multipart multipart = getMultipartData(filePath, message);
			//4) set the multiplart object to the message object
			mimeMessage.setContent(multipart);
			//send message
			log.info("Status Email Sent.........!");
			Transport.send(mimeMessage);
		} catch (Exception e) {
			log.error("Error sending email : "+e.getMessage(), e);
			//throw e;
		}

	}


	public void sendProcessingEmail(String subject, String platform, String fileName, int totRecs, int exportRec, UserSearchModel user, String sType) throws Exception {
		log.info("Sending Email with subject: "+subject);
		getSession();
		String message = "Hi "+user.getFmlyNm()+" "+user.getGivenNm()+",<br>";
		if("T".equals(sType)) {
			message+="ERP TRANSFER CONTROL";
		}else if("U".equals(sType)) {
			message+="ERP USER TO ROLE";
		}else if("M".equals(sType)) {
			message+="ERP USER TO SOD";
		}else {
			message+="ERP USER TO CRITICAL ROLE";
		}

		message+= " data has been Exported to GENESIS for "+platform+" <br> ";
		message+= "TOTAL Records in File :"+totRecs+" <br> ";
		message+= "TOTAL Records Exported :"+exportRec+" <br> ";

		message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
		message = message+" "+Utility.getServerProp("SERVER_URL")+ " <br><br>";
		message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Status Email Sent.........!");
	}


	public void sendRefDataEmail(String subject, String platform, String fileName, int totRecs, int exportRec, UserSearchModel user, String sType) throws Exception {
		log.info("Sending Email with subject: "+subject);
		getSession();
		String message = "Hi "+user.getFmlyNm()+" "+user.getGivenNm()+",<br>";
		if("M".equals(sType)) {
			message+="GRAC MITIGATING CONTROL ";
		}else if("R".equals(sType)) {
			message+="REVIEWERS DATA ";
		}
		else {
			message+="OTHER DATA";
		}

		message+= " data has been saved to Database for "+platform+" <br> ";
		message+= "TOTAL Records in File :"+totRecs+" <br> ";
		message+= "TOTAL Records Saved :"+exportRec+" <br> ";

		message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
		message = message+" "+Utility.getServerProp("SERVER_URL")+ " <br><br>";
		message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Status Email Sent.........!");
	}





	//User Request

	public void triggerReqEmail(PlatformProjectMdl prjData, int reqStage, String reqId, UserSearchModel assocUser, UserSearchModel assocMgr, Map<String, List<String>> emailMap ) throws Exception {
		String subject="Application Request ";
		String msg=	"";
		if(reqStage==1) {
			subject+="Submitted: "+prjData.getName()+" Request# : "+reqId+"  User : "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+
					"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")";

			msg=	"<br/>Hello <b>"+assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"</b>("+assocMgr.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")"+
					", <br/>Please review the following <b>"+prjData.getName()+"</b> request and complete your portion of the service request.<br>"+
					"Upon completion, please mark your portions as completed.<br/>" +
					"The following link takes you directly to the application, Please login with your WWID and Network Password<br/>" +
					"Click on <b>Users</b> menu and select <b>My Approval Queue</b><br/><br/> "+
					"<b>"+Utility.getServerProp("SERVER_URL")+"</b><br/><br/>"+
					"<b>Ticket Number: "+ reqId +"<br/>"+
					"Associate Name: "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")<br/>"+
					"Manager Name: "+ assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"("+assocMgr.getWwId()+" - "+assocMgr.getJnjMsftUsrnmTxt()+")</b><br/><br/>"+
					" "+confidentiality;
		}

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));

		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Message sent....!");

	}

	public void sendSodRefreshEmail(String subject, String currEnv, Map<String, Object> errorMap) throws Exception {
		log.info("Sending SOD Refresh Email for ENV :"+currEnv);

		subject+=" for Environment : "+currEnv;
		StringBuilder msg = new StringBuilder().append("Hello Team,<br/>");
		if(errorMap.isEmpty()) {
			subject+=" Successfully. ";
			msg.append("<br/>SOD REFRESH Completed successfully on "+currEnv+" Server @"+Utility.fmtMMDDYYYYTime(new Date())+"</b><br/><br/>"+confidentiality);
		}else {
			subject+=" with Errors. ";
			msg.append("<br/>SOD REFRESH Completed with Error/Exception,<br/>Please view the following errors/exceptions from "+currEnv+" Environments<br/> ");
			msg.append("<Table style='width:85%;border:#f3f3f3 1px solid;'>");
			msg.append("	<TR style='border:#f3f3f3 1px solid;'><TD width='5%;'>SrNo</TD><TD width='25%;'>View/Procedure</TD><TD width='69%;'>Error Message/Exception</TD></TR>");
			int i=0;
			for(Map.Entry<String, Object> entry:errorMap.entrySet()) {
				msg.append("<TR style='border:#f3f3f3 1px solid;'><TD>"+(++i)+"</TD><TD>"+entry.getKey()+"</TD><TD>"+entry.getValue()+"</TD></TR>");
			}
			msg.append("</Table>");
			msg.append("</b><br/><br/> "+confidentiality);
		}

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		//InternetAddress[] recAddrTo = getRecipient(env.getProperty("email.from"));
		InternetAddress[] recAddrTo = getRecipient(env.getProperty("email.from")+",dchauras@its.jnj.com");
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);

		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg.toString(), "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Message sent....!");
	}


	public void sendUser2RoleSummEmail(String subject, List<U2RFinalSummaryMdl> finSumLst, UserSearchModel user, String fromAddress, String region, String sType, String proc) throws Exception {
		log.info("Sending Email with subject: "+subject);
		getSession();
		String message = buidlUser2RoleMessage(finSumLst, user, region, sType, proc);
		message = message+ "<br> "+"Please click the below link to review the data for this control and perform necessary actions<br>";
		message = message+" "+Utility.getServerProp("SERVER_URL")+ " <br><br>";
		message = message+"With Regards,<br>Enterprise Application Security Tool (J&J) <br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(fromAddress));
		InternetAddress[] recipientAddress = getRecipient(user.getJnjEmailAddrTxt());
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");

		//5) send message
		// mimeMessage.setContent(message, "text/html; charset=utf-8");
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}

	private String buidlUser2RoleMessage(List<U2RFinalSummaryMdl> summary, UserSearchModel user, String region, String sType, String proc){
		StringBuilder data = new StringBuilder();
		data.append("Hi "+user.getFmlyNm()+" "+user.getGivenNm()+",<br>") ;
		String process = "";
		if("CR".equals(proc)) {
			process="ERP USER TO CRITICAL ROLE";
		}else if("U".equals(proc)) {
			process="ERP USER TO ROLE";
		}else if("US".equals(proc)) {
			process="ERP USER TO SOD";
		}else {
			process="ERP TRANSFER CONTROL";
		}

		if("C".equals(sType)) {
			data.append("ERP data has been extracted or Created for "+process+" Region : "+region+" <br> ");
		}else {
			data.append("ERP data has been Exported to GENESIS for "+process+" Region : "+region+" <br> ");
		}
		data.append("<body>");
		data.append("<Table border ='0' width='80%;'> ");
		if("C".equals(sType)) {
			data.append("	<TR><TD colspan='1'> Summary of Data Created</td></tr>");
		}else {
			data.append("	<TR><TD colspan='1'> Summary of Unique Records Exported</td></tr>");
		}
		data.append("	<TR><TD>");
		data.append("		<TABLE border ='1' width='95%;'>");
		data.append("			<TR><TD>SR</TD><TD>REGION</TD><TD>PLATFORM</TD><TD>ENVIRONMENT</TD><TD>SYSTEM</TD><TD>ACTIVE RECORDS</TD><TD>INCOMPLETE RECORDS</TD><TD>TOTAL RECORDS</TD></TR>");
					int acttot=0;
					int invtot=0;
					int regtot=0;
					int i=1;
					for(U2RFinalSummaryMdl mdl: summary) {
						data.append("<TR>");
						data.append(	"<TD>"+i+"</TD>");
						data.append(	"<TD>"+mdl.getRegion()+"</TD>");
						data.append(	"<TD>"+mdl.getPlatform()+"</TD>");
						data.append(	"<TD>"+mdl.getEnvironment()+"</TD>");
						data.append(	"<TD>"+mdl.getSystem()+"</TD>");
						if(mdl.getActvCount() > 0) {
							data.append(	"<TD>"+mdl.getActvCount()+"</TD>");
						}else {
							data.append(	"<TD bgcolor='red'>"+mdl.getActvCount()+"</TD>");
						}
						data.append("<TD>"+mdl.getInvlCount()+"</TD>");
						data.append("<TD>"+mdl.getTotal()+"</TD>");
						data.append("</TR>");

						acttot+=mdl.getActvCount();
						invtot+=mdl.getInvlCount();
						regtot+=mdl.getTotal();
						i++;
					}
		data.append("		</TABLE>");
		data.append("		</TD>");
		data.append("	</TR>");
		data.append("</Table>");
		if("C".equals(sType)) {
			data.append("<br><span>Total Number of Valid records extracted or created : "+acttot+"</span><br>");
		}else {
			data.append("<br><span>Total Number of records exported to Genesis : "+acttot+"</span><br>");
		}
		return data.toString();
	}


	//New User Request

	public void triggerNewReqEmail(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst, int reqStage, String reqId, UserSearchModel assocUser, UserSearchModel assocMgr, Map<String, List<String>> emailMap ) throws Exception {
		String subject="User Data Access Request ";
		String sysNames = "";
		for(SysPosAdGrpModelDispMdl disp: dispModelLst) {
			if("".equals(sysNames)) {
				sysNames=disp.getSysName().toUpperCase();
			}else {
				sysNames+=", "+disp.getSysName().toUpperCase();
			}
		}
		subject+="Submitted: "+sysNames+" Request# : "+reqId+"  User : "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+	"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")";
		String msg=	"<br/>Hello <b>";
		msg+=((reqStage==2)? assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"</b>("+assocMgr.getWwId()+" - "+assocMgr.getJnjMsftUsrnmTxt()+"),<br>Please review the following data access request for <b>"+sysNames+"</b> ."
				:assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</b>("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+"),<br> your request is submitted for <b>"+sysNames+"</b> .");
		if(reqStage==2) {
			msg+= "<br>and complete your portion of the service request.<br>"+
					"Upon completion, please mark your portions as completed.<br/>" +
					"The following link takes you directly to the application, Please login with your WWID and Network Password<br/>" +
					"Click on <b>User Request</b> menu and select <b>Retrieve Existing Request</b><br/><br/> "+
					"<b>"+Utility.getServerProp("SERVER_URL")+"</b><br/><br/>"+
					"<b>Ticket Number: "+ reqId +"<br/>"+
					"Associate Name: "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")<br/>"+
					"Manager Name: "+ assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"("+assocMgr.getWwId()+" - "+assocMgr.getJnjMsftUsrnmTxt()+")</b><br/><br/>";
		}else {
			msg+= " <br>The following link takes you directly to the application, Please login with your WWID and Network Password<br/>" +
					"Click on <b>User Request</b> menu and select <b>Retrieve Existing Request</b><br/><br/> "+
					"<b>"+Utility.getServerProp("SERVER_URL")+"</b><br/><br/>"+
					"<b>Ticket Number: "+ reqId +"<br/>"+
					"Associate Name: "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")<br/>"+
					"Manager Name: "+ assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"("+assocMgr.getWwId()+" - "+assocMgr.getJnjMsftUsrnmTxt()+")</b><br/><br/>";
		}
		msg+=" "+confidentiality;

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));

		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Message sent....!");

	}


	public void triggerConfApprovalEmail(String reqId, int reqStage, UserSearchModel assocUser, UserSearchModel assocMgr, String ce) throws Exception {
		String subject=("C".equals(ce))? "SOD CONFLICTS - APPROVAL " : "EXCESSIVE ACCESS - APPROVAL ";
		subject+="User Data Access Request# : "+reqId+"  User : "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+	"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")";
		String msg=	"<br/>Hello <b>";
		msg+= assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</b>("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+"),<br>Your Request# "+reqId+" for data access is approved.";
		msg+= "<br>The following link takes you directly to the application, Please login with your WWID and Network Password<br/>" +
					"Click on <b>User Request</b> menu and select <b>Retrieve Existing Request</b><br/><br/> "+
					"<b>"+Utility.getServerProp("SERVER_URL")+"</b><br/><br/>"+
					"<b>Ticket Number: "+ reqId +"<br/>"+
					"Associate Name: "+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"("+assocUser.getWwId()+" - "+assocUser.getJnjMsftUsrnmTxt()+")<br/>"+
					"Manager Name: "+ assocMgr.getFmlyNm()+", "+assocMgr.getGivenNm()+"("+assocMgr.getWwId()+" - "+assocMgr.getJnjMsftUsrnmTxt()+")</b><br/><br/>";
		msg+=" "+confidentiality;
		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		//TODO - Uncomment
		//InternetAddress[] recAddrTo = getRecipient(assocUser.getJnjEmailAddrTxt());
		//InternetAddress[] recAddrCc = getRecipient(assocMgr.getJnjEmailAddrTxt());
		InternetAddress[] recAddrTo = getRecipient("dchauras@its.jnj.com");
		InternetAddress[] recAddrCc = getRecipient("dchauras@its.jnj.com");
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Message sent....!");

	}


	public void sendGenesisWeeklyReportEmail(String subject, String filePath, String toEmail, String ccEmail, String type) throws Exception {
		log.info("Sending Email Trasnfer Report subject: "+subject);
		try {
			getSession();
			String message = "Hello Team, <br>";
			if("T".equals(type)) {
				message+=	"<br>"+"Please review the attached Weekly status update ERP TRANSFER CONTROL REPORT files <br><br>"+
						 	"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Platform team to action on the below</u></font> :<br><br>"+

						 	"This emails has 2 attachments:-<br><br>"+
						 	"1. <b>Signed off Items</b> - This file has the Signed off items from the NAGS (review which are Saved and Submitted by approvers). The team will have to review this file and take action on the Revoke items. 'Revoke' Items part of the Career transfer review is to remove the access completely for the user on the listed platform/system.<br>"+
							"Note: After the action is taken, the Platform team to store the evidence in a location specific to that platform and need not be provided to the Extended team. When needed we may reach out for evidence.<br><br>"+
							" 2. <b>Not Signed off Items</b> - These are unreviewed items in the review for the platform. The team can follow up with the pending approvers only after 2 weeks from the time the review is generated in Nags. As a monitor few associates will still have access in the NAGS to check this.<br>"+
							"Note: Please refrain from sending any mass communication to pending approvers, as NAGS is already doing this activity. Reach out to them separately over Email or Teams.<br><br>"+

							"<font face='Helvetica' color='Red' size='4' weight='bold'><u>General Instructions</u></font>:<br>"+
							"1. If the email received has only one file (either Signed off or Not Signed off), it only indicates that those are the available items for that platforms until that period.<br>"+
							"2. The attached files will be updated each week you receive them.<br>"+
							"3.For each review the Tool will send 4 Emails. The team has to be vigilant and act upon accordingly as they receive them.<br><br>"+

							"<b>All the remediations have to be completed</b> <font face='Helvetica' color='Red' size='4' >within 30 days</font> <b>from the date, the review is closed in Nags. Evidence should be in stored in the SharePoint</b>.<br>"+
							"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";
			}else if("U".equals(type) || "US".equals(type) ){
				String ttl = ("U".equals(type))?"ERP USER TO ROLE":"ERP USER TO SOD";
				message+= "<br>"+"Please download and review the Weekly status update for "+ttl+" REPORT files <br>by logging into : "+Utility.getServerProp("SERVER_URL")+" <br>"+
						  "Download the zip file for your PLATFORM from<b> SAP DATA => Reports => Weekly - User to Role Reports</b> <br>"+
						  "for Work instruction on how to get data <a href='https://jnj.sharepoint.com/:w:/r/teams/Global_ERP_Application_Security/Shared Documents/41. ERP Application Security/2022 UAR/Work instruction - Weekly Email/New update to the tool - User to Role.docx?d=w91685ebd1f604ddb97ecdb65571aa279&csf=1&web=1&e=tmoIOy'>click here</a> <br><br>"+
						  "<font face='Helvetica' color='Red' size='4' weight='bold'><u>Platform team to action on the below</u></font> :<br><br>"+

					 	"1. <b>Signed off Items</b> - This file has the Signed off items from the NAGS (review which are Saved and Submitted by approvers). The team will have to review this file and take action on the Revoke items. 'Revoke' Items part of the User to Role review is to remove the Role marked as revoke for the user on the listed platform/system.<br>"+
						"Note: After the action is taken, the Platform team has to capture the evidence as a screenshot and have the reconciliation document prepared and updated. This is the platform team responsibility as part of completeness check.<br><br>"+
						" 2. <b>Not Signed off Items</b> - These are unreviewed items in the review for the platform . The team has to follow up with the pending approvers after the review closes in the NAGS to secure offline email approval on the unreviewed entitlements. <br>"+
						"Note: Please refrain from sending any mass communication to pending approvers, as NAGS is already doing this activity. Reach out to them separately over Email or Teams.<br><br>"+

						"<font face='Helvetica' color='Red' size='4' weight='bold'><u>General Instructions</u></font>:<br>"+
						"1. From the downloaded Zip File, if the zip file has one attachment (either Signed off or Not Signed off), it only indicates that those are the available items for that platforms until that period.<br>"+
						"2. The attached files will be updated each week you receive them.<br>"+
						"3. The team has to be vigilant and action the remediation as they receive them.<br><br>"+

						"<b>All the remediations have to be completed</b> <font face='Helvetica' color='Red' size='4' >within 30 days</font> <b>from the date the platform team receives the FINAL weekly email. Evidence should be in stored in the SharePoint</b>.<br>"+
						"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";
			}else {
				String processType = ("DS".equals(type))? "ERP USER TO SOD":"ERP USER TO ROLE";
				message+= 	"<br>Please review the attached "+processType+" REPORT on the data which were rejected by NAGS at the time of review Generation.<br>"+
							"This file has all the entitlements for the platform where the user Status is either TERMINATED/INVALID/INACTIVE/PENDING or does not have a WWID associated.<br><br>"+
							"<font face='Helvetica' color='Red' size='4' weight='bold'><u>Action item for the Team</u></font> - The team should be able to review these items and be sure to take the following action for each of the status below:<br><br>"+

							"1. <b>TERMINATED</b> - The termination job should have removed the roles, Please re-verify in the system and confirm.<br>"+
							"2. <b>INVALID/INACTIVE/PENDING</b> - Users of these status should be manually followed up with the current Supervisor as per the JJEDS and an email approval on the existence of account is mandatory. After the supervisor confirms that the account is needed, please get the SOD conflicts approved by the respective compliance manager offline in an email.<br>"+
							"3. <b>ACTIVE</b> - Ideally Active users are not part of this list, but may contain due to the status change from the time the data was generated and collected. Manual follow up with the Compliance manager over email is mandatory to secure the approval on the SOD conflicts.<br>"+
							"4. <b>NON WWID accounts</b> - Get the email approval on the entitlements with the respective Platform security Leads and secure the evidences. <br><br>"+
							"<font face='Helvetica' color='Red' size='4' weight='bold'>Kind Note</font> - <b>All the action has to be completed on these accounts by the platform security team</b> <font face='Helvetica' color='Red' size='4'>within 10 days</font> <b>from the data of receipt of the email. Evidence should be in stored in the SharePoint</b>.<br>"+
							"Any queries, reach out to the Extended team DL : DL-BTB SolMan LER Security L3 &lt;DL-HCSUS-BTB-LER-SolMan-Security-L3@ITS.JNJ.com&gt; <br><br><br>";
			}
			message = message+"<br>With Regards,<br><b>Enterprise Application Security Tool (J&J)</b> <br><br>";
			message+=confidentiality;
			MimeMessage mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
			mimeMessage.setRecipients(Message.RecipientType.TO, getRecipient(toEmail));
			mimeMessage.setRecipients(Message.RecipientType.CC, getRecipient(ccEmail));
			mimeMessage.setSubject(subject);
			//create Multipart object and add MimeBodyPart objects to this object
			Multipart multipart = getMultipartData(filePath, message);
			//4) set the multiplart object to the message object
			mimeMessage.setContent(multipart);
			//send message
			log.info("Status Email Sent.........!");
			Transport.send(mimeMessage);
		} catch (Exception e) {
			log.error("Error sending email : "+e.getMessage(), e);
			//throw e;
		}

	}
	public void sendAbsNewRequestEmail(String subject,  UserSearchModel assocUser, UserSearchModel requestorUser, int reqId, UserReqCompMdl reqModel, List<AbsSysLeveExcsvRestrMdl> excessiveApprovalList,  Map<String, List<String>> emailMap ) throws Exception {
		String name = "";
		String complFlg = "";
		String reviewReq = "Yes";
		if (assocUser.getGivenNm().equals(requestorUser.getGivenNm()) && assocUser.getFmlyNm().equals(requestorUser.getFmlyNm())) {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm();
		}else {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm()+"/ "+assocUser.getGivenNm()+" "+assocUser.getFmlyNm();
		}
		String reqType = "";
		String content = "";
		if(reqModel.getTypeid() == 2) {
			reqType = "Remove";
			content = "Your Access Request has been successfully submitted and will be sent for further processing within the GRC/IAM systems. This email is for informational purposes only, no further action is required.<br><br>"
					+"Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.</div><br>";
		}else {		
			reqType = "Add";
			content = "Your Access Request has been successfully submitted and will be reviewed by the Compliance Manager (if applicable) in case of any compliance risks within EDAL. The Access Request will be submitted for further processing (only for the access approved by the Compliance Manager) within the GRC/IAM systems.<br><br>"
					+ "Your Access Request will automatically be submitted for further processing within the GRC/IAM systems (without any Compliance Manager review) in case there are no compliance risks identified within your Request.<br><br> "
					+ "Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.</div><br>";
			long excessiveCount = excessiveApprovalList.stream()
					.flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsRestricted().stream()).count();		
			if(excessiveCount > 0) {
				complFlg+="Restricted Access</br>";
			}		
			long excessiveNonCount = excessiveApprovalList.stream()
								.flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsNonRestricted().stream()).count();		
			if(excessiveNonCount > 0) {
				complFlg+="Non Restricted Access</br>";
			}
			
			if("Y".equals(reqModel.getConflictFound())) {
				complFlg+="SOD Conflicts</br>";
			}
			
			/*if("Y".equals(reqModel.getIsExistConflictFound())) {
				complFlg+="SOD Compilance Not Required";
			}*/
			/*if("N".equals(reqModel.getConflictFound())) {
				//if("Y".equals(reqModel.getIsExistConflictFound()) && excessiveCount > 0 && excessiveNonCount > 0 ) {
				if("Y".equals(reqModel.getIsExistConflictFound())  ) {
					if( excessiveCount > 0 || excessiveNonCount > 0) {					
					reviewReq = "Yes";
					}else {
						complFlg+="SOD Conflicts</br>";
						reviewReq = "No";
					}
				}
			}*/
			if ("N".equals(reqModel.getConflictFound()) && "Y".equals(reqModel.getIsExistConflictFound())
			        && (excessiveCount > 0 || excessiveNonCount > 0)) {
			    reviewReq = "Yes";
			    complFlg += "SOD Conflicts</br>";
			} else if ("N".equals(reqModel.getConflictFound()) && "Y".equals(reqModel.getIsExistConflictFound())) {
			    complFlg += "SOD Conflicts</br>";
			    reviewReq = "No";
			}
			
			if(excessiveCount <= 0 && excessiveNonCount <= 0 && "N".equals(reqModel.getConflictFound()) && "N".equals(reqModel.getIsExistConflictFound())) {				
				/*if("Y".equals(reqModel.getIsExistConflictFound())) {
					//complFlg+="SOD Compilance Not Required</br>";
					complFlg+="SOD Conflicts</br>";
				}else { */
					complFlg+="NA</br>";
				//}
				reviewReq = "No";
			}
		}
									
		subject=""+subject;
		String msg1 ="<html><head><style>body{font-family:'Bookman Old Style',serif;font-size:11pt;line-height:1.5;color:#000000}.section{font-family:'Bookman Old Style',serif;margin-top:10px;font-size:11pt}.section-heading{#font-weight:bold;margin-bottom:20px}.table{border-collapse:collapse;width:100%;text-align:center}.table th,.table td{border:1px solid #333;padding:8px;font-size:11pt;white-space: nowrap;text-overflow: ellipsis;overflow: hidden}.table th{font-weight:bold}.button{background-color:#0078D4;color:white;padding:8px 16px;text-decoration:none;border-radius:4px;font-weight:bold}.button:hover{background-color:#005D9D}</style></head>";
		msg1+= "<body><br><div class=\"section\"><span class=\"section-heading\">Dear "
		+toCamelCase(name)+",</span> <br><br>"+content;
				//+ "Your Access Request has been successfully submitted and will be reviewed by the Compliance Manager (if applicable) in case of any compliance risks within EDAL. The Access Request will be submitted for further processing (only for the access approved by the Compliance Manager) within the GRC/IAM systems.<br><br>"
				//+ "Your Access Request will automatically be submitted for further processing within the GRC/IAM systems (without any Compliance Manager review) in case there are no compliance risks identified within your Request.<br><br> "
				//+ "Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.</div><br>";
		msg1+="<div class=\"section\"><span class=\"section-heading\"><b><u>Access Request Summary</u></b></span>:</dir><br><br>";				
		msg1+="<table class=\"table\"><thead><tbody><tr><th><u>Request Creation Date</u></th><th><u>Request ID</u></th><th><u>Requestor</u></th>"
				+ "<th><u>Access Requested For</u></th><th><u>Request Type</u></th><th><u>Status</u></th>";
				if(reqModel.getTypeid() != 2) {
					msg1+= "<th><u>Compliance Review Required</u></th><th><u>Compliance Risks/Flags</u></th>";
				}
				msg1+= "</tr></thead><tbody><tr>"
				+ "<td><strong>"+Utility.fmtddMonYYYY((reqModel.getRequestedon() == null)? new Date():reqModel.getRequestedon())+"</strong></td>"
				+ "<td><strong>"+reqId+"</strong></td>"
				+ "<td><strong>"+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+"</strong></td>"
				+ "<td><strong>"+toCamelCase(assocUser.getGivenNm()+" "+assocUser.getFmlyNm())+"</strong></td>"
				
				+ "<td><strong>"+reqType+" – Security Access</strong></td>"
				+"<td><strong>Created</strong></td>";
				
				if(reqModel.getTypeid() != 2) {
					msg1+="<td><strong>"+reviewReq+"</strong></td><td><strong>"+complFlg+"</strong></td>";
				}
				
				msg1+= "</tr></tbody></table></br>";
		
		log.info("--------------- sendAbsNewRequestEmail   called :");
				
		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		msg1+=" <div class=\"section\" >You can check the details and the latest status of your Access Request by logging into EDAL:<br><br>"
				+ "<b><a href='"+btpUrl+reqId+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></b></br></br>";		
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> btpUrl :"+btpUrl);		
		
		
		//msg+="<a href='"+btpUrl+reqId+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br></br>";
		
		msg1+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		msg1+="<font face='Bookman Old Style'>Best Regards,<br/>";
		msg1+="<b>Enterprise Digital Abstraction Layer (EDAL)</b></font><br/>";
		msg1+="<font face='Bookman Old Style' color='Red'><b>Johnson & Johnson</b></font><br/>";
		msg1+="</br> "+confidentiality+"</div></body></html>";
		
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> msg :"+msg1);

		getSession();
		MimeMessage mimeMessage = new MimeMessage(session);
		
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg1, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Approval Message sent for REQID: "+reqModel.getReqid()+"....!");

	}

	/*
	public void sendAbsNewRequestEmail(String subject,  UserSearchModel assocUser, UserSearchModel requestorUser, int reqId, UserReqCompMdl reqModel, Map<String, List<String>> emailMap ) throws Exception {
		subject=""+subject;
		log.info("--------------- sendAbsNewRequestEmail   called :");
		//Enhancement 06162023: modified the subject on business request
		String msg=	"<br/><b>Your access request is being reviewed for approval. Check your inbox or log into EDAL to review your status at any time.</br> "
				+ "Your access will be submitted in IDMS/GRC once the compliance checks (if applicable) are performed and approved. </br>"
				+ "You will also receive notifications from IDMS/GRC with further status updates on your request.</b></br></br>";
		msg+= (reqModel.getTypeid() == 2)? "Remove ":"Add ";
		msg+=" Access for: <b>"+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</b>  |  Req ID: <b>"+reqId+
			"</b>  |  Created: <b>"+Utility.fmtddMonYYYY(new Date())+"</b></br>";
		msg+="Requestor: <b>" +requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+"<b></br></br>";
		//msg+="<a href='"+Utility.getServerProp("SERVER_URL")+"'> View Request </a></br></br></br>";
		//msg+="<a href='https://devsec.launchpad.cfapps.us10.hana.ondemand.com/3b6fda9f-ddc2-41e3-b5c8-849ba1f375c5.edaldevversion2.edalappdev-0.0.1/index.html#/pendingRequests'> View Request </a></br></br></br>";

		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> btpUrl :"+btpUrl);
		msg+="<a href='"+btpUrl+reqId+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br></br>";
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> msg :"+msg);

		//Collectng all POSVARIDS
		List<String> adList = new ArrayList<>();
		reqModel.getSysList().forEach(e ->{
			Arrays.asList(e.getPosvarids().split(",")).forEach(itm ->{
				adList.add(itm);
			});
		});

		String rtype=(reqModel.getTypeid() == 1)? "Add":"Remove";
		//Request Data
		msg+="<Table width='65%' border='0'>"
				+ "<tr>"
				+ 	"<th width='25%'>Request Type</th><th width='55%'>&nbsp</th><th width='15%'>Status</th>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td align='center'>"+rtype+"  -  "+adList.size()+" Security Groups</td><td>&nbsp</td><td>Created</td>"
				+ "</tr>"
				+ "<tr height='50px;'>"
				+ 	"<td colspan='3'>&nbsp;</td>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td><b>Access Reason:</b></td><td>&nbsp</td><td>&nbsp;</td>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td colspan='2'>"+reqModel.getComments()+"</td><td>&nbsp;</td>"
				+ "</tr>"
			+ "</Table>";
		msg+="</br></br>";


		//Compliance Flags
		msg+="Compliance Flag(s):<font face='Arial,Helvetica,sans-serif' color='Red' size='4' >*</font><br>";
		if("Y".equals(reqModel.getIsExces())) {
			msg+="• Restricted/Excessive Access</br>";//Enhancement 06162023: modified the test on business request
		}

		if("Y".equals(reqModel.getConflictFound())) {
			msg+="• SOD Conflicts";
		}

		//Adding confidentiality message
		msg+="</br></br></br> "+confidentiality;

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		//mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Saved Message sent for mimeMessage: "+mimeMessage+"....!");
		log.info("Saved Message sent for REQID: "+reqId+"....!");

	}*/
	private static String toCamelCase(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        String[] words = input.split("\\s+");
        String camelCase = Arrays.stream(words)
                .map(word -> word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase())
                .collect(Collectors.joining(" "));
        return camelCase;
    }


	public void sendAbsRequestApprovalEmail(String subject, UserSearchModel assocUser, UserSearchModel requestorUser, UserSearchModel approverUser, AbsUserReqMdl reqData, List<UserAbsConflictMdl> confList, List<AbsSysLeveExcsvRestrMdl> excessiveApprovalList, Map<String, List<String>> emailMap ) throws Exception {
		String name = "";
		if (assocUser.getGivenNm().equals(requestorUser.getGivenNm()) && assocUser.getFmlyNm().equals(requestorUser.getFmlyNm())) {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm();
		}else {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm()+"/ "+assocUser.getGivenNm()+" "+assocUser.getFmlyNm();
		}
		subject =""+subject;
		String msg1 ="<html><head><style>body{font-family:'Bookman Old Style',serif;font-size:11pt;line-height:1.5;color:#000000}.section{font-family:'Bookman Old Style',serif;margin-top:10px;font-size:11pt}.section-heading{#font-weight:bold;margin-bottom:20px}.table{border-collapse:collapse;width:100%;text-align:center}.table th,.table td{border:1px solid #333;padding:8px;font-size:11pt;white-space: nowrap;text-overflow: ellipsis;overflow: hidden}.table th{font-weight:bold}.button{background-color:#0078D4;color:white;padding:8px 16px;text-decoration:none;border-radius:4px;font-weight:bold}.button:hover{background-color:#005D9D}</style></head>";
		msg1+= "<body><br><div class=\"section\"><span class=\"section-heading\">Dear "
		+toCamelCase(name)+",</span> <br><br>"
		//+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+",</span> <br><br>"
				+ "Your Access Request has been reviewed by the Compliance Manager within EDAL and will be submitted for further "
				+ "processing within the GRC/IAM systems. Please check your inbox for updates or log into EDAL to check the "
				+ "latest status of your Access Request at any time.</div>";
		/*String msg="<br/>Dear " +requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+",<br/><style>  p {margin: 0; padding: 0;  }</style><p>&nbsp;</p>"+
		           "Your Access Request has been reviewed by the Compliance Manager within EDAL and will be submitted for further processing within the GRC/IAM systems.<br/>"+
				   "Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.<br/><br/>";*/
		msg1+="<div class=\"section\"><span class=\"section-heading\"><b><u>Access Request Summary</u></b></span>:<br><br>";
		//msg +="<b><u>Access Request Summary</u></b>:<br><style>  p {margin: 0; padding: 0;   }</style><p>&nbsp;</p>";
		
		String complFlg = "";
		
		List<RoleADGrpMdl> selVarsRestrictedAorF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()) || "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		if(selVarsRestrictedAorF.size() >0) {
			complFlg+="Restricted Access</br>";
		}
		List<RoleADGrpMdl> selVarsNonRestrictedAorF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsNonRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()) || "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		if(selVarsNonRestrictedAorF.size() >0) {
			complFlg+="Non Restricted Access</br>";
		}

		if(confList != null && !confList.isEmpty()) {			
			complFlg+= "SOD Conflicts";
		}
		msg1+="<table class=\"table\"><thead><tbody><tr><th><u>Request Creation Date</u></th><th><u>Request ID</u></th><th><u>Requestor</u></th>"
		+ "<th><u>Access Requested For</u></th><th><u>Request Type</u></th><th><u>Status</u></th><th><u>Compliance Review Performed By</u></th>"
		+ "<th><u>Compliance Risks/Flags Reviewed</u></th></tr></thead><tbody><tr>"
		+ "<td><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td>"
		+ "<td><strong>"+reqData.getReqid()+"</strong></td>"
		+ "<td><strong>"+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+"</strong></td>"
		+ "<td><strong>"+toCamelCase(assocUser.getGivenNm()+" "+assocUser.getFmlyNm())+"</strong></td>"
		//+ "<td><strong>"+reqData.getTypename()+"</strong></td>"
		+ "<td><strong>Add – Security Access</strong></td>"
		+"<td><strong>"+reqData.getReqStatusDesc()+"</strong></td>"
		+"</td><td><strong>"+toCamelCase(approverUser.getGivenNm()+" "+approverUser.getFmlyNm())+"</strong></td>"
		+"<td><strong>"+complFlg+"</strong></td></tr></tbody></table></div></br></br>";
		
		/*
		msg+="<style> table {border-collapse: collapse; width: 65%; } th, td { border: 1px solid; padding: 8px; } td { font-size: 14px; } </style>";
		msg+="<Table width='65%'>"
				+ "<tr>"
				+ 	"<th width='15%'><u>Request Creation Date</u></th><th width='10%'><u>Request ID</u></th><th width='20%'><u>Requestor</u></th><th width='20%'><u>Access Requested For</u></th>"
					+ "<th width='10%'><u>Request Type</u></th><th width='10%'><u>Status</u></th><th width='20%'><u>Compliance Review Performed By</u></th><th width='20%'><u>Compliance Risks/Flags Reviewed</u></th>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td align='center'><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td><td><strong>"+reqData.getReqid()+"</strong></td><td><strong>"
					+requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+"</strong></td><td><strong>"+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</strong></td><td><strong>"+reqData.getTypename()
					+"</strong></td><td><strong>"+reqData.getReqStatusDesc()+"</strong></td><td><strong>"+approverUser.getFmlyNm()+", "+approverUser.getGivenNm()+"</strong></td><td><strong>"+complFlg+"</strong></td>"
				+ "</tr>"
				
			+ "</Table>";
		msg+="</br></br>"; 
		*/
		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		msg1+=" <div class=\"section\" >You can check the details and the latest status of your Access Request by logging into EDAL:<br><br>"
				+ "<b><a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></b></br></br>";
		msg1+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		msg1+="<font face='Bookman Old Style'>Best Regards,<br/>";
		msg1+="<b>Enterprise Digital Abstraction Layer (EDAL)</b></font><br/>";
		msg1+="<font face='Bookman Old Style' color='Red'><b>Johnson & Johnson</b></font><br/>";
		msg1+="</br> "+confidentiality+"</div></body></html>";
		
		
		//msg+="You can check the details and the latest status of your Access Request by logging into EDAL:<br/><br/>";
		
		//msg+="<a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br>";
		//msg+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		//msg+="Best Regards,<br/>";
		//msg+="<b>Enterprise Digital Abstraction Layer (EDAL)</b><br/>";
		//msg+="<font face='Arial,Helvetica,sans-serif' color='Red' size='4' >Johnson & Johnson</font><br/>";
		
		//msg+="</br></br></br> "+confidentiality;

		getSession();
		MimeMessage mimeMessage = new MimeMessage(session);
		
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg1, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Approval Message sent for REQID: "+reqData.getReqid()+"....!");

	}
	public void sendAbsRequestPartialEmail(String subject, UserSearchModel assocUser, UserSearchModel requestorUser, UserSearchModel approverUser, AbsUserReqMdl reqData, List<UserAbsConflictMdl> confList, List<AbsSysLeveExcsvRestrMdl> excessiveApprovalList, Map<String, List<String>> emailMap ) throws Exception {
		String name = "";
		if (assocUser.getGivenNm().equals(requestorUser.getGivenNm()) && assocUser.getFmlyNm().equals(requestorUser.getFmlyNm())) {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm();
		}else {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm()+"/ "+assocUser.getGivenNm()+" "+assocUser.getFmlyNm();
		}
		subject =""+subject;
		String msg1 ="<html><head><style>body{font-family:'Bookman Old Style',serif;font-size:11pt;line-height:1.5;color:#000000}.section{font-family:'Bookman Old Style',serif;margin-top:10px;font-size:11pt}.section-heading{#font-weight:bold;margin-bottom:20px}.table{border-collapse:collapse;width:100%;text-align:center}.table th,.table td{border:1px solid #333;padding:8px;font-size:11pt;white-space: nowrap;text-overflow: ellipsis;overflow: hidden}.table th{font-weight:bold}.button{background-color:#0078D4;color:white;padding:8px 16px;text-decoration:none;border-radius:4px;font-weight:bold}.button:hover{background-color:#005D9D}</style></head>";
		msg1+= "<body><br><div class=\"section\"><span class=\"section-heading\">Dear "
		+toCamelCase(name)+",</span> <br><br>"
				+ "Your Access Request has been partially approved by the Compliance Manager within EDAL and will be submitted for further processing (only for the access approved) within the GRC/IAM systems. "
				+ "Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.<br><br> "
				+ "Please submit a new Access Request for the access rejected after resolving all identified compliance risks/concerns.</div>";
		/*String msg="<br/>Dear " +requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+",<br/><style>  p {margin: 0; padding: 0;  }</style><p>&nbsp;</p>"+
				 "Your Access Request has been partially approved by the Compliance Manager within EDAL and will be submitted for further processing (only for the access approved) within the GRC/IAM systems.<br/>"+
				 "Please check your inbox for updates or log into EDAL to check the latest status of your Access Request at any time.<br/><style>  p {margin: 0; padding: 0;  }</style><p>&nbsp;</p>"+
				 "Please submit a new Access Request for the access rejected after resolving all identified compliance risks/concerns."
				 + "<br/><br/>"; */
		//msg +="<b><u>Access Request Summary</u></b>:<br/><style>  p {margin: 0; padding: 0;   }</style><p>&nbsp;</p>";
		msg1+="<div class=\"section\"><span class=\"section-heading\"><b><u>Access Request Summary</u></b></span>:<br><br>";
		//Request Data
		//Compliance Flags
		String complFlg = "";
		String complFlgF = "";
		//if(excessiveApprovalList != null && !excessiveApprovalList.isEmpty()) {
			//complFlg+="• Restricted/Excessive Access (<font face='Arial,Helvetica,sans-serif' color='Red' size='3' >"+excessiveApprovalList.size()+"</font>)</br>";
			//complFlg+="Restricted Access</br>";
		//} 
		List<RoleADGrpMdl> selVarsRestrictedA = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		List<RoleADGrpMdl> selVarsRestrictedF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsRestricted().stream())
			    .filter(roleADGrpMdl -> "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		if(selVarsRestrictedA.size() >0) {
			complFlg+="Restricted Access<br/>";
		}
		if(selVarsRestrictedF.size() >0) {
			complFlgF +="Restricted Access<br/>";
		}
		
		List<RoleADGrpMdl> selVarsNonRestrictedA = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsNonRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		List<RoleADGrpMdl> selVarsNonRestrictedF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsNonRestricted().stream())
			    .filter(roleADGrpMdl -> "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		if(selVarsNonRestrictedA.size()>0) {
			complFlg+="Non Restricted Access<br/>";
		}
		if(selVarsNonRestrictedF.size() >0) {
			complFlgF +="Non Restricted Access<br/>";
		}
		//if(confList != null && !confList.isEmpty()) {
			//complFlg+= "• SOD Conflicts (<font face='Arial,Helvetica,sans-serif' color='Red' size='3' >"+confList.size()+"</font>)";
			//complFlg+= "SOD Conflicts";
		//}
		if(confList != null && !confList.isEmpty()) {
			List confRejLst = confList.stream().filter(e -> e.getAcceptDeny().contains("F")).collect(Collectors.toList());
			if(confRejLst.size() > 0)		
				complFlgF+= "SOD Conflicts<br/>";
			List confAccLst = confList.stream().filter(e -> e.getAcceptDeny().contains("A")).collect(Collectors.toList());
			if(confAccLst.size()>0) {
				complFlg+= "SOD Conflicts<br/>";
			}
		}
		msg1+="<table class=\"table\"><thead><tbody><tr><th><u>Request Creation Date</u></th><th><u>Request ID</u></th><th><u>Requestor</u></th>"
				+ "<th><u>Access Requested For</u></th><th><u>Request Type</u></th><th><u>Status</u></th><th><u>Compliance Review Performed By</u></th>"
				+ "<th><u>Compliance Risks/Flags Approved</u></th><th><u>Compliance Risks/Flags Rejected</u></th></tr></thead><tbody><tr>"
				+ "<td><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td>"
				+ "<td><strong>"+reqData.getReqid()+"</strong></td>"
				+ "<td><strong>"+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+"</strong></td>"
				+ "<td><strong>"+toCamelCase(assocUser.getGivenNm()+" "+assocUser.getFmlyNm())+"</strong></td>"
				//+ "<td><strong>"+reqData.getTypename()+"</strong></td>"
				+ "<td><strong>Add – Security Access</strong></td>"
				+"<td><strong>"+reqData.getReqStatusDesc()+"</strong></td>"
				+"</td><td><strong>"+toCamelCase(approverUser.getGivenNm()+" "+approverUser.getFmlyNm())+"</strong></td>"
				+"<td><strong>"+complFlg+"</strong></td>"
				+ "<td><strong>"+complFlgF+"<strong></td></tr></tbody></table></div></br></br>";
		/*
		msg+="<style> table {border-collapse: collapse; width: 65%; } th, td { border: 1px solid; padding: 8px; } td { font-size: 14px; } </style>";
		msg+="<Table width='65%'>"
				+ "<tr>"
				+ 	"<th width='15%'><u>Request Creation Date</u></th><th width='10%'><u>Request ID</u></th><th width='20%'><u>Requestor</u></th><th width='20%'><u>Access Requested For</u></th>"
					+ "<th width='10%'><u>Request Type</u></th><th width='10%'><u>Status</u></th><th width='20%'><u>Compliance Review Performed By</u></th><th width='20%'><u>Compliance Risks/Flags Approved</u></th><th width='20%'><u>Compliance Risks/Flags Rejected</u></th>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td align='center'><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"<strong></td><td><strong>"+reqData.getReqid()+"<strong></td><td><strong>"
					+requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+"<strong></td><td><strong>"+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"<strong></td><td><strong>"+reqData.getTypename()
					+"<strong></td><td><strong>"+reqData.getReqStatusDesc()+"<strong></td><td><strong>"+approverUser.getFmlyNm()+", "+approverUser.getGivenNm()+"<strong></td><td><strong>"+complFlg+"<strong></td><td><strong>"+complFlgF+"<strong></td>"
				+ "</tr>"
				
			+ "</Table>";
			*/
		//msg+="</br></br>";
		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		msg1+=" <div class=\"section\" >You can check the latest status of your Access Request including the details for approval/rejection by logging into EDAL:<br><br>"
				+ "<b><a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></b></br></br>";
		msg1+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		msg1+="<font face='Bookman Old Style'>Best Regards,<br/>";
		msg1+="<b>Enterprise Digital Abstraction Layer (EDAL)</b></font><br/>";
		msg1+="<font face='Bookman Old Style' color='Red'><b>Johnson & Johnson</b></font><br/>";
		msg1+="</br> "+confidentiality+"</div></body></html>";
		//msg+="You can check the latest status of your Access Request including the details for approval/rejection by logging into EDAL:<br/><br/>";
		//msg+="<a href='"+Utility.getServerProp("SERVER_URL")+"'> View Request </a></br></br></br>";
		//msg+="<a href='https://devsec.launchpad.cfapps.us10.hana.ondemand.com/ec0981f7-ea31-470c-a8f4-a5f3167f34bb.edaldevversion3.edalappdevversion2-0.0.1/index.html#/viewDetailRequest/"+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br></br>";
		//msg+="<a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br>";
		//msg+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		//msg+="Best Regards,<br/>";
		//msg+="<b>Enterprise Digital Abstraction Layer (EDAL)</b><br/>";
		//msg+="<font face='Arial,Helvetica,sans-serif' color='Red' size='4' >Johnson & Johnson</font><br/>";
		//Adding confidentiality message
		//msg+="</br></br></br> "+confidentiality;

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		//mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg1, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Approval Message sent for REQID: "+reqData.getReqid()+"....!");

	}
	
	public void sendAbsRequestAllRejectEmail(String subject, UserSearchModel assocUser, UserSearchModel requestorUser, UserSearchModel approverUser, AbsUserReqMdl reqData, List<UserAbsConflictMdl> confList, List<AbsSysLeveExcsvRestrMdl> excessiveApprovalList, Map<String, List<String>> emailMap ) throws Exception {
		String name = "";
		if (assocUser.getGivenNm().equals(requestorUser.getGivenNm()) && assocUser.getFmlyNm().equals(requestorUser.getFmlyNm())) {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm();
		}else {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm()+"/ "+assocUser.getGivenNm()+" "+assocUser.getFmlyNm();
		}
		subject =""+subject;
		String msg1 ="<html><head><style>body{font-family:'Bookman Old Style',serif;font-size:11pt;line-height:1.5;color:#000000}.section{font-family:'Bookman Old Style',serif;margin-top:10px;font-size:11pt}.section-heading{#font-weight:bold;margin-bottom:20px}.table{border-collapse:collapse;width:100%;text-align:center}.table th,.table td{border:1px solid #333;padding:8px;font-size:11pt;white-space: nowrap;text-overflow: ellipsis;overflow: hidden}.table th{font-weight:bold}.button{background-color:#0078D4;color:white;padding:8px 16px;text-decoration:none;border-radius:4px;font-weight:bold}.button:hover{background-color:#005D9D}</style></head>";
		msg1+= "<body><br><div class=\"section\"><span class=\"section-heading\">Dear "
				//+toCamelCase( requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+",</span> <br><br>"
				+toCamelCase(name)+",</span> <br><br>"
				+ "Your Access Request has been rejected by the Compliance Manager within EDAL due to compliance risks/concerns and will not be submitted for further processing. "				
				+ "Please submit a new Access Request after resolving all identified compliance risks/concerns</div>";
		msg1+="<div class=\"section\"><span class=\"section-heading\"><b><u>Access Request Summary</u></b></span>:<br><br>";
		/*String msg="<br/>Dear " +requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+",<br/><style>  p {margin: 0; padding: 0;   }</style><p>&nbsp;</p>"+
				"Your Access Request has been rejected by the Compliance Manager within EDAL due to compliance risks/concerns and will not be submitted for further processing.<br/>"+
				"Please submit a new Access Request after resolving all identified compliance risks/concerns.<br/><br/>";
		msg +="<b><u>Access Request Summary</u></b>:<br/><style>  p {margin: 0; padding: 0;   }</style><p>&nbsp;</p>";
		*/
		//Request Data
		//Compliance Flags
		String complFlg = "";
		//if(excessiveApprovalList != null && !excessiveApprovalList.isEmpty()) {
			//complFlg+="• Restricted/Excessive Access (<font face='Arial,Helvetica,sans-serif' color='Red' size='3' >"+excessiveApprovalList.size()+"</font>)</br>";
			//complFlg+="Restricted Access</br>";
		//}
		List<RoleADGrpMdl> selVarsRestrictedAorF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()) || "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		if(selVarsRestrictedAorF.size() >0) {
			complFlg+="Restricted Access</br>";
		}
		List<RoleADGrpMdl> selVarsNonRestrictedAorF = excessiveApprovalList.stream()
			    .flatMap(restExcsvMdl -> restExcsvMdl.getSelVarsNonRestricted().stream())
			    .filter(roleADGrpMdl -> "A".equals(roleADGrpMdl.getAcceptDeny()) || "F".equals(roleADGrpMdl.getAcceptDeny()))
			    .collect(Collectors.toList());
		
		if(selVarsNonRestrictedAorF.size() >0) {
			complFlg+="Non Restricted Access</br>";
		}


		if(confList != null && !confList.isEmpty()) {
			//complFlg+= "• SOD Conflicts (<font face='Arial,Helvetica,sans-serif' color='Red' size='3' >"+confList.size()+"</font>)";
			complFlg+= "SOD Conflicts";
		}
		msg1+="<table class=\"table\"><thead><tbody><tr><th><u>Request Creation Date</u></th><th><u>Request ID</u></th><th><u>Requestor</u></th>"
				+ "<th><u>Access Requested For</u></th><th><u>Request Type</u></th><th><u>Status</u></th><th><u>Compliance Review Performed By</u></th>"
				+ "<th><u>Compliance Risks/Flags Rejected</u></th></tr></thead><tbody><tr>"
				+ "<td><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td>"
				+ "<td><strong>"+reqData.getReqid()+"</strong></td>"
				+ "<td><strong>"+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+"</strong></td>"
				+ "<td><strong>"+toCamelCase(assocUser.getGivenNm()+" "+assocUser.getFmlyNm())+"</strong></td>"
				//+ "<td><strong>"+reqData.getTypename()+"</strong></td>"
				+ "<td><strong>Add – Security Access</strong></td>"
				+"<td><strong>"+reqData.getReqStatusDesc()+"</strong></td>"
				+"</td><td><strong>"+toCamelCase(approverUser.getGivenNm()+" "+approverUser.getFmlyNm())+"</strong></td>"
				+"<td><strong>"+complFlg+"</strong></td></tr></tbody></table></div></br></br>";
		/*msg+="<style> table {border-collapse: collapse; width: 65%; } th, td { border: 1px solid; padding: 8px; } td { font-size: 14px; } </style>";
		msg+="<Table width='65%'>"
				+ "<tr>"
				+ 	"<th width='15%'><u>Request Creation Date</u></th><th width='10%'><u>Request ID</u></th><th width='20%'><u>Requestor</u></th><th width='20%'><u>Access Requested For</u></th>"
					+ "<th width='10%'><u>Request Type</u></th><th width='10%'><u>Status</u></th><th width='20%'><u>Compliance Review Performed By</u></th><th width='20%'><u>Compliance Risks/Flags Rejected</u></th>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td align='center'><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td><td><strong>"+reqData.getReqid()+"</strong></td><td><strong>"
					+requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+"</strong></td><td><strong>"+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</strong></td><td><strong>"+reqData.getTypename()
					+"</strong></td><td><strong>"+reqData.getReqStatusDesc()+"</strong></td><td><strong>"+approverUser.getFmlyNm()+", "+approverUser.getGivenNm()+"</strong></td><td><strong>"+complFlg+"</strong></td>"
				+ "</tr>"
				
			+ "</Table>";
		msg+="</br></br>";*/
		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		//msg+="You can check the latest status of your Access Request including the details for rejection by logging into EDAL:<br/><br/>";
		//msg+="<a href='"+Utility.getServerProp("SERVER_URL")+"'> View Request </a></br></br></br>";
		//msg+="<a href='https://devsec.launchpad.cfapps.us10.hana.ondemand.com/ec0981f7-ea31-470c-a8f4-a5f3167f34bb.edaldevversion3.edalappdevversion2-0.0.1/index.html#/viewDetailRequest/"+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br></br>";
		msg1+=" <div class=\"section\" >You can check the latest status of your Access Request including the details for rejection by logging into EDAL:<br><br>"
				+ "<b><a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></b></br></br>";
		msg1+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		msg1+="<font face='Bookman Old Style'>Best Regards,<br/>";
		msg1+="<b>Enterprise Digital Abstraction Layer (EDAL)</b></font><br/>";
		msg1+="<font face='Bookman Old Style' color='Red'><b>Johnson & Johnson</b></font><br/>";
		msg1+="</br> "+confidentiality+"</div></body></html>";
		//msg+="<a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br>";
		//msg+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		//msg+="Best Regards,<br/>";
		//msg+="<b>Enterprise Digital Abstraction Layer (EDAL)</b><br/>";
		//msg+="<font face='Arial,Helvetica,sans-serif' color='Red' size='4' >Johnson & Johnson</font><br/>";
		//Adding confidentiality message
		//msg+="</br></br></br> "+confidentiality;

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		//mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg1, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Approval Message sent for REQID: "+reqData.getReqid()+"....!");

	}
	
	public void sendAbsCancelRequestApprovalEmail(String subject, UserSearchModel assocUser, UserSearchModel requestorUser, UserSearchModel approverUser, AbsUserReqMdl reqData,  Map<String, List<String>> emailMap, List<UserAbsConflictMdl> confList, List<RoleADGrpMdl> restRoles ) throws Exception {
		String name = "";
		if (assocUser.getGivenNm().equals(requestorUser.getGivenNm()) && assocUser.getFmlyNm().equals(requestorUser.getFmlyNm())) {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm();
		}else {
			name = requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm()+"/ "+assocUser.getGivenNm()+" "+assocUser.getFmlyNm();
		}
		subject =""+subject;
		String msg1 ="<html><head><style>body{font-family:'Bookman Old Style',serif;font-size:11pt;line-height:1.5;color:#000000}.section{font-family:'Bookman Old Style',serif;margin-top:10px;font-size:11pt}.section-heading{#font-weight:bold;margin-bottom:20px}.table{border-collapse:collapse;width:100%;text-align:center}.table th,.table td{border:1px solid #333;padding:8px;font-size:11pt;white-space: nowrap;text-overflow: ellipsis;overflow: hidden}.table th{font-weight:bold}.button{background-color:#0078D4;color:white;padding:8px 16px;text-decoration:none;border-radius:4px;font-weight:bold}.button:hover{background-color:#005D9D}</style></head>";
		msg1+= "<body><br><div class=\"section\"><span class=\"section-heading\">Dear "
				//+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+",</span> <br><br>"
				+toCamelCase(name)+",</span> <br><br>"
						+ "Your Access Request has been rejected by the Compliance Manager within EDAL due to compliance risks/concerns and will not be submitted for further processing. "						
						+ "Please submit a new Access Request after resolving all identified compliance risks/concerns.</div>";
		/*String msg="<br/>Dear " +requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+",<br/><style>  p {margin: 0; padding: 0;  }</style><p>&nbsp;</p>"+
				"Your Access Request has been rejected by the Compliance Manager within EDAL due to compliance risks/concerns and will not be submitted for further processing.<br/>"+
				"Please submit a new Access Request after resolving all identified compliance risks/concerns.<br/><br/>";
		msg +="<b><u>Access Request Summary</u></b>:<br/><style>  p {margin: 0; padding: 0;   }</style><p>&nbsp;</p>";*/
		msg1+="<div class=\"section\"><span class=\"section-heading\"><b><u>Access Request Summary</u></b></span>:<br><br>";
		//Request Data
		//Compliance Flags
		String complFlg = "";

		List<RoleADGrpMdl> resLst = restRoles.stream()
		        .filter(e -> "Yes".equalsIgnoreCase(e.getIsRestricted()))
		        .collect(Collectors.toList());
		if(resLst.size()>0) {
			complFlg+="Restricted Access</br>";
		}
		List<RoleADGrpMdl> nonResLst = restRoles.stream()
		        .filter(e -> "No".equalsIgnoreCase(e.getIsRestricted()))
		        .collect(Collectors.toList());
		if(nonResLst.size()>0) {
			complFlg+="Non Restricted Access</br>";
		}
			
		if(confList != null && !confList.isEmpty()) {			
			complFlg+= "SOD Conflicts";
		}
		
		msg1+="<table class=\"table\"><thead><tbody><tr><th><u>Request Creation Date</u></th><th><u>Request ID</u></th><th><u>Requestor</u></th>"
				+ "<th><u>Access Requested For</u></th><th><u>Request Type</u></th><th><u>Status</u></th><th><u>Compliance Review Performed By</u></th>"
				+ "<th><u>Compliance Risks/Flags Rejected</u></th></tr></thead><tbody><tr>"
				+ "<td><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td>"
				+ "<td><strong>"+reqData.getReqid()+"</strong></td>"
				+ "<td><strong>"+toCamelCase(requestorUser.getGivenNm()+" "+requestorUser.getFmlyNm())+"</strong></td>"
				+ "<td><strong>"+toCamelCase(assocUser.getGivenNm()+" "+assocUser.getFmlyNm())+"</strong></td>"
				//+ "<td><strong>"+reqData.getTypename()+"</strong></td>"
				+ "<td><strong>Add – Security Access</strong></td>"
				+"<td><strong>"+reqData.getReqStatusDesc()+"</strong></td>"
				+"</td><td><strong>"+toCamelCase(approverUser.getGivenNm()+" "+approverUser.getFmlyNm())+"</strong></td>"
				+"<td><strong>"+complFlg+"</strong></td></tr></tbody></table></div></br></br>";		
		/*msg+="<style> table {border-collapse: collapse; width: 65%; } th, td { border: 1px solid; padding: 8px; } td { font-size: 14px; } </style>";
		msg+="<Table width='65%'>"
				+ "<tr>"
				+ 	"<th width='15%'><u>Request Creation Date</u></th><th width='10%'><u>Request ID</u></th><th width='20%'><u>Requestor</u></th><th width='20%'><u>Access Requested For</u></th>"
					+ "<th width='10%'><u>Request Type</u></th><th width='10%'><u>Status</u></th><th width='20%'><u>Compliance Review Performed By</u></th><th width='20%'><u>Compliance Risks/Flags Rejected</u></th>"
				+ "</tr>"
				+ "<tr>"
				+ 	"<td align='center'><strong>"+Utility.fmtddMonYYYY((reqData.getRequestedon() == null)? new Date():reqData.getRequestedon())+"</strong></td><td><strong>"+reqData.getReqid()+"</strong></td><td><strong>"
					+requestorUser.getFmlyNm()+", "+requestorUser.getGivenNm()+"</strong></td><td><strong>"+assocUser.getFmlyNm()+", "+assocUser.getGivenNm()+"</strong></td><td><strong>"+reqData.getTypename()
					+"</strong></td><td><strong>"+reqData.getReqStatusDesc()+"</strong></td><td><strong>"+approverUser.getFmlyNm()+", "+approverUser.getGivenNm()+"</strong></td><td><strong>"+complFlg+"</strong></td>"
				+ "</tr>"
				
			+ "</Table>";
		msg+="</br></br>";*/
		String btpUrl = userMenuDao.getUtilsConstVals("BTP_API_URL");
		msg1+=" <div class=\"section\" >You can check the latest status of your Access Request including the details for rejection by logging into EDAL:<br><br>"
				+ "<b><a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></b></br></br>";
		msg1+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		msg1+="<font face='Bookman Old Style'>Best Regards,<br/>";
		msg1+="<b>Enterprise Digital Abstraction Layer (EDAL)</b></font><br/>";
		msg1+="<font face='Bookman Old Style' color='Red'><b>Johnson & Johnson</b></font><br/>";
		msg1+="</br> "+confidentiality+"</div></body></html>";
		//msg+="You can check the latest status of your Access Request including the details for rejection by logging into EDAL:<br/><br/>";
		//msg+="<a href='"+Utility.getServerProp("SERVER_URL")+"'> View Request </a></br></br></br>";
		//msg+="<a href='https://devsec.launchpad.cfapps.us10.hana.ondemand.com/ec0981f7-ea31-470c-a8f4-a5f3167f34bb.edaldevversion3.edalappdevversion2-0.0.1/index.html#/viewDetailRequest/"+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br></br>";
		//msg+="<a href='"+btpUrl+reqData.getReqid()+"/"+assocUser.getFmlyNm()+"%20"+assocUser.getGivenNm()+"'> View Request </a></br></br>";
		//msg+="Please reach out to the <a href='mailto:EDALProject@jnj.onmicrosoft.com'>EDAL Support Team<a> in case of any technical questions or concerns.<br/></br>";
		//msg+="Best Regards,<br/>";
		//msg+="<b>Enterprise Digital Abstraction Layer (EDAL)</b><br/>";
		//msg+="<font face='Arial,Helvetica,sans-serif' color='Red' size='4' >Johnson & Johnson</font><br/>";
		//Adding confidentiality message
		//msg+="</br></br></br> "+confidentiality;

		getSession();//Establish Session before sending
		MimeMessage mimeMessage = new MimeMessage(session);
		//mimeMessage.setFrom(new InternetAddress(env.getProperty("email.from")));
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		String toEmailstr = String.join(",", emailMap.get("TO"));
		String ccEmailstr = String.join(",", emailMap.get("CC"));
		InternetAddress[] recAddrTo = getRecipient(toEmailstr);
		InternetAddress[] recAddrCc = getRecipient(ccEmailstr);
		mimeMessage.setRecipients(Message.RecipientType.TO, recAddrTo);
		mimeMessage.setRecipients(Message.RecipientType.CC, recAddrCc);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(msg1, "text/html; charset=utf-8");
		Transport.send(mimeMessage);
		log.info("Approval Message sent for REQID: "+reqData.getReqid()+"....!");

	}
	

	public void sendReportGenerationConfirmation(String userEmailId, String subject, String message) throws Exception {
		log.info("Sending Email with subject: "+subject);
		getSession();		
		message = message+"<br><br>";
		message+=confidentiality;
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress("DoNotReply.EDALApplication@its.jnj.com"));
		InternetAddress[] recipientAddress = getRecipient(userEmailId);
		mimeMessage.setRecipients(Message.RecipientType.TO, recipientAddress);
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(message, "text/html; charset=utf-8");
		log.info("Status Email Sent.........!");
		Transport.send(mimeMessage);
	}




}
