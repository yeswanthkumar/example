package com.jnj.rqc.anaplan.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnaplanRespMdl {
	private Object meta ;
	private String status;
	private String statusMessage;
	private TokenInfo tokenInfo;
}
