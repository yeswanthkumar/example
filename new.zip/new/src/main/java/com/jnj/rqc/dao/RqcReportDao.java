package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.reportmodels.AppRoles;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.reportmodels.ReqLogModel;


/**
 * File    : <b>RqcReportDao.java</b>
 * @author : DChauras @Created : Feb 19, 2020 11:17:16 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface RqcReportDao {

	public List<ReportDataModel> getRqcReportData(String  startDt, String endDt ) throws SQLException, DataAccessException ;
	public List<AppRoles> getTktRoles(String[] ticketNo) throws SQLException, DataAccessException ;
	public List<AppRoles> getTktAppRoles(String[] ticketNo,  List<Integer> appIds) throws SQLException, DataAccessException ;
	public List<ReqLogModel> getTktReqLogs(String[] ticketNo) throws SQLException, DataAccessException ;




}
