package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.AppDataModel;



public interface ApplDataDao {

	public Map<String, List<AppDataModel>> queryAppsData(int tktNum)throws SQLException, DataAccessException;
	public List<AppDataModel> getApplicationDataList(int tktNum)throws SQLException, DataAccessException;


}
