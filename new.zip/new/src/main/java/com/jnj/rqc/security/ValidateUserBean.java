package com.jnj.rqc.security;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jnj.rqc.authenticate.UserValidationRequest;
import com.jnj.rqc.authenticate.UserValidationResponse;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;



/**
 * File    : <b>ValidateUserBean.java</b>
 * @author : DChauras @Created : Apr 26, 2021 8:52:28 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Component ("ValidateUserBean")
public class ValidateUserBean
{
	static final Logger log = LoggerFactory.getLogger(ValidateUserBean.class);

	private String ldapURL = "LDAP://jnjdir.jnj.com:3268";  // "eudir.jnj.com:3269"

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;

	public UserValidationResponse validateUserRequest(UserValidationRequest request )throws Exception
	{
		log.info("validateUserRequest : called");
		String userId = request.getUserId();
		String pass   = request.getPassword();
		log.info("validateUserRequest : userId :"+userId+" pass :"+pass);
		UserValidationResponse validResp = null;
		try {
			if(userId != null && !userId.isEmpty() && pass != null && !pass.isEmpty()){
				log.info("condition called");
				List<UserSearchModel> userLst = userSearchService.getUserData(1,userId, 0);
				if(userLst != null && !userLst.isEmpty()) {
					log.info("2nd condition called");
					UserSearchModel usr = userLst.get(0);
					if(!Utility.isEmpty(usr.getJnjSupvrWwId())) {
						log.info("3nd condition called");
						UserSearchModel mgrMdl = sAPExtrGaaDataService.getUserStatusJJEDS(usr.getJnjSupvrWwId(), 1);
						if(mgrMdl != null) {
							log.info("4th condition called");
							usr.setJnjSupvrName(mgrMdl.getFmlyNm()+" "+mgrMdl.getGivenNm());
							usr.setJnjSupvrEmail(mgrMdl.getJnjEmailAddrTxt());
						}
					}
					DirContext cntxt = getContext(usr.getJnjEmailAddrTxt(), pass);
					getUserDetail(usr.getJnjEmailAddrTxt(), cntxt);
					log.info("before UserValidationResponse email id received :"+usr.getJnjEmailAddrTxt());
					return new UserValidationResponse("success",usr.getJnjEmailAddrTxt());

				}else {
					log.info("else block UserValidationResponse ");
					return new UserValidationResponse( "error","email not found");
				}

			}
		} catch (Exception e) {
			throw new Exception(Constants.USER_AUTH_ERROR);
		}
		return validResp;
	}
	public void getUserDetail(String user, DirContext ctx) throws NamingException {
		log.info("getUserDetail method called");
	    try{
	        List<String> grpList=new ArrayList<>();
	    	SearchControls searchCtls = new SearchControls();
	        String searchBase = "dc=jnj,dc=com";
	        String returnedAtts[] = {"cn","memberOf"};
	        searchCtls.setReturningAttributes(returnedAtts);
	        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	        String searchFilter = "(&(objectclass=user)(mail="+user+"))";
	        NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
	        while (answer.hasMoreElements()) {
	            SearchResult sr =  answer.next();
	            Attributes attrs = sr.getAttributes();
	            if (attrs != null) {
	                try{
	                    String cn = attrs.get("cn").get().toString();
	                    log.info("USER : " + cn);
	                    NamingEnumeration<?> memberOf = attrs.get("memberOf").getAll();
	                    while (memberOf.hasMoreElements()) {
	                        String member =(String)memberOf.next();
	                        String userGroup = member.split(",")[0];
	        		        userGroup = userGroup.replaceAll("CN=", "").trim();
	        		        grpList.add(userGroup);
	        		        log.info(" User Group  :  "+userGroup);
	                    }
	                } catch (NullPointerException e) {
	                    System.out.println(e.getMessage());
	                }
	            }
	        }
	        log.info("getUserDetail end method called");
	        if(!grpList.isEmpty()) {
	        	//session.setAttribute(Constants.USER_GROUPS, grpList);
	        }
	    } catch (NamingException e) {
	        log.error(e.getMessage(), e);
	    } finally {
	        if(!ctx.equals(null))
	            ctx.close();
	      }
	}

	public boolean validateRequest(HttpServletRequest request )throws Exception
	{
		boolean result = false;
		HttpServletRequest req = request;
		HttpSession session = req.getSession(false);
		if(session!=null){
			try{
				session.invalidate();
			}catch(Exception e){}
		}
		//session = req.getSession(true);
		String userId = req.getParameter("ntId");
		String pass = req.getParameter("password");
		try {
			if(userId != null && !userId.isEmpty() && pass != null && !pass.isEmpty()){
				List<UserSearchModel> userLst = userSearchService.getUserData(1,userId, 0);
				if(userLst != null && !userLst.isEmpty()) {
					UserSearchModel usr = userLst.get(0);
					if(!Utility.isEmpty(usr.getJnjSupvrWwId())) {
						UserSearchModel mgrMdl = sAPExtrGaaDataService.getUserStatusJJEDS(usr.getJnjSupvrWwId(), 1);
						if(mgrMdl != null) {
							usr.setJnjSupvrName(mgrMdl.getFmlyNm()+" "+mgrMdl.getGivenNm());
							usr.setJnjSupvrEmail(mgrMdl.getJnjEmailAddrTxt());
						}
					}
					DirContext cntxt = getContext(usr.getJnjEmailAddrTxt(), pass);
					session=req.getSession(true);
					result = true;
					//getGroupMemberDetail(usr.getJnjEmailAddrTxt(), cntxt, session);
					getUserDetail(usr.getJnjEmailAddrTxt(), cntxt, session);
					session.setAttribute(Constants.AUTH_USER, usr);
					session.setAttribute(Constants.USER_VALIDATED, "Y");
					session.setAttribute("CSM_UNAM", usr.getJnjEmailAddrTxt());
					session.setAttribute("CSM_UPWD", pass);
				}else {
					request.setAttribute("error", Constants.USER_AUTH_ERROR);
				}
			}
		} catch (Exception e) {
			//session.setAttribute(Constants.USER_VALIDATED, "N");
			request.setAttribute("error", Constants.USER_AUTH_ERROR);
			throw new Exception(Constants.USER_AUTH_ERROR);
		}
		return result;
	}



	private DirContext getContext(String user, String passwd) throws NamingException {
	    Hashtable<String, String> env = new Hashtable<>();
	    env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
	    env.put(Context.PROVIDER_URL, ldapURL);
	    env.put(Context.SECURITY_AUTHENTICATION, "simple");
	    env.put(Context.SECURITY_PRINCIPAL, user);
	    env.put(Context.SECURITY_CREDENTIALS, passwd);
	    DirContext ctx = new InitialLdapContext(env, null);
	    return ctx;
	}


	public void getUserDetail(String user, DirContext ctx, HttpSession session) throws NamingException {
	    try{
	        List<String> grpList=new ArrayList<>();
	    	SearchControls searchCtls = new SearchControls();
	        String searchBase = "dc=jnj,dc=com";
	        String returnedAtts[] = {"cn","memberOf"};
	        searchCtls.setReturningAttributes(returnedAtts);
	        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	        String searchFilter = "(&(objectclass=user)(mail="+user+"))";
	        NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
	        while (answer.hasMoreElements()) {
	            SearchResult sr =  answer.next();
	            Attributes attrs = sr.getAttributes();
	            if (attrs != null) {
	                try{
	                    String cn = attrs.get("cn").get().toString();
	                    log.info("USER : " + cn);
	                    NamingEnumeration<?> memberOf = attrs.get("memberOf").getAll();
	                    while (memberOf.hasMoreElements()) {
	                        String member =(String)memberOf.next();
	                        String userGroup = member.split(",")[0];
	        		        userGroup = userGroup.replaceAll("CN=", "").trim();
	        		        grpList.add(userGroup);
	        		        log.info(" User Group  :  "+userGroup);
	                    }
	                } catch (NullPointerException e) {
	                    System.out.println(e.getMessage());
	                }
	            }
	        }
	        if(!grpList.isEmpty()) {
	        	session.setAttribute(Constants.USER_GROUPS, grpList);
	        }
	    } catch (NamingException e) {
	        log.error(e.getMessage(), e);
	    } finally {
	        if(!ctx.equals(null))
	            ctx.close();
	      }
	}


	public Map<String, List<GrpUsrDateMdl>> getGroupMemberDetail(String user, String pwd) throws NamingException {
	    Map<String, List<GrpUsrDateMdl>> adUserMap = new HashMap<>();
	    DirContext ctx = null;
		try{
	    	ctx = getContext(user, pwd);
	    	String searchBase = "dc=jnj,dc=com";
	        //String returnedAtts[] = {"cn","member"};
	        //String returnedAtts[] = {"cn","member", "memberof","sAMAccountName","primaryGroupToken","primaryGroupID","whenChanged", "whenCreated"};
	    	String returnedAtts[] = {"cn","member", "whenChanged", "whenCreated"};
	        SearchControls searchCtls = new SearchControls();
	        searchCtls.setReturningAttributes(returnedAtts);
	        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	        String searchFilter = "(&(objectCategory=group)(cn=JJC-Finance-Plan*))";
	      //String searchFilter = "(&(objectClass=group)(cn=JJC-Finance-Plan-IBP-Maintainer-ASPAC))";

	        NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
	        Date dayStart = Utility.atStartOfDay(new Date());
	        Date vldUpto = Utility.getValUptoDate();

	        while (answer.hasMoreElements()) {
	            SearchResult sr =  answer.next();
	            Attributes attrs = sr.getAttributes();
	            if (attrs != null) {
	            	Date modifiedDt = null;
	            	Date createdDt  = null;
	                try{
	                	String adGrpName = attrs.get("cn").get().toString();
	                	String createdDate = attrs.get("whencreated").get().toString();
	                	String changeDate = attrs.get("whenchanged").get().toString();
	                	log.info("AD GROUP : " + adGrpName+ "createdDate: "+createdDate+"  changeDate: "+changeDate);

	                	if(changeDate == null) {
	                		continue;
	                	}else {
	                		modifiedDt = Utility.ldapStrToDtUTCEST(changeDate);
	                		createdDt = Utility.ldapStrToDtUTCEST(createdDate);
	                		NamingEnumeration<?> memberOf = (attrs.get("member") != null)? attrs.get("member").getAll() : null;
		                    log.info("modifiedDt: "+modifiedDt+"  dayStart: "+dayStart);
		                    if(null != memberOf && memberOf.hasMoreElements() && null != modifiedDt && (modifiedDt.getTime() >= dayStart.getTime())) {
		                		List<GrpUsrDateMdl> userLst = null;
		                    	if(adUserMap.containsKey(adGrpName)) {
		                    		userLst = adUserMap.get(adGrpName);
		                    	}else {
		                    		userLst = new ArrayList<>();
		                    	}
		                    	while (memberOf.hasMoreElements()) {
			                        String member =(String)memberOf.next();
			                        if(member.indexOf("\\,") > 0) {
			                        	member = member.replace("\\,", "");
			                        }
			                        String userName = member.split(",")[0];
			                        userName = userName.replaceAll("CN=", "").trim();
			                        if(userName.indexOf("[") > 0) {
		        		        		userName = userName.substring(0, (userName.indexOf("[")-1));
		        		        	}
			                        userName = userName.trim();
			        		        GrpUsrDateMdl grpMdl = new GrpUsrDateMdl();
			        		        grpMdl.setAdgroup(adGrpName);
			        		        grpMdl.setUserId(userName);
			        		        grpMdl.setModDate(modifiedDt);
			        		        grpMdl.setVldFrom(modifiedDt);
			        		        grpMdl.setVldTo(vldUpto);
			        		        UserSearchModel srchUsr = null;
			        		        log.info(" Received User ID  :  "+userName);
			        		        if(userName.split(" ").length > 1) {
			        		        	String flcombo = formatName(userName.split(" "));
			        		        	String fName = flcombo.split("~")[0];
			        		        	String lName = flcombo.split("~")[1];
			        		        	srchUsr = sAPExtrGaaDataService.getUserStatusJJEDSByFnLn(fName, lName, 0);
			        		        }else {
			        		        	log.info(" User ID  :  "+userName);
			        		        	srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(userName, 0);
			        		        }

			        		        if(srchUsr != null) {
			        		        	if(!("INVALID".equals(srchUsr.getEmpStatTxt()) || "INACTIVE".equals(srchUsr.getEmpStatTxt()) || "TERMINATED".equals(srchUsr.getEmpStatTxt()))) {
			        		        		grpMdl.setFName(srchUsr.getGivenNm());
				        		        	grpMdl.setLName(srchUsr.getFmlyNm());
				        		        	grpMdl.setEmailId(srchUsr.getJnjEmailAddrTxt());
				        		        	grpMdl.setEmpStatus(srchUsr.getEmpStatTxt());
				        		        	grpMdl.setWwid(srchUsr.getWwId());
				        		        	userLst.add(grpMdl);
			        		        	}else {
			        		        		log.error("INVALID Member ID :"+userName+" for Group: "+adGrpName+"  Date modified :"+modifiedDt);
			        		        	}
			        		        }else {
			        		        	log.error("INVALID Member ID :"+userName+" for Group: "+adGrpName+"  Date modified :"+modifiedDt);
			        		        }
			        		     }
		                    	adUserMap.put(adGrpName, userLst);
		                    	/*if(adUserMap.size() > 2) {
		                    		break;
		                    	}*/
		                    }
	                	}
	                } catch (NullPointerException e) {
	                	log.error(e.getMessage());
	                }
	            }
	        }
	    } catch (NamingException e) {
	        log.error(e.getMessage(), e);
	    } finally {
	        if(!ctx.equals(null))
	            ctx.close();
	    }

		return adUserMap;
	}


	public String formatName(String[] usrArr) {
		String fName = usrArr[(usrArr.length - 1)];
		String lName="";
		for(int i=0;i<(usrArr.length - 1); i++) {
			if("".equals(lName)) {
				lName = usrArr[i];
			}else {
				lName += " "+usrArr[i];
			}
		}
		return fName+"~"+lName;
	}


	public Map<String, List<GrpUsrDateMdl>> getMemberDetailByGroup(String user, String pwd) throws NamingException {
	    Map<String, List<GrpUsrDateMdl>> adUserMap = new HashMap<>();
	    DirContext ctx = null;
		try{
	    	ctx = getContext(user, pwd);
	    	String searchBase = "dc=jnj,dc=com";
	        String returnedAtts[] = {"cn","member", "whenChanged", "whenCreated"};
	        SearchControls searchCtls = new SearchControls();
	        searchCtls.setReturningAttributes(returnedAtts);
	        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	        String searchFilter = "(&(objectCategory=group)(cn=JJC-Finance-Plan*))";

	        NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
	        Date dayStart = Utility.atStartOfDay(new Date());
	        Date vldUpto = Utility.getValUptoDate();

	        while (answer.hasMoreElements()) {
	            SearchResult sr =  answer.next();
	            Attributes attrs = sr.getAttributes();
	            if (attrs != null) {
	            	Date modifiedDt = null;
	            	Date createdDt  = null;
	                try{
	                	String adGrpName = attrs.get("cn").get().toString();
	                	String createdDate = attrs.get("whencreated").get().toString();
	                	String changeDate = attrs.get("whenchanged").get().toString();
	                	log.info("AD GROUP : " + adGrpName+ "createdDate: "+createdDate+"  changeDate: "+changeDate);

	                	if(changeDate == null) {
	                		continue;
	                	}else {
	                		modifiedDt = Utility.ldapStrToDtUTCEST(changeDate);
	                		createdDt = Utility.ldapStrToDtUTCEST(createdDate);
	                		NamingEnumeration<?> memberOf = (attrs.get("member") != null)? attrs.get("member").getAll() : null;
		                    log.info("modifiedDt: "+modifiedDt+"  dayStart: "+dayStart);
		                    if(null != memberOf && memberOf.hasMoreElements() && null != modifiedDt && (modifiedDt.getTime() >= dayStart.getTime())) {
		                    	List<GrpUsrDateMdl> userLst = null;
		                    	if(adUserMap.containsKey(adGrpName)) {
		                    		userLst = adUserMap.get(adGrpName);
		                    	}else {
		                    		userLst = new ArrayList<>();
		                    	}
		                    	while (memberOf.hasMoreElements()) {
			                        String member =(String)memberOf.next();
			                        if(member.indexOf("\\,") > 0) {
			                        	member = member.replace("\\,", "");
			                        }
			                        String userName = member.split(",")[0];
			                        userName = userName.replaceAll("CN=", "").trim();
			                        if(userName.indexOf("[") > 0) {
		        		        		userName = userName.substring(0, (userName.indexOf("[")-1));
		        		        	}
			                        userName = userName.trim();
			        		        GrpUsrDateMdl grpMdl = new GrpUsrDateMdl();
			        		        grpMdl.setAdgroup(adGrpName);
			        		        grpMdl.setUserId(userName);
			        		        grpMdl.setModDate(modifiedDt);
			        		        grpMdl.setVldFrom(modifiedDt);
			        		        grpMdl.setVldTo(vldUpto);
			        		        UserSearchModel srchUsr = null;
			        		        log.info(" Received User ID  :  "+userName);
			        		        if(userName.split(" ").length > 1) {
			        		        	String flcombo = formatName(userName.split(" "));
			        		        	String fName = flcombo.split("~")[0];
			        		        	String lName = flcombo.split("~")[1];
			        		        	srchUsr = sAPExtrGaaDataService.getUserStatusJJEDSByFnLn(fName, lName, 0);
			        		        }else {
			        		        	log.info(" User ID  :  "+userName);
			        		        	srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(userName, 0);
			        		        }

			        		        if(srchUsr != null) {
			        		        	if(!("INVALID".equals(srchUsr.getEmpStatTxt()) || "INACTIVE".equals(srchUsr.getEmpStatTxt()) || "TERMINATED".equals(srchUsr.getEmpStatTxt()))) {
			        		        		grpMdl.setFName(srchUsr.getGivenNm());
				        		        	grpMdl.setLName(srchUsr.getFmlyNm());
				        		        	grpMdl.setEmailId(srchUsr.getJnjEmailAddrTxt());
				        		        	grpMdl.setEmpStatus(srchUsr.getEmpStatTxt());
				        		        	grpMdl.setWwid(srchUsr.getWwId());
				        		        	userLst.add(grpMdl);
			        		        	}else {
			        		        		log.error("INVALID Member ID :"+userName+" for Group: "+adGrpName+"  Date modified :"+modifiedDt);
			        		        	}
			        		        }else {
			        		        	log.error("INVALID Member ID :"+userName+" for Group: "+adGrpName+"  Date modified :"+modifiedDt);
			        		        }
			        		     }
		                    	adUserMap.put(adGrpName, userLst);
		                    }
	                	}
	                } catch (NullPointerException e) {
	                	log.error(e.getMessage());
	                }
	            }
	        }
	    } catch (NamingException e) {
	        log.error(e.getMessage(), e);
	    } finally {
	        if(!ctx.equals(null))
	            ctx.close();
	    }

		return adUserMap;
	}




	/*public String[] generateRangeArray(int i) {
	    String range = "member;range=" + i * 1500 + "-" + ((i + 1) * 1500 - 1);
	    String[] returnedAtts = { range };
	    return returnedAtts;
	}

	public String generateRangeString(int i) {
	    String range = "member;range=" + i * 1500 + "-" + ((i + 1) * 1500 - 1);
	    return range;
	}
	*/

//
/*if(srchUsr != null) {
	grpMdl.setFName(srchUsr.getGivenNm());
	grpMdl.setLName(srchUsr.getFmlyNm());
	grpMdl.setEmailId(srchUsr.getJnjEmailAddrTxt());
	grpMdl.setEmpStatus(srchUsr.getEmpStatTxt());
	grpMdl.setWwid(srchUsr.getWwId());
}else {
	log.error("INVALID Member ID :"+userName+" for Group: "+adGrpName+"  Date modified :"+modifiedDt);
	String[] ldapName = userName.split(" ");
	if(ldapName.length > 1) {
		String flcombo = formatName(ldapName);
		grpMdl.setFName(flcombo.split("~")[0]);
    	grpMdl.setLName(flcombo.split("~")[1]);
	}else {
		grpMdl.setFName(ldapName[0]);
    	grpMdl.setLName(ldapName[0]);
	}
	grpMdl.setEmailId("NA");
	grpMdl.setEmpStatus("INVALID/NOT FOUND");
	grpMdl.setWwid("");
}
userLst.add(grpMdl);
*/






}
