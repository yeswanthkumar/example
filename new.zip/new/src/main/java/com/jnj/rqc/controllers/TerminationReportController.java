package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.service.TerminationReportService;
import com.jnj.rqc.terminations.models.TerminationModel;


@Controller
public class TerminationReportController {
	static final Logger log = LoggerFactory.getLogger(TerminationReportController.class);

	@Autowired
	private TerminationReportService terminationReportService;

	@GetMapping("/uploadTermData")
    public String gotoUploadPage(Model model) {
    	log.info("Routing to Termination report Upload page.");
    	return "userreview/termuploadpage";
    }


	@PostMapping("/uploadTerminationData")
    public String loadNagsTermData(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Selected Termination file :"+file.getOriginalFilename());
    	if (file.isEmpty()) {
    		log.info("FILE is empty/missing.");
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("error", "Status: Excel file is missing/empty!");
            return "redirect:uploadTerminationStatus";
        }

    	String ext =file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("error", "Status: Not a valid excel file!");
            return "redirect:uploadTerminationStatus";
    	}

    	try{
    		String path = terminationReportService.saveFile(file);
    		List<TerminationModel> result = terminationReportService.processTerminationReport(path, request);
    		HttpSession session = request.getSession();
    		session.removeAttribute("TERMINATIONDATA");
    		session.setAttribute("TERMINATIONDATA", result);
    		String filePath = terminationReportService.writeTerminationCSVReview("XLS", result);
    		redirectAttributes.addFlashAttribute("result", result);
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("success", "Status: Successfully Processed file - " + file.getOriginalFilename());
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "redirect:/uploadTerminationStatus";
    }


	@GetMapping("/uploadTerminationStatus")
    public String uploadStatus(Model model) {
    	return "userreview/termuploadpage";
    }

	@ResponseBody
    @GetMapping("/downloadTermExcel")
    public ResponseEntity<InputStreamResource> downloadTermExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		List<TerminationModel> result = (List<TerminationModel>)request.getSession().getAttribute("TERMINATIONDATA");
    	String filePath = terminationReportService.writeTerminationCSVReview("XLS", result);

    	log.info("Starting download CSV file :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@SuppressWarnings("all")
    @ResponseBody
    @GetMapping("/downloadTermPdf")
    public ResponseEntity<InputStreamResource> downloadPdf(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<TerminationModel> result = (List<TerminationModel>)request.getSession().getAttribute("TERMINATIONDATA");
    	int mon = (Integer)request.getSession().getAttribute("MON");
    	int yrs = (Integer)request.getSession().getAttribute("YRS");
    	String filePath = terminationReportService.writeTerminationCSVReview("PDF", result);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.APPLICATION_PDF)
        	.contentLength(fl.length())
        	.body(resource);
    }



}
