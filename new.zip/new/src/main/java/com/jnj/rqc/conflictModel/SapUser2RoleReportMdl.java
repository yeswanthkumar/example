package com.jnj.rqc.conflictModel;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapUser2RoleReportMdl {
	private String 	reviewName;
	private String 	groupPlatform;
	private String 	groupDescription;
	private String 	groupShortName;
	private String  group_other_2;
	private String  group_other_3;
	private String  accountName;
	private String  accountOwnerName;
	private String  accountOwnerTitle;
	private String  accountOwnerUserId;
	private String  accountOwnerUserName;
	private String  accountOwnerEmail;
	private String  accountOwnerMrc;
	private String  accountOwnerDepartment;
	private String  groupType;
	private String  designatedReviewer;
	private String  designatedReviewerWwid;
	private String  reviewedByName;
	private String  reviewedByWwid;
	private String  reviewStatus;
	private String  reviewerComments;
	private Date 	dateEntered;

	public String getData() {
		return reviewName + "~" + groupDescription	+ "~" + groupShortName + "~" + group_other_2 + "~" + group_other_3 + "~" + accountName + "~" + accountOwnerName + "~"
				+ accountOwnerTitle + "~" + accountOwnerUserId + "~" + accountOwnerUserName + "~" + accountOwnerEmail + "~"	+ accountOwnerMrc + "~" + accountOwnerDepartment +
				"~" + groupType	+ "~" + designatedReviewer + "~" + designatedReviewerWwid + "~" + reviewedByName + "~" + reviewedByWwid + "~"
				+ reviewStatus + "~" + reviewerComments + "~" + (dateEntered != null? Utility.fmtMMDDYYYY(dateEntered):"") ;
	}


	@Override
	public String toString() {
		return "SapUser2RoleReportMdl [reviewName=" + reviewName + ", groupDescription=" + groupDescription
				+ ", groupShortName=" + groupShortName + ", groupOther2=" + group_other_2 + ", groupOther3=" + group_other_3
				+ ", accountName=" + accountName + ", accountOwnerName=" + accountOwnerName + ", accountOwnerTitle="
				+ accountOwnerTitle + ", accountOwnerUserId=" + accountOwnerUserId + ", accountOwnerUserName="
				+ accountOwnerUserName + ", accountOwnerEmail=" + accountOwnerEmail + ", accountOwnerMrc="
				+ accountOwnerMrc + ", accountOwnerDepartment=" + accountOwnerDepartment + ", groupType=" + groupType
				+ ", designatedReviewer=" + designatedReviewer + ", designatedReviewerWwid=" + designatedReviewerWwid
				+ ", reviewedByName=" + reviewedByName + ", reviewedByWwid=" + reviewedByWwid + ", reviewStatus="
				+ reviewStatus + ", reviewerComments=" + reviewerComments + ", dateEntered=" + dateEntered + "]";
	}





}

