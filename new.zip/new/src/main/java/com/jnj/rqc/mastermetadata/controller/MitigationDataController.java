package com.jnj.rqc.mastermetadata.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.mastermetadata.dao.MitigationListData;
import com.jnj.rqc.mastermetadata.service.ApiResponse;
import com.jnj.rqc.mastermetadata.service.MitigationDataService;


@RestController
@RequestMapping("/v2/api/mitigationdata")
public class MitigationDataController {
	static final Logger log = LoggerFactory.getLogger(MitigationDataController.class);
    private final MitigationDataService mitigtionDataService;

    @Autowired
    public MitigationDataController(MitigationDataService mitigtionDataService) {
        this.mitigtionDataService = mitigtionDataService;
    }

    @PostMapping("/insert")
    public ResponseEntity<ApiResponse> insertMasterData(@RequestBody MitigationListData mitigationListData) {
    	log.debug("enter into the method");
        try {
            if (mitigationListData != null && mitigationListData.getRecords() != null && !mitigationListData.getRecords().isEmpty()) {
            	log.info("values received as inputData :"+mitigationListData.getRecords().toString());
            	mitigtionDataService.insertMultipleRecords(mitigationListData.getRecords());
            	 log.debug("end of the method");
            	 ApiResponse response = new ApiResponse(true, "Records inserted successfully.");
            	 return ResponseEntity.status(HttpStatus.CREATED).body(response);
            } else {
            	ApiResponse response = new ApiResponse(false, "No records provided.");
            	return ResponseEntity.status(HttpStatus.CREATED).body(response);
            }

        } catch (Exception e) {
        	log.error("Excepiton : "+e.getMessage());
        	ApiResponse response = new ApiResponse(false, "Error inserting records.");
        	return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
    }
    @DeleteMapping("/delete/all")
    public ResponseEntity<String> deleteAllRows(@RequestBody MitigationListData mitigationListData) {
    	log.debug("enter into the method");
        try {
        	mitigtionDataService.deleteAllRows(mitigationListData.getRecords());
        	log.debug("end of the method");
            return ResponseEntity.ok("All rows deleted successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting all rows.");
        }

    }
    
    @GetMapping("/fetch/all")
    public ResponseEntity<MitigationDataDTO> fetchMitigationData() {
        log.debug("enter into the method");
        MitigationDataDTO reportDTO = new MitigationDataDTO();
        try {
            reportDTO = mitigtionDataService.getAllMitigationData();
            if (reportDTO.getStatusCode() == 200) {
               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
            } else if (reportDTO.getStatusCode() == 500) {
                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
            }	            
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }	        
    }      
}
