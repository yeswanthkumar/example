package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.SchAdminModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;


/**
 * File    : <b>SAPExtrRegionWiseService.java</b>
 * @author : DChauras @Created : May 10, 2021 11:31:57 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface SAPExtrRegionWiseService {
	public List<SchAdminModel> getAllActiveSchedulers();//Getting information on all active Schedulres

	public Map<String, List<TrfCntrlSchModel>> getTrfCntlRegionSchedule(String region);
	public List<TrfCntrlSchModel> getCurrentTrfSchedule(String region, String status, String sType);

	public boolean saveScheduleTrfContol(String region, UserSearchModel curUser, String sType);

	public int updateTrnferSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType);

	public String sendProcessEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc);


	/**
	 * Method  : SAPExtrRegionWiseService.java.getAllTrfCntlScheduls()
	 *		   :<b>@param regions
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 17, 2021 2:19:26 PM
	 * Purpose :  Get Shedules for All Regions supplied
	 * @return : List<TrfCntrlSchModel>
	 */
	public List<TrfCntrlSchModel> getAllTrfCntlScheduls(List<String> regions);


		/**
		 * Method  : SAPExtrRegionWiseService.java.allowRegionsForTrfSch()
		 *		   :<b>@param regNames
		 *		   :<b>@param schList
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 17, 2021 3:15:45 PM
		 * Purpose : Method to Check existing Schedules and Prevent Duplicate Scheduling(Unless Data Archived)
		 * @return : List<String>
		 */
	public List<String> allowRegionsForSch(List<String> regNames, List<TrfCntrlSchModel> schList);

	public List<TrfCntrlSummaryMdl> getTransferSummary();
	public int getExistingScheduleCount(String region, String sType, String dataType);
	public int getExistingU2SSchCount(String region, String sType, String dataType);


	/*   USER TO ROLE  */
	public List<TrfCntrlSchModel> getCurrentUser2RoleSchedule(String region, String status, String sType);
	public int updateUser2RoleSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType);
	public List<TrfCntrlSchModel> getAllUser2RoleScheduls(List<String> regions);
	public List<TrfCntrlSummaryMdl> getUser2RoleSummary();
	public boolean saveScheduleUser2Role(String region, UserSearchModel curUser, String sType);

	public List<SAPTrfCntrlSummaryMdl> getRawDataSummary(String regId);


	//Delete ROWS
	public int deleteTrfTransData(String region, String platform, String env, String sysm);
	public int deleteUser2RoleTransData(String region, String platform, String env, String sysm);
	public int deleteUser2SodTransData(String region, String platform, String env, String sysm);

	public String sendUser2RoleEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc);
	//NEW EMAIL FORMAT
	public String sendUser2RoleCompleteDataEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc);

	//CRITICAL ROLES
	public Map<String, String> loadAllCriticalRoles();
	public List<TrfCntrlSchModel> getExistingCriticalSchedules(String region, String sType);
	public int delUser2CriticalRoleTransData(String region, String platform, String env, String sysm);
	public List<TrfCntrlSchModel> getAllUser2CriticalRoleScheduls(List<String> regions);
	public List<TrfCntrlSummaryMdl> getUser2CriticalRoleSummary();
	public boolean saveScheduleUser2CriticalRole(String region, UserSearchModel curUser, String sType);
	public List<TrfCntrlSchModel> getCurrentUser2CriticalRoleSchedule(String region, String status, String sType);
	public int updateUser2CriticalRoleSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType);
	public String sendUser2CriticalRoleEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType);
	public List<TrfCntrlSchModel> getExistingTRForU2RSchedules(String region, String sType, String process);

	//USER2SOD
	public List<TrfCntrlSchModel> getAllUser2SodScheduls(List<String> regions);
	public List<TrfCntrlSummaryMdl> getUser2SodSummary();
	public List<TrfCntrlSchModel> getExistingU2SSchedules(String region, String sType);
	public boolean saveScheduleUser2Sod(String region, UserSearchModel curUser, String type);
	public List<TrfCntrlSchModel> getCurrentUser2SodSchedule(String region, String status, String sType);
	public int updateUser2SodSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType);
	public String sendUser2SodEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType);




}
