package com.jnj.rqc.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jnj.rqc.models.AppDataModel;
import com.jnj.rqc.service.ApplDataService;


@Controller
public class ApplDataController {
	static final Logger log = LoggerFactory.getLogger(ApplDataController.class);

	@Autowired
	ApplDataService applDataService;

	 @GetMapping("/getAppList/{tktNum}")
	 @ResponseBody
	 public Map<String, List<AppDataModel>> getApps(@PathVariable Integer tktNum, Model model, HttpServletRequest req) {
		 log.info("Recd Ticket number: "+tktNum);
		 log.info("USER :"+System.getProperty("user.name"));

		 if(null==tktNum)tktNum =1; //220287;
		 String user = System.getProperty("user.name");
		 Map<String, List<AppDataModel>> allAppMap = applDataService.getApplicationData(tktNum);

		 model.addAttribute("User", user);
		 model.addAttribute("appMap", allAppMap);

		 return allAppMap ;  //"userreview/nagsupload";
    }



}
