package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSISodRiskModel {

	private String application;
	private String source;
	private String domain;
	private String bussPurpose;
	private String riskId;
	private String funcId1;
	private String funcDesc1;
	private String funcId2;
	private String funcDesc2;
	private String funcId3;
	private String funcDesc3;
	private String shrtDescRisk;
	private String longDescRisk;
	private String riskLevel;
	private String regulation;
	private String status;
	private String changeCmnt;

	@Override
	public String toString() {
		return "CSISodRiskModel [application=" + application + ", source=" + source + ", domain=" + domain
				+ ", bussPurpose=" + bussPurpose + ", riskId=" + riskId + ", funcId1=" + funcId1 + ", funcDesc1="
				+ funcDesc1 + ", funcId2=" + funcId2 + ", funcDesc2=" + funcDesc2 + ", funcId3=" + funcId3
				+ ", funcDesc3=" + funcDesc3 + ", shrtDescRisk=" + shrtDescRisk + ", longDescRisk=" + longDescRisk
				+ ", riskLevel=" + riskLevel + ", regulation=" + regulation + ", status=" + status + ", changeCmnt="
				+ changeCmnt + "]";
	}



	public String getData() {
		return application + "~" + source + "~" + domain + "~" + bussPurpose + "~" + riskId + "~" + funcId1 + "~"
				+ funcDesc1 + "~" + funcId2 + "~" + funcDesc2 + "~" + funcId3 + "~" + funcDesc3 + "~" + shrtDescRisk
				+ "~" + longDescRisk + "~" + riskLevel + "~" + regulation + "~" + status + "~" + changeCmnt;
	}







}
