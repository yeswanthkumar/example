package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PersonalSysModel {
	private int 	wwid;
	private String 	userId;
	private String 	firstName;
	private String 	lastName;
	private String 	userType;
	private int 	code;
	private String 	role;
	private String 	co;
	private String 	srcSystem;
	private String 	job;
	private String 	waivers;





	public String getData() {
		return  wwid + "~" + userId + "~" + firstName + "~" + lastName + "~"+ code + "~" +  role + "~" + co + "~" + srcSystem + "~" + userType + "~" + job + "~"+waivers ;
	}





	@Override
	public String toString() {
		return "PersonalSysModel [wwid=" + wwid + ", userId=" + userId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", userType=" + userType + ", code=" + code + ", role=" + role + ", co=" + co
				+ ", srcSystem=" + srcSystem + ", job=" + job + ", waivers=" + waivers + "]";
	}

}
