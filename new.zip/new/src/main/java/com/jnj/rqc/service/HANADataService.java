package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.HanaDBRiskModel;
import com.jnj.rqc.conflictModel.HanaRole2SodModel;
import com.jnj.rqc.conflictModel.HanaUser2SodModel;
import com.jnj.rqc.conflictModel.HanaUserPrivilegeModel;
import com.jnj.rqc.conflictModel.HanaUserRoleModel;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.dbextr.models.TableRespDto;





/**
 * File    : <b>HANADataService.java</b>
 * @author : DChauras @Created : Dec 24, 2020 2:44:55 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface HANADataService {

	public Map<String, List<HanaUser2SodModel>> readHanaUserData(String empId, String riskLevel, String templSysParam, String newRoles);

	public Map<String, HanaUserRoleModel> readUserGrantData(String templSysParam);
	public Map<String, HanaDBRiskModel> getHanaDBRiskData(String riskIdFilter);
	public String writeHanaUser2SodCsvReport(List<HanaUser2SodModel> data, String fileName);
	public Map<String, List<HanaUserPrivilegeModel>> readRolePrivilegeData(String templSysParam);
	public List<HanaRole2SodModel> readHanaRolesData(String roleNames, String riskLevel, String templSysParam);
	public String writeHanaRole2SodCsvReport(List<HanaRole2SodModel> data, String fileName);
	public TableRespDto getEnvData(String propName);
	public Map<String, List<HanaUserPrivilegeModel>> readNewRolesData(String newRoles, String templSysParam);
	public Map<String, List<HanaUserPrivilegeModel>> readUserDirectAssignmentData(String templSysParam) ;
	public String writeHanaConflictMatrixCsvReport(List<HanaDBRiskModel> data, String fileName);
	//Transfer Control
	public List<SAPUserAccessModel> readUserTrfContrlData(String templSysParam);
	public String writeJdeUserAccessCSV(List<SAPUserAccessModel> data, String fileName);

	public List<SapGaaUser2RoleModel> readHanaUserGrantData(String templSysParam, String calledBy);//Method Desinged for Genesis Data
	public List<SapGaaUser2RoleModel> readHanaUserGrantActData(String templSysParam);//Method designed to seperate Invalid Data from Active/Transfer

	public List<SapGaaUser2RoleModel> readHanaUserGrantDispData(String templSysParam, String calledBy);

	/*public List<HanaDBRiskModel> getHanaDBRiskData(String riskIdFilter);
	public List<CSISodRiskModel> readSodRiskData(String path);

	*/



}
