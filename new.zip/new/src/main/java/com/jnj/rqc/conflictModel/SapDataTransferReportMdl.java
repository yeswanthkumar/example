package com.jnj.rqc.conflictModel;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapDataTransferReportMdl {
	private String 	reviewName;
	private String 	sapPlatfrom;
	private String 	sapSystem;
	private String 	groupDescription;
	private String  accountName;
	private String  accountOwner;
	private String  accountOwnerWwid;
	private String  accountOwnerTitle;
	private String  designatedReviewer;
	private String  designatedReviewerWwid;
	private String  reviewedByName;
	private String  reviewedByWwid;
	private Date 	creationDate;
	private Date 	dateReviewed;
	private String  reviewStatus;
	private Date 	dateEntered;

	public String getData() {
		return reviewName+"~"+sapPlatfrom+"~"+sapSystem+"~"+groupDescription+"~"+accountName+"~"+accountOwner+"~"+accountOwnerWwid+"~"+accountOwnerTitle+"~"
				+designatedReviewer+"~"+designatedReviewerWwid+"~"+reviewedByName+"~"+reviewedByWwid+"~"
				+(creationDate !=null? Utility.fmtMMDDYYYY(creationDate):"")
				+"~"+(dateReviewed !=null? Utility.fmtMMDDYYYY(dateReviewed):"")
				+"~"+reviewStatus+"~"+(dateEntered != null? Utility.fmtMMDDYYYY(dateEntered):"");
	}

	@Override
	public String toString() {
		return "SapDataTransferReportMdl [reviewName=" + reviewName + ", sapPlatform=" + sapPlatfrom + ", sapSystem="
				+ sapSystem + ", groupDescription=" + groupDescription + ", accountName=" + accountName
				+ ", accountOwner=" + accountOwner + ", accountOwnerWwid=" + accountOwnerWwid + ", accountOwnerTitle="
				+ accountOwnerTitle + ", designatedReviewer=" + designatedReviewer + ", designatedReviewerWwid="
				+ designatedReviewerWwid + ", reviewedByName=" + reviewedByName + ", reviewedByWwid=" + reviewedByWwid
				+ ", creationDate=" + creationDate + ", dateReviewed=" + dateReviewed + ", reviewStatus=" + reviewStatus
				+ ", dateEntered=" + dateEntered + "]";
	}




}
