package com.jnj.rqc.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.U2REmailLogMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;



/**
 * File    : <b>SAPExtrGaaDataService.java</b>
 * @author : DChauras @Created : May 10, 2021 11:32:52 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface SAPExtrGaaDataService {
	public TableRespDto getEnvData(String propName);
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam, String calledBy);
	public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName);

	public List<SAPUserAccessModel> readSAPGaaUserAccessData(String templSysParam);
	public String writeSapGaaUserAccessCSV(List<SAPUserAccessModel> data, String fileName);

	public String writeLogData(StringBuilder data, String fileName) ;



	//Region Wise
	public Map<String, LinkedList<SAPUserAccessModel>> readSAPTrfContolRegionData(List<String> templSysParam);

		/**
		 * Method  : SAPExtrGaaDataService.java.readTrfContolRegionSch()
		 *		   :<b>@param activeSchedule
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 12, 2021 2:34:36 PM
		 * Purpose :
		 * @return : Map<String,List<SAPUserAccessModel>>
		 */
	public Map<String, List<SAPUserAccessModel>> startTrfContolRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String> templSysParam);

	public int insertTransferTransactions(List<SAPUserAccessModel> trfUserData, String sysTemp, String createdUser) ;
	//Region Wise
	public String writeRegTrfCntrlCSV(Map<String, LinkedList<SAPUserAccessModel>> data, String fileName);

	//Export Data
	public int exportTrfCntrlDataGenesis(Map<String, LinkedList<SAPUserAccessModel>> regDataMap, HttpServletRequest request);
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) ;
	public Map<String, List<SAPUserAccessModel>> startExportTrfContolRegionSch(TrfCntrlSchModel activeSchedule);
	public int exportTrfCntrlDataToGenesis(List<SAPUserAccessModel> dataList, String sysDetail);
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule);
	public List<SapGaaUser2RoleModel> readSapUserToRoleActData(String templSysParam);

	//Incomplete Data Email
	public void sendInvldDataEmail(String sysTemp, List<SapGaaUser2RoleModel> dataList);

	//GENESIS Transfer Control Report
	public Map <String, Map<String, List<SapDataTransferReportMdl>>> getGenesisTransferReportData();
	public List<String> getGenesisUser2RoleReportSystems();
	public Map<String, Map<String, List<SapUser2RoleReportMdl>>> getGenesisUser2RoleReportData();
	public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser);
	public Map<String, List<SapUser2RoleDeltaMdl>> getGenesisUser2RoleData(List<String> users);//Data For comparing Delta information
	public int checkDeltaRecord(SapUser2RoleDeltaMdl rec2Check);
	public List<SapU2RDeltaSummaryMdl> getUser2RoleSummaryDeltaData(String type);



	//CRITAL ROLES
	public List<SapGaaUser2RoleModel> getCriticalUser2RoleInfo(List<SapGaaUser2RoleModel> activeTrfData);
	public int insertUser2CriticalRoleTrans(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser);
	public Map<String, List<SapGaaUser2RoleModel>> startUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule);//Method designed to be called by Scheduler
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule);
	public int exportUser2CriticalRoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) ;
	public String clearUser2RoleDelta();
	public String clearUser2SodDelta();
	public List<TrfCntrlTransDataMdl> getAllTrfControlExportableData(String regn);
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn);
	public String writeSapGaaUser2RoleXLS(List<SapGaaUser2RoleModel> data, String fileName, String sheetNm);
	public UserSearchModel getUserStatusJJEDS(String userId, int active);
	public List<UserSearchModel> getUserListFromJJEDS(String userId, int active);
	//USER2SOD
	public Map<String, List<SapUser2SodModel>> startUser2SodRegionSch(TrfCntrlSchModel activeSchedule);
	public Map<String, List<SapUser2SodModel>> startExportUser2SodRegionSch(TrfCntrlSchModel activeSchedule);
	public int exportUser2SodDataToGenesis(List<SapUser2SodModel> dataList, String sysDetail);
	public void sendInvldUser2SodDataEmail(String sysTemp, List<SapUser2SodModel> dataList);
	public List<SapUser2SodTrnsModel> getAllUser2SodExportableData(String regn);
	public List<SapU2RDeltaSummaryMdl> getUser2SodSummaryDeltaData(String type);
	public Map<String, List<SapUser2SodDeltaMdl>> getGenesisUser2SodData(List<String> users);
	public Map<String, Map<String, List<SapUser2SodReportMdl>>> getGenesisUser2SodReportData();

	/*RAW Data processing for AUDIT*/
	public void saveUser2RoleRawData(Map<String, List<String>> usrRoleMap, Map<String, String> roleNameValue, String templSysParam);
	public int insertUser2RoleRawData(List<User2RoleRawDataMdl> rawDataList);
	public void saveUser2RoleAllRawData(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp);
	public int getU2RReportSeq(String finalEml);
	public int saveU2RRepPlatformEmailLog(int seq, List<String> sysIDs, String triggeredBy, String report);
	public Map<String, List<SapUser2RoleReportMdl>> getGenesisUser2RoleReportPlatformData(String platform);

	//Getting User Roles
	public List<IAMRolesADGrpMdl> readPFBUserRolesADGrpData(String templSysParam, String userId);
	public List<String> readPFICFINUserRolesPosnData(String templSysParam, String userId);
	public List<String> readGRCSYSUserRolesPosnData(String templSysParam, String userId);
	public List<String> readAnaplanSYSUserRolesData(String templSysParam, String userId);


	public UserSearchModel getUserStatusJJEDSByFnLn(String firstNm, String lastNm, int active);
	public List<U2REmailLogMdl> getWeeklyU2RReportDetails();
	public List<U2REmailLogMdl> getWeeklyU2RReportData(int seqId);
	public int updWeeklyReportStatus(int seqIdParam, String platform, String userId);




}
