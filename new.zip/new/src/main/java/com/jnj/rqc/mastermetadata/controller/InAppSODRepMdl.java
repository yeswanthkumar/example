package com.jnj.rqc.mastermetadata.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InAppSODRepMdl {
	private String userId;
	private String userEmail;
	private String userFirstName;
	private String userLastName;
	private String sectorName1;
	private String posName1;
	private String sectorName2;
	private String posName2;
    private String sodExists;
    private String conflictDescription;
    private String managerId;
    private String managerEmail;
    private String managerFullName;

}
