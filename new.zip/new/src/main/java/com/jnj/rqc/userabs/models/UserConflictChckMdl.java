package com.jnj.rqc.userabs.models;

import java.util.List;

import lombok.Data;

@Data
public class UserConflictChckMdl {
	private String 	userid;
	private List<RoleADGrpMdl> existingAccess;
	private List<RoleADGrpMdl> newAccess;
}
