package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class HanaUserGrantModel {
	private String wwId;  		//SYS.GRANTED_ROLES
	private String type; 		//SYS.GRANTED_ROLES
	private String roleName; 	//SYS.GRANTED_ROLES

	private String grantee;		//SYS.GRANTED_PRIVILEGES-ROLE
	private String granteeType; //SYS.GRANTED_PRIVILEGES
	//private String role;		//SYS.GRANTED_PRIVILEGES
	private String objType;		//SYS.GRANTED_PRIVILEGES
	private String objName;		//SYS.GRANTED_PRIVILEGES
	private String colName;		//SYS.GRANTED_PRIVILEGES
	private String privilege;	//SYS.GRANTED_PRIVILEGES
	private String valid;		//SYS.GRANTED_PRIVILEGES

	@Override
	public String toString() {
		return "HanaUserGrantModel [wwId=" + wwId + ", type=" + type + ", roleName=" + roleName + ", grantee=" + grantee
				+ ", granteeType=" + granteeType +", objType=" + objType + ", objName=" + objName
				+ ", colName=" + colName + ", privilege=" + privilege + ", valid=" + valid + "]";
	}


	public String getData() {
		return wwId + "~" + type + "~" + roleName + "~" + grantee + "~" + granteeType + "~" + objType + "~" + objName + "~" + colName + "~" + privilege + "~" + valid ;
	}



}
