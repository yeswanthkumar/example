package com.jnj.rqc.mastermetadata.controller;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SchedularStatusDTO {
	private int statusCode;
	private String	message;
	private Map<String, ?> status;
}
