package com.jnj.rqc.mastermetadata.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.mastermetadata.dao.MasterMetaData;
import com.jnj.rqc.mastermetadata.service.MitigationReportService;

@RestController
@RequestMapping("/v2/api/mitigationreport")
public class MitigationReportController {
	static final Logger log = LoggerFactory.getLogger(MitigationReportController.class);
	
	@Autowired
	private MitigationReportService mitigationReportService;
	
	 @GetMapping("/fetch")
	    public ResponseEntity<MitigationReportDTO> fetchData() {
	        log.debug("enter into the method");
	        MitigationReportDTO reportDTO = new MitigationReportDTO();
	        try {
	            reportDTO = mitigationReportService.getMitigationResults();
	            if (reportDTO.getStatusCode() == 200) {
	               return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	            } else if (reportDTO.getStatusCode() == 500) {
	                return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	            } else {
	                return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	            }	            
	        } catch (Exception e) {
	            log.error("Exception: " + e.getMessage());
	            return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	        }	        
	    }
	 
	 @GetMapping("/fetch/byCriteria")
	 public ResponseEntity<MitigationReportDTO> fetchDataBycriteria(@RequestParam("criteria") String criteria, @RequestParam("value") String value) {
     log.debug("enter into the method");
     MitigationReportDTO reportDTO = new MitigationReportDTO();
	     try {
	         reportDTO = mitigationReportService.getMitigationResults(criteria, value);
	         if (reportDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	         } else if (reportDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 @GetMapping("/fetch/errorreport")
	 public ResponseEntity<ReportErrorDTO> fetchReportError(
			 @RequestParam @DateTimeFormat(pattern = "MM/dd/yyyy") Date fromDate,
	            @RequestParam @DateTimeFormat(pattern = "MM/dd/yyyy") Date toDate) {
		 log.debug("enter into the method");
		 ReportErrorDTO reportDTO = new ReportErrorDTO();
	     try {	         
	    	 reportDTO = mitigationReportService.getErrorReport(fromDate, toDate);
	         if (reportDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	         } else if (reportDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 @GetMapping("/fetch/successreport")
	 public ResponseEntity<ReportErrorDTO> fetchReportSuccess(
			 @RequestParam @DateTimeFormat(pattern = "MM/dd/yyyy") Date fromDate,
	            @RequestParam @DateTimeFormat(pattern = "MM/dd/yyyy") Date toDate) {
		 log.debug("enter into the method");
		 ReportErrorDTO reportDTO = new ReportErrorDTO();
	     try {	         
	    	 reportDTO = mitigationReportService.getSuccessReport(fromDate, toDate);
	         if (reportDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(reportDTO, HttpStatus.OK);
	         } else if (reportDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(reportDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(reportDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 @GetMapping("/fetch/pingGRCStatus")
	 public ResponseEntity<SystemStatusDTO> fetchGRCStatus() {
		 log.debug("enter into the method");		
		 SystemStatusDTO statusDTO = new SystemStatusDTO();
	     try {	         
	    	 statusDTO = mitigationReportService.getGRCStatus();
	         if (statusDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(statusDTO, HttpStatus.OK);
	         } else if (statusDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(statusDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 @GetMapping("/fetch/pingIAMStatus")
	 public ResponseEntity<SystemStatusDTO> fetchIAMStatus() {
		 log.debug("enter into the method");		
		 SystemStatusDTO statusDTO = new SystemStatusDTO();
	     try {	         
	    	 statusDTO = mitigationReportService.getIAMStatus();
	         if (statusDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(statusDTO, HttpStatus.OK);
	         } else if (statusDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(statusDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 
	 @PostMapping("/update/userrole")
	 public ResponseEntity<ReportResponse> sendRequestTodownstream(@RequestBody ReportErrorModel reportErrorModel) {
		 log.debug("enter into the method");
		 ReportResponse entityRespose = new ReportResponse();
		 try {
			  entityRespose = mitigationReportService.sendRequestTodownstream(reportErrorModel);
			 if (entityRespose.getStatusCode() == 200) {
		          return new ResponseEntity<>(entityRespose, HttpStatus.OK);
		     } else if (entityRespose.getStatusCode() == 500) {
		          return new ResponseEntity<>(entityRespose, HttpStatus.INTERNAL_SERVER_ERROR);
		     } else {
		          return new ResponseEntity<>(entityRespose, HttpStatus.NOT_FOUND);
		     }
		 }catch(Exception ee) {
			 log.error("Exception :"+ee.getMessage());
			 return new ResponseEntity<>(entityRespose, HttpStatus.INTERNAL_SERVER_ERROR);
		 }		 
	 }
	 @GetMapping("/fetch/requestsubmitcount")
	 public ResponseEntity<MonitorReportDTO> requestsubmitcount(@RequestParam(name = "year", defaultValue = "2023") String year) {
		 log.debug("enter into the method");				
		 MonitorReportDTO systemDTO = new MonitorReportDTO();
	     try {  		    	
	    	 systemDTO = mitigationReportService.requestsubmitcount(year);
	         if (systemDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(systemDTO, HttpStatus.OK);
	         } else if (systemDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(systemDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(systemDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(systemDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 @GetMapping("/fetch/requestidsubmitcount")
	 public ResponseEntity<RequestMonitorReportDTO> requestsubmitidcount(@RequestParam(name = "year", defaultValue = "2023") String year) {
		 log.debug("enter into the method");						 
		 RequestMonitorReportDTO systemDTO = new RequestMonitorReportDTO();
	     try {  		    	
	    	 systemDTO = mitigationReportService.requestidsubmitcount(year);
	         if (systemDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(systemDTO, HttpStatus.OK);
	         } else if (systemDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(systemDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(systemDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(systemDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 
	 @GetMapping("/fetch/schedularStatus")
	 public ResponseEntity<SchedularStatusDTO> schedularStatus() {
		 log.debug("enter into the method");					
		 SchedularStatusDTO statusDTO = new SchedularStatusDTO();
	     try {  		    		    	 
	    	 statusDTO  = mitigationReportService.schedularStatus();
	         if (statusDTO.getStatusCode() == 200) {
	            return new ResponseEntity<>(statusDTO, HttpStatus.OK);
	         } else if (statusDTO.getStatusCode() == 500) {
	             return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	         } else {
	             return new ResponseEntity<>(statusDTO, HttpStatus.NOT_FOUND);
	         }	            
	     } catch (Exception e) {
	         log.error("Exception: " + e.getMessage());
	         return new ResponseEntity<>(statusDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	     }	        
	 }
	 
}
