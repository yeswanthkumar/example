package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MatrixModel {

	private String wwid;
	private int role1;
	private int role2;
	private String app1;
	private String app2;
	private String conflict;
	private String mitigatingControl;


	public String getData() {
		return  wwid+"~"+role1+"~"+role2+"~"+ app1 + "~" + app2 + "~" + conflict + "~" + mitigatingControl ;
	}




	@Override
	public String toString() {
		return "ConflictModel [wwid=" + wwid + "role1=" + role1 + ", role2=" + role2 + ", app1=" + app1 + ", app2=" + app2 + ", conflict=" + conflict + ", mitiCntrl=" + mitigatingControl + "]";
	}

}
