package com.jnj.rqc.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.jnj.rqc.constants.Constants;

//@Component
@WebFilter("/*")
public class UserAuthFilter implements Filter{
	static final Logger log = LoggerFactory.getLogger(UserAuthFilter.class);

	@Autowired
	ValidateUserBean validateUserBean;

	@Override
	public void init(final FilterConfig fc) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletResponse res = (HttpServletResponse) response;
		HttpServletRequest req = (HttpServletRequest) request;

		long startTime 			= System.currentTimeMillis();
		String method 			= req.getMethod();
		String path 			= req.getContextPath();
		String uri 				= req.getRequestURI();
		//String userId = req.getParameter("ntId");
		//String password = req.getParameter("password");
		HttpSession session 	= req.getSession(false);

		log.debug("******FILTER CALLED with  method:"+method+"\npath: "+path+"\n uri: "+uri );

		if(null != session)
		{
			//if("Y".equals(session.getAttribute(Constants.USER_VALIDATED)) || (uri.endsWith("/") || uri.endsWith("/index")||uri.endsWith("/login")||uri.endsWith("/logout")||uri.endsWith(".css")||uri.endsWith(".js")||uri.endsWith(".gif")||uri.endsWith(".jpg")||uri.endsWith(".png"))) {
			//if("Y".equals(session.getAttribute(Constants.USER_VALIDATED)) && (session.getAttribute(Constants.AUTH_USER) != null)) {
			if(("Y".equals(session.getAttribute(Constants.USER_VALIDATED)) && (session.getAttribute(Constants.AUTH_USER) != null)) || (uri.contains("v2"))){
				chain.doFilter(request, response);
				return;
			}
			else{
				log.debug("Validating USER..!");
				try
				{
					boolean validReq =  validateUserBean.validateRequest(req);
					if(validReq){
						chain.doFilter(req, res);
						return;
					}else{
						req.setAttribute("error", Constants.USER_AUTH_ERROR);
						req.getRequestDispatcher("/login").forward(req, res);
						return ;
					}
				} catch (Exception e) {
					log.error("Error Authenticating User:"+e.getMessage(), e);
				}
			}
		}else{
			log.info("URI: "+uri);
			if(uri.contains("actuator") || uri.contains("v2")) {
				chain.doFilter(request, response);
				return;
			}else if(uri.endsWith("/") || uri.endsWith("/index")||uri.endsWith("/login")||uri.endsWith("/logout")||uri.endsWith(".css")||uri.endsWith(".js")||uri.endsWith(".gif")||uri.endsWith(".jpg")||uri.endsWith(".JPG")||uri.endsWith(".png")|| uri.endsWith("/v2/api-docs")) {
				chain.doFilter(req, res);
				return;
			}else {
				try {
					boolean validReq =  validateUserBean.validateRequest(req);
					if(validReq){
						chain.doFilter(req, res);
						return;
					}else{
						req.setAttribute("error", Constants.USER_AUTH_ERROR);
						req.getRequestDispatcher("/login").forward(req, res);
						return;
					}
				} catch (Exception e) {
					req.setAttribute("error", e.getMessage());
					req.getRequestDispatcher("/login").forward(req, res);
					return;
				}
			}
		}
		chain.doFilter(req, res);
		return;
	}



}
