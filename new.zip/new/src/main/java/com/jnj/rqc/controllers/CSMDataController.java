package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.security.ValidateUserBean;
import com.jnj.rqc.service.AppEmailRoutingService;
import com.jnj.rqc.service.CSMDataService;
import com.jnj.rqc.service.RqcReportService;
import com.jnj.rqc.service.User2SodDataService;
import com.jnj.rqc.util.Utility;

@Controller
public class CSMDataController {

	static final Logger log = LoggerFactory.getLogger(CSMDataController.class);

	@Autowired
	private AppEmailRoutingService appEmailRoutingService;

	@Autowired
	RqcReportService rqcReportService;

	@Autowired
	ValidateUserBean validateUserBean;

	@Autowired
	CSMDataService cSMDataService;

	@Autowired
	User2SodDataService user2SodDataService;




	@GetMapping("/uploadCSMModelData")
    public String uploadCSMModelData(Model model, HttpServletRequest request) {
    	log.info("Uploading Model Data For CSM");
    	return "sapextraction/uploadcsmmodels";
    }


	@PostMapping("/saveCsmModelData")
    public String saveCsmModelData(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected CSM Model Data File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the correct XLSX file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLSX file is required!");
            return "sapextraction/uploadcsmmodels";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel file/Document...!");
            return "sapextraction/uploadcsmmodels";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<CSMModelAdGrpMap> csmData = cSMDataService.readCSMModelDataXls(path, request);
    		HttpSession session = request.getSession();
    		session.removeAttribute("CSMMODEL_DATA");
    		if(csmData != null && !csmData.isEmpty()) {
    			session.setAttribute("CSM_MDL_FILENAME", file.getOriginalFilename());
    			session.setAttribute("CSMMODEL_DATA", csmData);
        		model.addAttribute("CSMMODEL_DATA", csmData);
        		//CSMFILE_TOTALCOUNT
        		session.setAttribute("CSMMDL_VLDCOUNT", csmData.size());
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((csmData != null && !csmData.isEmpty())? csmData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/uploadcsmmodels";
    }


	@ResponseBody
    @GetMapping("/dwnCsmModelDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnCsmModelDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading CSM Model Data CSV ");
		String uid = Utility.getUid();
		String fileNm ="CSM_MODELData";
		List<CSMModelAdGrpMap> csmMdlData = (List<CSMModelAdGrpMap>)request.getSession().getAttribute("CSMMODEL_DATA");
		String filePath = cSMDataService.writeCSMModelDataCSV(csmMdlData, fileNm);
		File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/exportCsmModelData")
	public ResponseEntity<InputStreamResource> exportCsmModelData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving CSM Model Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "CSMMCL_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}

    	String flNm = (String)sess.getAttribute("CSM_MDL_FILENAME");
    	int recordsIns = 0;
		logData.append("Saving CSM Model Data to DataBase.");
    	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	List<CSMModelAdGrpMap> csmMdlData = (List<CSMModelAdGrpMap>)request.getSession().getAttribute("CSMMODEL_DATA");
    	logData.append("Total Records in file : "+csmMdlData.size()+"\n");
    	logData.append("Saving  "+csmMdlData.size()+" Records to DataBase. \n");
    	try {
    		recordsIns = cSMDataService.saveCSMModelDataToDB(csmMdlData);
    	} catch (Exception e) {
			logData.append("ERROR Total Records Inserted for CSM Model Data in DataBase : "+recordsIns+"\n"+e.getMessage());
			log.error("ERROR inserting Records for CSM Model Data "+e.getMessage(), e);
		}
    	logData.append("Total CSM Model Data Records saved to Database :(ADDED) "+recordsIns+"\n");
    	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	filePath = Utility.writeLogData(logData, "CSMMODEL_UPLOAD_"+Utility.fmtMDY(new Date())+".txt");
    	File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
		InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		return ResponseEntity.ok()
 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
     	.contentType(MediaType.TEXT_PLAIN)
     	.contentLength(fl.length())
     	.body(resource);

	}



	@GetMapping("/uploadCSMHistData")
    public String uploadCSMHistData(Model model, HttpServletRequest request) {
    	log.info("Uploading Historical Data From CSM");
    	return "sapextraction/uploadcsmhistory";
    }


	@GetMapping("/triggerCSMDataCreation")
    public String triggerCSMDataCreation(Model model, HttpServletRequest request) {
    	log.info("Uploading Historical Data From CSM");
    	return "sapextraction/uploadcsmhistory";
    }



	@PostMapping("/saveCsmData")
    public String saveCsmData(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected CSM History Data File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the correct XLSX file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLSX file is required!");
            return "sapextraction/uploadcsmhistory";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel file/Document...!");
            return "sapextraction/uploadcsmhistory";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<CSMHistDataMdl> csmData = cSMDataService.readCSMExcel(path, request);
    		HttpSession session = request.getSession();
    		session.removeAttribute("CSMHIST_DATA");
    		if(csmData != null && !csmData.isEmpty()) {
    			session.setAttribute("CSM_FILENAME", file.getOriginalFilename());
    			session.setAttribute("CSMHIST_DATA", csmData);
        		model.addAttribute("CSMHIST_DATA", csmData);
        		//CSMFILE_TOTALCOUNT
        		session.setAttribute("CSMFILE_VLDCOUNT", csmData.size());
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((csmData != null && !csmData.isEmpty())? csmData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/uploadcsmhistory";
    }


	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/exportCsmData")
	public ResponseEntity<InputStreamResource> exportCsmData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving CSM Archive Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "CSM_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}

    	String flNm = (String)sess.getAttribute("CSM_FILENAME");
    	int recordsIns = 0;
		logData.append("Saving CSM Archive Data to DataBase.");
    	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	List<CSMHistDataMdl> csmData = (List<CSMHistDataMdl>)request.getSession().getAttribute("CSMHIST_DATA");
    	logData.append("Total Records in file : "+csmData.size()+"\n");
    	logData.append("Saving  "+csmData.size()+" Records to DataBase. \n");
    	try {
    		recordsIns = cSMDataService.saveCSMDataToDB(csmData);
    	} catch (Exception e) {
			logData.append("ERROR Total Records Inserted for CSM Archive Data in DataBase : "+recordsIns+"\n"+e.getMessage());
			log.error("ERROR inserting Records for CSM Archive Data "+e.getMessage(), e);
		}
    	logData.append("Total CSM Archive Data Records saved to Database :(ADDED) "+recordsIns+"\n");
    	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	filePath = Utility.writeLogData(logData, "CSM_ARCHIVEUPLOAD_"+Utility.fmtMDY(new Date())+".txt");
    	File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
		InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		return ResponseEntity.ok()
 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
     	.contentType(MediaType.TEXT_PLAIN)
     	.contentLength(fl.length())
     	.body(resource);

	}



	@ResponseBody
    @GetMapping("/dwnCsmDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnCsmDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading CSM Archive CSV ");
		String uid = Utility.getUid();
		String fileNm ="CSM_Archive";
		List<CSMHistDataMdl> csmData = (List<CSMHistDataMdl>)request.getSession().getAttribute("CSMHIST_DATA");
		String filePath = cSMDataService.writeCSMDataCSV(csmData, fileNm);
		File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@GetMapping("/processInitCSMData")
    public String processInitCSMData(Model model, HttpServletRequest request) {
    	log.info("Getting LDAP User for CSM.");
    	return "sapextraction/csmdatacreation";
    }


	@PostMapping("/startProcessInitCSMData")
    public String startProcessInitCSMData(Model model, HttpServletRequest request) {
    	log.info("Getting LDAP User Data for CSM.");
    	List<GrpUsrDateMdl> adDataLst = startProcessCSMData(1, request);

    	if(adDataLst != null && !adDataLst.isEmpty()) {
    		int recordsSaved = saveIamCsmData(adDataLst);
    		log.info("Total new records saved: "+ adDataLst.size());
    		model.addAttribute("CSMUSER_NEWDATA", adDataLst);
    	}
    	model.addAttribute("NEWREC_COUNT", (adDataLst.isEmpty())? "0":adDataLst.size());
    	//Query All the Data, NOT sent to CSM so far.
    	List<GrpUsrDateMdl> allAdDataList = getAllCSMNewRecords();
    	request.getSession().removeAttribute("CSMUSER_DATA");
    	if(allAdDataList != null && !allAdDataList.isEmpty()) {
    		request.getSession().setAttribute("CSMUSER_DATA", allAdDataList);
    		model.addAttribute("CSMUSER_DATA", allAdDataList);
    		model.addAttribute("PROC_TIME", new Date());
    		model.addAttribute("REC_COUNT", allAdDataList.size());
    	}
    	model.addAttribute("message", "True");
		model.addAttribute("success", "Status: Data Extraction successfull  ( Total Records extracted: "+((allAdDataList != null && !allAdDataList.isEmpty())? allAdDataList.size():0)+" )");
    	return "sapextraction/csmdatacreation";
    }


	public List<GrpUsrDateMdl> startProcessCSMData(int proc, HttpServletRequest request) {
		Map<String, List<GrpUsrDateMdl>> adDataMap = new HashMap<>();
		List<GrpUsrDateMdl> step1CsmList = new ArrayList<>();
		List<GrpUsrDateMdl> finalCsmList = new ArrayList<>();

		try {
			if(1 == proc) {
				adDataMap = validateUserBean.getGroupMemberDetail((String)request.getSession().getAttribute("CSM_UNAM"), (String)request.getSession().getAttribute("CSM_UPWD"));
			}else {
				adDataMap = validateUserBean.getGroupMemberDetail(Constants.CSM_UNAM, Constants.CSM_UPWD);
			}

			if(adDataMap != null && !adDataMap.isEmpty()) {
				step1CsmList = cSMDataService.validateAndFilterData(adDataMap);//All NEW DATA
				if(!step1CsmList.isEmpty()) {//Filter from Previous RUN
					finalCsmList = cSMDataService.compareWithPreviousRun(step1CsmList);
				}
				/*if(!finalCsmList.isEmpty() && proc == 2) {
					String fileName = cSMDataService.buildCSMDataExcel(finalCsmList, "CSMData");
				}*/
			}
		} catch (Exception e) {
			log.error("Error connecting LDAP server :"+e.getMessage(), e);
		}
		return finalCsmList;

	}


	@ResponseBody
    @GetMapping("/dwnCsmCurrDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnCsmCurrDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading CSM Current Data EXCEL ");
		List<GrpUsrDateMdl> finalCsmList = (List<GrpUsrDateMdl>)request.getSession().getAttribute("CSMUSER_DATA");
		String filePath = cSMDataService.buildCSMDataExcel(finalCsmList, "CSMData");
		File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/markIAMDataForCSMComplete")
	public ResponseEntity<InputStreamResource> markIAMDataForCSMComplete(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("MARK IAM-CSM Data download complete in Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "IAMCSM_DATA_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}
		int recordsUpd = 0;
		logData.append("START Mark IAM-CSM User Data download to completed in DataBase    @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	List<GrpUsrDateMdl>  iamCsmData = (List<GrpUsrDateMdl>)request.getSession().getAttribute("CSMUSER_DATA");
    	logData.append("Total Records to Mark Completed  : "+iamCsmData.size()+"\n");
    	try {
    		recordsUpd = cSMDataService.updateIAMCSMDataToComplete();
    		request.getSession().removeAttribute("CSMUSER_DATA");//Removing Data from Session
    	} catch (Exception e) {
			logData.append("ERROR updating IAM-CSM Data status in DataBase : "+recordsUpd+"\n"+e.getMessage());
			log.error("ERROR Updating IAM-CSM Data in DataBase "+e.getMessage(), e);
		}
    	logData.append("Total IAM-CSM Data Records updated to Database :(UPDATED => 'N') "+recordsUpd+"\n");
    	logData.append("END Mark IAM-CSM User Data download completed in DataBase  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	filePath = Utility.writeLogData(logData, "IAM-CSMDATAC_"+Utility.fmtMDY(new Date())+".txt");
    	File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
		InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		return ResponseEntity.ok()
 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
     	.contentType(MediaType.TEXT_PLAIN)
     	.contentLength(fl.length())
     	.body(resource);
    }




	public int saveIamCsmData(List<GrpUsrDateMdl> iamDataList){
    	log.info("Saving IAM-CSM Data to Database");
    	int recordsIns = 0;
    	recordsIns = cSMDataService.saveIAMCSMDataToDB(iamDataList);
    	return recordsIns;
	}

	public List<GrpUsrDateMdl> getAllCSMNewRecords(){
    	log.info("Getting all IAM-CSM Data from Database");
    	int recordsIns = 0;
    	List<GrpUsrDateMdl> iamDataList = cSMDataService.getAllIAMCSMDataFromDB();
    	return iamDataList;
	}




	/*

	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/exportIAMDataForCSM")
	public ResponseEntity<InputStreamResource> exportIAMDataForCSM(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving IAM-CSM Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "IAMCSM_DATA_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}
		int recordsIns = 0;
		logData.append("START Processing Save IAM-CSM User Data to DataBase    @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	List<GrpUsrDateMdl>  iamCsmData = (List<GrpUsrDateMdl>)request.getSession().getAttribute("CSMUSER_DATA");
    	logData.append("Total Records to be Saved : "+iamCsmData.size()+"\n");
    	logData.append("Saving  "+iamCsmData.size()+" Records to DataBase. \n");
    	try {
    		recordsIns = saveIamCsmData(iamCsmData);
    	} catch (Exception e) {
			logData.append("ERROR Saving IAM-CSM Data in DataBase : "+recordsIns+"\n"+e.getMessage());
			log.error("ERROR Saving IAM-CSM Data in DataBase "+e.getMessage(), e);
		}
    	logData.append("Total IAM-CSM Data Records saved to Database :(ADDED) "+recordsIns+"\n");
    	logData.append("END Processing Save IAM-CSM User Data to DataBase  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
    	filePath = Utility.writeLogData(logData, "IAM-CSMDATA_"+Utility.fmtMDY(new Date())+".txt");
    	File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
		InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		return ResponseEntity.ok()
 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
     	.contentType(MediaType.TEXT_PLAIN)
     	.contentLength(fl.length())
     	.body(resource);
    }
*/



}
