package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BfSctrRegSystemDDMdl {
	String sysid;
	String sysname;
	String sysdesc;


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BfSctrRegSystemDDMdl other = (BfSctrRegSystemDDMdl) obj;
		if (sysid == null) {
			if (other.sysid != null)
				return false;
		} else if (!sysid.equals(other.sysid))
			return false;
		if (sysname == null) {
			if (other.sysname != null)
				return false;
		} else if (!sysname.equals(other.sysname))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sysid == null) ? 0 : sysid.hashCode());
		result = prime * result + ((sysname == null) ? 0 : sysname.hashCode());
		return result;
	}



}