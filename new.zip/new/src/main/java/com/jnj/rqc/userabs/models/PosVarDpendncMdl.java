package com.jnj.rqc.userabs.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PosVarDpendncMdl {
	private String posvarid;
	private String posvarname;
	List<ADGrpDpendncMdl> adgrps;

}
