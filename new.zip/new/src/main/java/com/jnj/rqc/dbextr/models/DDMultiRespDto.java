package com.jnj.rqc.dbextr.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.models.StrKeyValPair;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DDMultiRespDto {
	private int statusCode;
	private String message;
	private String datetimeStamp;
	private String statusDesc;
	private String developerMessage;
	private String type;//PER/POS
	private List<StrKeyValPair> table1;
	private List<StrKeyValPair> table2;

}
