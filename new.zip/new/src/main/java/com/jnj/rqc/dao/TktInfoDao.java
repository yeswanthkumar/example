package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.reportmodels.ReportDataModel;

public interface TktInfoDao {
	public List<ReportDataModel> getUserTktInfo(String[]  wwids ) throws SQLException, DataAccessException ;
	public List<ReportDataModel> searchTktInfo(String tktNo)throws SQLException, DataAccessException;
	//public List<AppRoles> getTktRoles(String[] ticketNo) throws SQLException, DataAccessException ;
	//public List<AppRoles> getTktAppRoles(String[] ticketNo,  List<Integer> appIds) throws SQLException, DataAccessException ;
	//public List<ReqLogModel> getTktReqLogs(String[] ticketNo) throws SQLException, DataAccessException ;

}
