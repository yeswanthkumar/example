package com.jnj.rqc.mastermetadata.controller;

import lombok.Data;

@Data
public class AnaplanRoleModel {
	private String clientId;
	private String userId;
	private String adGroupName;
	private String modDate;
	private String stopDate;
}
