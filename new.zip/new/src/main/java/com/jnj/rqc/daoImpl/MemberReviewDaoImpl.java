package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.dao.MemberReviewDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.Assigner;
import com.jnj.rqc.models.RQCTktData;
import com.jnj.rqc.models.UsrJJEdsMdl;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>MemberReviewDaoImpl.java</b>
 * @author : DChauras @Created : May 29, 2019 11:48:39 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class MemberReviewDaoImpl extends BaseDao implements MemberReviewDao {
	static final Logger log = LoggerFactory.getLogger(MemberReviewDaoImpl.class);

	/**
	 * Method  : MemberReviewDaoImpl.java.queryRQCTktDetails()
	 *		   :<b>@param MON
	 *		   :<b>@param YEAR
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 29, 2019 2:48:32 PM
	 * Purpose :
	 * @return : List<RQCTktData>
	 */
	@Override
	public List<RQCTktData> queryRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException {
		String sql = " SELECT a.TICKT_NO as tktNo, a.CLI_ID as wwid"+
				//+ ", b.CLI_LAST_NM, b.CLI_FIRST_NM, a.REQST_DT, a.REQST_TYP, a.STAT_CD " +
				" , c.EVNT_DESCN as evtDesc" +   //", c.SCHDD_DT, c.APRVL_DT " +
				" FROM TIPTOP.TICKT_REQSTOR a, TIPTOP.CLI_INFO_VW b, TIPTOP.V_TICKET_DETAIL_INFO c " +
				" where a.TICKT_NO = b.TICKT_NO and a.CLI_ID = b.CLI_ID " +
				" AND a.TICKT_NO = c.TICKT_NO  AND a.REQST_DT >= to_date('"+Utility.backDate6M(MON, YEAR)+"', 'MM/DD/YYYY') " +
				" ORDER BY a.TICKT_NO DESC ";
		final List<RQCTktData> tktdata = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(RQCTktData.class));
		return tktdata;
	}



	/**
	 * Method  : MemberReviewDaoImpl.java.getRQCTktDetails()
	 *		   :<b>@param MON
	 *		   :<b>@param YEAR
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 29, 2019 2:48:46 PM
	 * Purpose :
	 * @return : Map<String,String>
	 */
	@Override
	public Map<String, String> getRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException{
		Map<String, String> tableData = new HashMap<>();
		List<RQCTktData> dbData = queryRQCTktDetails(MON, YEAR);
		dbData.forEach(tktData ->{
			int tktNo 		= tktData.getTktNo();
			String wwid 	= tktData.getWwid().trim();
			String evtDesc = tktData.getEvtDesc().trim().toUpperCase();
			String keyStr = evtDesc+"~"+wwid;

			if(!tableData.containsKey(keyStr)) {//Only read the latest TICKET Number
				tableData.put(keyStr, tktNo+"");
			}
		});

		return tableData;

	}


	/**
	 * Method  : MemberReviewDaoImpl.java.getAssignerDetails()
	 *		   :<b>@param MON
	 *		   :<b>@param YEAR
	 *		   :<b>@return List<Assigner>
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 29, 2019 2:46:00 PM
	 * Purpose :
	 * @return : List<Assigner>
	 */
	@Override
	public List<Assigner> getAssignerDetails(int MON, int YEAR)throws SQLException, DataAccessException {
		String sql = " SELECT a.LOG_SEQ, a.TICKT_NO, a.CLI_ID, (b.FMLY_NM||', '||b.GIVEN_NM) AS ASSIGNEE_NAME, ROW_ADD_TMS, CMNTS "
					+" FROM TIPTOP.TICKT_REQSTOR_LOG a, SOD_EXTR.JJEDS_EMP_EXTR_MV b "
					+" WHERE a.ROW_ADD_TMS >= TO_DATE('"+Utility.backDate6M(MON, YEAR)+"', 'MM/DD/YYYY') "
					+" AND a.CLI_ID = b.WW_ID "
					+" ORDER BY TICKT_NO ASC, LOG_SEQ DESC, ROW_ADD_TMS DESC ";
		final List<Assigner> asgnrDataLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(Assigner.class));
		return asgnrDataLst;
	}

//////////

	@Override
	public List<SrcSysMemRoleModel> readSrcSysMemData(String srcSys)throws SQLException, DataAccessException{
		String sql = "SELECT SRC_SYS, WWID, FIRST_NM, LAST_NM, USERID, SUPVR_WWID, APPL_ROLE, SOD_CODE "
				 	+"FROM SOD_EXTR.NAGS_DATA WHERE SRC_SYS = '"+srcSys+"' "
				 	+"ORDER BY WWID, APPL_ROLE ";
		final List<SrcSysMemRoleModel> tktdata = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SrcSysMemRoleModel.class));
		return tktdata;
	}


	@Override
	public List<UsrJJEdsMdl> readJJEDSMemData(String winId)throws SQLException, DataAccessException{
		String sql = "SELECT a.WW_ID as WWID, a.JNJ_MSFT_USRNM_TXT as NTID, a.FMLY_NM||','||a.GIVEN_NM as FULLNAME, a.JNJ_EMAIL_ADDR_TXT as EMAIL, a.POSN_TITL_TXT as TITLE, b.DEPT_NM as DEPT, a.TERMNN_DT as TERMDT "+
					 "FROM SOD_EXTR.JJEDS_EMP_EXTR_MV a, TIPTOP.DEPT b "+
					 " WHERE  a.JNJ_MSFT_USRNM_TXT = upper('"+winId+"') AND a.JNJ_DEPTM_CD = b.DEPT_NO(+) ";
		final List<UsrJJEdsMdl> usrData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(UsrJJEdsMdl.class));
		return usrData;
	}




	@Override
	public Map<String, String> readMemRQCTktData()throws SQLException, DataAccessException{
		Map<String, String> tableData = new HashMap<>();
		List<RQCTktData>  dbData = qryMemRQCTktData();
		dbData.forEach(tktData ->{
			int tktNo 		= tktData.getTktNo();
			String wwid 	= tktData.getWwid().trim();
			String evtDesc = tktData.getEvtDesc().trim().toUpperCase();
			String keyStr = evtDesc+"~"+wwid;

			if(!tableData.containsKey(keyStr)) {//Only read the latest TICKET Number
				tableData.put(keyStr, tktNo+"");
			}
		});


		return tableData;

	}

	private List<RQCTktData> qryMemRQCTktData()throws SQLException, DataAccessException {
		String sql =" SELECT a.TICKT_NO as tktNo, a.CLI_ID as wwid, c.EVNT_DESCN as evtDesc " +
					" FROM TIPTOP.TICKT_REQSTOR a, TIPTOP.CLI_INFO_VW b, TIPTOP.V_TICKET_DETAIL_INFO c " +
					" where a.TICKT_NO = b.TICKT_NO and a.CLI_ID = b.CLI_ID " +
					" AND a.TICKT_NO = c.TICKT_NO  AND a.REQST_DT >= to_date('01/01/2018', 'MM/DD/YYYY') " +
					" ORDER BY a.TICKT_NO DESC ";
		final List<RQCTktData> tktdata = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(RQCTktData.class));
		return tktdata;
	}

	@Override
	public List<Assigner> queryMemAssignerData()throws SQLException, DataAccessException {
		String sql = " SELECT a.LOG_SEQ, a.TICKT_NO, a.CLI_ID, (b.GIVEN_NM||' '||b.FMLY_NM) AS ASSIGNEE_NAME, ROW_ADD_TMS, CMNTS "
					+" FROM TIPTOP.TICKT_REQSTOR_LOG a, SOD_EXTR.JJEDS_EMP_EXTR_MV b "
					+" WHERE a.ROW_ADD_TMS >= TO_DATE('01/01/2018', 'MM/DD/YYYY') "
					+" AND a.CLI_ID = b.WW_ID "
					+" ORDER BY TICKT_NO ASC, LOG_SEQ DESC, ROW_ADD_TMS DESC ";
		final List<Assigner> asgnrDataLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(Assigner.class));
		return asgnrDataLst;
	}



}


