package com.jnj.rqc.serviceImpl;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dao.SAPExtrGaaDao;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.U2REmailLogMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;
import com.jnj.rqc.service.HANADataService;
import com.jnj.rqc.service.HCSExtrDataService;
import com.jnj.rqc.service.JDEExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.User2SodDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;



/**
 * File    : <b>SAPExtrGaaDataServiceImpl.java</b>
 * @author : DChauras @Created : May 11, 2021 2:05:28 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class SAPExtrGaaDataServiceImpl implements SAPExtrGaaDataService{

	static final Logger log = LoggerFactory.getLogger(SAPExtrGaaDataServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	SAPExtrGaaDao sAPExtrGaaDao;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;
	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	JDEExtrDataService jDEExtrDataService;
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	HANADataService hANADataService;
	@Autowired
	GenesisDao genesisDao;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	HCSExtrDataService hCSExtrDataService;
	@Autowired
	User2SodDataService user2SodDataService;



	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadSAPGaaProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}



	@SuppressWarnings("all")
	@Override
	public List<SapGaaUser2RoleModel> readSapUserToRoleActData(String templSysParam){
		log.info("templSysParam :"+templSysParam);
		//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();

		List<SapGaaUser2RoleModel> userRoleData = readSapUserToRoleData(templSysParam, "R");
		if(userRoleData != null && !userRoleData.isEmpty()) {
			//START -  SAVE ALL RAW DATA
			saveUser2RoleAllRawData(userRoleData, templSysParam);
			//END -  SAVE ALL RAW DATA
			for(SapGaaUser2RoleModel mdl:userRoleData) {
	    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
	    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
	    				activeTrfData.add(mdl);
	    			}
	    		}else {
	    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
	    				String usrId = mdl.getUserId();
	    				UserSearchModel srchUsr = this.getUserStatusJJEDS(usrId, 0);
	    				if(srchUsr != null) {
							mdl.setUserStatus(srchUsr.getEmpStatTxt());
						}else {
							mdl.setUserStatus("NO DATA FOUND");
						}
	    				incompleteData.add(mdl);
	    			}
	    		}
	    	}
		}

		if(incompleteData != null && !incompleteData.isEmpty()) {
			sendInvldDataEmail(templSysParam, incompleteData);
		}
		return activeTrfData;
	}

	@Override
	public void sendInvldDataEmail(String sysTemp, List<SapGaaUser2RoleModel> dataList) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			log.info(envName+" Preparing INCOMPLETE/INVALID Records email for Systems ("+sysTemp+") ");
			String[] sysArr=sysTemp.split("_");
			String invldFlNm ="INCOMPLETE_UsertoRole_Review_SAP_"+sysTemp;
			//String invldFlPath = writeSapGaaUser2RoleCSV(dataList, invldFlNm);//CSV
			String invldFlPath = writeSapGaaUser2RoleXLS(dataList, invldFlNm,"InvalidData");
			String toEmail=Utility.getPlatformEmailAddress(sysArr[1]);
			log.info(envName+" Sending INCOMPLETE/INVALID Records email for Systems ("+sysTemp+") to:"+toEmail);
			emailUtil.sendPlatformEmail("("+envName+") - INCOMPLETE/INVALID ERP USER TO ROLE Data for Platform: "+sysArr[1]+" - ("+sysTemp+") ", invldFlPath, toEmail, "U");
		} catch (Exception e) {
			log.error("ERROR Sending "+envName+"INVALID/INCOMPLETE Data Email :"+e.getMessage(), e);
		}

	}

	@Override
	public void sendInvldUser2SodDataEmail(String sysTemp, List<SapUser2SodModel> dataList) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			log.info(envName+" Preparing INCOMPLETE/INVALID User to Sod Records email for Systems ("+sysTemp+") ");
			String[] sysArr=sysTemp.split("_");
			String invldFlNm ="INCOMPLETE_UsertoSod_Review_"+sysTemp;
			String invldFlPath = user2SodDataService.writeSapUser2SodExcel(dataList, invldFlNm);
			String toEmail=Utility.getPlatformEmailAddress(sysArr[1]);
			log.info(envName+" Sending INCOMPLETE/INVALID User to Sod Records email for Systems ("+sysTemp+") to:"+toEmail);
			emailUtil.sendPlatformEmail("("+envName+") - INCOMPLETE/INVALID ERP USER TO SOD Data for Platform: "+sysArr[1]+" - ("+sysTemp+") ", invldFlPath, toEmail, "US");
		} catch (Exception e) {
			log.error("ERROR Sending "+envName+"INVALID/INCOMPLETE Data Email :"+e.getMessage(), e);
		}

	}


	@SuppressWarnings("all")
	@Override
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam, String calledBy){
		log.info("templSysParam :"+templSysParam);
		LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
		Map<String, List<String>> usrRoleMap = new HashMap<>();
		Map<String, String> roleNameValue = new HashMap<>();
		try {
			List<String> userLst = sAPExtrGaaDao.getAllValidUsers(templSysParam);//Get All Users for the given System
			log.info("Total Users for ("+templSysParam+") ="+userLst.size());
			if(userLst != null && !userLst.isEmpty()) {
				for(String usr:userLst) {
					List<String> usrRoles = sAPExtrGaaDao.getUsersRoles(usr, templSysParam);
					if(usrRoles != null && !usrRoles.isEmpty()) {
						for (String usrRole : usrRoles) {
							roleNameValue.put(usrRole, "");
						}

						if(usrRoleMap.containsKey(usr)) {
							List<String> roleList = usrRoleMap.get(usr);
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}else {
							List<String> roleList = new ArrayList<>();
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}
					}
				}

				log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));

				//Getting Role Descriptions for All Unique Role Names
				log.info("Getting Role Description for  : "+roleNameValue.size()+" Records.");
				for(String rlNm : roleNameValue.keySet()) {
					String roleDesc = sAPExtrGaaDao.getRoleDescription(rlNm, templSysParam);
					if(roleDesc != null && roleDesc.length() > 0 ) {
						roleNameValue.put(rlNm, roleDesc);
					}
				}
				log.info("Completed Role Description for  : "+roleNameValue.size()+" Records.");

				// START - Store Raw Data into USER2ROLE_RAWDATA
				if("R".equals(calledBy)) {
					saveUser2RoleRawData(usrRoleMap, roleNameValue, templSysParam);
				}
				// END - Store Raw Data into USER2ROLE_RAWDATA

				log.info("Getting Active Users First Name/Last Name for "+templSysParam+" : "+usrRoleMap.size()+" Users.");
				for(String usr : usrRoleMap.keySet()) {
					UserSearchModel srchUsr = getUserStatusJJEDS(usr, 1);
					String[] sysInfoArr = templSysParam.split("_");
					List<String> usrRolesLst = usrRoleMap.get(usr);
					if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
						for(String rls:usrRolesLst) {
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId(rls);
							usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls).trim()));
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							//Logic added to replace role desc for roles not found
							String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
							if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
								rlDesc = usrMdl.getRoleId();
							}
							//END
							usrMdl.setPrimaryReviewInfo2(rlDesc);
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}else {//No Roles for the USER
						SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
						usrMdl.setRevUserId("");
						usrMdl.setUserId(usr);
						usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
						usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
						usrMdl.setRoleId("");
						usrMdl.setRoleDesc("");//No Roles Found
						usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
						usrMdl.setPrimaryReviewInfo2("");
						usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
						usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
						usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
						usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
						usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
						allUserData.add(usrMdl);
					}
				}//END - Preparing Role Data here
			}
			log.info("All USER-ROLE Data(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}




	//Region Wise User2Role
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String>templSysParam){
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		Map<String, List<SapGaaUser2RoleModel>> allUser2RoleData = new HashMap<>();
		Calendar startTime, endTime = null;
		for(String sysTempl :templSysParam) {
			LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
			Map<String, List<String>> usrRoleMap = new HashMap<>();
			Map<String, String> roleNameValue = new HashMap<>();
			try{
				List<String> userLst = sAPExtrGaaDao.getAllValidUsers(sysTempl);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					for(String usr:userLst) {
						List<String> usrRoles = sAPExtrGaaDao.getUsersRoles(usr, sysTempl);
						if(usrRoles != null && !usrRoles.isEmpty()) {
							for (String usrRole : usrRoles) {
								roleNameValue.put(usrRole, "");
							}

							if(usrRoleMap.containsKey(usr)) {
								List<String> roleList = usrRoleMap.get(usr);
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}else {
								List<String> roleList = new ArrayList<>();
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}
						}
					}
					log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));
					//Getting Role Descriptions for All Unique Role Names
					for(String rlNm : roleNameValue.keySet()) {
						String roleDesc = sAPExtrGaaDao.getRoleDescription(rlNm, sysTempl);
						if(roleDesc != null && roleDesc.length() > 0 ) {
							roleNameValue.put(rlNm, roleDesc);
						}
					}

					for(String usr : usrRoleMap.keySet()) {
						UserSearchModel srchUsr = getUserStatusJJEDS(usr, 1);
						String[] sysInfoArr = sysTempl.split("_");
						List<String> usrRolesLst = usrRoleMap.get(usr);
						if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
							for(String rls:usrRolesLst) {
								SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
								usrMdl.setRevUserId("");
								usrMdl.setUserId(usr);
								usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
								usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
								usrMdl.setRoleId(rls);
								usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls)));
								usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
								//Logic added to replace role desc for roles not found
								String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
								if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
									rlDesc = usrMdl.getRoleId();
								}
								//END
								usrMdl.setPrimaryReviewInfo2(rlDesc);
								usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
								usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
								usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
								usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
								usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
								allUserData.add(usrMdl);
							}
						}else {//No Roles for the USER
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId("");
							usrMdl.setRoleDesc("");//No Roles Found
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							usrMdl.setPrimaryReviewInfo2("");
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}//END - Preparing Role Data here
				}
				allUser2RoleData.put(sysTempl, allUserData);
			} catch (Exception e) {
				log.error("Error:"+e.getMessage(), e);
			}
		}
		return allUser2RoleData;
	}

	/* TRANFER CONTROL DATA INDIVIDUAL SYSTEMS
	 * @see com.jnj.rqc.service.SAPExtrGaaDataService#readSAPGaaUserAccessData(java.lang.String)
	 */
	@Override
	public List<SAPUserAccessModel> readSAPGaaUserAccessData(String templSysParam) {
		LinkedList<SAPUserAccessModel> allUserData = new LinkedList<>();

		Map<String, List<String>> usrRoleMap = new HashMap<>();
		Map<String, String> roleNameValue = new HashMap<>();
		try {
			log.info("Getting User Data from USR02 for System: "+templSysParam);
			List<SAPUserAccessModel> userLst = sAPExtrGaaDao.getValidUsersWithDate(templSysParam);//Get All Users for the given System
			log.info("Total Records for User Data from USR02 ("+(userLst !=null? userLst.size():"0")+" for System: "+templSysParam);
			if(userLst != null && !userLst.isEmpty()) {
				//log.info("Populating WWID for Template Name : "+templSysParam+" Started");
				int i=0;
				for(SAPUserAccessModel usr:userLst) {
					String usrSapId = usr.getSapId();
					log.info((++i)+". Populating WWID for Template Name : "+templSysParam+" usrSapId: "+usrSapId);
					if(usrSapId.toUpperCase().equals(usrSapId.toLowerCase())) {
						usr.setWwid(usrSapId);
					}else {
						UserSearchModel ursMdl = getUserStatusJJEDS(usrSapId, 1);//Changes Recommended by Prem & Vinod on 08/20/2021
						usr.setWwid((ursMdl!=null)? ursMdl.getWwId() : "" );
						//Changes Recommended by Prem & Vinod on 08/20/2021
						//String prsnNum = sAPExtrGaaDao.getUsersPersonNumber(usr.getSapId(), templSysParam);
						//usr.setPersonNumber(prsnNum);
						//String wwid = sAPExtrGaaDao.getUsersWwId(usr.getPersonNumber(), templSysParam);
						//usr.setWwid(wwid);
					}
				}
				//log.info("Populating Person Number and WWID for Template Name : "+templSysParam +" Completed");
			}
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			for(SAPUserAccessModel usrMdl:userLst) {
				usrMdl.setSapPlatform("SAP "+systemInfo[1]);
				usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
				usrMdl.setDescription("Access has been granted in the SAP "+systemInfo[1]+"-"+Utility.getSapClientName(systemInfo[2])+" System application. If the user no longer needs access to this system then please select REVOKE");
				String pltInfo =Utility.getSapPlatformInfo(systemInfo[1]).equals(systemInfo[1])? "Access is Granted in SAP "+systemInfo[1]:Utility.getSapPlatformInfo(systemInfo[1]) ;
				usrMdl.setDetails(pltInfo);
				if(!allUserData.contains(usrMdl)) {
					allUserData.add(usrMdl);
				}
			}
			log.info("All User ROLE Data for "+systemInfo[1]+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}



	@Override
	public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeSapGaaUser2RoleCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public String writeSapGaaUserAccessCSV(List<SAPUserAccessModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public String writeRegTrfCntrlCSV(Map<String, LinkedList<SAPUserAccessModel>> data, String fileName) {
		String filePath = "";
		List<SAPUserAccessModel> trfList = new ArrayList<>();
		for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry :data.entrySet() ) {
			trfList.addAll(entry.getValue());
		}
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(trfList, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	//GETTING REGION-WISE DATA

	@Override
	public Map<String, LinkedList<SAPUserAccessModel>> readSAPTrfContolRegionData(List<String> templSysParam) {
		Map<String, LinkedList<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		int i=1;
		Calendar startTime, endTime = null;

		for(String sysTemp:templSysParam) {//For loop - PER SYSTEM - START
			LinkedList<SAPUserAccessModel> allUserData = new LinkedList<>();
			startTime = Calendar.getInstance();
			log.info("****START  Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
			Map<String, List<String>> usrRoleMap = new HashMap<>();
			Map<String, String> roleNameValue = new HashMap<>();
			try{
				List<SAPUserAccessModel> userLst = sAPExtrGaaDao.getValidUsersWithDate(sysTemp);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Started");
					for(SAPUserAccessModel usr:userLst) {
						String prsnNum = sAPExtrGaaDao.getUsersPersonNumber(usr.getSapId(), sysTemp);
						usr.setPersonNumber(prsnNum);
						String wwid = sAPExtrGaaDao.getUsersWwId(prsnNum, sysTemp);
						usr.setWwid(wwid);
					}
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Completed");
				}
				//Preparing USER ACCESS DATA
				String[] systemInfo = sysTemp.split("_");
				for(SAPUserAccessModel usrMdl:userLst) {
					usrMdl.setSapPlatform("SAP "+systemInfo[1]);
					usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
					usrMdl.setDescription("Access has been granted in the SAP "+systemInfo[1]+"-"+(Utility.getSapClientName(systemInfo[2]))+" System application. If the user no longer needs access to this system then please select REVOKE");
					String pltInfo = Utility.getSapPlatformInfo(systemInfo[1]).equals(systemInfo[1])? "Access is Granted in SAP "+systemInfo[1]:Utility.getSapPlatformInfo(systemInfo[1]) ;
					usrMdl.setDetails(pltInfo);
					allUserData.add(usrMdl);
				}
				log.info("All User ROLE Data for System: "+sysTemp+" (size) :"+allUserData.size()+" Completed");
			} catch (Exception e) {
				log.error("Error (System: "+sysTemp+"):"+e.getMessage(), e);
			}
			endTime=Calendar.getInstance();
			log.info("****END  Compute Data for System : "+templSysParam+" - Start time: "+endTime+" Total time taken: "+((endTime.getTimeInMillis() -startTime.getTimeInMillis()/1000) )+" Seconds  *****");
			regionDataMap.put(sysTemp, allUserData);
		}////For loop - PER SYSTEM - END
		return regionDataMap;
	}



	@Override
	public int exportTrfCntrlDataGenesis(Map<String, LinkedList<SAPUserAccessModel>> regDataMap, HttpServletRequest request) {
		int totalRecords = 0;
		String region = "";
		try{
			for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry:regDataMap.entrySet()) {
				String sysDetail=entry.getKey();
				region=sysDetail.split("_")[0];
				List<SAPUserAccessModel> dataList = entry.getValue();
				log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
				if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
					int recordsIns = genesisDao.insertTrfCntrlData(dataList);
					totalRecords = totalRecords+recordsIns;
				}else {
					int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
					int startPos = 0;
					int endPos = Constants.GEN_BATCH_SIZE;
					for(int i=0; i<pgCnt;i++) {
						List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
						int recordsIns = genesisDao.insertTrfCntrlData(insData);
						totalRecords = totalRecords +recordsIns;
						startPos = startPos + Constants.GEN_BATCH_SIZE;
						endPos = endPos + Constants.GEN_BATCH_SIZE;
						if(endPos >dataList.size()) {
							endPos = dataList.size();
						}
					}
				}
			}
			log.info("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}






	/**
	 * Method  : SAPExtrGaaDataService.java.readTrfContolRegionSch()
	 *		   :<b>@param activeSchedule
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 12, 2021 2:34:36 PM
	 * Purpose :REGION WISE TRANSFER CONTROL DATA - Initiated by Scheduler
	 * @return : Map<String,List<SAPUserAccessModel>>
	 */
	@Override
	public Map<String, List<SAPUserAccessModel>> startTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP SYSTEMS
			List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
			log.info("TOTAL SAP Platforms in Region "+activeSchedule.getRegion()+" ("+((templSysParams != null && templSysParams.size() > 0)?templSysParams.size():0)+") ");
			if(templSysParams != null && !templSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = readSAPGaaUserAccessData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" Records: ("+trfUserData.size()+") - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> jdeTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_JDE");
			log.info("TOTAL JDE Platforms in Region "+activeSchedule.getRegion()+" ("+((jdeTemplSysParams != null && jdeTemplSysParams.size() > 0)?jdeTemplSysParams.size():0)+") ");
			if(jdeTemplSysParams != null && !jdeTemplSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:jdeTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = jDEExtrDataService.readTransferCntrlData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" Records("+trfUserData.size()+") - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			List<String> hanaTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_HANA");
			log.info("TOTAL HANA Platforms in Region "+activeSchedule.getRegion()+" ("+((hanaTemplSysParams != null && hanaTemplSysParams.size() > 0)?hanaTemplSysParams.size():0)+") ");
			if(hanaTemplSysParams != null && !hanaTemplSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:hanaTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = hANADataService.readUserTrfContrlData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - HANA SYSTEMS

		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	private void saveCriticalSystemSummary(String sysTemp, int totalRecords, String user, String status) {
		try{
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setCreatedRecCount(totalRecords);
			sumMdl.setCreatedDt(new Date());
			sumMdl.setCreatedBy(user);
			sumMdl.setCollStatus(status);
			sAPExtrRegionWiseDao.saveUser2CriticalRoleDataSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Saving Critical Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	private void saveUser2SodSystemSummary(String sysTemp, int totalRecords, String user, String status) {
		try{
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setCreatedRecCount(totalRecords);
			sumMdl.setCreatedDt(new Date());
			sumMdl.setCreatedBy(user);
			sumMdl.setCollStatus(status);
			sAPExtrRegionWiseDao.saveUser2SodDataSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Saving Critical Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	private void saveSystemSummary(String sysTemp, int totalRecords, String user, String status, String transType ) {
		try{
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setCreatedRecCount(totalRecords);
			sumMdl.setCreatedDt(new Date());
			sumMdl.setCreatedBy(user);
			sumMdl.setCollStatus(status);
			if("T".equals(transType)) {
				sAPExtrRegionWiseDao.saveTrfDataSummary(sumMdl);
			}else {
				sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
			}

		} catch (Exception e) {
			log.info("Error Saving Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	@Override
	public Map<String, List<SAPUserAccessModel>> startExportTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("EXPORT- All Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			//START - EXPORT SAP SYSTEMS
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT SAP SYSTEMS

			//START - EXPORT JDE SYSTEMS
			List<String> jdeTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_JDE");
			if(jdeTemplSysParams != null && !jdeTemplSysParams.isEmpty()) {
				for(String sysTemp:jdeTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT JDE SYSTEMS

			//START - EXPORT HANA SYSTEMS
			List<String> hanaTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_HANA");
			if(hanaTemplSysParams != null && !hanaTemplSysParams.isEmpty()) {
				for(String sysTemp:hanaTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT HANA SYSTEMS
		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

	private void updateSystemSummary(String sysTemp, int totalRecords, String user, String expStat, String collStat, String trnsType) {
		try {
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setExpRecCount(totalRecords);
			sumMdl.setExpStatus(expStat);
			sumMdl.setExpDt(new Date());
			sumMdl.setExpBy(user);
			sumMdl.setCollStatus(collStat);
			if("T".equals(trnsType)) {
				sAPExtrRegionWiseDao.updateTrfExportSummary(sumMdl);
			}else {
				sAPExtrRegionWiseDao.updateUser2RoleExportSummary(sumMdl);
			}

		} catch (Exception e) {
			log.info("Error Updating Export Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}

	private void updateCritSystemSummary(String sysTemp, int totalRecords, String user, String expStat, String collStat) {
		try {
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setExpRecCount(totalRecords);
			sumMdl.setExpStatus(expStat);
			sumMdl.setExpDt(new Date());
			sumMdl.setExpBy(user);
			sumMdl.setCollStatus(collStat);
			sAPExtrRegionWiseDao.updateUser2CriticalRoleExportSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Updating Export Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}

	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule) {
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime ;
		startTime = Calendar.getInstance();
		log.info("STARTING USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
		try{
			//START - SAP SYSTEMS
			List<String> templSysParamsSAP = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			log.info("Processing SAP USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
			if(templSysParamsSAP != null && !templSysParamsSAP.isEmpty()) {
				log.info("EXPORT - USER TO CRITICAL ROLE SAP Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsSAP.size()+") ");
				procUser2CriticalRoleExportTemplate(templSysParamsSAP, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion());
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			log.info("Processing JDE USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				log.info("EXPORT - USER TO CRITICAL ROLE JDE Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
				procUser2CriticalRoleExportTemplate(templSysParamsJDE, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion());
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			/*List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHANA.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHANA, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion());
			}*/
			//END - HANA SYSTEMS

			endTime= Calendar.getInstance();
			log.info("COMPLETED USER TO CRITICAL ROLE EXPORT TO GENESIS End Time:"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" in Region "+activeSchedule.getRegion()+" (Total time :"+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" seconds)");
		} catch (Exception e) {
			log.error("ERROR PROCESSING CRITICAL DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}




	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {

		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime ;
		startTime = Calendar.getInstance();
		log.info("STARTING USER TO ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
		try{
			//START - SAP SYSTEMS
			List<String> templSysParamsSAP = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			if(templSysParamsSAP != null && !templSysParamsSAP.isEmpty()) {
				log.info("EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsSAP.size()+") ");
				procUser2RoleExportTemplate(templSysParamsSAP, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion());
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				log.info("EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
				procUser2RoleExportTemplate(templSysParamsJDE, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion());
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHANA.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHANA, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion());
			}
			//END - HANA SYSTEMS

			//START - HCS/BRAVO SYSTEMS
			List<String> templSysParamsHCSBRAVO = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HCSBRAVO");
			if(templSysParamsHCSBRAVO != null && !templSysParamsHCSBRAVO.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HCS/BRAVO Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHCSBRAVO.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHCSBRAVO, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HCS/BRAVO Platform in Region "+activeSchedule.getRegion());
			}
			//END - HCS/BRAVO SYSTEMS


			endTime= Calendar.getInstance();
			log.info("COMPLETED USER TO ROLE EXPORT TO GENESIS End Time:"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" in Region "+activeSchedule.getRegion()+" (Total time :"+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" seconds)");
			/*
  			for(String sysTemp:templSysParamsHANA) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
				List<SapGaaUser2RoleModel> user2RleData = readUser2RoleExportDataTable(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

				if(user2RleData != null && !user2RleData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					int totalInsertedRecords = exportUser2RoleDataToGenesis(user2RleData, sysTemp);
					//Write Summary
					updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "U");
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, user2RleData);
			}*/

		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	private void procUser2CriticalRoleExportTemplate(List<String>regTemplate, TrfCntrlSchModel regSchedule, Map<String, List<SapGaaUser2RoleModel>> regDataMap) throws Exception {
		Calendar startTime, endTime = null;
		for(String sysTemp:regTemplate) {
			startTime = Calendar.getInstance();
			log.info("****START Reading Data from USER_CRITICAL_ROLE_TRANSDATA for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
			List<SapGaaUser2RoleModel> user2RleData = readUser2CriticalRoleExportDataTable(sysTemp);
			endTime = Calendar.getInstance();
			log.info("****END Reading Data from USER_CRITICAL_ROLE_TRANSDATA for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
			if(user2RleData != null && !user2RleData.isEmpty()){
				Calendar insStartTime, insEndTime = null;
				insStartTime = Calendar.getInstance();
				log.info("****START EXPORT Transaction USER TO CRITICAL ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(insStartTime.getTime())+"  *****");
				int totalInsertedRecords = exportUser2CriticalRoleDataToGenesis(user2RleData, sysTemp);
				//Write Summary
				updateCritSystemSummary(sysTemp, totalInsertedRecords, regSchedule.getCreatedBy(), "C", "C");
				insEndTime = Calendar.getInstance();
				log.info("****END  INSERT Transaction USER TO ROLE Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(insEndTime.getTime())+" Total time: ("+((insEndTime.getTimeInMillis() - insStartTime.getTimeInMillis())/1000)+" Sec) *****");
			}
			regDataMap.put(sysTemp, user2RleData);
		}
	}

	private void procUser2RoleExportTemplate(List<String>regTemplate, TrfCntrlSchModel regSchedule, Map<String, List<SapGaaUser2RoleModel>> regDataMap) throws Exception {
		Calendar startTime, endTime = null;
		for(String sysTemp:regTemplate) {
			startTime = Calendar.getInstance();
			log.info("****START Reading Data from USER_ROLE_TRANSDATA for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
			List<SapGaaUser2RoleModel> user2RleData = readUser2RoleExportDataTable(sysTemp);
			endTime = Calendar.getInstance();
			log.info("****END Reading Data from USER_ROLE_TRANSDATA for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
			if(user2RleData != null && !user2RleData.isEmpty()){
				Calendar insStartTime, insEndTime = null;
				insStartTime = Calendar.getInstance();
				log.info("****START EXPORT Transaction USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(insStartTime.getTime())+"  *****");
				int totalInsertedRecords = exportUser2RoleDataToGenesis(user2RleData, sysTemp);
				//Write Summary
				updateSystemSummary(sysTemp, totalInsertedRecords, regSchedule.getCreatedBy(), "C", "C", "U");
				insEndTime = Calendar.getInstance();
				log.info("****END  INSERT Transaction USER TO ROLE Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(insEndTime.getTime())+" Total time: ("+((insEndTime.getTimeInMillis() - insStartTime.getTimeInMillis())/1000)+" Sec) *****");
			}
			regDataMap.put(sysTemp, user2RleData);
		}
	}





	/**
	 * Method  : SAPExtrGaaDataServiceImpl.java.readExpotDatable()
	 *		   :<b>@param templSysParam
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 20, 2021 3:23:31 PM
	 * Purpose : Getting Transfer Control Data to Export to Genesis
	 * @return : List<SAPUserAccessModel>
	 */
	private List<SAPUserAccessModel> readTrfExportDataTable(String templSysParam) {

		List<SAPUserAccessModel> userLst = new LinkedList<>();
		try{
			List<TrfCntrlTransDataMdl> dataLst = sAPExtrRegionWiseDao.getExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisData(dataLst);
			}
			log.info("Total UNIQUE records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}


	private List<SapGaaUser2RoleModel> readUser2RoleExportDataTable(String templSysParam) {
		List<SapGaaUser2RoleModel> userLst = new LinkedList<>();
		try{
			List<SapGaaUser2RoleTransModel> dataLst = sAPExtrRegionWiseDao.getUser2RoleExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisUser2RoleData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}

	private List<SapGaaUser2RoleModel> readUser2CriticalRoleExportDataTable(String templSysParam) {
		List<SapGaaUser2RoleModel> userLst = new LinkedList<>();
		try{
			List<SapGaaUser2RoleTransModel> dataLst = sAPExtrRegionWiseDao.getUser2CriticalRoleExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisUser2RoleData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}

	private List<SapUser2SodModel> readUser2SodExportDataTable(String templSysParam) {
		List<SapUser2SodModel> dataLst = new LinkedList<>();
		try{
			dataLst = sAPExtrRegionWiseDao.getUser2SodExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			log.info("Total records to Export for "+templSysParam+"(size) :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}


	private List<SAPUserAccessModel> buidlGenesisData(List<TrfCntrlTransDataMdl> dataLst) {
		List<SAPUserAccessModel> dList= new ArrayList<>();

		SAPUserAccessModel sapUser = null;
		for(TrfCntrlTransDataMdl trnsMdl : dataLst) {
			sapUser = new SAPUserAccessModel();
			sapUser.setSapId(trnsMdl.getUserNtId());
			//sapUser.setGltgb(gltgb);
			sapUser.setNtId(trnsMdl.getUserNtId());
			//sapUser.setPersonNumber(personNumber);
			sapUser.setWwid(trnsMdl.getWwid());
			sapUser.setSapPlatform(trnsMdl.getPlatform());
			sapUser.setSystemClient(trnsMdl.getSystem());
			sapUser.setDescription(trnsMdl.getDescription());
			sapUser.setDetails(trnsMdl.getDetails());
			if(!dList.contains(sapUser)){
				dList.add(sapUser);
			}
		}
		return dList;
	}


	private List<SapGaaUser2RoleModel> buidlGenesisUser2RoleData(List<SapGaaUser2RoleTransModel> dataLst) {
		List<SapGaaUser2RoleModel> dList= new ArrayList<>();
		SapGaaUser2RoleModel sapUser = null;
		for(SapGaaUser2RoleTransModel trnsMdl : dataLst) {
			sapUser = new SapGaaUser2RoleModel();
			sapUser.setRevUserId("");
			sapUser.setUserId(trnsMdl.getUserId());
			sapUser.setPrimaryReviewInfo1(trnsMdl.getPrimaryReviewInfo1());
			sapUser.setPrimaryReviewInfo2(trnsMdl.getPrimaryReviewInfo2());
			sapUser.setPrimaryReviewInfo3(trnsMdl.getPrimaryReviewInfo3());
			sapUser.setAdditionalInfo1(trnsMdl.getAdditionalInfo1());
			sapUser.setAdditionalInfo2(trnsMdl.getAdditionalInfo2());
			sapUser.setAdditionalInfo3(trnsMdl.getAdditionalInfo3());
			dList.add(sapUser);
		}
		return dList;
	}



	@Override
	public int insertTransferTransactions(List<SAPUserAccessModel> trfUserData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(trfUserData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(trfUserData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(trfUserData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = trfUserData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >trfUserData.size()) {
						endPos = trfUserData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional Transfer Control Data"+e.getMessage(), e);
		}

		return totalRecords;
	}



	@Override
	public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(user2RoleData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2RoleData.size()) {
						endPos = user2RoleData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to ROLE Data"+e.getMessage(), e);
		}

		return totalRecords;
	}


	@Override
	public int insertUser2CriticalRoleTrans(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2CriticalRoleTransData(buidlUser2RoleTransData(user2RoleData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2CriticalRoleTransData(buidlUser2RoleTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2RoleData.size()) {
						endPos = user2RoleData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to CRITICAL ROLE Data"+e.getMessage(), e);
		}

		return totalRecords;
	}


	public int insertUser2SodTrans(List<SapUser2SodModel> dataList, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2SodTransData(dataList, sysTemp, createdUser);
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapUser2SodModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2SodTransData(insData, sysTemp, createdUser);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to SOD Data"+e.getMessage(), e);
		}
		return totalRecords;
	}

	@Override
	public int exportTrfCntrlDataToGenesis(List<SAPUserAccessModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertTrfCntrlData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertTrfCntrlData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR Total Records inserted for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}



	@Override
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2RoleData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2RoleData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User2 Role Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Role records to Genesis for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("ERROR exporting User to Role records to Genesis  for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}


	@Override
	public int exportUser2CriticalRoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2RoleData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2RoleData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User to Critical Role Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Critical Role records to Genesis for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}


	private List<TrfCntrlTransDataMdl> buidlTrfTransData(List<SAPUserAccessModel> insData, String templetParam, String usrScheduled){
		List<TrfCntrlTransDataMdl> dList= new ArrayList<>();
		String[] systemInfo = templetParam.split("_");
		TrfCntrlTransDataMdl trfMdl = null;
		String wwid="";
		for(SAPUserAccessModel sapMdl : insData) {
			trfMdl = new TrfCntrlTransDataMdl();
			trfMdl.setRegion(systemInfo[0]);
			trfMdl.setPlatform(systemInfo[1]);
			trfMdl.setEnvironment(systemInfo[2]);
			trfMdl.setSystem(systemInfo[3]);
			trfMdl.setDescription(sapMdl.getDescription());
			trfMdl.setDetails(sapMdl.getDetails());
			trfMdl.setUserNtId(sapMdl.getSapId());
			//TODO - Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getWwid() != null && sapMdl.getWwid().length() > 16) {
				wwid =sapMdl.getWwid().substring(0, 15);
			}else {
				wwid = sapMdl.getWwid();
			}
			//TODO - END
			trfMdl.setWwid(wwid);
			trfMdl.setCreatedBy(usrScheduled);
			trfMdl.setCreatedDt(new Date());
			dList.add(trfMdl);
		}
		return dList;
	}

	private List<SapGaaUser2RoleTransModel> buidlUser2RoleTransData(List<SapGaaUser2RoleModel> insData, String templetParam, String usrScheduled){
		List<SapGaaUser2RoleTransModel> dList= new ArrayList<>();
		String[] systemInfo = templetParam.split("_");
		SapGaaUser2RoleTransModel usrMdl = null;
		String wwid="";
		for(SapGaaUser2RoleModel sapMdl : insData) {
			usrMdl = new SapGaaUser2RoleTransModel();
			usrMdl.setRegion(systemInfo[0]);
			usrMdl.setPlatform(systemInfo[1]);
			usrMdl.setEnvironment(systemInfo[2]);
			usrMdl.setSystem(systemInfo[3]);
			usrMdl.setRevUserId("");
			//Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getUserId() != null && sapMdl.getUserId().length() > 16) {
				wwid = sapMdl.getUserId().substring(0, 15);
			}else {
				wwid = sapMdl.getUserId();
			}
			//END
			usrMdl.setUserId(wwid);
			usrMdl.setFirstName(sapMdl.getFirstName());
			usrMdl.setLastName(sapMdl.getLastName());
			usrMdl.setRoleId(sapMdl.getRoleId());
			usrMdl.setRoleDesc(sapMdl.getRoleDesc());
			usrMdl.setPrimaryReviewInfo1(sapMdl.getPrimaryReviewInfo1());
			usrMdl.setPrimaryReviewInfo2(sapMdl.getPrimaryReviewInfo2());
			usrMdl.setPrimaryReviewInfo3(sapMdl.getPrimaryReviewInfo3());

			usrMdl.setAdditionalInfo1(sapMdl.getAdditionalInfo1());
			usrMdl.setAdditionalInfo2(sapMdl.getAdditionalInfo2());
			usrMdl.setAdditionalInfo3(sapMdl.getAdditionalInfo3());
			usrMdl.setCreatedBy(usrScheduled);
			usrMdl.setCreatedDt(new Date());
			usrMdl.setUserStatus(sapMdl.getUserStatus());
			dList.add(usrMdl);
		}
		return dList;
	}

	//Region Wise USER-ROLE Processing
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
    	log.info("All USER To ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP DATA
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = readSapUserToRoleActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - SAP DATA

			//START - JDE DATA
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				for(String sysTemp:templSysParamsJDE) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = jDEExtrDataService.readUser2RoleActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - JDE DATA

			//START - HANA DATA
			List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				for(String sysTemp:templSysParamsHANA) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = hANADataService.readHanaUserGrantActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - HANA DATA

			//START - HCS/BRAVO DATA
			List<String> templSysParamsHCS = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HCSBRAVO");
			if(templSysParamsHCS != null && !templSysParamsHCS.isEmpty()) {
				for(String sysTemp:templSysParamsHCS) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = hCSExtrDataService.readHcsBravoActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - HCS/BRAVO DATA

		} catch (Exception e) {
			log.error("ERROR PROCESSING USER to ROLE DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

//USER TO CRITICAL ROLES REGION WISE
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule) {
		log.info("Processing All Platforms USER To Critical ROLE in Region "+activeSchedule.getRegion());
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP DATA
			List<String> templSysParams = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			log.info("Processing SAP USER To Critical ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> userToRoleData = readSapUserToRoleActData(sysTemp);
					//Start - Filtering Critical Roles
					List<SapGaaUser2RoleModel> criticalRolesLst = getCriticalUser2RoleInfo(userToRoleData);
			    	log.info("Total Records for User to Critical Roles :"+((criticalRolesLst == null || criticalRolesLst.isEmpty())? 0:criticalRolesLst.size()));
					//End - Filtering Critical Roles
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(criticalRolesLst != null && !criticalRolesLst.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Critical Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2CriticalRoleTrans(criticalRolesLst, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveCriticalSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction User to Critical Roles Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, criticalRolesLst);
				}
			}
			//END - SAP DATA

			//START - JDE DATA
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			log.info("Processing JDE USER To Critical ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				for(String sysTemp:templSysParamsJDE) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO CRITICAL ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> userToRoleData = jDEExtrDataService.readUser2RoleActData(sysTemp);
					//Start - Filtering Critical Roles
					List<SapGaaUser2RoleModel> criticalRolesLst = getCriticalUser2RoleInfo(userToRoleData);
			    	log.info("Total Records for User to Critical Roles :"+((criticalRolesLst == null || criticalRolesLst.isEmpty())? 0:criticalRolesLst.size()));
					//End - Filtering Critical Roles
					endTime = Calendar.getInstance();
					log.info("****END  Compute Critical Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(criticalRolesLst != null && !criticalRolesLst.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Critical Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2CriticalRoleTrans(criticalRolesLst, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveCriticalSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, criticalRolesLst);
				}
			}
			//END - JDE DATA

			//START - HANA DATA

			//START - HANA DATA
		} catch (Exception e) {
			log.error("ERROR PROCESSING USER to CRITICAL ROLE DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

	@Override
	public Map <String, Map<String, List<SapDataTransferReportMdl>>> getGenesisTransferReportData() {
		Map <String, Map<String, List<SapDataTransferReportMdl>>> allDataMap = new HashMap<>();
		Map<String, List<SapDataTransferReportMdl>> repSignedOffMap = new HashMap<>();
		Map<String, List<SapDataTransferReportMdl>> repOthersfMap = new HashMap<>();
		List<String> sysIDs=new ArrayList<>();
		try{
			List<SapDataTransferReportMdl> repLst = genesisDao.getGenesisTransferCtrlReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapDataTransferReportMdl repMdl : repLst ) {
					String pltForm = repMdl.getSapPlatfrom().toUpperCase().trim();
					if(!sysIDs.contains(pltForm)) {sysIDs.add(pltForm);}//Adding all Systems to List
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapDataTransferReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(pltForm)) {
							sOfLst = repSignedOffMap.get(pltForm);
							sOfLst.add(repMdl);
							repSignedOffMap.put(pltForm, sOfLst);
						}else {
							sOfLst = new ArrayList<> ();
							sOfLst.add(repMdl);
							repSignedOffMap.put(pltForm, sOfLst);
						}
					}else {//Other Items
						List<SapDataTransferReportMdl> othLst = null;
						if(repOthersfMap.containsKey(pltForm)) {
							othLst = repOthersfMap.get(pltForm);
							othLst.add(repMdl);
							repOthersfMap.put(pltForm, othLst);
						}else {
							othLst = new ArrayList<> ();
							othLst.add(repMdl);
							repOthersfMap.put(pltForm, othLst);
						}
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersfMap);
			}
			Utility.setCache(Constants.TRF_REPORT_SO_SYSTEMS, sysIDs);//Adding Cache
		} catch (Exception e) {
			log.error("Error Collecting Genesis Transfer Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}


	@Override
	public Map <String, Map<String, List<SapUser2SodReportMdl>>> getGenesisUser2SodReportData() {
		Map <String, Map<String, List<SapUser2SodReportMdl>>> allDataMap = new HashMap<>();
		Map<String, List<SapUser2SodReportMdl>> repSignedOffMap = new HashMap<>();
		Map<String, List<SapUser2SodReportMdl>> repOthersMap = new HashMap<>();
		List<String> sysIDs=new ArrayList<>();
		try{
			List<SapUser2SodReportMdl> repLst = genesisDao.getGenesisUser2SodReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapUser2SodReportMdl repMdl : repLst ) {
					String pltForm = repMdl.getGroupPlatform().toUpperCase().trim();
					if(!sysIDs.contains(pltForm)) {sysIDs.add(pltForm);}//Adding all Systems to List
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapUser2SodReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(pltForm)) {
							sOfLst = repSignedOffMap.get(pltForm);
							sOfLst.add(repMdl);
						}else {
							sOfLst = new ArrayList<> ();
							sOfLst.add(repMdl);
						}
						repSignedOffMap.put(pltForm, sOfLst);
					}else {//Other Items
						List<SapUser2SodReportMdl> othLst = null;
						if(repOthersMap.containsKey(pltForm)) {
							othLst = repOthersMap.get(pltForm);
							othLst.add(repMdl);
						}else {
							othLst = new ArrayList<> ();
							othLst.add(repMdl);
						}
						repOthersMap.put(pltForm, othLst);
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersMap);
			}
			Utility.setCache(Constants.U2S_REPORT_SO_SYSTEMS, sysIDs);//Adding Cache
			//Clear List
			repLst = null;
		} catch (Exception e) {
			log.error("Error Collecting Genesis USER TO SOD Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}

	@Override
	public List<String> getGenesisUser2RoleReportSystems(){
		List<String> sysIDs=new ArrayList<>();
		try{
			sysIDs = genesisDao.getGenesisUser2RoleSysData();
		} catch (Exception e) {
			log.error("Error Collecting Genesis USER TO ROLE Report System Data :"+e.getMessage(), e);
		}
		return sysIDs;
	}



	@Override
	public Map <String, List<SapUser2RoleReportMdl>> getGenesisUser2RoleReportPlatformData(String platform) {
		Map <String, List<SapUser2RoleReportMdl>> allDataMap = new HashMap<>();
		List<SapUser2RoleReportMdl> sOfLst = new ArrayList<> ();
		List<SapUser2RoleReportMdl> othLst = new ArrayList<> ();
		try{
			List<SapUser2RoleReportMdl> repLst = genesisDao.getGenesisUser2RolePlatformReportData(platform);
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapUser2RoleReportMdl repMdl : repLst ) {
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						sOfLst.add(repMdl);
					}else {//Other Items
						othLst.add(repMdl);
					}
				}
				allDataMap.put("SIGNED_ITEMS", sOfLst);
				allDataMap.put("OTHER_ITEMS", othLst);
			}
		} catch (Exception e) {
			log.error("Error Collecting Genesis USER TO ROLE Report Data for Platform("+platform+") :"+e.getMessage(), e);
		}
		return allDataMap;
	}



	@Override
	public Map <String, Map<String, List<SapUser2RoleReportMdl>>> getGenesisUser2RoleReportData() {
		Map <String, Map<String, List<SapUser2RoleReportMdl>>> allDataMap = new HashMap<>();
		Map<String, List<SapUser2RoleReportMdl>> repSignedOffMap = new HashMap<>();
		Map<String, List<SapUser2RoleReportMdl>> repOthersfMap = new HashMap<>();
		List<String> sysIDs=new ArrayList<>();
		try{
			List<SapUser2RoleReportMdl> repLst = genesisDao.getGenesisUser2RoleReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapUser2RoleReportMdl repMdl : repLst ) {
					String pltForm = repMdl.getGroupPlatform().toUpperCase().trim();
					if(!sysIDs.contains(pltForm)) {sysIDs.add(pltForm);}//Adding all Systems to List
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapUser2RoleReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(pltForm)) {
							sOfLst = repSignedOffMap.get(pltForm);
							sOfLst.add(repMdl);
						}else {
							sOfLst = new ArrayList<> ();
							sOfLst.add(repMdl);
						}
						repSignedOffMap.put(pltForm, sOfLst);
					}else {//Other Items
						List<SapUser2RoleReportMdl> othLst = null;
						if(repOthersfMap.containsKey(pltForm)) {
							othLst = repOthersfMap.get(pltForm);
							othLst.add(repMdl);
						}else {
							othLst = new ArrayList<> ();
							othLst.add(repMdl);
						}
						repOthersfMap.put(pltForm, othLst);
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersfMap);
			}
			Utility.setCache(Constants.U2R_REPORT_SO_SYSTEMS, sysIDs);//Adding Cache
			//Clear Memory
			repLst = null;
			//End
		} catch (Exception e) {
			log.error("Error Collecting Genesis USER TO ROLE Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}

	@Override
	public String writeLogData(StringBuilder data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 writer.writeNext(new String[]{ data.toString()});
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing Log Data: "+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	@Override
	public Map <String, List<SapUser2RoleDeltaMdl>> getGenesisUser2RoleData(List<String> users) {
		Map <String, List<SapUser2RoleDeltaMdl>> allDataMap = new HashMap<>();
		Map<String, String> usrMap=new HashMap<>();
		Date reportDate = new Date();
		try{
			List<SapUser2RoleDeltaMdl> repLst = new ArrayList<>();
			if(users.size() <= Constants.GEN_BATCH_SIZE) {
				repLst = genesisDao.getGenesisUser2RoleData(users);
			}else {
				int pgCnt = Utility.getPageCount(users.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<String> qryLst = users.subList(startPos, endPos);
					repLst.addAll(genesisDao.getGenesisUser2RoleData(qryLst));
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >users.size()) {
						endPos = users.size();
					}
				}
			}
			for(String id:users) {
				UserSearchModel srchUsr=this.getUserStatusJJEDS(id, 0);
				if(srchUsr != null) {
					usrMap.put(id, srchUsr.getEmpStatTxt());
				}else {
					usrMap.put(id, "NOT FOUND");
				}
			}

			if(repLst != null && !repLst.isEmpty() ) {
				List<SapUser2RoleDeltaMdl> dataLst = null;
				for(SapUser2RoleDeltaMdl repMdl : repLst ) {
					String pltForm = repMdl.getAdditionalInfo1().toUpperCase().trim();
					String usrId = repMdl.getUserId().trim();
					repMdl.setUserStatus(usrMap.get(usrId));
					repMdl.setReportDate(reportDate);
					if(allDataMap.containsKey(pltForm)) {
						dataLst = allDataMap.get(pltForm);
						dataLst.add(repMdl);
					}else {
						dataLst = new ArrayList<>();
						dataLst.add(repMdl);
					}
					allDataMap.put(pltForm, dataLst);
				}
			}
			log.info("Total Platforms returned for USER2ROLE Delta: "+(!allDataMap.isEmpty()? allDataMap.size():"0"));
		} catch (Exception e) {
			log.error("ERROR Collecting Genesis USER TO ROLE Data for Delta comparison :"+e.getMessage(), e);
		}
		return allDataMap;
	}


	@Override
	public Map <String, List<SapUser2SodDeltaMdl>> getGenesisUser2SodData(List<String> users) {
		Map <String, List<SapUser2SodDeltaMdl>> allDataMap = new HashMap<>();
		Map<String, String> usrMap=new HashMap<>();
		Date reportDate = new Date();
		try{
			List<SapUser2SodDeltaMdl> repLst = new ArrayList<>();
			if(users.size() <= Constants.GEN_BATCH_SIZE) {
				repLst = genesisDao.getGenesisUser2SodData(users);
			}else {
				int pgCnt = Utility.getPageCount(users.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<String> qryLst = users.subList(startPos, endPos);
					repLst.addAll(genesisDao.getGenesisUser2SodData(qryLst));
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >users.size()) {
						endPos = users.size();
					}
				}
			}
			Map<String, UserSearchModel> srchMap = new HashMap<>();
			for(String id:users) {
				UserSearchModel srchUsr = null;
				if(srchMap.containsKey(id)) {
					srchUsr = srchMap.get(id);
				}else {
					srchUsr = this.getUserStatusJJEDS(id, 0);
					srchMap.put(id, srchUsr);
				}

				if(srchUsr != null) {
					usrMap.put(id, srchUsr.getEmpStatTxt());
				}else {
					usrMap.put(id, "NOT FOUND");
				}
			}
			srchMap = null;

			if(repLst != null && !repLst.isEmpty() ) {
				List<SapUser2SodDeltaMdl> dataLst = null;
				for(SapUser2SodDeltaMdl repMdl : repLst ) {
					String pltForm = repMdl.getPlatformName().toUpperCase().trim();
					String usrId = repMdl.getUserId().trim();
					repMdl.setUserStatus(usrMap.get(usrId));
					repMdl.setReportDate(reportDate);
					if(allDataMap.containsKey(pltForm)) {
						dataLst = allDataMap.get(pltForm);
						dataLst.add(repMdl);
					}else {
						dataLst = new ArrayList<>();
						dataLst.add(repMdl);
					}
					allDataMap.put(pltForm, dataLst);
				}
			}
			log.info("Total Platforms returned for USER2SOD Delta: "+(!allDataMap.isEmpty()? allDataMap.size():"0"));
		} catch (Exception e) {
			log.error("ERROR Collecting Genesis USER TO SOD Data for Delta comparison :"+e.getMessage(), e);
		}
		return allDataMap;
	}






	@Override
	public List<SapU2RDeltaSummaryMdl> getUser2RoleSummaryDeltaData(String type){
		List<SapU2RDeltaSummaryMdl> allDataLst = new ArrayList<>();
		try{
			allDataLst = genesisDao.getGenesisUserWiseCounts(type);
			log.info("USER2ROLE Delta summary size: "+(!allDataLst.isEmpty()? allDataLst.size():"0"));
		} catch (Exception e) {
			log.error("ERROR getting USER2ROLE Delta summary :"+e.getMessage(), e);
		}
		return allDataLst;
	}

	@Override
	public List<SapU2RDeltaSummaryMdl> getUser2SodSummaryDeltaData(String type){
		List<SapU2RDeltaSummaryMdl> allDataLst = new ArrayList<>();
		try{
			allDataLst = genesisDao.getGenesisUser2SodDataCounts(type);
			log.info("USER2SOD Delta summary size: "+(!allDataLst.isEmpty()? allDataLst.size():"0"));
		} catch (Exception e) {
			log.error("ERROR getting USER2SOD Delta summary :"+e.getMessage(), e);
		}
		return allDataLst;
	}


	@Override
	public int checkDeltaRecord(SapUser2RoleDeltaMdl rec2Check) {
		int recCount=0;
		try{
			recCount = genesisDao.checkUser2RoleReportRecord(rec2Check.getUserId(), rec2Check.getPrimaryReviewInfo3(), rec2Check.getAdditionalInfo3());
		} catch (Exception e) {
			log.error("ERROR Collecting Genesis USER TO ROLE Data for Delta comparison :"+e.getMessage(), e);
		}
		return recCount;
	}



	@Override
	public List<SapGaaUser2RoleModel> getCriticalUser2RoleInfo(List<SapGaaUser2RoleModel> activeTrfData) {
		List<SapGaaUser2RoleModel> critalU2RLst = new ArrayList<>();
		Map<String, String> userToCriticalRoleMatrix = sAPExtrRegionWiseService.loadAllCriticalRoles();
		if(activeTrfData != null && !activeTrfData.isEmpty()) {
			for(SapGaaUser2RoleModel crMdl : activeTrfData) {
				String crKey=crMdl.getAdditionalInfo1().toUpperCase().trim()+"_"+crMdl.getAdditionalInfo3().toUpperCase().trim();
				if(userToCriticalRoleMatrix.containsKey(crKey)) {
					critalU2RLst.add(crMdl);
				}
			}
		}
		return critalU2RLst;
	}



	@Override
	public String clearUser2RoleDelta() {
		String result= "";
		try{
			result = sAPExtrRegionWiseDao.clearDeltaData();
			log.info("Cleared Delta User2Role: "+result);
		} catch (Exception e) {
			log.error("ERROR Clearing USER2ROLE Delta :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public String clearUser2SodDelta() {
		String result= "";
		try{
			result = sAPExtrRegionWiseDao.clearUser2SodDeltaData();
			log.info("Cleared Delta User2Sod: "+result);
		} catch (Exception e) {
			log.error("ERROR Clearing USER2SOD Delta :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public String writeSapGaaUser2RoleXLS(List<SapGaaUser2RoleModel> data, String fileName, String sheetNm) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeSapGaaUser2RoleExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), sheetNm);
		} catch (Exception e) {
			log.error("Error Writing Excel:"+e.getMessage(), e);
		}

		return filePath;
	}


	@Override
	public List<TrfCntrlTransDataMdl> getAllTrfControlExportableData(String regn) {
		List<TrfCntrlTransDataMdl> dataLst = new ArrayList<>();
		try{
			dataLst = sAPExtrRegionWiseDao.getAllTRFCntrlExportableData(regn);
			log.info("Total records to Download for Region("+regn+") :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn){
		List<SapGaaUser2RoleTransModel> dataLst = new ArrayList<>();
		try{
			dataLst = sAPExtrRegionWiseDao.getAllUser2RoleExportableData(regn);
			log.info("Total records to Download for Region("+regn+") :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public List<SapUser2SodTrnsModel> getAllUser2SodExportableData(String regn){
		List<SapUser2SodTrnsModel> dataLst = new ArrayList<>();
		try{
			dataLst = sAPExtrRegionWiseDao.getAllUser2SodExportableData(regn);
			log.info("Total records to Download for Region("+regn+") :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public UserSearchModel getUserStatusJJEDSByFnLn(String firstNm, String lastNm, int active) {
		String fname = firstNm.toUpperCase().trim();
		String lname = lastNm.toUpperCase().trim();
		UserSearchModel srchUsr = Utility.getUser(fname+"_"+lname);
		if(srchUsr == null){
			List<UserSearchModel> usrList = userSearchService.getUserDataByFN(fname, lname, active);
			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(srchUsr.getWwId(), srchUsr);
				Utility.setUser(fname+"_"+lname, srchUsr);
			}
		}
		return srchUsr;
	}

	@Override
	public UserSearchModel getUserStatusJJEDS(String userId, int active) {
		userId= userId.toUpperCase();
		UserSearchModel srchUsr = Utility.getUser(userId);
		if(srchUsr == null){
			List<UserSearchModel> usrList = getUserListFromJJEDS(userId, active);
			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(userId, srchUsr);
			}/*else {
				Utility.setUser(userId, srchUsr);
			}*/
		}
		return srchUsr;
	}


	@Override
	public List<UserSearchModel> getUserListFromJJEDS(String userId, int active) {
		List<UserSearchModel> usrList= null;
		userId= userId.toUpperCase();
		if(userId.toUpperCase().equals(userId.toLowerCase())) {
			usrList = userSearchService.getUserData(1, userId, active);
		}else {
			usrList = userSearchService.getUserData(2, userId, active);
		}
		return usrList;
	}


	//USER 2 SOD

	@Override
	public Map<String, List<SapUser2SodModel>> startUser2SodRegionSch(TrfCntrlSchModel activeSchedule) {
		log.info("Processing All Platforms USER To Critical ROLE in Region "+activeSchedule.getRegion());
		Map<String, List<SapUser2SodModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			List<String> templSysParams = Utility.loadUser2SodProperty("REGION_"+activeSchedule.getRegion());
			log.info("Processing USER TO SOD in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO SOD Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					Map<String, List<SapUser2SodModel>> user2SodDataMap = user2SodDataService.prepareUser2SodData(sysTemp);
					List<SapUser2SodModel> validUser2SodList = null;
					List<SapUser2SodModel> inValidUser2SodList = null;
					if(user2SodDataMap.containsKey("VAL_U2S")) {
						validUser2SodList = user2SodDataMap.get("VAL_U2S");
					}
					if(user2SodDataMap.containsKey("INV_U2S")) {
						inValidUser2SodList = user2SodDataMap.get("INV_U2S");
						if(inValidUser2SodList != null && !inValidUser2SodList.isEmpty()) {
							sendInvldUser2SodDataEmail(sysTemp, inValidUser2SodList);
						}

					}
					log.info("Total Records for USER TO SOD :"+((validUser2SodList == null || validUser2SodList.isEmpty())? 0:validUser2SodList.size()));
					//End - Filtering Critical Roles
					endTime = Calendar.getInstance();
					log.info("****END  Compute USER2SOD Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(validUser2SodList != null && !validUser2SodList.isEmpty()) {
						//Insert in Transaction Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT USER TO SOD Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2SodTrans(validUser2SodList, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveUser2SodSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction User to Sod Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, validUser2SodList);
				}
			}
		} catch (Exception e) {
			log.error("ERROR PROCESSING USER TO SOD DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	@Override
	public Map<String, List<SapUser2SodModel>> startExportUser2SodRegionSch(TrfCntrlSchModel activeSchedule) {
		Map<String, List<SapUser2SodModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime ;
		startTime = Calendar.getInstance();
		log.info("STARTING USER TO SOD EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
		try{
			//START - SAP SYSTEMS
			List<String> templSysParamsSAP = Utility.loadUser2SodProperty("REGION_"+activeSchedule.getRegion());
			log.info("Processing SAP USER TO SOD EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
			if(templSysParamsSAP != null && !templSysParamsSAP.isEmpty()) {
				log.info("EXPORT - USER TO SOD in Region "+activeSchedule.getRegion()+" ("+templSysParamsSAP.size()+") ");
				procUser2SodExportTemplate(templSysParamsSAP, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO SOD in Region "+activeSchedule.getRegion());
			}
			//END - SAP SYSTEMS
			endTime= Calendar.getInstance();
			log.info("COMPLETED USER TO SOD EXPORT TO GENESIS End Time:"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" in Region "+activeSchedule.getRegion()+" (Total time :"+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" seconds)");
		} catch (Exception e) {
			log.error("ERROR PROCESSING USER TO SOD DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	private void procUser2SodExportTemplate(List<String>regTemplate, TrfCntrlSchModel regSchedule, Map<String, List<SapUser2SodModel>> regDataMap) throws Exception {
		Calendar startTime, endTime = null;
		for(String sysTemp:regTemplate) {
			startTime = Calendar.getInstance();
			log.info("****START Reading Data from USER2SOD_TRANSDATA for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
			List<SapUser2SodModel> user2SodData = readUser2SodExportDataTable(sysTemp);
			endTime = Calendar.getInstance();
			log.info("****END Reading Data from USER2SOD_TRANSDATA for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
			if(user2SodData != null && !user2SodData.isEmpty()){
				Calendar insStartTime, insEndTime = null;
				insStartTime = Calendar.getInstance();
				log.info("****START EXPORT Transaction USER TO SOD Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(insStartTime.getTime())+"  *****");
				int totalInsertedRecords = exportUser2SodDataToGenesis(user2SodData, sysTemp);//CHANGE
				//Write Summary
				updateU2SSystemSummary(sysTemp, totalInsertedRecords, regSchedule.getCreatedBy(), "C", "C");
				insEndTime = Calendar.getInstance();
				log.info("****END  INSERT Transaction USER TO SOD Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(insEndTime.getTime())+" Total time: ("+((insEndTime.getTimeInMillis() - insStartTime.getTimeInMillis())/1000)+" Sec) *****");
			}
			regDataMap.put(sysTemp, user2SodData);
		}
	}

	private void updateU2SSystemSummary(String sysTemp, int totalRecords, String user, String expStat, String collStat) {
		try {
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setExpRecCount(totalRecords);
			sumMdl.setExpStatus(expStat);
			sumMdl.setExpDt(new Date());
			sumMdl.setExpBy(user);
			sumMdl.setCollStatus(collStat);
			sAPExtrRegionWiseDao.updateUser2SodExportSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Updating Export Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	@Override
	public int exportUser2SodDataToGenesis(List<SapUser2SodModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2SodData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapUser2SodModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2SodData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User to Sod Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Sod records to Genesis for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}



	/* USER TO ROLE RAW DATA INSERTION STARTS HERE*/

	@Override
	public void saveUser2RoleAllRawData(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp){
			int totalRecords = 0;
			try{
				if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
					int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransRawData(buidlUser2RoleTransData(user2RoleData, sysTemp, ""));
					totalRecords = totalRecords+recordsIns;
				}else {
					int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
					int startPos = 0;
					int endPos = Constants.GEN_BATCH_SIZE;
					for(int i=0; i<pgCnt;i++) {
						List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
						int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransRawData(buidlUser2RoleTransData(insData, sysTemp, ""));
						totalRecords = totalRecords +recordsIns;
						startPos = startPos + Constants.GEN_BATCH_SIZE;
						endPos = endPos + Constants.GEN_BATCH_SIZE;
						if(endPos >user2RoleData.size()) {
							endPos = user2RoleData.size();
						}
					}
				}
			} catch (Exception e) {
				log.error("Error inserting Transactional USER to ROLE Data"+e.getMessage(), e);
			}

			log.info("TOTAL USER TO ROLE DATA RECORDS(RAW):"+user2RoleData.size()+" TOTAL INSERTED :"+totalRecords);

	}




	@Override
	public void saveUser2RoleRawData(Map<String, List<String>> usrRoleMap, Map<String, String> roleNameValue, String templSysParam){
		List<User2RoleRawDataMdl> allUserData = new ArrayList<>();
		String[] sysInfoArr = templSysParam.split("_");
		for(String usr : usrRoleMap.keySet()) {
			List<String> usrRolesLst = usrRoleMap.get(usr);
			if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
				for(String rls:usrRolesLst) {
					User2RoleRawDataMdl usrMdl = new User2RoleRawDataMdl();
					usrMdl.setRegion(sysInfoArr[0]);
					usrMdl.setPlatform(sysInfoArr[1]);
					usrMdl.setEnvironment(sysInfoArr[2]);
					usrMdl.setSystem(sysInfoArr[3]);
					usrMdl.setUserId(usr);
					usrMdl.setRoleId(rls);
					usrMdl.setRoleDesc(((roleNameValue.isEmpty() || roleNameValue.get(rls) == null) ? "":roleNameValue.get(rls)));
					allUserData.add(usrMdl);
				}
			}else{//No Roles for the USER
				User2RoleRawDataMdl usrMdl = new User2RoleRawDataMdl();
				usrMdl.setRegion(sysInfoArr[0]);
				usrMdl.setPlatform(sysInfoArr[1]);
				usrMdl.setEnvironment(sysInfoArr[2]);
				usrMdl.setSystem(sysInfoArr[3]);
				usrMdl.setUserId(usr);
				usrMdl.setRoleId("NO ROLES");
				usrMdl.setRoleDesc("NO ROLES");
				allUserData.add(usrMdl);
			}
		}
		//Insert Data
		if(!allUserData.isEmpty()) {
			int totalRec = insertUser2RoleRawData(allUserData);
			log.info("TOTAL RAW DATA for System ("+templSysParam+") :"+allUserData.size()+"  INSERTED: "+totalRec);
		}
	}

	@Override
	public int insertUser2RoleRawData(List<User2RoleRawDataMdl> rawDataList){
		int totalRecords = 0;
		try{
			if(rawDataList.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleRawData(rawDataList);
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(rawDataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<User2RoleRawDataMdl> insData = rawDataList.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleRawData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >rawDataList.size()) {
						endPos = rawDataList.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting USER to ROLE RAW Data"+e.getMessage(), e);
		}
		return totalRecords;
	}


	@Override
	public int getU2RReportSeq(String finalEml) {
		int seq = 0;
		try{
			seq = sAPExtrRegionWiseDao.getUer2RoleSeq((("1".equals(finalEml))? "FINAL-"+Constants.U2R_REPORT:Constants.U2R_REPORT));//ERP USER TO ROLE REPORT
		} catch (Exception e) {
			log.error("ERROR Getting SEQ ID for ("+(("1".equals(finalEml))? "FINAL-"+Constants.U2R_REPORT:Constants.U2R_REPORT)+") :"+e.getMessage(), e);
		}
		return seq;
	}



	@Override
	public int saveU2RRepPlatformEmailLog(int seq, List<String> sysIDs, String triggeredBy, String report) {
		int totalRecs = 0;
		try{
			totalRecs = sAPExtrRegionWiseDao.saveU2RRepPlatformEmailLog(seq, sysIDs, report, triggeredBy) ;
			log.info("Total Records Saved for Seq:"+seq+" Rep: "+report+" : "+totalRecs);
		} catch (Exception e) {
			log.error("ERROR Saving Initial ("+Constants.U2R_REPORT+") Data:"+e.getMessage(), e);
		}
		return totalRecs;
	}

	@Override
	public List<IAMRolesADGrpMdl> readPFBUserRolesADGrpData(String templSysParam, String userId) {
		List<IAMRolesADGrpMdl> allUserData = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID:"+userId);
			allUserData = sAPExtrGaaDao.getPFBUserRoleADGrps(templSysParam, userId);//Get All Users for the given System
			log.info("Total Records for User ROles from  ("+(allUserData !=null? allUserData.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}

	@Override
	public List<String> readPFICFINUserRolesPosnData(String templSysParam, String userId) {
		List<String> cfinRoles = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID:"+userId);
			cfinRoles = sAPExtrGaaDao.getPFIUserRoleADGrps(templSysParam, userId);//Get All Users for the given System
			log.info("Total Records for User Roles from  ("+(cfinRoles !=null? cfinRoles.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cfinRoles;
	}



	@Override
	public List<U2REmailLogMdl> getWeeklyU2RReportDetails() {
		List<U2REmailLogMdl> repList= new ArrayList<>();
		try{
			repList = sAPExtrRegionWiseDao.getU2RWeeklyLogDetails();
		} catch (Exception e) {
			log.error("Error Getting USER TO ROLE Weekly Report summary : "+e.getMessage(), e);
		}
		return repList;
	}


	@Override
	public List<U2REmailLogMdl> getWeeklyU2RReportData(int seqId) {
		List<U2REmailLogMdl> repList= new ArrayList<>();
		try{
			repList = sAPExtrRegionWiseDao.getU2RWeeklyLogData(seqId);
		} catch (Exception e) {
			log.error("Error Getting USER TO ROLE Weekly Report Data : "+e.getMessage(), e);
		}
		return repList;
	}



	@Override
	public int updWeeklyReportStatus(int seqIdParam, String platform, String userId) {
		int recordsIns = 0;
		try{
			recordsIns = sAPExtrRegionWiseDao.updateWeeklyRptStatus(seqIdParam, platform, userId);
		} catch (Exception e) {
			log.error("Error Updating status for seqIdParam:"+seqIdParam+" platform : "+platform+"\n"+e.getMessage(), e);
		}
		return recordsIns;
	}



	@Override
	public List<String> readGRCSYSUserRolesPosnData(String templSysParam, String userId) {
		List<String> grcRoles = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID: "+userId);
			grcRoles = sAPExtrGaaDao.getGRCUserRoleADGrps(templSysParam, userId);//Get All Users for the given System
			log.info("Total Records for User Roles from  ("+(grcRoles !=null? grcRoles.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return grcRoles;
	}


	@Override
	public List<String> readAnaplanSYSUserRolesData(String templSysParam, String userId) {
		List<String> scmRoles = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID: "+userId);
			scmRoles = sAPExtrGaaDao.getGRCUserRoleADGrps(templSysParam, userId);//Get All Users for the given System
			log.info("Total Records for User Roles from  ("+(scmRoles !=null? scmRoles.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return scmRoles;
	}




}
