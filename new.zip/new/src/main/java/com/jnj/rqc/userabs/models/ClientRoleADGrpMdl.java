package com.jnj.rqc.userabs.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClientRoleADGrpMdl {
	private String client;
	private String user;
	private String ldapADGroup;
	private String mdate;//Modified date

}
