package com.jnj.rqc.mastermetadata.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.mastermetadata.dao.MasterMetaData;
import com.jnj.rqc.mastermetadata.service.ApiResponse;
import com.jnj.rqc.mastermetadata.service.MasterMetaDataService;


@RestController
@RequestMapping("/v2/api/masterdata")
public class MasterMetaDataController {
	static final Logger log = LoggerFactory.getLogger(MasterMetaDataController.class);
    private final MasterMetaDataService mastermetaDataService;

    @Autowired
    public MasterMetaDataController(MasterMetaDataService mastermetaDataService) {
        this.mastermetaDataService = mastermetaDataService;
    }

    @PostMapping("/insert")
    public ResponseEntity<ApiResponse> insertMasterData(@RequestBody MasterMetaData masterData) {
    	log.debug("enter into the method");
        try {
            if (masterData != null && masterData.getRecords() != null && !masterData.getRecords().isEmpty()) {
            	log.info("values received as inputData :"+masterData.getRecords().toString());
            	mastermetaDataService.insertMultipleRecords(masterData.getRecords());
            	 log.debug("end of the method");
            	 ApiResponse response = new ApiResponse(true, "Records inserted successfully.");
            	 return ResponseEntity.status(HttpStatus.CREATED).body(response);
            } else {
            	ApiResponse response = new ApiResponse(false, "No records provided.");
            	return ResponseEntity.status(HttpStatus.CREATED).body(response);
            }

        } catch (Exception e) {
        	log.error("Excepiton : "+e.getMessage());
        	ApiResponse response = new ApiResponse(false, "Error inserting records.");
        	return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
    }
    @DeleteMapping("/delete/all")
    public ResponseEntity<String> deleteAllRows() {
    	log.debug("enter into the method");
        try {
        	mastermetaDataService.deleteAllRows();
        	log.debug("end of the method");
            return ResponseEntity.ok("All rows deleted successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting all rows.");
        }

    }

}
