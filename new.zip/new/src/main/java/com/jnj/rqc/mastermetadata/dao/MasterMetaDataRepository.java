package com.jnj.rqc.mastermetadata.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.mastermetadata.controller.AnaplanRoleModel;
import com.jnj.rqc.mastermetadata.controller.CrossAppRoleModel;
import com.jnj.rqc.mastermetadata.controller.InAppSODRepMdl;
import com.jnj.rqc.mastermetadata.controller.MasterData;
import com.jnj.rqc.mastermetadata.controller.MitigationRptMdl;
import com.jnj.rqc.mastermetadata.controller.ReportErrorDTO;
import com.jnj.rqc.mastermetadata.controller.ReportErrorModel;
import com.jnj.rqc.mastermetadata.controller.ReportHeaderModel;
import com.jnj.rqc.mastermetadata.controller.UserAccessReqRptMdl;
import com.jnj.rqc.mastermetadata.controller.UserExcessiveReqRptMdl;

@Repository
public class MasterMetaDataRepository extends BaseDao {
	static final Logger log = LoggerFactory.getLogger(MasterMetaDataRepository.class);

	public void insertMultipleRecords(List<MasterData> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<MasterData> batch = records.subList(i, endIndex);
	                insertBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertBatchAsync(List<MasterData> masterList) {
		String insQry = "INSERT INTO SOD_DB_USER.ZMaster_DATA (BF_ID, BF_NAME, SEC_ID, SEC_NAME, REG_ID, REG_NAME, SYS_ID, SYS_NAME, POS_ID, POS_NAME, POS_DESC, ACS_ID, ACS_NAME, PV_ID, PV_NAME, AD_ID, AD_NAME, IS_RESTRICTED) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setInt(1, masterList.get(i).getBF_ID());
				ps.setString(2, masterList.get(i).getBF_NAME());
				ps.setInt(3, masterList.get(i).getSEC_ID());
				ps.setString(4, masterList.get(i).getSEC_NAME());
				ps.setInt(5, masterList.get(i).getREG_ID());
				ps.setString(6, masterList.get(i).getREG_NAME());
				ps.setInt(7, masterList.get(i).getSYS_ID());
				ps.setString(8, masterList.get(i).getSYS_NAME());
				ps.setInt(9, masterList.get(i).getPOS_ID());
				ps.setString(10, masterList.get(i).getPOS_NAME());
				ps.setString(11, masterList.get(i).getPOS_DESC());
				ps.setInt(12, masterList.get(i).getACS_ID());
				ps.setString(13, masterList.get(i).getACS_NAME());
				ps.setInt(14, masterList.get(i).getPV_ID());
				ps.setString(15, masterList.get(i).getPV_NAME());
				ps.setInt(16, masterList.get(i).getAD_ID());
				ps.setString(17, masterList.get(i).getAD_NAME());
				ps.setString(18, masterList.get(i).getIS_RESTRICTED());
			}
			@Override
			public int getBatchSize() {
				return masterList.size();
			}

		});
		log.info("Total Records inserted : "+(status.length == masterList.size() ? "Success-"+masterList.size() : "Failed-"+(masterList.size() - status.length)));
    }
	public void deleteAllRows() {
		log.debug("enter into the method");
		try {
			String sql = "DELETE FROM zmaster_data";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
	
	public List<MitigationRptMdl> getAllMitigation() throws SQLException, DataAccessException {
		log.debug("enter into the method");
		List<MitigationRptMdl> dataList = new ArrayList<>();		
		//String sql = "SELECT ZRH.USERID, ZC.RISKDESC, ZC.reqid, ZRH.REQUESTEDBY, ZC.mit_id, ZC.mit_desc, ZC.accept_deny, ZC.comments FROM ZUSER_CONFLICT ZC JOIN ZUREQHEAD ZRH ON ZC.REQID = ZRH.REQID";
		//String sql = "SELECT ZRH.USERID, ZC.RISKDESC, ZC.reqid, ZRH.REQUESTEDBY, ZRH.REQ_STATUS,ZRS.STATUS_NAME, ZC.mit_id, ZC.mit_desc, ZC.accept_deny,ZC.comments FROM ZUSER_CONFLICT ZC JOIN ZUREQHEAD ZRH ON ZC.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID";
		String sql = "SELECT ZRH.USERID, ZC.RISKDESC, ZC.reqid, ZRH.REQUESTEDBY, ZRH.REQ_STATUS,ZRS.STATUS_NAME, ZC.mit_id, ZC.mit_desc, ZC.accept_deny,ZC.comments, ZRH.USERNAME FROM ZUSER_CONFLICT ZC JOIN ZUREQHEAD ZRH ON ZC.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID";
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(MitigationRptMdl.class));
		log.info("MitigationRptMdl Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		log.debug("end of the method");
		return dataList;
	}
	public List<MitigationRptMdl> getAllMitigation(String criteria, String value) throws SQLException, DataAccessException {
		log.debug("enter into the method");
		boolean criteriaDefaultMatch = false;
		List<MitigationRptMdl> dataList = new ArrayList<>();	
		value = (value == null? "":value.toUpperCase());
		String sql = "SELECT ZRH.USERID, ZC.RISKDESC, ZC.reqid, ZRH.REQUESTEDBY, ZRH.REQ_STATUS,ZRS.STATUS_NAME, ZC.mit_id, ZC.mit_desc, ZC.accept_deny,ZC.comments, ZRH.USERNAME FROM ZUSER_CONFLICT ZC JOIN ZUREQHEAD ZRH ON ZC.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID";
		switch (criteria) {
			case "userId":
	            sql += " WHERE ZRH.USERID = ?";
	            break;
	        case "req_status":
	            sql += " WHERE UPPER(ZRH.REQ_STATUS) = ?";
	            break;
	        case "mitId":
	            sql += " WHERE UPPER(ZC.mit_id) like '%"+value+"%' ";
	            		criteriaDefaultMatch = true;
	            break;
	        case "status_name":
	            sql += " WHERE UPPER(ZRS.STATUS_NAME) = ?";
	            break;
	        case "requestedBy":
	            sql += " WHERE UPPER(ZRH.REQUESTEDBY) = ?";
	            break;
	        case "userName":
				sql += " AND UPPER(ZRH.USERNAME) like '%"+value+"%' ";
				criteriaDefaultMatch = true;
				break;
	        case "reqId":
	            sql += " WHERE ZC.reqid = ?";
	            break;
	        default: 
	        	log.debug("getAllMitigation default block entered. criteria not matched criteria :"+criteria+" value :"+value);	            
	        	criteriaDefaultMatch = true;
		}
		if(criteriaDefaultMatch) {
			dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(MitigationRptMdl.class));
		}else {
			dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {value}, new BeanPropertyRowMapper<>(MitigationRptMdl.class));
		}
		
		log.info("MitigationRptMdl Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		log.debug("end of the method");
		return dataList;
	}
	public List<ReportErrorModel> getAllErrorReport(Date fromDateTime, Date toDateTime)  throws SQLException, DataAccessException {
		 List<ReportErrorModel> excResRls = new ArrayList<>();
		 log.debug("from date received as :"+fromDateTime);
		 log.debug("to date received as :"+toDateTime);
		 		
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US); 
		 StringBuilder sql = new StringBuilder();
		 sql.append("SELECT REQID as reqId, USERID as userId, SYSID as systemId, ADGRPNAME as roleName, ADGRPID as adgrpid, SUBM_STATUS as subm_status, API_STATUS as api_status, API_ERROR_MSG as errorMsg, SUBM_UID as subm_uid, SUBM_DATE as subm_date ");
		 sql.append("FROM ZUSER_REQUESTED_ROLES ");
		 sql.append("WHERE (API_STATUS = 'E' OR subm_status = 'E') ");
		 sql.append("AND SUBM_DATE BETWEEN TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') AND TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') ");
		 sql.append("ORDER BY reqid DESC, upd_date DESC");
		try {
			String fromDateString = sdf.format(fromDateTime);
            String toDateString = sdf.format(toDateTime);
            log.debug("fromdate after parse :"+fromDateString);
            log.debug("todate after parse :"+toDateString);
            excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{fromDateString, toDateString}, new BeanPropertyRowMapper<>(ReportErrorModel.class));
            log.info("Get All Error records from all users size : " + ((excResRls != null) ? excResRls.size() : 0));
		}catch (Exception e) {
            log.debug("Error while processing getAllErrorReport method call :"+e.getMessage());            
        }
		
		return excResRls;
	}
	public List<ReportErrorModel> getAllSuccessReport(Date fromDateTime, Date toDateTime)  throws SQLException, DataAccessException {
		 List<ReportErrorModel> excResRls = new ArrayList<>();
		 log.debug("from date received as :"+fromDateTime);
		 log.debug("to date received as :"+toDateTime);
		 		
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US); 
		 StringBuilder sql = new StringBuilder();
		 sql.append("SELECT REQID as reqId, USERID as userId, SYSID as systemId, ADGRPNAME as roleName, ADGRPID as adgrpid, SUBM_STATUS as subm_status, API_STATUS as api_status, API_ERROR_MSG as errorMsg, SUBM_UID as subm_uid, SUBM_DATE as subm_date ");
		 sql.append("FROM ZUSER_REQUESTED_ROLES ");
		 sql.append("WHERE API_STATUS = 'C' ");
		 sql.append("AND SUBM_DATE BETWEEN TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') AND TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') ");
		 sql.append("ORDER BY reqid DESC, upd_date DESC");
		try {
			String fromDateString = sdf.format(fromDateTime);
           String toDateString = sdf.format(toDateTime);
           log.debug("fromdate after parse :"+fromDateString);
           log.debug("todate after parse :"+toDateString);
           excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{fromDateString, toDateString}, new BeanPropertyRowMapper<>(ReportErrorModel.class));
           log.info("Get All Error records from all users size : " + ((excResRls != null) ? excResRls.size() : 0));
		}catch (Exception e) {
           log.debug("Error while processing getAllErrorReport method call :"+e.getMessage());            
       }
		
		return excResRls;
	}
	public List<ReportErrorModel> getAllRecordsCount(Date fromDateTime, Date toDateTime)  throws SQLException, DataAccessException {
		 List<ReportErrorModel> excResRls = new ArrayList<>();
		 log.debug("from date received as :"+fromDateTime);
		 log.debug("to date received as :"+toDateTime);
		 		
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US); 
		 StringBuilder sql = new StringBuilder();
		 sql.append("SELECT REQID as reqId, USERID as userId, SYSID as systemId, ADGRPNAME as roleName, ADGRPID as adgrpid, SUBM_STATUS as subm_status, API_STATUS as api_status, API_ERROR_MSG as errorMsg, SUBM_UID as subm_uid, SUBM_DATE as subm_date ");
		 sql.append("FROM ZUSER_REQUESTED_ROLES ");
		// sql.append("WHERE API_STATUS = 'C' ");
		 sql.append("WHERE SUBM_DATE BETWEEN TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') AND TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') ");
		 sql.append("ORDER BY reqid DESC, upd_date DESC");
		try {
			String fromDateString = sdf.format(fromDateTime);
          String toDateString = sdf.format(toDateTime);
          log.debug("fromdate after parse :"+fromDateString);
          log.debug("todate after parse :"+toDateString);
          excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{fromDateString, toDateString}, new BeanPropertyRowMapper<>(ReportErrorModel.class));
          log.info("Get All Error records from all users size : " + ((excResRls != null) ? excResRls.size() : 0));
		}catch (Exception e) {
          log.debug("Error while processing getAllErrorReport method call :"+e.getMessage());            
      }
		
		return excResRls;
	}
	public List<ReportHeaderModel> getAllHeaderRecordsCount(Date fromDateTime, Date toDateTime)  throws SQLException, DataAccessException {
		 List<ReportHeaderModel> excResRls = new ArrayList<>();
		 log.debug("from date received as :"+fromDateTime);
		 log.debug("to date received as :"+toDateTime);
		 		
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US); 
		 StringBuilder sql = new StringBuilder();
		 sql.append("SELECT REQID as reqId, TYPEID as typeId, REQUESTEDON as requestedOn, REQ_STATUS as reqStatus ");
		 sql.append("FROM ZUREQHEAD ");		
		 sql.append("WHERE REQUESTEDON BETWEEN TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') AND TO_DATE(?, 'MM/DD/YYYY HH:MI:SS AM') ");
		 sql.append("ORDER BY reqid DESC, REQUESTEDON DESC");
		try {
			 String fromDateString = sdf.format(fromDateTime);
	         String toDateString = sdf.format(toDateTime);
	         log.debug("fromdate after parse :"+fromDateString);
	         log.debug("todate after parse :"+toDateString);
	         excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{fromDateString, toDateString}, new BeanPropertyRowMapper<>(ReportHeaderModel.class));
	         log.info("Get All Error records from all users size : " + ((excResRls != null) ? excResRls.size() : 0));
		}catch (Exception e) {
         log.debug("Error while processing getAllHeaderRecordsCount method call :"+e.getMessage());            
		}
		
		return excResRls;
	}
	public List<UserAccessReqRptMdl> getAllUserAccessReportDetails() throws SQLException, DataAccessException {
		List<UserAccessReqRptMdl> excResRls = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ZEXC.USERID, ZEXC.REQID, ZRH.USERNAME, ZRH.REQUESTEDBY as reqBy, ZRH.REQ_STATUS, ZRS.STATUS_NAME, ZEXC.SECNAME as sectorName, ZEXC.SYSNAME as systemName, ZEXC.POSVARNAME as existingAccessDetails, ZEXC.ACCEPT_DENY as status");
		sql.append(" FROM SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL ZEXC JOIN ZUREQHEAD ZRH ON ZEXC.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID ");
		sql.append(" WHERE IS_RESTRICTED in ('Yes' , 'YES') ");
		excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserAccessReqRptMdl.class));
		log.info("Get All Roles for RestrictiveData size : "+((excResRls !=null)? excResRls.size(): 0));
		return excResRls;
	}
	
	
	public List<UserAccessReqRptMdl> getAllUserAccessReportDetails(String criteria, String value)
			throws SQLException, DataAccessException {
		List<UserAccessReqRptMdl> excResRls = new ArrayList<>();
		boolean criteriaDefaultMatch = false;
		value = (value == null? "":value.toUpperCase());
		String sql = "SELECT ZEXC.USERID, ZEXC.REQID, ZRH.USERNAME, ZRH.REQUESTEDBY as reqBy, ZRH.REQ_STATUS, ZRS.STATUS_NAME, ZEXC.SECNAME as sectorName, ZEXC.SYSNAME as systemName, ZEXC.POSVARNAME as existingAccessDetails, ZEXC.ACCEPT_DENY as status FROM SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL ZEXC JOIN ZUREQHEAD ZRH ON ZEXC.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID WHERE IS_RESTRICTED in ('Yes' , 'YES') ";
		switch (criteria) {
		case "userId":
			sql += " AND ZEXC.USERID = ?";
			break;
		case "req_status":
			sql += " AND UPPER(ZRH.REQ_STATUS) = ?";
			break;
		case "reqId":
			sql += " AND ZEXC.REQID = ?";
			break;
		case "status_name":
			sql += " AND UPPER(ZRS.STATUS_NAME) = ?";
			break;
		case "reqBy":
			sql += " AND ZRH.REQUESTEDBY = ?";
			break;
		case "userName":
			sql += " AND UPPER(ZRH.USERNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		case "sectorName":
			sql += " AND UPPER(ZEXC.SECNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		case "systemName":
			sql += " AND UPPER(ZEXC.SYSNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		default:
			log.debug("getAllMitigation default block entered. criteria not matched criteria :" + criteria + " value :"
					+ value);
			criteriaDefaultMatch = true;
		}
		if (criteriaDefaultMatch) {
			excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {},
					new BeanPropertyRowMapper<>(UserAccessReqRptMdl.class));
		} else {
			excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] { value },
					new BeanPropertyRowMapper<>(UserAccessReqRptMdl.class));
		}

		log.info("Get All Roles for RestrictiveData size : " + ((excResRls != null) ? excResRls.size() : 0));
		return excResRls;
	}
	 
	
	public List<UserExcessiveReqRptMdl> getAllUserExcessiveReportDetails() throws SQLException, DataAccessException {
		List<UserExcessiveReqRptMdl> excResLst = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ZREST.USERID, ZREST.REQID, ZRH.USERNAME, ZRH.REQUESTEDBY as reqBy, ZRH.REQ_STATUS, ZRS.STATUS_NAME, ZREST.SECNAME as sectorName, ZREST.SYSNAME as systemName, ZREST.EXCSV_PRCNTG as excessPercentage, ZREST.LIMIT ");
		sql.append(" FROM SOD_DB_USER.ZREQ_RESTRICTIVE_EXCSV_ACCESS ZREST JOIN ZUREQHEAD ZRH ON ZREST.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID ");
		sql.append(" WHERE IS_EXCSV in ('Y' , 'Y') ");
		excResLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(UserExcessiveReqRptMdl.class));
		log.info("Request Excessive Data size : "+((excResLst !=null)? excResLst.size(): 0));
		return excResLst;
	}
	
	public List<UserExcessiveReqRptMdl> getAllUserExcessiveReportDetails(String criteria, String value)
			throws SQLException, DataAccessException {
		List<UserExcessiveReqRptMdl> excResRls = new ArrayList<>();
		boolean criteriaDefaultMatch = false;
		value = (value == null? "":value.toUpperCase());
		String sql = "SELECT ZREST.USERID, ZREST.REQID, ZRH.USERNAME, ZRH.REQUESTEDBY as reqBy, ZRH.REQ_STATUS, ZRS.STATUS_NAME, ZREST.SECNAME as sectorName, ZREST.SYSNAME as systemName, ZREST.EXCSV_PRCNTG as excessPercentage, ZREST.LIMIT FROM SOD_DB_USER.ZREQ_RESTRICTIVE_EXCSV_ACCESS ZREST JOIN ZUREQHEAD ZRH ON ZREST.REQID = ZRH.REQID JOIN ZREQUESTSTATUS ZRS ON ZRH.REQ_STATUS = ZRS.STATUS_ID WHERE IS_EXCSV in ('Y' , 'Y') ";
		switch (criteria) {
		case "userId":
			sql += " AND ZREST.USERID = ?";
			break;
		case "req_status":
			sql += " AND UPPER(ZRH.REQ_STATUS) = ?";
			break;
		case "reqId":
			sql += " AND ZREST.REQID = ?";
			break;
		case "status_name":
			sql += " AND UPPER(ZRS.STATUS_NAME) = ?";
			break;
		case "reqBy":
			sql += " AND ZRH.REQUESTEDBY = ?";
			break;
		case "userName":
			sql += " AND UPPER(ZRH.USERNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		case "sectorName":
			sql += " AND UPPER(ZREST.SECNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		case "systemName":
			sql += " AND UPPER(ZREST.SYSNAME) like '%"+value+"%' ";
			criteriaDefaultMatch = true;
			break;
		case "excessPercentage":
			sql += " AND ZREST.EXCSV_PRCNTG = ?";
			break;
		default:
			log.debug("getAllMitigation default block entered. criteria not matched criteria :" + criteria + " value :"
					+ value);
			criteriaDefaultMatch = true;
		}
		if (criteriaDefaultMatch) {
			excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {},
					new BeanPropertyRowMapper<>(UserExcessiveReqRptMdl.class));
		} else {
			excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] { value },
					new BeanPropertyRowMapper<>(UserExcessiveReqRptMdl.class));
		}

		log.info("Get All Roles for RestrictiveData size : " + ((excResRls != null) ? excResRls.size() : 0));
		return excResRls;
	}
	public void insertCFINMultipleRecords(List<IAMRolesADGrpMdl> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<IAMRolesADGrpMdl> batch = records.subList(i, endIndex);
	                insertCFINBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertCFINBatchAsync(List<IAMRolesADGrpMdl> batch) {
		String insQry = "INSERT INTO SOD_DB_USER.ZExistingRolesCFIN (USERNAME, ADGROUPNAME, FROMDATE, TODATE) VALUES (?, ?, ?, ?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, batch.get(i).getUser());
				ps.setString(2, batch.get(i).getLdapADGroup());
				ps.setString(3, batch.get(i).getMdate());
				ps.setString(4, batch.get(i).getStopdate());								
			}
			@Override
			public int getBatchSize() {
				return batch.size();
			}

		});
		log.info("Total Records inserted : "+(status.length == batch.size() ? "Success-"+batch.size() : "Failed-"+(batch.size() - status.length)));
    }
	public void insertDDGRMultipleRecords(List<IAMRolesADGrpMdl> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<IAMRolesADGrpMdl> batch = records.subList(i, endIndex);
	                insertDDGRBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertDDGRBatchAsync(List<IAMRolesADGrpMdl> batch) {
		String insQry = "INSERT INTO SOD_DB_USER.ZExistingRolesDDGR (USERNAME, ADGROUPNAME, MODDATE, STOPDATE, CLIENTNAME) VALUES (?, ?, ?, ?,?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, batch.get(i).getUser());
				ps.setString(2, batch.get(i).getLdapADGroup());
				ps.setString(3, batch.get(i).getMdate());
				ps.setString(4, batch.get(i).getStopdate());
				ps.setString(5, batch.get(i).getClient());				
			}
			@Override
			public int getBatchSize() {
				return batch.size();
			}

		});
		log.info("Total Records inserted : "+(status.length == batch.size() ? "Success-"+batch.size() : "Failed-"+(batch.size() - status.length)));
    }
	public void insertAnaplanMultipleRecords(List<IAMRolesADGrpMdl> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<IAMRolesADGrpMdl> batch = records.subList(i, endIndex);
	                insertAnaplanBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertAnaplanBatchAsync(List<IAMRolesADGrpMdl> batch) {
		String insQry = "INSERT INTO SOD_DB_USER.ZExistingRolesAnaplan (USERNAME, ADGROUPNAME, MODDATE, STOPDATE, CLIENTNAME) VALUES (?, ?, ?, ?,?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, batch.get(i).getUser());
				ps.setString(2, batch.get(i).getLdapADGroup());
				ps.setString(3, batch.get(i).getMdate());
				ps.setString(4, batch.get(i).getStopdate());
				ps.setString(5, batch.get(i).getClient());				
			}
			@Override
			public int getBatchSize() {
				return batch.size();
			}

		});
		log.info("Total Records inserted : "+(status.length == batch.size() ? "Success-"+batch.size() : "Failed-"+(batch.size() - status.length)));
    }
	public void deleteAllRowsFromCFIN() {
		log.debug("enter into the method");
		try {
			String sql = "DELETE FROM ZExistingRolesCFIN";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
	public void deleteAllRowsFromDDGR() {
		log.debug("enter into the method");
		try {
			String sql = "DELETE FROM ZExistingRolesDDGR";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
	public void deleteAllRowsFromAnaplan() {
		log.debug("enter into the method");
		try {
			String sql = "DELETE FROM ZExistingRolesAnaplan";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
	
	public List<AnaplanRoleModel> getExistingAnaplanRoleDetails() throws SQLException, DataAccessException {
		List<AnaplanRoleModel> anaplanRoleResLst = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT CLIENTNAME as clientId, USERNAME as userId, ADGROUPNAME, MODDATE, STOPDATE FROM ZExistingRolesAnaplan");		
		anaplanRoleResLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AnaplanRoleModel.class));
		log.info("Request Excessive Data size : "+((anaplanRoleResLst !=null)? anaplanRoleResLst.size(): 0));
		return anaplanRoleResLst;
	}
	
	public List<CrossAppRoleModel> getExistingCrosAppRoleDetails(String System) throws SQLException, DataAccessException {
		List<CrossAppRoleModel> crossAppRoleResLst = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		switch (System) {
			case "DDGR":
				sql.append(" SELECT USERNAME as userId, ADGROUPNAME, MODDATE, STOPDATE FROM ZExistingRolesDDGR");
			break;
			case "CFIN":
				sql.append(" SELECT USERNAME as userId, ADGROUPNAME, FROMDATE as modDate, TODATE as stopDate FROM ZExistingRolesCFIN where ADGROUPNAME!='ZS4-FI-BASIC-COMMON-ACCESS'");
			break;
			case "Anaplan":
				sql.append(" SELECT USERNAME as userId, ADGROUPNAME, MODDATE, STOPDATE FROM ZExistingRolesAnaplan");
			break;
		}		
		crossAppRoleResLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(CrossAppRoleModel.class));
		log.info("Request Excessive Data size : "+((crossAppRoleResLst !=null)? crossAppRoleResLst.size(): 0));
		return crossAppRoleResLst;
	}
}
