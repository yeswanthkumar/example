package com.jnj.rqc.mastermetadata.service;

import java.util.Date;

import com.jnj.rqc.mastermetadata.controller.MitigationReportDTO;
import com.jnj.rqc.mastermetadata.controller.ReportErrorDTO;
import com.jnj.rqc.mastermetadata.controller.ReportErrorModel;
import com.jnj.rqc.mastermetadata.controller.ReportResponse;
import com.jnj.rqc.mastermetadata.controller.RequestMonitorReportDTO;
import com.jnj.rqc.mastermetadata.controller.SchedularStatusDTO;
import com.jnj.rqc.mastermetadata.controller.MonitorReportDTO;
import com.jnj.rqc.mastermetadata.controller.SystemStatusDTO;

public interface MitigationReportService {
	public MitigationReportDTO getMitigationResults();
	public MitigationReportDTO getMitigationResults(String criteria, String value);
	public ReportErrorDTO getErrorReport(Date fromDateTime, Date toDateTime);
	public ReportResponse sendRequestTodownstream(ReportErrorModel reportErrorModel);
	public ReportErrorDTO getSuccessReport( Date fromDate, Date toDate);
	public SystemStatusDTO getGRCStatus();
	public SystemStatusDTO getIAMStatus();
	public MonitorReportDTO requestsubmitcount( String year);
	public RequestMonitorReportDTO requestidsubmitcount( String year);
	public SchedularStatusDTO schedularStatus();
	
}
