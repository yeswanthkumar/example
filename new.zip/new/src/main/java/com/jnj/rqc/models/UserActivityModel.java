package com.jnj.rqc.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserActivityModel {
	String userId;
	String firstName;
	String lastName;
	String role;
	String srcSys;
	String empActive;
	Date dtUpdated;
	@Override
	public String toString() {
		return "UserActivityModel [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", srcSys=" + srcSys + ", role=" + role + ", empActive=" + empActive + ", dtUpdated=" + dtUpdated
				+ "]";
	}


	public String getData() {
		return userId+"~"+firstName+"~"+lastName+"~"+role+"~"+srcSys+"~"+empActive+"~"+((dtUpdated != null)? Utility.fmtMMDDYYYYTime(dtUpdated):"");
	}




}
