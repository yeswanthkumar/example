package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZSectorMdl {
	private int secid;
	private String seccode;
	private String secname;
	private String secdesc;
	private String secimg;
	private String secloc;
	private String isactive;
	private  String createdby;
	private Date createdon;
	private  String cchangedby;
	private Date changedon;


	@Override
	public String toString() {
		return "ZSectorMdl [secid=" + secid + ", seccode=" + seccode + ", secname=" + secname + ", secdesc=" + secdesc
				+ ", secimg=" + secimg + ", secloc=" + secloc + ", isactive=" + isactive + ", createdby=" + createdby
				+ ", createdon=" + createdon + ", cchangedby=" + cchangedby + ", changedon=" + changedon + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZSectorMdl other = (ZSectorMdl) obj;
		if (isactive == null) {
			if (other.isactive != null)
				return false;
		} else if (!isactive.equals(other.isactive))
			return false;
		if (seccode == null) {
			if (other.seccode != null)
				return false;
		} else if (!seccode.equals(other.seccode))
			return false;
		if (secdesc == null) {
			if (other.secdesc != null)
				return false;
		} else if (!secdesc.equals(other.secdesc))
			return false;
		if (secid != other.secid)
			return false;
		if (secname == null) {
			if (other.secname != null)
				return false;
		} else if (!secname.equals(other.secname))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isactive == null) ? 0 : isactive.hashCode());
		result = prime * result + ((seccode == null) ? 0 : seccode.hashCode());
		result = prime * result + ((secdesc == null) ? 0 : secdesc.hashCode());
		result = prime * result + secid;
		result = prime * result + ((secname == null) ? 0 : secname.hashCode());
		return result;
	}











}
