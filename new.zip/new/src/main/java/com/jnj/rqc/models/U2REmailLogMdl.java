package com.jnj.rqc.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;

@Data
public class U2REmailLogMdl {
	private int seqId;
	private String reportName;
	private String platform;
	private String emailAddress;
	private String triggeredBy;
	private String emailSend;
	private Date   createdDt;
	private Date   sendDt;
	private String genFiles;
	private String status;
	private String statusUpdBy;
	private Date statusUpdDt;


	public String getData() {
		return seqId+"~"+reportName+"~"+platform+"~"+emailAddress+"~"+triggeredBy+"~"+emailSend+"~"+Utility.dtFmt.format(createdDt)+"~"+Utility.dtFmt.format(sendDt)+"~"+genFiles;
	}


	@Override
	public String toString() {
		return "U2REmailLogMdl [seqId=" + seqId + ", reportName=" + reportName + ", platform=" + platform
				+ ", emailAddress=" + emailAddress + ", triggeredBy=" + triggeredBy + ", emailSend=" + emailSend
				+ ", createdDt=" + createdDt + ", sendDt=" + sendDt + ", genFiles=" + genFiles + ", status=" + status
				+ ", statusUpdBy=" + statusUpdBy + ", statusUpdDt=" + statusUpdDt + "]";
	}









}
