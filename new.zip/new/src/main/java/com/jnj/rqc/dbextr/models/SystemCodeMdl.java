package com.jnj.rqc.dbextr.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SystemCodeMdl {
	String srcSystem;
	String accessRole;
	String sodCode;



	public String getData() {
		return srcSystem+"~"+accessRole+"~"+sodCode;
	}


}
