package com.jnj.rqc.reportwriter;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;



@Service
public class ExcelReportWriter {
	static final Logger log = LoggerFactory.getLogger(ExcelReportWriter.class);

	private static int headerFontSize = 12;
	private static boolean headerBold = true;

    public String writeTrfCntrlTransReport(String fileName, String sheetName, String columns, List<TrfCntrlTransDataMdl> data ) throws IOException, InvalidFormatException {
        String path = "";

    	Workbook workbook = new XSSFWorkbook(); // Create a Workbook .xlsx or new HSSFWorkbook() for generating `.xls` file
        CreationHelper createHelper = workbook.getCreationHelper();/* CreationHelper helps us create instances for various things like DataFormat, Hyperlink, RichTextString etc in a format (HSSF, XSSF) independent way */

        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet

        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);

        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = columns.split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(null != data && !data.isEmpty()) {
        	for(TrfCntrlTransDataMdl mdl: data) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getRegion());
                row.createCell(1).setCellValue(mdl.getPlatform());
                row.createCell(2).setCellValue(mdl.getEnvironment());
                row.createCell(3).setCellValue(mdl.getSystem());
                row.createCell(4).setCellValue(mdl.getDescription());
                row.createCell(5).setCellValue(mdl.getDescription());
                row.createCell(6).setCellValue(mdl.getUserNtId());
                row.createCell(7).setCellValue(mdl.getWwid());
                Cell createdDtCell = row.createCell(8);
                createdDtCell.setCellValue(mdl.getCreatedDt());
                createdDtCell.setCellStyle(dateCellStyle);
                row.createCell(9).setCellValue(mdl.getCreatedBy());
            }

        }

        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();

        return path;
    }

    public String writeUser2RoleTransReport(String fileName, String sheetName, String columns, List<SapGaaUser2RoleTransModel> data ) throws IOException, InvalidFormatException {
        String path = "";

    	Workbook workbook = new XSSFWorkbook(); // Create a Workbook .xlsx or new HSSFWorkbook() for generating `.xls` file
        CreationHelper createHelper = workbook.getCreationHelper();/* CreationHelper helps us create instances for various things like DataFormat, Hyperlink, RichTextString etc in a format (HSSF, XSSF) independent way */

        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet

        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);

        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = columns.split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapGaaUser2RoleTransModel mdl: data) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getRegion());
                row.createCell(1).setCellValue(mdl.getPlatform());
                row.createCell(2).setCellValue(mdl.getEnvironment());
                row.createCell(3).setCellValue(mdl.getSystem());
                row.createCell(4).setCellValue(mdl.getUserId());
                row.createCell(5).setCellValue(mdl.getFirstName());
                row.createCell(6).setCellValue(mdl.getLastName());
                row.createCell(7).setCellValue(mdl.getRoleId());
                row.createCell(8).setCellValue(mdl.getRoleDesc());
                row.createCell(9).setCellValue(mdl.getPrimaryReviewInfo1());
                row.createCell(10).setCellValue(mdl.getPrimaryReviewInfo2());
                row.createCell(11).setCellValue(mdl.getPrimaryReviewInfo3());
                row.createCell(12).setCellValue(mdl.getAdditionalInfo1());
                row.createCell(13).setCellValue(mdl.getAdditionalInfo2());
                row.createCell(14).setCellValue(mdl.getAdditionalInfo3());
                row.createCell(15).setCellValue(mdl.getUserStatus());

                Cell createdDtCell = row.createCell(16);
                createdDtCell.setCellValue(mdl.getCreatedDt());
                createdDtCell.setCellStyle(dateCellStyle);
                row.createCell(17).setCellValue(mdl.getCreatedBy());
            }

        }

        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }





    private Font createFont(Workbook workbook, int size, boolean bold) {
    	Font rowFont = workbook.createFont();
    	rowFont.setFontHeightInPoints((short) size);
    	rowFont.setColor(IndexedColors.BLACK.getIndex());
    	//rowFont.setColor(IndexedColors.BLUE.getIndex());
    	rowFont.setBold(bold);
    	//rowFont.setItalic(true);
    	//rowFont.setFontName("");
    	return rowFont;
    }




	/**
	 * Method  : ExcelReportWriter.java.writeSapGaaUser2RoleExcel()
	 *		   :<b>@param data
	 *		   :<b>@param fileName
	 *		   :<b>@param sheetName
	 *		   :<b>@return
	 *		   :<b>@throws IOException
	 *		   :<b>@throws InvalidFormatException</b>
	 * @author : DChauras  @Created :Aug 12, 2021 6:23:59 PM
	 * Purpose :
	 * @return : String
	 */
    public String writeSapGaaUser2RoleExcel(List<SapGaaUser2RoleModel> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = Constants.SAP_GAA_USER2ROLE.split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapGaaUser2RoleModel mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getRevUserId());
                row.createCell(1).setCellValue(mdl.getUserId());
                row.createCell(2).setCellValue(mdl.getPrimaryReviewInfo1());
                row.createCell(3).setCellValue(mdl.getPrimaryReviewInfo2());
                row.createCell(4).setCellValue(mdl.getPrimaryReviewInfo3());
                row.createCell(5).setCellValue(mdl.getAdditionalInfo1());
                row.createCell(6).setCellValue(mdl.getAdditionalInfo2());
                row.createCell(7).setCellValue(mdl.getAdditionalInfo3());
                row.createCell(8).setCellValue(mdl.getUserStatus());
            }
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }


    public String writeGenesisSignedOfExcel(List<SapDataTransferReportMdl> data, String fileName, String sheetName){
    	String filePath = "";
		try {
			Workbook workbook = new XSSFWorkbook();
			CreationHelper createHelper = workbook.getCreationHelper();
	        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
	        Font headerFont = createFont(workbook, headerFontSize, headerBold);
	        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
	        headerCellStyle.setFont(headerFont);
	        Row headerRow = sheet.createRow(0);//Create a Row
	        // Creating cells
	        String[] cols = Constants.GEN_SO_TRFREPORT.split(",");
	        for(int i = 0; i < cols.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(cols[i]);
	            cell.setCellStyle(headerCellStyle);
	        }

	        // Cell Style for formatting Date
	        CellStyle dateCellStyle = workbook.createCellStyle();
	        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

	        // Creating other rows and cells with data
	        int rowNum = 1;
	        if(data != null && !data.isEmpty()) {
	        	for(SapDataTransferReportMdl mdl: data) {
	            	Row row = sheet.createRow(rowNum++);
	                row.createCell(0).setCellValue(mdl.getReviewName());
	                row.createCell(1).setCellValue(mdl.getSapPlatfrom());
	                row.createCell(2).setCellValue(mdl.getSapSystem());
	                row.createCell(3).setCellValue(mdl.getGroupDescription());
	                row.createCell(4).setCellValue(mdl.getAccountName());
	                row.createCell(5).setCellValue(mdl.getAccountOwner());
	                row.createCell(6).setCellValue(mdl.getAccountOwnerWwid());
	                row.createCell(7).setCellValue(mdl.getAccountOwnerTitle());
	                row.createCell(8).setCellValue(mdl.getDesignatedReviewer());
	                row.createCell(9).setCellValue(mdl.getDesignatedReviewerWwid());
	                row.createCell(10).setCellValue(mdl.getReviewedByName());
	                row.createCell(11).setCellValue(mdl.getReviewedByWwid());

	                Cell createdDtCell = row.createCell(12);
	                createdDtCell.setCellValue(mdl.getCreationDate());
	                createdDtCell.setCellStyle(dateCellStyle);

	                Cell dateReviewed = row.createCell(13);
	                dateReviewed.setCellValue(mdl.getDateReviewed());
	                dateReviewed.setCellStyle(dateCellStyle);

	                row.createCell(14).setCellValue(mdl.getReviewStatus());

	                Cell dateEntered = row.createCell(15);
	                dateEntered.setCellValue(mdl.getDateEntered());
	                dateEntered.setCellStyle(dateCellStyle);
	            }
	        }
	        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
	            sheet.autoSizeColumn(i);
	        }
	        // Write the output to a file
	        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
	        filePath = outFile.getAbsolutePath();
	        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
	        workbook.write(bout);
	        bout.close();
	        workbook.close();
	    } catch (Exception e) {
			log.error("ERROR Creating Excel:"+e.getMessage(), e);
		}
    	return filePath;
	}


	public String writeGenesisU2SSignedOfExcel(List<SapUser2SodReportMdl> data, String fileName, String sheetName) {
		String filePath = "";
		try{
			Workbook workbook = new XSSFWorkbook();
			CreationHelper createHelper = workbook.getCreationHelper();
	        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
	        Font headerFont = createFont(workbook, headerFontSize, headerBold);
	        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
	        headerCellStyle.setFont(headerFont);
	        Row headerRow = sheet.createRow(0);//Create a Row
	        // Creating cells
	        String[] cols = Constants.GEN_SO_U2SREPORT.split(",");
	        for(int i = 0; i < cols.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(cols[i]);
	            cell.setCellStyle(headerCellStyle);
	        }
	        // Cell Style for formatting Date
	        CellStyle dateCellStyle = workbook.createCellStyle();
	        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
	        int rowNum = 1;
	        if(data != null && !data.isEmpty()) {
	        	for(SapUser2SodReportMdl mdl: data) {
	        		//,REVIEWER_COMMENTS,DATE_ENTERED
	        		Row row = sheet.createRow(rowNum++);
	                row.createCell(0).setCellValue(mdl.getReviewName());
	                row.createCell(1).setCellValue(mdl.getGroupPlatform());
	                row.createCell(2).setCellValue(mdl.getGroupDescription());
	                row.createCell(3).setCellValue(mdl.getGroupShortName());
	                row.createCell(4).setCellValue(mdl.getGroupOther1());
	                row.createCell(5).setCellValue(mdl.getGroupOther2());
	                row.createCell(6).setCellValue(mdl.getGroupOther3());
	                row.createCell(7).setCellValue(mdl.getAccountName());
	                row.createCell(8).setCellValue(mdl.getAccountOwnerName());
	                row.createCell(9).setCellValue(mdl.getAccountOwnerTitle());
	                row.createCell(10).setCellValue(mdl.getAccountOwnerUserName());
	                row.createCell(11).setCellValue(mdl.getAccountOwnerEmail());
	                row.createCell(12).setCellValue(mdl.getAccountOwnerDepartment());
	                row.createCell(13).setCellValue(mdl.getDesignatedReviewer());
	                row.createCell(14).setCellValue(mdl.getDesignatedReviewerWwid());
	                row.createCell(15).setCellValue(mdl.getReviewedByName());
	                row.createCell(16).setCellValue(mdl.getReviewedByWwid());
	                row.createCell(17).setCellValue(mdl.getDateGenerated());
	                row.createCell(18).setCellValue(mdl.getDateReviewed());
	                row.createCell(19).setCellValue(mdl.getReviewStatus());
	                row.createCell(20).setCellValue(mdl.getReviewerComments());
	                row.createCell(21).setCellValue(mdl.getDateEntered());
	             }
	        }
	        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
	            sheet.autoSizeColumn(i);
	        }
	        // Write the output to a file
	        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
	        filePath = outFile.getAbsolutePath();
	        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
	        workbook.write(bout);
	        bout.close();
	        workbook.close();
	    } catch (Exception e) {
			log.error("ERROR Creating Excel:"+e.getMessage(), e);
		}
	 return filePath;
	}



	public String writeGenesisU2RSignedOfExcel(List<SapUser2RoleReportMdl> data, String fileName, String sheetName) {
		String filePath = "";
		try{
			Workbook workbook = new XSSFWorkbook();
			CreationHelper createHelper = workbook.getCreationHelper();
	        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
	        Font headerFont = createFont(workbook, headerFontSize, headerBold);
	        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
	        headerCellStyle.setFont(headerFont);
	        Row headerRow = sheet.createRow(0);//Create a Row
	        // Creating cells
	        String[] cols = Constants.GEN_SO_U2RREPORT.split(",");
	        for(int i = 0; i < cols.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(cols[i]);
	            cell.setCellStyle(headerCellStyle);
	        }

	        // Cell Style for formatting Date
	        CellStyle dateCellStyle = workbook.createCellStyle();
	        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

	        // Creating other rows and cells with data
	        int rowNum = 1;
	        if(data != null && !data.isEmpty()) {
	        	for(SapUser2RoleReportMdl mdl: data) {
	        		Row row = sheet.createRow(rowNum++);
	                row.createCell(0).setCellValue(mdl.getReviewName());
	                row.createCell(1).setCellValue(mdl.getGroupDescription());
	                row.createCell(2).setCellValue(mdl.getGroupShortName());
	                row.createCell(3).setCellValue(mdl.getGroup_other_2());
	                row.createCell(4).setCellValue(mdl.getGroup_other_3());
	                row.createCell(5).setCellValue(mdl.getAccountName());
	                row.createCell(6).setCellValue(mdl.getAccountOwnerName());
	                row.createCell(7).setCellValue(mdl.getAccountOwnerTitle());
	                row.createCell(8).setCellValue(mdl.getAccountOwnerUserId());
	                row.createCell(9).setCellValue(mdl.getAccountOwnerUserName());
	                row.createCell(10).setCellValue(mdl.getAccountOwnerEmail());
	                row.createCell(11).setCellValue(mdl.getAccountOwnerMrc());
	                row.createCell(12).setCellValue(mdl.getAccountOwnerDepartment());
	                row.createCell(13).setCellValue(mdl.getGroupType());
	                row.createCell(14).setCellValue(mdl.getDesignatedReviewer());
	                row.createCell(15).setCellValue(mdl.getDesignatedReviewerWwid());
	                row.createCell(16).setCellValue(mdl.getReviewedByName());
	                row.createCell(17).setCellValue(mdl.getReviewedByWwid());
	                row.createCell(18).setCellValue(mdl.getReviewStatus());
	                row.createCell(19).setCellValue(mdl.getReviewerComments());


	                Cell dateEntered = row.createCell(20);
	                dateEntered.setCellValue(mdl.getDateEntered());
	                dateEntered.setCellStyle(dateCellStyle);
	             }
	        }
	        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
	            sheet.autoSizeColumn(i);
	        }
	        // Write the output to a file
	        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
	        filePath = outFile.getAbsolutePath();
	        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
	        workbook.write(bout);
	        bout.close();
	        workbook.close();
	    } catch (Exception e) {
			log.error("ERROR Creating Excel:"+e.getMessage(), e);
		}
	 return filePath;
	}


	public String writeSapUser2SodExcel(List<SapUser2SodModel> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = Constants.SAP_USER2SOD_HDR.split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapUser2SodModel mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getRevUserId());
                row.createCell(1).setCellValue(mdl.getUserId());
                row.createCell(2).setCellValue(mdl.getPrimaryReviewInfo1());
                row.createCell(3).setCellValue(mdl.getAdditionalInfo1());
                row.createCell(4).setCellValue(mdl.getAdditionalInfo2());
                row.createCell(5).setCellValue(mdl.getMitigatingId());
                row.createCell(6).setCellValue(mdl.getAdditionalInfo3());
                row.createCell(7).setCellValue(mdl.getPlatformName());
                row.createCell(8).setCellValue(mdl.getRiskIdAndRiskDescription());
                row.createCell(9).setCellValue(mdl.getReviewerDescription());
                row.createCell(10).setCellValue(mdl.getUserStatus());
            }
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }


	public String writeSapUser2SodTrnsExcel(List<SapUser2SodTrnsModel> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row
        // Creating cells
        String[] cols = Constants.SAP_USER2SOD_TRNSHDR.split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }
        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapUser2SodTrnsModel mdl: data) {
            	Row row = sheet.createRow(rowNum++);
            	row.createCell(0).setCellValue(mdl.getRegion());
            	row.createCell(1).setCellValue(mdl.getPlatform());
            	row.createCell(2).setCellValue(mdl.getEnvironment());
            	row.createCell(3).setCellValue(mdl.getSystem());
            	row.createCell(4).setCellValue(mdl.getRevUserId());
                row.createCell(5).setCellValue(mdl.getUserId());
                row.createCell(6).setCellValue(mdl.getPrimaryReviewInfo1());
                row.createCell(7).setCellValue(mdl.getAdditionalInfo1());
                row.createCell(8).setCellValue(mdl.getAdditionalInfo2());
                row.createCell(9).setCellValue(mdl.getMitigatingId());
                row.createCell(10).setCellValue(mdl.getAdditionalInfo3());
                row.createCell(11).setCellValue(mdl.getPlatformName());
                row.createCell(12).setCellValue(mdl.getRiskIdAndRiskDescription());
                row.createCell(13).setCellValue(mdl.getReviewerDescription());
                //row.createCell(14).setCellValue(mdl.getUserStatus());
            }
        }
        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }
        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }

	public String writeSapUser2SodDeltaExcel(List<SapUser2SodDeltaMdl> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row
        // Creating cells
        String[] cols = "REVIEWER USER ID,USER_ID,PRIMARY_REVIEW_INFO1,ADDITIONAL_INFO1,ADDITIONAL_INFO2,MITIGATING ID,ADDITIONAL_INFO3,PLATFORM NAME,RISK ID and RISK DESCRIPTION,REVIEWER ACKNOWLEDGEMENT / DESCRIPTION,USER STATUS,DATE ENTERED,REPORT DATE".split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }
        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapUser2SodDeltaMdl mdl: data) {
            	Row row = sheet.createRow(rowNum++);
            	row.createCell(0).setCellValue(mdl.getRevUserId());
                row.createCell(1).setCellValue(mdl.getUserId());
                row.createCell(2).setCellValue(mdl.getPrimaryReviewInfo1());
                row.createCell(3).setCellValue(mdl.getAdditionalInfo1());
                row.createCell(4).setCellValue(mdl.getAdditionalInfo2());
                row.createCell(5).setCellValue(mdl.getMitigatingId());
                row.createCell(6).setCellValue(mdl.getAdditionalInfo3());
                row.createCell(7).setCellValue(mdl.getPlatformName());
                row.createCell(8).setCellValue(mdl.getRiskIdAndRiskDescription());
                row.createCell(9).setCellValue(mdl.getReviewerDescription());
                row.createCell(10).setCellValue(mdl.getUserStatus());
                row.createCell(11).setCellValue(mdl.getDateEntered());
                row.createCell(12).setCellValue(mdl.getReportDate());
            }
        }
        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }
        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }



	public String writeMitiCntrlExcel(List<SapMitiCntrlModel> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = "Risk Id,Control / Mitigating Id,Control Description".split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapMitiCntrlModel mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getRiskId());
                row.createCell(1).setCellValue(mdl.getControlId());
                row.createCell(2).setCellValue(mdl.getControlDesc());
        	}
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }


	public String writeSapReviewerExcel(List<SapPlatformReviwerMdl> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = "PLATFORM NAME,RISK ID,REVIEWER ID".split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(SapPlatformReviwerMdl mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getPlatform());
                row.createCell(1).setCellValue(mdl.getRiskId());
                row.createCell(2).setCellValue(mdl.getReviewerId());
        	}
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }


	public String writeMercuryReviewerExcel(List<StrKeyValPair> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = "APPROVER LIST ID,REVIEWER ID".split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(StrKeyValPair mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getKey());
                row.createCell(1).setCellValue(mdl.getVal());
            }
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }


	public String writeCSMDataExcel(List<GrpUsrDateMdl> data, String fileName, String sheetName)throws IOException, InvalidFormatException {
        String path = "";
    	Workbook workbook = new XSSFWorkbook();
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet(sheetName);//Create Sheet
        Font headerFont = createFont(workbook, headerFontSize, headerBold);
        CellStyle headerCellStyle = workbook.createCellStyle(); // Create a CellStyle with the font
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);//Create a Row

        // Creating cells
        String[] cols = "Import Employee First Name,Import Employee Last Name,Import Employee WWID,Import Employee Email,JJEDS Status,Import AD Group,Import AD Group Effective Date,Import AD Group Valid From Date,Import AD Group Valid To Date".split(",");
        for(int i = 0; i < cols.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cols[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-MM-dd HH:mm:ss"));

        // Creating other rows and cells with data
        int rowNum = 1;
        if(data != null && !data.isEmpty()) {
        	for(GrpUsrDateMdl mdl: data) {
            	Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(mdl.getFName());
                row.createCell(1).setCellValue(mdl.getLName());
                row.createCell(2).setCellValue(mdl.getWwid());
                row.createCell(3).setCellValue(mdl.getEmailId());
                row.createCell(4).setCellValue(mdl.getEmpStatus());
                row.createCell(5).setCellValue(mdl.getAdgroup());

                Cell effDtCell = row.createCell(6);
                effDtCell.setCellValue(mdl.getModDate());
                effDtCell.setCellStyle(dateCellStyle);

                Cell frmDtCell = row.createCell(7);
                frmDtCell.setCellValue(mdl.getVldFrom());
                frmDtCell.setCellStyle(dateCellStyle);

                Cell toDtCell = row.createCell(8);
                toDtCell.setCellValue(mdl.getVldTo());
                toDtCell.setCellStyle(dateCellStyle);
            }
        }


        for(int i = 0; i < cols.length; i++) {// Resizing columns to fit the content size only done at last
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        File outFile = new File(Constants.REPO_OUT_LOC+fileName+".xlsx");
        path = outFile.getAbsolutePath();
        BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(outFile));
        workbook.write(bout);
        bout.close();
        workbook.close();
        return path;
    }






    // Example to modify an existing excel file
    /*private static void modifyExistingWorkbook() throws InvalidFormatException, IOException {
        // Obtain a workbook from the excel file
        Workbook workbook = WorkbookFactory.create(new File("existing-spreadsheet.xlsx"));

        // Get Sheet at index 0
        Sheet sheet = workbook.getSheetAt(0);

        // Get Row at index 1
        Row row = sheet.getRow(1);

        // Get the Cell at index 2 from the above row
        Cell cell = row.getCell(2);

        // Create the cell if it doesn't exist
        if (cell == null)
            cell = row.createCell(2);

        // Update the cell's value
        cell.setCellType(CellType.STRING);
        cell.setCellValue("Updated Value");

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("existing-spreadsheet.xlsx");
        workbook.write(fileOut);
        fileOut.close();

        // Closing the workbook
        workbook.close();
    }*/
}




