package com.jnj.rqc.dbextr.models;


import lombok.Data;


@Data
public class F0005Mdl {
	private String  dRSY;
	private String  dRRT;
	private String  dRKY;
	private String  dRDL01;
	private String  dRDL02;
	private String  dRSPHD;
	private String  dRUDCO;
	private String  dRHRDC;
	private String  dRUSER;
	private String  dRPID;
	private String  dRUPMJ;
	private String  dRJOBN;
	private String  dRUPMT;

	public String getData() {
		return  dRSY + "~" +dRRT + "~" + dRKY + "~" +dRDL01 + "~" + dRDL02 + "~"+dRSPHD+"~"+dRUDCO+
				"~"+dRHRDC+"~"+dRUSER+"~"+dRPID+"~"+dRUPMJ+"~"+dRJOBN+"~"+dRUPMT;
	}

}
