package com.jnj.rqc.mastermetadata.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jnj.rqc.userabs.dao.UserUtilsDao;
import com.jnj.rqc.userabs.models.RoleADGrpMultiUserMdl;

@Service
public class MasterDataInMemoryService {
	static final Logger log = LoggerFactory.getLogger(MasterDataInMemoryService.class);
	@Autowired
	private UserUtilsDao userUtilsDao;
	
	 private Map<String, List<RoleADGrpMultiUserMdl>> masterDataMap = new HashMap<>();
	 
	@PostConstruct
    public void loadMasterDataOnStartup() {        
        loadMasterData();
    }
	
	public void loadMasterData() {
		 try {
			 if(masterDataMap.size() > 0) {
				 log.debug("memory already exist");
			 }else {
				 log.debug("memory not exist filling the data");
				 List<RoleADGrpMultiUserMdl> masterDataList = userUtilsDao.getAllMstDataForMultiUserADGrp();
				 for (RoleADGrpMultiUserMdl data : masterDataList) {
			            String key = getKey(data.getSysId(), data.getAdgrpName());
			            List<RoleADGrpMultiUserMdl> dataList = masterDataMap.getOrDefault(key, new ArrayList<>());
			            dataList.add(data);
			            masterDataMap.put(key, dataList);
			     }
			 }
			 log.debug("memory filled with data :"+masterDataMap.size());
		 }catch(Exception ee) {
			 log.error("Error while loading master data: " + ee.getMessage(), ee);
		 }	
		 for (Map.Entry<String, List<RoleADGrpMultiUserMdl>> entry : masterDataMap.entrySet()) {
			    String key = entry.getKey();
			    List<RoleADGrpMultiUserMdl> values = entry.getValue();

			    log.debug("--------------->Key: " + key);
			    log.debug("--------------->Values: ");
			    
			    for (RoleADGrpMultiUserMdl value : values) {
			    	log.debug("  " + value.toString());
			    }
			}
	}
	private String getKey(String sysId, String adName) {		
	        return sysId + "_" + adName.toUpperCase();
	}
	public List<RoleADGrpMultiUserMdl> findBySYS_IDAndAD_NAME(String sysId, String adName) {
		 log.debug("findBySYS_IDAndAD_NAME called ");
	        String key = getKey(sysId, adName);
	        log.debug("findBySYS_IDAndAD_NAME called : key :"+key);
	        return masterDataMap.getOrDefault(key, new ArrayList<>());
	}

}
