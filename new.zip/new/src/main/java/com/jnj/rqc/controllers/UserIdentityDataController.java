package com.jnj.rqc.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.jnj.rqc.common.sorting.UserMdlComparatorLF;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.dbextr.models.ADGroupRespDto;
import com.jnj.rqc.dbextr.models.CRADGroupRespDto;
import com.jnj.rqc.dbextr.models.ConsRespUnitReq;
import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.DBSchemaInt;
import com.jnj.rqc.dbextr.models.DDMultiRespDto;
import com.jnj.rqc.dbextr.models.DDRespDto;
import com.jnj.rqc.dbextr.models.MstInParams;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.ExcessiveAccessModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.SearchUserName;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.TktApprLogMdl;
import com.jnj.rqc.models.UETktModel;
import com.jnj.rqc.models.UserRequestDispMdl;
import com.jnj.rqc.models.UserRequestModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.responseDto.UserSrchRespDto;
import com.jnj.rqc.service.BelmontJDAConflictService;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserIdentityService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.useridentity.models.UIReqDpendncMdl;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.useridentity.models.UIRequestModel;
import com.jnj.rqc.useridentity.models.UserIdentityConflictMdl;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;
import com.jnj.rqc.useridentity.models.UserRolesRespDto;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;



/**
 * File    : <b>UserIdentityDataController.java</b>
 * @author : DChauras @Created : Nov 9, 2021 12:05:56 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Controller
public class UserIdentityDataController {
	static final Logger log = LoggerFactory.getLogger(UserIdentityDataController.class);
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	UserIdentityService userIdentityService;
	@Autowired
	RqcSapConflictService rqcSapConflictService;
	@Autowired
	BelmontJDAConflictService belmontJDAConflictService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	UserIdentityDao userIdentityDao;


	@PostMapping("/getUserDetails")
    public ResponseEntity<UserSrchRespDto> getUserDetails(Model model,  @RequestBody SearchUserName searchUserName, HttpServletRequest req) {
    	log.info("Received userName: "+searchUserName.getUserName());
    	UserSrchRespDto userRespDto = new UserSrchRespDto();
    	List<UserSearchModel> usrLst = sAPExtrGaaDataService.getUserListFromJJEDS(searchUserName.getUserName(), 0);
    	for(UserSearchModel usr : usrLst ) {
    		String supId = usr.getJnjSupvrWwId();
    		if(!Utility.isEmpty(supId)) {
    			UserSearchModel mgr = sAPExtrGaaDataService.getUserStatusJJEDS(supId, 1);
    			if(mgr != null) {
    				usr.setJnjSupvrName(mgr.getFmlyNm()+" "+mgr.getGivenNm());
    				usr.setJnjSupvrEmail(mgr.getJnjEmailAddrTxt());
    			}
    		}
    	}
    	if(usrLst != null && !usrLst.isEmpty()) {
    		Collections.sort(usrLst, new UserMdlComparatorLF());
    	}else {
    		usrLst=new ArrayList<>();
    	}
    	userRespDto.setStatusCode(0);
        userRespDto.setUsers(usrLst);
        userRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	if (userRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(userRespDto, HttpStatus.OK);
        } else if (userRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(userRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(userRespDto, HttpStatus.NOT_FOUND);
        }
    }



	@PostMapping("/getBussFuncSectors")
    public ResponseEntity<DDRespDto> getBussFuncSectors(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Buss Func IDS: "+dBSchema.getSchema());
    	List<KeyValPair> secNms= new ArrayList<>();
    	secNms = userIdentityService.getBussFuncSectors(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(secNms);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getPrjSystemsData")
    public ResponseEntity<DDRespDto> getPrjSystemsData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Prj IDS: "+dBSchema.getSchema());//Add new Table mapping
    	DDRespDto tableRespDto = userIdentityService.getProjectSystemsData(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getRegSystems")
    public ResponseEntity<DDRespDto> getRegSystems(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Region IDS: "+dBSchema.getSchema());
    	List<KeyValPair> regNms= new ArrayList<>();
    	regNms = userIdentityService.getRegionSystems(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(regNms);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getRegsProjectData")
    public ResponseEntity<DDRespDto> getRegsProjectData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Region IDS: "+dBSchema.getSchema());
    	List<KeyValPair> projectNames = userIdentityService.getAllProjects();
    	DDRespDto respDto = new DDRespDto();
		respDto.setStatusCode(0);
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		respDto.setTables(projectNames);

    	if (respDto.getStatusCode() == 0) {
			return new ResponseEntity<>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(respDto, HttpStatus.NOT_FOUND);
        }
    }



	@PostMapping("/getSystemsPositions")
    public ResponseEntity<DDRespDto> getSystemsPositions(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received System IDS: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getPositionForSystems(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }



	@PostMapping("/getTypeOfAccess")
    public ResponseEntity<DDRespDto> getTypeOfAccess(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Position IDS: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getPosAccessTypes(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getPosVariants")
    public ResponseEntity<DDRespDto> getPosVariants(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Access IDS: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getAcsPosnVariant(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }







	@GetMapping("/getUserPersonalInfo/{pageId}")
    public String getUserPersonalInfo(@PathVariable int pageId, Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadUserProperty("REGION");
    	model.addAttribute("pageId", pageId+"");
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("AUTH_USER", request.getSession().getAttribute(Constants.AUTH_USER));
    	return "useridm/personalinfopage";
    }





	@GetMapping("/loadNewUserRoleSelection")
    public String loadNewUserRoleSelection(Model model, HttpServletRequest request) {
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames = userIdentityService.getAllProjects();
		List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");

    	model.addAttribute("reqType", reqType );
    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("bussFunctions", bussFunctions);
    	model.addAttribute("AUTH_USER", curUser);
    	model.addAttribute("REQ_FOR", "2");
    	return "useridm/userNewRoleSelectionpage";
    }

	@GetMapping("/loadNewUserRoleSelection/{reqFor}")
    public String loadNewUserRoleSelectionParam(@PathVariable String reqFor, Model model, HttpServletRequest request) {
		log.info("reqFor :"+reqFor);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames = userIdentityService.getAllProjects();
		List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");

		if("1".equals(reqFor) && (curUser.getJnjSupvrWwId() != null)) {
			UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(curUser.getJnjSupvrWwId(), 0);
			model.addAttribute("USER_MGR", mgrUser);
		}
    	model.addAttribute("reqType", reqType );
    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("bussFunctions", bussFunctions);
    	model.addAttribute("AUTH_USER", curUser);
    	model.addAttribute("REQ_FOR", reqFor);
    	return "useridm/userNewRoleSelectionpage";
    }

	@PostMapping("/getBussProcessSectors")
    public ResponseEntity<DDRespDto> getBussProcessSectors(Model model, @RequestBody DBSchemaInt dBSchema, HttpServletRequest req) {
    	//log.info("Received IDS: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getBussProcessSectors();
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getSectorRegions")
    public ResponseEntity<DDRespDto> getSectorRegions(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Sector ID's: "+dBSchema.getSchema());
    	List<KeyValPair> accFLst = userIdentityService.getAllSectorRegions(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(accFLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getCntryAccFuncData")
    public ResponseEntity<DDRespDto> getCntryAccFuncData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Region IDs: "+dBSchema.getSchema());
    	List<KeyValPair> cntryLst = userIdentityService.getCntryAccFunctions(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(cntryLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }



	@GetMapping("/loadUserRoleSelection")
    public String loadUserRoleSelection(Model model, HttpServletRequest request) {
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames = userIdentityService.getAllProjects();
		model.addAttribute("reqType", reqType );
    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("AUTH_USER", curUser);
    	return "useridm/userselectionpage";
    }



	@PostMapping("/getNewUserSelectionFormData")
    public String getNewUserSelectionFormData(@RequestParam("reqTyp") String reqTyp, @RequestParam("projects") String projects, @RequestParam("bussFunc") String bussFunc,
    		@RequestParam("bussProc") String bussProc, @RequestParam("sctorNm") String sctorNm, @RequestParam("regions") String regions,
    		@RequestParam("countryNm") String countryNm, @RequestParam("accFunction") String accFunction, @RequestParam("consUnit") String consUnit,
    		@RequestParam("respUnit") String respUnit, @RequestParam("assocWwid") String assocWwid, @RequestParam("cmnts") String cmnts, Model model, HttpServletRequest request
    		/*,@RequestParam("usrPersona") @Nullable String usrPersona, @RequestParam("usrPosition") @Nullable String usrPosition, @RequestParam("appRole") String appRole*/ ) {
    	log.info("reqTyp: "+reqTyp+" projects: "+projects+" bussFunc: "+bussFunc+" bussProc: "+bussProc+" sctorNm: "+sctorNm+"  regions: "+regions+
    			"  countryNm: "+countryNm+" accFunction: "+accFunction+" consUnit: "+consUnit+" respUnit: "+respUnit+" assocWwid:"+assocWwid);
    	//log.info("usrPersona: "+usrPersona+" usrPosition: "+usrPosition+" appRole:"+appRole);

    	UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocWwid, 1);
    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());
    	model.addAttribute("assocMgrWwid", assocUser.getJnjSupvrWwId());
    	model.addAttribute("assocEmail", assocUser.getJnjEmailAddrTxt());
    	model.addAttribute("assocDept", assocUser.getJnjDeptmDescnTxt());
    	////
		/*List<KeyValPair> usrPersonas 	= new ArrayList<KeyValPair>();
		List<KeyValPair> usrPositions 	= new ArrayList<KeyValPair>();
		List<KeyValPair> appRoles 		= new ArrayList<KeyValPair>();
		if(usrPersona != null && usrPersona.length() > 0) {
			usrPersonas 	= userIdentityService.getProjectPersonas(projects);
			appRoles 		= userIdentityService.getPersonaRoles(usrPersona);
		}else {
			usrPersona="";
		}
		if(usrPosition != null && usrPosition.length() > 0) {
			usrPositions 	= userIdentityService.getProjectPositions(projects);
			appRoles 		= userIdentityService.getPositionRoles(usrPosition);
		}else{
			usrPosition="";
		}*/
		////
    	if(assocUser.getJnjSupvrWwId() != null) {
    		UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 0);
    		model.addAttribute("USER_MGR", mgrUser);
    	}
    	UserSearchModel curUser 		= (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		List<KeyValPair> reqType 		= userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames 	= userIdentityService.getAllProjects();
		List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
		List<StrKeyValPair> bussProcess = userIdentityService.getBusinesProcess(bussFunc);
		List<KeyValPair> sectors 		= userIdentityService.getBussProcessSectorsKV();
		List<KeyValPair> regLst 		= userIdentityService.getAllSectorRegions(sctorNm);
		List<KeyValPair> cntryLst 		= userIdentityService.getRegCountries(regions);
		List<KeyValPair> accFunctions   =  userIdentityService.getCntryAccFunctions(countryNm);
		List<StrKeyValPair> consUnits   = userIdentityService.getConsUnitCntryAccf(countryNm, accFunction);
		List<StrKeyValPair> respUnits   = userIdentityService.getRespUnitCntryAccf(countryNm, accFunction);

		String rqTypParam = reqTyp;
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	String prjParam = projects;
    	model.addAttribute("prjParam", Integer.parseInt(prjParam));
    	model.addAttribute("projectNames", projectNames);


    	String bfObjParam = "["+bussFunc+"]";
    	model.addAttribute("bfObjParam", bfObjParam);
    	model.addAttribute("bussFunctions", bussFunctions);

    	String bpObjParam = "["+bussProc+"]";
    	model.addAttribute("bpObjParam", bpObjParam);
    	model.addAttribute("bussProcess", bussProcess);

    	String secObjParam = "["+sctorNm+"]";
    	model.addAttribute("secObjParam", secObjParam);
    	model.addAttribute("sectors", sectors);

    	String regParam =  "["+regions+"]";
    	model.addAttribute("regParam", regParam);
    	model.addAttribute("regNames", regLst);

    	String cntryParam =  "["+countryNm+"]";
    	model.addAttribute("cntryParam", cntryParam);
    	model.addAttribute("countries", cntryLst);

    	String acFncParam = "["+accFunction+"]";
    	model.addAttribute("acFncParam", acFncParam);
    	model.addAttribute("accFunctions", accFunctions);


    	//List<CRUnitADGroupMdl> consAdLst =  userIdentityService.getADGroupByType(consUnit, "C");
    	//model.addAttribute("consAdLst", consAdLst);
    	String consUnParam =  "["+consUnit+"]";
    	model.addAttribute("consUnParam", consUnParam);
    	model.addAttribute("consUnits", consUnits);



    	//List<CRUnitADGroupMdl> respAdLst =  userIdentityService.getADGroupByType(respUnit, "R");
    	//model.addAttribute("respAdLst", respAdLst);
    	String respUnParam = respUnit ;
    	model.addAttribute("respUnParam", respUnParam);
    	model.addAttribute("respUnits", respUnits);


    	model.addAttribute("cmntsParam", cmnts);
    	model.addAttribute("ENABLE_SUBMIT", "Y");

    	/*Getting Current Roles & Conflicts*/
    	try{
    		//START - HCS ROLES & CONFLICTS
    		List<PersonalSysModel> hcsCurRoleList = rqcSapConflictService.getUserExistingRoles(assocUser.getWwId());
    		if(hcsCurRoleList != null && !hcsCurRoleList.isEmpty()) {
    			model.addAttribute("hcsCurRoleList", hcsCurRoleList);
    			request.getSession().setAttribute("hcsCurRoleList", hcsCurRoleList);

    			List<MatrixModel> hcsUsrLvlConfRoles = new ArrayList<>();

        		if(hcsCurRoleList.size() > 1) {
        			String[] roleIds = rqcSapConflictService.getRoleIdsPersonalSys(hcsCurRoleList);
        			hcsUsrLvlConfRoles = rqcSapConflictService.getUserLevelConflictingRoles(assocUser.getWwId(), roleIds);
        			MatrixModel mdl = new MatrixModel();
        			mdl.setRole1(1);
        			mdl.setRole2(2);
        			mdl.setApp1("TEST APP 1");
        			mdl.setApp2("TEST APP 2");
        			mdl.setConflict("TEST APP 1/TEST APP 2");
        			mdl.setMitigatingControl("Testing Display of Conflicts");
        			hcsUsrLvlConfRoles.add(mdl);
        			if(hcsUsrLvlConfRoles != null && !hcsUsrLvlConfRoles.isEmpty()) {
        				model.addAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
        				request.getSession().setAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
        			}
        		}
    		}
    		//END - HCS ROLES & CONFLICTS

    		//START - JDA ROLES & CONFLICTS
    		Map<String, List<String>> jdaCurrentRoleMap = belmontJDAConflictService.getUserExistingRoles(assocUser.getWwId(), 4);//Hitting Production DataBase

    		if(jdaCurrentRoleMap != null && !jdaCurrentRoleMap.isEmpty()) {
    			request.getSession().setAttribute("jdaCurrentRoleMap", jdaCurrentRoleMap);
    			List<JDAPersonalSysMdl> jdaUserCurRlLst = belmontJDAConflictService.buildCurrentRolesData(request.getSession(), jdaCurrentRoleMap, assocUser);
    			model.addAttribute("jdaUserCurRlLst", jdaUserCurRlLst);
    			request.getSession().setAttribute("jdaUserCurRlLst", jdaUserCurRlLst);

    			//JDA (Internal) Conflicts in current roles
        		List<JDADBRiskModel> jdaUser2SodInternal =  belmontJDAConflictService.getUserLeverConflictsJDA(jdaCurrentRoleMap);
        		//test
        		if(jdaUser2SodInternal != null && !jdaUser2SodInternal.isEmpty()) {
        			List<JDAUser2SodModel> jdaUsr2SodLst = belmontJDAConflictService.convertToJDAUser2SodModel(jdaUser2SodInternal, assocUser);
        			if(jdaUsr2SodLst != null && !jdaUsr2SodLst.isEmpty()) {
        				model.addAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
        				request.getSession().setAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
        			}
        		}
    		}
    		//END - JDA ROLES & CONFLICTS
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	model.addAttribute("AUTH_USER", curUser);
    	return "useridm/usernewconfirmationpage";
    }




	@PostMapping("/getUserSelectionFormData")
    public String getUserSelectionFormData(@RequestParam("reqTyp") String reqTyp, @RequestParam("projects") String projects, @RequestParam("sctorNm") String sctorNm,
    		@RequestParam("usrPersona") @Nullable String usrPersona, @RequestParam("usrPosition") @Nullable String usrPosition, @RequestParam("appRole") String appRole,
    		@RequestParam("accFunction") String accFunction, @RequestParam("regions") String regions, @RequestParam("countryNm") String countryNm,
    		@RequestParam("consData") String consData, @RequestParam("respData") String respData, @RequestParam("assocWwid") String assocWwid, @RequestParam("cmnts") String cmnts, Model model, HttpServletRequest request) {
    	log.info("reqTyp: "+reqTyp+" projects: "+projects+" sctorNm: "+sctorNm+" accFunction: "+accFunction+"  regions: "+regions+"  countryNm: "+countryNm);
    	log.info("usrPersona: "+usrPersona+" usrPosition: "+usrPosition+" appRole:"+appRole);
    	log.info("consData: "+consData+" respData: "+respData+" assocWwid:"+assocWwid);

    	UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocWwid, 1);

    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());

    	UserSearchModel curUser 		= (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		List<KeyValPair> reqType 		= userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames 	= userIdentityService.getAllProjects();
		List<KeyValPair> sectors 		= userIdentityService.getAllSectors(projects);
		////
		List<KeyValPair> usrPersonas 	= new ArrayList<>();
		List<KeyValPair> usrPositions 	= new ArrayList<>();
		List<KeyValPair> appRoles 		= new ArrayList<>();
		if(usrPersona != null && usrPersona.length() > 0) {
			usrPersonas 	= userIdentityService.getProjectPersonas(projects);
			appRoles 		= userIdentityService.getPersonaRoles(usrPersona);
		}else {
			usrPersona="";
		}
		if(usrPosition != null && usrPosition.length() > 0) {
			usrPositions 	= userIdentityService.getProjectPositions(projects);
			appRoles 		= userIdentityService.getPositionRoles(usrPosition);
		}else{
			usrPosition="";
		}
		////
		List<KeyValPair> accFunctions =  userIdentityService.getAccFunctions(sctorNm);
		List<KeyValPair> regLst = userIdentityService.getAllFuncRegions(accFunction);
		List<KeyValPair> cntryLst = userIdentityService.getRegCountries(regions);
		List<StrKeyValPair> consUnits = userIdentityService.getConsUnitCntrySec(countryNm, sctorNm);
		List<StrKeyValPair> respUnits = userIdentityService.getRespUnitCntrySec(countryNm, sctorNm);

		String rqTypParam = reqTyp;
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	String prjParam = projects;
    	model.addAttribute("prjParam", Integer.parseInt(prjParam));
    	model.addAttribute("projectNames", projectNames);

    	String secObjParam = "["+sctorNm+"]";
    	model.addAttribute("secObjParam", secObjParam);
    	model.addAttribute("sectors", sectors);

    	//////////////////
    	String persParam = "["+usrPersona+"]";
    	model.addAttribute("selPersona", persParam);
    	model.addAttribute("usrPersonas", usrPersonas);

    	String posParam = "["+usrPosition+"]";
    	model.addAttribute("selPosition", posParam);
    	model.addAttribute("usrPositions", usrPositions);

    	String appRlParam = "["+appRole+"]";
    	model.addAttribute("selRole", appRlParam);
    	model.addAttribute("appRoles", appRoles);
    	/////////////////

    	String acFncParam = "["+accFunction+"]";
    	model.addAttribute("acFncParam", acFncParam);
    	model.addAttribute("accFunctions", accFunctions);

    	String regParam =  "["+regions+"]";
    	model.addAttribute("regParam", regParam);
    	model.addAttribute("regNames", regLst);

    	String cntryParam =  "["+countryNm+"]";
    	model.addAttribute("cntryParam", cntryParam);
    	model.addAttribute("countries", cntryLst);

    	String consUnParam =  "["+consData+"]";
    	model.addAttribute("consUnParam", consUnParam);
    	model.addAttribute("consUnits", consUnits);

    	String[] respUnParam = respData.split(",");
    	model.addAttribute("respUnParam", respUnParam);
    	model.addAttribute("respUnits", respUnits);
    	model.addAttribute("cmntsParam", cmnts);
    	model.addAttribute("ENABLE_SUBMIT", "Y");

    	/*Getting Current Roles & Conflicts*/
    	try{
    		//START - HCS ROLES & CONFLICTS
    		List<PersonalSysModel> hcsCurRoleList = rqcSapConflictService.getUserExistingRoles(assocUser.getWwId());
    		if(hcsCurRoleList != null && !hcsCurRoleList.isEmpty()) {
    			model.addAttribute("hcsCurRoleList", hcsCurRoleList);
    			request.getSession().setAttribute("hcsCurRoleList", hcsCurRoleList);

    			List<MatrixModel> hcsUsrLvlConfRoles = new ArrayList<>();

        		if(hcsCurRoleList.size() > 1) {
        			String[] roleIds = rqcSapConflictService.getRoleIdsPersonalSys(hcsCurRoleList);
        			hcsUsrLvlConfRoles = rqcSapConflictService.getUserLevelConflictingRoles(assocUser.getWwId(), roleIds);
        			if(hcsUsrLvlConfRoles != null && !hcsUsrLvlConfRoles.isEmpty()) {
        				model.addAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
        				request.getSession().setAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
        			}
        		}
    		}
    		//END - HCS ROLES & CONFLICTS

    		//START - JDA ROLES & CONFLICTS
    		Map<String, List<String>> jdaCurrentRoleMap = belmontJDAConflictService.getUserExistingRoles(assocUser.getWwId(), 4);//Hitting Production DataBase

    		if(jdaCurrentRoleMap != null && !jdaCurrentRoleMap.isEmpty()) {
    			request.getSession().setAttribute("jdaCurrentRoleMap", jdaCurrentRoleMap);
    			List<JDAPersonalSysMdl> jdaUserCurRlLst = belmontJDAConflictService.buildCurrentRolesData(request.getSession(), jdaCurrentRoleMap, assocUser);
    			model.addAttribute("jdaUserCurRlLst", jdaUserCurRlLst);
    			request.getSession().setAttribute("jdaUserCurRlLst", jdaUserCurRlLst);

    			//JDA (Internal) Conflicts in current roles
        		List<JDADBRiskModel> jdaUser2SodInternal =  belmontJDAConflictService.getUserLeverConflictsJDA(jdaCurrentRoleMap);
        		//test
        		if(jdaUser2SodInternal != null && !jdaUser2SodInternal.isEmpty()) {
        			List<JDAUser2SodModel> jdaUsr2SodLst = belmontJDAConflictService.convertToJDAUser2SodModel(jdaUser2SodInternal, assocUser);
        			if(jdaUsr2SodLst != null && !jdaUsr2SodLst.isEmpty()) {
        				model.addAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
        				request.getSession().setAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
        			}
        		}
    		}
    		//END - JDA ROLES & CONFLICTS
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	model.addAttribute("AUTH_USER", curUser);
    	return "useridm/userconfirmationpage";
    }


	@SuppressWarnings("all")
	@PostMapping("/saveUserSelectionFormData")
    public String saveUserSelectionFormData(@RequestParam("reqTyp") String reqTyp, @RequestParam("projects") String projects, @RequestParam("sctorNm") String sctorNm,
    		@RequestParam("usrPersona") @Nullable String usrPersona, @RequestParam("usrPosition") @Nullable String usrPosition, @RequestParam("appRole") String appRole,
    		@RequestParam("accFunction") String accFunction, @RequestParam("regions") String regions, @RequestParam("countryNm") String countryNm,
    		@RequestParam("consData") String consData, @RequestParam("respData") String respData,  @RequestParam("assocWwid") String assocWwid, @RequestParam("cmnts") String cmnts, Model model, HttpServletRequest request) {
    	log.info("SAVE DATA : reqTyp: "+reqTyp+" projects: "+projects+" sctorNm: "+sctorNm+" accFunction: "+accFunction+"  regions: "+regions+"  countryNm: "+countryNm+"  consData: "+consData+" respData: "+respData+" assocWwid:"+assocWwid);

    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocWwid, 1);
    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());
    	/*Getting All Values & Current Roles with Conflicts*/

		List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames = userIdentityService.getAllProjects();
		List<KeyValPair> sectors = userIdentityService.getAllSectors(projects);
		////
		List<KeyValPair> usrPersonas 	= new ArrayList<>();
		List<KeyValPair> usrPositions 	= new ArrayList<>();
		List<KeyValPair> appRoles 		= new ArrayList<>();
		if(usrPersona != null && usrPersona.length() > 0) {
			usrPersonas 	= userIdentityService.getProjectPersonas(projects);
			appRoles 		= userIdentityService.getPersonaRoles(usrPersona);
		}else {
			usrPersona="";
		}
		if(usrPosition != null && usrPosition.length() > 0) {
			usrPositions 	= userIdentityService.getProjectPositions(projects);
			appRoles 		= userIdentityService.getPositionRoles(usrPosition);
		}else{
			usrPosition="";
		}
		////

		List<KeyValPair> accFunctions =  userIdentityService.getAccFunctions(sctorNm);
		List<KeyValPair> regLst = userIdentityService.getAllFuncRegions(accFunction);
		List<KeyValPair> cntryLst = userIdentityService.getRegCountries(regions);
		List<StrKeyValPair> consUnits = userIdentityService.getConsUnitCntrySec(countryNm, sctorNm);
		List<StrKeyValPair> respUnits = userIdentityService.getRespUnitCntrySec(countryNm, sctorNm);

		String rqTypParam = reqTyp;
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	String prjParam = projects;
    	model.addAttribute("prjParam", Integer.parseInt(prjParam));
    	model.addAttribute("projectNames", projectNames);

    	String secObjParam = "["+sctorNm+"]";
    	model.addAttribute("secObjParam", secObjParam);
    	model.addAttribute("sectors", sectors);
		//////////////////
		String persParam = "["+usrPersona+"]";
		model.addAttribute("selPersona", persParam);
		model.addAttribute("usrPersonas", usrPersonas);

		String posParam = "["+usrPosition+"]";
		model.addAttribute("selPosition", posParam);
		model.addAttribute("usrPositions", usrPositions);

		String appRlParam = "["+appRole+"]";
		model.addAttribute("selRole", appRlParam);
		model.addAttribute("appRoles", appRoles);
		/////////////////
    	String acFncParam = "["+accFunction+"]";
    	model.addAttribute("acFncParam", acFncParam);
    	model.addAttribute("accFunctions", accFunctions);

    	String regParam =  "["+regions+"]";
    	model.addAttribute("regParam", regParam);
    	model.addAttribute("regNames", regLst);

    	String cntryParam =  "["+countryNm+"]";
    	model.addAttribute("cntryParam", cntryParam);
    	model.addAttribute("countries", cntryLst);

    	String consUnParam =  "["+consData+"]";
    	model.addAttribute("consUnParam", consUnParam);
    	model.addAttribute("consUnits", consUnits);

    	String[] respUnParam = respData.split(",");
    	model.addAttribute("respUnParam", respUnParam);
    	model.addAttribute("respUnits", respUnits);

    	model.addAttribute("cmntsParam", cmnts);

    	try{
    		//START - HCS ROLES & CONFLICTS
    		List<PersonalSysModel> hcsCurRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("hcsCurRoleList");
    		if(hcsCurRoleList != null && !hcsCurRoleList.isEmpty()) {
    			model.addAttribute("hcsCurRoleList", hcsCurRoleList);
    			List<MatrixModel> hcsUsrLvlConfRoles =(List<MatrixModel>)request.getSession().getAttribute("hcsUsrLvlConfRoles");
    			if(hcsUsrLvlConfRoles != null && !hcsUsrLvlConfRoles.isEmpty()) {
    				model.addAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
    			}
    		}
    		//END - HCS ROLES & CONFLICTS

    		//START - JDA ROLES & CONFLICTS
    		Map<String, List<String>> jdaCurrentRoleMap = (Map<String, List<String>>)request.getSession().getAttribute("jdaCurrentRoleMap");
    		if(jdaCurrentRoleMap != null && !jdaCurrentRoleMap.isEmpty()) {
    			List<JDAPersonalSysMdl> jdaUserCurRlLst = (List<JDAPersonalSysMdl>)request.getSession().getAttribute("jdaUserCurRlLst");
    			model.addAttribute("jdaUserCurRlLst", jdaUserCurRlLst);
				List<JDAUser2SodModel> jdaUsr2SodLst = (List<JDAUser2SodModel>)request.getSession().getAttribute("jdaUsr2SodLst");
    			if(jdaUsr2SodLst != null && !jdaUsr2SodLst.isEmpty()) {
    				model.addAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
    			}
    		}
    		//END - JDA ROLES & CONFLICTS

	    	if(null== curUser || null == curUser.getWwId()) {
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "User Session has expired, Please Re-Login to continue");
	    		return "useridm/userconfirmationpage";
	    	}

	    	if(!(assocUser != null && reqTyp != null && projects != null && appRole != null && sctorNm != null && accFunction != null && regions != null && countryNm != null && consData != null && respData != null)) {
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "Missing required values, Please select all mandatory fields to save Data");
	    		return "useridm/userconfirmationpage";
	    	}

	    	UserRequestModel reqModel = buildRequestModel(reqTyp, projects, sctorNm, usrPersona, usrPosition, appRole, accFunction, regions , countryNm , consData , respData, cmnts, curUser, assocUser);
	    	reqModel.setReqStatus(1);
	    	int requestId = userIdentityService.saveRequestData(reqModel, curUser, assocUser);

	    	if(requestId == 0) {
	    		model.addAttribute("ENABLE_SUBMIT", "Y");
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "Request cannot be saved, Please try again later");
	    		return "useridm/userconfirmationpage";
	    	}
	    	model.addAttribute("TKT_NUMBER", requestId);
	    	String msg  = "Status: Saved User Request Data, With TKT Number:: "+ requestId;
	    	model.addAttribute("message", "True");
	    	model.addAttribute("success", msg);
	    	model.addAttribute("ENABLE_SUBMIT", "N");
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	return "useridm/ticketconfirmationpage";//Routing to confirmation page.
    }


	@GetMapping("/showAllRequests")
    public String showAllRequests(Model model, HttpServletRequest request) {
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	List<KeyValPair> projectNames = userIdentityService.getAllProjects();
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();

    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("statusNms", statusNms);
	  return "useridm/viewrequestspage";
    }

	@PostMapping("/getUserRequestData")
    public String getUserRequestData(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, @RequestParam("projects") int projects,
    		@RequestParam("status") int status, @RequestParam("userWwId") String userWwId, Model model, HttpServletRequest request) {

		log.info("startDate :"+startDate+"  endDate:"+endDate+"  projects: "+projects+" status :"+status+"  userWwId: "+userWwId);
    	List<KeyValPair> projectNames = userIdentityService.getAllProjects();
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("statusNms", statusNms);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	model.addAttribute("prjParam",projects);
    	model.addAttribute("stParam",status);
    	model.addAttribute("userWwId",userWwId);

    	if(startDate.isEmpty() || endDate.isEmpty()) {
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
    		return "useridm/viewrequestspage";
    	}
    	Date stDt = Utility.fmtStrToDate(startDate);
		Date enDt = Utility.fmtStrToDate(endDate);
    	if(stDt.after(enDt)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates : Start date cannot be greater than End date....!");
            return "useridm/viewrequestspage";
    	}
    	List<UserRequestDispMdl> allReqLst = new ArrayList<>();
    	try{
			allReqLst = userIdentityService.getAllRequests(startDate, endDate, projects, status, userWwId);
			model.addAttribute("USERREQ_DATA", allReqLst);
			model.addAttribute("message", "True");
			if(!allReqLst.isEmpty()) {
				model.addAttribute("success", "Total rows returned: "+allReqLst.size());
    		}else {
    			model.addAttribute("success", "Total rows returned: 0");
    		}
		} catch (Exception e) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "ERROR:"+e.getMessage());
		}
    	return "useridm/viewrequestspage";
    }

	@GetMapping("/getMyRequestData")
    public String getMyRequestData(Model model, HttpServletRequest request) {
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	return "useridm/myrequestspage";
	}

	@PostMapping("/getMyRequestData")
    public String getMyRequestDataPost(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, Model model, HttpServletRequest request) {
		log.info("startDate :"+startDate+"  endDate:"+endDate);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);

    	if(startDate.isEmpty() || endDate.isEmpty()) {
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
    		return "useridm/myrequestspage";
    	}

    	Date stDt = Utility.fmtStrToDate(startDate);
    	Date enDt = Utility.fmtStrToDate(endDate);

    	if(stDt.after(enDt)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates : Start date cannot be greater than End date....!");
            return "useridm/myrequestspage";
    	}
    	List<UserRequestDispMdl> allReqLst = new ArrayList<>();
    	try{
			allReqLst = userIdentityService.getMyRequests(startDate, endDate, curUser.getWwId());
			model.addAttribute("MYREQ_DATA", allReqLst);
			model.addAttribute("message", "True");
			if(!allReqLst.isEmpty()) {
				model.addAttribute("success", "Total rows returned: "+allReqLst.size());
    		}else {
    			model.addAttribute("success", "Total rows returned: 0");
    		}
		} catch (Exception e) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "ERROR:"+e.getMessage());
		}
    	return "useridm/myrequestspage";
	}



	@GetMapping("/getApprovalQueue")
    public String getApprovalQueue(Model model, HttpServletRequest request) {
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	List<KeyValPair> projectNames = userIdentityService.getAllProjects();
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();

    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("statusNms", statusNms);
	  return "useridm/myApprovalQueuePage";
    }

	@PostMapping("/getApprovalQueData")
    public String getApprovalQueData(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, @RequestParam("projects") int projects
    		/*,@RequestParam("status") int status*/, Model model, HttpServletRequest request) {

		//log.info("startDate :"+startDate+"  endDate:"+endDate+"  projects: "+projects+" status :"+status);
		log.info("startDate :"+startDate+"  endDate:"+endDate+"  projects: "+projects);
    	List<KeyValPair> projectNames = userIdentityService.getAllProjects();
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);

    	model.addAttribute("projectNames", projectNames);
    	model.addAttribute("statusNms", statusNms);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	model.addAttribute("prjParam",projects);
    	//model.addAttribute("stParam",status);

    	if(startDate.isEmpty() || endDate.isEmpty()) {
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
    		return "useridm/myApprovalQueuePage";
    	}

    	Date stDt = Utility.fmtStrToDate(startDate);
		Date enDt = Utility.fmtStrToDate(endDate);
    	if(stDt.after(enDt)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates : Start date cannot be greater than End date....!");
            return "useridm/myApprovalQueuePage";
    	}
    	List<UserRequestDispMdl> allReqLst = new ArrayList<>();
    	try{
			allReqLst = userIdentityService.getMyApprQueData(startDate, endDate, projects, /*status,*/ curUser.getWwId());
			model.addAttribute("MYQUE_DATA", allReqLst);
			model.addAttribute("message", "True");
			if(!allReqLst.isEmpty()) {
				model.addAttribute("success", "Total rows returned: "+allReqLst.size());
    		}else {
    			model.addAttribute("success", "Total rows returned: 0");
    		}
		} catch (Exception e) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "ERROR:"+e.getMessage());
		}
    	return "useridm/myApprovalQueuePage";
    }


	@SuppressWarnings("all")
	@GetMapping("/getApprovalTktData")
	public String approveTktData(@RequestParam String tktnumber, Model model, HttpServletRequest request) {
		log.info("Received Ticket number: "+tktnumber);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", tktnumber );
		model.addAttribute("AUTH_USER", curUser );
		if(Utility.isEmpty(tktnumber)) {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number, Please check the number and try again!");
	        return "useridm/apprDenyRequest";
		}

		List<UETktModel>tktLst = userIdentityService.getTktData(tktnumber);
		if(tktLst != null && !tktLst.isEmpty()) {
			UETktModel ticket= tktLst.get(0);
			model.addAttribute("APPR_SEQ", ticket.getApprSeq());
			model.addAttribute("message", "True");
	        model.addAttribute("success", " Approval for request id ("+ticket.getReqId()+") ");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/apprDenyRequest";
		}
		return "useridm/apprDenyRequest";
	}

	@SuppressWarnings("all")
	@GetMapping("/getL2ApprovalTktData")
	public String getL2ApprovalTktData(@RequestParam String tktnumber, Model model, HttpServletRequest request) {
		log.info("Received Ticket number: "+tktnumber);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", tktnumber );
		model.addAttribute("AUTH_USER", curUser );
		if(Utility.isEmpty(tktnumber)) {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number, Please check the number and try again!");
	        return "useridm/apprDenyRequest";
		}

		List<UETktModel>tktLst = userIdentityService.getTktData(tktnumber);
		if(tktLst != null && !tktLst.isEmpty()) {
			UETktModel ticket= tktLst.get(0);
			model.addAttribute("APPR_SEQ", ticket.getApprSeq());
			model.addAttribute("message", "True");
	        model.addAttribute("success", " Approval for request id ("+ticket.getReqId()+") ");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/apprDenyRequest";
		}
		return "useridm/apprDenyRequest";
	}
	@SuppressWarnings("all")
	@PostMapping("/saveApprovalStage")
    public String saveApprovalStage(@RequestParam("tktnumber") String tktnumber, @RequestParam("approvedConslUnits") String approvedConslUnits, @RequestParam("deniedConslUnits") String deniedConslUnits,
    		@RequestParam("approvedResplUnits") String approvedResplUnits, @RequestParam("deniedResplUnits") String deniedResplUnits, @RequestParam("apprSeq") String apprSeq, @RequestParam("apprCmnts") String apprCmnts,
    		Model model, HttpServletRequest request) {
    	log.info("SAVE DATA : tktnumber: "+tktnumber+" approvedConslUnits: "+approvedConslUnits+" deniedConslUnits: "+deniedConslUnits+" approvedResplUnits: "+approvedResplUnits+"  deniedResplUnits: "+deniedResplUnits +" Approver Seq:"+apprSeq);
    	int reqStatus = 0;
    	int approvalCatg=0;
    	int approvalStat=0;
    	if("0".equals(apprSeq)) {
    		reqStatus 	 = 2;
    		approvalCatg = 1;
    		approvalStat = 1;
    	}

    	UserSearchModel approveUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", approveUser);

    	TktApprLogMdl appLogData = new TktApprLogMdl();
    	appLogData.setReqId(Integer.parseInt(tktnumber));
    	appLogData.setApproverId(approveUser.getWwId());
    	appLogData.setReqStatus(reqStatus);
    	appLogData.setApprovalCatg(approvalCatg+"");
    	appLogData.setApprovalStatus(approvalStat+"");
    	appLogData.setApprdConsUnits(approvedConslUnits);
    	appLogData.setDenidConsUnits(deniedConslUnits);
    	appLogData.setApprdRespUnits(approvedResplUnits);
    	appLogData.setDenidRespUnits(deniedResplUnits);
    	appLogData.setApprRemarks(apprCmnts);

    	userIdentityService.saveApprovalData(appLogData);


    	/*UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocWwid, 1);
    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());
    	Getting All Values & Current Roles with Conflicts

		List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
		List<KeyValPair> projectNames = userIdentityService.getAllProjects();
		List<KeyValPair> sectors = userIdentityService.getAllSectors(projects);
		List<KeyValPair> accFunctions =  userIdentityService.getAccFunctions(sctorNm);
		List<KeyValPair> regLst = userIdentityService.getAllFuncRegions(accFunction);
		List<KeyValPair> cntryLst = userIdentityService.getRegCountries(regions);
		List<StrKeyValPair> consUnits = userIdentityService.getConsUnitCntrySec(countryNm, sctorNm);
		List<StrKeyValPair> respUnits = userIdentityService.getRespUnitCntrySec(countryNm, sctorNm);

		String rqTypParam = reqTyp;
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	String prjParam = projects;
    	model.addAttribute("prjParam", Integer.parseInt(prjParam));
    	model.addAttribute("projectNames", projectNames);

    	String secObjParam = "["+sctorNm+"]";
    	model.addAttribute("secObjParam", secObjParam);
    	model.addAttribute("sectors", sectors);

    	String acFncParam = "["+accFunction+"]";
    	model.addAttribute("acFncParam", acFncParam);
    	model.addAttribute("accFunctions", accFunctions);

    	String regParam =  "["+regions+"]";
    	model.addAttribute("regParam", regParam);
    	model.addAttribute("regNames", regLst);

    	String cntryParam =  "["+countryNm+"]";
    	model.addAttribute("cntryParam", cntryParam);
    	model.addAttribute("countries", cntryLst);

    	String consUnParam =  "["+consData+"]";
    	model.addAttribute("consUnParam", consUnParam);
    	model.addAttribute("consUnits", consUnits);

    	String[] respUnParam = respData.split(",");
    	model.addAttribute("respUnParam", respUnParam);
    	model.addAttribute("respUnits", respUnits);

    	model.addAttribute("cmntsParam", cmnts);

    	try{
    		//START - HCS ROLES & CONFLICTS
    		List<PersonalSysModel> hcsCurRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("hcsCurRoleList");
    		if(hcsCurRoleList != null && !hcsCurRoleList.isEmpty()) {
    			model.addAttribute("hcsCurRoleList", hcsCurRoleList);
    			List<MatrixModel> hcsUsrLvlConfRoles =(List<MatrixModel>)request.getSession().getAttribute("hcsUsrLvlConfRoles");
    			if(hcsUsrLvlConfRoles != null && !hcsUsrLvlConfRoles.isEmpty()) {
    				model.addAttribute("hcsUsrLvlConfRoles", hcsUsrLvlConfRoles);
    			}
    		}
    		//END - HCS ROLES & CONFLICTS

    		//START - JDA ROLES & CONFLICTS
    		Map<String, List<String>> jdaCurrentRoleMap = (Map<String, List<String>>)request.getSession().getAttribute("jdaCurrentRoleMap");
    		if(jdaCurrentRoleMap != null && !jdaCurrentRoleMap.isEmpty()) {
    			List<JDAPersonalSysMdl> jdaUserCurRlLst = (List<JDAPersonalSysMdl>)request.getSession().getAttribute("jdaUserCurRlLst");
    			model.addAttribute("jdaUserCurRlLst", jdaUserCurRlLst);
				List<JDAUser2SodModel> jdaUsr2SodLst = (List<JDAUser2SodModel>)request.getSession().getAttribute("jdaUsr2SodLst");
    			if(jdaUsr2SodLst != null && !jdaUsr2SodLst.isEmpty()) {
    				model.addAttribute("jdaUsr2SodLst", jdaUsr2SodLst);
    			}
    		}
    		//END - JDA ROLES & CONFLICTS

	    	if(null== curUser || null == curUser.getWwId()) {
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "User Session has expired, Please Re-Login to continue");
	    		return "useridm/userconfirmationpage";
	    	}

	    	if(!(assocUser != null && reqTyp != null && projects != null && sctorNm != null && accFunction != null && regions != null && countryNm != null && consData != null && respData != null)) {
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "Missing required values, Please select all mandatory fields to save Data");
	    		return "useridm/userconfirmationpage";
	    	}

	    	int requestId = userIdentityService.saveRequestData(reqTyp, projects, sctorNm , accFunction, regions , countryNm , consData , respData, cmnts, curUser, assocUser);

	    	if(requestId == 0) {
	    		model.addAttribute("ENABLE_SUBMIT", "Y");
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "Request cannot be saved, Please try again later");
	    		return "useridm/userconfirmationpage";
	    	}
	    	model.addAttribute("TKT_NUMBER", requestId);
	    	String msg  = "Status: Saved User Request Data, With TKT Number:: "+ requestId;
	    	model.addAttribute("message", "True");
	    	model.addAttribute("success", msg);
	    	model.addAttribute("ENABLE_SUBMIT", "N");
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
*/    	return "useridm/ticketconfirmationpage";//Routing to confirmation page.
    }




	@SuppressWarnings("all")
	@GetMapping("/queryTktDetails")
	public String queryTktDetails(@RequestParam String tktnumber, Model model, HttpServletRequest request) {
		log.info("Received Ticket number: "+tktnumber);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", tktnumber );
		model.addAttribute("AUTH_USER", curUser );
		if(Utility.isEmpty(tktnumber)) {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number, Please check the number and try again!");
	        return "useridm/viewticketdetail";
		}

		List<UETktModel>tktLst = userIdentityService.getTktData(tktnumber);
		if(tktLst != null && !tktLst.isEmpty()) {


			UETktModel ticket= tktLst.get(0);
			model.addAttribute("message", "True");
	        model.addAttribute("success", " 1 Ticket Number match found displaying data");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/viewticketdetail";
		}
		return "useridm/viewticketdetail";
	}

	@PostMapping("/getProjectSectors")
    public ResponseEntity<DDRespDto> getProjectSectors(Model model, @RequestBody DBSchemaInt dBSchema, HttpServletRequest req) {
    	log.info("Received Property name: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getPrjChildObjects(dBSchema.getSchema()+"");
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	public List<KeyValPair> getAllSectors(String projId) {
		List<KeyValPair> sectors = userIdentityService.getAllSectors(projId);
		return sectors;
	}

	@PostMapping("/getPersonaRoles")
    public ResponseEntity<DDRespDto> getPersonaRoles(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received ID: "+dBSchema.getSchema());
    	List<KeyValPair> perLst = userIdentityService.getPersonaRoles(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(perLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getPositionRoles")
    public ResponseEntity<DDRespDto> getPositionRoles(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received ID: "+dBSchema.getSchema());
    	List<KeyValPair> posLst = userIdentityService.getPositionRoles(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(posLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getBussProcessInfo")
    public ResponseEntity<DDMultiRespDto> getBussProcessInfo(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received ID: "+dBSchema.getSchema());
    	List<StrKeyValPair> accFLst = userIdentityService.getBusinesProcess(dBSchema.getSchema());
    	DDMultiRespDto tableRespDto = new DDMultiRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTable1(accFLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getAccfConsRespUnits")
    public ResponseEntity<DDMultiRespDto> getAccfConsRespUnits(Model model, @RequestBody ConsRespUnitReq consRespUnitReq, HttpServletRequest req) {
    	log.info("Cntry IDs: "+consRespUnitReq.getCntryIds()+"  ACCF Ids:"+consRespUnitReq.getSecIds());
    	DDMultiRespDto tableRespDto = userIdentityService.getAccfConsRespUnits(consRespUnitReq.getCntryIds(), consRespUnitReq.getSecIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getADGrpsForConsRespUnit")
    public ResponseEntity<CRADGroupRespDto> getADGrpsConsRespUnit(Model model, @RequestBody ConsRespUnitReq consRespUnitReq, HttpServletRequest req) {
    	log.info("Consoildation Unit IDs: "+consRespUnitReq.getCntryIds()+"  Responsiblity Unit Ids:"+consRespUnitReq.getSecIds());
    	CRADGroupRespDto tableRespDto = userIdentityService.getADGroupsForConsRespUnits(consRespUnitReq.getCntryIds(), consRespUnitReq.getSecIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	/*OLD METHOD*/
	@PostMapping("/getAccountFunctions")
    public ResponseEntity<DDRespDto> getAccountFunctions(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received ID: "+dBSchema.getSchema());
    	List<KeyValPair> accFLst = userIdentityService.getAccFunctions(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(accFLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getFuncRegions")
    public ResponseEntity<DDRespDto> getFuncRegions(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received ID: "+dBSchema.getSchema());
    	List<KeyValPair> regLst = userIdentityService.getAllFuncRegions(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(regLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getCountriesData")
    public ResponseEntity<DDRespDto> getCountriesData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Region IDs: "+dBSchema.getSchema());
    	List<KeyValPair> cntryLst = userIdentityService.getRegCountries(dBSchema.getSchema());
    	DDRespDto tableRespDto = new DDRespDto();
    	tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(cntryLst);

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	//OLD Method
	@PostMapping("/getConsRespUnits")
    public ResponseEntity<DDMultiRespDto> getConsRespUnits(Model model, @RequestBody ConsRespUnitReq consRespUnitReq, HttpServletRequest req) {
    	log.info("Cntry IDs: "+consRespUnitReq.getCntryIds()+"  Sector Ids:"+consRespUnitReq.getSecIds());
    	DDMultiRespDto tableRespDto = userIdentityService.getConsRespUnits(consRespUnitReq.getCntryIds(), consRespUnitReq.getSecIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }












	@PostMapping("/getSectorsData")
    public ResponseEntity<DDRespDto> getSectorsData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Country IDs: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getCountrySectors(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getConsolidationUnitsData")
    public ResponseEntity<DDRespDto> getConsolidationUnitsData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Sector IDs: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getSectorConsUnit(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getResponsiblityUnitsData")
    public ResponseEntity<DDRespDto> getResponsiblityUnitsData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Sector IDs: "+dBSchema.getSchema());
    	DDRespDto tableRespDto = userIdentityService.getConsResponsiblityUnit(dBSchema.getSchema());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getUserEnvironmentData")
    public ResponseEntity<TableRespDto> getUserEnvironmentData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	//log.info("Received Property name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = userSearchService.getEnvData(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }



	private UserRequestModel buildRequestModel(String reqTyp, String projects, String sctorNm, String usrPersona, String usrPosition, String appRole,
			String accFunction, String regions, String countryNm, String consData, String respData, String cmnts, UserSearchModel curUser, UserSearchModel assocUser) {
		UserRequestModel reqMdl = new UserRequestModel();
		reqMdl.setReqTyp(Utility.strToNum(reqTyp));
		reqMdl.setPrjId(Utility.strToNum(projects));
		reqMdl.setSecIds(sctorNm);
		reqMdl.setPersonaIds(usrPersona);
		reqMdl.setPositionIds(usrPosition);
		reqMdl.setRoleIds(appRole);
		reqMdl.setAccfIds(accFunction);
		reqMdl.setRegIds(regions);
		reqMdl.setCntryIds(countryNm);
		reqMdl.setConsIds(consData);
		reqMdl.setRespIds(respData);
		reqMdl.setComments(cmnts);
		reqMdl.setReqDt(new Date());
		reqMdl.setReqBy(curUser.getWwId());
		reqMdl.setUserId(assocUser.getWwId());
		reqMdl.setMgrWwid(assocUser.getJnjSupvrWwId());
		reqMdl.setDtUpdated(new Date());
		reqMdl.setUpdtBy(curUser.getWwId());
		return reqMdl;

	}

	private UIRequestModel buildUIRequestModel(String reqTyp, String bfId, String secIds, String regIds, int reqStatus, String conflFound, String conflResolved, String routedToCompl, Date conflUpdated, String cmnts, UserSearchModel curUser, UserSearchModel assocUser, String isExces) {
		UIRequestModel reqMdl = new UIRequestModel();
		reqMdl.setReqTyp(Utility.strToNum(reqTyp));
		reqMdl.setReqDt(new Date());
		reqMdl.setReqBy(curUser.getWwId());
		reqMdl.setUserId(assocUser.getWwId());
		reqMdl.setMgrWwid(assocUser.getJnjSupvrWwId());
		reqMdl.setBfId(Utility.strToNum(bfId));
		reqMdl.setSecIds(secIds);
		reqMdl.setRegIds(regIds);
		reqMdl.setReqStatus(reqStatus);
		reqMdl.setConflFound(conflFound);
		reqMdl.setConflResolved(conflResolved);
		reqMdl.setRoutedToCompl(routedToCompl);
		reqMdl.setConflUpdated(conflUpdated);
		reqMdl.setDtUpdated(new Date());
		reqMdl.setUpdtBy(curUser.getWwId());
		reqMdl.setComments(cmnts);
		reqMdl.setIsExces(isExces);
		return reqMdl;
	}


	/*START - Adding All New Methods for Data Collection HERE*/

	@PostMapping("/getMSectorRegions")
    public ResponseEntity<DDRespDto> getMSectorRegions(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
    	log.info("Received BF ID's: "+dBSchema.getBfId()+ "  SEC ID's:"+dBSchema.getSecIds());
    	DDRespDto tableRespDto = userIdentityService.getAllMSectorRegions(dBSchema.getBfId(), dBSchema.getSecIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getSystemsForRegions")
    public ResponseEntity<DDRespDto> getSystemsForRegions(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
    	log.info("Received BF ID: "+dBSchema.getBfId()+"  Sec Ids:"+dBSchema.getSecIds()+"  Reg Ids:"+dBSchema.getRegIds());
    	DDRespDto tableRespDto = userIdentityService.getAllSystemsForRegns(dBSchema.getBfId(), dBSchema.getSecIds(), dBSchema.getRegIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getPositionsForSystem")
    public ResponseEntity<DDRespDto> getPositionsForSystem(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
		log.info("Received BF ID: "+dBSchema.getBfId()+"  Sec Ids:"+dBSchema.getSecIds()+"  Reg Ids:"+dBSchema.getRegIds()+" SysId:"+dBSchema.getSysId());
    	DDRespDto tableRespDto = userIdentityService.getAllPositionForSystem(dBSchema.getBfId(), dBSchema.getSecIds(), dBSchema.getRegIds(), dBSchema.getSysId());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getAccesTypForPositions")
    public ResponseEntity<DDRespDto> getAccesTypForPositions(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
		log.info("Received BF ID: "+dBSchema.getBfId()+"  Sec Ids:"+dBSchema.getSecIds()+"  Reg Ids:"+dBSchema.getRegIds()+" SysId:"+dBSchema.getSysId()+" PosIds:"+dBSchema.getPosIds() );
    	DDRespDto tableRespDto = userIdentityService.getAllAccessTypesForPosns(dBSchema.getBfId(), dBSchema.getSecIds(), dBSchema.getRegIds(), dBSchema.getSysId(), dBSchema.getPosIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getPosVarnForAcsTyps")
    public ResponseEntity<DDRespDto> getPosVarnForAcsTyps(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
		log.info("Received BF ID: "+dBSchema.getBfId()+"  Sec Ids:"+dBSchema.getSecIds()+"  Reg Ids:"+dBSchema.getRegIds()
		+" SysId:"+dBSchema.getSysId()+" PosIds:"+dBSchema.getPosIds()+" acsTypIds: "+dBSchema.getAcsTypIds());
    	DDRespDto tableRespDto = userIdentityService.getAllPosnVarnForAcsTyps(dBSchema.getBfId(), dBSchema.getSecIds(), dBSchema.getRegIds(), dBSchema.getSysId(), dBSchema.getPosIds(), dBSchema.getAcsTypIds());
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getAdGrpsForPosVar")
    public ResponseEntity<ADGroupRespDto> getAdGrpsForPosVar(Model model, @RequestBody MstInParams dBSchema, HttpServletRequest req) {
		log.info("Received BF ID: "+dBSchema.getBfId()+"  Sec Ids:"+dBSchema.getSecIds()+"  Reg Ids:"+dBSchema.getRegIds()
		+" SysId:"+dBSchema.getSysId()+" PosIds:"+dBSchema.getPosIds()+" acsTypIds: "+dBSchema.getAcsTypIds()+" posVarnts:"+dBSchema.getPosVarnts());
		ADGroupRespDto tableRespDto = userIdentityService.getAllADGrpsForPosnVarns(dBSchema.getBfId(), dBSchema.getSecIds(), dBSchema.getRegIds(), dBSchema.getSysId(), dBSchema.getPosIds(), dBSchema.getAcsTypIds(), dBSchema.getPosVarnts(), req);
    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/getUserAccessDetails")
    public ResponseEntity<UserRolesRespDto> getUserAccessDetails(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Property name: "+dBSchema.getSchema());
    	String userId = dBSchema.getSchema();
    	UserRolesRespDto tableRespDto = userIdentityService.getUserGrantedRoles(dBSchema.getSchema());
    	//Storing Users Existing Roles in Session
    	req.getSession().removeAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+userId);
    	if(tableRespDto.getRoles() != null && !tableRespDto.getRoles().isEmpty()) {
    		req.getSession().setAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+userId, tableRespDto.getRoles());
    	}
    	//End

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }



	@GetMapping("/startUserRequest")
    public String startUserRequest( Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadUserProperty("REGION");
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("AUTH_USER", request.getSession().getAttribute(Constants.AUTH_USER));
    	return "useridm/personalInfoMenu";
    }

	@GetMapping("/getNewAccessSelectionPage")
    public String getNewAccessSelectionPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadUserProperty("REGION");
    	List<KeyValPair> reqType = userIdentityService.getAllRequestTypes();
    	model.addAttribute("reqType", reqType );
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("AUTH_USER", request.getSession().getAttribute(Constants.AUTH_USER));
    	return "useridm/newAccessSelPage";
    }


	@PostMapping("/getNewAccessSelectionData")
    public String getNewAccessSelectionData(@RequestParam("assocWwid") String assocWwid, @RequestParam("reqTyp") String reqTyp, Model model, HttpServletRequest request) {
		log.info("reqFor :"+assocWwid+"  reqTyp:"+reqTyp);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(assocWwid, 0);
		model.addAttribute("assocUser", assocUser);
		request.getSession().setAttribute("assocUser", assocUser);
		request.getSession().setAttribute("reqTyp", reqTyp);

		if(assocUser.getJnjSupvrWwId() != null) {
			UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 0);
			if(assocMgr != null) {
				assocUser.setJnjSupvrName(assocMgr.getFmlyNm()+" "+assocMgr.getGivenNm()+"("+assocMgr.getJnjMsftUsrnmTxt()+")");
				assocUser.setJnjSupvrEmail(assocMgr.getJnjEmailAddrTxt());
			}
			model.addAttribute("USER_MGR", assocMgr);
		}
		List<KeyValPair> reqTypes = userIdentityService.getAllRequestTypes();
		List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
		model.addAttribute("reqType", reqTypes);
    	model.addAttribute("bussFunctions", bussFunctions);
    	model.addAttribute("AUTH_USER", curUser);
    	return "useridm/newAccessSelPageData";
    }


	@PostMapping("/newAccessSelectionConfirmation")
    public String newAccessSelectionConfirmation(@RequestParam("bussFunc") String bussFunc, @RequestParam("secCheckBx") String secCheckBx, @RequestParam("regCheckBx") String regCheckBx,
    		@RequestParam("selectedSystems") String selectedSystems, Model model, HttpServletRequest request) {
    	log.info("bussFunc: "+bussFunc+" secCheckBx: "+secCheckBx+" regCheckBx: "+regCheckBx+" selectedSystems:"+selectedSystems);

    	List<KeyValPair> newPosVarLst = new ArrayList<>();
    	List<KeyValPair> extPosVarLst = new ArrayList<>();
    	Map<String, List<KeyValPair>> adGrpMap = new HashMap<>();
    	Map<String, String> systemMap = new HashMap<>();
    	List<KeyValPair> systemLst = userIdentityService.getAllMasterRegionSystems(bussFunc, secCheckBx, regCheckBx);
    	model.addAttribute("systemLst", systemLst);
    	model.addAttribute("sysParam", selectedSystems);
    	request.getSession().setAttribute("sysParam", selectedSystems);
    	for(KeyValPair sysKv:systemLst) {
    		systemMap.put(sysKv.getKey()+"", sysKv.getVal());
    	}

    	List<SysPosAdGrpModelDispMdl> dispModelLst = new LinkedList<>();
    	for(String ky:selectedSystems.split(",")) {
    		String[] arrPosns 	= request.getParameterValues("usrPosition_"+ky);
    		String selPosns 	= Utility.getArrValues(arrPosns);
    		List<KeyValPair> posLst = userIdentityService.getAllMasterSystemPositions(bussFunc, secCheckBx, regCheckBx, ky, selPosns);//Position List
    		String[] arrAcssTyp = request.getParameterValues("accessType_"+ky);
    		String selAcssTyp 	= Utility.getArrValues(arrAcssTyp);
    		List<KeyValPair> acsTypLst = userIdentityService.getAllMasterPosnsAccsTypes(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp);
    		String[] arrPosnVr 	= request.getParameterValues("posnVariant_"+ky);
    		String selPosnVr  	= Utility.getArrValues(arrPosnVr);
    		List<KeyValPair> posVarLst = userIdentityService.getAllMasterAcsTypsPosVarnt(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp, selPosnVr);//Position Variants
    		newPosVarLst.addAll(posVarLst);//Collecting all Position Variants selected by User
    		List<KeyValPair> appAdGrps = new ArrayList<>();
    		List<UserRoleADGrpMdl> appUrAdGrps  = userIdentityService.getAllMasterPosVarntADGrp(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp, selPosnVr);
    		appUrAdGrps = userIdentityService.checkExistingADGroups(appUrAdGrps, request);
    		appUrAdGrps = userIdentityService.removeExistingADGroups(appUrAdGrps);
    		String adGrpIds="";
    		for(UserRoleADGrpMdl obj:appUrAdGrps){
    			KeyValPair kv = new KeyValPair();
    			kv.setKey(Integer.parseInt(obj.getAdgrpId()));
    			kv.setVal(obj.getAdgrpName());
    			appAdGrps.add(kv);
    			if("".equals(adGrpIds)) {
    				adGrpIds=obj.getAdgrpId();
    			}else {
    				adGrpIds+=","+obj.getAdgrpId();
    			}
    		}

    		List<String> allSysVarList = userIdentityService.getAllSystemPosVariants(bussFunc, secCheckBx, regCheckBx, ky);
    		List<KeyValPair> allSysVarListKV = userIdentityService.getAllSystemPosVariantsKV(bussFunc, secCheckBx, regCheckBx, ky);

    		SysPosAdGrpModelDispMdl dispMdl = new SysPosAdGrpModelDispMdl();
    		dispMdl.setBussFunc(bussFunc);
    		dispMdl.setSecIds(secCheckBx);
    		dispMdl.setRegIds(regCheckBx);
    		dispMdl.setSysId(ky);
    		dispMdl.setSysName(systemMap.get(ky));
    		dispMdl.setPosIds(selPosns);
    		dispMdl.setPositions(posLst);
    		dispMdl.setAscTypIds(selAcssTyp);
    		dispMdl.setAcsTypes(acsTypLst);
    		dispMdl.setPosVarIds(selPosnVr);
    		dispMdl.setPosnVariants(posVarLst);
    		dispMdl.setAdGrpIds(adGrpIds);
    		dispMdl.setAppAdGrps(appUrAdGrps);
    		dispMdl.setAllSysVarList(allSysVarList);
    		dispMdl.setAllSysVarListKV(allSysVarListKV);
    		dispModelLst.add(dispMdl);
    	}

    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	UserSearchModel assocUser = (UserSearchModel)request.getSession().getAttribute("assocUser");
    	model.addAttribute("assocUser", assocUser);
    	model.addAttribute("AUTH_USER", curUser);

    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());

    	List<KeyValPair> reqType 	= userIdentityService.getAllRequestTypes();
    	String rqTypParam 			= (String) request.getSession().getAttribute("reqTyp");
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
		model.addAttribute("bussFunctions", bussFunctions);
		model.addAttribute("bfuncParam", bussFunc);
		request.getSession().setAttribute("bfuncParam", bussFunc);

    	List<KeyValPair> sectrChkLst = userIdentityService.getBussFuncSectors(bussFunc);
    	model.addAttribute("sectrChkLst", sectrChkLst );
    	model.addAttribute("sectrParam", Arrays.asList(secCheckBx.split(",")));
    	request.getSession().setAttribute("sectrParam", secCheckBx);

    	List<KeyValPair> regnChkLst = userIdentityService.getAllMasterSectorRegions(bussFunc, secCheckBx);
    	model.addAttribute("regnChkLst", regnChkLst);
    	model.addAttribute("regnParam", Arrays.asList(regCheckBx.split(",")));
    	request.getSession().setAttribute("regnParam", regCheckBx);

    	model.addAttribute("dispDataLst", dispModelLst);//Data to Display
    	request.getSession().setAttribute("dispDataLst", dispModelLst);

    	try{
    		List<UserRoleADGrpMdl> extRoles = (request.getSession().getAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+assocUser.getWwId()) == null)? new ArrayList<>() : (List<UserRoleADGrpMdl>)request.getSession().getAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+assocUser.getWwId());
    		List<String> newPosnVarIds = new ArrayList<>();
    		List<String> extPosnVarIds = new ArrayList<>();
    		//newPosVarLst
    		newPosVarLst.forEach(er ->{
    			newPosnVarIds.add(er.getKey()+"");
    		});
    		//ExistingPosVarLst
    		extRoles.forEach(er ->{
    			if(er.getPvId() != null && er.getPvId().length() > 0) {
    				extPosnVarIds.add(er.getPvId());
    			}
    		});


    		//Calculate EXCESSIVE ACCESS var = SYS_ACCESS_LIMIT
    		List<ExcessiveAccessModel> exList = userIdentityService.checkExcessiveAccess(dispModelLst, extRoles, assocUser);
    		request.getSession().removeAttribute("EXCESSIVE_ACCESS");
    		if(!exList.isEmpty()) {
    			model.addAttribute("EXCESSIVE_ACCESS", exList);
    			request.getSession().setAttribute("EXCESSIVE_ACCESS", exList);
    		}
    		//END Excessive Access

        	//START - ROLES CONFLICTS
    		List<UserIdentityConflictMdl> confList = userIdentityService.checkSodConflicts(assocUser.getWwId(), newPosnVarIds, extPosnVarIds);
    		if(confList != null && !confList.isEmpty()) {
    			model.addAttribute("confList", confList);
    			request.getSession().setAttribute("confList", confList);
    			request.getSession().setAttribute("CONFLICTS", "Y");
    		}else {
    			request.getSession().removeAttribute("confList");
        		request.getSession().setAttribute("CONFLICTS", "N");
    		}
    		//END - ROLES CONFLICTS
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	return "useridm/newAccessConfPageData";
    }


	@PostMapping("/newAccessSubmit")
    public String newAccessSubmit(@RequestParam("cmnts") String cmnts, Model model, HttpServletRequest request) {
    	log.info("cmnts: "+cmnts);
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	UserSearchModel assocUser = (UserSearchModel)request.getSession().getAttribute("assocUser");
    	model.addAttribute("assocUser", assocUser);

    	String reqTyp = (String) request.getSession().getAttribute("reqTyp");
    	String bussFunc = (String) request.getSession().getAttribute("bfuncParam");
    	String sectors = (String)request.getSession().getAttribute("sectrParam");
    	String regions = (String)request.getSession().getAttribute("regnParam");
    	String selectedSys = (String)request.getSession().getAttribute("sysParam");
    	List<SysPosAdGrpModelDispMdl> dispModelLst = (List<SysPosAdGrpModelDispMdl>) request.getSession().getAttribute("dispDataLst");
    	String cmntsPrm = cmnts;
    	String conflFound = (request.getSession().getAttribute("CONFLICTS") != null)? (String)request.getSession().getAttribute("CONFLICTS"):"N";
    	List<UserIdentityConflictMdl> confList = ("Y".equals(conflFound)? (List<UserIdentityConflictMdl>)request.getSession().getAttribute("confList"): new ArrayList<>());
    	//Excessive Access Check
    	List<ExcessiveAccessModel> exList = (List<ExcessiveAccessModel>)request.getSession().getAttribute("EXCESSIVE_ACCESS");
		String isExces = (exList == null || exList.isEmpty())? "N":"Y";
    	try{
    		if(null== curUser || null == curUser.getWwId()) {
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "User Session has expired, Please Re-Login to continue");
	    		return "useridm/newAccessConfPageData";
	    	}

	    	UIRequestModel reqModel = buildUIRequestModel(reqTyp, bussFunc, sectors, regions, 1, conflFound, "", "", null, cmntsPrm, curUser, assocUser, isExces);

	    	int requestId = userIdentityService.saveUIRequestData(reqModel, dispModelLst, confList, exList, curUser, assocUser);

	    	if(requestId == 0) {
	    		model.addAttribute("ENABLE_SUBMIT", "Y");
	    		model.addAttribute("message", "True");
	            model.addAttribute("error", "Request cannot be saved, Please try again later");
	    		return "useridm/newAccessConfPageData";
	    	}
	    	model.addAttribute("TKT_NUMBER", requestId);
	    	String msg  = "Status: Saved User Request Data, With TKT Number:: "+ requestId;
	    	model.addAttribute("message", "True");
	    	model.addAttribute("success", msg);
	    	model.addAttribute("ENABLE_SUBMIT", "N");
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	return "useridm/ticketcompletepage";
    }


	@GetMapping("/showAllNewRequests")
    public String showAllNewRequests(Model model, HttpServletRequest request) {
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	model.addAttribute("statusNms", statusNms);
	  return "useridm/viewnewrequestspage";
    }

	@PostMapping("/getNewUserRequestData")
    public String getNewUserRequestData(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, @RequestParam("status") int status,
    		@RequestParam("userWwId") String userWwId, Model model, HttpServletRequest request) {
    	log.info("startDate :"+startDate+"  endDate:"+endDate+" status :"+status+"  userWwId: "+userWwId);
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	model.addAttribute("statusNms", statusNms);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	model.addAttribute("stParam",status);
    	model.addAttribute("userWwId",userWwId);

    	if(startDate.isEmpty() || endDate.isEmpty()) {
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
    		return "useridm/viewnewrequestspage";
    	}
    	Date stDt = Utility.fmtStrToDate(startDate);
		Date enDt = Utility.fmtStrToDate(endDate);
    	if(stDt.after(enDt)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates : Start date cannot be greater than End date....!");
            return "useridm/viewnewrequestspage";
    	}
    	List<UIRequestDispModel> allReqLst = new ArrayList<>();
    	try{
			allReqLst = userIdentityService.getAllNewRequests(startDate, endDate, userWwId, status);
			model.addAttribute("USRREQ_DATA", allReqLst);
			model.addAttribute("message", "True");
			if(!allReqLst.isEmpty()) {
				model.addAttribute("success", "Total rows returned: "+allReqLst.size());
    		}else {
    			model.addAttribute("success", "Total rows returned: 0");
    		}
		} catch (Exception e) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "ERROR:"+e.getMessage());
		}
    	return "useridm/viewnewrequestspage";
    }

	@GetMapping("/approveNewRequests")
    public String approveNewRequests(Model model, HttpServletRequest request) {
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	model.addAttribute("AUTH_USER", curUser);
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	model.addAttribute("statusNms", statusNms);
	  return "useridm/approvenewrequestspage";
    }

	@PostMapping("/getNewUserAppRequestData")
    public String getNewUserAppRequestData(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate,
    		@RequestParam("userWwId") String userWwId, Model model, HttpServletRequest request) {
    	log.info("startDate :"+startDate+"  endDate:"+endDate+"  userWwId: "+userWwId);
    	List<KeyValPair> statusNms = userIdentityService.getReqStatus();
    	model.addAttribute("statusNms", statusNms);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	model.addAttribute("userWwId",userWwId);

    	if(startDate.isEmpty() || endDate.isEmpty()) {
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
    		return "useridm/approvenewrequestspage";
    	}
    	Date stDt = Utility.fmtStrToDate(startDate);
		Date enDt = Utility.fmtStrToDate(endDate);
    	if(stDt.after(enDt)) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates : Start date cannot be greater than End date....!");
            return "useridm/approvenewrequestspage";
    	}
    	List<UIRequestDispModel> allReqLst = new ArrayList<>();
    	try{
			allReqLst = userIdentityService.getAllApprovalRequests(startDate, endDate, userWwId);
			model.addAttribute("USRREQ_DATA", allReqLst);
			model.addAttribute("message", "True");
			if(!allReqLst.isEmpty()) {
				model.addAttribute("success", "Total rows returned: "+allReqLst.size());
    		}else {
    			model.addAttribute("success", "Total rows returned: 0");
    		}
		} catch (Exception e) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "ERROR:"+e.getMessage());
		}
    	return "useridm/approvenewrequestspage";
    }


	@SuppressWarnings("all")
	@GetMapping("/qryNewTktDetails")
	public String qryNewTktDetails(@RequestParam String tktnumber, Model model, HttpServletRequest request) {
		log.info("Received Ticket number: "+tktnumber);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", tktnumber );
		model.addAttribute("AUTH_USER", curUser );
		if(Utility.isEmpty(tktnumber)) {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number, Please check the number and try again!");
	        return "useridm/viewTicketData";
		}

		List<UIRequestDispModel>tktLst = userIdentityService.getTicketData(tktnumber);
		if(tktLst != null && !tktLst.isEmpty()) {
			UIRequestDispModel ticket= tktLst.get(0);
			//Requestor
			UserSearchModel requestor = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getReqBy(), 1);
			ticket.setReqByName(requestor.getFmlyNm()+", "+requestor.getGivenNm());

			//Associate
			UserSearchModel associate = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getUserId(), 1);
			ticket.setAssoUserName(associate.getFmlyNm()+", "+associate.getGivenNm());

			//Manager
			UserSearchModel userMgr = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getMgrWwid(), 1);
			ticket.setMgrName(userMgr.getFmlyNm()+", "+userMgr.getGivenNm());

			model.addAttribute("userMgr", userMgr);
			model.addAttribute("assocUser", associate);
	    	model.addAttribute("REQ_USER", requestor);

	    	model.addAttribute("assocWwidPrm", associate.getWwId());
	    	model.addAttribute("assocNamePrm", associate.getFmlyNm()+" "+associate.getGivenNm());

	    	List<KeyValPair> reqType 	= userIdentityService.getAllRequestTypes();
	    	model.addAttribute("rqTypParam", ticket.getReqTyp());
	    	model.addAttribute("reqType", reqType );

	    	List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
			model.addAttribute("bussFunctions", bussFunctions);
			model.addAttribute("bfuncParam", ticket.getBfId());

			List<KeyValPair> sectrChkLst = userIdentityService.getBussFuncSectors(ticket.getBfId()+"");
	    	model.addAttribute("sectrChkLst", sectrChkLst );
	    	model.addAttribute("sectrParam", Arrays.asList(ticket.getSecIds().split(",")));

	    	List<KeyValPair> regnChkLst = userIdentityService.getAllMasterSectorRegions(ticket.getBfId()+"", ticket.getSecIds());
	    	model.addAttribute("regnChkLst", regnChkLst);
	    	model.addAttribute("regnParam", Arrays.asList(ticket.getRegIds().split(",")));

	    	model.addAttribute("cmntsPrm", ticket.getComments());
	    	model.addAttribute("tktStatusDesc", ticket.getReqStatusDesc());

	    	List<SysPosAdGrpModelDispMdl> dispModelLst = new LinkedList<>();
	    	List<UIReqDpendncMdl> dispDep = userIdentityService.getRequestDependency(ticket.getReqId()+"");

	    	Map<String, String> systemMap = new HashMap<>();
	    	List<KeyValPair> systemLst = userIdentityService.getAllMasterRegionSystems(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds());
	    	model.addAttribute("systemLst", systemLst);

	    	for(KeyValPair sysKv:systemLst) {
	    		systemMap.put(sysKv.getKey()+"", sysKv.getVal());
	    	}

	    	String sysPrm="";

	    	for(UIReqDpendncMdl dep:dispDep) {
	    		String ky = dep.getSysId();
	    		if("".equals(sysPrm)) {
	    			sysPrm = ky;
	    		}else {
	    			sysPrm+= ","+ky;
	    		}
	    		String[] arrPosns 		= dep.getPosIds().split(",");
	    		String selPosns 		= dep.getPosIds();
	    		List<KeyValPair> posLst = userIdentityService.getAllMasterSystemPositions(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns);//Position List
	    		String[] arrAcssTyp 	= dep.getAcsIds().split(",");
	    		String selAcssTyp 		= dep.getAcsIds();
	    		List<KeyValPair> acsTypLst = userIdentityService.getAllMasterPosnsAccsTypes(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp);
	    		String[] arrPosnVr 		= dep.getPvIds().split(",");
	    		String selPosnVr  		= dep.getPvIds();
	    		List<KeyValPair> posVarLst = userIdentityService.getAllMasterAcsTypsPosVarnt(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);//Position Variants
	    		List<KeyValPair> appAdGrps = new ArrayList<>();
	    		List<UserRoleADGrpMdl> appUrAdGrps  = userIdentityService.getAllMasterPosVarntADGrp(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);
	    		String adGrpIds="";
	    		for(UserRoleADGrpMdl obj:appUrAdGrps){
	    			KeyValPair kv = new KeyValPair();
	    			kv.setKey(Integer.parseInt(obj.getAdgrpId()));
	    			kv.setVal(obj.getAdgrpName());
	    			appAdGrps.add(kv);
	    			if("".equals(adGrpIds)) {
	    				adGrpIds=obj.getAdgrpId();
	    			}else {
	    				adGrpIds+=","+obj.getAdgrpId();
	    			}
	    		}
	    		SysPosAdGrpModelDispMdl dispMdl = new SysPosAdGrpModelDispMdl();
	    		dispMdl.setSysId(ky);
	    		dispMdl.setSysName(systemMap.get(ky));
	    		dispMdl.setPosIds(selPosns);
	    		dispMdl.setPositions(posLst);
	    		dispMdl.setAscTypIds(selAcssTyp);
	    		dispMdl.setAcsTypes(acsTypLst);
	    		dispMdl.setPosVarIds(selPosnVr);
	    		dispMdl.setPosnVariants(posVarLst);
	    		dispMdl.setAdGrpIds(adGrpIds);
	    		dispMdl.setAppAdGrps(appUrAdGrps);
	    		dispModelLst.add(dispMdl);
	    	}
	    	model.addAttribute("sysParam", sysPrm);
	    	model.addAttribute("dispDataLst", dispModelLst);//Data to Display

	    	String conflFound = ticket.getConflFound();
	    	if("Y".equals(conflFound)) {
	    		List<UserIdentityConflictMdl> confList = userIdentityService.getAllReqConflicts(ticket.getReqId()+"");
	    		if(confList != null && !confList.isEmpty()) {
	    			model.addAttribute("confList", confList);
	    		}
	    	}

	    	String isEscessive = ticket.getIsExces();
	    	if("Y".equals(isEscessive)) {
	    		List<ExcessiveAccessModel> exList  = userIdentityService.getAllReqExcData(ticket.getReqId()+"");
	    		if(exList != null && !exList.isEmpty()) {
	    			for(ExcessiveAccessModel exMdl: exList) {
	    				exMdl.setUser(associate);
	    				exMdl.setSelVariants(userIdentityService.getPosVarForIDs(exMdl.getSelVarids()) );
	    			}
	    			model.addAttribute("excList", exList);
	    		}
	    	}

	    	model.addAttribute("message", "True");
	        model.addAttribute("success", " 1 Ticket Number match found displaying data");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/viewTicketData";
		}
		return "useridm/viewTicketData";
	}



	@SuppressWarnings("all")
	@PostMapping("/getComplianceApprovalInfo")
	public String getComplianceApprovalInfo(@ModelAttribute("complReqId") String complReqId, Model model, HttpServletRequest request) {
		log.info("Received RequestID number: "+complReqId);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", complReqId );
		model.addAttribute("AUTH_USER", curUser );
		List<UIRequestDispModel>tktLst = userIdentityService.getTicketData(complReqId);
		if(tktLst != null && !tktLst.isEmpty()) {
			UIRequestDispModel ticket= tktLst.get(0);
			//Requestor
			UserSearchModel requestor = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getReqBy(), 1);
			ticket.setReqByName(requestor.getFmlyNm()+", "+requestor.getGivenNm());

			//Associate
			UserSearchModel associate = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getUserId(), 1);
			ticket.setAssoUserName(associate.getFmlyNm()+", "+associate.getGivenNm());

			//Manager
			UserSearchModel userMgr = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getMgrWwid(), 1);
			ticket.setMgrName(userMgr.getFmlyNm()+", "+userMgr.getGivenNm());

			model.addAttribute("assocUser", associate);
	    	model.addAttribute("REQ_USER", requestor);

	    	model.addAttribute("assocWwidPrm", associate.getWwId());
	    	model.addAttribute("assocNamePrm", associate.getFmlyNm()+" "+associate.getGivenNm());

	    	List<KeyValPair> reqType 	= userIdentityService.getAllRequestTypes();
	    	model.addAttribute("rqTypParam", ticket.getReqTyp());
	    	model.addAttribute("reqType", reqType );

	    	List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
			model.addAttribute("bussFunctions", bussFunctions);
			model.addAttribute("bfuncParam", ticket.getBfId());

			List<KeyValPair> sectrChkLst = userIdentityService.getBussFuncSectors(ticket.getBfId()+"");
	    	model.addAttribute("sectrChkLst", sectrChkLst );
	    	model.addAttribute("sectrParam", Arrays.asList(ticket.getSecIds().split(",")));

	    	List<KeyValPair> regnChkLst = userIdentityService.getAllMasterSectorRegions(ticket.getBfId()+"", ticket.getSecIds());
	    	model.addAttribute("regnChkLst", regnChkLst);
	    	model.addAttribute("regnParam", Arrays.asList(ticket.getRegIds().split(",")));

	    	model.addAttribute("cmntsPrm", ticket.getComments());
	    	model.addAttribute("tktStatusDesc", ticket.getReqStatusDesc());

	    	////////////////////////////////////////////
	    	List<SysPosAdGrpModelDispMdl> dispModelLst = new LinkedList<>();
	    	List<UIReqDpendncMdl> dispDep = userIdentityService.getRequestDependency(ticket.getReqId()+"");

	    	Map<String, String> systemMap = new HashMap<>();
	    	List<KeyValPair> systemLst = userIdentityService.getAllMasterRegionSystems(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds());
	    	model.addAttribute("systemLst", systemLst);
	    	//model.addAttribute("sysParam", selectedSystems);

	    	for(KeyValPair sysKv:systemLst) {
	    		systemMap.put(sysKv.getKey()+"", sysKv.getVal());
	    	}

	    	String sysPrm="";

	    	for(UIReqDpendncMdl dep:dispDep) {
	    		String ky = dep.getSysId();
	    		if("".equals(sysPrm)) {
	    			sysPrm = ky;
	    		}else {
	    			sysPrm+= ","+ky;
	    		}
	    		String[] arrPosns 		= dep.getPosIds().split(",");
	    		String selPosns 		= dep.getPosIds();
	    		List<KeyValPair> posLst = userIdentityService.getAllMasterSystemPositions(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns);//Position List
	    		String[] arrAcssTyp 	= dep.getAcsIds().split(",");
	    		String selAcssTyp 		= dep.getAcsIds();
	    		List<KeyValPair> acsTypLst = userIdentityService.getAllMasterPosnsAccsTypes(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp);
	    		String[] arrPosnVr 		= dep.getPvIds().split(",");
	    		String selPosnVr  		= dep.getPvIds();
	    		List<KeyValPair> posVarLst = userIdentityService.getAllMasterAcsTypsPosVarnt(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);//Position Variants
	    		List<KeyValPair> appAdGrps = new ArrayList<>();
	    		List<UserRoleADGrpMdl> appUrAdGrps  = userIdentityService.getAllMasterPosVarntADGrp(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);
	    		String adGrpIds="";
	    		for(UserRoleADGrpMdl obj:appUrAdGrps){
	    			KeyValPair kv = new KeyValPair();
	    			kv.setKey(Integer.parseInt(obj.getAdgrpId()));
	    			kv.setVal(obj.getAdgrpName());
	    			appAdGrps.add(kv);
	    			if("".equals(adGrpIds)) {
	    				adGrpIds=obj.getAdgrpId();
	    			}else {
	    				adGrpIds+=","+obj.getAdgrpId();
	    			}
	    		}
	    		SysPosAdGrpModelDispMdl dispMdl = new SysPosAdGrpModelDispMdl();
	    		dispMdl.setSysId(ky);
	    		dispMdl.setSysName(systemMap.get(ky));
	    		dispMdl.setPosIds(selPosns);
	    		dispMdl.setPositions(posLst);
	    		dispMdl.setAscTypIds(selAcssTyp);
	    		dispMdl.setAcsTypes(acsTypLst);
	    		dispMdl.setPosVarIds(selPosnVr);
	    		dispMdl.setPosnVariants(posVarLst);
	    		dispMdl.setAdGrpIds(adGrpIds);
	    		dispMdl.setAppAdGrps(appUrAdGrps);
	    		dispModelLst.add(dispMdl);
	    	}
	    	model.addAttribute("sysParam", sysPrm);
	    	model.addAttribute("dispDataLst", dispModelLst);//Data to Display

	    	String conflFound = ticket.getConflFound();
	    	if("Y".equals(conflFound)) {
	    		List<UserIdentityConflictMdl> confList = userIdentityService.getAllReqConflicts(ticket.getReqId()+"");
	    		if(confList != null && !confList.isEmpty()) {
	    			model.addAttribute("confList", confList);
	    			model.addAttribute("confsize", confList.size());
	    		}
	    	}else {
	    		model.addAttribute("confsize", "0");
	    	}
	    	List<KeyValPair> mitiCntrlLst = userIdentityService.getAllMitigatingControls(null, "M");//MITIGATING CONTROLS
	    	model.addAttribute("mitiCntrls", mitiCntrlLst);

	    	String isEscessive = ticket.getIsExces();
	    	if("Y".equals(isEscessive)) {
	    		List<ExcessiveAccessModel> exList  = userIdentityService.getAllReqExcData(ticket.getReqId()+"");
	    		if(exList != null && !exList.isEmpty()) {
	    			for(ExcessiveAccessModel exMdl: exList) {
	    				exMdl.setUser(associate);
	    				exMdl.setSelVariants(userIdentityService.getPosVarForIDs(exMdl.getSelVarids()) );
	    			}
	    			model.addAttribute("excList", exList);
	    			model.addAttribute("excsize", exList.size());
	    		}
	    	}else {
	    		model.addAttribute("excsize", "0");
	    	}
	    	List<KeyValPair> exCntrlLst = userIdentityService.getAllMitigatingControls(null, "E");//EXCESSIVE ACCESS CONTROLS
	    	model.addAttribute("exCntrls", exCntrlLst);

	    	model.addAttribute("message", "True");
	        model.addAttribute("success", " 1 Ticket Number match found displaying data");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/viewTicketData";
		}
		return "useridm/viewComplPage";
	}




	@SuppressWarnings("all")
	@PostMapping("/submitApprovalData")
	public String submitApprovalData(@RequestParam("approvaldata") String approvaldata, @RequestParam("approvalExdata") String approvalExdata,  @ModelAttribute("complReqId") String complReqId, @ModelAttribute("assocWwId") String assocWwId, Model model, HttpServletRequest request) {
		log.info("Received approvaldata: "+approvaldata);
		log.info("Received approvalExdata data: "+approvalExdata);
		log.info("Received RequestID number: "+complReqId);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("tktnum", complReqId );
		model.addAttribute("AUTH_USER", curUser );


		if((Utility.isEmpty(approvaldata) && Utility.isEmpty(approvalExdata)) || curUser==null) {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Please provide approval comments before submiting the data!");
	        return "useridm/viewComplPage";
		}

		//Save Approval/Send email
		String[] apprDataArray;
		if(!Utility.isEmpty(approvaldata)) {
			approvaldata = Utility.removeFirstComma(approvaldata);
			apprDataArray = approvaldata.split(",");
			if(apprDataArray.length > 0) {
				List<UserIdentityConflictMdl> resolMdl = userIdentityService.buildConflictApprModel(complReqId, assocWwId, curUser.getWwId(), apprDataArray);
				int appStatus = userIdentityService.saveConfApprovalStatus(resolMdl, assocWwId);
			}
		}


		//Excessive Data Access
		String[] exccDataArray ;
		if(!Utility.isEmpty(approvalExdata)) {
			approvalExdata =  Utility.removeFirstComma(approvalExdata);
			exccDataArray = approvalExdata.split(",");
			if(exccDataArray.length > 0) {
				List<ExcessiveAccessModel> excesAccLst = userIdentityService.buildExcesApprModel(complReqId, assocWwId, curUser.getWwId(), exccDataArray);
				int excStatus = userIdentityService.saveExcesApprovalStatus(excesAccLst, assocWwId);
			}
		}



		List<UIRequestDispModel>tktLst = userIdentityService.getTicketData(complReqId);
		if(tktLst != null && !tktLst.isEmpty()) {
			UIRequestDispModel ticket= tktLst.get(0);
			//Requestor
			UserSearchModel requestor = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getReqBy(), 1);
			ticket.setReqByName(requestor.getFmlyNm()+", "+requestor.getGivenNm());

			//Associate
			UserSearchModel associate = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getUserId(), 1);
			ticket.setAssoUserName(associate.getFmlyNm()+", "+associate.getGivenNm());

			//Manager
			UserSearchModel userMgr = sAPExtrGaaDataService.getUserStatusJJEDS(ticket.getMgrWwid(), 1);
			ticket.setMgrName(userMgr.getFmlyNm()+", "+userMgr.getGivenNm());

			model.addAttribute("assocUser", associate);
	    	model.addAttribute("REQ_USER", requestor);

	    	model.addAttribute("assocWwidPrm", associate.getWwId());
	    	model.addAttribute("assocNamePrm", associate.getFmlyNm()+" "+associate.getGivenNm());

	    	List<KeyValPair> reqType 	= userIdentityService.getAllRequestTypes();
	    	model.addAttribute("rqTypParam", ticket.getReqTyp());
	    	model.addAttribute("reqType", reqType );

	    	List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
			model.addAttribute("bussFunctions", bussFunctions);
			model.addAttribute("bfuncParam", ticket.getBfId());

			List<KeyValPair> sectrChkLst = userIdentityService.getBussFuncSectors(ticket.getBfId()+"");
	    	model.addAttribute("sectrChkLst", sectrChkLst );
	    	model.addAttribute("sectrParam", Arrays.asList(ticket.getSecIds().split(",")));

	    	List<KeyValPair> regnChkLst = userIdentityService.getAllMasterSectorRegions(ticket.getBfId()+"", ticket.getSecIds());
	    	model.addAttribute("regnChkLst", regnChkLst);
	    	model.addAttribute("regnParam", Arrays.asList(ticket.getRegIds().split(",")));

	    	model.addAttribute("cmntsPrm", ticket.getComments());
	    	model.addAttribute("tktStatusDesc", ticket.getReqStatusDesc());

	    	////////////////////////////////////////////
	    	List<SysPosAdGrpModelDispMdl> dispModelLst = new LinkedList<>();
	    	List<UIReqDpendncMdl> dispDep = userIdentityService.getRequestDependency(ticket.getReqId()+"");

	    	Map<String, String> systemMap = new HashMap<>();
	    	List<KeyValPair> systemLst = userIdentityService.getAllMasterRegionSystems(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds());
	    	model.addAttribute("systemLst", systemLst);
	    	//model.addAttribute("sysParam", selectedSystems);

	    	for(KeyValPair sysKv:systemLst) {
	    		systemMap.put(sysKv.getKey()+"", sysKv.getVal());
	    	}

	    	String sysPrm="";

	    	for(UIReqDpendncMdl dep:dispDep) {
	    		String ky = dep.getSysId();
	    		if("".equals(sysPrm)) {
	    			sysPrm = ky;
	    		}else {
	    			sysPrm+= ","+ky;
	    		}
	    		String[] arrPosns 		= dep.getPosIds().split(",");
	    		String selPosns 		= dep.getPosIds();
	    		List<KeyValPair> posLst = userIdentityService.getAllMasterSystemPositions(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns);//Position List
	    		String[] arrAcssTyp 	= dep.getAcsIds().split(",");
	    		String selAcssTyp 		= dep.getAcsIds();
	    		List<KeyValPair> acsTypLst = userIdentityService.getAllMasterPosnsAccsTypes(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp);
	    		String[] arrPosnVr 		= dep.getPvIds().split(",");
	    		String selPosnVr  		= dep.getPvIds();
	    		List<KeyValPair> posVarLst = userIdentityService.getAllMasterAcsTypsPosVarnt(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);//Position Variants
	    		List<KeyValPair> appAdGrps = new ArrayList<>();
	    		List<UserRoleADGrpMdl> appUrAdGrps  = userIdentityService.getAllMasterPosVarntADGrp(ticket.getBfId()+"", ticket.getSecIds(), ticket.getRegIds(), ky, selPosns, selAcssTyp, selPosnVr);
	    		String adGrpIds="";
	    		for(UserRoleADGrpMdl obj:appUrAdGrps){
	    			KeyValPair kv = new KeyValPair();
	    			kv.setKey(Integer.parseInt(obj.getAdgrpId()));
	    			kv.setVal(obj.getAdgrpName());
	    			appAdGrps.add(kv);
	    			if("".equals(adGrpIds)) {
	    				adGrpIds=obj.getAdgrpId();
	    			}else {
	    				adGrpIds+=","+obj.getAdgrpId();
	    			}
	    		}
	    		SysPosAdGrpModelDispMdl dispMdl = new SysPosAdGrpModelDispMdl();
	    		dispMdl.setSysId(ky);
	    		dispMdl.setSysName(systemMap.get(ky));
	    		dispMdl.setPosIds(selPosns);
	    		dispMdl.setPositions(posLst);
	    		dispMdl.setAscTypIds(selAcssTyp);
	    		dispMdl.setAcsTypes(acsTypLst);
	    		dispMdl.setPosVarIds(selPosnVr);
	    		dispMdl.setPosnVariants(posVarLst);
	    		dispMdl.setAdGrpIds(adGrpIds);
	    		dispMdl.setAppAdGrps(appUrAdGrps);
	    		dispModelLst.add(dispMdl);
	    	}
	    	model.addAttribute("sysParam", sysPrm);
	    	model.addAttribute("dispDataLst", dispModelLst);//Data to Display

	    	String conflFound = ticket.getConflFound();
	    	if("Y".equals(conflFound)) {
	    		List<UserIdentityConflictMdl> confList = userIdentityService.getAllReqConflicts(ticket.getReqId()+"");
	    		if(confList != null && !confList.isEmpty()) {
	    			model.addAttribute("confList", confList);
	    			model.addAttribute("confsize", confList.size());
	    		}
	    	}
	    	List<KeyValPair> mitiCntrlLst = userIdentityService.getAllMitigatingControls(null, "M");
	    	model.addAttribute("mitiCntrls", mitiCntrlLst);

	    	String isEscessive = ticket.getIsExces();
	    	if("Y".equals(isEscessive)) {
	    		List<ExcessiveAccessModel> exList  = userIdentityService.getAllReqExcData(ticket.getReqId()+"");
	    		if(exList != null && !exList.isEmpty()) {
	    			for(ExcessiveAccessModel exMdl: exList) {
	    				exMdl.setUser(associate);
	    				exMdl.setSelVariants(userIdentityService.getPosVarForIDs(exMdl.getSelVarids()) );
	    			}
	    			model.addAttribute("excList", exList);
	    			model.addAttribute("excsize", exList.size());
	    		}
	    	}

	    	List<KeyValPair> exCntrlLst = userIdentityService.getAllMitigatingControls(null, "E");//EXCESSIVE ACCESS CONTROLS
	    	model.addAttribute("exCntrls", exCntrlLst);

	    	model.addAttribute("message", "True");
	        model.addAttribute("success", " 1 Ticket Number match found displaying data");
			model.addAttribute("TKT_DETAIL", ticket);
			request.getSession().setAttribute("TKT_DETAIL", ticket);
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid Ticket Number/No Data found, Please check the number and try again!");
	        return "useridm/viewTicketData";
		}
		return "useridm/viewCompApprComplete";
	}

	@GetMapping("/updateUIMasterData")
    public String updateUIMasterData(Model model, HttpServletRequest request) {
    	log.info("Routing to Master Data Upload Page");
    	return "useridm/uploadMasterData";
    }

	@GetMapping("/updateUIConflictMetrixData")
    public String updateUIConflictMetrixData(Model model, HttpServletRequest request) {
    	log.info("Routing to Conflict Matrix Data Upload Page");
    	return "useridm/uploadUIConflictMatrix";
    }

	@GetMapping("/updatUIExcessiveAccess")
    public String updatUIExcessiveAccess(Model model, HttpServletRequest request) {
    	log.info("Routing to Conflict Matrix Data Upload Page");
    	return "useridm/uploadUIConfigData";
    }


	/*END - Adding All New Methods for Data Collection HERE*/




  }
