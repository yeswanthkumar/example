package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapGaaUser2RoleModel {
	private String revUserId;
	private String userId;
	private String firstName;
	private String lastName;
	private String roleId;
	private String roleDesc;
	private String primaryReviewInfo1;
	private String primaryReviewInfo2;
	private String primaryReviewInfo3;
	private String additionalInfo1;
	private String additionalInfo2;
	private String additionalInfo3;
	private String userStatus;


	@Override
	public String toString() {
		return "SapGaaUser2RoleModel [revUserId=" + revUserId + ", userId=" + userId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", roleId=" + roleId + ", roleDesc=" + roleDesc + ", primaryReviewInfo1="
				+ primaryReviewInfo1 + ", primaryReviewInfo2=" + primaryReviewInfo2 + ", primaryReviewInfo3="
				+ primaryReviewInfo3 + ", additionalInfo1=" + additionalInfo1 + ", additionalInfo2=" + additionalInfo2
				+ ", additionalInfo3=" + additionalInfo3 + "userStatus= "+userStatus+"]";
	}

	public String getData() {
		return revUserId+"~"+userId+"~"+primaryReviewInfo1+"~"+primaryReviewInfo2+"~"+primaryReviewInfo3+"~"+additionalInfo1+"~"+additionalInfo2+"~"+additionalInfo3+"~"+userStatus;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof SapGaaUser2RoleModel) {
			SapGaaUser2RoleModel temp = (SapGaaUser2RoleModel) obj;
            if(this.userId == temp.userId && this.primaryReviewInfo1 == temp.primaryReviewInfo1 && this.primaryReviewInfo2 == temp.primaryReviewInfo2
            		&& this.primaryReviewInfo3 == temp.primaryReviewInfo3 && this.additionalInfo1 == temp.additionalInfo1
            		&& this.additionalInfo2 == temp.additionalInfo2 && this.additionalInfo3 == temp.additionalInfo3 && this.userStatus == temp.userStatus)
                return true;
        }
        return false;
    }


	@Override
    public int hashCode() {
        return (this.userId.hashCode() + this.firstName.hashCode() + this.lastName.hashCode() + this.roleId.hashCode() +
        		this.roleDesc.hashCode() + this.primaryReviewInfo3.hashCode() + this.additionalInfo1.hashCode() );
    }



}
