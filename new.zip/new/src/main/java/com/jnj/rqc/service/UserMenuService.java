package com.jnj.rqc.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

public interface UserMenuService {
	public List<String> getUserHeaderMenus(String userId, String adGrp, HttpServletRequest request);
	public List<String> getUserSideNavMenus(String userId, String adGrp, String menuId, HttpServletRequest request);
	public List<String> getConstantList(String cid);
}
