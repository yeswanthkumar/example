package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;

@Data
public class TktApprLogMdl {
	private int 	apprLogId;
	private int 	reqId;
	private String  approverId;
	private int 	reqStatus;
	private String 	approvalCatg;
	private String 	approvalStatus;
	private String 	apprdConsUnits;
	private String 	denidConsUnits;
	private String 	apprdRespUnits;
	private String 	denidRespUnits;
	private String 	apprRemarks;
	private Date   	updDate;

	}
