package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;

@Data
public class UserRequestModel {
	private int 	reqId;
	private int 	reqTyp;
	private Date   	reqDt;
	private String 	reqBy;
	private String 	userId;
	private String 	mgrWwid;
	private int 	prjId;
	private String  personaIds;
	private String  positionIds;
	private String  roleIds;
	private String 	secIds;
	private String 	accfIds;
	private String 	regIds;
	private String 	cntryIds;
	private String 	consIds;
	private String 	respIds;
	private String  conflictFound;
	private int 	reqStatus;
	private Date   	dtUpdated;
	private String  updtBy;
	private String comments;


	@Override
	public String toString() {
		return "UserRequestModel [reqId=" + reqId + ", reqTyp=" + reqTyp + ", reqDt=" + reqDt + ", reqBy=" + reqBy
				+ ", userId=" + userId + ", mgrWwid=" + mgrWwid + ", prjId=" + prjId + ", personaIds=" + personaIds
				+ ", positionIds=" + positionIds + ", roleIds=" + roleIds + ", secIds=" + secIds + ", accfIds="
				+ accfIds + ", regIds=" + regIds + ", cntryIds=" + cntryIds + ", consIds=" + consIds + ", respIds="
				+ respIds + ", conflictFound=" + conflictFound + ", reqStatus=" + reqStatus + ", dtUpdated=" + dtUpdated
				+ ", updtBy=" + updtBy + ", comments=" + comments + "]";
	}

















}
