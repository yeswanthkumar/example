package com.jnj.rqc.sodrefresh.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.sodrefresh.service.SodRefreshService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>SodRefreshController.java</b>
 * @author : DChauras @Created : Nov 9, 2021 12:06:32 PM
 * Purpose :Controller is designed to Execute all the Methods in SOD_REFRESH Script
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class SodRefreshController {
	static final Logger log = LoggerFactory.getLogger(SodRefreshController.class);
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	SodRefreshService sodRefreshService;



	@GetMapping("/triggerSodRefresh")
	public String triggerSodRefresh(Model model, HttpServletRequest request)
	{	String envName = Utility.getServerProp("ENVIRONMENT");
		log.info("<<<<<<<<<<<<<<<  ("+envName+") START MANUAL SOD_REFRESH @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		executeSODRefresh();
		log.info("<<<<<<<<<<<<<<<  ("+envName+") END MANUAL SOD_REFRESH  @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		return "home";
	}


	@SuppressWarnings("all")
	public String executeSODRefresh() {
		String envName = Utility.getServerProp("ENVIRONMENT");
		Calendar startTime = Calendar.getInstance(), endTime = null;
		Map<String, Object> errorMap = new HashMap<>();
		log.info("STARTED: SOD REFRESH on "+envName+"  @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
		try{
			errorMap = sodRefreshService.runSodRefresh(envName, errorMap);
			//Sending Email
	    	emailUtil.sendSodRefreshEmail("SOD REFRESH COMPLETED", envName, errorMap);
	    } catch (Exception e) {
			log.error("ERROR in SOD_REFRESH(Refresh All Materialised Views) :"+e.getMessage(), e);
		}
    	endTime = Calendar.getInstance();
    	log.info("COMPLETED: SOD REFRESH on "+envName+"  @ "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total Time Taken : "+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" Seconds.");


    	return "";
    }





}
