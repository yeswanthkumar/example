package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.UserSearchModel;


public interface UserMenuDao {
	public Map<Integer, String> getUserHeaderMenus(String userId, String adGrp, HttpServletRequest request)throws SQLException, DataAccessException;
	public Map<Integer, String> getMenuSideNav(String menuId, UserSearchModel usr, HttpServletRequest request)throws SQLException, DataAccessException;
	public String getUtilsConstVals(String cid)throws SQLException, DataAccessException;
	public int getUtilsConstExcsvVals(String cid) throws SQLException, DataAccessException;
}
