package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.controllers.ExchangeDataController;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.dbextr.models.ADGroupRespDto;
import com.jnj.rqc.dbextr.models.CRADGroupRespDto;
import com.jnj.rqc.dbextr.models.DDMultiRespDto;
import com.jnj.rqc.dbextr.models.DDRespDto;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.CRUnitADGroupMdl;
import com.jnj.rqc.models.ExcessiveAccessModel;
import com.jnj.rqc.models.KeyValDiffPair;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.PlatformProjectMdl;
import com.jnj.rqc.models.ProjectApprCatgMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.TktApprLogMdl;
import com.jnj.rqc.models.UETktModel;
import com.jnj.rqc.models.UserRequestDispMdl;
import com.jnj.rqc.models.UserRequestModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserIdentityService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.useridentity.models.BusinessFunctionModel;
import com.jnj.rqc.useridentity.models.BusinessProcessModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.IamAdGrpRequestDTO;
import com.jnj.rqc.useridentity.models.IamAdGrpRequestObj;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceStatusRespDTO;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceSubRespDTO;
import com.jnj.rqc.useridentity.models.TempDispMdl;
import com.jnj.rqc.useridentity.models.TmpPosnsMdl;
import com.jnj.rqc.useridentity.models.UIReqDpendncMdl;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.useridentity.models.UIRequestModel;
import com.jnj.rqc.useridentity.models.UserIdentityConflictMdl;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;
import com.jnj.rqc.useridentity.models.UserRolesRespDto;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


@Service
public class UserIdentityServiceImpl implements UserIdentityService{
	static final Logger log = LoggerFactory.getLogger(UserIdentityServiceImpl.class);

	@Autowired
	Environment environment;
	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	UserIdentityDao userIdentityDao;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;
	@Autowired
	EmailUtil emailUtil;

	@Autowired
	private RestTemplate restHttpTemplate;
	@Autowired
	ExchangeDataController exchangeDataController;


	@Override
	public UserRolesRespDto getUserGrantedRoles(String userId) {
		List<UserRoleADGrpMdl> usrRoles= new ArrayList<>();
		try{
			//usrRoles =  userIdentityDao.getUserRoles(userId, 1);//1=Existing/2=Requested
			//GET -PFB(DDGR) system Details
			List<IAMRolesADGrpMdl>  pfbRoleLst = sAPExtrGaaDataService.readPFBUserRolesADGrpData(Constants.SAP_ADGRP_BW4PFB, userId);
			if(pfbRoleLst != null && !pfbRoleLst.isEmpty()){
				for(IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
					List<UserRoleADGrpMdl> complMdl = getSystemDetail(rlMdl.getLdapADGroup());
					UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
					if(complMdl != null && !complMdl.isEmpty()) {
						usrMdl=complMdl.get(0);
						usrMdl.setUserId(rlMdl.getUser());
					}else {
						usrMdl.setUserId(rlMdl.getUser());
						usrMdl.setAdgrpName(rlMdl.getLdapADGroup());
						usrMdl.setSysId(rlMdl.getClient());
					}
					if(rlMdl.getMdate() != null && rlMdl.getMdate().length() > 0) {
						usrMdl.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					}
					usrRoles.add(usrMdl);
				}
			}
			//CFIN DATA
			List<String>  cfinRoles = sAPExtrGaaDataService.readPFICFINUserRolesPosnData(Constants.SAP_ADGRP_S4PFI, userId);
			if(cfinRoles != null && !cfinRoles.isEmpty()){
				for(String tRole : cfinRoles) {
					List<UserRoleADGrpMdl> complMdl = getCFINRoleDetail(tRole);
					UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
					if(complMdl != null && !complMdl.isEmpty()) {
						usrMdl=complMdl.get(0);
						usrMdl.setUserId(userId);
					}else {
						usrMdl.setUserId(userId);
						usrMdl.setAdgrpName(tRole);
						usrMdl.setSysId("1");
						usrMdl.setSysName("CFIN");
					}
					//usrMdl.setUpdDate(new Date());
					usrRoles.add(usrMdl);
				}
			}

			//GRC DATA
			List<String>  grcRoles = sAPExtrGaaDataService.readGRCSYSUserRolesPosnData(Constants.SAP_GRC_SYSTEM, userId);
			if(grcRoles != null && !grcRoles.isEmpty()){
				for(String tRole : grcRoles) {
					List<UserRoleADGrpMdl> complMdl = getCFINRoleDetail(tRole);
					UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
					if(complMdl != null && !complMdl.isEmpty()) {
						usrMdl=complMdl.get(0);
						usrMdl.setUserId(userId);
					}else {
						usrMdl.setUserId(userId);
						usrMdl.setAdgrpName(tRole);
						usrMdl.setSysId("1");
						usrMdl.setSysName("CFIN");
					}
					//usrMdl.setUpdDate(new Date());
					usrRoles.add(usrMdl);
				}
			}
			//Ananplan Roles - from DB
			List<String>  csmRoles = userIdentityDao.getAnaplanHistDataForUser(userId);
			if(csmRoles != null && !csmRoles.isEmpty()){
				for(String tRole : csmRoles) {
					List<UserRoleADGrpMdl> complMdl = getAnaplanRoleDetail(tRole);
					UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
					if(complMdl != null && !complMdl.isEmpty()) {
						usrMdl=complMdl.get(0);
						usrMdl.setUserId(userId);
					}else {
						usrMdl.setUserId(userId);
						usrMdl.setAdgrpName(tRole);
						usrMdl.setSysId("4");
						usrMdl.setSysName("Anaplan");
					}
					usrRoles.add(usrMdl);
				}
			}

			/*ANAPLAN-IAM Roles from IAM */
			/*List<String>  iamRoles = userIdentityDao.getAnaplanHistDataForUser(userId);
			if(iamRoles != null && !iamRoles.isEmpty()){
				for(String tRole : iamRoles) {
					List<UserRoleADGrpMdl> complMdl = getAnaplanRoleDetail(tRole);
					UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
					if(complMdl != null && !complMdl.isEmpty()) {
						usrMdl=complMdl.get(0);
						usrMdl.setUserId(userId);
					}else {
						usrMdl.setUserId(userId);
						usrMdl.setAdgrpName(tRole);
						usrMdl.setSysId("4");
						usrMdl.setSysName("Anaplan");
					}
					usrRoles.add(usrMdl);
				}
			}
			*/

		} catch (Exception e) {
			log.info("Error getting Granted Roles Data:"+e.getMessage(), e);
		}

		List<TempDispMdl> tmpDisp = getConsolidateList(usrRoles);

		UserRolesRespDto rlsDto = new UserRolesRespDto();
		rlsDto.setStatusCode(0);
		rlsDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		rlsDto.setRoles(usrRoles);
		rlsDto.setDispRole(tmpDisp);
		return rlsDto;
	}

	private List<TempDispMdl> getConsolidateList(List<UserRoleADGrpMdl> usrRoles) {
		List<TempDispMdl> tmpDisp = new ArrayList<>();
		Map<String, Map<String, List<String>>> tmpMap = new HashMap<>();
		if(usrRoles != null && !usrRoles.isEmpty()) {
			for(UserRoleADGrpMdl rle : usrRoles) {
				String systm = (null == rle.getSysName() || "".equals(rle.getSysName()))? "SYSTEM-NOTFOUNT":rle.getSysName();
				String posn  = (null == rle.getPosName() || "".equals(rle.getPosName()))? "POSITION-NOTFOUND":rle.getPosName();
				if(tmpMap.containsKey(systm)) {
					Map<String, List<String>> posMap = tmpMap.get(systm);
					List<String> ads;
					if(posMap.containsKey(posn)) {
						ads = posMap.get(posn);
					}else {
						ads = new ArrayList<>();
					}
					//ads.add(rle.getAdgrpName());//Modified to Display Variants
					String pv=(null==rle.getPvName()|| "".equals(rle.getPvName()))?"VariantNotFound":rle.getPvName();
					if(!ads.contains(pv)) {
						ads.add(pv);
					}
					posMap.put(posn, ads);
					tmpMap.put(systm, posMap);
				}else {
					Map<String, List<String>> posMap = new HashMap<>();
					List<String> ads = new ArrayList<>();
					//ads.add(rle.getAdgrpName());//Modified to Display Variants
					ads.add((null==rle.getPvName() || "".equals(rle.getPvName()))?"VariantNotFound":rle.getPvName());
					posMap.put(posn, ads);
					tmpMap.put(systm, posMap);
				}
			}
		}

		if(tmpMap != null && !tmpMap.isEmpty()) {
			for(Map.Entry<String, Map<String, List<String>>> sysMp:tmpMap.entrySet()) {
				String sysNm = sysMp.getKey();
				TempDispMdl tmdl = new TempDispMdl();
				tmdl.setSysName(sysNm);
				List<TmpPosnsMdl> posns = new ArrayList<>();
				tmdl.setPosns(posns);
				for(Map.Entry<String, List<String>> posMp:(sysMp.getValue()).entrySet()) {
					String posnNm = posMp.getKey();
					TmpPosnsMdl tps = new TmpPosnsMdl();
					tps.setPosName(posnNm);
					tps.setAdgrps(posMp.getValue());
					posns.add(tps);
				}
				tmpDisp.add(tmdl);
			}
		}

		return tmpDisp;
	}

	@Override
	public List<UserRoleADGrpMdl> getSystemDetail(String ldapADGroup) {
		List<UserRoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userIdentityDao.getMstDataForADGrp(ldapADGroup);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public List<UserRoleADGrpMdl> getCFINRoleDetail(String tchRole){
		List<UserRoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userIdentityDao.getCFINMstDataForRole(tchRole);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public List<UserRoleADGrpMdl> getAnaplanRoleDetail(String tchRole){
		List<UserRoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userIdentityDao.getAnaplanMstDataForRole(tchRole);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public List<UserRoleADGrpMdl> getIAMAnaplanUserRoleDetail(String tchRole){
		List<UserRoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userIdentityDao.getAnaplanMstDataForRole(tchRole);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public DDRespDto getBussProcessSectors() {
		List<KeyValPair> secNms= new ArrayList<>();
		String typ="SEC";
		try{
			secNms = getBussProcessSectorsKV();
		} catch (Exception e) {
			log.info("Error getting Sectors Data:"+e.getMessage(), e);
		}
		DDRespDto ddRespDto = new DDRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setType(typ);
		ddRespDto.setTables(secNms);
		return ddRespDto;
	}


	@Override
	public List<KeyValPair> getBussFuncSectors(String bfIds) {
		List<KeyValPair> secNms= new ArrayList<>();
		try{
			List<KeyValPair> secs = null;
			for(String id:bfIds.split(",")) {
				secs = userIdentityDao.getBussFuncSectorsKV(id);
				if(secs != null && !secs.isEmpty()) {
					for(KeyValPair kv:secs) {
						if(!secNms.contains(kv)) {
							secNms.add(kv);
						}
					}
				}
			}
		} catch (Exception e) {
			log.info("Error getting Sectors Data:"+e.getMessage(), e);
		}
		return secNms;
	}



	@Override
	public DDRespDto getProjectSystemsData(String prjId) {
		List<KeyValPair> systems = getProjectSystems(prjId);
		DDRespDto tableRespDto = new DDRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(systems);
		return tableRespDto;
	}

	@Override
	public List<KeyValPair> getProjectSystems(String prjId) {
		List<KeyValPair> sysNms= new ArrayList<>();
		try{
			sysNms = userIdentityDao.getProjSystemsKV(prjId);
		} catch (Exception e) {
			log.info("Error getting System Data:"+e.getMessage(), e);
		}
		return sysNms;
	}

	@Override
	public List<KeyValPair> getRegionSystems(String regIds) {
		List<KeyValPair> regNms= new ArrayList<>();
		try{
			List<KeyValPair> regs = null;
			for(String id:regIds.split(",")) {
				regs = userIdentityDao.getRegnSystemsKV(id);
				if(regs != null && !regs.isEmpty()) {
					for(KeyValPair kv:regs) {
						if(!regNms.contains(kv)) {
							regNms.add(kv);
						}
					}
				}
			}
		} catch (Exception e) {
			log.info("Error getting System Data:"+e.getMessage(), e);
		}
		return regNms;
	}



	@Override
	public DDRespDto getPositionForSystems(String sysIds) {
		List<KeyValPair> posSysNms= new ArrayList<>();
		posSysNms = getSystemPositionsKV(sysIds.split(","));

		DDRespDto respDto = new DDRespDto();
		respDto.setStatusCode(0);
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		respDto.setTables(posSysNms);

		return respDto;
	}


	@Override
	public List<KeyValPair> getSystemPositionsKV(String[] sysIds){
		List<KeyValPair> posNms= new ArrayList<>();
		try{
			for(String sysId:sysIds) {
				List<KeyValPair> pNms = userIdentityDao.getSysPositionsKeyVal(sysId);
				if(pNms != null && !pNms.isEmpty()) {
					for(KeyValPair pos: pNms) {
						if(!posNms.contains(pos)) {
							posNms.add(pos);
						}
					}
				}
			}
		} catch (Exception e) {
			log.info("Error getting Positions for System Data:"+e.getMessage(), e);
		}
		return posNms;
	}

	@Override
	public DDRespDto getPosAccessTypes(String posIds){
		List<KeyValPair> accTypes= new ArrayList<>();
		accTypes = getAccessTypesKV(posIds.split(","));
		DDRespDto respDto = new DDRespDto();
		respDto.setStatusCode(0);
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		respDto.setTables(accTypes);
		return respDto;
	}

	@Override
	public List<KeyValPair> getAccessTypesKV(String[] posIds){
		List<KeyValPair> accessNms= new ArrayList<>();
		try{
			List<KeyValPair> accNms = null;
			if(posIds != null && posIds.length > 0) {
				for(String posId:posIds) {
					accNms = userIdentityDao.getPosAccessTypesKV(posId);
					if(accNms != null && !accNms.isEmpty()) {
						for(KeyValPair accs: accNms) {
							if(!accessNms.contains(accs)) {
								accessNms.add(accs);
							}
						}
					}
				}
			}else {
				accNms = userIdentityDao.getPosAccessTypesKV(null);
				if(accNms != null && !accNms.isEmpty()) {
					for(KeyValPair accs: accNms) {
						if(!accessNms.contains(accs)) {
							accessNms.add(accs);
						}
					}
				}
			}
		} catch (Exception e) {
			log.info("Error getting Positions for System Data:"+e.getMessage(), e);
		}
		return accessNms;
	}

	@Override
	public DDRespDto getAcsPosnVariant(String acsIds){
		List<KeyValPair> posVarLst= new ArrayList<>();
		posVarLst = getPosnVariants(acsIds.split(","));
		DDRespDto respDto = new DDRespDto();
		respDto.setStatusCode(0);
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		respDto.setTables(posVarLst);
		return respDto;
	}

	@Override
	public List<KeyValPair> getPosnVariants(String[] acsIds){
		List<KeyValPair> pvrNmsLst= new ArrayList<>();
		try{
			List<KeyValPair> pvrLst = null;
			if(acsIds != null && acsIds.length > 0) {
				for(String acsId:acsIds) {
					pvrLst = userIdentityDao.getAcsPosnVariantKV(acsId);
					if(pvrLst != null && !pvrLst.isEmpty()) {
						for(KeyValPair pvr: pvrLst) {
							if(!pvrNmsLst.contains(pvr)) {
								pvrNmsLst.add(pvr);
							}
						}
					}
				}
			}else {
				pvrLst = userIdentityDao.getAcsPosnVariantKV(null);
				if(pvrLst != null && !pvrLst.isEmpty()) {
					for(KeyValPair pvr: pvrLst) {
						if(!pvrNmsLst.contains(pvr)) {
							pvrNmsLst.add(pvr);
						}
					}
				}
			}
		} catch (Exception e) {
			log.info("Error getting Positions for System Data:"+e.getMessage(), e);
		}
		return pvrNmsLst;
	}




	@Override
	public List<KeyValPair> getBussProcessSectorsKV(){
		List<KeyValPair> secNms= new ArrayList<>();
		try{
			secNms = userIdentityDao.getSectorsKeyVal(null);
		} catch (Exception e) {
			log.info("Error getting Sectors Data:"+e.getMessage(), e);
		}
		return secNms;
	}

	@Override
	public List<KeyValPair> getCntryAccFunctions(String cntryIds) {
		List<KeyValPair> accFLst = new ArrayList<>();
		String[] idArr=cntryIds.split(",");
		try{
			for(String cntId:idArr) {
				List<KeyValPair> afLstTmp = userIdentityDao.getCntryAcctFuncKV(cntId);
				if(afLstTmp != null && !afLstTmp.isEmpty()) {
					for(KeyValPair kp:afLstTmp) {
						if(!accFLst.contains(kp)) {
							accFLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Positions :"+accFLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return accFLst;
	}

	//Getting Projects -Persona/Positions based on project Selection
	@Override
	public DDRespDto getPrjChildObjects(String prjPlatformId) {
		String typ="SEC";
		String typ2="";
		List<KeyValPair> envNms= new ArrayList<>();
		List<KeyValPair> envNms2= new ArrayList<>();
		try{
			List<PlatformProjectMdl> prjs = userIdentityDao.getProjectsData(prjPlatformId);
			if(prjs != null && !prjs.isEmpty()) {
				PlatformProjectMdl prj = prjs.get(0);
				String[] rendrArr = prj.getRenderNext().split(",");
				if(rendrArr != null && rendrArr.length > 0) {
					typ="SEC";
					envNms = userIdentityDao.getProjectSectors(prjPlatformId);
					if(rendrArr.length > 1) {
						typ2=rendrArr[1];
						if("POS".equals(typ2)) {
							envNms2 = userIdentityDao.getProjectPositions(prjPlatformId);
						}else if("PER".equals(typ2)) {
							envNms2 = userIdentityDao.getProjectPersonas(prjPlatformId);
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		DDRespDto ddRespDto = new DDRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setType(typ);
		ddRespDto.setTables(envNms);
		if(typ2.length() > 0) {
			ddRespDto.setType2(typ2);
			ddRespDto.setTables2(envNms2);
		}
		return ddRespDto;
	}



	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadJDEProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}



	@Override
	public List<KeyValPair> getAllRequestTypes() {
		log.info("Get All User Request Types");
		List<KeyValPair> reqTypeLst = new ArrayList<>();
		try{
			reqTypeLst = userIdentityDao.getRequestTypes();
			log.info("Total Records for Request Types :"+reqTypeLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return reqTypeLst;
	}



	@Override
	public List<KeyValPair> getAllProjects() {
		log.info("Get All PLATFORM/PROJECTS");
		List<KeyValPair> prjLst = new ArrayList<>();
		try{
			prjLst = userIdentityDao.getProjectsKeyVal();
			log.info("Total Records for Platform/Projects :"+prjLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return prjLst;
	}


	@Override
	public List<StrKeyValPair> getBusinesFunctions(String bfId) {
		log.info("Get All BUSINESS FUNCTIONS");
		List<StrKeyValPair> bussFunc = new ArrayList<>();
		try{
			List<BusinessFunctionModel> bfList = getAllBusinesFunctions("");
			if(bfList != null && !bfList.isEmpty()) {
				bfList.forEach(bfMdl ->{
					StrKeyValPair bfKv = new StrKeyValPair();
					bfKv.setKey(bfMdl.getBfId());
					bfKv.setVal(bfMdl.getBfName());
					bussFunc.add(bfKv);
				});
			}
			log.info("Total Key/Value Records for Business Functions: "+bussFunc.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return bussFunc;
	}

	@Override
	public List<BusinessFunctionModel> getAllBusinesFunctions(String bfId) throws Exception{
		log.info("Get All BUSINESS FUNCTIONS");
		List<BusinessFunctionModel> bussFunc = userIdentityDao.getBusinessFunctionVals(bfId);
		log.info("Total Records for Business Functions :"+bussFunc.size());
		return bussFunc;
	}


	@Override
	public List<StrKeyValPair> getBusinesProcess(String bfId) {
		log.info("Get All BUSINESS PROCESS");
		List<StrKeyValPair> bussProc = new ArrayList<>();
		try{
			List<BusinessProcessModel> bpList = getAllBusinesProcess(bfId);
			if(bpList != null && !bpList.isEmpty()) {
				bpList.forEach(bpMdl ->{
					StrKeyValPair bpKv = new StrKeyValPair();
					bpKv.setKey(bpMdl.getBpId());
					bpKv.setVal(bpMdl.getBpName());
					if(!bussProc.contains(bpKv)) {
						bussProc.add(bpKv);
					}
				});
			}
			log.info("Total Key/Value Records for Business Functions: "+bussProc.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return bussProc;
	}

	@Override
	public List<BusinessProcessModel> getAllBusinesProcess(String bfId) throws Exception{
		log.info("Get All BUSINESS Process");
		List<BusinessProcessModel> bussProc = userIdentityDao.getBusinessProcessVals(bfId);
		log.info("Total Records for Func-Business Process :"+bussProc.size());
		return bussProc;
	}





	@Override
	public List<KeyValPair> getAllRegions(String[] regIds) {
		log.info("Get All Regions");
		List<KeyValPair> regLst = new ArrayList<>();
		try{
			regLst = userIdentityDao.getRegionsKeyVal(regIds);
			log.info("Total Records for Regions :"+regLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return regLst;
	}


	@Override
	public List<KeyValPair> getPersonaRoles(String perIds) {
		List<KeyValPair> perRoleLst = new ArrayList<>();
		String[] idArr=perIds.split(",");
		try{
			for(String perId:idArr) {
				List<KeyValPair> perRlTmp = userIdentityDao.getPerRolesKV(perId);
				if(perRlTmp != null && !perRlTmp.isEmpty()) {
					for(KeyValPair kp:perRlTmp) {
						if(!perRoleLst.contains(kp)) {
							perRoleLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Persona Roles :"+perRoleLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return perRoleLst;
	}

	@Override
	public List<KeyValPair> getPositionRoles(String posIds) {
		List<KeyValPair> posRoleLst = new ArrayList<>();
		String[] idArr=posIds.split(",");
		try{
			for(String posId:idArr) {
				List<KeyValPair> posRlTmp = userIdentityDao.getPosRolesKV(posId);
				if(posRlTmp != null && !posRlTmp.isEmpty()) {
					for(KeyValPair kp:posRlTmp) {
						if(!posRoleLst.contains(kp)) {
							posRoleLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Position Roles :"+posRoleLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posRoleLst;
	}

	@Override
	public List<KeyValPair> getAccFunctions(String secIds) {
		List<KeyValPair> accFLst = new ArrayList<>();
		String[] idArr=secIds.split(",");
		try{
			for(String secId:idArr) {
				List<KeyValPair> afLstTmp = userIdentityDao.getSecAcctFuncKV(secId);
				if(afLstTmp != null && !afLstTmp.isEmpty()) {
					for(KeyValPair kp:afLstTmp) {
						if(!accFLst.contains(kp)) {
							accFLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Positions :"+accFLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return accFLst;
	}

	@Override
	public List<KeyValPair> getAllSectorRegions(String secIds) {
		List<KeyValPair> regLst = new ArrayList<>();
		String[] idArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		try{
			for(String secId:idArr) {
				List<KeyValPair> regLstTmp = userIdentityDao.getSectorRegionKV(secId);
				if(regLstTmp != null && !regLstTmp.isEmpty()) {
					for(KeyValPair kp:regLstTmp) {
						if(!regLst.contains(kp)) {
							regLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Roles :"+regLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return regLst;
	}



	@Override
	public List<KeyValPair> getAllFuncRegions(String funcIds) {
		List<KeyValPair> regLst = new ArrayList<>();
		String[] idArr=funcIds.split(",");
		try{
			for(String positionId:idArr) {
				List<KeyValPair> regLstTmp = userIdentityDao.getfuncRegKV(positionId);
				if(regLstTmp != null && !regLstTmp.isEmpty()) {
					for(KeyValPair kp:regLstTmp) {
						if(!regLst.contains(kp)) {
							regLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Roles :"+regLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return regLst;
	}

	@Override
	public List<KeyValPair> getRegCountries(String regIds) {
		List<KeyValPair> cntryLst = new ArrayList<>();
		String[] idArr=regIds.split(",");
		try{
			for(String regionId:idArr) {
				List<KeyValPair> cntLstTmp = userIdentityDao.getCountriesKeyVal(regionId);
				if(cntLstTmp != null && !cntLstTmp.isEmpty()) {
					for(KeyValPair kp:cntLstTmp) {
						if(!cntryLst.contains(kp)) {
							cntryLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Roles :"+cntryLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cntryLst;
	}


	@Override
	public DDMultiRespDto getAccfConsRespUnits(String cntryIds, String accfIds) {
		List<StrKeyValPair> cuLst = new ArrayList<>();
		List<StrKeyValPair> ruLst = new ArrayList<>();
		cuLst = getConsUnitCntryAccf(cntryIds, accfIds);
		ruLst = getRespUnitCntryAccf(cntryIds, accfIds);
		log.info("Total Records for Resp Unit :"+ruLst.size());

		DDMultiRespDto ddRespDto = new DDMultiRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTable1(cuLst);//Set Cons Unit
		ddRespDto.setTable2(ruLst);
		return ddRespDto;
	}

	@Override
	public CRADGroupRespDto getADGroupsForConsRespUnits(String consIds, String respIds) {
		List<CRUnitADGroupMdl> cuAdLst = new ArrayList<>();
		List<CRUnitADGroupMdl> ruAdLst = new ArrayList<>();
		try {
				if(!Utility.isEmpty(consIds)) {
					cuAdLst = userIdentityDao.getADGrpsforConsRespUnit(consIds, "C");
				}
				if(!Utility.isEmpty(respIds)) {
					ruAdLst = userIdentityDao.getADGrpsforConsRespUnit(respIds, "R");
				}
		}catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		log.info("Total Records for Cons Unit :"+cuAdLst.size()+"  Resp Units:"+ruAdLst.size());
		CRADGroupRespDto ddRespDto = new CRADGroupRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTable1(cuAdLst);//Set Cons Unit
		ddRespDto.setTable2(ruAdLst);
		return ddRespDto;
	}

	@Override
	public List<CRUnitADGroupMdl> getADGroupByType(String crIds, String type){//C="Consolidation"/R="Responsiblity"
		List<CRUnitADGroupMdl> crAdLst = new ArrayList<>();
		try {
				if(!Utility.isEmpty(crIds)) {
					crAdLst = userIdentityDao.getADGrpsforConsRespUnit(crIds, type);
				}
		}catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return crAdLst;
	}



	@Override
	public DDMultiRespDto getConsRespUnits(String cntryIds, String secIds) {
		List<StrKeyValPair> cuLst = new ArrayList<>();
		List<StrKeyValPair> ruLst = new ArrayList<>();
		cuLst = getConsUnitCntrySec(cntryIds, secIds);
		ruLst = getRespUnitCntrySec(cntryIds, secIds);
		log.info("Total Records for Resp Unit :"+ruLst.size());

		DDMultiRespDto ddRespDto = new DDMultiRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTable1(cuLst);//Set Cons Unit
		ddRespDto.setTable2(ruLst);
		return ddRespDto;
	}


	@Override
	public List<StrKeyValPair> getConsUnitCntryAccf(String cntryIds, String accfIds){
		List<StrKeyValPair> cuLst = new ArrayList<>();
		try {
			cuLst = userIdentityDao.getAccfConsUnitKeyVal(cntryIds, accfIds);
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cuLst;
	}


	@Override
	public List<StrKeyValPair> getRespUnitCntryAccf(String cntryIds, String accfIds){
		List<StrKeyValPair> ruLst = new ArrayList<>();
		try {
			ruLst = userIdentityDao.getAccfRespUnitKeyVal(cntryIds, accfIds);
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return ruLst;
	}

	@Override
	public List<StrKeyValPair> getRespUnitCntrySec(String cntryIds, String secIds){
		List<StrKeyValPair> ruLst = new ArrayList<>();
		try {
			ruLst = userIdentityDao.getRespUnitKeyVal(cntryIds, secIds);
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return ruLst;
	}

	@Override
	public List<StrKeyValPair> getConsUnitCntrySec(String cntryIds, String secIds){
		List<StrKeyValPair> cuLst = new ArrayList<>();
		try {
			cuLst = userIdentityDao.getConsUnitKeyVal(cntryIds, secIds);
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cuLst;
	}



	@Override
	public DDRespDto getCountrySectors(String cntryIds) {
		List<KeyValPair> secLst = new ArrayList<>();
		String[] idArr=cntryIds.split(",");
		try{
			for(String cntId:idArr) {
				List<KeyValPair> secLstTmp = userIdentityDao.getSectorKeyVal(cntId);
				if(secLstTmp != null && !secLstTmp.isEmpty()) {
					for(KeyValPair kp:secLstTmp) {
						if(!secLst.contains(kp)) {
							secLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Sectors :"+secLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}

		DDRespDto ddRespDto = new DDRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTables(secLst);
		return ddRespDto;
	}

	@Override
	public DDRespDto getSectorConsUnit(String secIds) {
		List<KeyValPair> consUntLst = new ArrayList<>();
		String[] idArr=secIds.split(",");
		try{
			for(String secId:idArr) {
				List<KeyValPair> consLstTmp = userIdentityDao.getConsUnitKeyVal(secId);
				if(consLstTmp != null && !consLstTmp.isEmpty()) {
					for(KeyValPair kp:consLstTmp) {
						if(!consUntLst.contains(kp)) {
							consUntLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Cons Unit :"+consUntLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}

		DDRespDto ddRespDto = new DDRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTables(consUntLst);
		return ddRespDto;
	}

	@Override
	public DDRespDto getConsResponsiblityUnit(String consIds) {
		List<KeyValPair> respUntLst = new ArrayList<>();
		String[] idArr=consIds.split(",");
		try{
			for(String consId:idArr) {
				List<KeyValPair> respLstTmp = userIdentityDao.getResponsiblityUnitKeyVal(consId);
				if(respLstTmp != null && !respLstTmp.isEmpty()) {
					for(KeyValPair kp:respLstTmp) {
						if(!respUntLst.contains(kp)) {
							respUntLst.add(kp);
						}
					}
				}
			}
			log.info("Total Records for Cons Unit :"+respUntLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}

		DDRespDto ddRespDto = new DDRespDto();
		ddRespDto.setStatusCode(0);
		ddRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		ddRespDto.setTables(respUntLst);
		return ddRespDto;
	}


	//TODO - LOAD REFERENCE DATA
	@Override
	public void loadAllReferenceData() {
		log.info("LOAD All Reference Data");

		/*List<KeyValPair> reqTypeLst = new ArrayList<KeyValPair>();
		try{
			reqTypeLst = userIdentityDao.getProjectsKeyVal();
			log.info("Total Records for Platform/Projects :"+reqTypeLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}*/
	}



	@Override
	public List<KeyValPair> getAllSectors(String projId) {
		List<KeyValPair> secLst = new ArrayList<>();
		try{
			secLst = userIdentityDao.getProjectSectors(projId);
			log.info("Total Records for Platform/Projects :"+secLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return secLst;
	}

	@Override
	public List<KeyValPair> getProjectPersonas(String projId) {
		List<KeyValPair> perLst = new ArrayList<>();
		try{
			perLst = userIdentityDao.getProjectPersonas(projId);
			log.info("Total Records for Project-Personas :"+perLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return perLst;
	}

	@Override
	public List<KeyValPair> getProjectPositions(String projId) {
		List<KeyValPair> posLst = new ArrayList<>();
		try{
			posLst = userIdentityDao.getProjectPositions(projId);
			log.info("Total Records for Project-Positions :"+posLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posLst;
	}




	@Override
	public int saveRequestData(UserRequestModel reqModel,UserSearchModel curUser, UserSearchModel assocUser) {
		int requestId = 0;
		try{
			requestId = userIdentityDao.saveUserRequest(reqModel);
			if(requestId > 0) {//Save Successfull, Routing for Manager Approval
				log.info("Saved Request with ID : "+requestId);
				//Request Saved - Trigger Email
				UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
				List<PlatformProjectMdl> prjData = userIdentityDao.getProjectsData(reqModel.getPrjId()+"");
 				Map<String, List<String>> emailMap = getApproverCategoryEmails(assocUser, reqModel.getPrjId()+"", 1, 999, assocMgr);
				emailUtil.triggerReqEmail(prjData.get(0), Constants.REQ_SAVED_MGR_ROUTING, requestId+"", assocUser, assocMgr, emailMap);
				//userIdentityDao.updateRequestStatus(requestId, 2);//Routed for Manager Approval
			}
		} catch (Exception e) {
			log.error("Error Saving Ticket Info:"+e.getMessage(), e);
		}
		return requestId;
	}

	@Override
	public Map<String, List<String>> getApproverCategoryEmails(UserSearchModel assocUser, String projId, int seqId, int implementorId, UserSearchModel assocMgr) throws Exception {
		Map<String, List<String>> emailMap = new HashMap<>();
		emailMap = readProjectApprCategory(projId, seqId, implementorId);//Get Applicable categories from Database
		if(1 == seqId) {//MANAGER APPROVAL
			List<String> toEmailLst = null;
			if(emailMap != null && emailMap.containsKey("TO")) {
				toEmailLst = emailMap.get("TO");
			}else {
				toEmailLst = new ArrayList<>();
			}
			toEmailLst.add(assocMgr.getJnjEmailAddrTxt());
			toEmailLst.add(assocUser.getJnjEmailAddrTxt());
			emailMap.put("TO", toEmailLst);
		}else {
			List<String> ccEmailLst = null;
			if(emailMap != null && emailMap.containsKey("CC")) {
				ccEmailLst = emailMap.get("CC");
			}else {
				ccEmailLst = new ArrayList<>();
			}
			ccEmailLst.add(assocUser.getJnjEmailAddrTxt());
			emailMap.put("CC", ccEmailLst);
		}
		return emailMap;
	}

	@Override
	public Map<String, List<String>> readProjectApprCategory(String projId, int seqId, int implementorId){
		Map<String, List<String>> emailMap = new HashMap<>();
		List<String> toEmailLst = new ArrayList<>();
		List<String> ccEmailLst = new ArrayList<>();
		try {
			List<ProjectApprCatgMdl> catgLst = userIdentityDao.getProjectApprCategory(projId, seqId, implementorId);//Get Applicable categories from Database
			if(!catgLst.isEmpty()) {
				for(ProjectApprCatgMdl cMdl:catgLst) {
					String[] emlArr = cMdl.getEmail().split(",");
					if(emlArr.length > 0) {
						if(999 == cMdl.getSeqId()) {
							for(String emailAddress : emlArr) {
								if(!emailAddress.equals("JJEDS")) {
									ccEmailLst.add(emailAddress);
								}
							}
						}else{
							for(String emailAddress : emlArr) {
								if(!emailAddress.equals("JJEDS")) {
									toEmailLst.add(emailAddress);
								}
							}
						}
					}
				}
			}
			emailMap.put("TO", toEmailLst);
			emailMap.put("CC", ccEmailLst);
		} catch (Exception e) {

		}
		return emailMap;
	}



	@Override
	public List<KeyValPair> getReqStatus() {
		log.info("Get All REQUEST Status");
		List<KeyValPair> reqStLst = new ArrayList<>();
		try{
			Map<Integer, String> reqStatMap =(Utility.getCache(Constants.REQUEST_STATUS) == null)? (Map<Integer, String>)Utility.getCache(Constants.REQUEST_STATUS): null;
			if(reqStatMap == null || reqStatMap.isEmpty()) {
				reqStLst = userIdentityDao.getReqStatusKeyVal();
				if(reqStLst != null && !reqStLst.isEmpty()) {
					reqStatMap = new HashMap<>();
					for(KeyValPair kvp: reqStLst) {
						reqStatMap.put(kvp.getKey(), kvp.getVal());
					}
				}
				Utility.setCache(Constants.REQUEST_STATUS, reqStatMap);
			}else {
				for(Map.Entry<Integer, String> entry:reqStatMap.entrySet()) {
					KeyValPair kv = new KeyValPair();
					kv.setKey(entry.getKey());
					kv.setVal(entry.getValue());
					reqStLst.add(kv);
				}
			}
			log.info("Total Records for Platform/Projects :"+reqStLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return reqStLst;
	}


	@SuppressWarnings("all")
	@Override
	public List<UserRequestDispMdl> getAllRequests(String startDate, String endDate, int projects, int status, String userWwId) {
		List<UserRequestDispMdl> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try {
			List<UserRequestDispMdl> allReqs = userIdentityDao.getUserSubmittedReqs(startDate, endDate, projects, status, userWwId);
			if(allReqs != null && !allReqs.isEmpty()) {
				userReqs = getRequestDependencies(allReqs);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}


	@Override
	public List<UserRequestDispMdl> getMyRequests(String startDate, String endDate, String userWwId) {
		List<UserRequestDispMdl> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try {
			List<UserRequestDispMdl> allReqs = userIdentityDao.getMyReqData(startDate, endDate, userWwId);
			if(allReqs != null && !allReqs.isEmpty()) {
				userReqs = getRequestDependencies(allReqs);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}




	@SuppressWarnings("unchecked")
	private List<UserRequestDispMdl> getRequestDependencies(List<UserRequestDispMdl> reqList) throws Exception {
		List<UserRequestDispMdl> allReqs = new ArrayList<>();
		if(reqList != null && !reqList.isEmpty()) {
			for(UserRequestDispMdl reqs : reqList) {
				UserSearchModel userReqBy = sAPExtrGaaDataService.getUserStatusJJEDS(reqs.getReqBy(), 1);
				if(userReqBy != null) {
					reqs.setReqByName(userReqBy.getFmlyNm()+" "+userReqBy.getGivenNm());
					reqs.setReqByNtId(userReqBy.getJnjMsftUsrnmTxt());
				}

				UserSearchModel assoUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqs.getUserId(), 1);
				if(assoUser != null) {
					reqs.setUserName(assoUser.getFmlyNm()+" "+assoUser.getGivenNm());
					reqs.setUserNtId(assoUser.getJnjMsftUsrnmTxt());
				}
				UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqs.getMgrWwid(), 1);
				if(mgrUser != null) {
					reqs.setMgrName(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm());
					reqs.setMgrNtId(mgrUser.getJnjMsftUsrnmTxt());
				}
				allReqs.add(reqs);
			}
		}
		return allReqs;
	}


	@Override
	public List<UETktModel> getTktData(String tktNum) {
		List<UETktModel> userTktLst = new ArrayList<>();
		try {
			List<UETktModel> tktLst = userIdentityDao.getUserTktData(tktNum);
			if(tktLst != null && !tktLst.isEmpty()) {
				UETktModel mdl= tktLst.get(0);
				//Requestor
				UserSearchModel requestor = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getReqBy(), 1);
				mdl.setReqByName(requestor.getFmlyNm()+", "+requestor.getGivenNm());
				mdl.setReqByNtId(requestor.getJnjMsftUsrnmTxt());
				//Associate
				UserSearchModel associate = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getUserId(), 1);
				mdl.setUserName(associate.getFmlyNm()+", "+associate.getGivenNm());
				mdl.setUserNtId(associate.getJnjMsftUsrnmTxt());
				//Manager
				UserSearchModel userMgr = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getMgrWwid(), 1);
				mdl.setMgrName(userMgr.getFmlyNm()+", "+userMgr.getGivenNm());
				mdl.setMgrNtId(userMgr.getJnjMsftUsrnmTxt());
				//PERSONAS
				if(mdl.getPersonaIds() != null && mdl.getPersonaIds().length() > 0) {
					List<KeyValPair> personas = userIdentityDao.getPersonasKeyVal(mdl.getPersonaIds().split(","));
					mdl.setPersonas(personas);
				}
				//POSITIONS
				if(mdl.getPositionIds() != null && mdl.getPositionIds().length() > 0) {
					List<KeyValPair> positions = userIdentityDao.getPositionsKeyVal(mdl.getPositionIds().split(","));
					mdl.setPositions(positions);
				}
				//ROLES
				if(mdl.getRoleIds() != null && mdl.getRoleIds().length() > 0) {
					List<KeyValPair> roles = userIdentityDao.getRolesKeyVal(mdl.getRoleIds().split(","));
					mdl.setRoles(roles);
				}
				//Sectors
				if(mdl.getSecIds() != null && mdl.getSecIds().length() > 0) {
					List<KeyValPair> sectors = userIdentityDao.getSectorsKeyVal(mdl.getSecIds().split(","));
					mdl.setSectors(sectors);
					//mdl.setSecNames(Utility.getStringValues(sectors));
				}

				if(mdl.getAccfIds() != null && mdl.getAccfIds().length() > 0){
					List<KeyValPair> accFuncs = userIdentityDao.getAcctFuncKeyVal(mdl.getAccfIds().split(","));
					mdl.setAccfunctions(accFuncs);
					//mdl.setAccfNames(Utility.getStringValues(accFuncs));
				}

				if(mdl.getRegIds() != null && mdl.getRegIds().length() > 0) {
					List<KeyValPair> rgns = userIdentityDao.getRegionsKeyVal(mdl.getRegIds().split(","));
					mdl.setRegions(rgns);
					//mdl.setRegNames(Utility.getStringValues(rgns));
				}


				if(mdl.getCntryIds() != null && mdl.getCntryIds().length() > 0) {
					List<KeyValPair> cntrys = userIdentityDao.getCntrysKeyVal(mdl.getCntryIds().split(","));
					mdl.setCountries(cntrys);
					//mdl.setCntryNames(Utility.getStringValues(cntrys));
				}

				if(mdl.getConsIds() != null && mdl.getConsIds().length() > 0) {
					List<KeyValPair> consUnits = userIdentityDao.getConsUnitsKeyVal(mdl.getConsIds().split(","));
					mdl.setConsUnits(consUnits);
					//mdl.setConsNames(Utility.getStringValues(consUnits));
				}

				if(mdl.getRespIds() != null && mdl.getRespIds().length() > 0) {
					List<StrKeyValPair> respUnits = userIdentityDao.getRespUnitsKeyVal(mdl.getRespIds().split(","));
					mdl.setRespUnits(respUnits);
					//mdl.setRespNames(Utility.getStringValuesStr(respUnits));
				}

				List<TktApprLogMdl> apprDataLst = userIdentityDao.getApprovalLogData(mdl.getReqId()+"");
				mdl.setApproverLog(apprDataLst);
				userTktLst.add(mdl);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userTktLst;
	}



	@Override
	public List<UserRequestDispMdl> getMyApprQueData(String startDate, String endDate, int projects, /*int status,*/ String mgrId) {
		List<UserRequestDispMdl> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try {
			List<UserRequestDispMdl> reqList = userIdentityDao.getMgrApprQueData(startDate, endDate, projects, /*status,*/ mgrId);
			if(reqList != null && !reqList.isEmpty()) {
				userReqs = getRequestDependencies(reqList);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}



	@Override
	public void saveApprovalData(TktApprLogMdl appLogData) {
		try{
			int logSeqId = userIdentityDao.updateApprovalLog(appLogData);
			if(logSeqId > 0) {
				userIdentityDao.updateRequestStatus(appLogData.getReqId()+"", appLogData.getReqStatus(), 1);//Routed for Manager Approval
				List<UETktModel> tktLst = userIdentityDao.getUserTktData(appLogData.getReqId()+"");
				if(tktLst != null && !tktLst.isEmpty()) {
					List<PlatformProjectMdl> prjData = userIdentityDao.getProjectsData(tktLst.get(0).getPrjId()+"");
					UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(tktLst.get(0).getUserId(), 1);
					UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(tktLst.get(0).getMgrWwid(), 1);
					Map<String, List<String>> emailMap = getApproverCategoryEmails(assocUser, tktLst.get(0).getPrjId()+"", 2, 0, null);
					//Sending Approval LEVE-2 Email
					emailUtil.triggerReqEmail(prjData.get(0), Constants.REQ_COMPL_ROUTING, appLogData.getReqId()+"", assocUser, assocMgr, emailMap);
				}
			}
		} catch (Exception e) {
			log.error("Error Saving Approval Data: "+e.getMessage(), e);
		}

	}

/*****MASTER DATA METHODS*********************/

	@Override
	public DDRespDto getAllMSectorRegions(String bfId, String secIds) {
		DDRespDto tableRespDto = new DDRespDto();
		List<KeyValPair> regLst = getAllMasterSectorRegions(bfId, secIds);
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(regLst);
		return tableRespDto;
	}

	@Override
	public List<KeyValPair> getAllMasterSectorRegions(String bfId, String secIds) {
		List<KeyValPair> regLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		try{
			regLst = userIdentityDao.getMSectorRegionKV(bfId, secIdArr);
			log.info("Total Records for Regions :"+regLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return regLst;
	}



	@Override
	public DDRespDto getAllSystemsForRegns(String bfId, String secIds, String regIds){
		DDRespDto tableRespDto = new DDRespDto();
		List<KeyValPair> regLst = getAllMasterRegionSystems(bfId, secIds, regIds);
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(regLst);
		return tableRespDto;
	}

	@Override
	public List<KeyValPair> getAllMasterRegionSystems(String bfId, String secIds, String regIds) {
		List<KeyValPair> regLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		try{
			regLst = userIdentityDao.getMRegionSystemsKV(bfId, secIdArr, regIdArr);
			log.info("Total Records for Systems :"+regLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return regLst;
	}

	@Override
	public DDRespDto getAllPositionForSystem(String bfId, String secIds, String regIds, String sysId) {
		DDRespDto tableRespDto = new DDRespDto();
		List<KeyValPair> posLst = getAllMasterSystemPositions(bfId, secIds, regIds, sysId, null);
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(posLst);
		return tableRespDto;
	}

	@Override
	public List<KeyValPair> getAllMasterSystemPositions(String bfId, String secIds, String regIds, String sysId, String selPosns) {
		List<KeyValPair> posLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		String[] filter = (selPosns == null || selPosns.trim().length() == 0)? new String[] {}:selPosns.split(",");
		try{
			List<KeyValPair> allLst = userIdentityDao.getMSystemPositionsKV(bfId, secIdArr, regIdArr, sysId);
			log.info("Total Records for Position :"+allLst.size());
			if(allLst != null && !allLst.isEmpty()) {
				if(filter.length > 0) {
					for(String ky:filter) {
						for(KeyValPair vk:allLst) {
							if(ky.equals(vk.getKey()+"")) {
								posLst.add(vk);
							}
						}
					}
				}else {
					posLst.addAll(allLst);
				}
			}
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posLst;
	}


	@Override
	public DDRespDto getAllAccessTypesForPosns(String bfId, String secIds, String regIds, String sysId, String posIds) {
		DDRespDto tableRespDto = new DDRespDto();
		List<KeyValPair> posLst = getAllMasterPosnsAccsTypes(bfId, secIds, regIds, sysId, posIds, null);
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(posLst);
		return tableRespDto;
	}


	@Override
	public List<KeyValPair> getAllMasterPosnsAccsTypes(String bfId, String secIds, String regIds, String sysId,  String posIds, String acsTypIds) {
		List<KeyValPair> posLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		String[] posIdArr=(posIds == null || posIds.length() == 0)? new String[] {}:posIds.split(",");
		String[] filter = (acsTypIds == null || acsTypIds.length() == 0)? new String[] {}:acsTypIds.split(",");
		try{
			List<KeyValPair> allVrLst = userIdentityDao.getMPosnsAccsTypKV(bfId, secIdArr, regIdArr, sysId, posIdArr);
			if(filter.length > 0) {
				for(String vrKey:filter) {
					for(KeyValPair recData : allVrLst){
						String recKey = recData.getKey()+"";
						if(vrKey.equals(recKey)) {
							posLst.add(recData);
						}
					}
				}
			}else {
				posLst.addAll(allVrLst);
			}

			log.info("Total Records for AccesTyps :"+posLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posLst;
	}

	@Override
	public DDRespDto getAllPosnVarnForAcsTyps(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds){
		DDRespDto tableRespDto = new DDRespDto();
		List<KeyValPair> posLst = getAllMasterAcsTypsPosVarnt(bfId, secIds, regIds, sysId, posIds, acsTypIds, null);
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(posLst);
    	return tableRespDto;
	}

	@Override
	public List<KeyValPair> getAllMasterAcsTypsPosVarnt(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVarIds){
		List<KeyValPair> posVrLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		String[] posIdArr=(posIds == null || posIds.length() == 0)? new String[] {}:posIds.split(",");
		String[] acsTypIdArr=(acsTypIds == null || acsTypIds.length() == 0)? new String[] {}:acsTypIds.split(",");
		String[] filter = (posVarIds == null || posVarIds.length() == 0)? new String[] {}:posVarIds.split(",");
		try{
			List<KeyValPair> allVrLst = userIdentityDao.getMAcsTypPosVarnKV(bfId, secIdArr, regIdArr, sysId, posIdArr, acsTypIdArr);
			log.info("Total Records for PositionVariants :"+posVrLst.size());
			if(filter.length > 0) {
				for(String vrKey:filter) {
					for(KeyValPair recData : allVrLst){
						String recKey = recData.getKey()+"";
						if(vrKey.equals(recKey)) {
							posVrLst.add(recData);
						}
					}
				}
			}else {
				posVrLst.addAll(allVrLst);
			}
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posVrLst;
	}


	@Override
	public ADGroupRespDto getAllADGrpsForPosnVarns(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVars, HttpServletRequest req){
		ADGroupRespDto tableRespDto = new ADGroupRespDto();
		List<UserRoleADGrpMdl> adLst = new ArrayList<>();
		List<UserRoleADGrpMdl> adGrpLst = getAllMasterPosVarntADGrp(bfId, secIds, regIds, sysId, posIds, acsTypIds, posVars);
		//Check for Existing ADGroups
		adLst = checkExistingADGroups(adGrpLst, req);
		//END
		tableRespDto.setStatusCode(0);
    	tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    	tableRespDto.setTables(adLst);
    	return tableRespDto;
	}

	@Override
	public List<UserRoleADGrpMdl> checkExistingADGroups(List<UserRoleADGrpMdl> adGrpLst, HttpServletRequest req) {
		List<UserRoleADGrpMdl> finLst = new ArrayList<>();
		UserSearchModel assocUser = (UserSearchModel)req.getSession().getAttribute("assocUser");
		List<UserRoleADGrpMdl> exstAdGrp =  (List<UserRoleADGrpMdl>)req.getSession().getAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+assocUser.getWwId());
		for(UserRoleADGrpMdl adGrp : adGrpLst) {
			adGrp.setIsExisting("N");
			if(exstAdGrp != null && !exstAdGrp.isEmpty()) {
				for(UserRoleADGrpMdl exGrp : exstAdGrp) {
					if(adGrp.getAdgrpName().toUpperCase().equals(exGrp.getAdgrpName().toUpperCase())) {
						adGrp.setIsExisting("Y");
						break;
					}
				}
			}
			finLst.add(adGrp);
		}
		return finLst;
	}

	@Override
	public List<UserRoleADGrpMdl> removeExistingADGroups(List<UserRoleADGrpMdl> adGrpLst) {
		List<UserRoleADGrpMdl> finLst = new ArrayList<>();
		for(UserRoleADGrpMdl adGrp : adGrpLst) {
			if(!("Y".equals(adGrp.getIsExisting()))) {
				finLst.add(adGrp);
			}
		}
		return finLst;
	}



	@Override
	public List<UserRoleADGrpMdl> getAllMasterPosVarntADGrp(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVars){
		List<UserRoleADGrpMdl> posVrLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		String[] posIdArr=(posIds == null || posIds.length() == 0)? new String[] {}:posIds.split(",");
		String[] acsTypIdArr=(acsTypIds == null || acsTypIds.length() == 0)? new String[] {}:acsTypIds.split(",");
		String[] posVarArr=(posVars == null || posVars.length() == 0)? new String[] {}:posVars.split(",");
		try{
			posVrLst = userIdentityDao.getMPosVarnADGrpKV(bfId, secIdArr, regIdArr, sysId, posIdArr, acsTypIdArr, posVarArr);
			log.info("Total Records for PositionVariants :"+posVrLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posVrLst;
	}

	//Build Query for Conflicts.



	@Override
	public List<UserIdentityConflictMdl> checkSodConflicts(String wwId, List<String> newPosnVarIds, List<String> extPosnVarIds) {
		List<UserIdentityConflictMdl> confMdl = new LinkedList<>();
		List<String> allIds = new ArrayList<>();
		allIds.addAll(newPosnVarIds);
		allIds.addAll(extPosnVarIds);
		try {
			if(!allIds.isEmpty() && allIds.size() > 1) {
				String query = buildQuery(allIds);
				confMdl = userIdentityDao.getConflictsforPositions(query);
			}
		} catch (Exception e) {
			log.error("Error Getting Conflict Info :"+e.getMessage(), e);
		}
		return confMdl;
	}


	private String buildQuery(List<String> data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT RISK_ID, RISK_DESC, APP1, APP_NAME1, APP2, APP_NAME2, POSV1, POSV_NAME1, POSV2, POSV_NAME2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_DB_USER.USER_CONFLICT_MATRIX ");
		sql.append(" WHERE (");
		for (int i = 0; i < data.size(); i++) {
			for (int j = i+1; j < data.size(); j++) {
				sql.append(" ( POSV1 = "+data.get(i) +" AND POSV2 = "+data.get(j)+") OR (POSV2 = "+data.get(i) +" AND POSV1 = "+data.get(j)+") ");
				if(i < (data.size() - 2)) {
					sql.append(" OR ");
				}
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, POSV1, POSV2 ");
		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}

	@Override
	public int saveUIRequestData(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst, List<UserIdentityConflictMdl> confList, List<ExcessiveAccessModel> exList, UserSearchModel curUser, UserSearchModel assocUser) {
		int requestId = 0;
		try{
			requestId = userIdentityDao.saveUIUserRequest(reqModel, dispModelLst);
			if(requestId > 0) {//Save Successfull, Routing for Manager/Compliance Approval(Trigger Email)
				if("Y".equals(reqModel.getConflFound())) {
					int confRecs = userIdentityDao.saveUIUserConflicts(requestId, assocUser, confList);
					log.info("Saved Conflicts to Database :"+confRecs);
				}
				//Excessive Access
				if("Y".equals(reqModel.getIsExces()) && !exList.isEmpty()) {
					int excsReq = userIdentityDao.saveUIExAccess(requestId, assocUser, exList);
					log.info("Saved Excessive Data to Database :"+excsReq);
				}


				log.info("Saved Request with ID : "+requestId);
				UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
				//List<PlatformProjectMdl> prjData = userIdentityDao.getProjectsData(reqModel.getPrjId()+"");
 				//Map<String, List<String>> emailMap = getApproverCategoryEmails(assocUser, reqModel.getPrjId()+"", 1, 999, assocMgr);

				Map<String, List<String>> emailMap = new HashMap<>();
				List<String> toList = new ArrayList<>();
				List<String> ccList = new ArrayList<>();
				if("Y".equals(reqModel.getConflFound()) || "Y".equals(reqModel.getIsExces())) {
					toList.add("dchauras@its.jnj.com");//TODO:Add compliance Email ID
					ccList.add("dchauras@its.jnj.com");//Associate email
					ccList.add("dchauras@its.jnj.com");//Manager email
				}else {
					toList.add("dchauras@its.jnj.com");//Associate email
					ccList.add("dchauras@its.jnj.com");//Manager email
				}
				emailMap.put("TO", toList);
				emailMap.put("CC", ccList);

				emailUtil.triggerNewReqEmail(reqModel, dispModelLst, (("Y".equals(reqModel.getConflFound()) || "Y".equals(reqModel.getIsExces()))? Constants.REQ_COMPL_ROUTING : Constants.REQ_SAVED_MGR_ROUTING), requestId+"", assocUser, assocMgr, emailMap);
				//userIdentityDao.updateRequestStatus(requestId, 2);//Routed for Manager Approval
			}
		} catch (Exception e) {
			log.error("Error Saving Ticket Info:"+e.getMessage(), e);
		}
		return requestId;
	}



	@SuppressWarnings("all")
	@Override
	public List<UIRequestDispModel> getAllNewRequests(String startDate, String endDate, String userWwId, int status) {
		List<UIRequestDispModel> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try {
			List<UIRequestDispModel> allReqs = userIdentityDao.getNewUserSubmittedReqs(startDate, endDate, userWwId, status);
			for(UIRequestDispModel reqMdl:allReqs ) {
				UserSearchModel reqByUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getReqBy(), 0);
				reqMdl.setReqByName(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getUserId(), 1);
				reqMdl.setAssoUserName(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getMgrWwid(), 1);
				reqMdl.setMgrName(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
				if(reqMdl.getReqStatus() > 6) {
					reqMdl.setRoleStatus(userIdentityDao.getDBRoleReqstStatus(reqMdl.getReqId()+""));
				}
			}
			//List<UserRequestDispMdl> allReqs = userIdentityDao.getUserSubmittedReqs(startDate, endDate, projects, status, userWwId);
			/*if(allReqs != null && !allReqs.isEmpty()) {
				userReqs = getRequestDependencies(allReqs);
			}*/
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}

	@Override
	public List<UIRequestDispModel> getAllApprovalRequests(String startDate, String endDate, String userWwId){
		List<UIRequestDispModel> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try {
			List<UIRequestDispModel> allReqs = userIdentityDao.getNewUserApprovalReqs(startDate, endDate, userWwId);
			for(UIRequestDispModel reqMdl:allReqs ) {
				UserSearchModel reqByUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getReqBy(), 0);
				reqMdl.setReqByName(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getUserId(), 1);
				reqMdl.setAssoUserName(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getMgrWwid(), 1);
				reqMdl.setMgrName(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
				if(reqMdl.getReqStatus() > 6) {
					reqMdl.setRoleStatus(userIdentityDao.getDBRoleReqstStatus(reqMdl.getReqId()+""));
				}
			}
			//List<UserRequestDispMdl> allReqs = userIdentityDao.getUserSubmittedReqs(startDate, endDate, projects, status, userWwId);
			/*if(allReqs != null && !allReqs.isEmpty()) {
				userReqs = getRequestDependencies(allReqs);
			}*/
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}

	@Override
	public List<UIRequestDispModel> getTicketData(String tktNum){
		List<UIRequestDispModel> userTktLst = new ArrayList<>();
		try {
			List<UIRequestDispModel> tktLst = userIdentityDao.getUserSavedTktData(tktNum);
			if(tktLst != null && !tktLst.isEmpty()) {
				UIRequestDispModel mdl= tktLst.get(0);
				userTktLst.add(mdl);
				//POSITIONS
				/*if(mdl.getPositionIds() != null && mdl.getPositionIds().length() > 0) {
					List<KeyValPair> positions = userIdentityDao.getPositionsKeyVal(mdl.getPositionIds().split(","));
					mdl.setPositions(positions);
				}*/

				//Sectors
				/*if(mdl.getSecIds() != null && mdl.getSecIds().length() > 0) {
					List<KeyValPair> sectors = userIdentityDao.getSectorsKeyVal(mdl.getSecIds().split(","));
					mdl.setSectors(sectors);
					//mdl.setSecNames(Utility.getStringValues(sectors));
				}*/

				//Regions
				/*if(mdl.getRegIds() != null && mdl.getRegIds().length() > 0) {
					List<KeyValPair> rgns = userIdentityDao.getRegionsKeyVal(mdl.getRegIds().split(","));
					mdl.setRegions(rgns);
					//mdl.setRegNames(Utility.getStringValues(rgns));
				}
				 */


				/*List<TktApprLogMdl> apprDataLst = userIdentityDao.getApprovalLogData(mdl.getReqId()+"");
				mdl.setApproverLog(apprDataLst);
				userTktLst.add(mdl);*/
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userTktLst;
	}

	@Override
	public List<UIReqDpendncMdl> getRequestDependency(String reqId) {
		List<UIReqDpendncMdl> depLst = new ArrayList<>();
		try {
			depLst = userIdentityDao.getRequestDependencies(reqId);
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return depLst;
	}

	@Override
	public List<UserIdentityConflictMdl> getAllReqConflicts(String reqId) {
		List<UserIdentityConflictMdl> confLst = new ArrayList<>();
		try {
			confLst = userIdentityDao.getRequestConflicts(reqId);
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return confLst;
	}

	@Override
	public List<ExcessiveAccessModel> getAllReqExcData(String reqId) {
		List<ExcessiveAccessModel> excLst = new ArrayList<>();
		try {
			excLst = userIdentityDao.getRequestExcData(reqId);
		} catch (Exception e) {
			log.error("Error getting Request Excessive Data: "+e.getMessage(), e);
		}
		return excLst;
	}

	@Override
	public List<KeyValPair> getPosVarForIDs(String varIds) {
		List<KeyValPair> varKv = new ArrayList<>();
		try {
			varKv = userIdentityDao.getPosVarKeyVal(varIds.split(","));
		} catch (Exception e) {
			log.error("Error Position Variant Data: "+e.getMessage(), e);
		}
		return varKv;
	}


	@Override
	public List<UserIdentityConflictMdl> getAllUserConflicts(String userId) {
		List<UserIdentityConflictMdl> confLst = new ArrayList<>();
		try {
			confLst = userIdentityDao.getUserConflicts(userId);
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return confLst;
	}

	@Override
	public List<KeyValPair> getAllMitigatingControls(String id, String type) {
		List<KeyValPair> mitiLst = new ArrayList<>();
		try {
			mitiLst = userIdentityDao.getMitiControls(id, type);
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return mitiLst;
	}

	@Override
	public int saveConfApprovalStatus(List<UserIdentityConflictMdl> resolMdl, String userId) {
		int status = 0;
		try{
			int recUpd = userIdentityDao.saveTktConflictApproval(resolMdl);
			int reqUpd = userIdentityDao.updReqSodApprStatus(resolMdl.get(0).getReqId(), 3, "Y");
			if(recUpd > 0 && reqUpd > 0) {
				UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
				UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
				emailUtil.triggerConfApprovalEmail(resolMdl.get(0).getReqId(), 3, assocUser, assocMgr, "C");//Sending Approval Email to User
			}
		} catch (Exception e) {
			log.error("Error Saving SOD Conflicts Approval Data: "+e.getMessage(), e);
			status =1;
		}
		return status;
	}

	@Override
	public int saveExcesApprovalStatus(List<ExcessiveAccessModel> resolMdl, String userId) {
		int status = 0;
		try{
			int recUpd = userIdentityDao.saveTktExcesApproval(resolMdl);
			int reqUpd = userIdentityDao.updReqSodApprStatus(resolMdl.get(0).getReqId()+"", 3, "Y");
			if(recUpd > 0 && reqUpd > 0) {
				UserSearchModel assocUser = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
				UserSearchModel assocMgr = sAPExtrGaaDataService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
				emailUtil.triggerConfApprovalEmail(resolMdl.get(0).getReqId()+"", 3, assocUser, assocMgr, "E");//Sending Approval Email to User
			}
		} catch (Exception e) {
			log.error("Error Saving SOD Conflicts Approval Data: "+e.getMessage(), e);
			status =1;
		}
		return status;
	}

	@Override
	public List<UserIdentityConflictMdl> buildConflictApprModel(String reqId, String userId, String curUserId, String[] apprDataArray){
		List<UserIdentityConflictMdl> resolMdl = new ArrayList<>();
		for(String data: apprDataArray){
			String[] dataArr = data.split("~");
			UserIdentityConflictMdl cMdl = new UserIdentityConflictMdl();
			cMdl.setUserId(userId);
			cMdl.setReqId(reqId);
			cMdl.setRiskId(dataArr[0].split("_")[1]);
			cMdl.setResolStatus("C");
			cMdl.setAcceptDeny(("D".equals(dataArr[1])? "D":"A"));
			cMdl.setMitiCntrlSel("D".equals(dataArr[1])? 0: Integer.parseInt(dataArr[1]));
			cMdl.setReslCmnts(dataArr[2]);
			cMdl.setReslBy(curUserId);
			cMdl.setDtResolved(new Date());
			resolMdl.add(cMdl);
		}
		return resolMdl;
	}


	@Override
	public List<ExcessiveAccessModel> buildExcesApprModel(String reqId, String userId, String curUserId, String[] apprDataArray){
		List<ExcessiveAccessModel> resolMdl = new ArrayList<>();
		for(String data: apprDataArray){
			String[] dataArr = data.split("~");
			ExcessiveAccessModel cMdl = new ExcessiveAccessModel();
			cMdl.setUserId(userId);
			cMdl.setReqId(Integer.parseInt(reqId));
			cMdl.setSysId(dataArr[0].split("_")[1]);
			cMdl.setResolved("Y");
			cMdl.setAcceptDeny(("D".equals(dataArr[1])? "D":"A"));
			cMdl.setCntrlSel("D".equals(dataArr[1])? 0: Integer.parseInt(dataArr[1]));
			cMdl.setReslCmnts(dataArr[2]);
			cMdl.setReslBy(curUserId);
			cMdl.setDtResolved(new Date());
			resolMdl.add(cMdl);
		}
		return resolMdl;
	}

	@SuppressWarnings("all")
	@Override
	public List<UIRequestDispModel> getAllApprovedRequests() {
		List<UIRequestDispModel> userReqs = new ArrayList<>();
		try{
			List<UIRequestDispModel> allReqs = userIdentityDao.getAllApprovedUserReqs();
			for(UIRequestDispModel reqMdl:allReqs ) {
				UserSearchModel reqByUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getReqBy(), 0);
				reqMdl.setReqByName(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getUserId(), 1);
				reqMdl.setAssoUserName(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getMgrWwid(), 1);
				reqMdl.setMgrName(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}


	@SuppressWarnings("all")
	@Override
	public List<UIRequestDispModel> getAllReqSubmittedToIAM() {
		List<UIRequestDispModel> userReqs = new ArrayList<>();
		try{
			List<UIRequestDispModel> allReqs = userIdentityDao.getAllIamSubmittedReqs();
			for(UIRequestDispModel reqMdl:allReqs ) {
				UserSearchModel reqByUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getReqBy(), 0);
				reqMdl.setReqByName(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getUserId(), 1);
				reqMdl.setAssoUserName(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = sAPExtrGaaDataService.getUserStatusJJEDS(reqMdl.getMgrWwid(), 1);
				reqMdl.setMgrName(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}

	@Override
	public boolean sendReqDataToIamGrc(UIRequestDispModel reqMdl) {
		//Get System Info for Request ID
		boolean result = false;
		try {
			Date start = new Date();
			log.info("Processing REQUEST ID: "+reqMdl.getReqId()+" STARTED at time: "+Utility.fmtMMDDYYYYTime(start));
			List<UIReqDpendncMdl> reqDetLst = userIdentityDao.getRequestDependencies(reqMdl.getReqId()+"");
			if(reqDetLst != null && !reqDetLst.isEmpty()) {
				for(UIReqDpendncMdl detailNum : reqDetLst) {
					if(detailNum.getSysId().equals("1")) {
						//Process GRC Data Send
					}else {
						//Send to IAM
						 List<IAMRequestedRoleModel> respList = sendDataToIAM(reqMdl.getReqId(), reqMdl.getUserId(), reqMdl.getReqBy(), detailNum.getSysId(), reqMdl.getComments(),  detailNum);
						 if(respList != null && !respList.isEmpty()) {
							 int recsInserted = userIdentityDao.saveIamReqstedRoles(respList);
							 if(recsInserted == respList.size()) {
								 result = true;
							 }
						 }
					}
				}
			}
			log.info("Processing REQUEST ID: "+reqMdl.getReqId()+" COMPLETED at time: "+Utility.fmtMMDDYYYYTime(start));
		}catch (Exception e) {
			log.error("Error processing data post to GRC/IAM :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public boolean getReqStatusFromIamGrc(UIRequestDispModel reqMdl) {
		//Get System Info for Request ID
		boolean result = true;
		try {
			Date start = new Date();
			log.info("Getting REQUEST ID: "+reqMdl.getReqId()+" STARTED at time: "+Utility.fmtMMDDYYYYTime(start));
			List<IAMRequestedRoleModel> reqDetLst = userIdentityDao.getGRCIAMReqSubmDependencies(reqMdl.getReqId()+"");
			if(reqDetLst != null && !reqDetLst.isEmpty()) {
				for(IAMRequestedRoleModel detailNum : reqDetLst) {
					if(detailNum.getSysId().equals("1")) {
						//Process GRC Data Send
					}else {
						//GET Status from IAM
						IamAdGrpServiceStatusRespDTO iamRespBody = getStatusFromIAM(detailNum);
						int recsUpdated = 0;
						if(iamRespBody != null && iamRespBody.getValues() != null) {
							String status = "";
							String stMsg  = "";
							String errMsg = "";
							if( iamRespBody.getValues().isCCC_IsComplete() && !iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_COMPLTED; stMsg  = "Role Assigned"; errMsg = "";
							}else if( !iamRespBody.getValues().isCCC_IsComplete() && !iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_PENDING; stMsg  = ""; 	errMsg = "";
							}else if(iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_ERROR; stMsg  = ""; 	errMsg = iamRespBody.getValues().getCCC_ErrorMessage();
							}
							recsUpdated = userIdentityDao.updateIamReqstedRolesStatus(status, stMsg, errMsg, iamRespBody.getValues().getXDateUpdated(), detailNum);
							log.info("Updated ("+recsUpdated+") Records to ("+status+") Status.");
						}
					}
				}
			}
			log.info("Status for REQUEST ID: "+reqMdl.getReqId()+" CAPTURED at time: "+Utility.fmtMMDDYYYYTime(start));
		}catch (Exception e) {
			log.error("Error processing data post to GRC/IAM :"+e.getMessage(), e);
		}
		return result;
	}



	@Override
	public List<IAMRequestedRoleModel> sendDataToIAM(int reqId, String userId, String reqBy, String sysId, String comments, UIReqDpendncMdl detailNum) {
		List<IAMRequestedRoleModel> rolesList = new ArrayList<>();
		try{
			String iamSessionId = exchangeDataController.getIamRequestSession();
			HttpHeaders headers = exchangeDataController.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();
			String[] adIds = detailNum.getAdIds().split(",");
			for(String adGrpId : adIds) {
				String adGrpName = userIdentityDao.getAdGrpById(adGrpId);
				IamAdGrpRequestDTO reqDto = new IamAdGrpRequestDTO();
				reqDto.setCCC_RequestType(Constants.GRP_MEMBERSHIP);
				reqDto.setCCC_Reason(comments);
				reqDto.setCCC_ActionType(Constants.TYPE_ADD);
				//reqObj.setCCC_Requestor(reqBy);
				reqDto.setCCC_Requestor("SA-HCS-SOD_DB_USER");
				reqDto.setCCC_ResourceName(adGrpName);
				reqDto.setCCC_Recipient(userId);

				IamAdGrpRequestObj reqObj = new IamAdGrpRequestObj();//
				reqObj.setValues(reqDto);
				String reqElement = gson.toJson(reqObj);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM, HttpMethod.POST, reqEntity, String.class);
				IamAdGrpServiceSubRespDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					log.info("Resp Body: "+respEntity.getBody());
					respDto = gson.fromJson(respEntity.getBody(), IamAdGrpServiceSubRespDTO.class);
					log.info("resp.UID :"+respDto.getUid()+" URI: "+respDto.getUri());
				}else {
					respDto = new IamAdGrpServiceSubRespDTO();
					respDto.setUid("");
					respDto.setUri("");
				}
				rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getUid(), "N"));
			}
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }

		return rolesList;
	}

	@Override
	public IamAdGrpServiceStatusRespDTO getStatusFromIAM(IAMRequestedRoleModel detailNum) {
		IamAdGrpServiceStatusRespDTO respBody = null;
		try{
			String iamSessionId = exchangeDataController.getIamRequestSession();
			HttpHeaders headers = exchangeDataController.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();
			String submId = detailNum.getSubmUid().trim();
			String reqElement = "";
			HttpEntity<String> reqEntity = new HttpEntity<>(headers);
			ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM+"/"+submId, HttpMethod.GET, reqEntity, String.class);

			if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
				log.info("Resp Body: "+respEntity.getBody());
				respBody = gson.fromJson(respEntity.getBody(), IamAdGrpServiceStatusRespDTO.class);
				log.info("resp.STATUS COMPLETE:"+respBody.getValues().isCCC_IsComplete()+" IS ERROR: "+respBody.getValues().isCCC_IsError());
			}else {
				respBody = new IamAdGrpServiceStatusRespDTO();
				respBody.setUri("");
			}
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }

		return respBody;
	}


	@Override
	public IAMRequestedRoleModel createIamRoleModel(int reqId, String userId, String sysId, String comments, String reqBy, String adGrpId, String adGrpName, String submUid, String submStatus) {
		IAMRequestedRoleModel mdl = new IAMRequestedRoleModel();
		mdl.setReqId(reqId);
		mdl.setUserId(userId);
		mdl.setSysId(sysId);
		mdl.setComments(comments);
		mdl.setSysName("");
		mdl.setReqBy(reqBy);
		mdl.setPosId("");
		mdl.setPosName("");
		mdl.setPvId("");
		mdl.setPvName("");
		mdl.setAdgrpId(adGrpId);
		mdl.setAdgrpName(adGrpName);
		mdl.setSubmUid(submUid);
		mdl.setSubmDate(new Date());
		mdl.setSubmStatus(submStatus);
		return mdl;
	}

	@Override
	public int updateIamRequestStatus(int reqId, int status) {
		int updCount=0;
		try {
			updCount  =userIdentityDao.updateIamRequestStatus(reqId+"", status);
		} catch (Exception e) {
			log.error("ERROR Updating Req status: "+e.getMessage(), e);
		}
		return updCount;
	}

	@Override
	public int getRequestCount(String reqId) {
		int count=0;
		try {
			count  = userIdentityDao.getRequestChildCount(reqId);
		} catch (Exception e) {
			log.error("ERROR Getting Count of Requests Child Items: "+e.getMessage(), e);
		}
		return count;
	}

	@Override
	public List<String> getCompltdReqStat(String reqId) {
		List<String> dataLst = new ArrayList<>();
		try {
			dataLst  = userIdentityDao.getCompletedReqStatus(reqId);
		} catch (Exception e) {
			log.error("ERROR Getting Status of Requests Child Items: "+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public List<String> getAllSystemPosVariants(String bfId, String secIds, String regIds, String sysId){
		List<String> posVrLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		try{
			posVrLst = userIdentityDao.getAllSystemPosVariants(bfId, secIdArr, regIdArr, sysId);
			log.info("Total Records for PositionVariants :"+posVrLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posVrLst;
	}

	@Override
	public List<KeyValPair> getAllSystemPosVariantsKV(String bfId, String secIds, String regIds, String sysId){
		List<KeyValPair> posVrLst = new ArrayList<>();
		String[] secIdArr=(secIds == null || secIds.length() == 0)? new String[] {}:secIds.split(",");
		String[] regIdArr=(regIds == null || regIds.length() == 0)? new String[] {}:regIds.split(",");
		try{
			posVrLst = userIdentityDao.getAllSystemPosVariantsKV(bfId, secIdArr, regIdArr, sysId);
			log.info("Total Records for PositionVariants :"+posVrLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return posVrLst;
	}


	@Override
	public List<ExcessiveAccessModel> checkExcessiveAccess(List<SysPosAdGrpModelDispMdl> dispLst, List<UserRoleADGrpMdl> extRoles, UserSearchModel assocUser) {
		List<ExcessiveAccessModel> exLst = new ArrayList<>();
		for(SysPosAdGrpModelDispMdl dMdl : dispLst) {
			List<String> reqPosVarIds = new ArrayList<>();
			ExcessiveAccessModel exData = new ExcessiveAccessModel();
			exData.setIsExcessive("N");
			exData.setUser(assocUser);
			exData.setSysId(dMdl.getSysId());
			exData.setSysName(dMdl.getSysName());
			exData.setSelVarids(dMdl.getPosVarIds());
			exData.setSelVariants(dMdl.getPosnVariants());
			exData.setAllAvailableVars(dMdl.getAllSysVarListKV());
			exData.setLimit(Constants.SYS_EXCSV_LIMIT);
			List<KeyValPair> colExVar = new ArrayList<>();
			String colExVrIds="";
			reqPosVarIds = Arrays.asList(dMdl.getPosVarIds().split(","));
			if(!extRoles.isEmpty()) {
				for(UserRoleADGrpMdl extMdl : extRoles) {
					if(extMdl.getSysId().equals(dMdl.getSysId())) {
						if(!reqPosVarIds.contains(extMdl.getPvId())) {//Check Duplicate
							reqPosVarIds.add((extMdl.getPvId()==null)?"":extMdl.getPvId());
						}
						KeyValPair kv = new KeyValPair();
						kv.setKey(Integer.parseInt(extMdl.getPvId()));
						kv.setVal(extMdl.getPvName());
						colExVrIds = (colExVrIds.length() == 0)?extMdl.getPvId()+"":(colExVrIds+","+extMdl.getPvId());
						colExVar.add(kv);

					}
				}
			}
			exData.setExVariants(colExVar);
			exData.setExVarIds(colExVrIds);

			double reqVarCount = reqPosVarIds.size();
			double allVarCount = dMdl.getAllSysVarList().size();
			double expercntg =(reqVarCount/allVarCount)*100;
			if(expercntg >= Constants.SYS_EXCSV_LIMIT){
				dMdl.setExPercentage(expercntg);
				dMdl.setExcessive(true);
				exData.setIsExcessive("Y");
				exData.setExPercentage(expercntg);
				exData.setUserVars(getUserVars(exData));
				exLst.add(exData);
			}
		}
		return exLst;
	}

	private List<KeyValDiffPair> getUserVars(ExcessiveAccessModel exData) {
		List<KeyValDiffPair> finalList = new ArrayList<>();
		if(!exData.getSelVariants().isEmpty()) {
			for(KeyValPair kv : exData.getSelVariants()) {
				KeyValDiffPair kdp = new KeyValDiffPair();
				kdp.setKey(kv.getKey()+"");
				kdp.setVal(kv.getVal());
				kdp.setDiff("N");
				finalList.add(kdp);
			}
		}

		if(!exData.getExVariants().isEmpty()) {
			for(KeyValPair kv : exData.getExVariants()) {
				KeyValDiffPair kdp = new KeyValDiffPair();
				kdp.setKey(kv.getKey()+"");
				kdp.setVal(kv.getVal());
				kdp.setDiff("E");
				finalList.add(kdp);
			}
		}
		return finalList;
	}





}
