package com.jnj.rqc.userabs.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AbsComplianceRequest {
	private String 	reqid;
	private String	userid;
	private String  reqStatus;
	private List<UserAbsConflictMdl> confApprovalList;
	private List<AbsSysLeveExcsvRestrMdl> restExcsvAcssList;
	//private List<AbsExcesvAccsMdl> excessiveApprovalList;
}


