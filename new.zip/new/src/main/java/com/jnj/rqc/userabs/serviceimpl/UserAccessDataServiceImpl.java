package com.jnj.rqc.userabs.serviceimpl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.masterdata.dao.MasterDataDao;
import com.jnj.rqc.masterdata.dto.ZSystemMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.security.AnaplanAuthenticatorBean;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.dao.SAPUserDao;
import com.jnj.rqc.userabs.dao.UserUtilsDao;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSecExcesvRestrictedAccsMdl;
import com.jnj.rqc.userabs.models.AbsSodConflictRespDto;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RolesRespDto;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.useridentity.models.AnaplanEmailDimensionModel;
import com.jnj.rqc.useridentity.models.DBDataAnaplanEmailDimensionModel;
import com.jnj.rqc.useridentity.models.EmailItem;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>UserAccessDataServiceImpl.java</b>
 * @author : DChauras @Created : Mar 7, 2023 3:00:24 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class UserAccessDataServiceImpl implements UserAccessDataService {
	static final Logger log = LoggerFactory.getLogger(UserAccessDataServiceImpl.class);

	@Autowired
	private UserUtilsDao userUtilsDao;
	@Autowired
	private SAPUserDao sAPUserDao;
	@Autowired
	private MasterDataDao masterDataDao;
	@Autowired
	private UserSearchService userSearchService;
	@Autowired
	private AnaplanAuthenticatorBean anaplanAuthenticatorBean;
	@Autowired
	private RestTemplate restHttpTemplate;
	@Autowired
	private UserMenuDao userMenuDao;


	private void addRoleData(RoleADGrpMdl rlAdMdl, Map<String, List<RoleADGrpMdl>> sysRlsMap) {
		List<RoleADGrpMdl> usrRoles = null;
		String id = (rlAdMdl.getSysName() == null? "":rlAdMdl.getSysName())+"-"+rlAdMdl.getSysId();
		if(sysRlsMap.containsKey(id)) {
			usrRoles =  sysRlsMap.get(id);
		}else {
			usrRoles = new ArrayList<>();
		}
		usrRoles.add(rlAdMdl);
		sysRlsMap.put(id, usrRoles);
	}

	@Override
	public RolesRespDto getExistingRoles(String userId) {
		RolesRespDto rlsDto = new RolesRespDto();
		try{
			Map<String, List<RoleADGrpMdl>> sysRlsMap = getSystemsExistingRoles(userId);
			rlsDto.setStatusCode(0);
			rlsDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			rlsDto.setRoles(sysRlsMap);
		} catch (Exception e) {
			log.info("Error getting Granted Roles Data:"+e.getMessage(), e);
		}
		return rlsDto;
	}
	// Function to get or create RoleADGrpMdl
	private RoleADGrpMdl getOrCreateRoleADGrpMdl( List<RoleADGrpMdl> completeMdl, List<ZSystemMdl> systemList, IAMRolesADGrpMdl rlMdl, String sysId, String defaultSysName) {
	    RoleADGrpMdl usrMdl = null;
	    if (completeMdl != null && !completeMdl.isEmpty()) {
	        usrMdl = completeMdl.get(0);
	        usrMdl.setUserId(rlMdl.getUser());
	        usrMdl.setIsExisting("Y");
	    } /*else {
	        usrMdl = new RoleADGrpMdl();
	        usrMdl.setSysId((!systemList.isEmpty() ? systemList.get(0).getSysid() + "" : sysId));
	        usrMdl.setSysName((!systemList.isEmpty() ? systemList.get(0).getSysname() : defaultSysName));
	        usrMdl.setUserId(rlMdl.getUser());
	        usrMdl.setAdgrpName(rlMdl.getLdapADGroup());
	        usrMdl.setIsExisting("Y");
	    }*/
	    return usrMdl;
	}

		@Override
	public Map<String, List<RoleADGrpMdl>> getSystemsExistingRoles(String userId) {
		Map<String, List<RoleADGrpMdl>> sysRlsMap = new HashMap<>();
		try{

			//Removing Cache Part to check performance. // By Raja
			//Check Cache
			/*if(Utility.hasUserAccess(userId)) {
				sysRlsMap = Utility.getUserAccess(userId);
			}else {*/
				//GET -PFB(DDGR) system Details --DATA HUB-2
			System.out.println("Before DDGR RFC method Call>>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
				List<IAMRolesADGrpMdl>  pfbRoleLst = getPFBSystemRolesADGrpData(Constants.SAP_ADGRP_BW4PFB, userId);
				System.out.println("After DDGR RFC method Call>>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
				/*List<ZSystemMdl> systemLst2 = masterDataDao.getAllZSystems(2);
			    List<ZSystemMdl> systemLst3 = masterDataDao.getAllZSystems(3);
			    List<ZSystemMdl> systemLst6 = masterDataDao.getAllZSystems(6);
			    for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
			    	RoleADGrpMdl usrMdl2 = getOrCreateRoleADGrpMdl(getSystemRoleDetail(rlMdl.getLdapADGroup(), "2"), systemLst2, rlMdl, "2", "Data Hub");	
			    	if(usrMdl2!=null) {
				        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
				        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
				        addRoleData(usrMdl2, sysRlsMap);
			    	}
			            
			        RoleADGrpMdl usrMdl3 = getOrCreateRoleADGrpMdl(getSystemRoleDetail(rlMdl.getLdapADGroup(), "3"), systemLst3, rlMdl, "3", "Bravo Express (Plan And Actual)" );
			        if(usrMdl3!=null) {
		                usrMdl3.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
		                usrMdl3.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
		                addRoleData(usrMdl3, sysRlsMap);
			        }
			        RoleADGrpMdl usrMdl5 = getOrCreateRoleADGrpMdl(getSystemRoleDetail(rlMdl.getLdapADGroup(), "5"), systemLst3, rlMdl, "5", "Management A1 Adjustments" );
			        if(usrMdl5!=null) {
		                usrMdl5.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
		                usrMdl5.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
		                addRoleData(usrMdl5, sysRlsMap);
			        }
			        
			        RoleADGrpMdl usrMdl6 = getOrCreateRoleADGrpMdl(getSystemRoleDetail(rlMdl.getLdapADGroup(), "6"), systemLst6, rlMdl, "6", "SAP Analytics Cloud (SAC) Reporting");	
			    	if(usrMdl6!=null) {
			    		usrMdl6.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
			    		usrMdl6.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
				        addRoleData(usrMdl6, sysRlsMap);
			    	}
			    }*/
				if(pfbRoleLst != null && !pfbRoleLst.isEmpty()){
					List<String> uniqueADGrpNames = pfbRoleLst.stream().map(r -> r.getLdapADGroup()).distinct().collect(Collectors.toList());
					List<RoleADGrpMdl> ddgrSystemRoleDetail=getAllSystemRoleDetail(uniqueADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"2");
					for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
						RoleADGrpMdl usrMdl2 = ddgrSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
					
					List<RoleADGrpMdl> bravoSystemRoleDetail=getAllSystemRoleDetail(uniqueADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"3");
					for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
						RoleADGrpMdl usrMdl2 = bravoSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
					
					List<RoleADGrpMdl> aOneSystemRoleDetail=getAllSystemRoleDetail(uniqueADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"5");
					for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
						RoleADGrpMdl usrMdl2 = aOneSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
					
					List<RoleADGrpMdl> sacSystemRoleDetail=getAllSystemRoleDetail(uniqueADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"6");
					for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
						RoleADGrpMdl usrMdl2 = sacSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
				}
			    /*for (IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
			    	RoleADGrpMdl usrMdl2 = getSystemRoleDetail(rlMdl.getLdapADGroup(), "2").get(0);	
			    	if(usrMdl2!=null) {
				        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
				        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
				        usrMdl2.setUserId(rlMdl.getUser());
				        usrMdl2.setIsExisting("Y");
				        addRoleData(usrMdl2, sysRlsMap);
			    	}
			            
			        RoleADGrpMdl usrMdl3 = getSystemRoleDetail(rlMdl.getLdapADGroup(), "3").get(0);
			        if(usrMdl3!=null) {
		                usrMdl3.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
		                usrMdl3.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
		                usrMdl3.setUserId(rlMdl.getUser());
		                usrMdl3.setIsExisting("Y");
		                addRoleData(usrMdl3, sysRlsMap);
			        }
			        RoleADGrpMdl usrMdl5 = getSystemRoleDetail(rlMdl.getLdapADGroup(), "5").get(0);
			        if(usrMdl5!=null) {
		                usrMdl5.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
		                usrMdl5.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
		                usrMdl5.setUserId(rlMdl.getUser());
		                usrMdl5.setIsExisting("Y");
		                addRoleData(usrMdl5, sysRlsMap);
			        }
			        
			        RoleADGrpMdl usrMdl6 = getSystemRoleDetail(rlMdl.getLdapADGroup(), "6").get(0);	
			    	if(usrMdl6!=null) {
			    		usrMdl6.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
			    		usrMdl6.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
			    		usrMdl6.setUserId(rlMdl.getUser());
			    		usrMdl6.setIsExisting("Y");
				        addRoleData(usrMdl6, sysRlsMap);
			    	}
			    }*/
			    System.out.println("After DDGR Object Construction >>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
				/*if(pfbRoleLst != null && !pfbRoleLst.isEmpty()){
					List<ZSystemMdl> systemLst = masterDataDao.getAllZSystems(2);
					for(IAMRolesADGrpMdl rlMdl : pfbRoleLst) {
						List<RoleADGrpMdl> completeMdl = getSystemRoleDetail(rlMdl.getLdapADGroup(), "2");
						RoleADGrpMdl usrMdl = null;
						if(completeMdl != null && !completeMdl.isEmpty()) {
							usrMdl = completeMdl.get(0);
							usrMdl.setUserId(rlMdl.getUser());
							usrMdl.setIsExisting("Y");
						}else {
							usrMdl = new RoleADGrpMdl();
							usrMdl.setSysId((!systemLst.isEmpty()? systemLst.get(0).getSysid()+"" : "2"));
							usrMdl.setSysName((!systemLst.isEmpty()? systemLst.get(0).getSysname() : "Data Hub"));
							usrMdl.setUserId(rlMdl.getUser());
							usrMdl.setAdgrpName(rlMdl.getLdapADGroup());
							usrMdl.setIsExisting("Y");
						}
						if(rlMdl.getMdate() != null && rlMdl.getMdate().length() > 0) {
							usrMdl.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
						}
						if(rlMdl.getStopdate() != null && rlMdl.getStopdate().length() > 0) {
							usrMdl.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
						}
						addRoleData(usrMdl, sysRlsMap);
					}										
				}*/
				//CFIN DATA
			    System.out.println("Before CFIN RFC method Call>>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
				List<IAMRolesADGrpMdl>  cfinRoles = readPFICFINRolesPosnData(Constants.SAP_ADGRP_S4PFI, userId);
				System.out.println("After CFIN RFC method Call>>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
				
				if(cfinRoles != null && !cfinRoles.isEmpty()){
					List<String> cfinUniqADGrpNames = cfinRoles.stream().map(r -> r.getLdapADGroup()).distinct().collect(Collectors.toList());
					List<RoleADGrpMdl> cfinSystemRoleDetail=getAllSystemRoleDetail(cfinUniqADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"1");
					for (IAMRolesADGrpMdl rlMdl : cfinRoles) {
						RoleADGrpMdl usrMdl2 = cfinSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
				}
				
				/*if(cfinRoles != null && !cfinRoles.isEmpty()){
					List<ZSystemMdl> systemLst = masterDataDao.getAllZSystems(1);
					for(IAMRolesADGrpMdl cfRole : cfinRoles) {
						List<RoleADGrpMdl> complMdl = getSystemRoleDetail(cfRole.getLdapADGroup(), "1");
						RoleADGrpMdl usrMdl = null;
						if(complMdl != null && !complMdl.isEmpty()) {
							usrMdl = complMdl.get(0);
							usrMdl.setUserId(userId);
							usrMdl.setIsExisting("Y");
						}else {
							usrMdl = new RoleADGrpMdl();
							usrMdl.setSysId((!systemLst.isEmpty()? systemLst.get(0).getSysid()+"" : "1"));
							usrMdl.setSysName((!systemLst.isEmpty()? systemLst.get(0).getSysname() : "CFIN"));
							usrMdl.setUserId(userId);
							usrMdl.setAdgrpName(cfRole.getLdapADGroup());
							usrMdl.setIsExisting("Y");
						}
						if(cfRole.getMdate() != null && cfRole.getMdate().length() > 0) {
							usrMdl.setUpdDate(Utility.fmtYMDStr(cfRole.getMdate()));
						}
						if(cfRole.getStopdate() != null && cfRole.getStopdate().length() > 0) {
							usrMdl.setEndDate(Utility.fmtYMDStr(cfRole.getStopdate()));
						}
						addRoleData(usrMdl, sysRlsMap);
					}
				}*/
				
				System.out.println("After CFIN Object Construction >>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));

				//Ananplan Roles - from AnaPlan Webservice
				UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userId, 1);
				//List<IAMRolesADGrpMdl>  csmRoles = userUtilsDao.getAnaplanHistDataForUser(userId);
				List<IAMRolesADGrpMdl>  csmRoles = getAnaPlanUserDataByEmail(assocUser);
				if(csmRoles != null && !csmRoles.isEmpty()){
					List<String> anaplanUniqADGrpNames = csmRoles.stream().map(r -> r.getLdapADGroup()).distinct().collect(Collectors.toList());
					List<RoleADGrpMdl> anaplanSystemRoleDetail=getAllSystemRoleDetail(anaplanUniqADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"4");
					for (IAMRolesADGrpMdl rlMdl : csmRoles) {
						RoleADGrpMdl usrMdl2 = anaplanSystemRoleDetail.stream().filter(carnet -> rlMdl.getLdapADGroup().equals(carnet.getAdgrpName())).findFirst().orElse(null);
						if(usrMdl2!=null) {
					        usrMdl2.setUpdDate(Utility.fmtYMDStr(rlMdl.getMdate()));
					        usrMdl2.setEndDate(Utility.fmtYMDStr(rlMdl.getStopdate()));
					        usrMdl2.setUserId(rlMdl.getUser());
					        usrMdl2.setIsExisting("Y");
					        addRoleData(usrMdl2, sysRlsMap);
				    	}
					}
				}
				/*if(csmRoles != null && !csmRoles.isEmpty()){
					List<ZSystemMdl> systemLst = masterDataDao.getAllZSystems(4);
					for(IAMRolesADGrpMdl aRole : csmRoles) {
						List<RoleADGrpMdl> complMdl = getSystemRoleDetail(aRole.getLdapADGroup(), "4");
						RoleADGrpMdl usrMdl = new RoleADGrpMdl();
						if(complMdl != null && !complMdl.isEmpty()) {
							usrMdl=complMdl.get(0);
							usrMdl.setUserId(userId);
							usrMdl.setIsExisting("Y");
						}else {
							usrMdl.setSysId((!systemLst.isEmpty()? systemLst.get(0).getSysid()+"" : "4"));
							usrMdl.setSysName((!systemLst.isEmpty()? systemLst.get(0).getSysname() : "Anaplan"));
							usrMdl.setUserId(userId);
							usrMdl.setAdgrpName(aRole.getLdapADGroup());
							usrMdl.setIsExisting("Y");
						}
						if(aRole.getMdate() != null && aRole.getMdate().length() > 0) {
							usrMdl.setUpdDate(Utility.fmtYMDStr(aRole.getMdate()));
						}
						if(aRole.getStopdate() != null && aRole.getStopdate().length() > 0) {
							usrMdl.setEndDate(Utility.fmtYMDStr(aRole.getStopdate()));
						}
						addRoleData(usrMdl, sysRlsMap);
					}
				}*/




				//Ananplan Roles - from DB - OLD
				/*List<IAMRolesADGrpMdl>  csmRoles = userUtilsDao.getAnaplanHistDataForUser(userId);
				if(csmRoles != null && !csmRoles.isEmpty()){
					List<ZSystemMdl> systemLst = masterDataDao.getAllZSystems(4);
					for(IAMRolesADGrpMdl aRole : csmRoles) {
						List<RoleADGrpMdl> complMdl = getSystemRoleDetail(aRole.getLdapADGroup(), "4");
						RoleADGrpMdl usrMdl = new RoleADGrpMdl();
						if(complMdl != null && !complMdl.isEmpty()) {
							usrMdl=complMdl.get(0);
							usrMdl.setUserId(userId);
							usrMdl.setIsExisting("Y");
						}else {
							usrMdl.setSysId((!systemLst.isEmpty()? systemLst.get(0).getSysid()+"" : "4"));
							usrMdl.setSysName((!systemLst.isEmpty()? systemLst.get(0).getSysname() : "Anaplan"));
							usrMdl.setUserId(userId);
							usrMdl.setAdgrpName(aRole.getLdapADGroup());
							usrMdl.setIsExisting("Y");
						}
						if(aRole.getMdate() != null && aRole.getMdate().length() > 0) {
							usrMdl.setUpdDate(Utility.fmtYMDStr(aRole.getMdate()));
						}
						if(aRole.getStopdate() != null && aRole.getStopdate().length() > 0) {
							usrMdl.setEndDate(Utility.fmtYMDStr(aRole.getStopdate()));
						}
						addRoleData(usrMdl, sysRlsMap);
					}
				}*/

				//GRC DATA
				/*List<IAMRolesADGrpMdl>  grcRoles = readGRCSYSUserRolesPosnData(Constants.SAP_GRC_SYSTEM, userId);
				if(grcRoles != null && !grcRoles.isEmpty()){
					for(IAMRolesADGrpMdl gRole : grcRoles) {
						List<RoleADGrpMdl> complMdl = getCFINRoleDetail(gRole.getLdapADGroup());
						RoleADGrpMdl usrMdl = new RoleADGrpMdl();
						if(complMdl != null && !complMdl.isEmpty()) {
							usrMdl=complMdl.get(0);
							usrMdl.setUserId(userId);
						}else {
							usrMdl.setUserId(userId);
							usrMdl.setAdgrpName(gRole.getLdapADGroup());
							usrMdl.setSysId("1");
							usrMdl.setSysName("CFIN");
						}
						if(gRole.getMdate() != null && gRole.getMdate().length() > 0) {
							usrMdl.setUpdDate(Utility.fmtYMDStr(gRole.getMdate()));
						}
						if(gRole.getStopdate() != null && gRole.getStopdate().length() > 0) {
							usrMdl.setEndDate(Utility.fmtYMDStr(gRole.getStopdate()));
						}
						addRoleData(usrMdl, sysRlsMap);
					}
				}*/

				/*ANAPLAN-IAM Roles from IAM */
				/*List<String>  iamRoles = userIdentityDao.getAnaplanHistDataForUser(userId);
				if(iamRoles != null && !iamRoles.isEmpty()){
					for(String tRole : iamRoles) {
						List<UserRoleADGrpMdl> complMdl = getAnaplanRoleDetail(tRole);
						UserRoleADGrpMdl usrMdl = new UserRoleADGrpMdl();
						if(complMdl != null && !complMdl.isEmpty()) {
							usrMdl=complMdl.get(0);
							usrMdl.setUserId(userId);
						}else {
							usrMdl.setUserId(userId);
							usrMdl.setAdgrpName(tRole);
							usrMdl.setSysId("4");
							usrMdl.setSysName("Anaplan");
						}
						usrRoles.add(usrMdl);
					}
				}
				*/

				//Removing Cache Part to check performance. // By Raja
				/*
				 * if(null != sysRlsMap && !sysRlsMap.isEmpty()) { Utility.setUserAccess(userId,
				 * sysRlsMap); } }
				 */


		} catch (Exception e) {
			log.info("Error getting Granted Roles Data:"+e.getMessage(), e);
		}
		return sysRlsMap;
	}



	@Override
	public List<IAMRolesADGrpMdl> getPFBSystemRolesADGrpData(String templSysParam, String userId) {
		List<IAMRolesADGrpMdl> allUserData = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID:"+userId);
			allUserData = sAPUserDao.getPFBRoleADGrps(templSysParam, userId);
			log.info("Total Records for User ROles from  ("+(allUserData !=null? allUserData.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}


	@Override
	public List<IAMRolesADGrpMdl> readPFICFINRolesPosnData(String templSysParam, String userId) {
		List<IAMRolesADGrpMdl> cfinRoles = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID:"+userId);
			cfinRoles = sAPUserDao.getPFIRoleADGrps(templSysParam, userId);
			log.info("Total Records for User Roles from  ("+(cfinRoles !=null? cfinRoles.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cfinRoles;
	}



	@Override
	public List<IAMRolesADGrpMdl> readGRCSYSUserRolesPosnData(String templSysParam, String userId) {
		List<IAMRolesADGrpMdl> cfinRoles = new LinkedList<>();
		try {
			log.info("Getting User Roles Data for System: "+templSysParam+" USER ID:"+userId);
			cfinRoles = sAPUserDao.getPFIRoleADGrps(templSysParam, userId);
			log.info("Total Records for User Roles from  ("+(cfinRoles !=null? cfinRoles.size():"0")+" for System: "+templSysParam);
			} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return cfinRoles;
	}



	@Override
	public List<RoleADGrpMdl> getSystemRoleDetail(String ldapADGroup, String sysId) {
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userUtilsDao.getMstRolesDataForADGrp(ldapADGroup, sysId);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}
	
	@Override
	public List<RoleADGrpMdl> getAllSystemRoleDetail(String ldapADGroup, String sysId) {
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userUtilsDao.getAllMstRolesDataForADGrp(ldapADGroup, sysId);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public List<RoleADGrpMdl> getSystemDetail(String ldapADGroup ) {
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userUtilsDao.getMstDataForADGrp(ldapADGroup);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public List<RoleADGrpMdl> getCFINRoleDetail(String tchRole){
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userUtilsDao.getCFINMstDataForRole(tchRole);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public List<RoleADGrpMdl> getAnaplanRoleDetail(String tchRole){
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		try {
			dataLst = userUtilsDao.getAnaplanMstDataForRole(tchRole);
		} catch (Exception e) {
			log.error("Error getting AD Group Data:"+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public AbsSodConflictRespDto checkAbsSodConflicts(String wwId, List<RoleADGrpMdl> newRoles, List<RoleADGrpMdl> extRoles) {
		List<UserAbsConflictMdl> confLst = new LinkedList<>();		
		AbsSodConflictRespDto respDto = new AbsSodConflictRespDto();
		try{
			List<RoleADGrpMdl> allIds = new ArrayList<>();
			List<StrKeyValPair> systemPosList = new ArrayList<>();			
			allIds.addAll(newRoles);
			allIds.addAll(extRoles);
			allIds.forEach(e ->{ //Added for removing duplicate System and Position combinations
				StrKeyValPair sysPosMdl = new StrKeyValPair(e.getSysId(), e.getPosId());				
				if(!systemPosList.contains(sysPosMdl)) {
					systemPosList.add(sysPosMdl);
				}
			});
			
			
			if(!systemPosList.isEmpty() && systemPosList.size() > 1) {								
				String query = buildQuery(systemPosList);				
				confLst = userUtilsDao.getAbsConflictsForPosVariants(query);
			}
			confLst.forEach(c -> c.setIsExisting("N"));
			confLst.forEach(c -> c.setIsExisting2("N"));
			
			confLst.forEach(cfLst -> {
				extRoles.forEach(exLst -> {
					if(cfLst.getApp1().equals(exLst.getSysId()) && cfLst.getPosv1().equals(exLst.getPosId())) {
						cfLst.setIsExisting("E");
					}else if(cfLst.getApp2().equals(exLst.getSysId()) && cfLst.getPosv2().equals(exLst.getPosId())) {
						cfLst.setIsExisting2("E");
					}
				});
			});
			
			respDto.setConfList(confLst);
			respDto.setStatusCode(0);
			respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setMessage("Conflict Size: "+confLst.size());
		} catch (Exception e) {
			respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc("Error Getting Conflict Info :"+e.getMessage());
			log.error("Error Getting Conflict Info :"+e.getMessage(), e);
		}
		return respDto;
	}


	private String buildQuery(List<StrKeyValPair> data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT RISKID, RISKDESC, APP1, APPNAME1, POSV1, POSVNAME1, APP2, APPNAME2, POSV2, POSVNAME2, CONFLICT, RISK_LEVEL, nvl(MIT_ID, 0) as MIT_ID, MIT_DESC, CREATEDON ");
		sql.append(" FROM SOD_DB_USER.ZUSER_CONFLICT_MATRIX ");
		if(data.size() == 2) {
			sql.append(" WHERE ( APP1 = "+data.get(0).getKey()+ " AND  POSV1 = "+data.get(0).getVal() +" AND APP2 = "+data.get(1).getKey() +" AND POSV2 = "+data.get(1).getVal()+") "
					+ " OR ( APP2 = "+data.get(0).getKey()+" AND POSV2 = "+data.get(0).getVal() +" AND APP1 = "+data.get(1).getKey() +" AND POSV1 = "+data.get(1).getVal()+") ");
		}else {
			sql.append(" WHERE (");
			for (int i = 0; i < data.size(); i++) {
				for (int j = i+1; j < data.size(); j++) {
					sql.append(" ( APP1 = "+data.get(i).getKey()+ " AND  POSV1 = "+data.get(i).getVal() +" AND APP2 = "+data.get(j).getKey() +" AND POSV2 = "+data.get(j).getVal()+") "
							+ "OR ( APP2 = "+data.get(i).getKey()+" AND POSV2 = "+data.get(i).getVal() +" AND APP1 = "+data.get(j).getKey() +" AND POSV1 = "+data.get(j).getVal()+") ");
					if(i < (data.size() - 2)) {
						sql.append(" OR ");
					}
				}
			}
			sql.append(" )");
		}

		sql.append(" ORDER BY APP1, APP2, POSV1, POSV2 ");
		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}

	/*private String buildQuery(List<RoleADGrpMdl> data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT RISKID, RISKDESC, APP1, APPNAME1, APP2, APPNAME2, POSV1, POSVNAME1, POSV2, POSVNAME2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_DB_USER.ZUSER_CONFLICT_MATRIX ");
		sql.append(" WHERE (");
		for (int i = 0; i < data.size(); i++) {
			for (int j = i+1; j < data.size(); j++) {
				//sql.append(" ( POSV1 = "+data.get(i).getPvId() +" AND POSV2 = "+data.get(j).getPvId()+") OR (POSV2 = "+data.get(i).getPvId() +" AND POSV1 = "+data.get(j).getPvId()+") ");
				sql.append(" ( APP1 = "+data.get(i).getSysId()+ " AND  POSV1 = "+data.get(i).getPvId() +" AND APP2 = "+data.get(j).getSysId() +" AND POSV2 = "+data.get(j).getPvId()+") OR ( APP2 = "+data.get(i).getSysId()+" AND POSV2 = "+data.get(i).getPvId() +" AND APP1 = "+data.get(j).getSysId() +" AND POSV1 = "+data.get(j).getPvId()+") ");
				if(i < (data.size() - 2)) {
					sql.append(" OR ");
				}
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, POSV1, POSV2 ");
		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}
*/

	@Override
	public List<AbsSysLeveExcsvRestrMdl> checkRestrtvExcessiveAccess(UserSearchModel assocUser, Map<String, List<RoleADGrpMdl>> exstRoles, Map<String, List<RoleADGrpMdl>> newRoles, Boolean isReport) throws Exception{
		List<AbsSysLeveExcsvRestrMdl> systemResExcsvList = new LinkedList<>();//System Level List of Objects to be Returned
		//Iterate and check for Each System
		for(Map.Entry<String, List<RoleADGrpMdl>> rlsEntry : newRoles.entrySet()) {
			if(rlsEntry.getValue() == null || rlsEntry.getValue().isEmpty()) {//Skip when NO ROLES
				continue;
			}
			AbsSysLeveExcsvRestrMdl sysModel = new AbsSysLeveExcsvRestrMdl(); //System Level Model
			sysModel.setUser(assocUser);
			sysModel.setUserid(assocUser.getWwId());
			sysModel.setSysid(rlsEntry.getKey());
			List<ZSystemMdl> dataList = masterDataDao.getAllZSystems(Integer.parseInt(rlsEntry.getKey()));//Get System Name/ID
			if(dataList != null && !dataList.isEmpty()) {
				sysModel.setSysName(dataList.get(0).getSysname());
			}

			//THRESHOLD LIMIT LOGIC STARTS HERE
			int excsvRestrtvPercentage = userMenuDao.getUtilsConstExcsvVals(Constants.SYS_EXCSV_REST_LIMIT+"_"+rlsEntry.getKey());	
			
			List<AbsSecExcesvRestrictedAccsMdl> sectorDataList = new ArrayList<>();//Sector Level List
			sysModel.setSectorDataList(sectorDataList);		
						
			//New Variants - PART1 : Key=SectorId-SectorName, value = listofRoles
			Map<String, List<RoleADGrpMdl>> newRolesSysDataMap = getSectorWiseSysPvData(rlsEntry.getValue(), rlsEntry.getKey());

			//Existing Variants - PART 2
			List<RoleADGrpMdl> existRoles = (exstRoles.containsKey(rlsEntry.getKey()) ? exstRoles.get(rlsEntry.getKey()) : new ArrayList<>());
			Map<String, List<RoleADGrpMdl>> existingRolesSysDataMap = (!existRoles.isEmpty())? getSectorWiseSysPvData(existRoles, rlsEntry.getKey()) : new HashMap<>() ;

			//Added Logic for only for Data HUB - New Logic
			 List<String> allAcsIdList = rlsEntry.getValue().stream()
					.map(r -> r.getAccId())
					.distinct()
					.filter(aid -> !aid.equals("3"))
					.collect(Collectors.toList());
			
			//Add distinct Positions to Query // yeswanth
			List<String> nposList = rlsEntry.getValue().stream()
				.map(r -> r.getPosId())
				.distinct()
				.collect(Collectors.toList());
			
			//constructing existing roles unique posIds
			List<String> uniquePosIds = new ArrayList<>();
			Set<String> seenPosIds = new HashSet<>();			
			existingRolesSysDataMap.values().forEach(roleList -> {
				roleList.forEach(role -> {
					String posId = role.getPosId();
					if (seenPosIds.add(posId)) {
						uniquePosIds.add(posId);
					}
				});
			});
			List<String> combinedPosIdsList = new ArrayList<>(uniquePosIds);
			combinedPosIdsList.addAll(nposList);
			
			//constructing existing roles unique acsIds and eliminating aid =3 reports.
			List<String> uniqueAcsIdLst = new ArrayList<>();
			for(Map.Entry<String, List<RoleADGrpMdl>> entry : existingRolesSysDataMap.entrySet()){
				List<String> accId = entry.getValue().stream()
				.map(r -> r.getAccId())
				.distinct()
				.filter(aid -> !aid.equals("3") )
				.collect(Collectors.toList());
				uniqueAcsIdLst.addAll(accId);
			}
			List<String> combinedAcsIdsList = new ArrayList<>(uniqueAcsIdLst);
			combinedAcsIdsList.addAll(allAcsIdList);
			

			log.debug("exisintroles unique posids :"+ uniquePosIds+" new roles unique posids :"+nposList);
			log.debug("exisintroles unique acsIds :"+ uniqueAcsIdLst+" new roles unique acsIds :"+allAcsIdList);
			//Getting all the Position Variants Sectorwise	-PART3 // yeswanth commented
			Map<String, List<RoleADGrpMdl>> allRolesSysDataMap = getAllSysVariantsSectoryWise(rlsEntry.getKey(), combinedPosIdsList, combinedAcsIdsList);
			
			//Map<String, List<RoleADGrpMdl>> allRolesSysDataMap = getAllPosSysVariantsSectoryWise(rlsEntry.getKey(), allPosnList);
			
			//Calculating the Percentage
			List<RoleADGrpMdl> userSelectedRestrictedDataLst = new ArrayList<>();
			List<RoleADGrpMdl> userSelectedNonRestrictedDataLst = new ArrayList<>();
			sysModel.setSelVarsNonRestricted(userSelectedNonRestrictedDataLst);
			sysModel.setSelVarsRestricted(userSelectedRestrictedDataLst);

			for(Map.Entry<String, List<RoleADGrpMdl>> secRoles : newRolesSysDataMap.entrySet()) {//Sectorwise Calcualtions and Data Collection
				String secKey = secRoles.getKey();
				AbsSecExcesvRestrictedAccsMdl secRestExcMdl = new AbsSecExcesvRestrictedAccsMdl();
				secRestExcMdl.setIsExcsv("N");
				secRestExcMdl.setIsRestricted("N");
				secRestExcMdl.setSysid(rlsEntry.getKey());
				secRestExcMdl.setSysName(sysModel.getSysName());
				secRestExcMdl.setLimit(excsvRestrtvPercentage);
				secRestExcMdl.setSecId(secKey.split("-")[0]);
				secRestExcMdl.setSecName(secKey.split("-")[1]);

				if(secKey.contains("RESTRICTED")) {
					userSelectedRestrictedDataLst.addAll(secRoles.getValue());
					secRestExcMdl.setIsRestricted("Y");
				}else {
					List<RoleADGrpMdl> totalVarLst = new ArrayList<>(); //Total Variants for Sector
					List<RoleADGrpMdl> secNewDataLst = secRoles.getValue();
					List<RoleADGrpMdl> secExtDataLst = existingRolesSysDataMap.containsKey(secKey) ? existingRolesSysDataMap.get(secKey) : new ArrayList<>();					
					log.debug("existing roles list :"+secExtDataLst);
					log.debug("newroles before removal of duplicates size :"+secNewDataLst.size()+"  : list is :"+secNewDataLst);					
					// remove duplicates from new roles 
					List<RoleADGrpMdl> removedDupExistList = secNewDataLst.stream()
							.filter(newroles -> !secExtDataLst.stream()
										.anyMatch(extroles -> extroles.getPvId().equals(newroles.getPvId())))
										.collect(Collectors.toList());
					log.debug("newroles after removal of duplicates size :"+removedDupExistList.size()+"  : list is :"+removedDupExistList);
					//remove RUs from existing roles
					List<RoleADGrpMdl> remRUExistingRoles = secExtDataLst.stream().filter(e -> e.getPvName().startsWith("CU")).collect(Collectors.toList());
					List<RoleADGrpMdl> removeRUNewRoles = removedDupExistList.stream().filter(e -> e.getPvName().startsWith("CU")).collect(Collectors.toList());
					
					totalVarLst.addAll(removeRUNewRoles);
					//totalVarLst.addAll(removedDupExistList);
					//totalVarLst.addAll(secNewDataLst);
					//totalVarLst.addAll(secExtDataLst);
					totalVarLst.addAll(remRUExistingRoles);
					//yeswanth commented to remove duplicates on pvnames instead of pvid
					/*List<String> distinctVariants = totalVarLst.stream()
							.map(r -> r.getPvId())
							.distinct()
							.collect(Collectors.toList());
					*/										
					List<String> distinctVariants = totalVarLst.stream()							
							.map(r -> r.getPvName().toUpperCase())
							.distinct()
							.collect(Collectors.toList());
					//Yeswanth Added to find the posId of the existing and new roles
					List<String> posIdsList = totalVarLst.stream()
															.map(p -> p.getPosId())
															.distinct()
															.collect(Collectors.toList());
					

					List<RoleADGrpMdl> secLvlAllVars = allRolesSysDataMap.containsKey(secKey) ? allRolesSysDataMap.get(secKey) : new ArrayList<>();
					log.debug("All sec total sum : secLvlAllVars : "+secLvlAllVars);	
					List<RoleADGrpMdl> matchingRoles = secLvlAllVars.stream()
			                .filter(role -> posIdsList.contains(role.getPosId()))
			                .collect(Collectors.toList());
					log.debug("All sec total after filter : secLvlAllVars : "+matchingRoles);
					List<String> matchingRole= matchingRoles.stream().map(e -> e.getPvName()).collect(Collectors.toList());
					log.debug("------------. matchingRole : list :"+matchingRole);;
					//Added new logic to take distinct variants sectorwise					
					/*List<String> secWisedistinctVariants = secLvlAllVars.stream()
															.map(r -> r.getPvId())
															.distinct()
															.collect(Collectors.toList()); */
			        /* commented as part of filtering RU
					List<String> secWisedistinctVariants = matchingRoles.stream()
															.map(r -> r.getPvName())
															.distinct()
															.collect(Collectors.toList());
														*/
					//matchingRoles
			        List<String> secWisedistinctVariants = matchingRoles.stream()
			        	    .map(r -> r.getPvName().toUpperCase())
			        	    .filter(pvName -> pvName.startsWith("CU"))
			        	    .distinct()
			        	    .collect(Collectors.toList());		
					
					
					double reqVarCount = distinctVariants.size();
					double allVarCount = secWisedistinctVariants.size();//Added new logic
					double expercntg =(reqVarCount/allVarCount)*100;
					if(isReport) {
						userSelectedNonRestrictedDataLst.addAll(secRoles.getValue());
						secRestExcMdl.setExcsvPrcntg(expercntg);
						secRestExcMdl.setIsExcsv("Y");
					}
					else {
						if(expercntg >= excsvRestrtvPercentage){
							userSelectedNonRestrictedDataLst.addAll(secRoles.getValue());
							secRestExcMdl.setExcsvPrcntg(expercntg);
							secRestExcMdl.setIsExcsv("Y");
						}
					}
				}

				if("Y".equals(secRestExcMdl.getIsExcsv()) || "Y".equals(secRestExcMdl.getIsRestricted())) {
					sectorDataList.add(secRestExcMdl);
				}
			}
			//Added logic to cal %age for existing sec roles
			/*for (Map.Entry<String, List<RoleADGrpMdl>> secRoles : existingRolesSysDataMap.entrySet()) {
				String secKey = secRoles.getKey();
				if (secKey.contains("RESTRICTED") && secKey.equals("0-RESTRICTED")) {
			        continue; 
			    }
				if (!newRolesSysDataMap.containsKey(secKey)) {
					AbsSecExcesvRestrictedAccsMdl secRestExcMdl = new AbsSecExcesvRestrictedAccsMdl();
			        secRestExcMdl.setIsExcsv("N");
			        secRestExcMdl.setIsRestricted("N");
			        secRestExcMdl.setSysid(rlsEntry.getKey());
			        secRestExcMdl.setSysName(sysModel.getSysName());
			        secRestExcMdl.setLimit(excsvRestrtvPercentage);
			        secRestExcMdl.setSecId(secKey.split("-")[0]);
			        secRestExcMdl.setSecName(secKey.split("-")[1]);
			        List<RoleADGrpMdl> totalVarLst = new ArrayList<>(); //Total Variants for Sector
					//List<RoleADGrpMdl> secNewDataLst = secRoles.getValue();
					List<RoleADGrpMdl> secExtDataLst = existingRolesSysDataMap.containsKey(secKey) ? existingRolesSysDataMap.get(secKey) : new ArrayList<>();					
								
					totalVarLst.addAll(secExtDataLst);	
					
					List<String> distinctVariants = totalVarLst.stream()
							.map(r -> r.getPvName())
							.distinct()
							.collect(Collectors.toList());
					
					List<String> posIdsList = totalVarLst.stream()
							.map(p -> p.getPosId())
							.distinct()
							.collect(Collectors.toList());
					

					List<RoleADGrpMdl> secLvlAllVars = allRolesSysDataMap.containsKey(secKey) ? allRolesSysDataMap.get(secKey) : new ArrayList<>();
					log.debug("All sec total sum : secLvlAllVars : "+secLvlAllVars);	
					List<RoleADGrpMdl> matchingRoles = secLvlAllVars.stream()
			                .filter(role -> posIdsList.contains(role.getPosId()))
			                .collect(Collectors.toList());
							
			        List<String> secWisedistinctVariants = matchingRoles.stream()
			        	    .map(r -> r.getPvName().toUpperCase())
			        	    .filter(pvName -> pvName.startsWith("CU"))
			        	    .distinct()
			        	    .collect(Collectors.toList());	
			        
					double reqVarCount = distinctVariants.size();
					double allVarCount = secWisedistinctVariants.size();//Added new logic
					double expercntg =(reqVarCount/allVarCount)*100;
					if(expercntg >= excsvRestrtvPercentage){
						userSelectedNonRestrictedDataLst.addAll(secRoles.getValue());
						secRestExcMdl.setExcsvPrcntg(expercntg);
						secRestExcMdl.setIsExcsv("Y");
					}
					sectorDataList.add(secRestExcMdl);
				}				
			} */
			
			if((sectorDataList != null && !sectorDataList.isEmpty()) || (userSelectedRestrictedDataLst != null && !userSelectedRestrictedDataLst.isEmpty())) {
				systemResExcsvList.add(sysModel);
			}
		}
		return systemResExcsvList;
	}
	//New Mothod for All Variants --Not USING
	/*public Map<String, List<RoleADGrpMdl>> getAllPosSysVariantsSectoryWise(String sysId, List<String> posList) {
		Map<String, List<RoleADGrpMdl>> dataMap = new HashMap<String, List<RoleADGrpMdl>>();
		try {
			//List<RoleADGrpMdl> dataLst = userUtilsDao.getAllSectorWiseSysPvData(sysId);
			List<RoleADGrpMdl> dataLst = userUtilsDao.getAllSectorWiseSysPosPvData(sysId, posList.toArray(new String[posList.size()]));

			if(dataLst != null && !dataLst.isEmpty()) {
				dataMap = fileterSectorWiseSysPvData(dataLst);
			}
		} catch (Exception e) {
			log.error("Error getting Sertorwise Role Details for system:"+sysId+" "+e.getMessage(), e);
		}
		return dataMap;
	}*/

	//OLD Method for All Variants - Currently in USE
	//public Map<String, List<RoleADGrpMdl>> getAllSysVariantsSectoryWise(String sysId, List<String> posIdLst, List<String> acsIdlst) {
	public Map<String, List<RoleADGrpMdl>> getAllSysVariantsSectoryWise(String sysId, List<String> posIdLst, List<String> acsIdlst) {
		Map<String, List<RoleADGrpMdl>> dataMap = new HashMap<>();
		try {
			String[] acsIds =(acsIdlst.size() > 0 && !acsIdlst.get(0).isEmpty())? acsIdlst.toArray(new String[acsIdlst.size()]) : null;
			String[] posIds =(posIdLst.size() > 0 && !posIdLst.get(0).isEmpty())? posIdLst.toArray(new String[posIdLst.size()]) : null;
			//List<RoleADGrpMdl> dataLst = userUtilsDao.getAllSectorWiseSysPvData(sysId, acsIds);
			List<RoleADGrpMdl> dataLst = userUtilsDao.getAllSectorWiseSysPosPvData(sysId, posIds, acsIds);
			if(("2".equals(sysId)) || ("6".equals(sysId))) {
				List<RoleADGrpMdl> dataList1 = dataLst.stream()
									.filter(item -> ("2".equals(item.getAccId()) && "Yes".equals(item.getIsRestricted())) || !"2".equals(item.getAccId()))
									.collect(Collectors.toList());
				if(dataList1 != null && !dataList1.isEmpty()) {
					dataMap = fileterSectorWiseSysPvData(dataList1);
				}
			}else {
				if(dataLst != null && !dataLst.isEmpty()) {
					dataMap = fileterSectorWiseSysPvData(dataLst);					
				}
			}
			
		} catch (Exception e) {
			log.error("Error getting Sertorwise Role Details for system:"+sysId+" "+e.getMessage(), e);
		}
		return dataMap;
	}

	@Override
	public  Map<String, List<RoleADGrpMdl>> getSectorWiseSysPvData(List<RoleADGrpMdl> selectedAdgrps, String sysId) {
		Map<String, List<RoleADGrpMdl>> dataMap = new HashMap<>();
		try {
			//All Distinct PV's
			List<String> npvList = selectedAdgrps.stream()
				.map(r -> r.getPvId())
				.distinct()
				.collect(Collectors.toList());
			log.debug("getSectorWiseSysPvData npvList :"+npvList);

			//Add distinct Positions to Query
			List<String> nposList = selectedAdgrps.stream()
				.map(r -> r.getPosId())
				.distinct()
				.collect(Collectors.toList());
			log.debug("getSectorWiseSysPvData nposList :"+nposList);
			//Added for Data HUB
			String[] acsIds = null;
			if(("2".equals(sysId)) || ("6".equals(sysId))) {
				log.debug("getSectorWiseSysPvData  enter into the block : ");
				log.debug("getSectorWiseSysPvData  sysId : "+sysId);
				List<String> ascList = selectedAdgrps.stream()
				.map(r -> r.getAccId())
				.distinct()
				.filter(acs -> !acs.equals("3"))
				//.filter(acs -> !acs.equals("2"))
				.collect(Collectors.toList());
				log.debug("getSectorWiseSysPvData  end of the block : ");
				log.debug("getSectorWiseSysPvData  ascList : "+ascList);
				acsIds = (ascList.size() > 0 && !ascList.get(0).isEmpty())? ascList.toArray(new String[ascList.size()]) : null;
			}
			
			String[] npvArray = npvList.toArray(new String[npvList.size()]);
			String[] nposArray = nposList.toArray(new String[nposList.size()]);
			int batchSize = 500;
			 List<RoleADGrpMdl> dataList = new ArrayList<>();	
			for (int i = 0; i < npvArray.length; i += batchSize) {
				int start = i;
			    int end = Math.min(i + batchSize, npvArray.length);
			    String[] subPvIds = Arrays.copyOfRange(npvArray, start, end);
			    List<RoleADGrpMdl> subDataList = userUtilsDao.getSectorWiseSysPvsData(subPvIds, nposArray, acsIds, sysId);
		        dataList.addAll(subDataList);
			}	
			//List<RoleADGrpMdl> dataList = userUtilsDao.getSectorWiseSysPvsData(npvList.toArray(new String[npvList.size()]), nposList.toArray(new String[nposList.size()]), acsIds, sysId);
			//filter acid =2 and is restricted = No from the dataList if the system is datahub or sac
			if(("2".equals(sysId)) || ("6".equals(sysId))) {
				List<RoleADGrpMdl> dataList1 = dataList.stream()
									.filter(item -> ("2".equals(item.getAccId()) && "Yes".equals(item.getIsRestricted())) || !"2".equals(item.getAccId()))
									.collect(Collectors.toList());
				if(dataList1 != null && !dataList1.isEmpty()) {
					dataMap = fileterSectorWiseSysPvData(dataList1);
				}
			}else {
				if(dataList != null && !dataList.isEmpty()) {
					dataMap = fileterSectorWiseSysPvData(dataList);
				}
			}
			
		} catch (DataAccessException | SQLException e) {
			log.error("Error getting restricted Variant count: "+e.getMessage(), e);
		}
		return dataMap;
	}

	private  Map<String, List<RoleADGrpMdl>> fileterSectorWiseSysPvData(List<RoleADGrpMdl> dataList) {
		Map<String, List<RoleADGrpMdl>> dataMap = new HashMap<>();
		if(dataList != null && !dataList.isEmpty()) {
			dataList.forEach(r ->{
				List<RoleADGrpMdl> gdLst = null;
				if(r.getIsRestricted().equalsIgnoreCase("Yes")) {
					String sec ="0-RESTRICTED";
					if(dataMap.containsKey(sec)) {
						 gdLst = dataMap.get(sec);
					}else {
						gdLst = new ArrayList<>();
					}
					gdLst.add(r);
					dataMap.put(sec, gdLst);
				}else {
					String sec = r.getSecId()+"-"+r.getSecName();
					if(dataMap.containsKey(sec)) {
						 gdLst = dataMap.get(sec);
					}else {
						gdLst = new ArrayList<>();
					}
					gdLst.add(r);
					dataMap.put(sec, gdLst);
				}
			});
		}
		return dataMap;
	}



	@Override
	public List<AbsExcesvAccsMdl> checkExcessiveAccess(UserSearchModel assocUser, Map<String, List<RoleADGrpMdl>> exstRoles, Map<String, List<RoleADGrpMdl>> newRoles) throws Exception{
		List<AbsExcesvAccsMdl> excsvLst = new ArrayList<>();

		for(Map.Entry<String, List<RoleADGrpMdl>> rlsEntry : newRoles.entrySet()) {
			AbsExcesvAccsMdl sysExcMdl = new AbsExcesvAccsMdl();
			sysExcMdl.setIsExcsv("N");
			sysExcMdl.setUser(assocUser);
			sysExcMdl.setSysid(rlsEntry.getKey());
				//Selected Variants
			List<String> selPv = new ArrayList<>();
			rlsEntry.getValue().stream()
				.forEach(r -> selPv.add(r.getPvId()+"~"+r.getPvName()));
				sysExcMdl.setSelVariants(selPv);

			//Existing Variants
			List<RoleADGrpMdl> existRoles = (exstRoles.containsKey(rlsEntry.getKey()) ? exstRoles.get(rlsEntry.getKey()) : new ArrayList<>() );
			List<String> extPv = new ArrayList<>();
			existRoles.stream()
			//.filter(rl -> rl.getSysId().equals(rlsEntry.getKey()))
			.forEach(r -> extPv.add(r.getPvId()+"~"+r.getPvName()));
			sysExcMdl.setExVariants(extPv);

			List<String> allSysVarLst = userUtilsDao.getAllSystemPosVarIds(rlsEntry.getKey());
			sysExcMdl.setAllAvailableVars(allSysVarLst);

			int excsvRestrtvPercentage = userMenuDao.getUtilsConstExcsvVals(Constants.SYS_EXCSV_REST_LIMIT+"_"+rlsEntry.getKey());

			sysExcMdl.setLimit(excsvRestrtvPercentage);
			List<String> reqVariants = new ArrayList<>();
			reqVariants.addAll(sysExcMdl.getSelVariants());
			reqVariants.addAll(sysExcMdl.getExVariants());
			List<String> distinctVars = reqVariants.stream()
					.distinct()
					.collect(Collectors.toList());

			double reqVarCount = distinctVars.size();
			double allVarCount = allSysVarLst.size();
			double expercntg =(reqVarCount/allVarCount)*100;
			if(expercntg >= excsvRestrtvPercentage){
				sysExcMdl.setExcsvPrcntg(expercntg);
				sysExcMdl.setIsExcsv("Y");
				excsvLst.add(sysExcMdl);
			}

		}
		return excsvLst;
	}



	@Override
	public List<EmailItem> loadAllEmailDimensionsFromAnaPlan() {
    	log.info("Read/Download individuals Export Definitions");
    	 long start = System.currentTimeMillis();
    	 List<EmailItem> dataList = new LinkedList<>();
    	 try{
    		 start = System.currentTimeMillis();
    		 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
    		 log.info("<<<<<<<<<<  Total time taken for AnaPlan Authentication : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    		 log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 HttpHeaders headers = Utility.getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 Gson gson = new Gson();
    		 HttpEntity<String> reqEntity = new HttpEntity<>(headers);
    		 //Get VIEW ID for AnaPlan : Employee Email
    		//ResponseEntity<String> respEntity = restHttpTemplate.exchange("https://api.anaplan.com/2/0/models/EB35B4594A2945FD9D9C547DD8CFB44D/views/1037000000000", HttpMethod.GET, reqEntity, String.class);
    		 String anaplanViewUri = userMenuDao.getUtilsConstVals("ANAPLAN_VIEW_URI");
    		 log.info("AnaPlan View Uri : "+anaplanViewUri);
    		 ResponseEntity<String> respEntity = restHttpTemplate.exchange(anaplanViewUri, HttpMethod.GET, reqEntity, String.class);
    		 log.info("<<<<<<<<<<  Total time taken for AnaPlan Authentication + View Data : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
    			 AnaplanEmailDimensionModel respBody = gson.fromJson(respEntity.getBody(), AnaplanEmailDimensionModel.class);
    			 if(null != respBody && null != respBody.getPages() && !respBody.getPages().isEmpty() ) {
    				 String pageId = respBody.getPages().stream()
    						 			.filter(p -> p.getName().equalsIgnoreCase("Employee Email"))
    						 				.findFirst()
    						 					.get().getId();
    				 log.info("Resp Body PAGE ID/Dimension ID: "+pageId);

    				 if(!Utility.isEmpty(pageId)) {
    					 Utility.setAnaPlanPageId(pageId);
    					 long vstart = System.currentTimeMillis();
    					 //Get EMAIL Dimension ID's for All Users in AnaPlan
    					 String anaplanDimUri = userMenuDao.getUtilsConstVals("ANAPLAN_DIMENSION_URI");
    					 log.info("AnaPlan Dimension Uri : "+anaplanDimUri+"/"+pageId+"/items");
    					 ResponseEntity<String> dimItemsResp = restHttpTemplate.exchange(anaplanDimUri+"/"+pageId+"/items", HttpMethod.GET, reqEntity, String.class);
    					 log.info("<<<<<<<<<<  Total time taken for AnaPlan to Get All View Dimensions Data : "+((System.currentTimeMillis() - vstart)/1000)+ " seconds >>>>>>>>>>");
    					 if (dimItemsResp != null && dimItemsResp.getStatusCode() == HttpStatus.OK) {
    		    			 //log.info("Dimensions Body: "+dimItemsResp.getBody());
    		    			 DBDataAnaplanEmailDimensionModel dbDimModel = gson.fromJson(dimItemsResp.getBody(), DBDataAnaplanEmailDimensionModel.class);
    		    			 if(dbDimModel != null && null != dbDimModel.getItems() && !dbDimModel.getItems().isEmpty()) {
    		    				 log.info("Total Number of Email Records Read :"+dbDimModel.getItems().size());
    		    				 dataList = dbDimModel.getItems();
    		    				 vstart = System.currentTimeMillis();
    		    				 //INSERT DATA TO DATABASE
    		    				 int recordsInserted = userUtilsDao.insertDimensionsData(dataList);
    		    				 log.info("<<<<<<<<<<  Total time taken to Insert "+recordsInserted+" AnaPlan View Dimensions to Database : "+((System.currentTimeMillis() - vstart)/1000)+ " seconds >>>>>>>>>>");
    		    			 }
    					 }
    				 }
    			 }
    		 }
    		 log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    	} catch (Exception e) {
			log.error("Exception getting Exp Def:"+e.getMessage(), e);
		}
    	 return dataList;
	}


	//@Override
	public List<IAMRolesADGrpMdl> getAnaPlanUserDataByEmail(UserSearchModel assocUser) {
    	log.info("Reading Individual Export Data for Email : "+assocUser.getJnjEmailAddrTxt());
    	 long start = System.currentTimeMillis();
    	 List<IAMRolesADGrpMdl> dataList = new ArrayList<>();
    	 try{
    		 start = System.currentTimeMillis();
    		 String dimId  = userUtilsDao.getDimensionIdForUserEmail(assocUser.getJnjEmailAddrTxt().toUpperCase().trim());
    		 String pageId = Utility.getAnaPlanPageId();
    		 if(!Utility.isEmpty(dimId) && !Utility.isEmpty(pageId)) {
    			 start = System.currentTimeMillis();
    			 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
        		 log.info("<<<<<<<<<<  Total time taken for AnaPlan Authentication : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
        		 log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
        		 HttpHeaders headers = Utility.getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
        		 Gson gson = new Gson();
        		 HttpEntity<String> reqEntity = new HttpEntity<>(headers);
        		 //Get Data for Current User
        		 //https://api.anaplan.com/2/0/models/EB35B4594A2945FD9D9C547DD8CFB44D/views/1037000000000/data?pages=101000000044:290000014048&format=v1
        		 String anaplanViewUri = userMenuDao.getUtilsConstVals("ANAPLAN_VIEW_URI");
        		 log.info("AnaPlan User Data URI :"+anaplanViewUri+"/data?pages="+pageId+":"+dimId+"&format=v1");
        		 ResponseEntity<String> respEntity = restHttpTemplate.exchange(anaplanViewUri+"/data?pages="+pageId+":"+dimId+"&format=v1", HttpMethod.GET, reqEntity, String.class);
        		 log.info("<<<<<<<<<<  Total time taken for AnaPlan Authentication and View Data : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
        		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
        			 //log.info("Resp Body: "+respEntity.getBody());
        			 ////
        			 BufferedReader br = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(respEntity.getBody().getBytes())));
        			 IAMRolesADGrpMdl csmMdl = null;
        			 String dline = "";
        			 int totalCount = 0;
        			 while ((dline = br.readLine()) != null) {
        				 String[] usrData = dline.split(",");
        				 log.debug("Anaplan ressponse as ----------------> :"+Arrays.toString(usrData));
        				 if(totalCount <= 1) {//IGNORE HEADER ROW
        					 totalCount++;
        					 continue;
        				 }
        				 totalCount++;
        				 if(usrData != null && usrData.length >= 7 ) {
        					 csmMdl = new IAMRolesADGrpMdl();
        					 csmMdl.setUser(assocUser.getWwId());
        					 csmMdl.setClient("4");
        					 csmMdl.setLdapADGroup(usrData[1].trim().toUpperCase());
        					 csmMdl.setMdate(usrData[9].trim());
        					 csmMdl.setStopdate(usrData[10].trim());
        					 /*csmMdl.setUserId(assocUser.getWwId());
        					 csmMdl.setFName(assocUser.getGivenNm());
        					 csmMdl.setLName(assocUser.getFmlyNm());
        					 csmMdl.setEmailId(assocUser.getJnjEmailAddrTxt());
        					 csmMdl.setAdgroup(usrData[1].trim());
        					 csmMdl.setEmpStatus(assocUser.getEmpStatTxt());
        					 csmMdl.setModelname(usrData[3]);
        					 String modDate = usrData[4].trim();
        					 String vldFrm  = usrData[5].trim();
        					 String vldTo   = usrData[6].trim();
        					 csmMdl.setModDate(Utility.frmStrToDt(modDate));
        					 csmMdl.setVldFrom(Utility.frmStrToDt(vldFrm));
        					 csmMdl.setVldTo(Utility.frmStrToDt(vldTo));*/
							//csmMdl.setVldTo(Utility.ldapStrToDtUTCEST(vldTo));
        					 dataList.add(csmMdl);
 	 					}
 	 				}
 	 			 }
        		 log.info("<<<<<<<<<<  Total User Records collected : "+dataList.size()+" in :"+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
        	 }
    	} catch (Exception e) {
			log.error("Exception getting Exp Def:"+e.getMessage(), e);
		}
    	 return dataList;
	}










}