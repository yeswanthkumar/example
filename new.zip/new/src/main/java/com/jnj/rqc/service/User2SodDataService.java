package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.CSIUser2SodReportModel;
import com.jnj.rqc.conflictModel.JDEUser2SodReportModel;
import com.jnj.rqc.conflictModel.MercuryUser2SodReportModel;
import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.StrKeyValPair;



/**
 * File    : <b>User2SodDataService.java</b>
 * @author : DChauras @Created : Dec 8, 2021 11:00:15 AM
 * Purpose : Methods for processing USER TO SOD DATA
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface User2SodDataService {
	public TableRespDto getEnvData(String propName);
	public Map<String, List<SapUser2SodModel>> prepareUser2SodData(String templSysParam);
	public List<CSIUser2SodReportModel> readCSIReportExcel(String path);
	public List<SapPlatformReviwerMdl> loadPlatformReviewers(String path);
	public List<StrKeyValPair> loadMercuryPlatformReviewers(String path);
	public String writeSapUser2SodExcel(List<SapUser2SodModel> data, String fileName);
	public Map<String, SapMitiCntrlModel> loadSapMitiCntrlMap();
	public List<SapMitiCntrlModel> readMitigatingCntrlExcel(String qPath);
	public String writeMitiCntrlExcel(List<SapMitiCntrlModel> data, String fileName);
	public Map<String, SapPlatformReviwerMdl> loadDBReviewersData(int reload);
	public int saveReviewersData(List<SapPlatformReviwerMdl> revrData);
	public int saveMercuryReviewersData(List<StrKeyValPair> revrData);
	public String writeReviewerExcel(List<SapPlatformReviwerMdl> data, String fileName);
	public String writeMerReviewerExcel(List<StrKeyValPair> data, String fileName);
	public int insertUser2SodTransactions(List<SapUser2SodModel> user2SodData, String sysTemp, String createdUser);
	public List<JDEUser2SodReportModel> readJDEReportExcel(String path);
	public List<MercuryUser2SodReportModel> readCSIMercuryReportExcel(String path);
	public Map<String, String> loadMercuryDBReviewersData(int reload);

}
