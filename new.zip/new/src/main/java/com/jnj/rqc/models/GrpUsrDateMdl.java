package com.jnj.rqc.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GrpUsrDateMdl {
	String userId;
	String fName;
	String lName;
	String wwid;
	String emailId;
	String empStatus;
	String adgroup;
	String modelname;
	Date   modDate;
	Date   vldFrom;
	Date   vldTo;
	String addRemove;
	String isNew;
}
