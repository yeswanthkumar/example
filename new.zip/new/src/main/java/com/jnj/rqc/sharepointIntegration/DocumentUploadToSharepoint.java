package com.jnj.rqc.sharepointIntegration;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class DocumentUploadToSharepoint {
	
	@Autowired
	private Authentication authentication;
	
	static final Logger log = LoggerFactory.getLogger(DocumentUploadToSharepoint.class);
	
	public boolean excelDocumentUpload(SXSSFWorkbook workbook, String folderName, String fileName) throws IOException, UnrecoverableKeyException, CertificateException, NoSuchAlgorithmException, KeyStoreException, NoSuchProviderException{
		boolean retValue = false;
		  String siteURL = "https://jnj.sharepoint.com/teams/EDALProject";
		  String wsUrl = siteURL + "/_api/web/GetFolderByServerRelativeUrl('EDAL%20Reports/Compliance%20Reports/"+folderName+"')/Files/add(url='"+fileName+"',overwrite=true)";
		  
		  URL url = new URL(wsUrl);
		  URLConnection connection = url.openConnection();
		  HttpURLConnection httpConn = (HttpURLConnection) connection;
		  
		  httpConn.setDoOutput(true);
		  httpConn.setDoInput(true);	
		  httpConn.setRequestMethod("POST");				
		  httpConn.setRequestProperty("Authorization", "Bearer " + getAccessToken());
          
          ByteArrayOutputStream bos = new ByteArrayOutputStream();
          try {
              workbook.write(bos);
              workbook.close();
          } finally {
              bos.close();
          }
          
		  DataOutputStream wr = new DataOutputStream(httpConn.getOutputStream ());
		  wr.write(bos.toByteArray());
		  wr.flush();
		  wr.close();
						
		  //Read the response.
		  String responseStr = "";
		  if (httpConn.getResponseCode() == 200) {
		    responseStr = "File has been written successfully. ResponseCode: "+ httpConn.getResponseCode();
		    retValue = true;
		  }else{
		    responseStr += "Error while writing file, ResponseCode: " + httpConn.getResponseCode() + " " + httpConn.getResponseMessage();
		    retValue = false;
		  }	
		  
		  System.out.println(responseStr);	//Print response
		  log.debug("FOLDER CREATION");
		  log.debug(responseStr);
		  return retValue;
	}
	
	public boolean folderCreation(String folderName) throws IOException{
		boolean retValue = false;
		String siteURL = "https://jnj.sharepoint.com/teams/EDALProject";
		String wsURL = siteURL + "/_api/web/folders";
        URL url = new URL(wsURL);
        URLConnection connection = url.openConnection();
        String[] arr = siteURL.split("com");
        String siteNameURL = arr[arr.length-1];
        String jsonInputString = "{'__metadata': { 'type': 'SP.Folder' }, 'ServerRelativeUrl': '"+ siteNameURL +"/EDAL%20Reports/Compliance%20Reports/"+ folderName + "'}";
        HttpURLConnection httpConn = (HttpURLConnection) connection;
        try {
            // Set header
            httpConn.setRequestProperty("Content-Type", "application/json;odata=verbose");
            httpConn.setRequestProperty("Accept", "application/json;odata=verbose");
            httpConn.setRequestProperty("Authorization", "Bearer " + getAccessToken());
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            httpConn.setRequestMethod("POST");
            httpConn.setRequestProperty("X-RequestDigest", "SHAREPOINT_FORM_DIGEST");
            httpConn.setRequestProperty("Content-Length", Integer.toString(jsonInputString.getBytes("utf-8").length));
            DataOutputStream wr = new DataOutputStream(httpConn.getOutputStream());

            byte[] input = jsonInputString.getBytes("utf-8");
            wr.write(input, 0, input.length);

            String responseStr = "";
            if (httpConn.getResponseCode() == 201) {
                responseStr = "Folder has been created successfully. ResponseCode: " + httpConn.getResponseCode();
                retValue = true;
            } else {
                responseStr += "Error while creating folder, ResponseCode: " + httpConn.getResponseCode() + " "
                        + httpConn.getResponseMessage();
                retValue = false;
            }
            System.out.println(responseStr);
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
        return retValue;
	}
	
	public String getAccessToken() throws UnrecoverableKeyException, CertificateException, NoSuchAlgorithmException, KeyStoreException, NoSuchProviderException, IOException {
		String accessToken = "";
		accessToken = authentication.oauthAuthentication();
		return accessToken;
	}

}
