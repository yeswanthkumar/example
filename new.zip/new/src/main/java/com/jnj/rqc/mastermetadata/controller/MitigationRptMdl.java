package com.jnj.rqc.mastermetadata.controller;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MitigationRptMdl {
	private Long userId;
	private String userName;
	private String userEmail;
	private String riskdesc;
    private Long reqId;
    private String requestedBy;
    private String req_status;
    private String status_name;
    private String mitId;
    private String mitDesc;
    private String acceptDeny;
    private String comments;

}
