package com.jnj.rqc.common.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemCodeModel implements Serializable, Comparable<SystemCodeModel> {
	private static final long serialVersionUID = 1L;

	private String srcSystem;
	private String accessRole;
	private String sodCode;

	@Override
	public String toString() {
		return "SystemCodeModel [srcSystem=" + srcSystem + ", accessRole=" + accessRole + ", sodCode=" + sodCode + "]";
	}

	public String getData() {
		return srcSystem + "~" + accessRole + "~" + sodCode ;
	}

	/*@Override
	public int compareTo(SystemCodeModel o) {
		return this.getSodCode().compareTo( o.getSodCode());
	}
	*/

	@Override
	public int compareTo(SystemCodeModel o) {
		return this.getAccessRole().compareTo( o.getAccessRole());
	}
}
