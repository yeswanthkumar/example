package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;


/**
 * File    : <b>BelmontJDAConflictService.java</b>
 * @author : DChauras @Created : Feb 17, 2021 4:07:41 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface BelmontJDAConflictService {
	public List<MatrixModel> getCurConflictDetails(String empWwid, String[] data);
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data);
	public List<JDACrossAppMatrixModel> getCrossAppConflictDetails(String empWwid, List<String> data);
	public Map<String, List<String>> getUserExistingRoles(String empWwid, int system);
	public Map<String, List<String>> getUserRolesData(String empWwid, int system);
	public List<JDAPersonalSysMdl> buildCurrentRolesData(HttpSession session, Map<String, List<String>> currentRoleMap, UserSearchModel userData);
	public Map<String, JDADBRiskModel> getJDADBRiskData(String riskIdFilter);
	public List<JDADBRiskModel> getUserLeverConflictsJDA(Map<String, List<String>> currentRoles);
	public Map<String, List<String>> getMapForNewRoles(String data, int system);
	public List<JDADBRiskModel> getConflictMatrix();
	public List<JDACrossAppMatrixModel> getCrossAppConflictMatrix();
	public List<StrKeyValPair> getTechRoleNames();
	public Map<String, JDACrossAppMatrixModel> loadJDACrossAppMatrix(String riskIdFilter);
	public Map<String, List<StrKeyValPair>> loadJDATechNames();
	public String getRoleUFNamesToTechNames(String ufName);
	public List<String>getRolesFromPersonalSystem(String idToUse);
	public List<String>convertTechToUserFriendly(List<String> techNames);
	public List<JDAUser2SodModel> convertToJDAUser2SodModel(List<JDADBRiskModel> user2SodInternalNewRoles, UserSearchModel user) ;

	//CSV
	public String writeUserRoleCSVReport(String fileNm, List<JDAPersonalSysMdl> userRoles);
	public String writeConfCSVReport(String fileNm, List<JDAUser2SodModel> roleConflictList);
	public String writeCrossAppConfCSVReport(String fileNm, List<JDACrossAppMatrixModel> roleConflictList);
	public String writeConflictMatrixCSVReport(String fileNm, List<JDADBRiskModel> matrixList);
	public String writeCrossAppMatrixCSVReport(String fileNm, List<JDACrossAppMatrixModel> matrixList);







	//Multi User
	public Map<String, List<JDAPersonalSysMdl>> getMultiUserExistingRoles(List<String> empWwid);


	//END

	public String[] getRoleIdsPersonalSys(List<JDAPersonalSysMdl> psList);
	public List<MatrixModel> getUserLevelConflictingRoles(String empWwid, String[] data);
	public Map<String, List<String>> getSystemCodes(String data);
	public Map<String, List<String>> getSystemCodes(String[] data);


	public String writeSystemCodeCSVReport(String fileNm, List<SystemCodeModel> sysCdLst);


	public Map<String, SystemCodeModel> getSystemCodes();
	public String writeTechRoleMapCSVReport(String fileNm, List<StrKeyValPair> userRoles);


}
