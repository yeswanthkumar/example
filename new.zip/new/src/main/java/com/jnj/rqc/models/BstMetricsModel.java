package com.jnj.rqc.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;

@Data
public class BstMetricsModel {
	private Date   cDate;
	private String userId;
	private String firstVarEventVal;


	public String getData() {
		return Utility.dtFmt.format(cDate) +"~" +userId +"~"+ firstVarEventVal;
	}


	@Override
	public String toString() {
		return "BstMetricsModel [cDate=" + cDate + ", userId=" + userId + ", firstVarEventVal=" + firstVarEventVal+ "]";
	}



}
