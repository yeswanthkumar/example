package com.jnj.rqc.userabs.dao;

import java.util.List;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.sap.conn.jco.JCoException;

/**
 * File    : <b>SAPUserDao.java</b>
 * @author : DChauras @Created : Mar 7, 2023 3:51:43 PM
 * Purpose : DAO for Querying SAP Data
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

public interface SAPUserDao {

	public List<IAMRolesADGrpMdl> getPFBRoleADGrps(String sysTempl, String userId) throws JCoException;
	public List<IAMRolesADGrpMdl> getPFIRoleADGrps(String templSysParam, String user) throws JCoException;
	public List<IAMRolesADGrpMdl> getGRCRoleADGrps(String templSysParam, String user) throws JCoException;
	public void fetchExistingRolesCFIN(String templSysParam) throws JCoException;
	public void fetchExistingRolesDDGR(String templSysParam) throws JCoException;
	public void fetchExistingRolesAnaplan() throws JCoException;

}
