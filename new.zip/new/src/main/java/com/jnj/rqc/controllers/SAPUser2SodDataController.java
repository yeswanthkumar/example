package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dao.User2SodDao;
import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.User2SodDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>SAPUser2SodDataController.java</b>
 * @author : DChauras @Created : Dec 7, 2021 4:35:21 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class SAPUser2SodDataController {
	static final Logger log = LoggerFactory.getLogger(SAPUser2SodDataController.class);

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	User2SodDataService user2SodDataService;

	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	User2SodDao user2SodDao;

	String BASE_REGION = "REGION";




	@PostMapping("/getUser2SodEnvironmentData")
    public ResponseEntity<TableRespDto> getUser2SodEnvironmentData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Property name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = user2SodDataService.getEnvData(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping("/loadUser2SodPage")
    public String loadSapUserAccessProvPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadUser2SodProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	return "sapextraction/sapuser2sodpage";
    }

     @PostMapping("/loadUser2SodPageData")
    public String loadUser2SodPageData(@RequestParam("regions") String regions, @RequestParam("pltNames") String pltNames, @RequestParam("environmentId") String environmentId,
    		@RequestParam("sysNames") String sysNames, Model model, HttpServletRequest request) {
    	log.info("region: "+regions+" Platform: "+pltNames+" environmentId: "+environmentId+" sysNames: "+sysNames);
    	String regParam = regions;
    	List<String> regNames = Utility.loadUser2SodProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );

    	String selPlts = pltNames;
    	List<String> platformNames = Utility.loadUser2SodProperty(regParam);
    	model.addAttribute("platformNames", platformNames );
    	model.addAttribute("selPlts", selPlts );

    	String envIdParam = environmentId;
    	List<String> envIdNames = Utility.loadUser2SodProperty(regParam+"_"+selPlts);
    	model.addAttribute("envIdNames", envIdNames );
    	model.addAttribute("envIdParam", envIdParam );

    	String selSysNm = sysNames;
    	List<String> systemNames = Utility.loadUser2SodProperty(regParam+"_"+selPlts+"_"+envIdParam);
    	model.addAttribute("systemNames", systemNames );
    	model.addAttribute("selSysNm", selSysNm );

    	if("0".equals(regions) || "0".equals(pltNames) || "0".equals(environmentId) || "0".equals(sysNames) ) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region/Platform/Environment/System.");
            return "sapextraction/sapuser2sodpage";
    	}

    	String templSysParam = regParam+"_"+selPlts+"_"+envIdParam+"_"+selSysNm;
    	log.info("TemplateName: "+templSysParam);

    	Map<String, List<SapUser2SodModel>> user2SodDataMap = user2SodDataService.prepareUser2SodData(templSysParam);
    	List<SapUser2SodModel> validU2SList 	= user2SodDataMap.get("VAL_U2S");
    	List<SapUser2SodModel> inValidU2SList 	= user2SodDataMap.get("INV_U2S");

    	request.getSession().setAttribute("SAP_USER2SOD_DATA", validU2SList);
    	request.getSession().setAttribute("SAP_USER2SOD_INVLDATA", inValidU2SList);
    	request.getSession().setAttribute("PLATFORM", selPlts);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	model.addAttribute("SAP_USER2SOD_DATA", validU2SList);

    	//TODO - Added flag for export
    	model.addAttribute("EXPORT_ALLOWED", "Y");
    	//END flag
    	String msg  = "Status: Total USER TO SOD Data: "+ ((validU2SList == null || validU2SList.isEmpty() ) ?  "0": validU2SList.size()+"");
    	msg+="  -  (INVALID RECORDS : "+ ((inValidU2SList == null || inValidU2SList.isEmpty() ) ?  "0": inValidU2SList.size()+"")+" )";
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapuser2sodpage";
    }


    @SuppressWarnings("all")
 	@ResponseBody
 	@GetMapping("/exportU2SIndividualSystemData")
    public ResponseEntity<InputStreamResource> exportU2SIndividualSystemData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	String template = (String) request.getSession().getAttribute("TEMPLATE");
    	log.info("Export User to Sod Data for: "+template);
    	StringBuilder actions= new StringBuilder();
    	actions.append("Export SAP User to Sod Data for:"+template+"\n");
    	actions.append("Checking Export Status\n");
    	String[] tmplArr=template.split("_");
    	synchronized (tmplArr) {
 				int count = sAPExtrRegionWiseService.getExistingU2SSchCount(tmplArr[0], "E", "S");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER, U=USER2ROLE, S=USER2SOD'
 				if(count > 0) {
 					actions.append("User to Sod Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
 				}else {
 					UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
 					List<SapUser2SodModel> user2SodData = (List<SapUser2SodModel>)request.getSession().getAttribute("SAP_USER2SOD_DATA");
 					actions.append("Total Records to be replaced : "+user2SodData.size()+" \n Clearing records from Table.\n");
 					int delRec = sAPExtrRegionWiseService.deleteUser2SodTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
 					actions.append("Total records deleted : "+delRec+"\n\n");
 					actions.append("Inserting "+user2SodData.size()+" Records\n");
 					int insRecords = user2SodDataService.insertUser2SodTransactions(user2SodData, template, curUser.getJnjMsftUsrnmTxt());
 					actions.append("Total Records inserted : "+insRecords+"\n" );
 					try {
 						//Building Summary
 						TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
 						sumMdl.setRegion(tmplArr[0]);
 						sumMdl.setPlatform(tmplArr[1]);
 						sumMdl.setEnvironment(tmplArr[2]);
 						sumMdl.setSystem(tmplArr[3]);
 						sumMdl.setCreatedRecCount(insRecords);
 						sumMdl.setCreatedDt(new Date());
 						sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
 						sumMdl.setCollStatus("C");
 						actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
 						sAPExtrRegionWiseDao.saveUser2SodDataSummary(sumMdl);
 						actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
 					} catch (Exception e) {
 						log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
 					}
 				}
 			}
 			String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
 			String filePath = Utility.writeLogData(actions, fileNm);
 			File fl = new File(filePath);
 			log.info("Download File name:"+fl.getName());
 			InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
 			return ResponseEntity.ok()
 	 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
 	     	.contentType(MediaType.TEXT_PLAIN)
 	     	.contentLength(fl.length())
 	     	.body(resource);
 	   }





    @ResponseBody
    @GetMapping("/downSapUser2SodExcel")
 	@SuppressWarnings("all")
     public ResponseEntity<InputStreamResource> downSapUser2SodExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
 		log.info("Downloading SAP User to SOD Excel ");
 		String fileNm ="UsertoSod_Review_"+request.getSession().getAttribute("PLATFORM");
 		String invldFlNm ="INCOMPLETE_UsertoSod_Review_"+request.getSession().getAttribute("PLATFORM");
 		List<SapUser2SodModel> u2sData = (List<SapUser2SodModel>)request.getSession().getAttribute("SAP_USER2SOD_DATA");
 		List<SapUser2SodModel> incompleteData = (List<SapUser2SodModel>)request.getSession().getAttribute("SAP_USER2SOD_INVLDATA");
 		String filePath = user2SodDataService.writeSapUser2SodExcel(u2sData, fileNm);
 		String invldFlPath = user2SodDataService.writeSapUser2SodExcel(incompleteData, invldFlNm);

 		String zipfilePath = Utility.createZip(Arrays.asList(filePath,invldFlPath), Constants.REPO_OUT_LOC+fileNm+"_"+Utility.fmtMDY(new Date())+".zip");
     	File fl = new File(zipfilePath);
 		log.info("Download File name:"+fl.getName());
     	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
     	return ResponseEntity.ok()
     		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
         	.contentType(MediaType.TEXT_PLAIN)
         	.contentLength(fl.length())
         	.body(resource);
     }


    @GetMapping("/uploadMitigatingCntrlFile")
    public String uploadMitiCntrlData(Model model, HttpServletRequest request) {
    	log.info("User to Sod Mitigating Control Upload Page");
    	return "sapextraction/uploadMitigatingCntrlFile";
    }

	@PostMapping("/uploadMitiCntrlProcess")
    public String uploadMitiCntrlProcess(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected Mitigating Control File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the correct file to upload.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "sapextraction/uploadMitigatingCntrlFile";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel File/Document...!");
            return "sapextraction/uploadMitigatingCntrlFile";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<SapMitiCntrlModel> u2sMitiData = user2SodDataService.readMitigatingCntrlExcel(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("U2S_MITICNTRL");
    		if(u2sMitiData != null && !u2sMitiData.isEmpty()) {
    			session.setAttribute("MITI_FILENAME", file.getOriginalFilename());
    			session.setAttribute("U2S_MITICNTRL", u2sMitiData);
        		model.addAttribute("U2S_MITICNTRL", u2sMitiData);
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((u2sMitiData != null && !u2sMitiData.isEmpty())? u2sMitiData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/uploadMitigatingCntrlFile";
    }



	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/saveMitiCntrlData")
    public ResponseEntity<InputStreamResource> saveMitiCntrlData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving User to SOD Nitigating Control Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "MITIGATING_CONTROL_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("MITI_FILENAME");
        	int recordsIns = 0;
    		logData.append("Saving Mitigating Control Data (USER2SOD) to DataBase.");
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<SapMitiCntrlModel> mitiData = (List<SapMitiCntrlModel>)request.getSession().getAttribute("U2S_MITICNTRL");
        	logData.append("Total Records in file : "+mitiData.size()+"\n");
        	logData.append("Saving  "+mitiData.size()+" Records to DataBase. \n");
        	try {
        		recordsIns = user2SodDao.insertUser2SodMitiData(mitiData);
    		} catch (Exception e) {
    			logData.append("Total Records Inserted Mitigating in DataBase : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for MITIGATING CTRL "+e.getMessage(), e);
    		}
        	logData.append("Total MITIGATING CONTROL Records saved to Database : "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "GRAC_MITIGATING_CONTROL_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	String envName = Utility.getServerProp("ENVIRONMENT");
        	String subject = " GRAC MITIGATING CONTROL Data saved to Database @DateTime: "+Utility.fmtMMDDYYYYTime(new Date());
        	try {
				emailUtil.sendRefDataEmail(envName+" - "+subject, "USER2SOD", flNm, mitiData.size(), recordsIns, user, "M");
			} catch (Exception e) {
				log.error("Error Sending USER TO SOD Manual Upload Email :"+e.getMessage(), e);
			}
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadMitiCntrlDataExcel")
 	@SuppressWarnings("all")
     public ResponseEntity<InputStreamResource> downloadMitiCntrlDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
 		log.info("Downloading SAP User to SOD Excel ");
 		String fileNm ="GRAC_MITIGATING_CONTROL";
 		List<SapMitiCntrlModel> mitiData = (List<SapMitiCntrlModel>)request.getSession().getAttribute("U2S_MITICNTRL");
 		String filePath = user2SodDataService.writeMitiCntrlExcel(mitiData, fileNm);
 		File fl = new File(filePath);
 		log.info("Download File name:"+fl.getName());
     	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
     	return ResponseEntity.ok()
     		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
         	.contentType(MediaType.TEXT_PLAIN)
         	.contentLength(fl.length())
         	.body(resource);
     }

	@GetMapping("/uploadReviverDetails")
    public String uploadReviverDetails(Model model, HttpServletRequest request) {
    	log.info("User to Sod Reviver Upload Page");
    	return "sapextraction/uploadRevieverDetails";
    }

	@GetMapping("/uploadMerReviverDetails")
    public String uploadMerReviverDetails(Model model, HttpServletRequest request) {
    	log.info("Mercury User to Sod Reviver Upload Page");
    	return "sapextraction/uploadMercuryRevieverDetails";
    }

	@PostMapping("/uploadReviverDetailsData")
    public String uploadReviverDetailsData(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected Reviever File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the correct file to upload.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "sapextraction/uploadRevieverDetails";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel File/Document...!");
            return "sapextraction/uploadRevieverDetails";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<SapPlatformReviwerMdl> revData = user2SodDataService.loadPlatformReviewers(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("U2S_REVIWERS");
    		if(revData != null && !revData.isEmpty()) {
    			session.setAttribute("REV_FILENAME", file.getOriginalFilename());
    			session.setAttribute("U2S_REVIWERS", revData);
        		model.addAttribute("U2S_REVIWERS", revData);
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((revData != null && !revData.isEmpty())? revData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/uploadRevieverDetails";
    }

	@PostMapping("/uploadMercuryReviverData")
    public String uploadMercuryReviverData(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected Reviever File:"+file.getOriginalFilename()+" to Process");

    	if (file.isEmpty()) {
    		log.info("No FILE selected or File does not exists... Please select the correct file to upload.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Upload .XLS file is required!");
            return "sapextraction/uploadMercuryRevieverDetails";
        }

    	String ext = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid Excel File/Document...!");
            return "sapextraction/uploadMercuryRevieverDetails";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<StrKeyValPair> revData = user2SodDataService.loadMercuryPlatformReviewers(path);
    		HttpSession session = request.getSession();
    		session.removeAttribute("MER_REVIWERS");
    		if(revData != null && !revData.isEmpty()) {
    			session.setAttribute("MER_FILENAME", file.getOriginalFilename());
    			session.setAttribute("MER_REVIWERS", revData);
        		model.addAttribute("MER_REVIWERS", revData);
    		}
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Mercury Data Load successfull - " + file.getOriginalFilename()+" - ( Records: "+((revData != null && !revData.isEmpty())? revData.size():0)+" )");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "sapextraction/uploadMercuryRevieverDetails";
    }




	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/saveUser2SodReviewereData")
	public ResponseEntity<InputStreamResource> saveReviwerData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving User to SOD Reviewer Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "REVIEWER_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("REV_FILENAME");
        	int recordsIns = 0;
    		logData.append("Saving Reviewers Data (USER2SOD) to DataBase.");
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<SapPlatformReviwerMdl> revrData = (List<SapPlatformReviwerMdl>)request.getSession().getAttribute("U2S_REVIWERS");
        	logData.append("Total Records in file : "+revrData.size()+"\n");
        	logData.append("Saving  "+revrData.size()+" Records to DataBase. \n");
        	try {
        		recordsIns = user2SodDataService.saveReviewersData(revrData);
        	} catch (Exception e) {
    			logData.append("ERROR Total Records Inserted for Reviewers in DataBase : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for REVIEWERS DATA "+e.getMessage(), e);
    		}
        	logData.append("Total REVIEWER Records saved to Database :(ADDED) "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "REVIEWER_UPLOAD_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	String envName = Utility.getServerProp("ENVIRONMENT");
        	String subject = " REVIEWER_UPLOAD Data saved to Database @DateTime: "+Utility.fmtMMDDYYYYTime(new Date());
        	try {
				emailUtil.sendRefDataEmail(envName+" - "+subject, "USER2SOD", flNm, revrData.size(), recordsIns, user, "R");
			} catch (Exception e) {
				log.error("Error Sending Email for Reviewer Manual Upload Email :"+e.getMessage(), e);
			}
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@SuppressWarnings("all")
	@ResponseBody
    @GetMapping("/saveMerUser2SodReviewereData")
	public ResponseEntity<InputStreamResource> saveMercuryReviwerData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	log.info("Saving Mercury User to SOD Reviewer Data to Database");
    	HttpSession sess = request.getSession();
    	UserSearchModel user =(UserSearchModel)sess.getAttribute(Constants.AUTH_USER);
    	StringBuilder logData = new StringBuilder();
    	String filePath = "";
    	if(user == null) {
    		logData.append("Your Session has EXPIRED/TIMED OUT, Please RE-LOGIN and try again....!");
    		filePath = Utility.writeLogData(logData, "REVIEWER_UPLOAD_FAILED_"+Utility.fmtMDY(new Date())+".txt");
    	}else {
    		String flNm = (String)sess.getAttribute("MER_FILENAME");
        	int recordsIns = 0;
    		logData.append("Saving Mercury Reviewers Data (USER2SOD) to DataBase.");
        	logData.append("\nSTART Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	List<StrKeyValPair> revrData = (List<StrKeyValPair>)request.getSession().getAttribute("MER_REVIWERS");
        	logData.append("Total Records in file : "+revrData.size()+"\n");
        	logData.append("Saving  "+revrData.size()+" Records to DataBase. \n");
        	try {
        		recordsIns = user2SodDataService.saveMercuryReviewersData(revrData);
        	} catch (Exception e) {
    			logData.append("ERROR Total Records Inserted for Mercury Reviewers in DataBase : "+recordsIns+"\n"+e.getMessage());
    			log.error("ERROR inserting Records for MERCURY REVIEWERS DATA "+e.getMessage(), e);
    		}
        	logData.append("Total MERCURY REVIEWER Records saved to Database :(ADDED) "+recordsIns+"\n");
        	logData.append("END Processing file : "+flNm+"  @: "+Utility.fmtMMDDYYYYTime(new Date())+"\n");
        	filePath = Utility.writeLogData(logData, "MERCURYREVIEWER_UPLOAD_"+Utility.fmtMDY(new Date())+".txt");
        	//Send Email
        	String envName = Utility.getServerProp("ENVIRONMENT");
        	String subject = " MERCURY REVIEWER_UPLOAD Data saved to Database @DateTime: "+Utility.fmtMMDDYYYYTime(new Date());
        	try {
				emailUtil.sendRefDataEmail(envName+" - "+subject, "USER2SOD", flNm, revrData.size(), recordsIns, user, "R");
			} catch (Exception e) {
				log.error("Error Sending Email for Mercury Reviewer Manual Upload Email :"+e.getMessage(), e);
			}
        }

    	log.info("Downloading logfile :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadReviewerDataExcel")
 	@SuppressWarnings("all")
     public ResponseEntity<InputStreamResource> downloadReviewerDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
 		log.info("Downloading SAP Reviewer Data Excel ");
 		String fileNm ="SAP_REVIEWERDATA";
 		List<SapPlatformReviwerMdl> revrData = (List<SapPlatformReviwerMdl>)request.getSession().getAttribute("U2S_REVIWERS");
 		String filePath = user2SodDataService.writeReviewerExcel(revrData, fileNm);
 		File fl = new File(filePath);
 		log.info("Download File name:"+fl.getName());
     	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
     	return ResponseEntity.ok()
     		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
         	.contentType(MediaType.TEXT_PLAIN)
         	.contentLength(fl.length())
         	.body(resource);
     }



	@ResponseBody
    @GetMapping("/downloadMerReviewerDataExcel")
 	@SuppressWarnings("all")
     public ResponseEntity<InputStreamResource> downloadMerReviewerDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
 		log.info("Downloading Mercury Reviewer Data Excel ");
 		String fileNm ="MERCURY_REVIEWERDATA";
 		List<StrKeyValPair> revrData = (List<StrKeyValPair>)request.getSession().getAttribute("MER_REVIWERS");
 		String filePath = user2SodDataService.writeMerReviewerExcel(revrData, fileNm);
 		File fl = new File(filePath);
 		log.info("Download File name:"+fl.getName());
     	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
     	return ResponseEntity.ok()
     		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
         	.contentType(MediaType.TEXT_PLAIN)
         	.contentLength(fl.length())
         	.body(resource);
     }

  }
