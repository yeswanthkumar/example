package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.AppRoutingModel;
import com.jnj.rqc.service.AppEmailRoutingService;
import com.jnj.rqc.service.RqcReportService;

@Controller
public class AppEmailRoutingController {

	static final Logger log = LoggerFactory.getLogger(AppEmailRoutingController.class);

	@Autowired
	private AppEmailRoutingService appEmailRoutingService;

	@Autowired
	RqcReportService rqcReportService;

	@GetMapping("/routingInfoPage")
    public String loadReportForm(Model model, HttpServletRequest request) {
    	log.info("Routing to RQC Routing Info.");
    	Map<String, List<AppRoutingModel>> appRouteMap = appEmailRoutingService.getAllAppRoutingDetails(request);
    	request.getSession().setAttribute("ROUTING_MAP", appRouteMap);
    	List<String> keys = new ArrayList<>(appRouteMap.keySet());
    	Collections.sort(keys);
    	model.addAttribute("CATGKEYS",keys);
    	model.addAttribute("CATMODEL", request.getSession().getAttribute("ALLCATEGORY"));
    	request.getSession().setAttribute("CATMODEL", request.getSession().getAttribute("ALLCATEGORY"));
    	return "reports/routingInfoPage";
    }



	@PostMapping("/filterEmailRouting")
	@SuppressWarnings("all")
	public String filterEmailRouting(@RequestParam("category") String category,  Model model, HttpServletRequest request) {
    	log.info(" Category Param :"+category);
    	model.addAttribute("catKey", category);
    	request.getSession().setAttribute("category", category);
    	Map<String, List<AppRoutingModel>> appRouteMap = (Map<String, List<AppRoutingModel>>)request.getSession().getAttribute("ROUTING_MAP");
    	List<String> keys = new ArrayList<>(appRouteMap.keySet());
    	Collections.sort(keys);
    	model.addAttribute("CATGKEYS",keys);
    	List<AppRoutingModel> rtModelLst = new ArrayList<>();
    	if("ALL".equals(category)) {
    		rtModelLst =(List<AppRoutingModel>)request.getSession().getAttribute("ALLCATEGORY");
    	}else {
    		rtModelLst =appEmailRoutingService.filterAppRoutingCategory(category, appRouteMap);
    	}
    	request.getSession().setAttribute("CATMODEL", rtModelLst);
    	model.addAttribute("CATMODEL", rtModelLst);
    	return "reports/routingInfoPage";
    }


	@ResponseBody
    @GetMapping("/downloadRoutingFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadRoutingExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Routing Files");
		List<AppRoutingModel> rtModelLst = (List<AppRoutingModel>)request.getSession().getAttribute("CATMODEL");

		String fileNm = Constants.REPO_OUT_LOC+request.getSession().getAttribute("category")+"_ROUTING";
		String filePath = rqcReportService.createRoutingFile(fileNm, rtModelLst);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
	}

/*
	@ResponseBody
    @GetMapping("/downIndividualFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadIndividualExcel(@RequestParam String app1, @RequestParam String app2, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		//log.info("Downloading RuleSet Individual File: "+requestParams.get("app1")+"-"+requestParams.get("app2"));
		log.info("Downloading RuleSet Individual File: "+app1+"-"+app2);
		String ruleSetFileDir =(String)request.getSession().getAttribute("RULESETDIR");
		List<RuleSetSmryModel> summaryModel = (List<RuleSetSmryModel>)request.getSession().getAttribute("SUMMARYDATA");
		String filePath = "";
		for(RuleSetSmryModel mdl : summaryModel) {
			if(mdl.getApp1().equals(app1) && mdl.getApp2().equals(app2)) {
				filePath = mdl.getFileLoc();
				break;
			}
		}
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

*/
}
