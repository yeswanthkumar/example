package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.ConflictResponseDTO;
import com.jnj.rqc.conflictModel.EmlRoleConfResponseDTO;
import com.jnj.rqc.conflictModel.JSONRoleConfResponseDTO;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.conflictModel.RoleSearcModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

@Controller
public class SODWebConflictController {
	static final Logger log = LoggerFactory.getLogger(SODWebConflictController.class);

	@Autowired
	private RqcSapConflictService RqcSapConflictService;

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	EmailUtil emailUtil;


	@GetMapping("/rqcSapTestEmail")
    public String rqcSapTestEmail(Model model) {
    	log.info("Test EMail .");
    	try {
			emailUtil.sendEmail("Post Processing Status",  "Hi This is Dharm","D:\\Users\\DChauras\\RQC\\TERMINATIONS\\Terminations_08182020\\HCS_Applications_Termination_Requests_08-18-2020.xlsx", null);
		} catch (Exception e) {

			e.printStackTrace();
		}
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
    	return "conflictcheck/conflictInfo";
    }




/**
 * Method  : SODWebConflictController.java.searchEmlUserLevelDetails()
 *		   :<b>@param roleSearcModel
 *		   :<b>@param model
 *		   :<b>@param request
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Aug 20, 2020 3:02:55 PM
 * Purpose : Get User Level Roles & Conflicts based on User ID
 * @return : String
 */
	@PostMapping("/getUserSODConflicts")
    public ResponseEntity<EmlRoleConfResponseDTO> searchAndEmlUserLevelDetails(@RequestBody RoleSearcModel roleSearcModel, Model model, HttpServletRequest request) {
		log.info(" Received Parameters idType: "+roleSearcModel.getIdType()+" ID: "+roleSearcModel.getUserId());

		EmlRoleConfResponseDTO respDto = new EmlRoleConfResponseDTO();
    	String idToUse = "";

		if(roleSearcModel == null || roleSearcModel.getUserId() == null || roleSearcModel.getUserId().length() == 0 ) {
			return new ResponseEntity<>(getDtoStatus(respDto, 1), HttpStatus.BAD_REQUEST);
		}
		idToUse = roleSearcModel.getUserId();
		List<UserSearchModel> userLst = null;
		if(roleSearcModel.getIdType() == 2) {
			userLst = userSearchService.getUserDataByNtId(roleSearcModel.getUserId(), 1);
			if(userLst != null && !userLst.isEmpty()) {
				idToUse = userLst.get(0).getWwId();
			}else {
				return new ResponseEntity<>(getDtoStatus(respDto, 2), HttpStatus.BAD_REQUEST);
			}
		}else {
			userLst =  userSearchService.getUserData(1, idToUse, 1);
		}

    	try{
    		String userName = (userLst.get(0).getJnjMsftUsrnmTxt()).toUpperCase();
			String name 	= userLst.get(0).getFmlyNm()+", "+userLst.get(0).getGivenNm()+"("+userLst.get(0).getJnjMsftUsrnmTxt().toUpperCase()+")";

    		List<MatrixModel> userLvlConflictRoles = new ArrayList<>();
    		List<KeyValPair> keyLst = new ArrayList<>();
    		String roleFilePath = "";
    		String confFilePath = "";

    		List<PersonalSysModel> currentRoleList = RqcSapConflictService.getUserExistingRoles(idToUse);
    		if(currentRoleList != null && currentRoleList.size() > 1) {
    			roleFilePath = createUserLvlRoleFile("XLS", currentRoleList, userName);
    			KeyValPair curRoles = new KeyValPair();
    			curRoles.setVal("Existing Role Count");
    			curRoles.setKey(currentRoleList.size());
    			keyLst.add(curRoles);

    			String[] roleIds = RqcSapConflictService.getRoleIdsPersonalSys(currentRoleList);
    			userLvlConflictRoles = RqcSapConflictService.getUserLevelConflictingRoles(idToUse, roleIds);

    			if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
    				confFilePath = createUserLvlConflictFile("XLS", userLvlConflictRoles, userName, 0);
    				KeyValPair confRoles = new KeyValPair();
    				confRoles.setVal("Conflicting Role Count");
    				confRoles.setKey(userLvlConflictRoles.size());
        			keyLst.add(confRoles);
    			}
    		}

    		log.debug("Current Roles Count: "+((currentRoleList == null || currentRoleList.isEmpty())? "0" : currentRoleList.size()));
    		log.debug("Conflicting Roles Count: "+((userLvlConflictRoles == null || userLvlConflictRoles.isEmpty())? "0" : userLvlConflictRoles.size()));

    		emailUtil.sendEmail("User Role and Conflict Details Review for - "+name,  Constants.ROLE_CONFLICT_MSG1, roleFilePath+";"+confFilePath, null);

    		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setStatusCode(Constants.SUCCESS);
			respDto.setStatusDesc("");
			respDto.setDeveloperMessage("SUCCESS");
			respDto.setStatusMsg("SUCCESS");
			respDto.setData(keyLst);

		} catch (Exception e) {
            log.error("Error getting user data :"+e.getMessage(), e);
        	e.printStackTrace();
        	respDto.setStatusCode(Constants.ERROR);
        	respDto.setStatusDesc("Exception Recorded");
        	respDto.setDeveloperMessage(e.getMessage());
        	respDto.setStatusMsg(e.getMessage());
        	return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new ResponseEntity<>(respDto, HttpStatus.OK);
    }


	/**
	 * Method  : RqcSapConflictController.java.searchUserDetails()
	 *		   :<b>@param empWwid
	 *		   :<b>@param data
	 *		   :<b>@param model
	 *		   :<b>@param request
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jan 15, 2020 1:50:54 PM
	 * Purpose :Check for Role Conflicts when User is Adding a new Role.
	 * @return : String
	 */
		@PostMapping("/newRoleAndConflicts")
		public ResponseEntity<EmlRoleConfResponseDTO> newRoleAndConflicts(@RequestBody RoleSearcModel roleSearcModel,  Model model, HttpServletRequest request) {
			log.info("EMPID :"+roleSearcModel.getUserId()+"  idType: "+roleSearcModel.getIdType()+"   Data:"+roleSearcModel.getData());

			EmlRoleConfResponseDTO respDto = new EmlRoleConfResponseDTO();
	    	String idToUse = "";

			if(roleSearcModel == null || roleSearcModel.getUserId() == null || roleSearcModel.getUserId().length() == 0 ) {
				return new ResponseEntity<>(getDtoStatus(respDto, 1), HttpStatus.BAD_REQUEST);
			}

			if(roleSearcModel.getData().length() == 0) {
				return new ResponseEntity<>(getDtoStatus(respDto, 3), HttpStatus.BAD_REQUEST);
			}

			try{
				idToUse = roleSearcModel.getUserId();
				Map<String, List<String>> sysCdMap = RqcSapConflictService.getSystemCodes(roleSearcModel.getData());
				List<String> sodCds = sysCdMap.get("SYSCDLST");
				List<String> invldRls = sysCdMap.get("INVLDLST");
				String[] dataArr = sodCds.toArray(new String[sodCds.size()]);

				List<UserSearchModel> userLst = null;
				if(roleSearcModel.getIdType() == 2) {
					userLst = userSearchService.getUserDataByNtId(roleSearcModel.getUserId(), 1);
					if(userLst != null && !userLst.isEmpty()) {
						idToUse = userLst.get(0).getWwId();
					}else {
						return new ResponseEntity<>(getDtoStatus(respDto, 2), HttpStatus.BAD_REQUEST);
					}
				}else {
					userLst =  userSearchService.getUserData(1, idToUse, 1);
				}

				String userName = (userLst.get(0).getJnjMsftUsrnmTxt()).toUpperCase();
				String name 	= userLst.get(0).getFmlyNm()+", "+userLst.get(0).getGivenNm()+" ("+userLst.get(0).getJnjMsftUsrnmTxt().toUpperCase()+")";

				List<PersonalSysModel> currentRoleList = RqcSapConflictService.getUserExistingRoles(idToUse);
				List<MatrixModel> curRoleConflictList = RqcSapConflictService.getCurConflictDetails(idToUse, dataArr);
	    		List<MatrixModel> newRoleConflictList = RqcSapConflictService.getNewConflictDetails(idToUse, dataArr);

	    		List<KeyValPair> keyLst = new ArrayList<>();
	    		String roleFilePath = "";
	    		String curConflFilePath = "";
	    		String newConflFilePath = "";
	    		if(currentRoleList != null && !currentRoleList.isEmpty()) {
	    			roleFilePath = createUserLvlRoleFile("XLS", currentRoleList, userName);
	    			KeyValPair curRoles = new KeyValPair();
	    			curRoles.setVal("Existing Role Count");
	    			curRoles.setKey(currentRoleList.size());
	    			keyLst.add(curRoles);
	    		}

	    		if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
	    			curConflFilePath = createUserLvlConflictFile("XLS", curRoleConflictList, userName, 0);
    				KeyValPair confRoles = new KeyValPair();
    				confRoles.setVal("Current Conflicting Role Count");
    				confRoles.setKey(curRoleConflictList.size());
        			keyLst.add(confRoles);
	    		}

	    		if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
	    			newConflFilePath = createUserLvlConflictFile("XLS", newRoleConflictList, userName, 1);
    				KeyValPair confRoles = new KeyValPair();
    				confRoles.setVal("New Conflicting Role Count");
    				confRoles.setKey(newRoleConflictList.size());
        			keyLst.add(confRoles);
	    		}
	    		emailUtil.sendEmail("User Role and Conflict Details Review - Add Role for - "+name,  Constants.ROLE_CONFLICT_MSG1, roleFilePath+";"+curConflFilePath+";"+newConflFilePath, invldRls);

	    		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
				respDto.setStatusCode(Constants.SUCCESS);
				respDto.setStatusDesc("");
				respDto.setDeveloperMessage("SUCCESS");
				respDto.setStatusMsg("SUCCESS");
				respDto.setData(keyLst);

			} catch (Exception e) {
	            log.error("Error getting user data :"+e.getMessage(), e);
	        	e.printStackTrace();
	        	respDto.setStatusCode(Constants.ERROR);
	        	respDto.setStatusDesc("Exception Recorded");
	        	respDto.setDeveloperMessage(e.getMessage());
	        	respDto.setStatusMsg(e.getMessage());
	        	return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    	return new ResponseEntity<>(respDto, HttpStatus.OK);
	    }



	private EmlRoleConfResponseDTO getDtoStatus(EmlRoleConfResponseDTO respDto, int params) {
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		if(params == 1) {
			respDto.setStatusCode(Constants.ERROR);
			respDto.setStatusDesc("MISSING PARAMETERS");
			respDto.setDeveloperMessage("Missing required Parameters(userId): WWID/NTID/idType.");
			respDto.setStatusMsg("Missing required Parameters(userId): WWID/NTID/idType");
		}else if(params == 2) {
			respDto.setStatusCode(Constants.ERROR);
			respDto.setStatusDesc("INVALID PARAMETERS");
			respDto.setDeveloperMessage("Invalid NTID, Please correct the NTID and Search again.");
			respDto.setStatusMsg("Invalid NTID, Please correct the NTID and Search again.");
		}else if(params == 3) {
			respDto.setDeveloperMessage("Missing required Parameters(data): Role Names.");
			respDto.setStatusMsg("Missing required Parameters(data): Role Names.");
		}

		return respDto;
	}
	//Test Method designed for NAYANA
	private JSONRoleConfResponseDTO getDtoJSONStatus(JSONRoleConfResponseDTO respDto, int params) {
		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		if(params == 1) {
			respDto.setStatusCode(Constants.ERROR);
			respDto.setStatusDesc("MISSING PARAMETERS");
			respDto.setDeveloperMessage("Missing required Parameters(userId): WWID/NTID/idType.");
			respDto.setStatusMsg("Missing required Parameters(userId): WWID/NTID/idType");
		}else if(params == 2) {
			respDto.setStatusCode(Constants.ERROR);
			respDto.setStatusDesc("INVALID PARAMETERS");
			respDto.setDeveloperMessage("Invalid NTID, Please correct the NTID and Search again.");
			respDto.setStatusMsg("Invalid NTID, Please correct the NTID and Search again.");
		}else if(params == 3) {
			respDto.setDeveloperMessage("Missing required Parameters(data): Role Names.");
			respDto.setStatusMsg("Missing required Parameters(data): Role Names.");
		}

		return respDto;
	}

	private String createUserLvlRoleFile(String type, List<PersonalSysModel> curRoles, String usrId) throws IOException{
		log.info("Type received :"+ type +" Total Roles: "+curRoles);
		String filePath = "";
		String fileNm ="";
		if("XLS".equals(type)) {
			fileNm ="UserRolesList_"+usrId;
			filePath = RqcSapConflictService.writeUserRoleCSVReport(fileNm, curRoles);
		}else {
			fileNm ="UserRolesList_"+usrId+".pdf";
			filePath = RqcSapConflictService.writeUserRolePDFReport(fileNm, curRoles);
		}
		File fl = new File(filePath);
    	log.info("Create file: "+fl.getName());
    	return filePath;
    }


	private String createUserLvlConflictFile(String type, List<MatrixModel> userConflicts, String usrId, int newRoles) throws IOException{
		log.info("File Type received :"+ type);
		String fileNm ="";
		String filePath = "";
		if("XLS".equals(type)) {

			fileNm =(newRoles >0)?"NewUserRolesConflictList_"+usrId : "UserRolesConflictList_"+usrId;
			filePath = RqcSapConflictService.writeConfCSVReport(fileNm, userConflicts);
		}else {
			fileNm =(newRoles >0)? "NewUserRolesConflictList_"+usrId+".pdf" : "UserRolesConflictList_"+usrId+".pdf";
			String title = "User level SOD Conflicts between Application Role(s)";
			filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, userConflicts);
		}
		File fl = new File(filePath);
    	log.info("Created File :"+fl.getName());
    	return filePath;
    }



	@ResponseBody
    @GetMapping("/downloadUserLvlPDF/{type}11")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadUserLevelPdf(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="";
		List<PersonalSysModel> currentRoleList = null;
		List<MatrixModel> userLvlConflictRoles = null;

		if("userroles".equals(type)) {
			fileNm ="UserRolesList.pdf";
			currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			filePath = RqcSapConflictService.writeUserRolePDFReport(fileNm, currentRoleList);
		}else {
			fileNm ="UserRolesConflictList.pdf";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			String title = "User level SOD Conflicts between Application Role(s)";
			filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, userLvlConflictRoles);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.APPLICATION_PDF)
        	.contentLength(fl.length())
        	.body(resource);
    }





	/**
	 * Method  : RqcSapConflictController.java.loadSearchConflictForm()
	 *		   :<b>@param model
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jan 15, 2020 3:19:48 PM
	 * Purpose :User level Sod Conflict/Roles Report
	 * @return : String
	 */
	@GetMapping("/searchUserConflicts1")
    public String loadSearchConflictForm(Model model) {
		List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		log.info("Routing to Conflict Search page.");
    	return "conflictcheck/userConflictSearchInfo";
    }






	@ResponseBody
    @GetMapping("/downloadCurConfExcel/{type}11")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm ="ExistingAndRequestedRoleConflicts";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}


		String filePath = RqcSapConflictService.writeConfCSVReport(fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadCurConfPDF/{type}11")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		String title="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested.pdf";
			title="Requested New Role(s) SOD Conflicts with each other";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm = "ExistingAndRequestedRoleConflicts.pdf";
			title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}
		String filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }






/**
 * Method  : RqcSapConflictController.java.getUserConflicts()
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Jan 15, 2020 1:53:31 PM
 * Purpose : This is a Open Method designed to provide JSON response to the requesting system -Still needs to be completed
 * @return : ResponseEntity<List<ConflictResponseDTO>>
 */
    @GetMapping("/getUserConflicts11")
    public ResponseEntity<List<ConflictResponseDTO>> getUserConflicts() {
        log.info("Conflict List");

        List<ConflictResponseDTO> list = new ArrayList<>();
        ConflictResponseDTO dto = new ConflictResponseDTO();
        dto.setTimeStamp(new Date());
        list.add(dto);

        return new ResponseEntity<>(list, HttpStatus.OK);
    }



	/*Multi User Role Review*/

	@GetMapping("/reviewMultiUser11")
    public String multiUserRoleForm(Model model) {
    	log.info("Routing to Multi-User Role Review page.");
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
    	return "conflictcheck/multiUserRoleReview";
    }

	@PostMapping("/srchMultiUserRoles11")
    public String searchMultiUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empIds") String empIds, Model model, HttpServletRequest request){
		log.info("idType: "+idType+" empIds: "+empIds);
		List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		model.addAttribute("empIdParams",empIds);
		model.addAttribute("idTParam", idType);
		if(idType == 0 || empIds == null || empIds.length() == 0) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Search By/WWID/NTID ");
            return "conflictcheck/multiUserRoleReview";
    	}
		List<String>idToUse = new ArrayList<>();
		if(idType == 2) {
			List<UserSearchModel> userLst = userSearchService.getUserData(2, empIds, 1);
			if(userLst != null && !userLst.isEmpty()) {
				for(UserSearchModel item : userLst){
					idToUse.add(item.getWwId());
				}
			}else {
				model.addAttribute("message", "True");
	            model.addAttribute("error", "Invalid NTID's, Please correct the NTID and Search again.");
	            return "conflictcheck/multiUserRoleReview";
			}
		}else {
			idToUse = Arrays.asList(empIds.split(","));
		}

		try{
			Map<String, List<MatrixModel>> userLvlConfRlsMaps = new HashMap<>();
			Map<String, List<PersonalSysModel>> curRoleMap = RqcSapConflictService.getMultiUserExistingRoles(idToUse);

    		HttpSession session = request.getSession();
    		if(curRoleMap != null && !curRoleMap.isEmpty()) {
    			session.setAttribute("curRoleMap", curRoleMap);
        		model.addAttribute("curRoleMap", curRoleMap);
        		model.addAttribute("message", "True");
        	}

    		if(curRoleMap != null && curRoleMap.size() > 1) {
    			for (Map.Entry<String, List<PersonalSysModel>> entry : curRoleMap.entrySet()) {
    				String[] roleIds = RqcSapConflictService.getRoleIdsPersonalSys(entry.getValue());
        			List<MatrixModel> confList = RqcSapConflictService.getUserLevelConflictingRoles(entry.getKey(), roleIds);
        			if(confList != null && !confList.isEmpty()) {
        				userLvlConfRlsMaps.put(entry.getKey(), confList);
        			}
        		}
    		}
    		if(userLvlConfRlsMaps != null && !userLvlConfRlsMaps.isEmpty()) {
    			session.setAttribute("curUserConflicts", userLvlConfRlsMaps);
        		model.addAttribute("curUserConflicts", userLvlConfRlsMaps);
    		}

    		model.addAttribute("success", "Status: Count of total users found : "+((curRoleMap == null || curRoleMap.isEmpty())? "0" : curRoleMap.size()));
    		model.addAttribute("success1", "Status: Count of total users found : "+((userLvlConfRlsMaps == null || userLvlConfRlsMaps.isEmpty())? "0" : userLvlConfRlsMaps.size()));
    	} catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/multiUserRoleReview";
    }




	@ResponseBody
    @GetMapping("/downloadMultiUserLvlExcel/{type}11")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> downloadMultiUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		Map<String,List<PersonalSysModel>> currentRoleMap = null;
		Map<String, List<MatrixModel>> userLvlConflictMap = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
			filePath = RqcSapConflictService.writeMultiUserRolePDFCSVReport("CSV", fileNm, currentRoleMap);
		}else {
			fileNm ="UserRolesConflictList";
			userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
			filePath = RqcSapConflictService.writeMultiConfPDFCSVReport("CSV", fileNm, userLvlConflictMap);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	@ResponseBody
    @GetMapping("/dwnMultiUserLvlPDF/{type}11")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnMultiUserConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		Map<String,List<PersonalSysModel>> currentRoleMap = null;
		Map<String, List<MatrixModel>> userLvlConflictMap = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
			filePath = RqcSapConflictService.writeMultiUserRolePDFCSVReport("PDF", fileNm, currentRoleMap);
		}else {
			fileNm ="UserRolesConflictList";
			userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
			filePath = RqcSapConflictService.writeMultiConfPDFCSVReport("PDF", fileNm, userLvlConflictMap);
		}
		File fl = new File(filePath);

    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	/***New Methods Designed to send User Leve Roles/Conflicts Info to Email***/




	//1. USER LEVEL :Input : User ID, type of ID : 1=WWID, 2=NTID



	/*
	@PostMapping("/loadDBTables")
    public ResponseEntity<TableRespDto> getTableData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Schema name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = dBExtService.getSchemaTables(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<TableRespDto>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<TableRespDto>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<TableRespDto>(tableRespDto, HttpStatus.NOT_FOUND);
        }

    }

	  */




	@ResponseBody
    @GetMapping("/NEWdownloadUserLvlExcel/{type}")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> NEWdownloadUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		List<PersonalSysModel> currentRoleList = null;
		List<MatrixModel> userLvlConflictRoles = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			filePath = RqcSapConflictService.writeUserRoleCSVReport(fileNm, currentRoleList);
		}else {
			fileNm ="UserRolesConflictList";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			filePath = RqcSapConflictService.writeConfCSVReport(fileNm, userLvlConflictRoles);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	//END Individual User Download of Conflicts and Roles


	//Test Methods Designed for Nayana

	@PostMapping("/getUserSODConflictsJSON")
    public ResponseEntity<JSONRoleConfResponseDTO> searchUserLevelDetailsJSON(@RequestBody RoleSearcModel roleSearcModel, Model model, HttpServletRequest request) {
		log.info(" Received Parameters idType: "+roleSearcModel.getIdType()+" ID: "+roleSearcModel.getUserId());

		JSONRoleConfResponseDTO respDto = new JSONRoleConfResponseDTO();
    	String idToUse = "";

		if(roleSearcModel == null || roleSearcModel.getUserId() == null || roleSearcModel.getUserId().length() == 0 ) {
			return new ResponseEntity<>(getDtoJSONStatus(respDto, 1), HttpStatus.BAD_REQUEST);
		}
		idToUse = roleSearcModel.getUserId();
		List<UserSearchModel> userLst = null;
		if(roleSearcModel.getIdType() == 2) {
			userLst = userSearchService.getUserDataByNtId(roleSearcModel.getUserId(), 1);
			if(userLst != null && !userLst.isEmpty()) {
				idToUse = userLst.get(0).getWwId();
			}else {
				return new ResponseEntity<>(getDtoJSONStatus(respDto, 2), HttpStatus.BAD_REQUEST);
			}
		}else {
			userLst =  userSearchService.getUserData(1, idToUse, 1);
		}

    	try{
    		String userName = (userLst.get(0).getJnjMsftUsrnmTxt()).toUpperCase();
			String name 	= userLst.get(0).getFmlyNm()+", "+userLst.get(0).getGivenNm()+"("+userLst.get(0).getJnjMsftUsrnmTxt().toUpperCase()+")";

    		List<MatrixModel> userLvlConflictRoles = new ArrayList<>();
    		List<KeyValPair> keyLst = new ArrayList<>();
    		String roleFilePath = "";
    		String confFilePath = "";

    		List<PersonalSysModel> currentRoleList = RqcSapConflictService.getUserExistingRoles(idToUse);
    		if(currentRoleList != null && currentRoleList.size() > 1) {
    			roleFilePath = createUserLvlRoleFile("XLS", currentRoleList, userName);
    			KeyValPair curRoles = new KeyValPair();
    			curRoles.setVal("Existing Role Count");
    			curRoles.setKey(currentRoleList.size());
    			keyLst.add(curRoles);
    			respDto.setCurrentRoleList(currentRoleList);

    			String[] roleIds = RqcSapConflictService.getRoleIdsPersonalSys(currentRoleList);
    			userLvlConflictRoles = RqcSapConflictService.getUserLevelConflictingRoles(idToUse, roleIds);

    			if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
    				confFilePath = createUserLvlConflictFile("XLS", userLvlConflictRoles, userName, 0);
    				KeyValPair confRoles = new KeyValPair();
    				confRoles.setVal("Conflicting Role Count");
    				confRoles.setKey(userLvlConflictRoles.size());
        			keyLst.add(confRoles);
        			respDto.setUserLvlConflictRoles(userLvlConflictRoles);
    			}
    		}

    		log.debug("Current Roles Count: "+((currentRoleList == null || currentRoleList.isEmpty())? "0" : currentRoleList.size()));
    		log.debug("Conflicting Roles Count: "+((userLvlConflictRoles == null || userLvlConflictRoles.isEmpty())? "0" : userLvlConflictRoles.size()));

    		emailUtil.sendEmail("User Role and Conflict Details Review for - "+name,  Constants.ROLE_CONFLICT_MSG1, roleFilePath+";"+confFilePath, null);

    		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setStatusCode(Constants.SUCCESS);
			respDto.setStatusDesc("");
			respDto.setDeveloperMessage("SUCCESS");
			respDto.setStatusMsg("SUCCESS");
			respDto.setData(keyLst);

		} catch (Exception e) {
            log.error("Error getting user data :"+e.getMessage(), e);
        	e.printStackTrace();
        	respDto.setStatusCode(Constants.ERROR);
        	respDto.setStatusDesc("Exception Recorded");
        	respDto.setDeveloperMessage(e.getMessage());
        	respDto.setStatusMsg(e.getMessage());
        	return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new ResponseEntity<>(respDto, HttpStatus.OK);
    }



}
