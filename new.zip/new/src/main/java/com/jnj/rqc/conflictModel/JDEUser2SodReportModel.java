package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDEUser2SodReportModel {
	private String reviewerId;
	private String userId;
	private String fullName;
	private String srcRole;
	private String srcRoleDesc;
	private String srcObj;
	private String srcObjDesc;
	private String tgtRole;
	private String tgtRoleDesc;
	private String tgtObj;
	private String tgtObjDesc;
	private String riskLevel;
	private String mitigatingCntrl;
	private String userStatus;
}
