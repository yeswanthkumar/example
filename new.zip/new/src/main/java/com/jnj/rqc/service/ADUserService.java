package com.jnj.rqc.service;

import com.jnj.rqc.models.User;
import com.jnj.rqc.responseDto.UserNameRespDto;

public interface ADUserService {
	public User searchUserById(String userId);
	public UserNameRespDto searchUserByName(String empName);
	public User searchUserByWWID(String usrWid);

}
