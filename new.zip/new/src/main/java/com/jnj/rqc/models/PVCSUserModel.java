package com.jnj.rqc.models;

import java.util.List;

import lombok.Data;

@Data
public class PVCSUserModel {
	private String userId;
	private String fullName;
	private String wwid;
	private List<String> roles;
	private String appName;//PVCS
	private String sox;
	private String mgrWwid;
	private String mgrName;
	private String mgrEmail;
	private String empstatus;





	public String getData() {
		return  userId + "," + wwid + ","+ fullName + ","+ appName+ "," + sox
				+ ","+ mgrWwid + "," + mgrName + "," + mgrEmail + "," + empstatus ;
	}





	@Override
	public String toString() {
		return "UserModel [userId=" + userId + ", fullName=" + fullName + ", wwid=" + wwid + ", roles=" + roles
				+ ", appName=" + appName + ", sox=" + sox + ", mgrWwid=" + mgrWwid + ", mgrName=" + mgrName
				+ ", mgrEmail=" + mgrEmail + ", empstatus="+empstatus+"]";
	}
}



