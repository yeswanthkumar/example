package com.jnj.rqc.models;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class UserSearchModel {
	private String 	wwId;
	private String 	jnjMsftUsrnmTxt;   //ntId;
	private String 	givenNm;
	private String 	fmlyNm;  //
	private String 	empStatTxt; //Status
	private Date 	lastHireDt;
	private Date 	termnnDt;
	private String 	jnjEmailAddrTxt;  //email
	private String 	jnjDeptmCd;
	private String 	jnjDeptmDescnTxt;
	private String 	busnTelNo;
	private String 	locnId ;
	private String 	jnjSupvrWwId;//mgrId;
	private String  jnjSupvrName;
	private String  jnjSupvrEmail;
	private String 	posnTitlTxt;
	private String 	jobId;
	private String 	posnId;
	private String 	prefdLangTxt;
	private String 	rmNoTxt;
	private String  lglEntCatgCd;
	private String  jnjCoCd;
	private String isCompilanceMgr;

	public String getData() {
		return wwId+"~"+((jnjMsftUsrnmTxt==null)?" ":jnjMsftUsrnmTxt)+"~"+givenNm+"~"+fmlyNm+"~"+empStatTxt+"~"+((lastHireDt == null)? " ":Utility.fmtMMDDYYYY(lastHireDt))+"~"+((termnnDt == null)? " " : Utility.fmtMMDDYYYY(termnnDt))+"~"+
				((jnjEmailAddrTxt==null)?" ":jnjEmailAddrTxt)+"~"+((jnjDeptmCd==null)?" ":jnjDeptmCd)+"~"+((jnjDeptmDescnTxt == null)?" ":jnjDeptmDescnTxt)+"~"+((busnTelNo==null)?" ":busnTelNo)+"~"+((locnId==null)?" ":locnId)+"~"+ ((jnjSupvrWwId==null)?" ":jnjSupvrWwId)+
				"~"+posnTitlTxt+"~"+jobId+"~"+posnId+"~"+prefdLangTxt+"~"+rmNoTxt+"~"+lglEntCatgCd+"~"+jnjCoCd;
	}


	@Override
	public String toString() {
		return "UserSearchModel [wwId=" + wwId + ", jnjMsftUsrnmTxt=" + jnjMsftUsrnmTxt + ", givenNm=" + givenNm
				+ ", fmlyNm=" + fmlyNm + ", empStatTxt=" + empStatTxt + ", lastHireDt=" + lastHireDt + ", termnnDt="
				+ termnnDt + ", jnjEmailAddrTxt=" + jnjEmailAddrTxt + ", jnjDeptmCd=" + jnjDeptmCd
				+ ", jnjDeptmDescnTxt=" + jnjDeptmDescnTxt + ", busnTelNo=" + busnTelNo + ", locnId=" + locnId
				+ ", jnjSupvrWwId=" + jnjSupvrWwId + ", posnTitlTxt=" + posnTitlTxt + ", jobId=" + jobId + ", posnId="
				+ posnId + ", prefdLangTxt=" + prefdLangTxt + ", rmNoTxt=" + rmNoTxt + ", lglEntCatgCd=" + lglEntCatgCd
				+ ", jnjCoCd=" + jnjCoCd + "]";
	}




}
