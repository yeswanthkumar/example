package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.F9861Mdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class F9861Handler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(F9861Handler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: OBJ7333.F9861 ");
		String filePath = "";
		List<F9861Mdl> dataList = getF9861Data();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("F9861", dataList);
		}
		return filePath;
	}


	private List<F9861Mdl> getF9861Data() throws SQLException, DataAccessException{
		List<F9861Mdl> dataList = dBExtrDao.getF9861Data();
		return dataList;
	}


	private String createCSVReport(String fileName, List<F9861Mdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CCRA_CONVERSION CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String headerStr = "SIOBNM,SIMKEY,SIENHV,SIUSER,SIDM,SIJDEVERS,SIMSAR,SISTCE,SIDVP,SIMRGMOD,"+
					 			"SIMRGOPT,SIRLS,SIPATHCD, SIMODCMT,SIPID,SIJOBN, SIUPMJ, SIUPMT";
			 String [] header = headerStr.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
