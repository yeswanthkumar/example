package com.jnj.rqc.conflictModel;

import java.io.Serializable;
import java.util.List;

import com.jnj.rqc.models.KeyValPair;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmlRoleConfResponseDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	private int statusCode;
	private String statusDesc;
	private String statusMsg;
	private String datetimeStamp;
	private String developerMessage;
	private List<KeyValPair> data;
	//private UserSearchModel user;
}
