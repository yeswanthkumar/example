package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.BelmontJDAConflictService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

/**
 * File    : <b>BelmontJDASODController.java</b>
 * @author : DChauras @Created : Feb 17, 2021 2:35:04 AM
 * Purpose : SOD Controller for Belmont/JAD
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class BelmontJDASODController {
	static final Logger log = LoggerFactory.getLogger(BelmontJDASODController.class);

	@Autowired
	private BelmontJDAConflictService belmontJDAConflictService;

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	EmailUtil emailUtil;


	@GetMapping("/searchBelmontUserConflicts")
    public String loadBelmontConflictForm(Model model) {
		List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		List<KeyValPair> rlsTyps = Utility.getRoleTyp();
		model.addAttribute("rlsTyps", rlsTyps );
		//Adding Environment/System
		List<KeyValPair> envTyps = Utility.getJDAEnvironment();
		model.addAttribute("envTyps", envTyps );
		log.info("Routing to Conflict Search page.");
    	return "belmont/belmontUserConflictSearchInfo";
    }



	@PostMapping("/srchBelmontUserLvlConflicts")
    public String searchBelmontUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empId") String empId, @RequestParam("data") String data, @RequestParam("rlTyp") int rlTyp, @RequestParam("sysTyp") int sysTyp, @RequestParam("idCount") int idCount, Model model, HttpServletRequest request) {
		if(sysTyp == 0 ){
			 sysTyp = 4;//DEFAULT to PROD
		}

		String systemName = getSystemName(sysTyp);
		log.info(" Received idType: "+idType+ " WWID/NTID :"+empId+" Data:"+data+" Role Type: "+rlTyp+" System: ("+sysTyp+")"+systemName);
    	model.addAttribute("empIdParam",empId);
    	model.addAttribute("idParam", idType);
    	model.addAttribute("params",data);
    	model.addAttribute("idCntPrm",idCount);

    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );

		List<KeyValPair> rlsTyps = Utility.getRoleTyp();
		model.addAttribute("rlsTyps", rlsTyps );
		model.addAttribute("rlParam", rlTyp );

		//Adding Environment/System/Default to Production
		List<KeyValPair> envTyps = Utility.getJDAEnvironment();
		model.addAttribute("envTyps", envTyps );
		model.addAttribute("sysParam", sysTyp);


		if(!(empId != null && empId.length() > 0) && (idType != 0)) {
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Search By or User's WWID/NTID ");
            return "belmont/belmontUserConflictSearchInfo";
    	}
		if((data != null && data.length() > 0) && (rlTyp == 0)) {
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Role Type, Please select Role Type to proceed. ");
            return "belmont/belmontUserConflictSearchInfo";
    	}

		List<String>idToUse = new ArrayList<>();
		List<UserSearchModel> userLst = userSearchService.getUserData(idType, empId, 1);
		if(userLst != null && !userLst.isEmpty()) {
			for(UserSearchModel usrS : userLst) {
				idToUse.add(usrS.getWwId());
				Utility.setUser(usrS.getWwId(), usrS);
			}
		}else {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid NTID's/ID not found, Please correct the NTID/WWID and Search again.");
            return "belmont/belmontUserConflictSearchInfo";
		}
		//New Variables introduced. 10/13/2022
		String[] recdIds = empId.split(",");
		Map<String, String> usrConterMap1 = Utility.buildIDMap(recdIds);
		Map<String, String> usrConterMap2 = Utility.buildIDMap(recdIds);




    	try{
    		HttpSession session = request.getSession();
    		List<JDAPersonalSysMdl> jdaAllCurrentRoleList = new LinkedList<>();
    		List<JDAUser2SodModel> allUser2SodInternal = new LinkedList<>();
    		List<JDACrossAppMatrixModel> crossAppRoleConflictList = new LinkedList<>();
    		if(!idToUse.isEmpty()){
	    		for(String id : idToUse) {
	    			List<JDAPersonalSysMdl> jdaUserCurRlLst = null;
	    			Map<String, List<String>> newRolesMap = null;
	    			Map<String, List<String>> currentRoleMap = belmontJDAConflictService.getUserExistingRoles(id, sysTyp);
	    			String outData = "";
	        		if(data != null && data.length() > 0) {
	        			if(rlTyp == 2) {
	            			outData = belmontJDAConflictService.getRoleUFNamesToTechNames(data);
	            		}else {
	            			outData = data;
	            		}
	        			newRolesMap = belmontJDAConflictService.getMapForNewRoles(outData, sysTyp);
	        		}

	        		if(currentRoleMap != null && !currentRoleMap.isEmpty()) {
	        			jdaUserCurRlLst = belmontJDAConflictService.buildCurrentRolesData(session, currentRoleMap, Utility.getUser(id));
	        			jdaAllCurrentRoleList.addAll(jdaUserCurRlLst);
	        			log.debug("Current Roles Count for User ("+id+") : "+((jdaUserCurRlLst == null || jdaUserCurRlLst.isEmpty())? "0" : jdaUserCurRlLst.size()));
	        			//JDA (Internal) Conflicts in current roles
	            		List<JDADBRiskModel> user2SodInternal =  belmontJDAConflictService.getUserLeverConflictsJDA(currentRoleMap);
	            		if(user2SodInternal != null && !user2SodInternal.isEmpty()) {
	            			List<JDAUser2SodModel> usrSdMdlLst = belmontJDAConflictService.convertToJDAUser2SodModel(user2SodInternal, Utility.getUser(id));
	            			allUser2SodInternal.addAll(usrSdMdlLst);
	            		}
	        		}

	        		//Conflicts when new Role Added
	    			if(newRolesMap != null && !newRolesMap.isEmpty()) {
	    				List<JDADBRiskModel> user2SodInternalNewRoles = belmontJDAConflictService.getUserLeverConflictsJDA(newRolesMap);
	    				if(user2SodInternalNewRoles != null && !user2SodInternalNewRoles.isEmpty()) {
	    					List<JDAUser2SodModel> usrSdMdlLst = convertToJDAUser2SodModel(user2SodInternalNewRoles, Utility.getUser(id));
	    					allUser2SodInternal.addAll(usrSdMdlLst);
	    				}
	    			}

	    			//Evaluate CROSS-APP Conflicts from JDA Cross-App Role and Conflict Matrix.xlsx
	        		LinkedList<String> allRolesInJDA = new LinkedList<>(currentRoleMap.keySet());//All Current Roles
	        		//Get All User Roles in Other Applications
	        		List<String> otherRoles = belmontJDAConflictService.getRolesFromPersonalSystem(id);//SAP and MDM only
	        		allRolesInJDA.addAll(otherRoles);
	        		if(newRolesMap != null && !newRolesMap.isEmpty()) {
	        			allRolesInJDA.addAll(new ArrayList<>(newRolesMap.keySet()));
	        		}
	        		//Convert to USER-FRIENDLY ROLES
	        		List<String> userFriendlyList = belmontJDAConflictService.convertTechToUserFriendly(allRolesInJDA);
	        		List<JDACrossAppMatrixModel> usrCrsAppRlCnflct = belmontJDAConflictService.getCrossAppConflictDetails(id, userFriendlyList);
	        		if(usrCrsAppRlCnflct != null && !usrCrsAppRlCnflct.isEmpty()) {
	        			crossAppRoleConflictList.addAll(usrCrsAppRlCnflct);
	        		}
	        	}
    		}

    		//All JDA ROLES
    		if(jdaAllCurrentRoleList != null && !jdaAllCurrentRoleList.isEmpty()) {
    			session.setAttribute("jdaCurrentRoleList", jdaAllCurrentRoleList);
    			model.addAttribute("jdaCurrentRoleList", jdaAllCurrentRoleList);
    			String msg  = ("Total existing roles for all Users: "+jdaAllCurrentRoleList.size());
        		model.addAttribute("message", "True");
        		model.addAttribute("success" , "Status: "+msg);
    		}else {
    			String msg  = ("Total existing roles: 0, Potential invalid ID's or New User's?");
        		model.addAttribute("message", "True");
        		model.addAttribute("success" , "Status: "+msg);
    		}

    		//INTERNAL Conflicts
    		if(allUser2SodInternal != null && !allUser2SodInternal.isEmpty()) {
    			allUser2SodInternal = Utility.processFinalConfIntData(allUser2SodInternal, usrConterMap1);
    			session.setAttribute("jdaInternalConflicts", allUser2SodInternal);
    			model.addAttribute("jdaInternalConflicts", allUser2SodInternal);
    			log.debug("Current Conflicts Count: "+allUser2SodInternal.size());
        		String msg1  = ("Total Internal Conflicts: "+allUser2SodInternal.size());
        		model.addAttribute("success1", "Status: "+msg1);
        	}else {
				String msg1  = ("Total Internal Conflicts : 0 ");
        		model.addAttribute("success1", "Status: "+msg1);
			}
    		//CROSS-APPLICATION Conflicts

    		if(crossAppRoleConflictList != null && crossAppRoleConflictList.size() > 0) {
    			crossAppRoleConflictList = Utility.processFinalConfData(crossAppRoleConflictList, usrConterMap2);
    			session.setAttribute("crossAppRoleConflictList", crossAppRoleConflictList);
    			model.addAttribute("crossAppRoleConflictList", crossAppRoleConflictList);
        		String msg2  = ("Total Cross Application Conflicts : "+crossAppRoleConflictList.size()+"  -  TOTAL ID's Submitted ("+recdIds.length+")");
        		model.addAttribute("success2", "Status: "+msg2);
    		}else {
    			String msg2  = ("Total Cross Application Conflicts: 0"+"  -  TOTAL ID's Submitted ("+recdIds.length+")");
        		model.addAttribute("success2", "Status: "+msg2);
    		}
    	} catch (Exception e) {
            log.error("Error loading User Conflict Data :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "belmont/belmontUserConflictSearchInfo";
    }

	/*@PostMapping("/srchBelmontUserLvlConflicts")
    public String searchBelmontUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empId") String empId, @RequestParam("data") String data, @RequestParam("rlTyp") int rlTyp, @RequestParam("sysTyp") int sysTyp, Model model, HttpServletRequest request) {
		if(sysTyp == 0 ){
			 sysTyp = 4;//DEFAULT to PROD
		}
		String systemName = getSystemName(sysTyp);
		log.info(" Received idType: "+idType+ " WWID/NTID :"+empId+" Data:"+data+" Role Type: "+rlTyp+" System: ("+sysTyp+")"+systemName);
    	model.addAttribute("empIdParam",empId);
    	model.addAttribute("idParam", idType);
    	model.addAttribute("params",data);
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		String idToUse = "";
		String userName = "";

		List<KeyValPair> rlsTyps = Utility.getRoleTyp();
		model.addAttribute("rlsTyps", rlsTyps );
		model.addAttribute("rlParam", rlTyp );

		//Adding Environment/System/Default to Production
		List<KeyValPair> envTyps = Utility.getJDAEnvironment();
		model.addAttribute("envTyps", envTyps );
		model.addAttribute("sysParam", sysTyp);


		if(!(empId != null && empId.length() > 0) && (idType != 0)) {
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Search By or User WWID/NTID ");
            return "belmont/belmontUserConflictSearchInfo";
    	}
		if((data != null && data.length() > 0) && (rlTyp == 0)) {
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Role Type ");
            return "belmont/belmontUserConflictSearchInfo";
    	}

		List<UserSearchModel> userLst =null;
		if(idType == 2) {
			userLst = userSearchService.getUserDataByNtId(empId, 1);
			if(userLst != null && !userLst.isEmpty()) {
				idToUse = userLst.get(0).getWwId();
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}else {
				model.addAttribute("message", "True");
	            model.addAttribute("error", "Invalid NTID, Please correct the NTID and Search again.");
	            return "belmont/belmontUserConflictSearchInfo";
			}
		}else {
			idToUse = empId;
			userLst = userSearchService.getUserData(1, idToUse, 1);
			if(userLst != null && !userLst.isEmpty()) {
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}
		}

    	try{
    		HttpSession session = request.getSession();
    		String[] roleIds=null;
    		List<JDAPersonalSysMdl> jdaCurrentRoleList = null;
    		List<JDADBRiskModel> user2SodInternal = new LinkedList<JDADBRiskModel>();
    		List<JDADBRiskModel> user2SodInternalNewRoles = new LinkedList<JDADBRiskModel>();
    		Map<String, List<String>> currentRoleMap = belmontJDAConflictService.getUserExistingRoles(idToUse, session, sysTyp);
    		String outData = "";
    		if(rlTyp == 2) {
    			outData = belmontJDAConflictService.getRoleUFNamesToTechNames(data);
    		}else {
    			outData = data;
    		}
    		Map<String, List<String>> newRolesMap = belmontJDAConflictService.getMapForNewRoles(outData, session, sysTyp);

    		if(currentRoleMap != null && !currentRoleMap.isEmpty()) {
    			jdaCurrentRoleList = belmontJDAConflictService.buildCurrentRolesData(session, currentRoleMap, userLst.get(0).getJnjMsftUsrnmTxt());
    			session.setAttribute("jdaCurrentRoleList", jdaCurrentRoleList);
    			model.addAttribute("jdaCurrentRoleList", jdaCurrentRoleList);
    			log.debug("Current Roles Count: "+((jdaCurrentRoleList == null || jdaCurrentRoleList.isEmpty())? "0" : jdaCurrentRoleList.size()));
        		String msg  = ("Total existing roles: "+jdaCurrentRoleList.size());
        		model.addAttribute("message", "True");
        		model.addAttribute("success" , "Status: "+msg);

        		//JDA (Internal) Conflicts in current roles
    			user2SodInternal =  belmontJDAConflictService.getUserLeverConflictsJDA(currentRoleMap);
    		}else {
    			String msg  = ("Total existing roles: 0, Potential invalid ID or New User?");
        		model.addAttribute("message", "True");
        		model.addAttribute("success" , "Status: "+msg);
    		}

    		//Conflicts when new Role Added
			if(newRolesMap != null && !newRolesMap.isEmpty()) {
				user2SodInternalNewRoles = belmontJDAConflictService.getUserLeverConflictsJDA(newRolesMap);
				if(user2SodInternalNewRoles != null && !user2SodInternalNewRoles.isEmpty()) {
					user2SodInternal.addAll(user2SodInternalNewRoles);
				}
			}

			if(user2SodInternal != null && !user2SodInternal.isEmpty()) {
				session.setAttribute("jdaInternalConflicts", user2SodInternal);
    			model.addAttribute("jdaInternalConflicts", user2SodInternal);
    			log.debug("Current Conflicts Count: "+user2SodInternal.size());
        		String msg1  = ("Total existing Conflicts: "+user2SodInternal.size());
        		model.addAttribute("success1", "Status: "+msg1);
			}else {
				String msg1  = ("Total existing Conflicts: 0 ");
        		model.addAttribute("success1", "Status: "+msg1);
			}

    		//Evaluate CROSS-APP Conflicts from JDA Cross-App Role and Conflict Matrix.xlsx
    		List<JDACrossAppMatrixModel> crossAppRoleConflictList = new ArrayList<JDACrossAppMatrixModel>();
    		LinkedList<String> allRolesInJDA = new LinkedList<String>(currentRoleMap.keySet());//All Current Roles
    		//Get All User Roles in Other Applications
    		List<String> otherRoles = belmontJDAConflictService.getRolesFromPersonalSystem(idToUse);//SAP and MDM only
    		allRolesInJDA.addAll(otherRoles);
    		if(newRolesMap != null && !newRolesMap.isEmpty()) {
    			allRolesInJDA.addAll(new ArrayList<String>(newRolesMap.keySet()));
    		}
    		//Convert to USER-FRIENDLY ROLES
    		List<String> userFriendlyList = belmontJDAConflictService.convertTechToUserFriendly(allRolesInJDA);
    		crossAppRoleConflictList = belmontJDAConflictService.getCrossAppConflictDetails(idToUse, userFriendlyList);

    		if(crossAppRoleConflictList != null && crossAppRoleConflictList.size() > 0) {
    			session.setAttribute("crossAppRoleConflictList", crossAppRoleConflictList);
    			model.addAttribute("crossAppRoleConflictList", crossAppRoleConflictList);
        		String msg2  = ("Total Cross App Conflicts: : "+crossAppRoleConflictList.size());
        		model.addAttribute("success2", "Status: "+msg2);
    		}else {
    			String msg2  = ("Total Cross App Conflicts: : 0");
        		model.addAttribute("success2", "Status: "+msg2);
    		}
    	} catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "belmont/belmontUserConflictSearchInfo";
    }
*/

	private List<JDAUser2SodModel> convertToJDAUser2SodModel(List<JDADBRiskModel> user2SodInternalNewRoles, UserSearchModel user) {
		List<JDAUser2SodModel> sodLst = new ArrayList<>();
		for(JDADBRiskModel mdl : user2SodInternalNewRoles) {
			JDAUser2SodModel sodMdl = new JDAUser2SodModel();
			sodMdl.setWwId(user.getWwId());
			sodMdl.setRiskId(mdl.getRiskId());
			sodMdl.setRiskDesc(mdl.getRiskDesc());
			sodMdl.setRoleId(mdl.getRoleId());
			sodMdl.setRoleName(mdl.getRoleName());
			sodMdl.setFuncId(mdl.getFuncId());
			sodMdl.setFuncDesc(mdl.getFuncDesc());
			sodMdl.setRiskLevel(mdl.getRiskLevel());
			sodMdl.setRegulation(mdl.getRegulation());
			sodMdl.setTrgtCon(mdl.getTrgtCon());
			sodMdl.setMitiCntrl(mdl.getMitiCntrl());
			sodMdl.setComplMgr(mdl.getComplMgr());
			sodMdl.setRulesetGpo(mdl.getRulesetGpo());
			sodLst.add(sodMdl);
		}
		return sodLst;
	}



	private String getSystemName(int sysTyp) {
		String systemName="";
		if(sysTyp == 0 || sysTyp == 4 ) {//DEFAULT TO PRODUCTION
			sysTyp = 4;
			systemName="PRODUCTION";
		}else if(sysTyp == 1) {
			systemName="DEVELOPMENT";
		}else if(sysTyp == 2) {
			systemName="QUALITY";
		}else if(sysTyp == 3) {
			systemName="PRE-QUALITY";
		}
		return systemName;
	}



	@GetMapping("/loadBelmontConflictMatrix")
    public String loadConflicts(Model model, HttpServletRequest request) {
    	List<JDADBRiskModel> confMatrix = belmontJDAConflictService.getConflictMatrix();
    	model.addAttribute("MatrixData", confMatrix);
    	request.getSession().setAttribute("MatrixData", confMatrix);
    	String msg  = ("Total Unique Records in Conflict Matrix: "+((confMatrix != null && !confMatrix.isEmpty())? confMatrix.size():0));
		model.addAttribute("message", "True");
		model.addAttribute("success" , "Status: "+msg);
    	return "belmont/conflictMatrixBelmont";
    }

	@ResponseBody
    @GetMapping("/downLdJDACoflictMatrixExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadCoflictMatrixExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading JDA INTRA Conflict Matrix ");
		String fileNm ="JDA_INTRA_ConflictMatrix";
		List<JDADBRiskModel> confMatrix = (List<JDADBRiskModel>)request.getSession().getAttribute("MatrixData");
		String filePath = belmontJDAConflictService.writeConflictMatrixCSVReport(fileNm, confMatrix);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@GetMapping("/loadJDACrossAppConflictMatrix")
    public String loadCrossAppConflicts(Model model, HttpServletRequest request) {
    	List<JDACrossAppMatrixModel> confMatrix = belmontJDAConflictService.getCrossAppConflictMatrix();
    	model.addAttribute("message", "true");
    	model.addAttribute("success", "Total Record Count : "+confMatrix.size());
    	model.addAttribute("CrossMatrixData", confMatrix);
    	request.getSession().setAttribute("CrossMatrixData", confMatrix);
    	return "belmont/jdaCrossAppConflictMatrix";
    }


	@ResponseBody
    @GetMapping("/downldCrossAppMatrixExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downldCrossAppMatrixExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading JDA CROSS-APP Conflict Matrix ");
		String fileNm ="JDA_CROSSAPP_ConflictMatrix";
		List<JDACrossAppMatrixModel> confMatrix = (List<JDACrossAppMatrixModel>)request.getSession().getAttribute("CrossMatrixData");
		String filePath = belmontJDAConflictService.writeCrossAppMatrixCSVReport(fileNm, confMatrix);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	@GetMapping("/loadJDATechRoleNames")
    public String loadJDATechRoleNames(Model model, HttpServletRequest request) {
    	List<StrKeyValPair> techRoles = belmontJDAConflictService.getTechRoleNames();
    	model.addAttribute("message", "true");
    	model.addAttribute("success", "Total Record Count : "+techRoles.size());
    	model.addAttribute("RolesData", techRoles);
    	return "belmont/jdaTechRolesMapping";
    }


	@ResponseBody
    @GetMapping("/techRoleNamesExcel")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> downloadTechRoleNamesExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Tech Role Name Mappings ");
		String filePath = "";
		String fileNm ="JDARoleMap";
		List<StrKeyValPair> techRoles = belmontJDAConflictService.getTechRoleNames();
		filePath = belmontJDAConflictService.writeTechRoleMapCSVReport(fileNm, techRoles);

		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }





	@ResponseBody
    @GetMapping("/downloadBelmontUserLvlExcel/{type}")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> downloadUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="JDAUserRoles";
		List<JDAPersonalSysMdl> currentRoleList = null;
		List<JDAUser2SodModel> userLvlConflictRoles = null;
		List<JDACrossAppMatrixModel> crossAppRoleConflictList = null;

		if("userroles".equals(type)) {
			fileNm ="JDAUserRoles";
			currentRoleList = (List<JDAPersonalSysMdl>)request.getSession().getAttribute("jdaCurrentRoleList");
			filePath = belmontJDAConflictService.writeUserRoleCSVReport(fileNm, currentRoleList);
		}else if("usrConf".equals(type)){
			fileNm ="JDAIntraRoleConflict";
			userLvlConflictRoles = (List<JDAUser2SodModel>)request.getSession().getAttribute("jdaInternalConflicts");
			filePath = belmontJDAConflictService.writeConfCSVReport(fileNm, userLvlConflictRoles);
		}else {
			fileNm ="JDACrossAppConflicts";
			crossAppRoleConflictList = (List<JDACrossAppMatrixModel>)request.getSession().getAttribute("crossAppRoleConflictList");
			filePath = belmontJDAConflictService.writeCrossAppConfCSVReport(fileNm, crossAppRoleConflictList);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }














	//Multi User Role Review

		@GetMapping("/reviewBelmontMultiUser")
	    public String multiUserRoleForm(Model model) {
	    	log.info("Routing to Multi-User Role Review page.");
	    	List<KeyValPair> userIdValue = Utility.getIdParams();
			model.addAttribute("idVal", userIdValue );
	    	return "belmont/multiUserRoleReviewbelmont";
	    }


	/*	@PostMapping("/srchBelmontMultiUserRoles")
	    public String searchMultiUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empIds") String empIds, Model model, HttpServletRequest request){
			log.info("idType: "+idType+" empIds: "+empIds);
			List<KeyValPair> userIdValue = Utility.getIdParams();
			model.addAttribute("idVal", userIdValue );
			model.addAttribute("empIdParams",empIds);
			model.addAttribute("idTParam", idType);
			if(idType == 0 || empIds == null || empIds.length() == 0) {
	    		log.info("Missing required Data");
	            model.addAttribute("message", "True");
	            model.addAttribute("error", "Missing required values: Search By/WWID/NTID ");
	            return "belmont/multiUserRoleReviewbelmont";
	    	}
			List<String>idToUse = new ArrayList<String>();
			if(idType == 2) {
				List<UserSearchModel> userLst = userSearchService.getUserData(2, empIds, 1);
				if(userLst != null && !userLst.isEmpty()) {
					for(UserSearchModel item : userLst){
						idToUse.add(item.getWwId());
					};
				}else {
					model.addAttribute("message", "True");
		            model.addAttribute("error", "Invalid NTID's, Please correct the NTID and Search again.");
		            return "belmont/multiUserRoleReviewbelmont";
				}
			}else {
				idToUse = Arrays.asList(empIds.split(","));
			}

			try{
				Map<String, List<MatrixModel>> userLvlConfRlsMaps = new HashMap<String, List<MatrixModel>>();
				Map<String, List<JDAPersonalSysMdl>> curRoleMap = belmontJDAConflictService.getMultiUserExistingRoles(idToUse);

	    		HttpSession session = request.getSession();
	    		if(curRoleMap != null && !curRoleMap.isEmpty()) {
	    			session.setAttribute("curRoleMap", curRoleMap);
	        		model.addAttribute("curRoleMap", curRoleMap);
	        		model.addAttribute("message", "True");
	        	}

	    		if(curRoleMap != null && curRoleMap.size() > 1) {
	    			for (Map.Entry<String, List<JDAPersonalSysMdl>> entry : curRoleMap.entrySet()) {
	    				String[] roleIds = belmontJDAConflictService.getRoleIdsPersonalSys(entry.getValue());
	        			List<MatrixModel> confList = belmontJDAConflictService.getUserLevelConflictingRoles(entry.getKey(), roleIds);
	        			if(confList != null && !confList.isEmpty()) {
	        				userLvlConfRlsMaps.put(entry.getKey(), confList);
	        			}
	        		}
	    		}
	    		if(userLvlConfRlsMaps != null && !userLvlConfRlsMaps.isEmpty()) {
	    			session.setAttribute("curUserConflicts", userLvlConfRlsMaps);
	        		model.addAttribute("curUserConflicts", userLvlConfRlsMaps);
	    		}

	    		model.addAttribute("success", "Status: Count of total users found : "+((curRoleMap == null || curRoleMap.isEmpty())? "0" : curRoleMap.size()));
	    		model.addAttribute("success1", "Status: Count of total users found : "+((userLvlConfRlsMaps == null || userLvlConfRlsMaps.isEmpty())? "0" : userLvlConfRlsMaps.size()));
	    	} catch (Exception e) {
	            log.error("Error uploading file :"+e.getMessage(), e);
	        	e.printStackTrace();
	        }
	        return "belmont/multiUserRoleReviewbelmont";
	    }

		@ResponseBody
	    @GetMapping("/downloadBelmontMultiUserLvlExcel/{type}")
	    @SuppressWarnings("all")
		public ResponseEntity<InputStreamResource> downloadMultiUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
			log.info("Path Variable received :"+ type);
			String filePath = "";
			String fileNm ="BelmontUserRolesList";
			Map<String,List<PersonalSysModel>> currentRoleMap = null;;
			Map<String, List<MatrixModel>> userLvlConflictMap = null;
			if("userroles".equals(type)) {
				fileNm ="BelmontUserRolesList";
				currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
				filePath = belmontJDAConflictService.writeMultiUserRolePDFCSVReport("CSV", fileNm, currentRoleMap);
			}else {
				fileNm ="BelmontUserRolesConflictList";
				userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
				filePath = belmontJDAConflictService.writeMultiConfPDFCSVReport("CSV", fileNm, userLvlConflictMap);
			}
			File fl = new File(filePath);
	    	log.info("Download File name:"+fl.getName());
	    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
	    	return ResponseEntity.ok()
	    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	        	.contentType(MediaType.TEXT_PLAIN)
	        	.contentLength(fl.length())
	        	.body(resource);
	    }


		@ResponseBody
	    @GetMapping("/dwnMultiBelmontUserLvlPDF/{type}")
		@SuppressWarnings("all")
	    public ResponseEntity<InputStreamResource> dwnMultiUserConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
			log.info("Path Variable received :"+ type);
			String filePath = "";
			String fileNm ="BelmontUserRolesList";
			Map<String,List<PersonalSysModel>> currentRoleMap = null;;
			Map<String, List<MatrixModel>> userLvlConflictMap = null;
			if("userroles".equals(type)) {
				fileNm ="BelmontUserRolesList";
				currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
				filePath = belmontJDAConflictService.writeMultiUserRolePDFCSVReport("PDF", fileNm, currentRoleMap);
			}else {
				fileNm ="BelmontUserRolesConflictList";
				userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
				filePath = belmontJDAConflictService.writeMultiConfPDFCSVReport("PDF", fileNm, userLvlConflictMap);
			}
			File fl = new File(filePath);

	    	log.info("Download File name:"+fl.getName());
	    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
	    	return ResponseEntity.ok()
	    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	        	.contentType(MediaType.TEXT_PLAIN)
	        	.contentLength(fl.length())
	        	.body(resource);
	    }

		@GetMapping("/searchBelmontSystemCodesPage")
	    public String searchSystemCodes(Model model) {
	    	List<String> sysCodes = Utility.getSystemNameList();
	    	Collections.sort(sysCodes);
	    	model.addAttribute("sysCodes", sysCodes);
	    	model.addAttribute("system","0");
	    	return "belmont/systemCodesBelmont";
	    }

		@PostMapping("/getBelmontSystemCodes")
	    public String getSystemCodes(@RequestParam("system") String system, Model model, HttpServletRequest request) {
			log.info("Selected System : "+system);
	    	model.addAttribute("system",system);
	    	List<String> sysCodes = Utility.getSystemNameList();
	    	Collections.sort(sysCodes);
	    	model.addAttribute("sysCodes", sysCodes);

			try{
				HttpSession session = request.getSession();
				List<SystemCodeModel> sysCdList = Utility.getSystemCodeList(system);
				session.setAttribute("sysCdList", sysCdList);
				model.addAttribute("sysCdList", sysCdList);
	    		model.addAttribute("message", "True");
	    		log.debug("System Codes size : "+((sysCdList==null)?  "0":sysCdList.size()));
	    		model.addAttribute("success", "Status: Search successful for System Codes... total records : "+((sysCdList == null)?  "0":sysCdList.size()));
	    	} catch (Exception e) {
	            log.error("Error getting system codes :"+e.getMessage(), e);
	        	e.printStackTrace();
	        }
	        return "belmont/systemCodesBelmont";
	    }

		@ResponseBody
	    @GetMapping("/downloadBelmontSysCodeExcel")
		@SuppressWarnings("all")
	    public ResponseEntity<InputStreamResource> downloadSysCodeExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
			log.info("Downloading SysCodes ");
			String fileNm ="BelmontJDASystemCodes";
			List<SystemCodeModel> sysCdLst = (List<SystemCodeModel>)request.getSession().getAttribute("sysCdList");
			String filePath = belmontJDAConflictService.writeSystemCodeCSVReport(fileNm, sysCdLst);
	    	File fl = new File(filePath);
	    	log.info("Download File name:"+fl.getName());
	    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
	    	return ResponseEntity.ok()
	    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	        	.contentType(MediaType.TEXT_PLAIN)
	        	.contentLength(fl.length())
	        	.body(resource);
	    }

	*/

	/*
	@ResponseBody
    @GetMapping("/downloadCurConfExcel/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm ="ExistingAndRequestedRoleConflicts";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}


		String filePath = RqcSapConflictService.writeConfCSVReport(fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadCurConfPDF/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		String title="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested.pdf";
			title="Requested New Role(s) SOD Conflicts with each other";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm = "ExistingAndRequestedRoleConflicts.pdf";
			title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}
		String filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


 @GetMapping("/getUserConflicts")
    public ResponseEntity<List<ConflictResponseDTO>> getUserConflicts() {
        log.info("Conflict List");

        List<ConflictResponseDTO> list = new ArrayList<ConflictResponseDTO>();
        ConflictResponseDTO dto = new ConflictResponseDTO();
        dto.setTimeStamp(new Date());
        list.add(dto);

        return new ResponseEntity<List<ConflictResponseDTO>>(list, HttpStatus.OK);
    }



	//Multi User Role Review



*/

	/***New Methods Designed to send User Leve Roles/Conflicts Info to Email***/


	//emailUtil.sendEmail("User Role and Conflict Details Review for - "+name,  Constants.ROLE_CONFLICT_MSG1, roleFilePath+";"+confFilePath, null);


   /* @GetMapping("/getUserEmailDetails")
	@SuppressWarnings("all")
    public String getUserEmailDetails(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Path Variable received ");
		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", '0');
		return "conflictcheck/sendEmail";
    }


	@PostMapping("/sendUserDataEmail")
	@SuppressWarnings("all")
    public String sendUserDataEmail(@RequestParam("txtEmailToAddress") String txtEmailToAddress, @RequestParam("txtEmailFromAddress") String txtEmailFromAddress, @RequestParam("txtEmailSubject") String txtEmailSubject, @RequestParam("dataType") String dataType,RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Variable received \n txtEmailToAddress :"+txtEmailToAddress+"\n txtEmailFromAddress :"+txtEmailFromAddress+"\n txtEmailSubject : "+txtEmailSubject+"\n dataType : "+dataType);

		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		emlInfo.setTo(txtEmailToAddress);
		emlInfo.setSubject(txtEmailSubject);
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", dataType);

		String roleFileNm ="";
		String confFileNm ="";
		String newConfFileNm ="";

		String roleFilePath = "";
		String confFilePath = "";
		String newConfFilePath = "";
		try {
			List<PersonalSysModel> currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			List<MatrixModel> userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			List<MatrixModel> newRoleConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			//PDF Generation
			if("PDF".equals(dataType)) {
				if(currentRoleList != null && !currentRoleList.isEmpty()) {
					roleFileNm 		="UserRolesList.pdf";
					roleFilePath	= RqcSapConflictService.writeUserRolePDFReport(roleFileNm, currentRoleList);
				}

				if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
					confFileNm ="UserRolesConflictList.pdf";
					String title = "User level SOD Conflicts between Application Role(s)";
					confFilePath = RqcSapConflictService.writeConfPDFReport(title, confFileNm, userLvlConflictRoles);
				}

				if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
					newConfFileNm ="NewRolesConflictList.pdf";
					String title = "User level SOD Conflicts between New Application Role(s)";
					newConfFilePath = RqcSapConflictService.writeConfPDFReport(title, newConfFileNm, newRoleConflictRoles);
				}
			}else {
				if(currentRoleList != null && !currentRoleList.isEmpty()) {
					roleFileNm ="UserRolesList";
					roleFilePath = RqcSapConflictService.writeUserRoleCSVReport(roleFileNm, currentRoleList);
				}
				if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
					confFileNm ="UserRolesConflictList";
					confFilePath = RqcSapConflictService.writeConfCSVReport(confFileNm, userLvlConflictRoles);
				}
				if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
					newConfFileNm ="NewRolesConflictList";
					newConfFilePath = RqcSapConflictService.writeConfCSVReport(newConfFileNm, newRoleConflictRoles);
				}

			}

			String fileLocations ="";
			if(currentRoleList != null && !currentRoleList.isEmpty()) {
				fileLocations = roleFilePath;
			}
			if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+confFilePath;
				}
			}

			if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+newConfFilePath;
				}
			}

			model.addAttribute("message", "True");
			emailUtil.sendEmail(txtEmailSubject,  Constants.ROLE_CONFLICT_MSG1, fileLocations, null, txtEmailToAddress, txtEmailFromAddress);

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage(), e);
			model.addAttribute("error : Failure sending email", e.getMessage());
			return "conflictcheck/sendEmail";
		}
		model.addAttribute("success", "User Role/Conflict review email send successfully ("+dataType+").....!");
    	return "conflictcheck/sendEmail";
    }

	@GetMapping("/getUserConfEmailDetails")
	@SuppressWarnings("all")
    public String getUserConfEmailDetails(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Path Variable received :");
		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", '0');
		return "conflictcheck/sendEmailNewRoles";
    }

	@PostMapping("/sendUserConfDataEmail")
	@SuppressWarnings("all")
    public String sendUserConfDataEmail(@RequestParam("txtEmailToAddress") String txtEmailToAddress, @RequestParam("txtEmailFromAddress") String txtEmailFromAddress, @RequestParam("txtEmailSubject") String txtEmailSubject, @RequestParam("dataType") String dataType,RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Variable received \n txtEmailToAddress :"+txtEmailToAddress+"\n txtEmailFromAddress :"+txtEmailFromAddress+"\n txtEmailSubject : "+txtEmailSubject+"\n dataType : "+dataType);

		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		emlInfo.setTo(txtEmailToAddress);
		emlInfo.setSubject(txtEmailSubject);
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", dataType);

		String newRolesConfFile ="";
		String newRolesConfFilePath = "";

		String newAndExtngConfFile="";
		String newAndExtngConfFilePath = "";
		try {

			//List<PersonalSysModel> currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			List<MatrixModel> curRoleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
			List<MatrixModel> newRoleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			List<String>invldRls = (List<String>)request.getSession().getAttribute("invldRls");
			//PDF Generation

			if("PDF".equals(dataType)) {
				if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
					newAndExtngConfFile	="ExistingAndRequestedRoleConflicts.pdf";
					String title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
					newAndExtngConfFilePath	= RqcSapConflictService.writeConfPDFReport(title, newAndExtngConfFile, curRoleConflictList);
				}

				if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
					newRolesConfFile ="ConflictsInRolesRequested.pdf";
					String title = "Requested New Role(s) SOD Conflicts with each other";
					newRolesConfFilePath = RqcSapConflictService.writeConfPDFReport(title, newRolesConfFile, newRoleConflictList);
				}
			}else {
				if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
					newAndExtngConfFile ="ExistingAndRequestedRoleConflicts";
					newAndExtngConfFilePath = RqcSapConflictService.writeConfCSVReport(newAndExtngConfFile, curRoleConflictList);
				}
				if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
					newRolesConfFile ="ConflictsInRolesRequested";
					newRolesConfFilePath = RqcSapConflictService.writeConfCSVReport(newRolesConfFile, newRoleConflictList);
				}
			}

			String fileLocations ="";
			if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
				fileLocations = newAndExtngConfFilePath;
			}
			if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+newRolesConfFilePath;
				}
			}
			model.addAttribute("message", "True");
			emailUtil.sendEmail(txtEmailSubject,  Constants.ROLE_CONFLICT_MSG1, fileLocations, invldRls, txtEmailToAddress, txtEmailFromAddress);

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage(), e);
			model.addAttribute("error : Failure sending email", e.getMessage());
			return "conflictcheck/sendEmailNewRoles";
		}
		model.addAttribute("success", "User Role/Conflict review email send successful.....!");
    	return "conflictcheck/sendEmailNewRoles";
    }

*/
	/*	@GetMapping("/rqcSapConflictInfo")
    public String loadConflictForm(Model model) {
    	log.info("Routing to Conflict Test page.");
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
    	return "conflictcheck/conflictInfo";
    }


	@PostMapping("/newUserRoleConflicts")
    public String searchUserDetails(@RequestParam("idType") int idType, @RequestParam("empId") String empId,  @RequestParam("data") String data, Model model, HttpServletRequest request) {
		log.info("EMPID :"+empId+"  idType: "+idType+"   Data:"+data);
    	model.addAttribute("empIdParam",empId);
    	model.addAttribute("params",data);
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		model.addAttribute("idParam", idType);

		if(!(empId != null && empId.length() > 0) || (idType == 0) || StringUtils.isEmpty(data)) {
			log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values : "+((idType == 0)?"Search By":(empId == null || empId.length()==0) ? " WWID/NTID ": " Role Names" ));
            return "conflictcheck/conflictInfo";
    	}

		try{
			Map<String, List<String>> sysCdMap = RqcSapConflictService.getSystemCodes(data);
			List<String> sodCds = sysCdMap.get("SYSCDLST");
			List<String> invldRls = sysCdMap.get("INVLDLST");
			String[] dataArr = sodCds.toArray(new String[sodCds.size()]);

			String idToUse = "";
			String userName ="";
			if(idType == 2) {
				List<UserSearchModel> userLst = userSearchService.getUserDataByNtId(empId, 1);
				if(userLst != null && !userLst.isEmpty()) {
					idToUse = userLst.get(0).getWwId();
					userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
				}else {
					model.addAttribute("message", "True");
		            model.addAttribute("error", "Invalid NTID, Please correct the NTID and Search again.");
		            return "conflictcheck/conflictInfo";
				}
			}else {
				idToUse = empId;
				List<UserSearchModel> userLst = userSearchService.getUserData(1, idToUse, 1);
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}
			List<MatrixModel> curRoleConflictList = RqcSapConflictService.getCurConflictDetails(idToUse, dataArr);
    		List<MatrixModel> newRoleConflictList = RqcSapConflictService.getNewConflictDetails(idToUse, dataArr);

    		HttpSession session = request.getSession();
    		session.setAttribute(Constants.ACTIVE_USER, userName);
    		//Ensure Cache data is removed
    		if(session.getAttribute("curRoleConflictList") != null) {
    			session.removeAttribute("curRoleConflictList");
    		}
    		if(session.getAttribute("newRoleConflictList") != null) {
    			session.removeAttribute("newRoleConflictList");
    		}
    		//END
    		if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
    			session.setAttribute("curRoleConflictList", curRoleConflictList);
    			model.addAttribute("curRoleConflictList", curRoleConflictList);
    		}

    		if(newRoleConflictList!= null && !newRoleConflictList.isEmpty()) {
    			session.setAttribute("newRoleConflictList", newRoleConflictList);
    			model.addAttribute("newRoleConflictList", newRoleConflictList);
    		}

    		if(invldRls != null && !invldRls.isEmpty()) {
    			session.setAttribute("invldRls", invldRls);
    			model.addAttribute("invldRls", invldRls.toString());
    		}
    		model.addAttribute("message", "True");
    		log.debug("Conflicts with Existing Roles : "+((curRoleConflictList==null)?  "0":curRoleConflictList.size()));
    		log.debug("Conflicts within new Roles : "+((newRoleConflictList==null)?  "0":newRoleConflictList.size()));

    		String msg  = "Status: Conflicts with existing roles: "+ ((curRoleConflictList == null || curRoleConflictList.isEmpty() ) ?  "0": curRoleConflictList.size()+"");
    		String msg1 = "Status: Conflicts within New roles: "+((newRoleConflictList == null || newRoleConflictList.isEmpty()) ? "0" : newRoleConflictList.size()+"");
    		model.addAttribute("success", msg);
    		model.addAttribute("success1", msg1);
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/conflictInfo";
    }

*/


}
