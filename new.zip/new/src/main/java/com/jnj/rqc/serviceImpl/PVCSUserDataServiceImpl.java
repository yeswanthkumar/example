package com.jnj.rqc.serviceImpl;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.UserRole;
import com.jnj.rqc.service.PVCSUserDataService;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>PVCSUserExtract.java</b>
 * @author : DChauras @Created : Apr 26, 2019 11:42:53 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class PVCSUserDataServiceImpl implements PVCSUserDataService {

	static final Logger log = LoggerFactory.getLogger(PVCSUserDataServiceImpl.class);

	@Override
	public List<UserRole> createUserCSV(Path filePath,  HttpSession session) {
		Map<String, List<String>> userRoleMap = readPVCSUserData(filePath);
		String targetFile = filePath.getFileName().toString();
		targetFile = targetFile.substring(0, targetFile.lastIndexOf("."));
		String outFilePath = Constants.PVCS_OUT_LOC+targetFile+"_"+Utility.fmtMDY(new Date())+".csv";
		List<UserRole> UserToRole = new ArrayList<>();//List for Printing on Screen
		try {
			File out = new File(outFilePath);
			StringBuilder sb = new StringBuilder();
			userRoleMap.forEach((user, roles)-> {
				UserRole usr = new UserRole();
				usr.setUserName(user);
				List<String>rlList = new ArrayList<>();
				roles.forEach(role ->{
					rlList.add(role);
					sb.append(user+","+role+"\r\n");
				});
				usr.setRoles(rlList);
				UserToRole.add(usr);
			});
			sb.append("\n");
			FileUtils.writeStringToFile(out, sb.toString(), "utf-8");
			//Session
			session.setAttribute("PVCSUserFile", outFilePath);
		} catch (Exception e) {
			log.error("ERROR writing CSV:"+outFilePath+"\nMessage: "+e.getMessage());
			e.printStackTrace();
		}
		return UserToRole;
	}



	/**
	 * Method  : PVCSUserDataServiceImpl.java.readPVCSUserData()
	 *		   :<b>@param filePath
	 * @author : DChauras  @Created :May 7, 2019 11:09:01 AM
	 * Purpose : Reads the Uploaded file, and creates Map of UserName to List of Roles
	 * @return : Map<String,List<String>>
	 */
	@Override
	public Map<String, List<String>> readPVCSUserData(Path filePath){
		log.info("Reading PVCS User File: "+filePath);

		List<String> result = new ArrayList<>();
		Map<String, List<String>> usrRlMap = new HashMap<>();
		try {
			List<String> lines = FileUtils.readLines(filePath.toFile(), "utf-8");
			result = lines.stream()
					.filter(ln -> !"".equals(ln.trim())) 		//Removing all BLANK Lines
					.map(s -> s.replaceAll(" ", "").toUpperCase())
					.collect(Collectors.toList());
			result.remove(0); //Removing the Header ROW

			String dbID = "";
			for(String str:result) {
				if(str.startsWith("PROJECTDATABASE")){
					dbID = getDBId(str);
					continue;
				}
				str = (str.substring(5)).replaceAll("\"", "");
				String[] data = str.split("\\|");
				String usrId = "";
				List<String> roleList = new ArrayList<>();
				if(data != null && data.length > 0) {
					usrId = data[0];
					roleList = getRole(dbID, data);
					if(usrRlMap.containsKey(usrId)) {
						List<String> tmp = usrRlMap.get(usrId);
						tmp.addAll(roleList);
						usrRlMap.put(usrId, tmp);
					}else {
						usrRlMap.put(usrId, roleList);
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Error reading User Data :"+e.getMessage());
			e.printStackTrace();
		}
		//System.out.println("Total Number of PVCS USERS :"+usrRlMap.size());
		return usrRlMap;
	}


	private String getDBId(String str) {
		String dbId = str.substring((str.lastIndexOf("\\")+1), str.indexOf("("));
		return dbId;
	}

	private List<String> getRole(String dbID, String[] data){
		List<String> rlLst = new ArrayList<>();
		if(data != null && data.length > 1){
			for(int i=1; i<data.length; i++) {
				if(Utility.getRole(data[i]) != null) {
					rlLst.add(dbID+"_"+Utility.getRole(data[i]));
				}
			}
		}
		return rlLst;
	}


}
