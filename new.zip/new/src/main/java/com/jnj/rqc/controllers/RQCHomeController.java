package com.jnj.rqc.controllers;


import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.User;
import com.jnj.rqc.service.UserMenuService;


@Controller
public class RQCHomeController {
	static final Logger log = LoggerFactory.getLogger(RQCHomeController.class);


	@Autowired
	UserMenuService userMenuService;

	@RequestMapping(value = {"/","/index","/login"})
	public String login(Model model, HttpServletRequest request ) {
		log.info("Routing to login.html");
		String pageFwd="login";
		if(request.getSession(false) != null && request.getSession(false).getAttribute(Constants.AUTH_USER) != null &&
			request.getSession(false).getAttribute(Constants.USER_VALIDATED).equals("Y")) {
			pageFwd= "home";
		}
		return pageFwd;
	}

	@RequestMapping(value = {"/displayError"})
	public String error(Model model, HttpServletRequest request ) {
		log.info("Routing to login.html");
		return "displayError";
	}


	@RequestMapping(value = {"/home"})
	public String home(Model model, HttpServletRequest request, HttpServletResponse response ) {
		log.info("Routing to home.html");
		//Added session validation
		/*if(request.getSession(false) == null || request.getSession(false).getAttribute(Constants.AUTH_USER) == null ||
				!request.getSession(false).getAttribute(Constants.USER_VALIDATED).equals("Y")) {
				return "logout";
		}*/
		List<String> headerMenu = userMenuService.getUserHeaderMenus("", "", request);
		String menuString = "";
		for(String menu:headerMenu) {
			menuString+=menu+"\n";
		}
		request.getSession().setAttribute("HEADER_MENU", menuString);
		model.addAttribute("HEADER_MENU", menuString);

		//COOKIE SETTINGS
		if(request.getSession(false) != null && request.getSession(false).getAttribute("TEST_COOKIE") != null) {
			Cookie cookie = (Cookie)request.getSession(false).getAttribute("TEST_COOKIE");
			cookie.setMaxAge(60*60*1000);
			cookie.setSecure(true);
			//cookie.setHttpOnly(true);
			cookie.setPath("/");
			response.addCookie(cookie);
			request.getSession(false).removeAttribute("TEST_COOKIE");
		}

		//return "homeOrg";
		return "home";
	}

	@RequestMapping(value = "/homeOrg/{subMenu}")
	public String homeOgr(@PathVariable String subMenu, Model model, HttpServletRequest request) {
		log.info("Getting Sub Menus for :"+subMenu);
		//TODO - Add session validation
		/*
		  CHECK USER VALIDATED
		  */

		List<String> sideNavLst = userMenuService.getUserSideNavMenus("", "", subMenu, request);
		String subNavStr = "";
		for(String menu:sideNavLst) {
			subNavStr+=menu+"\n";
		}
		request.getSession().setAttribute("SUB_MENU", subNavStr);
		model.addAttribute("SUB_MENU", subNavStr);
		model.addAttribute("HEADER_MENU", request.getSession().getAttribute("HEADER_MENU"));
		if("USERS".equals(subMenu)) {
			//List<String> regNames = Utility.loadUserProperty("REGION");
	    	//model.addAttribute("regNames", regNames );
	    	model.addAttribute("AUTH_USER", request.getSession().getAttribute(Constants.AUTH_USER));
			return "useridm/personalInfoMenu";
		}else {
			return "homeOrg";
		}

	}

	@RequestMapping(value = {"/logout"})
	public String logout(Model model, HttpServletRequest request ) {
		HttpSession session = request.getSession(false);
		if(session!=null){
			session.invalidate();
		}
		return "login";
	}




	@RequestMapping(value = "/app")
	public String app(User user) {
		log.info("Routing to appLayout.html");
		//return "login";
		return "appLayout";
	}

	@RequestMapping(value = "/contact")
	public String contactUs() {
		log.info("Routing to contact.html");
		//return "login";
		return "contact";
	}


}
