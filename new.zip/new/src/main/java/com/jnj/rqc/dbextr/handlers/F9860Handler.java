package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.F9860Mdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class F9860Handler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(F9860Handler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: OBJ7333.F9860 ");
		String filePath = "";
		List<F9860Mdl> dataList = getF9860Data();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("F9860", dataList);
		}
		return filePath;
	}


	private List<F9860Mdl> getF9860Data() throws SQLException, DataAccessException{
		List<F9860Mdl> dataList = dBExtrDao.getF9860Data();
		return dataList;
	}


	private String createCSVReport(String fileName, List<F9860Mdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CCRA_CONVERSION CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String headerStr = "SIOBNM,SIMD,SISY,SISYR,SIFUNO,SIFUNU,SIPFX,SISRCLNG,SIANSIF,SICATO,SICLDF,SICPYD,SIOMIT,SIOPDF,SIAPPLID,SICURTYP,SIBFLOCN,SIGBOPTN,SIGTFILE,"+
					 			"SIGTTYPE,SIGTFFU1,SIJDETEXT,SIPROPID,SIMID1,SIBASE,SIPARDLL,SIPAROBN,SIPKGCOL,SIOLCD01,SIOLCD02,SIOLCD03,SIOLCD04,SIOLCD05,SIPID,SIUSER," +
					 			"SIJOBN,SIUPMJ, SIUPMT";
			 String [] header = headerStr.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
