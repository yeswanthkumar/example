package com.jnj.rqc.conflictModel;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapUser2SodReportMdl_OLD {
	private String 	reviewName;
	private String 	sapPlatform;
	private String 	sapSystem;
	private String 	description;
	private String  otherInfo3;
	private String  accountName;
	private String  accountOwnerName;
	private String  accountOwnerWwid;
	private String  accountOwnerTitle;
	private String  designatedReviewer;
	private String  designatedReviewerWwid;
	private String  reviewedByName;
	private String  reviewedByWwid;
	private Date  	dateGenerated;
	private Date  	dateReviewed;
	private String  reviewStatus;
	private String  reviewerComments;
	private Date 	dateEntered;

	@Override
	public String toString() {
		return "SapUser2SodReportMdl [reviewName=" + reviewName + ", sapPlatform=" + sapPlatform + ", sapSystem="
				+ sapSystem + ", description=" + description + ", otherInfo3=" + otherInfo3 + ", accountName="
				+ accountName + ", accountOwnerName=" + accountOwnerName + ", accountOwnerWwid=" + accountOwnerWwid
				+ ", accountOwnerTitle=" + accountOwnerTitle + ", designatedReviewer=" + designatedReviewer
				+ ", designatedReviewerWwid=" + designatedReviewerWwid + ", reviewedByName=" + reviewedByName
				+ ", reviewedByWwid=" + reviewedByWwid + ", dateGenerated=" + dateGenerated + ", dateReviewed="
				+ dateReviewed + ", reviewStatus=" + reviewStatus + ", reviewerComments=" + reviewerComments
				+ ", dateEntered=" + dateEntered + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		SapUser2SodReportMdl_OLD other = (SapUser2SodReportMdl_OLD) obj;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (accountOwnerName == null) {
			if (other.accountOwnerName != null)
				return false;
		} else if (!accountOwnerName.equals(other.accountOwnerName))
			return false;
		if (accountOwnerTitle == null) {
			if (other.accountOwnerTitle != null)
				return false;
		} else if (!accountOwnerTitle.equals(other.accountOwnerTitle))
			return false;
		if (accountOwnerWwid == null) {
			if (other.accountOwnerWwid != null)
				return false;
		} else if (!accountOwnerWwid.equals(other.accountOwnerWwid))
			return false;
		if (dateEntered == null) {
			if (other.dateEntered != null)
				return false;
		} else if (!dateEntered.equals(other.dateEntered))
			return false;
		if (dateGenerated == null) {
			if (other.dateGenerated != null)
				return false;
		} else if (!dateGenerated.equals(other.dateGenerated))
			return false;
		if (dateReviewed == null) {
			if (other.dateReviewed != null)
				return false;
		} else if (!dateReviewed.equals(other.dateReviewed))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (designatedReviewer == null) {
			if (other.designatedReviewer != null)
				return false;
		} else if (!designatedReviewer.equals(other.designatedReviewer))
			return false;
		if (designatedReviewerWwid == null) {
			if (other.designatedReviewerWwid != null)
				return false;
		} else if (!designatedReviewerWwid.equals(other.designatedReviewerWwid))
			return false;
		if (otherInfo3 == null) {
			if (other.otherInfo3 != null)
				return false;
		} else if (!otherInfo3.equals(other.otherInfo3))
			return false;
		if (reviewName == null) {
			if (other.reviewName != null)
				return false;
		} else if (!reviewName.equals(other.reviewName))
			return false;
		if (reviewStatus == null) {
			if (other.reviewStatus != null)
				return false;
		} else if (!reviewStatus.equals(other.reviewStatus))
			return false;
		if (reviewedByName == null) {
			if (other.reviewedByName != null)
				return false;
		} else if (!reviewedByName.equals(other.reviewedByName))
			return false;
		if (reviewedByWwid == null) {
			if (other.reviewedByWwid != null)
				return false;
		} else if (!reviewedByWwid.equals(other.reviewedByWwid))
			return false;
		if (reviewerComments == null) {
			if (other.reviewerComments != null)
				return false;
		} else if (!reviewerComments.equals(other.reviewerComments))
			return false;
		if (sapPlatform == null) {
			if (other.sapPlatform != null)
				return false;
		} else if (!sapPlatform.equals(other.sapPlatform))
			return false;
		if (sapSystem == null) {
			if (other.sapSystem != null)
				return false;
		} else if (!sapSystem.equals(other.sapSystem))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = prime * result + ((accountOwnerName == null) ? 0 : accountOwnerName.hashCode());
		result = prime * result + ((accountOwnerTitle == null) ? 0 : accountOwnerTitle.hashCode());
		result = prime * result + ((accountOwnerWwid == null) ? 0 : accountOwnerWwid.hashCode());
		result = prime * result + ((dateEntered == null) ? 0 : dateEntered.hashCode());
		result = prime * result + ((dateGenerated == null) ? 0 : dateGenerated.hashCode());
		result = prime * result + ((dateReviewed == null) ? 0 : dateReviewed.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((designatedReviewer == null) ? 0 : designatedReviewer.hashCode());
		result = prime * result + ((designatedReviewerWwid == null) ? 0 : designatedReviewerWwid.hashCode());
		result = prime * result + ((otherInfo3 == null) ? 0 : otherInfo3.hashCode());
		result = prime * result + ((reviewName == null) ? 0 : reviewName.hashCode());
		result = prime * result + ((reviewStatus == null) ? 0 : reviewStatus.hashCode());
		result = prime * result + ((reviewedByName == null) ? 0 : reviewedByName.hashCode());
		result = prime * result + ((reviewedByWwid == null) ? 0 : reviewedByWwid.hashCode());
		result = prime * result + ((reviewerComments == null) ? 0 : reviewerComments.hashCode());
		result = prime * result + ((sapPlatform == null) ? 0 : sapPlatform.hashCode());
		result = prime * result + ((sapSystem == null) ? 0 : sapSystem.hashCode());
		return result;
	}









}

