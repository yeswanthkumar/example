package com.jnj.rqc.mastermetadata.controller;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportStats {
	private String sysName;
	private List<SysNameWiseStats> sysNamewiseStats;
	// private String month;
	
}
