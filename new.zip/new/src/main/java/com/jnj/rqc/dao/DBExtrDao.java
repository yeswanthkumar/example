package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.dbextr.models.CcraConversionMdl;
import com.jnj.rqc.dbextr.models.CcraExtractMdl;
import com.jnj.rqc.dbextr.models.CcraStageMdl;
import com.jnj.rqc.dbextr.models.ConflictMatrixMdl;
import com.jnj.rqc.dbextr.models.F0005Mdl;
import com.jnj.rqc.dbextr.models.F00821Mdl;
import com.jnj.rqc.dbextr.models.F0082Mdl;
import com.jnj.rqc.dbextr.models.F983051Mdl;
import com.jnj.rqc.dbextr.models.F9860Mdl;
import com.jnj.rqc.dbextr.models.F9861Mdl;
import com.jnj.rqc.dbextr.models.F9865Mdl;
import com.jnj.rqc.dbextr.models.SystemCodeMdl;
import com.jnj.rqc.reportmodels.ReportDataModel;

public interface DBExtrDao {
	public List<SystemCodeMdl> getSystemCodeData() throws SQLException, DataAccessException ;
	public List<ConflictMatrixMdl> getConflictMatrixData() throws SQLException, DataAccessException ;
	public List<CcraConversionMdl> getCCRAConversionData() throws SQLException, DataAccessException ;
	public List<CcraExtractMdl> getCCRAExtractData() throws SQLException, DataAccessException ;
	public List<CcraStageMdl> getCCRAStageData() throws SQLException, DataAccessException ;

	//OBJ7333
	public List<F9860Mdl> getF9860Data() throws SQLException, DataAccessException ;
	public List<F9861Mdl> getF9861Data() throws SQLException, DataAccessException ;
	public List<F9865Mdl> getF9865Data() throws SQLException, DataAccessException ;

	//PD7333
	public List<F983051Mdl> getF983051Data() throws SQLException, DataAccessException ;

	//PDCTL
	public List<F0005Mdl> getF0005Data() throws SQLException, DataAccessException ;
	public List<F0082Mdl> getF0082Data() throws SQLException, DataAccessException ;
	public List<F00821Mdl> getF00821Data() throws SQLException, DataAccessException ;

	public List<ReportDataModel> searchTktInfo(String tktNo)throws SQLException, DataAccessException;


}
