package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDACrossAppMatrixModel {
	private String wwid;
	private String app1;
	private String app2;
	private String role1;
	private String role2;
	private String conflict;
	private String mitigatingControl;


	public String getData() {
		return  wwid+"~"+app1+"~"+app2+"~"+ role1 + "~" + role2 + "~" + role1+"\\"+role2 + "~" + mitigatingControl ;
	}


	@Override
	public String toString() {
		return "JDACrossAppMatrixModel [wwid=" + wwid + ", app1=" + app1 + ", app2=" + app2 + ", role1=" + role1
				+ ", role2=" + role2 + ", conflict=" + conflict + ", mitigatingControl=" + mitigatingControl + "]";
	}





}
