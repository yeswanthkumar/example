package com.jnj.rqc.conflictModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jnj.rqc.models.UserSearchModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConflictResponseDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	private Date timeStamp;
	private UserSearchModel user;
	private List<MatrixModel> curRoleConflictList = new ArrayList<>();
	private List<MatrixModel> newRoleConflictList = new ArrayList<>();
	private List<MatrixModel> pendRoleConflictList = new ArrayList<>();
}
