package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class HanaUser2SodModel {

	private String wwId;  		//SYS.GRANTED_ROLES
	private String riskId;
	private String riskDesc;
	private String funcA;
	private String funcADesc;
	private String funcB;
	private String funcBDesc;
	private String riskLevel;
	private String regulation;
	private String trgtCon;
	private String mitiCntrl;
	private String complMgr;
	private String rulesetGpo;
	private String role1;
	private String role2;




	public String getData() {
		return  wwId + "~" + riskId + "~" + riskDesc +"~"+role1+ "~"+role2+"~" + funcA + "~" + funcADesc + "~" + funcB + "~" + funcBDesc + "~" + riskLevel
				+ "~" + regulation + "~" + trgtCon + "~" + mitiCntrl + "~" + complMgr + "~" + rulesetGpo;
	}




	@Override
	public String toString() {
		return "HanaUser2SodModel [wwId=" + wwId + ", riskId=" + riskId + ", riskDesc=" + riskDesc + ", funcA=" + funcA
				+ ", funcADesc=" + funcADesc + ", funcB=" + funcB + ", funcBDesc=" + funcBDesc + ", riskLevel="
				+ riskLevel + ", regulation=" + regulation + ", trgtCon=" + trgtCon + ", mitiCntrl=" + mitiCntrl
				+ ", complMgr=" + complMgr + ", rulesetGpo=" + rulesetGpo + ", role1=" + role1 + ", role2=" + role2
				+ "]";
	}




}
