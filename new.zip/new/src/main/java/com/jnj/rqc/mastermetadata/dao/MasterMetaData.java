package com.jnj.rqc.mastermetadata.dao;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.MasterData;

public class MasterMetaData {

	 private List<MasterData> records;

	    public List<MasterData> getRecords() {
	        return records;
	    }

	    public void setRecords(List<MasterData> records) {
	        this.records = records;
	    }

		@Override
		public String toString() {
			return "MyDataInput [records=" + records + ", getRecords()=" + getRecords() + ", getClass()=" + getClass()
					+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}
}
