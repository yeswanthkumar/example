package com.jnj.rqc.mastermetadata.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.mastermetadata.controller.MitigationData;

@Repository
public class MitigationDataRepository extends BaseDao {
	static final Logger log = LoggerFactory.getLogger(MitigationDataRepository.class);

	public void insertMultipleRecords(List<MitigationData> records) {
		log.debug("enter into the method");
		try {
	            int batchSize = 100;
	            for (int i = 0; i < records.size(); i += batchSize) {
	                int endIndex = Math.min(i + batchSize, records.size());
	                List<MitigationData> batch = records.subList(i, endIndex);
	                insertBatchAsync(batch);
	            }

	     } catch (Exception e) {
	    	 log.error("Exception while inserting records :"+e.getMessage());
	     }
		log.debug("end of the method");
	}
	private void insertBatchAsync(List<MitigationData> mitigationList) {
		String insQry = "INSERT INTO SOD_DB_USER.ZMITIGATIN_CONTROLS (MID, MCNTRL, MDESC, ISACTIVE, TYPE, CREATEDBY, CREATEDON, CHANGEDBY, CHANGEDON) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, mitigationList.get(i).getMid());
				ps.setString(2, mitigationList.get(i).getMcntrl());
				ps.setString(3, mitigationList.get(i).getMdesc());
				ps.setString(4, "Y");
				ps.setString(5, "C");
				ps.setString(6, mitigationList.get(i).getCreatedBy());
				ps.setDate(7, getCurrentDatetime());
				ps.setString(8, mitigationList.get(i).getChangedBy());
				ps.setDate(9, getCurrentDatetime());
			}
			@Override
			public int getBatchSize() {
				return mitigationList.size();
			}

		});
		log.info("Total Records inserted : "+(status.length == mitigationList.size() ? "Success-"+mitigationList.size() : "Failed-"+(mitigationList.size() - status.length)));
    }
	
	public java.sql.Date getCurrentDatetime() {
	    java.util.Date today = new java.util.Date();
	    return new java.sql.Date(today.getTime());
	}
	
	public void deleteAllRows(List<MitigationData> records) {
		log.debug("enter into the method");
		try {
			//String mitId = records.stream().collect(Collectors.joining(" "));
			
			  String mitId=""; 
			  for(MitigationData record: records) {
				  mitId=mitId+"'"+record.getMid()+"',"; 
			  }
			  mitId = mitId.replaceAll(",$", "");
			String sql = "DELETE FROM SOD_DB_USER.ZMITIGATIN_CONTROLS WHERE MID IN ("+mitId+")";
			getJdbcTemplateSRADUtils().update(sql);
		}catch(Exception e) {
			log.error("Exception : error while deletion :"+e.getMessage());
		}
    	log.debug("end of the method");
    }
	
	public List<MitigationData> getAllMitigationData() throws SQLException, DataAccessException {
		log.debug("enter into the method");
		List<MitigationData> dataList = new ArrayList<>();		
		String sql = "select * from ZMITIGATIN_CONTROLS";
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(MitigationData.class));
		log.info("MitigationRptMdl Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		log.debug("end of the method");
		return dataList;
	}
}
