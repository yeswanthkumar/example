package com.jnj.rqc.serviceImpl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.ApplDataDao;
import com.jnj.rqc.models.AppDataModel;
import com.jnj.rqc.service.ApplDataService;


@Service
public class ApplDataServiceImpl implements ApplDataService {
	static final Logger log = LoggerFactory.getLogger(ApplDataServiceImpl.class);

	@Autowired
	ApplDataDao applDataDao;

	@Override
	public Map<String, List<AppDataModel>> getApplicationData(int tktNum) {
		log.info("Tickete Number Received : "+tktNum);
		Map<String, List<AppDataModel>> appsDataMap = null;
		try {
			appsDataMap = applDataDao.queryAppsData(tktNum);
			log.info("Allication list Data size :"+appsDataMap.size());

			/*appsDataMap.forEach((grp, appLst) ->{
				log.debug("Group: "+grp);
				int i=1;
				for(AppDataModel appData:appLst){
					log.debug("     "+(i++)+". Appl: "+appData+"\n");
					if(null != appData.getRoles()) {
						int j=1;
						for(PosRoles rol:appData.getRoles()) {
							log.debug("          "+(j++)+". ROLE: "+rol+"\n");
						}
					}

				};
			});*/

		} catch (DataAccessException | SQLException e) {
			log.error("Exception getting Application Data:"+e.getMessage(), e);
		}
		return appsDataMap;
	}

}
