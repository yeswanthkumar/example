package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZAccessTypeMdl {
	private int 	accid;
	private String 	accname;
	private String 	accdesc;
	private String 	isactive;
	private  String createdby;
	private Date 	createdon;
	private  String cchangedby;
	private Date 	changedon;


	@Override
	public String toString() {
		return "ZAccessTypeMdl [accid=" + accid + ", accname=" + accname + ", accdesc=" + accdesc + ", isactive="
				+ isactive + ", createdby=" + createdby + ", createdon=" + createdon + ", cchangedby=" + cchangedby
				+ ", changedon=" + changedon + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZAccessTypeMdl other = (ZAccessTypeMdl) obj;
		if (accdesc == null) {
			if (other.accdesc != null)
				return false;
		} else if (!accdesc.equals(other.accdesc))
			return false;
		if (accid != other.accid)
			return false;
		if (accname == null) {
			if (other.accname != null)
				return false;
		} else if (!accname.equals(other.accname))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accdesc == null) ? 0 : accdesc.hashCode());
		result = prime * result + accid;
		result = prime * result + ((accname == null) ? 0 : accname.hashCode());
		return result;
	}




}
