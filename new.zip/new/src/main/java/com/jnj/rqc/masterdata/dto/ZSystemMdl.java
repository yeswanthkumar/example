package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZSystemMdl {
	private int sysid;
	private String sysname;
	private String sysdesc;
	private String isactive;
	private  String createdby;
	private Date createdon;
	private  String cchangedby;
	private Date changedon;


	@Override
	public String toString() {
		return "ZSystemMdl [sysid=" + sysid + ", sysname=" + sysname + ", sysdesc=" + sysdesc + ", isactive=" + isactive
				+ ", createdby=" + createdby + ", createdon=" + createdon + ", cchangedby=" + cchangedby
				+ ", changedon=" + changedon + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZSystemMdl other = (ZSystemMdl) obj;
		if (isactive == null) {
			if (other.isactive != null)
				return false;
		} else if (!isactive.equals(other.isactive))
			return false;
		if (sysdesc == null) {
			if (other.sysdesc != null)
				return false;
		} else if (!sysdesc.equals(other.sysdesc))
			return false;
		if (sysid != other.sysid)
			return false;
		if (sysname == null) {
			if (other.sysname != null)
				return false;
		} else if (!sysname.equals(other.sysname))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isactive == null) ? 0 : isactive.hashCode());
		result = prime * result + ((sysdesc == null) ? 0 : sysdesc.hashCode());
		result = prime * result + sysid;
		result = prime * result + ((sysname == null) ? 0 : sysname.hashCode());
		return result;
	}










}
