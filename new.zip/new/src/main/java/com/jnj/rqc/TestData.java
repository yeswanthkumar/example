package com.jnj.rqc;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.userabs.models.UserReqDetCompMdl;

public class TestData {

	public static void main(String[] args) throws JsonProcessingException {

		List<String> al = new ArrayList<>();

		String[] arr=  al.toArray(new String[al.size()]);
		System.out.println(arr);

		/*IamAdGrpRequestDTO dto = new IamAdGrpRequestDTO();
		dto.setCCC_ActionType("ADD");
		dto.setCCC_Reason("Testing");

		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(dto);
		System.out.println("jsonInString: "+jsonInString);
		*/
		/*List<String> allList = Arrays.asList("1,2,3,4,5,6".split(","));
		List<String> rem = Arrays.asList("1,2".split(","));

		List<String> test = allList.stream()
		.filter(e -> !rem.contains(e))
		.collect(Collectors.toList());


		System.out.println("test:"+test);
		*/


		//long lng = Long.parseLong("1674229906102l");
		//Date dd = new Date(lng);
		// String nullName = null;
		// String name = Optional.ofNullable(nullName).orElse("john");
		//System.out.println("Date:"+name);
		//UserConflictChckMdl mdl = new UserConflictChckMdl();
		/*UserExcsvAccessChckMdl mdl = new UserExcsvAccessChckMdl();
		mdl.setUserid("643022369");
		List<RoleADGrpMdl> existingAccess = new ArrayList<>();
		RoleADGrpMdl ex1 = new RoleADGrpMdl();
		existingAccess.add(ex1);
		Map<String, List<RoleADGrpMdl>> m1 = new HashMap<>();
		m1.put("1", existingAccess);
		mdl.setExistingAccess(m1);
		List<RoleADGrpMdl> newAccess = new ArrayList<>();
		RoleADGrpMdl n1 = new RoleADGrpMdl();
		newAccess.add(n1);
		Map<String, List<RoleADGrpMdl>> m2 = new HashMap<>();
		m2.put("2", newAccess);
		mdl.setNewAccess(m2);*/
		/*AbsComplianceRequest mdl = new AbsComplianceRequest();
		mdl.setReqid("6");
		mdl.setUserid("643022369");
		List<UserAbsConflictMdl> confApprovalList = new ArrayList<>();
		UserAbsConflictMdl cMdl = new UserAbsConflictMdl();
		confApprovalList.add(cMdl);
		List<AbsExcesvAccsMdl> excessiveApprovalList = new ArrayList<AbsExcesvAccsMdl>();
		AbsExcesvAccsMdl eMdl = new AbsExcesvAccsMdl();
		List<RawSysDpendncMdl> variantDetails = new ArrayList<>();
		RawSysDpendncMdl det = new RawSysDpendncMdl();
		variantDetails.add(det);
		eMdl.setVariantDetails(variantDetails);
		excessiveApprovalList.add(eMdl);
		mdl.setConfApprovalList(confApprovalList);

		mdl.setExcessiveApprovalList(excessiveApprovalList);

		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(mdl);
		System.out.println("jsonInString: "+jsonInString);
		*/
		//objToJson();



	}

	public static void objToJson() {
		ObjectMapper mapper = new ObjectMapper();
		UserReqCompMdl req = new UserReqCompMdl();
		req.setTypeid(1);
		req.setRequestedby("643022369");
		req.setUserid("643022369");
		req.setManagerid("643022369");
		req.setBfid("2");
		req.setSecids("1,2,3,4,5,6");
		req.setRegids("1,2,3");
		req.setConflictFound("Y");
		req.setIsExces("Y");
		req.setComments("Testing Data");
		List<UserReqDetCompMdl> sysList = new ArrayList<>();
		List<UserAbsConflictMdl> confList = new ArrayList<>();
		List<AbsExcesvAccsMdl> excList  = new ArrayList<>();
		UserReqDetCompMdl sys = new UserReqDetCompMdl();
		sys.setSysid("1");
		sys.setPosids("1");
		sys.setAccids("1");
		sys.setPosvarids("1,3");
		sys.setAdids("1,3");

		UserReqDetCompMdl sys1 = new UserReqDetCompMdl();
		sys1.setSysid("2");
		sys1.setPosids("7");
		sys1.setAccids("2,3");
		sys1.setPosvarids("4,8,9,10");
		sys1.setAdids("15,13");
		UserReqDetCompMdl sys2 = new UserReqDetCompMdl();
		sys2.setSysid("3");
		sys2.setPosids("2");
		sys2.setAccids("2");
		sys2.setPosvarids("6,7");
		sys2.setAdids("6,7");
		sysList.add(sys);
		sysList.add(sys1);
		sysList.add(sys2);
		req.setSysList(sysList);
		///////
		UserAbsConflictMdl cnf = new UserAbsConflictMdl();
		cnf.setRiskid("1");
		cnf.setRiskdesc("Financial Operational Vs BRAVO-PLAN-SUBMITTER");
		cnf.setApp1("1");
		cnf.setApp2("3");
		cnf.setPosv1("1");
		cnf.setPosv2("7");
		cnf.setConflict("Financial Operational – CU 001270 Vs BRAVO-PLAN-SUBMITTER-CU-001270-JANPHRCEUTICALS");
		confList.add(cnf);
		req.setConfList(confList);
		/////
		AbsExcesvAccsMdl exc = new AbsExcesvAccsMdl();
		exc.setSysid("2");
		exc.setLimit(70);
		exc.setIsExcsv("Y");
		exc.setExcsvPrcntg(87.5);
		exc.setExVarids("");
		exc.setSelVarids("4,8,9,10,11,12,13");
		excList.add(exc);
		req.setExcList(excList);

		//Object to JSON in String
		try {
			String jsonInString = mapper.writeValueAsString(req);
			System.out.println("jsonInString: "+jsonInString);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
