package com.jnj.rqc.masterdata.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.masterdata.dto.ZAccessTypeRespDto;
import com.jnj.rqc.masterdata.dto.ZBussFuncRespDto;
import com.jnj.rqc.masterdata.dto.ZPosVariantRespDto;
import com.jnj.rqc.masterdata.dto.ZPositionRespDto;
import com.jnj.rqc.masterdata.dto.ZRegionRespDto;
import com.jnj.rqc.masterdata.dto.ZReqTypRespDto;
import com.jnj.rqc.masterdata.dto.ZSectorRespDto;
import com.jnj.rqc.masterdata.dto.ZSystemRespDto;
import com.jnj.rqc.masterdata.service.MasterDataService;
import com.jnj.rqc.userabs.models.ZBsFnSecRegSystemRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSecRegnsRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSectorsRespDto;
import com.jnj.rqc.userabs.models.ZPosnsAccessRespDto;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarRespDto;
import com.jnj.rqc.userabs.models.ZSysPositionsRespDto;



/**
 * File    : <b>MasterDataController.java</b>
 * @author : DChauras @Created : Feb 1, 2023 3:29:26 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@RestController
@RequestMapping("/v2")
public class MasterDataController {
	static final Logger log = LoggerFactory.getLogger(MasterDataController.class);

	@Autowired
	private MasterDataService masterDataService;


	/**
	 * Method  : MasterDataController.java.getBusinessFunctions()
	 *		   :<b>@param bfid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:29:19 PM
	 * Purpose :
	 * @return : ResponseEntity<ZBussFuncRespDto>
	*/
	@GetMapping("/getzbussfunc/{bfid}")
	public ResponseEntity<ZBussFuncRespDto> getBusinessFunctions(@PathVariable("bfid") int bfid){
		log.info("Received BFID: "+bfid);
		ZBussFuncRespDto bfRespDto = masterDataService.getZBusssFunc(bfid);
    	if (bfRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(bfRespDto, HttpStatus.OK);
        } else if (bfRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(bfRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(bfRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZReqTypes()
	 *		   :<b>@param typid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:29:14 PM
	 * Purpose :
	 * @return : ResponseEntity<ZReqTypRespDto>
	*/
	@GetMapping("/getzreqtyps/{typid}")
	public ResponseEntity<ZReqTypRespDto> getZReqTypes(@PathVariable("typid") int typid){
		log.info("Received TYPID: "+typid);
		ZReqTypRespDto rqRespDto = masterDataService.getZReqTyp(typid);
    	if (rqRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(rqRespDto, HttpStatus.OK);
        } else if (rqRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(rqRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(rqRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZSectors()
	 *		   :<b>@param secid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:29:08 PM
	 * Purpose : Get All Sectors
	 * @return : ResponseEntity<ZSectorRespDto>
	*/
	@GetMapping("/getzsectors/{secid}")
	public ResponseEntity<ZSectorRespDto> getZSectors(@PathVariable("secid") int secid){
		log.info("Received SECID: "+secid);
		ZSectorRespDto secRespDto = masterDataService.getZSectors(secid);
    	if (secRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(secRespDto, HttpStatus.OK);
        } else if (secRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(secRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(secRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZRegions()
	 *		   :<b>@param regid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:29:02 PM
	 * Purpose : Get Regions
	 * @return : ResponseEntity<ZRegionRespDto>
	*/
	@GetMapping("/getzregions/{regid}")
	public ResponseEntity<ZRegionRespDto> getZRegions(@PathVariable("regid") int regid){
		log.info("Received REGID: "+regid);
		ZRegionRespDto regRespDto = masterDataService.getZRegions(regid);
    	if (regRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(regRespDto, HttpStatus.OK);
        } else if (regRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(regRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(regRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZSystems()
	 *		   :<b>@param sysid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:28:49 PM
	 * Purpose :
	 * @return : ResponseEntity<ZSystemRespDto>
	*/
	@GetMapping("/getzsystems/{sysid}")
	public ResponseEntity<ZSystemRespDto> getZSystems(@PathVariable("sysid") int sysid){
		log.info("Received SYSID: "+sysid);
		ZSystemRespDto sysRespDto = masterDataService.getZSystems(sysid);
    	if (sysRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(sysRespDto, HttpStatus.OK);
        } else if (sysRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(sysRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(sysRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZPositions()
	 *		   :<b>@param posid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:46:39 PM
	 * Purpose :
	 * @return : ResponseEntity<ZPositionRespDto>
	*/

	@GetMapping("/getzpositions/{posid}")
	public ResponseEntity<ZPositionRespDto> getZPositions(@PathVariable("posid") int posid){
		log.info("Received POSID: "+posid);
		ZPositionRespDto posRespDto = masterDataService.getZPositions(posid);
    	if (posRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(posRespDto, HttpStatus.OK);
        } else if (posRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(posRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(posRespDto, HttpStatus.NOT_FOUND);
        }
	}



	/**
	 * Method  : MasterDataController.java.getZAccessTypes()
	 *		   :<b>@param accid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 3, 2023 3:42:03 PM
	 * Purpose :
	 * @return : ResponseEntity<ZAccessTypeRespDto>
	*/
	@GetMapping("/getzaccesstypes/{accid}")
	public ResponseEntity<ZAccessTypeRespDto> getZAccessTypes(@PathVariable("accid") int accid){
		log.info("Received ACCID: "+accid);
		ZAccessTypeRespDto accTypRespDto = masterDataService.getZAccessTypes(accid);
    	if (accTypRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(accTypRespDto, HttpStatus.OK);
        } else if (accTypRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(accTypRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(accTypRespDto, HttpStatus.NOT_FOUND);
        }
	}

	@GetMapping("/getzposvariants/{posvarid}")
	public ResponseEntity<ZPosVariantRespDto> getZPosVariants(@PathVariable("posvarid") int posvarid){
		log.info("Received ACCID: "+posvarid);
		ZPosVariantRespDto posvarRespDto = masterDataService.getZPosVariants(posvarid);
    	if (posvarRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(posvarRespDto, HttpStatus.OK);
        } else if (posvarRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(posvarRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(posvarRespDto, HttpStatus.NOT_FOUND);
        }
	}


	@PostMapping("/getzbsnsfuncsctrs")
	public ResponseEntity<ZBsnsFuncSectorsRespDto> getZBusinessFuncSectors(@RequestParam("bfId") String bfId ){
		log.info("Received BFID: "+bfId);
		ZBsnsFuncSectorsRespDto bfSecRespDto = masterDataService.getZBfSectors(bfId);
    	if (bfSecRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(bfSecRespDto, HttpStatus.OK);
        } else if (bfSecRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(bfSecRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(bfSecRespDto, HttpStatus.NOT_FOUND);
        }
	}

	@PostMapping("/getzbsnsfuncsctrrgns")
	public ResponseEntity<ZBsnsFuncSecRegnsRespDto> getZBusinessFuncSectorRegions(@RequestParam("bfId") String bfId, @RequestParam("secIds") String secIds ){
		log.info("Received BFID: "+bfId+"  Sec Ids: "+secIds);
		ZBsnsFuncSecRegnsRespDto bfSecRegRespDto = masterDataService.getZBfSectRegns(bfId, secIds.split(","));
    	if (bfSecRegRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(bfSecRegRespDto, HttpStatus.OK);
        } else if (bfSecRegRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(bfSecRegRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(bfSecRegRespDto, HttpStatus.NOT_FOUND);
        }
	}


	@PostMapping("/getzbstregnsystems")
	public ResponseEntity<ZBsFnSecRegSystemRespDto> getZBsnsFuncSctrRegnSystems(@RequestParam("bfId") String bfId, @RequestParam("secIds") String secIds, @RequestParam("regIds") String regIds ){
		log.info("Received BFID: "+bfId+"  Sec Ids: "+secIds+" regIds: "+regIds);
		ZBsFnSecRegSystemRespDto bfSecRegSysRespDto = masterDataService.getZBfSectRegnSystems(bfId, secIds.split(","), regIds.split(","));
    	if (bfSecRegSysRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(bfSecRegSysRespDto, HttpStatus.OK);
        } else if (bfSecRegSysRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(bfSecRegSysRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(bfSecRegSysRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZSysPositions()
	 *		   :<b>@param sysId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2023 4:43:11 PM
	 * Purpose : Get System Positions
	 * @return : ResponseEntity<ZSysPositionsRespDto>
	*/
	/*@PostMapping("/getzsystempositions")
	public ResponseEntity<ZSysPositionsRespDto> getZSysPositions(@RequestParam("sysId") String sysId ){
		log.info("Received SYSID: "+sysId);
		ZSysPositionsRespDto sysPosnsRespDto = masterDataService.getZSystemPositions(sysId);
    	if (sysPosnsRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<ZSysPositionsRespDto>(sysPosnsRespDto, HttpStatus.OK);
        } else if (sysPosnsRespDto.getStatusCode() == 500) {
			return new ResponseEntity<ZSysPositionsRespDto>(sysPosnsRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<ZSysPositionsRespDto>(sysPosnsRespDto, HttpStatus.NOT_FOUND);
        }
	}*/

	@PostMapping("/getzsystempositions")
	public ResponseEntity<ZSysPositionsRespDto> getZSysPositions(@RequestParam("bfId") String bfId, @RequestParam("secIds") String secIds, @RequestParam("regIds") String regIds, @RequestParam("sysId") String sysId ){
		log.info("Received SYSID: "+sysId);
		ZSysPositionsRespDto sysPosnsRespDto = masterDataService.getZSystemPositions(bfId, secIds.split(","), regIds.split(","), sysId);
    	if (sysPosnsRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(sysPosnsRespDto, HttpStatus.OK);
        } else if (sysPosnsRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(sysPosnsRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(sysPosnsRespDto, HttpStatus.NOT_FOUND);
        }
	}





	/**
	 * Method  : MasterDataController.java.getZSysPosnsAccess()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2023 6:03:52 PM
	 * Purpose : Get All Acces Types for given System and Positions
	 * @return : ResponseEntity<ZPosnsAccessRespDto>
	*/
	/*@PostMapping("/getzpositionsaccess")
	public ResponseEntity<ZPosnsAccessRespDto> getZSysPosnsAccess(@RequestParam("sysId") String sysId,  @RequestParam("posIds") String posIds ){
		log.info("Received SYSID: "+sysId+ " POSID's :"+posIds);
		ZPosnsAccessRespDto posnsAccessRespDto = masterDataService.getZPosnsAccessTypes(sysId, posIds.split(","));
    	if (posnsAccessRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<ZPosnsAccessRespDto>(posnsAccessRespDto, HttpStatus.OK);
        } else if (posnsAccessRespDto.getStatusCode() == 500) {
			return new ResponseEntity<ZPosnsAccessRespDto>(posnsAccessRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<ZPosnsAccessRespDto>(posnsAccessRespDto, HttpStatus.NOT_FOUND);
        }
	}*/

	@PostMapping("/getzpositionsaccess")
	public ResponseEntity<ZPosnsAccessRespDto> getZSysPosnsAccess(@RequestParam("bfId") String bfId, @RequestParam("secIds") String secIds, @RequestParam("regIds") String regIds, @RequestParam("sysId") String sysId,  @RequestParam("posIds") String posIds ){
		log.info("Received SYSID: "+sysId+ " POSID's :"+posIds);
		ZPosnsAccessRespDto posnsAccessRespDto = masterDataService.getZPosnsAccessTypes(bfId, secIds.split(","), regIds.split(","), sysId, posIds.split(","));
    	if (posnsAccessRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(posnsAccessRespDto, HttpStatus.OK);
        } else if (posnsAccessRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(posnsAccessRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(posnsAccessRespDto, HttpStatus.NOT_FOUND);
        }
	}


	/**
	 * Method  : MasterDataController.java.getZAcsPosVariants()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 16, 2023 10:40:58 AM
	 * Purpose : Get All the Positions
	 * @return : ResponseEntity<ZSysPosAccPvarRespDto>
	*/
	/*@PostMapping("/getzacsposvariants")
	public ResponseEntity<ZSysPosAccPvarRespDto> getZAcsPosVariants(@RequestParam("sysId") String sysId, @RequestParam("posIds") String posIds, @RequestParam("acsIds") String acsIds ){
		log.info("Received SYSID: "+sysId+ " POSID's :"+posIds +"  AccessIds: "+acsIds);
		ZSysPosAccPvarRespDto acsPosVarRespDto = masterDataService.getZAccsPosVariants(sysId, posIds.split(","), acsIds.split(","));
    	if (acsPosVarRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<ZSysPosAccPvarRespDto>(acsPosVarRespDto, HttpStatus.OK);
        } else if (acsPosVarRespDto.getStatusCode() == 500) {
			return new ResponseEntity<ZSysPosAccPvarRespDto>(acsPosVarRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<ZSysPosAccPvarRespDto>(acsPosVarRespDto, HttpStatus.NOT_FOUND);
        }
	}*/

	@PostMapping("/getzacsposvariants")
	public ResponseEntity<ZSysPosAccPvarRespDto> getZAcsPosVariants(@RequestParam("bfId") String bfId, @RequestParam("secIds") String secIds, @RequestParam("regIds") String regIds, @RequestParam("sysId") String sysId, @RequestParam("posIds") String posIds, @RequestParam("acsIds") String acsIds ){
		log.info("Received SYSID: "+sysId+ " POSID's :"+posIds +"  AccessIds: "+acsIds);
		ZSysPosAccPvarRespDto acsPosVarRespDto = masterDataService.getZAccsPosVariants(bfId, secIds.split(","), regIds.split(","), sysId, posIds.split(","), acsIds.split(","));
    	if (acsPosVarRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(acsPosVarRespDto, HttpStatus.OK);
        } else if (acsPosVarRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(acsPosVarRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(acsPosVarRespDto, HttpStatus.NOT_FOUND);
        }
	}


}
