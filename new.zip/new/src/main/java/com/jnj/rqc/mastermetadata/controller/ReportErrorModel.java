package com.jnj.rqc.mastermetadata.controller;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportErrorModel {
	private String reqId;
	private String userId;
	private String	systemId;
	private String systemName;
	private String	positionName;
	private String cuName;
	private String roleName;
	private String status;
	private String errorMsg;
	private String message;	
	private String subm_status;
	private String api_status;
	private String subm_uid;
	private String adgrpid;
	private String subm_date;
}
