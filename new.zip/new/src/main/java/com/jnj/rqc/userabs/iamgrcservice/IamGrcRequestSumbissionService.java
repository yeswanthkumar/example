package com.jnj.rqc.userabs.iamgrcservice;

import java.util.List;

import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceStatusRespDTO;

public interface IamGrcRequestSumbissionService {

	/**
	 * Method  : IamGrcRequestSumbissionService.java.processApprovedRequestForSubmission()
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 28, 2023 3:15:43 PM
	 * Purpose : Get All the requests which are ready for submission.
	 * @return : List<AbsUserReqMdl>
	 */
	public List<AbsUserReqMdl> getApprovedRequestForSubmission();

	/**
		 * Method  : IamGrcRequestSumbissionService.java.submitApprRequestToDownstreams()
		 *		   :<b>@param allReqLst</b>
		 * @author : DChauras  @Created :May 1, 2023 12:50:30 AM
		 * Purpose :
		 * @return : void
		 */
	public void submitApprRequestToDownstreams(List<AbsUserReqMdl> allReqLst);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.sendApprovedDataToAnaplanIamGrc()
		 *		   :<b>@param reqMdl
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 12:50:26 AM
		 * Purpose :
		 * @return : boolean
		 */
	public boolean sendApprovedDataToAnaplanIamGrc(AbsUserReqMdl reqMdl);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.sendDataToIAM()
		 *		   :<b>@param reqId
		 *		   :<b>@param userId
		 *		   :<b>@param reqBy
		 *		   :<b>@param sysId
		 *		   :<b>@param comments
		 *		   :<b>@param detailNum
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 12:50:20 AM
		 * Purpose :
		 * @return : List<IAMRequestedRoleModel>
		 */
	public List<IAMRequestedRoleModel> sendDataToIAM(int reqId, int reqType, String userId, String reqBy, String sysId, String comments, ReqDpendncMdl detailNum);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.updateIamGrcRequestStatus()
		 *		   :<b>@param reqId
		 *		   :<b>@param status
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 12:50:37 AM
		 * Purpose : Update Request status in Request Header Table
		 * @return : int
		 */
	public int updateIamGrcRequestStatus(int reqId, int status);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.getAllEDALReqSubmittedToIAM()
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 3:55:50 PM
		 * Purpose : Query All EDAL Submitted Request to IAM
		 * @return : List<AbsUserReqMdl>
		 */
	public List<AbsUserReqMdl> getAllEDALReqSubmittedToIAM();

	/**
		 * Method  : IamGrcRequestSumbissionService.java.getEdalReqStatusFromIam()
		 *		   :<b>@param reqMdl
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 4:25:18 PM
		 * Purpose : Getting Request Status from IAM
		 * @return : boolean
		 */
	public boolean getEdalReqStatusFromIam(AbsUserReqMdl reqMdl);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.getEdalStatusFromIAM()
		 *		   :<b>@param detailNum
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 5:48:58 PM
		 * Purpose : Getting Status for AD Group
		 * @return : IamAdGrpServiceStatusRespDTO
		 */
	public IamAdGrpServiceStatusRespDTO getEdalStatusFromIAM(IAMRequestedRoleModel detailNum);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.getEdalRequestCount()
		 *		   :<b>@param reqId
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 6:22:40 PM
		 * Purpose : Count of sub-requests
		 * @return : int
		 */
	public int getEdalRequestCount(String reqId);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.getCompltdReqStat()
		 *		   :<b>@param reqId
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 6:27:37 PM
		 * Purpose : Count of Child requests completed
		 * @return : List<String>
		 */
	public List<String> getCompltdReqStat(String reqId);

	/**
		 * Method  : IamGrcRequestSumbissionService.java.updateIamRequestStatus()
		 *		   :<b>@param reqId
		 *		   :<b>@param status
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 1, 2023 6:33:14 PM
		 * Purpose : Update Status
		 * @return : int
		 */
	public int updateIamRequestStatus(int reqId, int status);

	List<IAMRequestedRoleModel> sendDataToGRC(int reqId, int reqType, String userId, String reqBy, String sysId, String comments, ReqDpendncMdl detailNum);

	public boolean pingGRC(String reqBy);
	public boolean pingIAM( String comments);



	//public AbsUserRequestRespDto getAllRequestData(String startDate, String endDate, int paramType, String paramValue);
	//public List<RawSysDpendncMdl> getSysDependencies(String sysid, String posnids, String accids, String posvarids);
	//public AbsUserReqMdl getRequestDataByID(String reqId);
	//public List<UserAbsConflictMdl> getAllReqLvlConflicts(String reqId);
	//public List<AbsExcesvAccsMdl> getReqLvlExcData(String reqId);
	//public List<KeyValPair> getAllMitigatingControls(int id, String type);
	//public String saveComplApprovalData(UserSearchModel approveUser, AbsComplianceRequest absComlianceRequest);


}
