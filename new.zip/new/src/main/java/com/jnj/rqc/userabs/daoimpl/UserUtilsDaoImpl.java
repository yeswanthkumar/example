package com.jnj.rqc.userabs.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.userabs.dao.UserUtilsDao;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMultiUserMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.useridentity.models.EmailItem;
import com.jnj.rqc.util.Utility;




@Service
public class UserUtilsDaoImpl  extends BaseDao implements UserUtilsDao {
	static final Logger log = LoggerFactory.getLogger(UserUtilsDaoImpl.class);


	@Override
	public List<RoleADGrpMdl> getMstDataForADGrp(String ldapADGroup) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select Distinct SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, AD_ID as adgrpId, AD_NAME as adgrpName ");
		sql.append(" from SOD_DB_USER.MASTER_DATA ");
		sql.append(" Where upper(AD_NAME) = UPPER('"+ldapADGroup.trim()+"') ");
		sql.append(" ORDER BY SYS_ID, SYS_NAME ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<RoleADGrpMdl> getMstRolesDataForADGrp(String ldapADGroup, String sysId) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT SEC_ID as secId, SEC_NAME as secName, sys_id as sysId, sys_name as sysName, pos_id as posId, pos_name as posName, acs_id as accId, acs_name as accName, pv_id as pvId, ");
		sql.append(" pv_name as pvName, ad_id as adgrpId, ad_name as adgrpName, is_restricted ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE UPPER(ad_name) = UPPER('"+ldapADGroup.trim()+"') AND sys_id = '"+sysId+"' ");
		sql.append(" ORDER BY sys_id, pos_id, acs_id, pv_id, ad_id ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}
	
	@Override
	public List<RoleADGrpMdl> getAllMstRolesDataForADGrp(String ldapADGroup, String sysId) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT SEC_ID as secId, SEC_NAME as secName, sys_id as sysId, sys_name as sysName, reg_id as regId, reg_name as regName, pos_id as posId, pos_name as posName, acs_id as accId, acs_name as accName, pv_id as pvId, ");
		sql.append(" pv_name as pvName, ad_id as adgrpId, UPPER(ad_name) as adgrpName, is_restricted ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE UPPER(ad_name) IN ("+ldapADGroup+") AND sys_id IN ("+sysId+") ");
		sql.append(" ORDER BY sys_id, pos_id, acs_id, pv_id, ad_id ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	/*@Override
	public List<RoleADGrpMdl> getMstRolesDataForADGrp(String ldapADGroup, String sysId) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<RoleADGrpMdl>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT b.sysid as sysId, c.sysname as sysName, b.posid as posId, d.posname as posName, b.accid as accId, e.accname as accName, a.posvarid as pvId, f.posvarname as pvName, a.adid as adgrpId, a.adname as adgrpName ");
		sql.append(" FROM SOD_DB_USER.ZADGROUP a, SOD_DB_USER.ZMAP_ACC_PVAR b, SOD_DB_USER.ZSYSTEM c, SOD_DB_USER.ZPOSITION d, SOD_DB_USER.ZACCESSTYPE e, SOD_DB_USER.ZPOSVARIANT f ");
		sql.append(" WHERE a.isactive='Y' AND a.posvarid = b.posvarid ");
		sql.append(" AND b.sysid = c.sysid AND b.posid = d.posid AND b.accid = e.accid AND b.posvarid = f.posvarid ");
		sql.append(" AND UPPER(a.adname) = UPPER('"+ldapADGroup.trim()+"') AND b.sysid = '"+sysId+"' ");
		sql.append(" ORDER BY b.sysid, b.posid, b.accid, a.posvarid, a.adid ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<RoleADGrpMdl>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}*/





	@Override
	public List<RoleADGrpMdl> getCFINMstDataForRole(String techRle) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select '1' as sysId, 'CFIN' as sysName, POS_ID, POS_NAME, PV_ID, PV_NAME, ROLE_ID as adgrpId, ROLE_ID as adgrpName ");
		sql.append(" FROM SOD_DB_USER.CFIN_ROLE2POSITION ");
		sql.append(" WHERE UPPER(ROLE_ID) = UPPER('"+techRle+"') ");
		sql.append(" ORDER BY 1, 2 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<RoleADGrpMdl> getAnaplanMstDataForRole(String techRle) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" Select Distinct SYS_ID, SYS_NAME, POS_ID, POS_NAME, PV_ID, PV_NAME, AD_ID as adgrpId, AD_NAME as adgrpName ");
		sql.append(" from SOD_DB_USER.MASTER_DATA ");
		sql.append(" Where upper(AD_NAME) = UPPER('"+techRle.trim()+"') AND SYS_ID = '4' ");
		sql.append(" ORDER BY SYS_ID, SYS_NAME ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<UserAbsConflictMdl> getAbsConflictsForPosVariants(String query) throws SQLException, DataAccessException {
		List<UserAbsConflictMdl> dataLst = getJdbcTemplateSRADUtils().query(query, new Object[]{}, new BeanPropertyRowMapper<>(UserAbsConflictMdl.class));
		log.info("Conflict Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public List<String> getAllSystemPosVarIds(String sysId) throws SQLException, DataAccessException{
		List<String> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT DISTINCT PV_ID FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ?  ORDER BY 1 ");  //Add non restricting
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql.toString(), new Object[]{sysId}, String.class);
		log.info("System PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	/*@Override
	public List<RoleADGrpMdl> getSectorWiseSysPvData(String pvId, String[] sysIds) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new ArrayList<RoleADGrpMdl>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT Count(PV_ID) FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? AND PV_ID = ? and upper(IS_RESTRICTED) = 'YES' ");
		int restrCount = getJdbcTemplateSRADUtils().queryForObject(sql.toString(), new Object[]{sysId, pvId}, Integer.class);
		log.info("System PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return restrCount;
	}*/


	//New Methd ro Get Sectorwise Restricted/Non-Restricted Data
	/*@Override
	public List<RoleADGrpMdl> getSectorWiseSysPvsData(String[] pvIds, String sysId) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+pvIds.length)] ;
		sql.append(" SELECT Distinct SEC_ID, SEC_NAME, SYS_ID, SYS_NAME, POS_ID, POS_NAME, ACS_ID as accId, ACS_NAME as accName, PV_ID, PV_NAME, IS_RESTRICTED ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		inParam[prmPos] =  sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "PV_ID", pvIds, inParam, sql);
		sql.append(" ORDER BY 1,5,7,9 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<RoleADGrpMdl>(RoleADGrpMdl.class));
		log.info("System PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}*/
	@Override
	public List<RoleADGrpMdl> getSectorWiseSysPvsData(String[] pvIds, String[] posIds, String[] acsIds, String sysId) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+pvIds.length+posIds.length)] ;
		sql.append(" SELECT Distinct SEC_ID, SEC_NAME, SYS_ID, SYS_NAME, POS_ID, POS_NAME, ACS_ID as accId, ACS_NAME as accName, PV_ID, PV_NAME, IS_RESTRICTED, AD_NAME as adgrpName");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		inParam[prmPos] =  sysId;
		prmPos++;
		//New Conditions Added on 06/22/2023
		if("1".equals(sysId)) {//CFIN - consider only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if(("2".equals(sysId)) || ("6".equals(sysId))) {//DataHub - Exclude ACS_ID = 3 and Include only ACS ID's supplied //Raja added 6 for SAC
			if(acsIds != null && acsIds.length > 0) {
				//if(acsIds.length ==1 && "2".equals(acsIds[0])) {
					
				//}else {
				String accKeys ="";
				sql.append(" AND ACS_ID IN ( ");
				for(int j=0; j<acsIds.length; j++) {
					/*if ("2".equals(acsIds[j]) ) {
						continue;
					}*/
					if(j+1 < acsIds.length) {
						accKeys+= "'"+acsIds[j]+"',";
					}else {
						accKeys+= "'"+acsIds[j]+"' ";
					}
				}
				sql.append(accKeys +" ) ");
				//}
			}
			sql.append(" AND ACS_ID <> '3' ");
			//sql.append(" AND ACS_ID <> '2' ");
		}else if("3".equals(sysId)) {//BRAVO - consider only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if("4".equals(sysId)) {//Anaplan - consider only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if("5".equals(sysId)) {//Bravo A1 Adjustments - consider only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}
		//END
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "PV_ID", pvIds, inParam, sql);
		sql.append(" ORDER BY 1,5,7,9 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	//New Method
	@Override
	public List<RoleADGrpMdl> getAllSectorWiseSysPosPvData(String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		int prmPos = 0;
		Object[] inParam = new Object[(1+posIds.length)] ;
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT Distinct SEC_ID, SEC_NAME, SYS_ID, SYS_NAME, POS_ID, POS_NAME, ACS_ID as accId, ACS_NAME as accName, PV_ID, PV_NAME, IS_RESTRICTED, AD_NAME as adgrpName ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		inParam[prmPos] =  sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		if("1".equals(sysId)) {//CFIN- include only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if(("2".equals(sysId)) || ("6".equals(sysId)) ) {//Data Hub - Exclude all ACS_ID=3
			if(acsIds != null && acsIds.length > 0) {
				// if accId is 2 and size is 1 do nothing if ("2".equals(acsIds[i])) {
				if(acsIds.length ==1 && "2".equals(acsIds[0])) {
					// do nothing
				}else { 
					//String accKeys ="";
					//sql.append(" AND ACS_ID = '1' AND ACS_ID='4' AND ACS_ID='5' AND ACS_ID='6' ");
					sql.append(" AND ACS_ID IN ('1','4','5','6') ");
					/*sql.append(" AND ACS_ID IN ( ");
					for(int j=0; j<acsIds.length; j++) {

						if(j+1 < acsIds.length) {
							accKeys+= "'"+acsIds[j]+"',";
						}else {
							accKeys+= "'"+acsIds[j]+"' ";
						}
					}
					sql.append(accKeys +" ) "); */
					
				}

			}
			sql.append(" AND ACS_ID <> '3' ");
			//sql.append(" AND ACS_ID <> '2' ");
		}else if("3".equals(sysId)) {//BRAVO- include only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if("4".equals(sysId)) {//Anaplan - consider only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if("5".equals(sysId)) {
			sql.append(" AND ACS_ID = '1' ");
		}
		sql.append(" ORDER BY 1,5,7,9 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("System PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	//OLD Method
	@Override
	public List<RoleADGrpMdl> getAllSectorWiseSysPvData(String sysId, String[] acsIds) throws SQLException, DataAccessException{
		List<RoleADGrpMdl> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT Distinct SEC_ID, SEC_NAME, SYS_ID, SYS_NAME, POS_ID, POS_NAME, ACS_ID as accId, ACS_NAME as accName, PV_ID, PV_NAME, IS_RESTRICTED ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		if("1".equals(sysId)) {//CFIN- include only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}else if("2".equals(sysId)) {//Data Hub - Exclude all ACS_ID=3
			if(acsIds != null && acsIds.length > 0) {
				String accKeys ="";
				sql.append(" AND ACS_ID IN ( ");
				for(int j=0; j<acsIds.length; j++) {
					if(j+1 < acsIds.length) {
						accKeys+= "'"+acsIds[j]+"',";
					}else {
						accKeys+= "'"+acsIds[j]+"' ";
					}
				}
				sql.append(accKeys +" ) ");
			}
			sql.append(" AND ACS_ID <> '3' ");
		}else if("3".equals(sysId)) {//BRAVO- include only ACS_ID=1
			sql.append(" AND ACS_ID = '1' ");
		}
		sql.append(" ORDER BY 1,5,7,9 ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {sysId}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("All System("+sysId+") PVARID Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}



	@Override
	public List<IAMRolesADGrpMdl> getAnaplanHistDataForUser(String userId) throws SQLException, DataAccessException{
		List<IAMRolesADGrpMdl> dataLst = new LinkedList<>();
		String sql= " SELECT DISTINCT ADGROUP as ldapADGroup, to_char(VLD_FROM, 'yyyyMMdd') as mdate, to_char(VLD_to, 'yyyyMMdd') as stopdate " +
					" FROM SOD_DB_USER.CSMDATA_HIST " +
					" WHERE STATUS = 'ACTIVE' AND WWID = ? ";
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[]{userId}, new BeanPropertyRowMapper<>(IAMRolesADGrpMdl.class));
		log.info("System ADGRP Data's size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Transactional
	@Override
	public int insertDimensionsData(List<EmailItem> dataList) throws SQLException, DataAccessException {
		log.info("Saving AnaPlan Email Dimensions Total Rows : "+dataList.size());
		String delQry = " DELETE SOD_DB_USER.ZANAPLAN_EMAIL_DIMENSION ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.ZANAPLAN_EMAIL_DIMENSION ( CODE, ID, NAME )  VALUES (?, ?, ? ) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, dataList.get(i).getCode());
				ps.setString(2, dataList.get(i).getId());
				ps.setString(3, dataList.get(i).getName());
			}

			@Override
			public int getBatchSize() {
				return dataList.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return status.length;

	}


	@Override
	public String getDimensionIdForUserEmail(String emailId) throws SQLException, DataAccessException {
		String dimId = "";
		emailId = emailId.toUpperCase().trim();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT ID FROM SOD_DB_USER.ZANAPLAN_EMAIL_DIMENSION WHERE Upper(CODE) = ? ");
		dimId = getJdbcTemplateSRADUtils().queryForObject(sql.toString(), new Object[]{emailId}, String.class);
		log.info("Dimension ID for Email ("+emailId+") : "+dimId);
		return dimId;
	}
	
	@Override
	public List<RoleADGrpMultiUserMdl> getAllMstDataForMultiUserADGrp() throws SQLException, DataAccessException {
		List<RoleADGrpMultiUserMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT SEC_ID as secId, SEC_NAME as secName, sys_id as sysId, sys_name as sysName, pos_id as posId, pos_name as posName, acs_id as accId, acs_name as accName, pv_id as pvId, ");
		sql.append(" pv_name as pvName, ad_id as adgrpId, ad_name as adgrpName, is_restricted, reg_name as region ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" ORDER BY sys_id, pos_id, acs_id, pv_id, ad_id ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {},
				new BeanPropertyRowMapper<>(RoleADGrpMultiUserMdl.class));
		log.info("System ADGRP Data's size : " + ((dataLst != null) ? dataLst.size() : 0));
		return dataLst;
	}

}
