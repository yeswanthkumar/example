package com.jnj.rqc.useridentity.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusinessFunctionModel {
	String bfId;
	String bfName;
	String bfDescription;
	String isActive;


	@Override
	public String toString() {
		return "BusinessFunctionModel [bfId=" + bfId + ", bfName=" + bfName + ", bfDescription=" + bfDescription
				+ ", isActive=" + isActive + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BusinessFunctionModel other = (BusinessFunctionModel) obj;
		if (bfDescription == null) {
			if (other.bfDescription != null)
				return false;
		} else if (!bfDescription.equals(other.bfDescription))
			return false;
		if (bfId == null) {
			if (other.bfId != null)
				return false;
		} else if (!bfId.equals(other.bfId))
			return false;
		if (bfName == null) {
			if (other.bfName != null)
				return false;
		} else if (!bfName.equals(other.bfName))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfDescription == null) ? 0 : bfDescription.hashCode());
		result = prime * result + ((bfId == null) ? 0 : bfId.hashCode());
		result = prime * result + ((bfName == null) ? 0 : bfName.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		return result;
	}




}
