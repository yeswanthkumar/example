package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RawSysDpendncMdl {
	private int reqid;
	private String sysid;
	private String sysname;
	private String posid;
	private String posname;
	private String accid;
	private String accname;
	private String posvarid;
	private String posvarname;
	private String acceptDeny;
	private String resolutionCmnts;
	private String adgrpName;

}
