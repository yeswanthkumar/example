package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.F983051Mdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class F00821Handler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(F00821Handler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: PD7333.F983051");
		String filePath = "";
		List<F983051Mdl> dataList = getF983051Data();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("F983051", dataList);
		}
		return filePath;
	}


	private List<F983051Mdl> getF983051Data() throws SQLException, DataAccessException{
		List<F983051Mdl> dataList = dBExtrDao.getF983051Data();
		return dataList;
	}


	private String createCSVReport(String fileName, List<F983051Mdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CCRA_CONVERSION CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String headerStr = "VRPID,VRVERS,VRREPORTID,VRVERSIONID,VRJD,VREXCL,VRUSER,VRVCD,VRVED,VRPROPTMID,VRPOID,VROPCR,"+
					 			"VRVLISTMODE,VRVERTXTID, VRCHKOUTSTS,VRCHKOUTDAT,VRUSR0,VRVRSAVAIL,VRENHV,VRMKEY,VRPODATA,"+
					 			"VRDSTNM, VRVCC1, VRVCC2,VRVCC3,VRVCC4,VRVCC5,VRFRMTSTR";
			 String [] header = headerStr.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
