package com.jnj.rqc.mastermetadata.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserExcessiveReqRptMdl {
	private Long userId;
	private String userName;
	private String userEmail;
    private Long reqId;
    private Long reqBy;
    private String req_status;
    private String status_name;
    private String sectorName;
    private String systemName;
    private Double excessPercentage;
    private Double limit;

}
