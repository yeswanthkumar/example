package com.jnj.rqc.dbextr.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConsRespUnitReq {
	String cntryIds;
	String secIds;
}
