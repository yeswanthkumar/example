package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.RqcReportDao;
import com.jnj.rqc.models.AppRoutingModel;
import com.jnj.rqc.reportmodels.AppRoles;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.reportmodels.ReqLogModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.RqcReportService;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>RqcReportServiceImpl.java</b>
 * @author : DChauras @Created : Feb 19, 2020 11:12:22 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class RqcReportServiceImpl implements RqcReportService {
	static final Logger log = LoggerFactory.getLogger(RqcReportServiceImpl.class);

	@Autowired
	RqcReportDao rqcReportDao;

	@Autowired
	CSVReportWriter csvReportWriter;



	@SuppressWarnings("all")
	@Override
	public Map<String, ReportDataModel> processRQCReport(String startDate, String endDate, int status, String appName) {
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		log.info("Received Start Date :"+startDate +"  End date : "+endDate);
		Map<String, ReportDataModel> repDataMap = new HashMap<>();
		try{
			List<ReportDataModel> dataList =  rqcReportDao.getRqcReportData(startDate, endDate);

			if(dataList!= null && !dataList.isEmpty()) {
				dataList.forEach(item->{
					repDataMap.put(item.getTicktNo(), item);
				});
				getRoleDetails(repDataMap, appName);
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		//Blocak Added to to eliminate records with NO APPROVAL
		if(status == 2) {
			Map<String, ReportDataModel> tempMap = new HashMap<>();
			repDataMap.forEach((key,repData) ->{
				if(repData.getReqLogs() != null && repData.getReqLogs().size() > 0 ) {
					tempMap.put(key, repData);
				}
			});
			repDataMap.clear();
			repDataMap.putAll(tempMap);
		}

		//Filtering Code not matching the System Code
		if(appName != null && appName.length() > 0) {
			Map<String, ReportDataModel> tempMap = new HashMap<>();
			repDataMap.forEach((key,repData) ->{
				if(repData.getRoles() != null && repData.getRoles().size() > 0 ) {
					tempMap.put(key, repData);
				}
			});
			repDataMap.clear();
			repDataMap.putAll(tempMap);
		}

		return repDataMap;
	}

	@Override
	@SuppressWarnings("all")
	public void getRoleDetails(Map<String, ReportDataModel> repDataMap, String appName) {
		log.info("Data Map Received has :"+ repDataMap.size()+" Rows");
		try{
			String[] keys = Arrays.copyOf(repDataMap.keySet().toArray(), repDataMap.keySet().size(), String[].class);
			//If Ticket Count is more than 1000
			List<AppRoles> tktAppRls	= new ArrayList<>();
			List<ReqLogModel> tktLogs	= new ArrayList<>();
			if(keys.length > 900) {
				List<String[]> keyList = Utility.getKeySetList(keys, 900);
				for(String[] tktArr:keyList){
					//tktAppRls.addAll(rqcReportDao.getTktRoles(tktArr));
					tktAppRls.addAll(rqcReportDao.getTktAppRoles(tktArr, Utility.getSubAppIds(appName)));
					tktLogs.addAll(rqcReportDao.getTktReqLogs(tktArr));
				}
			}else {
				tktAppRls	= rqcReportDao.getTktAppRoles(keys, Utility.getSubAppIds(appName));
				tktLogs	    = rqcReportDao.getTktReqLogs(keys);
			}

			//Adding Roles to Map
			tktAppRls.forEach(item ->{
				ReportDataModel mdl = repDataMap.get(item.getTicktNo());
				List<AppRoles> chldRls = mdl.getRoles();
				if(chldRls == null) {
					chldRls = new ArrayList<>();
					chldRls.add(item);
				}else {
					chldRls.add(item);
				}
				mdl.setRoles(chldRls);
				repDataMap.put(item.getTicktNo(), mdl);
			});


			//Adding Work Log to Map
			tktLogs.forEach(item ->{
				ReportDataModel mdl = repDataMap.get(item.getTicktNo());
				List<ReqLogModel> chldLgs = mdl.getReqLogs();
				if(chldLgs == null) {
					chldLgs = new ArrayList<>();
					chldLgs.add(item);
				}else {
					chldLgs.add(item);
				}
				mdl.setReqLogs(chldLgs);
				repDataMap.put(item.getTicktNo(), mdl);
			});
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

	}

	@Override
	public String createRQCCsvReport(String fileName, List<ReportDataModel> repDataList) {
		String filePath = csvReportWriter.createRQCCSVReport(fileName+"_"+Utility.fmtMDY(new Date())+".csv", repDataList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}


	@Override
	public String createRoutingFile(String fileName, List<AppRoutingModel> rtModel) {
		String filePath = csvReportWriter.createRoutingCSVReport(fileName+"_"+Utility.fmtMDY(new Date())+".csv", rtModel);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}




}
