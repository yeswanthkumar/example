package com.jnj.rqc.conflictModel;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSMHistDataMdl {
	private String 	dispName;
	private String 	parent;
	private String 	code;
	private String 	fName;
	private String 	lName;
	private String 	wwid;
	private String 	email;
	private String 	status;
	private String 	adgroup;
	private Date 	effDate;
	private Date 	vldFrom;
	private Date 	vldTo;


	@Override
	public String toString() {
		return "CSMHistDataMdl [dispName=" + dispName + ", parent=" + parent + ", code=" + code + ", fName=" + fName
				+ ", lName=" + lName + ", wwid=" + wwid + ", email=" + email + ", status=" + status + ", adgroup="
				+ adgroup + ", effDate=" + effDate + ", vldFrom=" + vldFrom + ", vldTo=" + vldTo + "]";
	}


	public String getData() {
		return dispName + "~" + parent + "~" + code + "~" + fName + "~" + lName + "~" + wwid + "~" + email + "~" + status + "~"	+ adgroup + "~" + Utility.fmtCsmDt2Str(effDate) + "~" + Utility.fmtCsmDt2Str(vldFrom) + "~" + Utility.fmtCsmDt2Str(vldTo);
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		CSMHistDataMdl other = (CSMHistDataMdl) obj;
		if (adgroup == null) {
			if (other.adgroup != null)
				return false;
		} else if (!adgroup.equals(other.adgroup))
			return false;
		if (effDate == null) {
			if (other.effDate != null)
				return false;
		} else if (!effDate.equals(other.effDate))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (vldFrom == null) {
			if (other.vldFrom != null)
				return false;
		} else if (!vldFrom.equals(other.vldFrom))
			return false;
		if (vldTo == null) {
			if (other.vldTo != null)
				return false;
		} else if (!vldTo.equals(other.vldTo))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adgroup == null) ? 0 : adgroup.hashCode());
		result = prime * result + ((effDate == null) ? 0 : effDate.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((vldFrom == null) ? 0 : vldFrom.hashCode());
		result = prime * result + ((vldTo == null) ? 0 : vldTo.hashCode());
		return result;
	}




}
