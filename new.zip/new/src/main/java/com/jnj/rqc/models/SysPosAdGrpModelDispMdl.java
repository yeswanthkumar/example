package com.jnj.rqc.models;

import java.util.List;

import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SysPosAdGrpModelDispMdl {
	String bussFunc;
	String secIds;
	String regIds;
	String sysId;
	String sysName;
	String ascTypIds;
	List<KeyValPair> acsTypes;
	String posIds;
	List<KeyValPair> positions;
	String posVarIds;
	List<KeyValPair> posnVariants;
	String adGrpIds;
	List<UserRoleADGrpMdl> appAdGrps;
	List<String> allSysVarList;
	List<KeyValPair> allSysVarListKV;
	boolean isExcessive;
	private double exPercentage;
}
