package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.service.HCSExtrDataService;
import com.jnj.rqc.service.JDEExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;




/**
 * File    : <b>HCSDataExtrController.java</b>
 * @author : DChauras @Created : Sep 9, 2021 12:02:14 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Controller
public class HCSDataExtrController {
	static final Logger log = LoggerFactory.getLogger(HCSDataExtrController.class);

	@Autowired
	JDEExtrDataService jDEExtrDataService;
	@Autowired
	HCSExtrDataService hCSExtrDataService;

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;

	@Autowired
	EmailUtil emailUtil;

	String BASE_REGION = "REGION";


	@PostMapping("/getHcsExtrEnvironmentData")
    public ResponseEntity<TableRespDto> getHcsExtrEnvironmentData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	TableRespDto tableRespDto = hCSExtrDataService.getEnvData(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

	@GetMapping("/loadHCSUser2RolePage")
    public String loadHCSUser2RolePage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadHCSProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	return "sapextraction/hcsuser2rolepage";
    }


	@PostMapping("/loadHCSUser2RolePageData")
    public String loadHCSUser2RolePageData(@RequestParam("regions") String regions, @RequestParam("pltNames") String pltNames, @RequestParam("environmentId") String environmentId,
    		@RequestParam("sysNames") String sysNames, Model model, HttpServletRequest request) {
    	log.info("region: "+regions+" Platform: "+pltNames+" environmentId: "+environmentId+" sysNames: "+sysNames);
    	String regParam = regions;
    	List<String> regNames = Utility.loadHCSProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );

    	String selPlts = pltNames;
    	List<String> platformNames = Utility.loadHCSProperty(regParam);
    	model.addAttribute("platformNames", platformNames );
    	model.addAttribute("selPlts", selPlts );

    	String envIdParam = environmentId;
    	List<String> envIdNames = Utility.loadHCSProperty(regParam+"_"+selPlts);
    	model.addAttribute("envIdNames", envIdNames );
    	model.addAttribute("envIdParam", envIdParam );

    	String selSysNm = sysNames;
    	List<String> systemNames = Utility.loadHCSProperty(regParam+"_"+selPlts+"_"+envIdParam);
    	model.addAttribute("systemNames", systemNames );
    	model.addAttribute("selSysNm", selSysNm );

    	if("0".equals(regions) || "0".equals(pltNames) || "0".equals(environmentId) || "0".equals(sysNames) ) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region/Platform/Environment/System.");
            return "sapextraction/hcsuser2rolepage";
    	}

    	String templSysParam = regParam+"_"+selPlts+"_"+envIdParam+"_"+selSysNm;
    	log.info("TemplateName: "+templSysParam);

    	List<SapGaaUser2RoleModel> user2RoleData = hCSExtrDataService.readUser2RoleData(templSysParam, "I");
    	//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();
    	for(SapGaaUser2RoleModel mdl:user2RoleData) {
    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
    				activeTrfData.add(mdl);
    			}
    		}else {
    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
    				incompleteData.add(mdl);
    			}
    		}
    	}
    	request.getSession().removeAttribute("INVALID_HCS_USER2ROLE");//Removing OLD Data
    	if(!incompleteData.isEmpty()) {
    		UserSearchModel srchUsr = null;
			for(SapGaaUser2RoleModel uMdl:incompleteData) {
    			String usrID = uMdl.getUserId().trim();
    			srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usrID, 0);
    			if(srchUsr != null ) {
					uMdl.setUserStatus(srchUsr.getEmpStatTxt());
				}else {
					uMdl.setUserStatus("NOT FOUND");
				}
    		}
    		request.getSession().setAttribute("INVALID_HCS_USER2ROLE", incompleteData);
    		log.info("Total USER-ROLE(INCOMPLETE DATA) : "+incompleteData.size());
    	}

    	request.getSession().setAttribute("HCSUSER_ROLEDATA", activeTrfData);//Only ACTIVE/TRANSFER RECORDS
    	request.getSession().setAttribute("PLATFORM", selPlts+"_"+selSysNm);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	model.addAttribute("HCSUSER_ROLEDATA", activeTrfData);
    	String msg  = "Status: Total USER-ROLE Data: "+ ((activeTrfData == null || activeTrfData.isEmpty() ) ?  "0": activeTrfData.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	//TODO - Added flag for export
    	model.addAttribute("EXPORT_ALLOWED", "Y");
    	//END flag
    	return "sapextraction/hcsuser2rolepage";
    }

	@ResponseBody
    @GetMapping("/downHcsUser2RoleExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downHcsUser2RoleExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading HCS User to Role Excel ");
		String fileNm ="UsertoRole_Review_"+request.getSession().getAttribute("PLATFORM");
		String invldFlNm ="INCOMPLETE_UsertoRole_Review_"+request.getSession().getAttribute("PLATFORM");
		List<SapGaaUser2RoleModel> actTrfData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("HCSUSER_ROLEDATA");
		List<SapGaaUser2RoleModel> incompleteData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("INVALID_HCS_USER2ROLE");
		String filePath = sAPExtrGaaDataService.writeSapGaaUser2RoleXLS(actTrfData, fileNm, "User2Role");
		String invldFlPath = sAPExtrGaaDataService.writeSapGaaUser2RoleXLS(incompleteData, invldFlNm,"InvalidData");
		String zipfilePath = Utility.createZip(Arrays.asList(filePath,invldFlPath), Constants.REPO_OUT_LOC+fileNm+"_"+Utility.fmtMDY(new Date())+".zip");
    	File fl = new File(zipfilePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	 @SuppressWarnings("all")
	 @ResponseBody
	 @GetMapping("/exportHCSU2LIndividualSystemData")
	 public ResponseEntity<InputStreamResource> exportHCSU2LIndividualSystemData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		 String template = (String) request.getSession().getAttribute("TEMPLATE");
			log.info("Export HCS User to Role Data for: "+template);
			StringBuilder actions= new StringBuilder();
			actions.append("Export HCS/BRAVO User to Role Data for:"+template+"\n");
			actions.append("Checking Export Status\n");
			String[] tmplArr=template.split("_");
			synchronized (tmplArr) {
				int count = sAPExtrRegionWiseService.getExistingScheduleCount(tmplArr[0], "E", "U");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
				if(count > 0) {
					actions.append("User to Role Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
				}else {
					UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
					List<SapGaaUser2RoleModel> userAccessData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("HCSUSER_ROLEDATA");
					actions.append("Total Records to be replaced : "+userAccessData.size()+" \n Clearing records from Table.\n");
					int delRec = sAPExtrRegionWiseService.deleteUser2RoleTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
					actions.append("Total records deleted : "+delRec+"\n\n");
					actions.append("Inserting "+userAccessData.size()+" Records\n");
					int insRecords = jDEExtrDataService.insertUser2RoleTransactions(userAccessData, template, curUser.getJnjMsftUsrnmTxt());
					actions.append("Total Records inserted : "+insRecords+"\n" );
					try {
						//Building Summary
						TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
						sumMdl.setRegion(tmplArr[0]);
						sumMdl.setPlatform(tmplArr[1]);
						sumMdl.setEnvironment(tmplArr[2]);
						sumMdl.setSystem(tmplArr[3]);
						sumMdl.setCreatedRecCount(insRecords);
						sumMdl.setCreatedDt(new Date());
						sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
						sumMdl.setCollStatus("C");
						actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
						sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
						actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
					} catch (Exception e) {
						log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
					}
				}
			}
			String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
			String filePath = jDEExtrDataService.writeLogData(actions, fileNm);
			File fl = new File(filePath);
			log.info("Download File name:"+fl.getName());
			InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
			return ResponseEntity.ok()
	 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
	     	.contentType(MediaType.TEXT_PLAIN)
	     	.contentLength(fl.length())
	     	.body(resource);
	   }





  }
