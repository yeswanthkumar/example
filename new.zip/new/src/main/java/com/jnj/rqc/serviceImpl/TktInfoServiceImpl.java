package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.RqcReportDao;
import com.jnj.rqc.dao.TktInfoDao;
import com.jnj.rqc.reportmodels.AppRoles;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.reportmodels.ReqLogModel;
import com.jnj.rqc.service.TktInfoService;
import com.jnj.rqc.util.Utility;

@Service
public class TktInfoServiceImpl implements TktInfoService {
	static final Logger log = LoggerFactory.getLogger(TktInfoServiceImpl.class);
	@Autowired
	TktInfoDao tktInfoDao;

	@Autowired
	RqcReportDao rqcReportDao;


	@Override
	public Map<String, ReportDataModel> getUserTktInfo(String[] wwids) {
		Map<String, ReportDataModel> repDataMap = new HashMap<>();
		try{
			List<ReportDataModel> dataList =  tktInfoDao.getUserTktInfo(wwids);
			if(dataList!= null && !dataList.isEmpty()) {
				dataList.forEach(item->{
					repDataMap.put(item.getTicktNo(), item);
				});
				getRoleDetails(repDataMap, null);
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		//Blocak Added to to eliminate records with NO APPROVAL
		/*if(status == 2) {
			Map<String, ReportDataModel> tempMap = new HashMap<String, ReportDataModel>();
			repDataMap.forEach((key,repData) ->{
				if(repData.getReqLogs() != null && repData.getReqLogs().size() > 0 ) {
					tempMap.put(key, repData);
				}
			});
			repDataMap.clear();
			repDataMap.putAll(tempMap);
		}*/

		//Filter Test Tickets with No Roles Submited
		Map<String, ReportDataModel> tempMap = new HashMap<>();
		repDataMap.forEach((key,repData) ->{
			if(repData.getRoles() != null && repData.getRoles().size() > 0 ) {
				tempMap.put(key, repData);
			}
		});
		repDataMap.clear();
		repDataMap.putAll(tempMap);

		return repDataMap;
		}


	@Override
	public Map<String, ReportDataModel> searchTktInfo(String tktNo) {
		Map<String, ReportDataModel> repDataMap = new HashMap<>();
		try{
			List<ReportDataModel> dataList =  tktInfoDao.searchTktInfo(tktNo);
			if(dataList!= null && !dataList.isEmpty()) {
				dataList.forEach(item->{
					repDataMap.put(item.getTicktNo(), item);
				});
				getRoleDetails(repDataMap, null);
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		//Filter Test Tickets with No Roles Submited
		Map<String, ReportDataModel> tempMap = new HashMap<>();
		repDataMap.forEach((key,repData) ->{
			if(repData.getRoles() != null && repData.getRoles().size() > 0 ) {
				tempMap.put(key, repData);
			}
		});
		repDataMap.clear();
		repDataMap.putAll(tempMap);

		return repDataMap;
	}

	@Override
	@SuppressWarnings("all")
	public void getRoleDetails(Map<String, ReportDataModel> repDataMap, String appName) {
		log.info("Data Map Received has :"+ repDataMap.size()+" Rows");
		try{
			String[] keys = Arrays.copyOf(repDataMap.keySet().toArray(), repDataMap.keySet().size(), String[].class);
			//If Ticket Count is more than 1000
			List<AppRoles> tktAppRls	= new ArrayList<>();
			List<ReqLogModel> tktLogs	= new ArrayList<>();
			if(keys.length > 900) {
				List<String[]> keyList = Utility.getKeySetList(keys, 900);
				for(String[] tktArr:keyList){
					tktAppRls.addAll(rqcReportDao.getTktAppRoles(tktArr, Utility.getSubAppIds(appName)));
					tktLogs.addAll(rqcReportDao.getTktReqLogs(tktArr));
				}
			}else {
				tktAppRls	= rqcReportDao.getTktAppRoles(keys, Utility.getSubAppIds(appName));
				tktLogs	    = rqcReportDao.getTktReqLogs(keys);
			}

			//Adding Roles to Map
			tktAppRls.forEach(item ->{
				ReportDataModel mdl = repDataMap.get(item.getTicktNo());
				List<AppRoles> chldRls = mdl.getRoles();
				if(chldRls == null) {
					chldRls = new ArrayList<>();
					chldRls.add(item);
				}else {
					chldRls.add(item);
				}
				mdl.setRoles(chldRls);
				repDataMap.put(item.getTicktNo(), mdl);
			});


			//Adding Work Log to Map
			tktLogs.forEach(item ->{
				ReportDataModel mdl = repDataMap.get(item.getTicktNo());
				List<ReqLogModel> chldLgs = mdl.getReqLogs();
				if(chldLgs == null) {
					chldLgs = new ArrayList<>();
					chldLgs.add(item);
				}else {
					chldLgs.add(item);
				}
				mdl.setReqLogs(chldLgs);
				repDataMap.put(item.getTicktNo(), mdl);
			});
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

	}


}

