package com.jnj.rqc.userreq.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.AbsCancelRejectRequestModel;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSecExcesvRestrictedAccsMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.IAMReqRoleMdl;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.ReqSrchConstMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.userabs.models.UserReqDetCompMdl;
import com.jnj.rqc.useridentity.models.ConflictRequestedModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.util.Utility;

@Repository
public class AbsUserRequesDaoImpl extends BaseDao implements AbsUserRequesDao {

	static final Logger log = LoggerFactory.getLogger(AbsUserRequesDaoImpl.class);




	@Override
	public int saveAbsUserRequest(UserReqCompMdl reqModel) throws SQLException, DataAccessException {
		log.info("Saving User Abs Request for : "+reqModel.getUserid());
		int requestId = 0;
		String seqSql= " SELECT req_head_seq.nextval from dual";
		String headerSql = " INSERT INTO SOD_DB_USER.ZUREQHEAD "+
				" (REQID, TYPEID, REQUESTEDON, REQUESTEDBY, USERID, MANAGERID, BFID, SECIDS, REGIDS, REQ_STATUS, CONFLICT_FOUND, IS_EXCES, UPDATEDBY, UPDATEDON, COMMENTS, REQUESTEDBYNAME, USERNAME, MANAGERNAME, REQSYS, REQSYSNAMES ) " +
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		log.info("Saving User Abs Request for reqModel : "+reqModel);
		int reqId = getJdbcTemplateSRADUtils().queryForObject(seqSql, Integer.class);
		if(reqId > 0) {
			log.info("Saving User Abs Request header block called ");
			int insResult = getJdbcTemplateSRADUtils().update(headerSql, new Object[] {reqId, reqModel.getTypeid(), new Date(), reqModel.getRequestedby(),
					reqModel.getUserid(), reqModel.getManagerid(), reqModel.getBfid(), reqModel.getSecids(), reqModel.getRegids(), reqModel.getReqStatus(),
					reqModel.getConflictFound(), reqModel.getIsExces(), reqModel.getRequestedby(), new Date(), reqModel.getComments(), reqModel.getRequestedbyname(), reqModel.getUsername(), reqModel.getManagername(), reqModel.getReqsys(), reqModel.getReqsysnames() });
			if(insResult > 0) {
				log.info("Saving User Abs Request detail block called ");
				List<UserReqDetCompMdl> detailMdlLst = reqModel.getSysList();
				requestId = reqId;
				String detSql = " INSERT INTO SOD_DB_USER.ZUREQDETAIL (REQID, SYSID, POSIDS, ACCIDS, POSVARIDS, ADIDS, DT_CREATED ) VALUES ( ?, ?, ?, ?, ?, ?, ? ) ";
				int[] status = getJdbcTemplateSRADUtils().batchUpdate(detSql,
			            new BatchPreparedStatementSetter() {
							@Override
							public void setValues(PreparedStatement ps, int i) throws SQLException {
								ps.setInt(1, reqId);
								ps.setString(2, detailMdlLst.get(i).getSysid());
								ps.setString(3, detailMdlLst.get(i).getPosids());
								ps.setString(4, detailMdlLst.get(i).getAccids());
								ps.setString(5, detailMdlLst.get(i).getPosvarids());
								ps.setString(6, detailMdlLst.get(i).getAdids());
								ps.setDate(7, new java.sql.Date(new Date().getTime()));
							}

							@Override
							public int getBatchSize() {
								return detailMdlLst.size();
							}
						});
			}else {
				log.error("Cannot Save User Abs Request");
			}
		}
		log.info("Saved Abs Request Data with ID ::"+requestId);
		return requestId;
	}


	@Override
	public List<IAMReqRoleMdl> getRequestRoleStatus(String reqId) throws SQLException, DataAccessException {
		List<IAMReqRoleMdl> dataLst = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append(" Select a.REQID as reqId, a.SEQID as seqId, a.USERID as userId, a.SYSID as sysId, a.SYSNAME as sysName, a.POSID as posId, a.POSNAME as posName, a.PVARID as pvId, a.PVARNAME as pvName, ");
		sql.append(" a.ADGRPID as adgrpId, a.ADGRPNAME as adgrpName, a.REQUESTEDBY as reqBy, a.COMMENTS, a.SUBM_UID, a.SUBM_DATE, a.SUBM_STATUS, a.API_STATUS, a.API_MSG, a.UPD_DATE, a.API_ERROR_MSG ");
		sql.append(" FROM  SOD_DB_USER.ZUSER_REQUESTED_ROLES a, SOD_DB_USER.ZSYSTEM b WHERE a.REQID = ? ");
		//sql.append(" FROM  SOD_DB_USER.ZUSER_REQUESTED_ROLES a, SOD_DB_USER.ZSYSTEM b WHERE a.REQID = ? AND a.API_STATUS IS  NOT NULL AND a.API_STATUS <> 'P' ");
		sql.append(" AND a.SYSID = b.SYSID ");
		sql.append(" ORDER BY a.REQID, a.SYSID, a.SEQID ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(IAMReqRoleMdl.class));
		log.info("Submitted Request size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	/* (non-Javadoc)
	 * @see com.jnj.rqc.userreq.dao.AbsUserRequesDao#getSavedUserRequests(java.lang.String, java.lang.String, java.lang.String, int)
	 */
	@Override
	public List<AbsUserReqMdl> getAllSavedUserRequests(String startDate, String endDate, int paramType, String paramValue)throws SQLException, DataAccessException {
		List<AbsUserReqMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.REQID, a.TYPEID, b.TYPENAME as typename, a.REQUESTEDON, a.REQUESTEDBY, a.REQUESTEDBYNAME, a.USERID, a.USERNAME, a.MANAGERID, a.MANAGERNAME, nvl(a.REQSYS,0) as REQSYS, a.REQSYSNAMES, a.BFID, a.SECIDS, a.REGIDS, a.REQ_STATUS, ");
		sql.append(" d.STATUS_NAME as reqStatusDesc, a.CONFLICT_FOUND, a.ROUTED_TO_COMPL, a.CONFLICT_RESOLVED, a.DATE_RESOLVED, a.IS_EXCES, a.UPDATEDBY, a.UPDATEDON, a.COMMENTS ");
		sql.append(" FROM SOD_DB_USER.ZUREQHEAD a, SOD_DB_USER.ZREQTYPE b , SOD_DB_USER.ZREQUESTSTATUS d ");
		sql.append(" WHERE a.TYPEID = b.TYPEID  AND a.REQ_STATUS = d.STATUS_ID ");
		sql.append(" AND a.REQUESTEDON between TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') and TO_DATE(?, 'mm/dd/yyyy hh24:mi:ss') ");
		paramValue = (paramValue == null? "":paramValue.toUpperCase());
		if(paramType == 1) {
			sql.append(" AND a.USERID = '"+paramValue+"' ");
		}else if(paramType == 2) {
			sql.append(" AND UPPER(a.USERNAME) like '%"+paramValue+"%' ");
		}else if(paramType == 3) {
			sql.append(" AND a.REQUESTEDBY = '"+paramValue+"' ");
		}else if(paramType == 4) {
			sql.append(" AND UPPER(a.REQUESTEDBYNAME) like '%"+paramValue+"%' ");
		}else if(paramType == 5) {
			sql.append(" AND a.MANAGERID = '"+paramValue+"' ");
		}else if(paramType == 6) {
			sql.append(" AND UPPER(a.MANAGERNAME) like '%"+paramValue+"%' ");
		}else if(paramType == 7) {
			sql.append(" AND a.REQUESTEDON = TO_DATE('"+paramValue+"', 'mm/dd/yyyy') ");
		}else if(paramType == 8) {
			sql.append(" AND UPPER(a.REQSYSNAMES) like '%"+paramValue+"%' ");
		}else if(paramType == 9) {
			sql.append(" AND a.TYPEID = '"+paramValue+"' ");
		}else if(paramType == 10) {
			sql.append(" AND a.REQ_STATUS = '"+paramValue+"' ");
		}else if(paramType == 11) {
			sql.append(" AND a.REQID = '"+paramValue+"' ");
		}
		sql.append(" ORDER BY a.REQID DESC, a.REQUESTEDON DESC  ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {startDate, endDate}, new BeanPropertyRowMapper<>(AbsUserReqMdl.class));
		log.info("User Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<AbsUserReqMdl> getRequestDataByReqID(String reqId)throws SQLException, DataAccessException {
		List<AbsUserReqMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.REQID, a.TYPEID, b.TYPENAME as typename, a.REQUESTEDON, a.REQUESTEDBY, a.REQUESTEDBYNAME, a.USERID, a.USERNAME, a.MANAGERID, a.MANAGERNAME, nvl(a.REQSYS,0) as REQSYS, a.REQSYSNAMES, a.BFID, a.SECIDS, a.REGIDS, a.REQ_STATUS, ");
		sql.append(" d.STATUS_NAME as reqStatusDesc, a.CONFLICT_FOUND, a.ROUTED_TO_COMPL, a.CONFLICT_RESOLVED, a.DATE_RESOLVED, a.IS_EXCES, a.UPDATEDBY, a.UPDATEDON, a.COMMENTS ");
		sql.append(" FROM SOD_DB_USER.ZUREQHEAD a, SOD_DB_USER.ZREQTYPE b , SOD_DB_USER.ZREQUESTSTATUS d ");
		sql.append(" WHERE a.TYPEID = b.TYPEID  AND a.REQ_STATUS = d.STATUS_ID ");
		sql.append(" AND a.REQID = ? ");
		sql.append(" ORDER BY a.REQID DESC, a.REQUESTEDON DESC  ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(AbsUserReqMdl.class));
		log.info("User Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}





	/* (non-Javadoc)
	 * @see com.jnj.rqc.userreq.dao.AbsUserRequesDao#saveAbsUserConflicts(int, com.jnj.rqc.models.UserSearchModel, java.util.List)
	 */
	@Override
	public int saveAbsUserConflicts(int requestId, UserSearchModel assocUser, List<UserAbsConflictMdl> confList) throws SQLException, DataAccessException {
		log.info("Saving Conflicts for Request for : "+requestId);

		String detSql = " INSERT INTO SOD_DB_USER.ZUSER_CONFLICT "+
				" (USERID, REQID, RISKID, RISKDESC, APP1, POSV1, APP2, POSV2, CONFLICT, RISK_LEVEL, MIT_ID, MIT_DESC, ISEXISTING, ISEXISTING2) "+
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(detSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, confList.get(i).getRiskid());
				ps.setString(4, confList.get(i).getRiskdesc());
				ps.setString(5, confList.get(i).getApp1());
				ps.setString(6, confList.get(i).getPosv1());
				ps.setString(7, confList.get(i).getApp2());
				ps.setString(8, confList.get(i).getPosv2());
				ps.setString(9, confList.get(i).getConflict());
				ps.setString(10, confList.get(i).getRiskLevel());
				//ps.setString(11, confList.get(i).getMitId());
				//ps.setString(12, confList.get(i).getMitDesc());
				ps.setString(11, "");
				ps.setString(12, "");
				ps.setString(13, confList.get(i).getIsExisting());
				ps.setString(14, confList.get(i).getIsExisting2());
			}

			@Override
			public int getBatchSize() {
				return confList.size();
			}
		});
		log.info("Saved Conflicts Data for RequestID ::"+requestId+" Total Conflicts:"+rowsUpdated.length);
		return rowsUpdated.length;
	}



	@Override
	public int saveAbsExcsvAccess(int requestId, UserSearchModel assocUser, List<AbsExcesvAccsMdl> exList) throws SQLException, DataAccessException {
		log.info("Saving Abs User Excessive Access info for Request for : "+requestId);

		String exSql = " INSERT INTO SOD_DB_USER.ZUREQUEST_EXCSV_ACCESS "+
				" (USERID, REQID, SYSID, LIMIT, IS_EXCSV, EXCSV_PRCNTG, EX_VARIDS, SEL_VARIDS, CREATEDON) "+
				" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(exSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, exList.get(i).getSysid());
				ps.setDouble(4, exList.get(i).getLimit());
				ps.setString(5, exList.get(i).getIsExcsv());
				ps.setDouble(6, exList.get(i).getExcsvPrcntg());
				ps.setString(7, exList.get(i).getExVarids());
				ps.setString(8, exList.get(i).getSelVarids());
				ps.setDate(9, new java.sql.Date(new Date().getTime()));
			}

			@Override
			public int getBatchSize() {
				return exList.size();
			}
		});
		log.info("Saved Excessive Data for RequestID ::"+requestId+" Total Excessive data: "+rowsUpdated.length);
		return rowsUpdated.length;
	}

	@Transactional
	@Override
	public int[] saveAbsRestExcsvAccessSystemData(int requestId, UserSearchModel assocUser, List<AbsSecExcesvRestrictedAccsMdl> sectorDataList, List<RoleADGrpMdl> seletedVars) throws SQLException, DataAccessException{
		log.info("Saving Abs Restrictive/Excessive Access info for Request for : "+requestId);
		int sctrInsCount = saveSectorRestExcsvAccessData(requestId, assocUser, sectorDataList);
		int roleInsCount = saveRestExcsvAccessRolesData(requestId, assocUser, seletedVars);
		log.info("Saved Excessive/Restricted Access Data for RequestID ::"+requestId+" Total Sector data: "+sctrInsCount+"  Roles Roles: "+roleInsCount);
		int[] sysData = {sctrInsCount, roleInsCount};
		return sysData;
	}

	@Transactional
	@Override
	public int saveSectorRestExcsvAccessData( int requestId, UserSearchModel assocUser, List<AbsSecExcesvRestrictedAccsMdl> sectorDataList) throws SQLException, DataAccessException{
		log.info("Saving Sectorwise/Systemwise Restrictive/Excessive Access info for Request for : "+requestId);
		StringBuilder secSql = new StringBuilder();
		secSql.append(" INSERT INTO SOD_DB_USER.ZREQ_RESTRICTIVE_EXCSV_ACCESS " );
		secSql.append(" ( USERID, REQID, SECID, SECNAME, SYSID, SYSNAME, IS_EXCSV, IS_RESTRICTED, EXCSV_PRCNTG, LIMIT ) " );
		secSql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");

		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(secSql.toString(), new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, sectorDataList.get(i).getSecId());
				ps.setString(4, sectorDataList.get(i).getSecName());
				ps.setString(5, sectorDataList.get(i).getSysid());
				ps.setString(6, sectorDataList.get(i).getSysName());
				ps.setString(7, sectorDataList.get(i).getIsExcsv());
				ps.setString(8, sectorDataList.get(i).getIsRestricted());
				ps.setDouble(9, (Math.round((sectorDataList.get(i).getExcsvPrcntg()) * 100) / 100.0));
				ps.setDouble(10, sectorDataList.get(i).getLimit());
			}

			@Override
			public int getBatchSize() {
				return sectorDataList.size();
			}
		});
		log.info("Saved Excessive Data for RequestID ::"+requestId+" Total Excessive data: "+rowsUpdated.length);
		return rowsUpdated.length;
	}

	@Transactional
	@Override
	public int saveRestExcsvAccessRolesData(int requestId, UserSearchModel assocUser, List<RoleADGrpMdl> seletedVars) throws SQLException, DataAccessException{
		log.info("Saving Restrictive/Excessive Access Role info for Request for : "+requestId);
		StringBuilder roleSql = new StringBuilder();
		roleSql.append(" INSERT INTO SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL " );
		roleSql.append(" (USERID, REQID, SECID, SECNAME, SYSID, SYSNAME, POSID, POSNAME, ACCID, ACCNAME, POSVARID, POSVARNAME, IS_RESTRICTED) " );
		roleSql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

		int[] rowsUpdated = getJdbcTemplateSRADUtils().batchUpdate(roleSql.toString(), new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, assocUser.getWwId());
				ps.setInt(2, requestId);
				ps.setString(3, seletedVars.get(i).getSecId());
				ps.setString(4, seletedVars.get(i).getSecName());
				ps.setString(5, seletedVars.get(i).getSysId());
				ps.setString(6, seletedVars.get(i).getSysName());
				ps.setString(7, seletedVars.get(i).getPosId());
				ps.setString(8, seletedVars.get(i).getPosName());
				ps.setString(9, seletedVars.get(i).getAccId());
				ps.setString(10, seletedVars.get(i).getAccName());
				ps.setString(11, seletedVars.get(i).getPvId());
				ps.setString(12, seletedVars.get(i).getPvName());
				ps.setString(13, seletedVars.get(i).getIsRestricted());
			}

			@Override
			public int getBatchSize() {
				return seletedVars.size();
			}
		});
		log.info("Saved Excessive Data for RequestID ::"+requestId+" Total Excessive data: "+rowsUpdated.length);
		return rowsUpdated.length;
	}


	@Override
	public List<ReqSrchConstMdl> getAllSrchConstants() throws SQLException, DataAccessException {
		List<ReqSrchConstMdl> dataLst = new ArrayList<>();
		String sql= " SELECT SKEY, SVAL, SDESC, ISACTIVE FROM SOD_DB_USER.ZREQ_SRCH_CONST WHERE ISACTIVE = 'Y' ORDER BY 1,2 " ;
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(ReqSrchConstMdl.class));
		log.info("Srch Constants size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public int getCountOfPendingRequest(String userId) throws SQLException, DataAccessException {
		StringBuilder qry = new StringBuilder();
		qry.append(" SELECT count(*) as reqCount from SOD_DB_USER.ZUREQHEAD ");
		qry.append(" WHERE REQ_STATUS <= 6 ");
		qry.append(" AND USERID = ? ");
		int recCount = getJdbcTemplateSRADUtils().queryForObject(qry.toString(), new Object[] {userId}, Integer.class);
		log.info("Total Pending Request Records :"+recCount);
		return recCount;
	}



	@Override
	public List<ReqDpendncMdl> getTktDependencies(String reqId) throws SQLException, DataAccessException {
		List<ReqDpendncMdl> dataLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
					  sql.append(" SELECT a.REQID, a.SYSID, b.SYSNAME, a.POSIDS, a.ACCIDS, a.POSVARIDS, a.ADIDS ");
					  sql.append(" FROM SOD_DB_USER.ZUREQDETAIL a, SOD_DB_USER.ZSYSTEM b ");
					  sql.append(" WHERE a.SYSID = b.SYSID AND REQID= ? ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(ReqDpendncMdl.class));
		log.info("Dependencies size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}
	@Override
	public List<String> getTktDependenciesByConflict(String reqId, String sysid1, String sysid2,  String posid1,  String posid2) throws SQLException, DataAccessException {
        List<String> dataList = new ArrayList<>();
        String sql = " SELECT a.POSVARIDS FROM SOD_DB_USER.ZUREQDETAIL a, SOD_DB_USER.ZSYSTEM b "+
                 " WHERE a.SYSID = b.SYSID AND a.REQID= ? AND a.SYSID in (?, ?) and a.POSIDS in (?, ?) ";
        dataList = getJdbcTemplateSRADUtils().queryForList(sql, new Object[] {reqId, sysid1, sysid2, posid1, posid2}, String.class);
        log.info("List of IDS size : "+((dataList !=null)? dataList.size(): 0));
        return dataList;
    }

	@Override
	public List<RawSysDpendncMdl> getSysDependencies(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr) throws SQLException, DataAccessException {
		List<RawSysDpendncMdl> rawData = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, SYS_NAME as SYSNAME, POS_ID as POSID, POS_NAME as POSNAME, ACS_ID as ACCID, ACS_NAME as ACCNAME, PV_ID as POSVARID, PV_NAME as POSVARNAME, AD_NAME as adgrpName ");
		sql.append(" FROM  SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+posnIdArr.length+accIdArr.length+pvarIdArr.length)];
		inParam[prmPos] = sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posnIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "ACS_ID", accIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "PV_ID", pvarIdArr, inParam, sql);
		sql.append(" ORDER BY SYS_ID, POS_ID, ACS_ID, PV_ID ");
		rawData = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(RawSysDpendncMdl.class));
		log.info("Positions size : "+((rawData !=null)? rawData.size(): 0));
		return rawData;
	}

	/*@Override
	public List<RawSysDpendncMdl> getSysDependencies(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr) throws SQLException, DataAccessException {
		List<RawSysDpendncMdl> rawData = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.SYSID, e.SYSNAME, a.POSID, b.POSNAME, a.ACCID, c.ACCNAME, a.POSVARID, d.POSVARNAME  ");
		sql.append(" FROM  SOD_DB_USER.ZMAP_ACC_PVAR a, SOD_DB_USER.ZPOSITION b, SOD_DB_USER.ZACCESSTYPE c, SOD_DB_USER.ZPOSVARIANT d, SOD_DB_USER.ZSYSTEM e ");
		sql.append(" WHERE a.ISACTIVE = 'Y' AND a.SYSID = e.SYSID AND a.POSID = b.POSID  AND a.ACCID = c.ACCID AND a.POSVARID = d.POSVARID ");
		sql.append("AND a.SYSID = ? ");
		int prmPos=0;
		Object[] inParam = new Object[(1+posnIdArr.length+accIdArr.length+pvarIdArr.length)];
		inParam[prmPos] = sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.POSID", posnIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.ACCID", accIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.POSVARID", pvarIdArr, inParam, sql);
		sql.append(" ORDER BY a.SYSID, a.POSID, a.ACCID, a.POSVARID ");
		rawData = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<RawSysDpendncMdl>(RawSysDpendncMdl.class));
		log.info("Positions size : "+((rawData !=null)? rawData.size(): 0));
		return rawData;
	}*/


	@Override
	public List<UserAbsConflictMdl> getRequestLvlConflicts(String reqId) throws SQLException, DataAccessException {
		List<UserAbsConflictMdl> confLst = new ArrayList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT a.USERID, a.REQID, a.RISKID, a.RISKDESC, a.APP1, b.SYSNAME as appName1, a.APP2, c.SYSNAME as appName2, a.POSV1, a.POSV2, a.CONFLICT, a.RISK_LEVEL, ");
		sql.append(" a.MIT_ID, a.MIT_DESC, a.CREATEDON, a.STATUS, a.ACCEPT_DENY, a.COMMENTS, a.RESOLVEDBY, a.RESOLVEDON, a.ISEXISTING, a.ISEXISTING2  ");
		sql.append(" FROM SOD_DB_USER.ZUSER_CONFLICT a, SOD_DB_USER.ZSYSTEM b, SOD_DB_USER.ZSYSTEM c ");
		sql.append(" WHERE a.APP1 = b.SYSID AND a.APP2 = c.SYSID ");
		sql.append(" AND a.REQID = ? ");
		confLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(UserAbsConflictMdl.class));
		log.info("Request Conflicts size : "+((confLst !=null)? confLst.size(): 0));
		return confLst;
	}

	/*@Override
	public List<UserAbsConflictMdl> getRequestLvlConflicts(String reqId) throws SQLException, DataAccessException {
		List<UserAbsConflictMdl> confLst = new ArrayList<UserAbsConflictMdl>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT a.USERID, a.REQID, a.RISKID, a.RISKDESC, a.APP1, b.SYSNAME as appName1, a.APP2, c.SYSNAME as appName2, a.POSV1, d.POSVARNAME as posvName1, ");
		sql.append(" a.POSV2, e.POSVARNAME as posvName2, a.CONFLICT, a.MITIGATING_CONTROL, a.CREATEDON, a.STATUS, a.ACCEPT_DENY, NVL( a.MITI_CNTRL_SEL, 0 ) MITI_CNTRL_SEL, ");
		sql.append(" a.COMMENTS, a.RESOLVEDBY, a.RESOLVEDON ");
		sql.append(" FROM SOD_DB_USER.ZUSER_CONFLICT a, SOD_DB_USER.ZSYSTEM b, SOD_DB_USER.ZSYSTEM c, SOD_DB_USER.ZPOSVARIANT d , SOD_DB_USER.ZPOSVARIANT e ");
		sql.append(" WHERE a.APP1 = b.SYSID AND a.APP2 = c.SYSID AND a.POSV1 = d.POSVARID AND a.POSV2 = e.POSVARID ");
		sql.append(" AND a.REQID = ? ");

		confLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<UserAbsConflictMdl>(UserAbsConflictMdl.class));
		log.info("Request Conflicts size : "+((confLst !=null)? confLst.size(): 0));
		return confLst;
	}*/


	@Override
	public List<AbsExcesvAccsMdl> getRequestLvlExcData(String reqId) throws SQLException, DataAccessException {
		List<AbsExcesvAccsMdl> excLst = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.USERID, a.REQID, a.SYSID, b.SYSNAME, a.LIMIT, a.IS_EXCSV, a.EXCSV_PRCNTG, a.SEL_VARIDS, a.CREATEDON, a.RESOLVED, ");
		sql.append(" a.ACCEPT_DENY, a.ACCEPTED_VARIDS, a.DENIED_VARIDS, nvl(a.CNTRL_SELECTED, 0) as cntrlSelected, a.RESOLUTION_CMNTS, a.RESOLVEDBY, a.RESOLVEDON ");
		sql.append(" FROM SOD_DB_USER.ZUREQUEST_EXCSV_ACCESS a, SOD_DB_USER.ZSYSTEM b ");
		sql.append(" WHERE a.SYSID = b.SYSID ");
		sql.append(" AND a.REQID = ? ");
		sql.append(" ORDER BY a.SYSID ");
		excLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(AbsExcesvAccsMdl.class));
		log.info("Request Excessive Data size : "+((excLst !=null)? excLst.size(): 0));
		return excLst;
	}





	@Override
	public List<StrKeyValPair> getMitigatingControls(String id, String type)  throws SQLException, DataAccessException{
		List<StrKeyValPair> dataLst = new LinkedList<>();
		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT MID AS KEY, MCNTRL AS VAL FROM SOD_DB_USER.ZMITIGATIN_CONTROLS ");
		sql.append(" WHERE ISACTIVE='Y' AND TYPE= '"+type+"' ");
		if(!Utility.isEmpty(id) && !"0".equals(id)) {
			sql.append(" AND MID = '"+id+"' ");
		}
		sql.append("ORDER BY KEY, VAL ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("Mitigating Control size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public int updReqCancelRejectStatus(AbsCancelRejectRequestModel absCancelRejectRequestModel, UserSearchModel approveUser) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE  SOD_DB_USER.ZUREQHEAD ");
		sql.append(" SET REQ_STATUS = ?, REJ_CANCELLED = ?, REJ_CANCELLEDBY = ?, ");
		sql.append(" REJ_CANCELLEDON = sysdate, REJ_CANCELLEDRSN = ? ");
		sql.append(" WHERE REQID = ? AND REQ_STATUS IN (1, 2, 3) ");
		int status = 0;
		if("R".equalsIgnoreCase(absCancelRejectRequestModel.getCancelReject())) {
			status = 8;
		}else {
			status = 9;
		}
		return getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {status, absCancelRejectRequestModel.getCancelReject(),
				absCancelRejectRequestModel.getUserid() ,absCancelRejectRequestModel.getReason(), absCancelRejectRequestModel.getReqid()});
	}





	@Transactional
	@Override
	public int updReqConflictStatus(List<UserAbsConflictMdl> confList, UserSearchModel approveUser) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.ZUSER_CONFLICT ");
		sql.append(" SET STATUS = ?, ACCEPT_DENY = ?, ");
		sql.append(" COMMENTS = ?,  RESOLVEDBY = ?, RESOLVEDON = sysdate, ");
		sql.append(" MIT_ID = ?, MIT_DESC = ? ");
		sql.append(" WHERE REQID = ? AND  APP1 = ? AND APP2 = ? AND POSV1 = ? AND POSV2 = ?");

		int[] recordsUpdated = getJdbcTemplateSRADUtils().batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setString(1, confList.get(i).getStatus());
                ps.setString(2, confList.get(i).getAcceptDeny());
                ps.setString(3, confList.get(i).getComments());
                ps.setString(4, approveUser.getWwId());
                ps.setString(5, confList.get(i).getMitId());
                ps.setString(6, confList.get(i).getMitDesc());
                ps.setString(7, confList.get(i).getReqid());
                ps.setString(8, confList.get(i).getApp1());
                ps.setString(9, confList.get(i).getApp2());
                ps.setString(10, confList.get(i).getPosv1());
                ps.setString(11, confList.get(i).getPosv2());
            }

            @Override
			public int getBatchSize() {
                return confList.size();
            }

        });
		return  recordsUpdated.length;
	}


	@Transactional
	@Override
	public int updReqExcsvRestrictiveAccessStatus(List<RoleADGrpMdl> excsvRestApprovalList, UserSearchModel approveUser) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL ");
		sql.append(" SET ACCEPT_DENY = ?, RESOLVED = ?, RESOLUTION_CMNTS = ?, RESOLVEDBY = ?, RESOLVEDON = sysdate ");
		sql.append(" WHERE REQID = ? AND SECID = ? AND SYSID = ? AND POSID = ? AND ACCID = ? AND POSVARID = ? ");

		int[] recordsUpdated = getJdbcTemplateSRADUtils().batchUpdate(
					sql.toString(), new BatchPreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
	                        ps.setString(1, excsvRestApprovalList.get(i).getAcceptDeny());
	                        ps.setString(2, excsvRestApprovalList.get(i).getResolved());
	                        ps.setString(3, excsvRestApprovalList.get(i).getResolutionCmnts());
	                        ps.setString(4, approveUser.getWwId());
	                        ps.setInt(5, excsvRestApprovalList.get(i).getReqId());
	                        ps.setString(6, excsvRestApprovalList.get(i).getSecId());
	                        ps.setString(7, excsvRestApprovalList.get(i).getSysId());
	                        ps.setString(8, excsvRestApprovalList.get(i).getPosId());
	                        ps.setString(9, excsvRestApprovalList.get(i).getAccId());
	                        ps.setString(10, excsvRestApprovalList.get(i).getPvId());
	                    }

	                    @Override
						public int getBatchSize() {
	                        return excsvRestApprovalList.size();
	                    }

	                });
		return  recordsUpdated.length;
	}




	@Transactional
	@Override
	public int updReqExcsvAccessStatus(List<AbsExcesvAccsMdl> excessiveApprovalList, UserSearchModel approveUser) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE ZUREQUEST_EXCSV_ACCESS ");
		sql.append(" SET RESOLVED = ?, ACCEPT_DENY = ?, ACCEPTED_VARIDS = ?, DENIED_VARIDS = ?, ");
		sql.append(" RESOLUTION_CMNTS = ?, RESOLVEDBY = ?, RESOLVEDON = sysdate ");
		sql.append(" WHERE REQID = ? AND SYSID = ? ");

		int[] recordsUpdated = getJdbcTemplateSRADUtils().batchUpdate(
					sql.toString(), new BatchPreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
	                        ps.setString(1, excessiveApprovalList.get(i).getResolved());
	                        ps.setString(2, excessiveApprovalList.get(i).getAcceptDeny());
	                        ps.setString(3, excessiveApprovalList.get(i).getAcceptedVarids());
	                        ps.setString(4, excessiveApprovalList.get(i).getDenedVarids());
	                        ps.setString(5, excessiveApprovalList.get(i).getResolutionCmnts());
	                        ps.setString(6, excessiveApprovalList.get(i).getResolvedby());
	                        ps.setInt(7, excessiveApprovalList.get(i).getReqid());
	                        ps.setString(8, excessiveApprovalList.get(i).getSysid());
	                    }

	                    @Override
						public int getBatchSize() {
	                        return excessiveApprovalList.size();
	                    }

	                });
		return  recordsUpdated.length;
	}

	@Override
	public int confUpdateRequestStatus(String requestId, int status, String confResolved) throws SQLException, DataAccessException {
			log.info("Update Request Status  REQID: "+requestId );
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.ZUREQHEAD ");
			sql.append(" SET REQ_STATUS = ?, CONFLICT_RESOLVED = ?, DATE_RESOLVED = sysdate ");
			sql.append(" WHERE REQID = ? " );
			return  getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {status, confResolved, requestId});
	}

	@Transactional
	@Override
	public int saveVariantApprovalStatus(List<RawSysDpendncMdl> variantDetails, String reqid) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" INSERT INTO SOD_DB_USER.ZREQ_EXCSVACCESS_APPROVAL ");
		sql.append(" (REQID, SYSID, SYSNAME, POSID, POSNAME, ACCID, ACCNAME, POSVARID, POSVARNAME, ACCEPT_DENY, RESOLUTION_CMNTS) ");
		sql.append(" Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		int[] insRec = getJdbcTemplateSRADUtils().batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
	                        ps.setString(1, reqid);
	                        ps.setString(2, variantDetails.get(i).getSysid());
	                        ps.setString(3, variantDetails.get(i).getSysname());
	                        ps.setString(4, variantDetails.get(i).getPosid());
	                        ps.setString(5, variantDetails.get(i).getPosname());
	                        ps.setString(6, variantDetails.get(i).getAccid());
	                        ps.setString(7, variantDetails.get(i).getAccname());
	                        ps.setString(8, variantDetails.get(i).getPosvarid());
	                        ps.setString(9, variantDetails.get(i).getPosvarname());
	                        ps.setString(10, variantDetails.get(i).getAcceptDeny());
	                        ps.setString(11, variantDetails.get(i).getResolutionCmnts());
	                    }

	                    @Override
						public int getBatchSize() {
	                        return variantDetails.size();
	                    }

	                });
		return  insRec.length;
	}


	@Override
	public List<String> getApproverCategoryEmails(List<String> sysList, int catCd) throws SQLException, DataAccessException {
		List<String> dataLst = new ArrayList<>();
			StringBuilder sql= new StringBuilder();
			sql.append(" SELECT EMAIL_IDS from SOD_DB_USER.ZAPPROVAL_CATEGORY ");
			sql.append(" WHERE APPROVAL_TYPE = '"+catCd+"'" );
			String inSql = String.join(",", Collections.nCopies(sysList.size(), "?"));
			sql.append(" AND SYSID IN ("+inSql+") ");
			dataLst = getJdbcTemplateSRADUtils().queryForList(sql.toString(), sysList.toArray(), String.class);
			log.info("List of IDS size : "+((dataLst !=null)? dataLst.size(): 0));
			return dataLst;
	}


	@Override
	public List<AbsUserReqMdl> getEligibleApprovedRequests()throws SQLException, DataAccessException {
		List<AbsUserReqMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.REQID, a.TYPEID, b.TYPENAME as typename, a.REQUESTEDON, a.REQUESTEDBY, a.REQUESTEDBYNAME, a.USERID, a.USERNAME, a.MANAGERID, a.MANAGERNAME, nvl(a.REQSYS,0) as REQSYS, a.REQSYSNAMES, a.BFID, a.SECIDS, a.REGIDS, a.REQ_STATUS, ");
		sql.append(" d.STATUS_NAME as reqStatusDesc, a.CONFLICT_FOUND, a.ROUTED_TO_COMPL, a.CONFLICT_RESOLVED, a.DATE_RESOLVED, a.IS_EXCES, a.UPDATEDBY, a.UPDATEDON, a.COMMENTS  ");
		sql.append(" FROM SOD_DB_USER.ZUREQHEAD a, SOD_DB_USER.ZREQTYPE b , SOD_DB_USER.ZREQUESTSTATUS d ");
		sql.append(" WHERE a.TYPEID = b.TYPEID  AND a.REQ_STATUS = d.STATUS_ID ");
		sql.append(" AND ((a.REQ_STATUS = 1 AND a.CONFLICT_FOUND <> 'Y' AND a.IS_EXCES <> 'Y' ) OR (a.REQ_STATUS = 4 AND (a.CONFLICT_FOUND = 'Y' OR a.IS_EXCES = 'Y') ))");
		sql.append(" ORDER BY a.REQID DESC, a.REQUESTEDON DESC  ");

		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AbsUserReqMdl.class));
		log.info("Approved Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}

	@Override
	public int updateIamReqstedDataHubAnaplanRoles(List<IAMRequestedRoleModel> reqMdlLst) throws SQLException, DataAccessException {
	    log.info("Updating IAM requested data for multiple roles :"+reqMdlLst);
	    
	    String updateSql = "UPDATE SOD_DB_USER.ZUSER_REQUESTED_ROLES " +
	                      "SET COMMENTS = ?, SUBM_UID = ?, SUBM_STATUS = ?, SUBM_DATE = ? " +
	                      "WHERE REQID = ? AND ADGRPNAME = ? AND USERID = ?";
	    
	    int[] updateCounts = getJdbcTemplateSRADUtils().batchUpdate(updateSql, new BatchPreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps, int i) throws SQLException {
	            IAMRequestedRoleModel roleModel = reqMdlLst.get(i);
	            ps.setString(1, roleModel.getComments());
	            ps.setString(2, roleModel.getSubmUid());
	            ps.setString(3, roleModel.getSubmStatus());
	            ps.setDate(4, new java.sql.Date(roleModel.getSubmDate().getTime()));
	            ps.setInt(5, roleModel.getReqId());
	            ps.setString(6, roleModel.getAdgrpName());
	            ps.setString(7, roleModel.getUserId());
	        }

	        @Override
	        public int getBatchSize() {
	            return reqMdlLst.size();
	        }
	    });

	   // log.info("Updated " + updateCounts.length + " rows");
	    //Arrays.stream(updateCounts).sum();

	    log.info("Total Request Roles saved ::"+((updateCounts==null) ?"0":updateCounts.length+""));
		return (updateCounts==null) ?0:updateCounts.length;
	}

	
	@Override
	public int saveIamReqstedDataHubAnaplanRoles(List<IAMRequestedRoleModel> reqMdlLst ) throws SQLException, DataAccessException {
		log.info("Saving IAM Request");
		String reqSql = " INSERT INTO SOD_DB_USER.ZUSER_REQUESTED_ROLES "+
						" (REQID, SEQID, USERID, SYSID, SYSNAME, POSID, POSNAME, PVARID, PVARNAME, ADGRPID, ADGRPNAME, REQUESTEDBY, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS ) " +
						" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";

		int[] status = getJdbcTemplateSRADUtils().batchUpdate(reqSql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setInt(1, reqMdlLst.get(i).getReqId());
				ps.setInt(2, (i+1));
				ps.setString(3, reqMdlLst.get(i).getUserId());
				ps.setString(4, reqMdlLst.get(i).getSysId());
				ps.setString(5, reqMdlLst.get(i).getSysName());
				ps.setString(6, reqMdlLst.get(i).getPosId());
				ps.setString(7, reqMdlLst.get(i).getPosName());
				ps.setString(8, reqMdlLst.get(i).getPvId());
				ps.setString(9, reqMdlLst.get(i).getPvName());
				ps.setString(10, reqMdlLst.get(i).getAdgrpId());
				ps.setString(11, reqMdlLst.get(i).getAdgrpName());
				ps.setString(12, reqMdlLst.get(i).getReqBy());
				ps.setString(13, reqMdlLst.get(i).getComments());
				ps.setString(14, reqMdlLst.get(i).getSubmUid());
				ps.setDate(15, new java.sql.Date(reqMdlLst.get(i).getSubmDate().getTime()));
				ps.setString(16, reqMdlLst.get(i).getSubmStatus());
			}

			@Override
			public int getBatchSize() {
				return reqMdlLst.size();
			}
		});
		log.info("Total Request Roles saved ::"+((status==null) ?"0":status.length+""));
		return (status==null) ?0:status.length;
	}

	@Override
	public int updateIamGrcRequestStatus(int requestId, int status) throws SQLException, DataAccessException {
			log.info("Update Request Status  REQID: "+requestId +" Status: "+status);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.ZUREQHEAD SET REQ_STATUS = ?  WHERE REQID = ? " );
			return  getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {status, requestId });
	}


	@Override
	public String getZadGrpById(String adGrpId) throws SQLException, DataAccessException {
		//String sql= " SELECT DISTINCT ADNAME FROM SOD_DB_USER.ZADGROUP WHERE ADID = ? ";
		String sql= " SELECT DISTINCT AD_NAME from SOD_DB_USER.ZMASTER_DATA WHERE AD_ID = ? ";
		String adgroup = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {adGrpId}, String.class);
		return adgroup;
	}


	@Override
	public String getAllADGrpBySystem(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr) throws SQLException, DataAccessException {
		List<String> dataLst = new ArrayList<>();
		Object[] inParam = new Object[(1+posnIdArr.length+accIdArr.length+pvarIdArr.length)];
		int prmPos=0;

		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT Distinct AD_ID as ADID FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		inParam[prmPos] = sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posnIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "ACS_ID", accIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "PV_ID", pvarIdArr, inParam, sql);
		sql.append(" ORDER BY 1 ");
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql.toString(), inParam, String.class);
		log.info("ADID's size : "+((dataLst !=null)? dataLst.size(): 0));
		return String.join(",", dataLst);
	}

	/*@Override
	public String getAllADGrpBySystem(String sysid, String[] posnIdArr, String[] accIdArr, String[] pvarIdArr) throws SQLException, DataAccessException {
		List<String> dataLst = new ArrayList<String>();
		Object[] inParam = new Object[(1+posnIdArr.length+accIdArr.length+pvarIdArr.length)];
		int prmPos=0;

		StringBuilder sql= new StringBuilder();
		sql.append(" SELECT Distinct a.sysid, a.posid, a.accid, a.posvarid, b.ADID, b.ADNAME  FROM SOD_DB_USER.ZMAP_ACC_PVAR a, SOD_DB_USER.ZADGROUP b ");
		sql.append(" WHERE a.isactive = 'Y' AND a.sysid = 2 AND a.posid in (7,8,9) AND a.accid IN (2) ");
		sql.append(" AND a.posvarid IN(6,7,8,9,10,11,12,13,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84)");
		sql.append(" AND a.posvarid = b.posvarid ");

		sql.append(" SELECT Distinct b.ADID FROM SOD_DB_USER.ZMAP_ACC_PVAR a, SOD_DB_USER.ZADGROUP b ");
		sql.append(" WHERE a.isactive = 'Y' AND a.SYSID = ? ");
		inParam[prmPos] = sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.POSID", posnIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.ACCID", accIdArr, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.POSVARID", pvarIdArr, inParam, sql);
		sql.append(" AND a.posvarid = b.posvarid ORDER BY 1 ");
		dataLst = getJdbcTemplateSRADUtils().queryForList(sql.toString(), inParam, String.class);
		log.info("ADID's size : "+((dataLst !=null)? dataLst.size(): 0));
		return String.join(",", dataLst);
	}*/



	@Override
	public List<AbsUserReqMdl> getAllEDALIamSubmittedRequests()throws SQLException, DataAccessException {
		List<AbsUserReqMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.REQID, a.TYPEID, b.TYPENAME as typename, a.REQUESTEDON, a.REQUESTEDBY, a.REQUESTEDBYNAME, a.USERID, a.USERNAME, a.MANAGERID, a.MANAGERNAME, nvl(a.REQSYS,0) as REQSYS, a.REQSYSNAMES, a.BFID, a.SECIDS, a.REGIDS, a.REQ_STATUS, ");
		sql.append(" d.STATUS_NAME as reqStatusDesc, a.CONFLICT_FOUND, a.ROUTED_TO_COMPL, a.CONFLICT_RESOLVED, a.DATE_RESOLVED, a.IS_EXCES, a.UPDATEDBY, a.UPDATEDON, a.COMMENTS  ");
		sql.append(" FROM SOD_DB_USER.ZUREQHEAD a, SOD_DB_USER.ZREQTYPE b , SOD_DB_USER.ZREQUESTSTATUS d ");
		sql.append(" WHERE a.TYPEID = b.TYPEID  AND a.REQ_STATUS = d.STATUS_ID ");
		sql.append(" AND a.REQ_STATUS = "+Constants.PROVISIONING_WIP+" ORDER BY a.REQID DESC, a.REQUESTEDON DESC  ");
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AbsUserReqMdl.class));
		log.info("EDAL-IAM Submitted Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


	@Override
	public List<IAMRequestedRoleModel> getEdalIamReqSubmittedRoles(String reqId) throws SQLException, DataAccessException {
		List<IAMRequestedRoleModel> dataLst = new ArrayList<>();
		String sql= " Select REQID as reqId, SEQID as seqId, USERID as userId, SYSID as sysId, SYSNAME as sysName, POSID as posId, POSNAME as posName, "
					+ " PVARID as pvId, PVARNAME as pvName, ADGRPID as adgrpId, ADGRPNAME as adgrpName, REQUESTEDBY as reqBy, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS " +
					" FROM  SOD_DB_USER.ZUSER_REQUESTED_ROLES WHERE REQID = ? AND SUBM_STATUS = 'N' AND (API_STATUS IS NULL or API_STATUS = 'P' ) " +
					" ORDER BY REQID, SYSID, SEQID " ;
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(IAMRequestedRoleModel.class));
		log.info("Submitted Request size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}
	@Override
	public List<IAMRequestedRoleModel> getEdalIamReqSubmittedErrorRoles(int reqId, String sysid ) throws SQLException, DataAccessException {
		List<IAMRequestedRoleModel> dataLst = new ArrayList<>();
		String sql= " Select REQID as reqId, SEQID as seqId, USERID as userId, SYSID as sysId, SYSNAME as sysName, POSID as posId, POSNAME as posName, "
					+ " PVARID as pvId, PVARNAME as pvName, ADGRPID as adgrpId, ADGRPNAME as adgrpName, REQUESTEDBY as reqBy, COMMENTS, SUBM_UID, SUBM_DATE, SUBM_STATUS " +
					" FROM  SOD_DB_USER.ZUSER_REQUESTED_ROLES WHERE REQID = ? AND SUBM_STATUS = 'E' " ;
		dataLst = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(IAMRequestedRoleModel.class));
		log.info("Submitted Request size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}
	
	@Override
	public int updateEdalIamReqstedRolesStatus(String apiStatus, String apiMsg, String apiErrMsg, Date updDt, IAMRequestedRoleModel detailNum ) throws SQLException, DataAccessException {
		log.info("Update IAM Request Status");
		String reqSql = " UPDATE SOD_DB_USER.ZUSER_REQUESTED_ROLES " +
						" SET API_STATUS = ?, API_MSG = ?, API_ERROR_MSG = ?, UPD_DATE= ? "+
						" WHERE  REQID = ? AND SEQID = ? AND SYSID = ? AND ADGRPID = ? " ;

		int recUpd = getJdbcTemplateSRADUtils().update(reqSql, new Object[] {apiStatus, apiMsg, apiErrMsg, updDt, detailNum.getReqId(), detailNum.getSeqId(), detailNum.getSysId(), detailNum.getAdgrpId()});
		log.info("Total Roles Status updated for ::"+recUpd);
		return recUpd;
	}


	@Override
	public int getRequestChildCount(String reqId) throws SQLException, DataAccessException{
		int count = 0;
		String sql = " SELECT COUNT(REQID) FROM SOD_DB_USER.ZUSER_REQUESTED_ROLES WHERE REQID = ? ";
		count = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {reqId}, Integer.class);
		return count;
	}


	@Override
	public List<String> getCompletedReqStatus(String reqId) throws SQLException, DataAccessException{
		List<String> dataList = new ArrayList<>();
		String sql = " SELECT API_STATUS FROM SOD_DB_USER.ZUSER_REQUESTED_ROLES " +
					 " WHERE REQID = ? AND API_STATUS IS  NOT NULL AND API_STATUS <> 'P' ";
		dataList = getJdbcTemplateSRADUtils().queryForList(sql, new Object[] {reqId}, String.class);
		return dataList;
	}

	@Override
	public int updateIamRequestStatus(String requestId, int status) throws SQLException, DataAccessException {
			log.info("Update Request Status  REQID: "+requestId +" Status: "+status);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE SOD_DB_USER.ZUREQHEAD SET REQ_STATUS = ?  WHERE REQID = ? " );
			return  getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {status, requestId });
	}


	@Override
	public List<String> getExcessiveAccessDeniedVariants(String reqId, String sysId) throws SQLException, DataAccessException{
		List<String> dataList = new ArrayList<>();
		/*" SELECT DISTINCT POSVARID FROM SOD_DB_USER.ZREQ_EXCSVACCESS_APPROVAL" +
		 " WHERE ACCEPT_DENY = 'D' AND REQID = ? AND SYSID = ? ORDER BY POSVARID ";*/
		String sql = " SELECT DISTINCT POSVARID from SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL "+
				     " WHERE ACCEPT_DENY in ('D', 'F') AND REQID = ? AND SYSID = ? ORDER BY POSVARID ";
 		dataList = getJdbcTemplateSRADUtils().queryForList(sql, new Object[] {reqId, sysId}, String.class);
		return dataList;
	}

	@Override
	public List<ConflictRequestedModel> getConflictsDeniedPositions(String reqId, String sysId) throws SQLException, DataAccessException{
		List<ConflictRequestedModel> dataList = new ArrayList<>();
		String sql = " SELECT APP1, POSV1, APP2, POSV2 from SOD_DB_USER.ZUSER_CONFLICT "+
			     " WHERE ACCEPT_DENY = 'F' AND REQID = ?";
		dataList = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(ConflictRequestedModel.class));
		return dataList;
	}
	@Override
	public List<ConflictRequestedModel> getConflictCount(String reqId, String sysId) throws SQLException, DataAccessException{
		List<ConflictRequestedModel> dataList = new ArrayList<>();
		String sql = " SELECT APP1, POSV1, APP2, POSV2 from SOD_DB_USER.ZUSER_CONFLICT "+
			     " WHERE REQID = ?";
		dataList = getJdbcTemplateSRADUtils().query(sql, new Object[] {reqId}, new BeanPropertyRowMapper<>(ConflictRequestedModel.class));
		return dataList;
	}


	@Override
	public List<AbsSecExcesvRestrictedAccsMdl> getRequestLvlRestExcSecData(String reqId) throws SQLException, DataAccessException {
		List<AbsSecExcesvRestrictedAccsMdl> excResLst = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT USERID, REQID, SECID, SECNAME, SYSID, SYSNAME, IS_EXCSV, IS_RESTRICTED, EXCSV_PRCNTG, LIMIT, CREATEDON ");
		sql.append(" FROM SOD_DB_USER.ZREQ_RESTRICTIVE_EXCSV_ACCESS ");
		sql.append(" WHERE REQID = ? ");
		sql.append(" ORDER BY SYSID,SECID ");
		excResLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(AbsSecExcesvRestrictedAccsMdl.class));
		log.info("Request Excessive Data size : "+((excResLst !=null)? excResLst.size(): 0));
		return excResLst;
	}


	@Override
	public List<RoleADGrpMdl> getRequestLvlRestExcRoleData(String reqId) throws SQLException, DataAccessException {
		List<RoleADGrpMdl> excResRls = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT USERID, REQID, SECID, SECNAME, SYSID, SYSNAME, POSID, POSNAME, ACCID, ACCNAME, POSVARID as pvId, POSVARNAME as pvName, IS_RESTRICTED, CREATEDON, ACCEPT_DENY, RESOLVED, RESOLUTION_CMNTS, RESOLVEDBY, RESOLVEDON ");
		sql.append(" FROM SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL ");
		sql.append(" WHERE REQID = ? ");
		sql.append(" ORDER BY SYSID, POSID, ACCID, POSVARID ");
		excResRls = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId}, new BeanPropertyRowMapper<>(RoleADGrpMdl.class));
		log.info("Get All Roles for Restrictive/ExcessiveAccess Data size : "+((excResRls !=null)? excResRls.size(): 0));
		return excResRls;
	}

	@Override
	public int updateReqCancelRejectStatusChildTable(AbsCancelRejectRequestModel absCancelRejectRequestModel, UserSearchModel approveUser) throws SQLException, DataAccessException {
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.ZREQ_RESTR_EXCSV_APPROVAL ");
		sql.append(" SET ACCEPT_DENY = ?, RESOLVED = ?, RESOLUTION_CMNTS = ?, RESOLVEDBY = ?, RESOLVEDON = sysdate ");
		sql.append(" WHERE REQID = ? ");
		int res= getJdbcTemplateSRADUtils().update(sql.toString(), new Object[] {"F", "Y",absCancelRejectRequestModel.getReason(),
				absCancelRejectRequestModel.getUserid() , absCancelRejectRequestModel.getReqid()});
		log.info("Update Count on ZREQ_RESTR_EXCSV_APPROVAL Table : "+res);

		StringBuilder sqlConflict = new StringBuilder();
		sqlConflict.append(" UPDATE SOD_DB_USER.ZUSER_CONFLICT ");
		sqlConflict.append(" SET ACCEPT_DENY = ?, STATUS = ?, COMMENTS = ?, RESOLVEDBY = ?, RESOLVEDON = sysdate ");
		sqlConflict.append(" WHERE REQID = ? ");
		int resConflict= getJdbcTemplateSRADUtils().update(sqlConflict.toString(), new Object[] {"F", "Y",absCancelRejectRequestModel.getReason(),
				absCancelRejectRequestModel.getUserid() , absCancelRejectRequestModel.getReqid()});
		log.info("Update Count on ZREQ_RESTR_EXCSV_APPROVAL Table : "+resConflict);
		return 1;
	}
	
	@Override
	public List<AbsUserReqMdl> getRequestedDetailsFromHeader(String ReqId) throws SQLException, DataAccessException {
		List<AbsUserReqMdl> dataLst = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT REQID, TYPEID, REQUESTEDON, BFID from SOD_DB_USER.ZUREQHEAD ");
		sql.append(" WHERE REQID = ? ");	
		dataLst = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {ReqId}, new BeanPropertyRowMapper<>(AbsUserReqMdl.class));
		log.info("getRequestedDetailsFromHeader Request Data size : "+((dataLst !=null)? dataLst.size(): 0));
		return dataLst;
	}


}
