package com.jnj.rqc.mastermetadata.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.autotask.RQCUtilSchedular;

@RestController
@RequestMapping("/v2/api")
public class MyInvokeController {
	
	@Autowired
	private RQCUtilSchedular rqcUtilSchedular;
	
	@GetMapping("/invokeCFINScheduler")
    public void invokeCFINScheduler() {
		rqcUtilSchedular.edalFetchExistingRolesCFINScheduler();
    }
	@GetMapping("/invokeDDGRScheduler")
    public void invokeDDGRScheduler() {
		rqcUtilSchedular.edalFetchExistingRolesDDGRScheduler();
    }
	@GetMapping("/invokeAnaplanScheduler")
    public void invokeAnaplanScheduler() {
		rqcUtilSchedular.edalFetchExistingRolesAnaplanScheduler();
    }
	@GetMapping("/invokeRequestScheduler")
	public void invokeRequestScheduler() {
		rqcUtilSchedular.edalIAMRequestScheduler();
	}
	@GetMapping("/invokeStatusScheduler")
	public void invokeStatusScheduler() {
		rqcUtilSchedular.edalIAMRequestStatusScheduler();
	}
}
