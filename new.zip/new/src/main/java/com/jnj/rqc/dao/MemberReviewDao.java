package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.models.Assigner;
import com.jnj.rqc.models.RQCTktData;
import com.jnj.rqc.models.UsrJJEdsMdl;

public interface MemberReviewDao {
	public List<RQCTktData> queryRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException;
	public Map<String, String> getRQCTktDetails(int MON, int YEAR)throws SQLException, DataAccessException;
	public List<Assigner> getAssignerDetails(int MON, int YEAR)throws SQLException, DataAccessException;

	//SRC_SYS MEM ROLE ASSIGNMENTS
	public List<SrcSysMemRoleModel> readSrcSysMemData(String srcSys)throws SQLException, DataAccessException;
	public Map<String, String> readMemRQCTktData() throws SQLException, DataAccessException;
	public List<Assigner> queryMemAssignerData()throws SQLException, DataAccessException ;
	public List<UsrJJEdsMdl> readJJEDSMemData(String winId)throws SQLException, DataAccessException;

}
