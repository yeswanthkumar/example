package com.jnj.rqc.reportwriter;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.util.Utility;

@Service
public class PDFReportWriter {
	static final Logger log = LoggerFactory.getLogger(PDFReportWriter.class);

	//Member Review Report
	public String buildReport(List<MemRevieModel> data, String fileName, int mon, int year)
	{
	    Document document = new Document();
	    String filePath= "";
	    try
	    {
	    	File outfile = new File(Constants.REPO_OUT_LOC+fileName);
	    	filePath = outfile.getAbsolutePath();
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outfile));
	        document.open();
	        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 6, BaseColor.BLACK);
	        String dtperiod = (mon<10 ? "0"+mon : mon)+"-"+year;
	        //horizontalAlignCell.setHorizontalAlignment(Element.ALIGN_CENTER);
	        Paragraph title = new Paragraph("Monthly Membership Review Report for "+dtperiod, titleFont);
	        title.setAlignment(Element.ALIGN_CENTER);
	        document.add(title);


	        String [] header = "ACCOUNT NAME, ACC FIRST COL, ACC LAST COL, WWID, FULL NAME, WIN NT ID, EMAIL ADDRESS, TITLE, DEPARTMENT, GRP SHORT NAME, GROUP NAME, GROUP, ROLE, DATE ADDED, TICKET NUMBER, ASIGNER NAME".split(",");
	        PdfPTable table = new PdfPTable(header.length);

	        table.setWidthPercentage(100);
	        table.setSpacingBefore(10f);
	        table.setSpacingAfter(10f);
	        //table.addCell(new PageNumberCellGenerator(pageNumber, BackgroundColorGeneratorDEFAULT_BACKGROUND_COLOR).generateTile());

	        Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 4, BaseColor.BLACK);
	        Font dataFont = FontFactory.getFont(FontFactory.HELVETICA, 4);

	        //Set Column widths
	        float[] columnWidths = {2f, 1f, 1f, 1f, 2f, 1f, 2f, 1.5f, 1.8f, 2f, 3f, 1f, 2f, 1f, 1f, 2f};
	        table.setWidths(columnWidths);
	        PdfPCell headerCell = null;
	        for(String headstr:header) {
	        	headerCell = new PdfPCell(new Phrase(headstr, headFont));
	        	headerCell.setBorderColor(BaseColor.DARK_GRAY);
	        	headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        	headerCell.setPaddingLeft(1);
	        	headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
	        	headerCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        	headerCell.setUseBorderPadding(true);
		        table.addCell(headerCell);
	        }
	        table.setHeaderRows(1);

	        for(MemRevieModel nmodel:data) {

	        	PdfPCell acnm = new PdfPCell(new Phrase(nmodel.getAccountName(), dataFont));
	        	table.addCell(acnm);

	        	String acfcc = (nmodel.getAccountFstCol() != null)? Utility.dtFmt.format(nmodel.getAccountFstCol()):"";
	        	PdfPCell acfc = new PdfPCell(new Phrase(acfcc, dataFont));
	        	table.addCell(acfc);

	        	String aclcc = (nmodel.getAccountLstCol() != null)? Utility.dtFmt.format(nmodel.getAccountLstCol()):"";
	        	PdfPCell aclc = new PdfPCell(new Phrase(aclcc, dataFont));
	        	table.addCell(aclc);

	        	PdfPCell wwid = new PdfPCell(new Phrase(nmodel.getWwid(), dataFont));
	        	table.addCell(wwid);

	        	PdfPCell flNm = new PdfPCell(new Phrase(nmodel.getFullName(), dataFont));
	        	table.addCell(flNm);

	        	PdfPCell ntid = new PdfPCell(new Phrase(nmodel.getNetId(), dataFont));
	        	table.addCell(ntid);

	        	PdfPCell email = new PdfPCell(new Phrase(nmodel.getEmail(), dataFont));
	        	table.addCell(email);

	        	PdfPCell ttl = new PdfPCell(new Phrase(nmodel.getTitle(), dataFont));
	        	table.addCell(ttl);

	        	PdfPCell dept = new PdfPCell(new Phrase(nmodel.getDept(), dataFont));
	        	table.addCell(dept);

	        	PdfPCell gsn = new PdfPCell(new Phrase(nmodel.getGrpShrtNm(), dataFont));
	        	table.addCell(gsn);

	        	PdfPCell grpnm = new PdfPCell(new Phrase(nmodel.getGrpNm(), dataFont));
	        	table.addCell(grpnm);

	        	PdfPCell grp = new PdfPCell(new Phrase(nmodel.getGrp(), dataFont));
	        	table.addCell(grp);

	        	PdfPCell role = new PdfPCell(new Phrase(nmodel.getRole(), dataFont));
	        	table.addCell(role);

	        	String addDt = (nmodel.getDtAdded() != null)? Utility.dtFmt.format(nmodel.getDtAdded()):"";
	        	PdfPCell dtAd = new PdfPCell(new Phrase(addDt, dataFont));
	        	table.addCell(dtAd);

	        	PdfPCell tktNum = new PdfPCell(new Phrase(nmodel.getRqcTkt(), dataFont));
	        	table.addCell(tktNum);

	        	PdfPCell asg = new PdfPCell(new Phrase(nmodel.getAsignerName(), dataFont));
	        	table.addCell(asg);

	        	//table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	/*String [] bdyData = nmodel.getData().split("~");
	        	for(String bodyStr:bdyData) {
	        		table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	}*/
	        }
	        document.add(table);
	        document.close();
	        writer.close();
	        System.out.println("File "+outfile.getAbsolutePath()+" creation completed.");
	    } catch (Exception e)
	    {
	        System.out.println("Error creating PDF Document :"+e.getMessage());
	    	e.printStackTrace();
	    }

	    return filePath;
	}









}
