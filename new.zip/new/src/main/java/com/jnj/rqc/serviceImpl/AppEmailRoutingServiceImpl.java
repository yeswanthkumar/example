package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.AppEmailRoutingDao;
import com.jnj.rqc.models.AppRoutingModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.AppEmailRoutingService;

@Service
public class AppEmailRoutingServiceImpl implements AppEmailRoutingService {
	static final Logger log = LoggerFactory.getLogger(AppEmailRoutingServiceImpl.class);

	@Autowired
	AppEmailRoutingDao appEmailRoutingDao;

	@Autowired
	CSVReportWriter cSVReportWriter;

	@Override
	public Map<String, List<AppRoutingModel>> getAllAppRoutingDetails(HttpServletRequest request) {
		Map<String, List<AppRoutingModel>> dataMap = new HashMap<>();
		try{
			List<AppRoutingModel>summaryList =  appEmailRoutingDao.getAppRoutingData();
			request.getSession().setAttribute("ALLCATEGORY", summaryList);
			String ctgry ="";
			if(summaryList != null && !summaryList.isEmpty()) {
				for(AppRoutingModel appMdl:summaryList) {
					ctgry = appMdl.getCategory();
					List<AppRoutingModel> catList = null;
					if(dataMap.containsKey(ctgry)) {
						catList = dataMap.get(ctgry);
						catList.add(appMdl);
					}else {
						catList = new ArrayList<>();
						catList.add(appMdl);
					}
					dataMap.put(ctgry, catList);
				}
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return dataMap;
	}

	@Override
	public List<AppRoutingModel> filterAppRoutingCategory(String category, Map<String, List<AppRoutingModel>> dataMap) {
		List<AppRoutingModel> catList = new ArrayList<>();
		if(null!=category && category.length()>0) {
			catList = dataMap.get(category);
		}
		return catList;
	}


	/*@Override
	public Map<String, List<RuleSetModel>> getRuleSetData(List<RuleSetSmryModel> summaryList) {
		Map<String, List<RuleSetModel>> reuleSetDataMap = new HashMap<String, List<RuleSetModel>>();
		List<RuleSetModel> dataList = new ArrayList<RuleSetModel>();
		String app1 = "";
		String app2 = "";
		try{
			for(RuleSetSmryModel rlsMdl : summaryList) {
				app1 = rlsMdl.getApp1();
				app2 = rlsMdl.getApp2();
				dataList = ruleSetReviewDao.getRuleSetData(app1, app2);
				if(!dataList.isEmpty()) {
					reuleSetDataMap.put(app1.replace("/", "_")+"-"+app2.replace("/", "_"), dataList);
				}
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return reuleSetDataMap;
	}


	@Override
	public Map<String, String> generateRuleSetFiles(Map<String, List<RuleSetModel>> dataMap, String strDate, HttpServletRequest request) {
		Map<String, String> fileMap = new HashMap<String, String>();
		String outFile = "";
		String dirPath = Constants.RULESET_OUT_LOC+"RuleSet_"+strDate;
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("RULESETDIR", dirPath);
		for (Map.Entry<String, List<RuleSetModel>> fileData : dataMap.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_"+strDate+".csv";
			outFile = createCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;
	}

	public String createCSV(List<RuleSetModel> data, String fileName) {
		String filePath = cSVReportWriter.writeRuleSetCSVReport(data, fileName);
		return filePath;
	}


	@Override
	public void updateFileLocation(List<RuleSetSmryModel> summaryList, Map<String, String> ruleSetFileMap) {

		if(summaryList != null && !summaryList.isEmpty()) {
			String app1 = "";
			String app2 = "";
			String key  = "";
			for(RuleSetSmryModel smry : summaryList)  {
				app1 = smry.getApp1();
				app2 = smry.getApp2();
				key = app1.replace("/", "_")+"-"+app2.replace("/", "_");
				if(ruleSetFileMap.containsKey(key)) {
					smry.setFileLoc(ruleSetFileMap.get(key));
				}
			}
		}

	}

*/
}
