package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.jnj.rqc.models.UserSearchModel;

import lombok.Data;

@Data
public class AbsExcesvAccsMdl implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -6991068953092591679L;

	UserSearchModel user;
	String userid;
	int    reqid;
	String sysid;
	String sysName;
	String isExcsv ;
	double excsvPrcntg;
	double limit;
	String selVarids;
	Date   createdon;
	String resolved;
	String acceptDeny;
	String acceptedVarids;
	String denedVarids;
	int    cntrlSelected;
	String resolutionCmnts;
	String resolvedby;
	Date   resolvedon;

	List<RawSysDpendncMdl> variantDetails;
	List<String> selVariants;
	String       exVarids;
	List<String> exVariants;
	List<String> allAvailableVars;

}