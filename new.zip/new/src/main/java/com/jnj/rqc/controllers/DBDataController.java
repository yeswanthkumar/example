package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.dbextr.models.DBSchema;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.service.DBExtService;
import com.jnj.rqc.util.Utility;

@Controller
public class DBDataController {
	static final Logger log = LoggerFactory.getLogger(DBDataController.class);
	@Autowired
	DBExtService dBExtService;

	String schema="SOD_SCHEMA_NAMES";

    @GetMapping("/loadDBSchemas")
    public String getDBSchemas(Model model, @RequestParam("schemaName") String schemaName) {
    	log.info("Routing to Table view page Schema : "+schemaName);
    	schema = schemaName;
    	List<String> schemaNames = Utility.loadProperty(schema);
    	model.addAttribute("schemaNames", schemaNames);
    	return "dbextract/dbextractview";
    }


    @PostMapping("/loadDBTables")
    public ResponseEntity<TableRespDto> getTableData(Model model, @RequestBody DBSchema dBSchema, HttpServletRequest req) {
    	log.info("Received Schema name: "+dBSchema.getSchema());
    	TableRespDto tableRespDto = dBExtService.getSchemaTables(dBSchema.getSchema());

    	if (tableRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/genExtractFiles")
    public String genExtractFiles(Model model, @RequestParam("schemaNames") String schemaNames,  @RequestParam("tablenames") String tablenames,HttpServletRequest req) {
    	log.info("Received Schema: "+schemaNames+"  Table:"+tablenames);
    	List<String> schemas = Utility.loadProperty(schema);
    	List<String> tables = Utility.loadProperty(schemaNames);
    	model.addAttribute("schemaNames", schemas);
    	model.addAttribute("selSchema", schemaNames);
    	model.addAttribute("tablenames", tables);
    	model.addAttribute("selTbls", tablenames);

    	if(schemaNames.equals("0")|| tablenames.equals("0")) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter "+((schemaNames.equals("0"))?" Schema Name ":" Table Name "));
            return "dbextract/dbextractview";
    	}
    	try {
    		String filePath = dBExtService.createExcelData(tablenames);
    		Map<String, String> fileMap = (Map<String, String>)req.getSession().getAttribute("FILE_NAMES");
    		if(fileMap != null && !fileMap.isEmpty()) {
    			fileMap.put(tablenames, filePath);
    		}else {
    			fileMap = new HashMap<>();
    			fileMap.put(tablenames, filePath);
    		}
    		req.getSession().setAttribute("FILE_NAMES", fileMap);
    		model.addAttribute("FILE_NAMES", fileMap);
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(), e);
			model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Exception getting Data "+e.getMessage());
		}

    	return "dbextract/dbextractview";
    }



    @ResponseBody
    @GetMapping("/downloadData")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExcel(@RequestParam String table, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading RuleSet Individual File: "+table);
		Map<String, String> fileMap =(Map<String, String>)request.getSession().getAttribute("FILE_NAMES");
		String filePath = fileMap.get(table);

    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }




}
