package com.jnj.rqc.common.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SrcSysMemRoleModel {
	private String srcSys;
	private String wwid;
	private String firstNm;
	private String lastNm;
	private String userid;
	private String supvrWwid;
	private String applRole;
	private int sodCode;
	private String rqcTkt;
	private String asignerName;
	@Override
	public String toString() {
		return "SrcSysMemRoleModel [srcSys=" + srcSys + ", wwid=" + wwid + ", firstNm=" + firstNm + ", lastNm=" + lastNm
				+ ", userid=" + userid + ", supvrWwid=" + supvrWwid + ", applRole=" + applRole + ", sodCode=" + sodCode
				+ ", rqcTkt=" + rqcTkt + ", asignerName=" + asignerName + "]";
	}


	public String getData() {
		return srcSys+"~"+wwid+"~"+firstNm+"~"+lastNm+"~"+userid+"~"+supvrWwid+"~"+applRole+"~"+sodCode+"~"+rqcTkt+"~"+asignerName;
	}

}
