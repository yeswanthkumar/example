package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.sorting.UserComparatorLF;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.models.User;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.responseDto.UserNameRespDto;
import com.jnj.rqc.service.UserMenuService;
import com.jnj.rqc.util.Utility;

@Service
public class UserMenuServiceImpl implements UserMenuService {
	static final Logger log = LoggerFactory.getLogger(UserMenuServiceImpl.class);

	@Autowired
	Environment environment;
	@Autowired
	UserMenuDao userMenuDao;

	private static DirContext adContext;

	@Override
	public List<String> getUserHeaderMenus(String userId, String adGrp, HttpServletRequest request) {
		List<String> userMenus = new LinkedList<>();
		try {
			Map<Integer, String> menuMap = userMenuDao.getUserHeaderMenus(userId, adGrp, request);
			if(menuMap != null && !menuMap.isEmpty()) {
				for(int i=0; i<menuMap.size(); i++) {
					userMenus.add(menuMap.get(i+1));
				}
			}
		} catch (Exception e) {
			log.error("Error getting User Menus :"+e.getMessage(), e);
		}
		return userMenus;
	}


	@Override
	public List<String> getUserSideNavMenus(String userId, String adGrp, String menuId, HttpServletRequest request) {
		List<String> userMenus = new LinkedList<>();
		UserSearchModel usr=(UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		try {
			Map<Integer, String> menuMap = userMenuDao.getMenuSideNav(menuId, usr, request);
			if(menuMap != null && !menuMap.isEmpty()) {
				for(int i=0; i<menuMap.size(); i++) {
					userMenus.add(menuMap.get(i+1));
				}
			}
		} catch (Exception e) {
			log.error("Error getting User Menus :"+e.getMessage(), e);
		}
		return userMenus;
	}



	public User searchUserById(String userId) {
		User usr = new User();
		try {//userId = "AGoldbe1";
			String sAttrList[]={"uid","manager","cn","jnjDisplayName","name","givenName","jnjNickname","sn","initials","title","jnjBusinessUnit","jnjDepartmentDescription","Department","jnjDivision","jnjStartDate","eCertStatus","employeeType","jnjMSUPN","jnjmsusername","mail","jnj-managerAtTermination","telephoneNumber","roomNumber","businessCategory","directReports","objectClass"};
			SearchControls ctrl = new SearchControls();
			ctrl.setReturningAttributes(sAttrList);
			ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
			String searchBase = "DC=jjedsed,DC=jnj,DC=com" ;
			String searchFilter = "(&(jnjmsusername="+userId+")(!(employeeType=TERMINATED))   (!(uid=640100059)) )";
			adContext = initADContext();
			NamingEnumeration<SearchResult> enumeration = adContext.search(searchBase, searchFilter, ctrl);

			while (enumeration.hasMoreElements()) {
				SearchResult result = enumeration.next();
				Attributes attribs = result.getAttributes();
				System.out.println("Attributes:"+attribs);
				//NamingEnumeration<String> attribsIDs = attribs.getIDs();

				String fullNm = (attribs.get("cn") != null ?  (attribs.get("cn").toString().split(":")[1]):"");
				String wwid = (attribs.get("uid") != null ?  (attribs.get("uid").toString().split(":")[1]):"");
				String mail = (attribs.get("mail") != null ?  (attribs.get("mail").toString().split(":")[1]):"");
				String fNm =  (attribs.get("givenName") != null ?  (attribs.get("givenName").toString().split(":")[1]):"");
				String lNm= (attribs.get("sn") != null ?  (attribs.get("sn").toString().split(":")[1]):"");
				String ntId = (attribs.get("jnjmsusername") != null ?  (attribs.get("jnjmsusername").toString().split(":")[1]):"");
				String deptDesc = (attribs.get("jnjDepartmentDescription") != null ?  (attribs.get("jnjDepartmentDescription").toString().split(":")[1]):"");
				String dept = (attribs.get("department") != null ?  (attribs.get("department").toString().split(":")[1]):"");
				String tel = (attribs.get("TELEPHONENUMBER") != null ?  (attribs.get("TELEPHONENUMBER").toString().split(":")[1]):"");
				String bussUnit = (attribs.get("jnjBusinessUnit") != null ?  (attribs.get("jnjBusinessUnit").toString().split(":")[1]):"");
				String mgrDet = (attribs.get("manager") != null ?  (attribs.get("manager").toString().split(":")[1]):"");
				String cube = (attribs.get("roomnumber") != null ?  (attribs.get("roomnumber").toString().split(":")[1]):"");

				//String bussUnit = (attribs.get("jnjBusinessUnit") != null ?  (attribs.get("jnjBusinessUnit").toString().split(":")[1]):"");

				usr.setFullName(fullNm.trim());
				usr.setWwid(wwid.trim());
				usr.setFirstName(fNm.trim());
				usr.setLasttName(lNm.trim());
				usr.setEmail(mail.trim());
				usr.setNtId(ntId.trim());
				usr.setDepartment(dept.trim());
				usr.setDepartmentDesc(deptDesc);
				usr.setTel(tel.replace("$", "").trim());
				usr.setBusinessUnit(bussUnit);
				usr.setCubeno(cube);
				getManagerdata(usr, mgrDet);
			}
		} catch (Exception e) {
			System.out.println("Error:"+e.getMessage());
			e.printStackTrace();
		}
		return usr;
	}


	public UserNameRespDto searchUserByName(String empName) {
		UserNameRespDto userRespDto = new UserNameRespDto();
		try {

			String sAttrList[]={"cn","uid","mail","givenName","sn","jnjmsusername","jnjDepartmentDescription","Department","TELEPHONENUMBER","roomNumber","jnjBusinessUnit", "manager"};
		    SearchControls ctrl = new SearchControls();
            ctrl.setReturningAttributes(sAttrList);
            ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String searchBase = "DC=jjedsed,DC=jnj,DC=com" ;
            String searchFilter = "(&(|(uid=" + empName + ")(givenName=" + empName + ")(sn=" + empName + "))(!(employeeType=TERMINATED)))";
            adContext = initADContext();
            NamingEnumeration<SearchResult> enumeration = adContext.search(searchBase, searchFilter, ctrl);
            List<User> userList = new ArrayList<>();
            while (enumeration.hasMoreElements()) {
                SearchResult result = enumeration.next();
                Attributes attribs = result.getAttributes();
                System.out.println("Attributes:"+attribs);
                NamingEnumeration<String> attribsIDs = attribs.getIDs();

                String fullNm = (attribs.get("cn") != null ?  (attribs.get("cn").toString().split(":")[1]):"");
                String wwid = (attribs.get("uid") != null ?  (attribs.get("uid").toString().split(":")[1]):"");
                String mail = (attribs.get("mail") != null ?  (attribs.get("mail").toString().split(":")[1]):"");
                String fNm =  (attribs.get("givenName") != null ?  (attribs.get("givenName").toString().split(":")[1]):"");
                String lNm= (attribs.get("sn") != null ?  (attribs.get("sn").toString().split(":")[1]):"");
                String ntId = (attribs.get("jnjmsusername") != null ?  (attribs.get("jnjmsusername").toString().split(":")[1]):"");
                String deptDesc = (attribs.get("jnjDepartmentDescription") != null ?  (attribs.get("jnjDepartmentDescription").toString().split(":")[1]):"");
                String dept = (attribs.get("Department") != null ?  (attribs.get("Department").toString().split(":")[1]):"");
                String tel = (attribs.get("TELEPHONENUMBER") != null ?  (attribs.get("TELEPHONENUMBER").toString().split(":")[1]):"");
                String bussUnit = (attribs.get("jnjBusinessUnit") != null ?  (attribs.get("jnjBusinessUnit").toString().split(":")[1]):"");
                String mgrDet = (attribs.get("manager") != null ?  (attribs.get("manager").toString().split(":")[1]):"");
                String cube = (attribs.get("roomnumber") != null ?  (attribs.get("roomnumber").toString().split(":")[1]):"");

                User usr = new User();
                usr.setFullName(fullNm.trim());
                usr.setWwid(wwid.trim());
                usr.setFirstName(fNm.trim());
                usr.setLasttName(lNm.trim());
                usr.setEmail(mail.trim());
                usr.setNtId(ntId.trim());
                usr.setDepartment(dept.trim());
                usr.setDepartmentDesc(deptDesc.trim());
                usr.setTel(tel.replace("$", "").trim());
                usr.setBusinessUnit(bussUnit);
                usr.setCubeno(cube);
                getManagerdata(usr, mgrDet);
                userList.add(usr);
            }
            //SORT BY LAST NAME, FIRST NAME
            Collections.sort(userList, new UserComparatorLF());
            userRespDto.setUsers(userList);
            userRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		} catch (Exception e) {
			System.out.println("Error:"+e.getMessage());
			e.printStackTrace();
		}

		return userRespDto;
	}


	public User searchUserByWWID(String usrWid) {
		User usr = null;
		try {
			String sAttrList[]={"cn","uid","mail","givenName","sn","jnjmsusername","jnjDepartmentDescription","Department","TELEPHONENUMBER","roomNumber","jnjBusinessUnit", "manager"};
		    SearchControls ctrl = new SearchControls();
            ctrl.setReturningAttributes(sAttrList);
            ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String searchBase = "DC=jjedsed,DC=jnj,DC=com" ;
            String searchFilter = "(&(|(uid=" + usrWid + ")(givenName=" + usrWid + ")(sn=" + usrWid + "))(!(employeeType=TERMINATED)))";
            adContext = initADContext();
            NamingEnumeration<SearchResult> enumeration = adContext.search(searchBase, searchFilter, ctrl);
            if (enumeration.hasMoreElements()) {
                SearchResult result = enumeration.next();
                Attributes attribs = result.getAttributes();
                System.out.println("Attributes:"+attribs);
                NamingEnumeration<String> attribsIDs = attribs.getIDs();

                String fullNm = (attribs.get("cn") != null ?  (attribs.get("cn").toString().split(":")[1]):"");
                String wwid = (attribs.get("uid") != null ?  (attribs.get("uid").toString().split(":")[1]):"");
                String mail = (attribs.get("mail") != null ?  (attribs.get("mail").toString().split(":")[1]):"");
                String fNm =  (attribs.get("givenName") != null ?  (attribs.get("givenName").toString().split(":")[1]):"");
                String lNm= (attribs.get("sn") != null ?  (attribs.get("sn").toString().split(":")[1]):"");
                String ntId = (attribs.get("jnjmsusername") != null ?  (attribs.get("jnjmsusername").toString().split(":")[1]):"");
                String deptDesc = (attribs.get("jnjDepartmentDescription") != null ?  (attribs.get("jnjDepartmentDescription").toString().split(":")[1]):"");
                String dept = (attribs.get("Department") != null ?  (attribs.get("Department").toString().split(":")[1]):"");
                String tel = (attribs.get("TELEPHONENUMBER") != null ?  (attribs.get("TELEPHONENUMBER").toString().split(":")[1]):"");
                String bussUnit = (attribs.get("jnjBusinessUnit") != null ?  (attribs.get("jnjBusinessUnit").toString().split(":")[1]):"");
                String mgrDet = (attribs.get("manager") != null ?  (attribs.get("manager").toString().split(":")[1]):"");
                String cube = (attribs.get("roomnumber") != null ?  (attribs.get("roomnumber").toString().split(":")[1]):"");
                usr = new User();
                usr.setFullName(fullNm.trim());
                usr.setWwid(wwid.trim());
                usr.setFirstName(fNm.trim());
                usr.setLasttName(lNm.trim());
                usr.setEmail(mail.trim());
                usr.setNtId(ntId.trim());
                usr.setDepartment(dept.trim());
                usr.setDepartmentDesc(deptDesc.trim());
                usr.setTel(tel.replace("$", "").trim());
                usr.setBusinessUnit(bussUnit);
                usr.setCubeno(cube);
                getManagerdata(usr, mgrDet);
            }
         } catch (Exception e) {
			System.out.println("Error:"+e.getMessage());
			e.printStackTrace();
		}

		return usr;
	}



	private void getManagerdata(User usr, String mgrDet) {
	    String [] mgrArr = null;
        String mgrNm ="";
        String mgrWwid="";
        if(mgrDet != null && mgrDet.length() > 0) {
        	mgrArr = mgrDet.split(",");
        	if(mgrArr.length > 0) {
        		String []nmArr = mgrArr[0].split("=");
        		if(nmArr.length>1) {
        			mgrNm = nmArr[1];
        		}
        	}
        	if(mgrArr.length > 1) {
        		String[] wArr = mgrArr[1].split("=");
        		if(wArr.length > 1) {
        			mgrWwid = wArr[1];
        		}
        	}
        }
        usr.setMgrId(mgrWwid);
        usr.setMgrNm(mgrNm);
	}

	/*public void searchUserById(String userId) {
		try {
			    String sAttrList[]={"uid","manager","cn","jnjDisplayName","name","givenName","jnjNickname","sn","initials","title","jnjBusinessUnit","jnjDepartmentDescription","Department","jnjDivision","jnjStartDate","eCertStatus","employeeType","jnjMSUPN","mail","jnj-managerAtTermination","telephoneNumber","roomNumber","businessCategory","directReports","objectClass"};
	            SearchControls ctrl = new SearchControls();
	            ctrl.setReturningAttributes(sAttrList);
	            ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
	            String searchBase = "DC=jjedsed,DC=jnj,DC=com" ;
	            String searchFilter = "(&(jnjmsusername="+userId+")(!(employeeType=TERMINATED))   (!(uid=640100059)) )";
	            adContext = initADContext();
	            NamingEnumeration<SearchResult> enumeration = adContext.search(searchBase, searchFilter, ctrl);

	            while (enumeration.hasMoreElements()) {
	                SearchResult result = (SearchResult) enumeration.next();




	                Attributes attribs = result.getAttributes();
	                System.out.println("Attributes:"+attribs);
	                NamingEnumeration<String> attribsIDs = attribs.getIDs();
	                StringBuffer output = new StringBuffer();
	                int iAttr = 0;
	                //String sAttrList[]={"uid","manager","cn","jnjDisplayName","name","givenName","jnjNickname","sn","initials","title","jnjBusinessUnit","jnjDepartmentDescription","Department","jnjDivision","jnjStartDate","eCertStatus","employeeType","jnjMSUPN","mail","jnj-managerAtTermination","telephoneNumber","roomNumber","businessCategory","directReports","objectClass"};
	                while (attribsIDs.hasMore()) {
	                	String attrID = attribsIDs.next();
	                    System.out.println("AttributeId:"+ iAttr+" "+attrID+"  Val:"+attribs.get(attrID));
	                }
	                int j = 1;
	                for(String attNm: sAttrList) {

	                	System.out.println((j++)+". "+attNm+"-"+attribs.get(attNm));
	                }


	            }
		} catch (Exception e) {
			System.out.println("Error:"+e.getMessage());
			e.printStackTrace();
		}
	}*/


	private  DirContext initADContext() throws Exception{
		//if(adContext == null) {
			adContext = new InitialDirContext(getEnvParams());
		//}
		return adContext;
	}


	private Hashtable<String, String> getEnvParams(){
		//String contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
		//String ldapUrl = "LDAP://jjedsdir.na.jnj.com";
		//String securityAuthType = "simple";
		//String securityPrincipal = "DChauras";
		//private static String securityCredentials="Dharm1234";
		String contextFactory = environment.getProperty("ldap.factory");
		String ldapUrl ="LDAP://" + environment.getProperty("ldap.provider");
		String secAuthType = environment.getProperty("ldap.auth");
		String secPrincipal = environment.getProperty("ldap.pser");

		Hashtable<String, String> envParams = new Hashtable<>();
		envParams.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
		envParams.put(Context.PROVIDER_URL, ldapUrl);
		envParams.put(Context.SECURITY_AUTHENTICATION, secAuthType);
		envParams.put(Context.SECURITY_PRINCIPAL, secPrincipal);

		return envParams;
	}


	@Override
	public List<String> getConstantList(String cid) {
		List<String> dataList = new ArrayList<>();
		try {
			String vals = userMenuDao.getUtilsConstVals(cid);
			if(!vals.isEmpty()) {
				dataList =  Arrays.stream(vals.split(","))
                .collect(Collectors.toList());
			}

		} catch (Exception e) {
			log.error("Exception getting Constant Value for Variable : "+cid, e);
		}
		return dataList;
	}



}
