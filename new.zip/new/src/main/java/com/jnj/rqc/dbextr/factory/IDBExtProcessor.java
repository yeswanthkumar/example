package com.jnj.rqc.dbextr.factory;

import java.sql.SQLException;

import org.springframework.dao.DataAccessException;

public interface IDBExtProcessor {

	public String process()throws SQLException, DataAccessException;


}
