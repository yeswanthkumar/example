package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.CRUnitADGroupMdl;
import com.jnj.rqc.models.ExcessiveAccessModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.PlatformProjectMdl;
import com.jnj.rqc.models.ProjectApprCatgMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.TktApprLogMdl;
import com.jnj.rqc.models.UETktModel;
import com.jnj.rqc.models.UserRequestDispMdl;
import com.jnj.rqc.models.UserRequestModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.useridentity.models.BusinessFunctionModel;
import com.jnj.rqc.useridentity.models.BusinessProcessModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.UIReqDpendncMdl;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.useridentity.models.UIRequestModel;
import com.jnj.rqc.useridentity.models.UserIdentityConflictMdl;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;

public interface UserIdentityDao {
	/*Reading from Master Data*/
	int buildQuery(int counter, String varName, String[] recdArr, Object[] inparams, StringBuilder sql);
	public List<KeyValPair> getMSectorRegionKV(String bfId, String[] secIds)throws SQLException, DataAccessException;
	public List<KeyValPair> getMRegionSystemsKV(String bfId, String[] secIds, String[] regIds)throws SQLException, DataAccessException;
	public List<KeyValPair> getMSystemPositionsKV(String bfId, String[] secIds, String[] regIds, String sysId)throws SQLException, DataAccessException;
	public List<KeyValPair> getMPosnsAccsTypKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds)throws SQLException, DataAccessException;
	public List<KeyValPair> getMAcsTypPosVarnKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsTypIds)throws SQLException, DataAccessException;
	public List<UserRoleADGrpMdl> getMPosVarnADGrpKV(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsTypIds, String[] posVarArr) throws SQLException, DataAccessException;
	public List<UserRoleADGrpMdl> getMstDataForADGrp(String ldapADGroup) throws SQLException, DataAccessException;
	public List<UserRoleADGrpMdl> getCFINMstDataForRole(String techRle) throws SQLException, DataAccessException;
	public List<UserRoleADGrpMdl> getAnaplanMstDataForRole(String techRle) throws SQLException, DataAccessException;
	public List<UserIdentityConflictMdl> getConflictsforPositions(String query) throws SQLException, DataAccessException;
	public int saveUIUserRequest(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst)throws SQLException, DataAccessException;
	public int saveUIUserConflicts(int requestId, UserSearchModel assocUser, List<UserIdentityConflictMdl> confList) throws SQLException, DataAccessException;
	public int saveUIExAccess(int requestId, UserSearchModel assocUser, List<ExcessiveAccessModel> exList) throws SQLException, DataAccessException;
	public List<UIRequestDispModel> getNewUserSubmittedReqs(String startDate, String endDate, String userWwId, int status)throws SQLException, DataAccessException;
	public List<UIRequestDispModel> getNewUserApprovalReqs(String startDate, String endDate, String userWwId)throws SQLException, DataAccessException;
	public List<UIRequestDispModel> getUserSavedTktData(String tktNum) throws SQLException, DataAccessException;
	public List<UIReqDpendncMdl> getRequestDependencies(String reqId)throws SQLException, DataAccessException;
	public List<UserIdentityConflictMdl> getRequestConflicts(String reqId) throws SQLException, DataAccessException;
	public List<ExcessiveAccessModel> getRequestExcData(String reqId) throws SQLException, DataAccessException;
	public List<UserIdentityConflictMdl> getUserConflicts(String userId) throws SQLException, DataAccessException;
	public List<KeyValPair> getMitiControls(String id, String type) throws SQLException, DataAccessException;
	public int updReqSodApprStatus(String requestId, int status, String resolved) throws SQLException, DataAccessException;
	public int saveTktConflictApproval(List<UserIdentityConflictMdl> resolMdl) throws SQLException, DataAccessException;
	public int saveTktExcesApproval(List<ExcessiveAccessModel> resolMdl) throws SQLException, DataAccessException;
	//IAM
	public List<UIRequestDispModel> getAllApprovedUserReqs()throws SQLException, DataAccessException;
	public List<UIRequestDispModel> getAllIamSubmittedReqs()throws SQLException, DataAccessException;
	public String getAdGrpById(String adGrpId) throws SQLException, DataAccessException;
	public int saveIamReqstedRoles(List<IAMRequestedRoleModel> reqMdlLst) throws SQLException, DataAccessException;
	public int updateIamRequestStatus(String requestId, int status) throws SQLException, DataAccessException;
	public List<IAMRequestedRoleModel> getGRCIAMReqSubmDependencies(String reqId) throws SQLException, DataAccessException;
	public int updateIamReqstedRolesStatus(String apiStatus, String apiMsg, String apiErrMsg, Date updDt, IAMRequestedRoleModel detailNum) throws SQLException, DataAccessException;
	public int getRequestChildCount(String reqId) throws SQLException, DataAccessException;
	public List<String> getCompletedReqStatus(String reqId) throws SQLException, DataAccessException;
	public List<IAMRequestedRoleModel> getDBRoleReqstStatus(String reqId) throws SQLException, DataAccessException;
	public List<KeyValPair> getAllSystemPosVariantsKV(String bfId, String[] secIds, String[] regIds, String sysId) throws SQLException, DataAccessException;
	/*Reading from Master Data*/

	public List<KeyValPair> getBussFuncSectorsKV(String bfId) throws SQLException, DataAccessException;
	public List<KeyValPair> getProjSystemsKV(String prjId) throws SQLException, DataAccessException;
	public List<KeyValPair> getRegnSystemsKV(String regId) throws SQLException, DataAccessException;
	public List<KeyValPair> getSysPositionsKeyVal(String sysIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getPosAccessTypesKV(String posId) throws SQLException, DataAccessException;
	public List<KeyValPair> getAcsPosnVariantKV(String posId) throws SQLException, DataAccessException;

	public List<UserRoleADGrpMdl> getUserRoles(String userId, int type) throws SQLException, DataAccessException;//Type 1=Granted/2=Requested
	public List<KeyValPair> getRequestTypes() throws SQLException, DataAccessException  ;
	public List<KeyValPair> getProjectsKeyVal()throws SQLException, DataAccessException;
	public List<BusinessFunctionModel> getBusinessFunctionVals(String bfId)throws SQLException, DataAccessException;
	public List<BusinessProcessModel> getBusinessProcessVals(String bfId)throws SQLException, DataAccessException;
	public List<KeyValPair> getSectorRegionKV(String secId)throws SQLException, DataAccessException;
	public List<KeyValPair> getCntryAcctFuncKV(String secId)throws SQLException, DataAccessException;
	public List<StrKeyValPair> getAccfConsUnitKeyVal(String cntryIds, String accfIds)throws SQLException, DataAccessException;
	public List<StrKeyValPair> getAccfRespUnitKeyVal(String cntryIds, String accfIds) throws SQLException, DataAccessException;
	public List<CRUnitADGroupMdl> getADGrpsforConsRespUnit(String cnsRspIds, String typ)throws SQLException, DataAccessException;

	public List<PlatformProjectMdl> getProjectsData(String prjId) throws SQLException, DataAccessException;
	public List<KeyValPair> getProjectSectors(String prjPlatformId)throws SQLException, DataAccessException;
	public List<KeyValPair> getSecAcctFuncKV(String secId)throws SQLException, DataAccessException;
	public List<KeyValPair> getPerRolesKV(String perId)throws SQLException, DataAccessException;
	public List<KeyValPair> getPosRolesKV(String perId) throws SQLException, DataAccessException;
	public List<KeyValPair> getfuncRegKV(String funcId)throws SQLException, DataAccessException;
	public List<StrKeyValPair> getRespUnitKeyVal(String cntryIds, String secIds)throws SQLException, DataAccessException;
	public List<StrKeyValPair> getConsUnitKeyVal(String cntryIds, String secIds)throws SQLException, DataAccessException;
	//public int saveUserRequest(String reqTyp, String projects, String sctorNm, String accFunction, String regions, String countryNm, String consData, String respData, String cmnts, UserSearchModel curUser, UserSearchModel assocUser)throws SQLException, DataAccessException;
	public int saveUserRequest(UserRequestModel reqModel)throws SQLException, DataAccessException;
	public int updateRequestStatus(String requestId, int status, int apprSeq) throws SQLException, DataAccessException;
	public List<KeyValPair> getRegionsKeyVal(String[] regIds) throws SQLException, DataAccessException ;
	public List<UserRequestDispMdl> getUserSubmittedReqs(String startDate, String endDate, int projects, int status, String userWwId)throws SQLException, DataAccessException;
	public List<KeyValPair> getProjectPersonas(String prjId) throws SQLException, DataAccessException;
	public List<KeyValPair> getProjectPositions(String prjId)throws SQLException, DataAccessException;
	public List<UserRequestDispMdl> getMyReqData(String startDate, String endDate, String userWwId)throws SQLException, DataAccessException;
	public List<UserRequestDispMdl> getMgrApprQueData(String startDate, String endDate, int projects, /*int status,*/ String mgrId)throws SQLException, DataAccessException;

	public List<KeyValPair> getCountriesKeyVal(String regionId)throws SQLException, DataAccessException;
	public List<KeyValPair> getSectorKeyVal(String cntId)throws SQLException, DataAccessException;
	public List<KeyValPair> getConsUnitKeyVal(String secId)throws SQLException, DataAccessException;
	public List<KeyValPair> getResponsiblityUnitKeyVal(String consId)throws SQLException, DataAccessException;
	public List<KeyValPair> getReqStatusKeyVal()throws SQLException, DataAccessException;
	public List<UETktModel> getUserTktData(String tktNum) throws SQLException, DataAccessException;
	//Parent table
	public List<KeyValPair> getPersonasKeyVal(String[] persIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getPositionsKeyVal(String[] posIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getRolesKeyVal(String[] roleIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getSectorsKeyVal(String[] secIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getAcctFuncKeyVal(String[] accfIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getCntrysKeyVal(String[] cntryIds) throws SQLException, DataAccessException;
	public List<KeyValPair> getConsUnitsKeyVal(String[] consIds) throws SQLException, DataAccessException;
	public List<StrKeyValPair> getRespUnitsKeyVal(String[] respIds) throws SQLException, DataAccessException;
	public List<ProjectApprCatgMdl> getProjectApprCategory(String projects, int seqId, int implId) throws SQLException, DataAccessException;
	public int updateApprovalLog(TktApprLogMdl appLogData)throws SQLException, DataAccessException;
	public List<TktApprLogMdl> getApprovalLogData(String reqId) throws SQLException, DataAccessException;
	public List<UserRequestDispMdl> getMgrApprQueWithConflictsData(String startDate, String endDate, String mgrId)	throws SQLException, DataAccessException;
	public List<String> getAllSystemPosVariants(String bfId, String[] secIds, String[] regIds, String sysId) throws SQLException, DataAccessException;
	public List<KeyValPair> getPosVarKeyVal(String[] pvIds) throws SQLException, DataAccessException;
	public List<String> getAnaplanHistDataForUser(String userId) throws SQLException, DataAccessException;
	//public List<String> getAnaplanIamDataForUser(String userId) throws SQLException, DataAccessException;

































	/*public List<SAPUserAccessModel> getJDEUserData(String templSysParam) throws SQLException, DataAccessException  ;
	public List<SapGaaUser2RoleModel> getJDEUser2RoleData(String templSysParam) throws SQLException, DataAccessException;
	public List<String> getAllValidUsers(String templSysParam) throws JCoException  ;
	public List<String> getUsersRoles(String user, String templSysParam) throws JCoException;
	public String getRoleDescription(String role, String templSysParam) throws JCoException;
	public String getUsersPersonNumber(String user, String templSysParam) throws JCoException;
	public String getUsersWwId(String prsnNumber, String templSysParam) throws JCoException;*/
}
