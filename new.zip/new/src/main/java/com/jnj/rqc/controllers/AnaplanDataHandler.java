package com.jnj.rqc.controllers;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.jnj.rqc.dao.CSMDataDao;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.security.AnaplanAuthenticatorBean;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserIdentityService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.useridentity.models.AnaplanEmailDimensionModel;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;




/**
 * File    : <b>AnaplanDataHandler.java</b>
 * @author : DChauras @Created : Dec 15, 2022 5:35:28 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class AnaplanDataHandler {
	static final Logger log = LoggerFactory.getLogger(AnaplanDataHandler.class);
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	UserIdentityService userIdentityService;
	@Autowired
	UserIdentityDao userIdentityDao;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;




	@Autowired
	private RestTemplate restHttpTemplate;
	@Autowired
	private UserMenuDao userMenuDao;

	@Autowired
	CSMDataDao cSMDataDao;

	@Autowired
	AnaplanAuthenticatorBean anaplanAuthenticatorBean;

	String uri = "https://api.anaplan.com/1/3/"; //https://api.anaplan.com/2/0/workspaces/{workspaceId}/models/{modelId}/exports

	@GetMapping("/login2Anaplan")
    public String connctToAnaplan(Model model,  HttpServletRequest req) {//Test Method
    	log.info("Login to ANAPLAN");
    	 long start = System.currentTimeMillis();
    	 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
    	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    	log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    	//getExpDef(model, req);
    	return "home";
    }


	@GetMapping("/getExpDef")
    public String getExpDef(Model model,  HttpServletRequest req) {//Test Method
    	log.info("getExportDefinitions");
    	 long start = System.currentTimeMillis();
    	 List<GrpUsrDateMdl> dataList = downloadExpDef();
    	 return "home";
	}



    	public List<GrpUsrDateMdl> downloadExpDef() {//Test Method
	    	log.info("Read and Download Export Definitions");
	    	 long start = System.currentTimeMillis();
	    	 List<GrpUsrDateMdl> dataList = new LinkedList<>();
	    	 try{
	    		 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
	    		 HttpHeaders headers = getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
	    		 Gson gson = new Gson();
	    		 HttpEntity<String> reqEntity = new HttpEntity<>(headers);
	    		 //ANAPLAN
	    		 //ResponseEntity<String> respEntity = restHttpTemplate.exchange("https://api.anaplan.com/2/0/workspaces/8a81b0117522ca1701754b5d63282532/models/646630C2F0024B2AAC4308F60BBEAE92", HttpMethod.GET, reqEntity, String.class);
	    		 start = System.currentTimeMillis();
	    		 ResponseEntity<String> respEntity = restHttpTemplate.exchange("https://api.anaplan.com/2/0/workspaces/8a81b0117522ca1701754b5d63282532/models/646630C2F0024B2AAC4308F60BBEAE92/files/116000000018", HttpMethod.GET, reqEntity, String.class);
	    		 log.info("<<<<<<<<<<  Total time taken to AnaPlan Read Data : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
	    		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
	 				BufferedReader br = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(respEntity.getBody().getBytes())));
	 				GrpUsrDateMdl csmMdl = null;
	 				String dline = "";
	 				int totalCount = 0;
	 				while ((dline = br.readLine()) != null) {
	 					String[] usrData = dline.split(",");
	 					if(totalCount == 0) {//IGNORE HEADER ROW
	 						totalCount++;
	 						continue;
	 					}
	 					totalCount++;
	 					if(usrData != null && usrData.length >= 9 ) {
	 						if(null != usrData[4] && usrData[4].trim().length() >1 && null != usrData[5] && usrData[5].trim().length() >1 ) {
	 							UserSearchModel curUser = userSearchService.getUserStatusByEmailJJEDS(usrData[4].trim(), 1);
	 							if(curUser != null) {
	 								csmMdl = new GrpUsrDateMdl();
	 								csmMdl.setUserId(curUser.getWwId());
	 								csmMdl.setFName(curUser.getGivenNm());
	 								csmMdl.setLName(curUser.getFmlyNm());
	 								csmMdl.setEmailId(curUser.getJnjEmailAddrTxt());
	 								csmMdl.setAdgroup(usrData[5].trim());
	 								csmMdl.setEmpStatus(curUser.getEmpStatTxt());
	 								csmMdl.setModelname("");
	 								String modDate = usrData[6].trim();
	 								String vldFrm  = usrData[7].trim();
	 								String vldTo   = usrData[8].trim();
	 								csmMdl.setModDate(Utility.frmStrToDt(modDate));
	 								csmMdl.setVldFrom(Utility.frmStrToDt(vldFrm));
	 								csmMdl.setVldTo(Utility.frmStrToDt(vldTo));
	 								//csmMdl.setVldTo(Utility.ldapStrToDtUTCEST(vldTo));
	 								dataList.add(csmMdl);
	 							}
	 						}
	 					}
	 				}
	 			 }
	    		 log.info("Total Number if Records Read :"+dataList.size());
	    		 log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
	    		 log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
			} catch (Exception e) {
				log.error("Exception getting Exp Def:"+e.getMessage(), e);
			}
	    	 return dataList;
    	}



    	public int saveCSMDataToDB(List<GrpUsrDateMdl> iamCsmData){
    		int result = 0;
    		try {
    				result = cSMDataDao.insertCSMCurrentData(iamCsmData);
    		} catch (Exception e) {
    			log.error("Error inserting CSM Archive Data :"+e.getMessage(), e);
    		}
    		return result;
    	}



	@GetMapping("/uploadNewDef")
    public String uploadNewDef(Model model,  HttpServletRequest req) {//Test Method
		log.info("Routing to Upload page.");
    	return "sapextraction/uploadAnaplanModels";
	}

	@PostMapping("/uploadNewDefData")
    public String uploadNewDefData(@RequestParam("file") @Nullable MultipartFile file , Model model,  HttpServletRequest req) {//Test Method
    	log.info("getExportDefinitions");
    	 long start = System.currentTimeMillis();
    	 try{
    		 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
    		 //HttpHeaders headers = getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 Gson gson = new Gson();
    		 //HttpEntity<String> reqEntity = new HttpEntity<String>(headers);

    		 //READ ALL FILES
    		 /*
    		 ResponseEntity<String> respEntity = restHttpTemplate.exchange("https://api.anaplan.com/2/0/workspaces/8a81b0117522ca1701754b5d63282532/models/646630C2F0024B2AAC4308F60BBEAE92/files", HttpMethod.GET, reqEntity, String.class);
    		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
 				log.info("Resp Body: "+respEntity.getBody());
 				//respBody = gson.fromJson(respEntity.getBody(), IamAdGrpServiceStatusRespDTO.class);
 				//log.info("resp.STATUS COMPLETE:"+respBody.getValues().isCCC_IsComplete()+" IS ERROR: "+respBody.getValues().isCCC_IsError());
 			 }else {
 				//respBody = new IamAdGrpServiceStatusRespDTO();
 				//respBody.setUri("");
 			 }
 			 */


 			//UPLOAD FILES
    		//upload-file : 113000000108
    		//https://api.anaplan.com/1/3/workspaces/8a8196b15b7dbae6015b8694411d13fe/models/75A40874E6B64FA3AE0743278996850F/files/113000000008 --upload-file Tests.txt
    		// HttpHeaders headers2 = getHeaders("FILE", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 HttpHeaders headers = new HttpHeaders();
    		 headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    		 headers.add("Authorization", "AnaplanAuthToken "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 headers.set("upload", file.getOriginalFilename());//Setting File Name
    		 ContentDisposition contentDisposition = ContentDisposition
    	                .builder("form-data")
    				 	//.builder("application/octet-stream")
    	                .name("file")
    	                .filename(file.getOriginalFilename())
    	                .build();

    		 MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();
    		 fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());
    		 HttpEntity<byte[]> fileEntity = new HttpEntity<>(file.getBytes(), fileMap);
    		 MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
    	     body.add("upload-file", fileEntity);
    	     HttpEntity<MultiValueMap<String, Object>> reqEntity2 = new HttpEntity<>(body, headers);
    	     //Adding Converter
    	     MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    		 converter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
    		 restHttpTemplate.getMessageConverters().add(converter);

    	     ResponseEntity<String> respEntity2 = restHttpTemplate.exchange("https://api.anaplan.com/2/0/workspaces/8a81b0117522ca1701754b5d63282532/models/646630C2F0024B2AAC4308F60BBEAE92/files/113000000108", HttpMethod.PUT, reqEntity2, String.class);
    		 if (respEntity2 != null && respEntity2.getStatusCode() == HttpStatus.NO_CONTENT) {
  				log.info("Resp Body: "+respEntity2.getBody());
    		 }else {
    			 log.error("ERROR Uploading file: "+respEntity2);
    		 }
    		log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
 	    	log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
		} catch (Exception e) {
			log.error("Exception getting Exp Def:"+e.getMessage(), e);
		}

    	return "home";
    }




	public HttpHeaders getHeaders(String mediaTyp, String authToken) {
		HttpHeaders headers = new HttpHeaders();
		if(Utility.isEmpty(mediaTyp) || "JSON".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}else if("TEXT".equals(mediaTyp)) {
			headers.setContentType(MediaType.TEXT_PLAIN);
		}else if("FILE".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			//headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		}

		if(!Utility.isEmpty(authToken)) {
			//Authorization:AnaplanAuthToken {anaplan_auth_token}
			headers.add("Authorization", "AnaplanAuthToken "+authToken);
		}
		return headers;
	}



	/**
	 * Method  : AnaplanDataHandler.java.getIndividualExportDef()
	 *		   :<b>@param emailId
	 *		   :<b>@param model
	 *		   :<b>@param req
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jun 5, 2023 2:37:03 PM
	 * Purpose : Get individuals export Definitions
	 * @return : String
	 */
	@GetMapping("/getIndividualExportDef")
    public String getIndividualExportDef(@RequestParam String emailId, Model model,  HttpServletRequest req) {//Test Method
    	log.info("getExportDefinitions");
    	 long start = System.currentTimeMillis();
    	 List<GrpUsrDateMdl> dataList = getAccessDataForIndividualUser(emailId);
    	 return "home";
	}


	/**
	 * Method  : AnaplanDataHandler.java.getAccessDataForIndividualUser()
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jun 5, 2023 2:35:44 PM
	 * Purpose : Get Individual User Roles from Anaplan
	 * @return : List<GrpUsrDateMdl>
	 */
	public List<GrpUsrDateMdl> getAccessDataForIndividualUser(String emailId) {//Test
    	log.info("Read/Download individuals Export Definitions");
    	 long start = System.currentTimeMillis();
    	 List<GrpUsrDateMdl> dataList = new LinkedList<>();
    	 try{
    		 anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
    		 HttpHeaders headers = getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
    		 Gson gson = new Gson();
    		 HttpEntity<String> reqEntity = new HttpEntity<>(headers);
    		 start = System.currentTimeMillis();
    		 //Get Email Dimension
    		 ResponseEntity<String> respEntity = restHttpTemplate.exchange("https://api.anaplan.com/2/0/models/EB35B4594A2945FD9D9C547DD8CFB44D/views/1037000000000", HttpMethod.GET, reqEntity, String.class);
    		 log.info("<<<<<<<<<<  Total time taken to AnaPlan Read Data : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
    			 log.info("Resp Body: "+respEntity.getBody());
    			 AnaplanEmailDimensionModel respBody = gson.fromJson(respEntity.getBody(), AnaplanEmailDimensionModel.class);
    			 if(null != respBody && null != respBody.getPages() && !respBody.getPages().isEmpty() ) {
    				 String dimensionId = respBody.getPages().stream()
    						 			.filter(p -> p.getName().equalsIgnoreCase("Employee Email"))
    						 				.findFirst()
    						 					.get().getId();
    				 log.info("Resp Body Dimension ID: "+dimensionId);

    				 if(!Utility.isEmpty(dimensionId)) {
    					 String dimUrl = "https://api.anaplan.com/2/0/workspaces/8a868cdd82bd3b1d0182fa0379267ac8/models/EB35B4594A2945FD9D9C547DD8CFB44D/dimensions/"+dimensionId+"/items";
    					 ResponseEntity<String> dimItemsResp = restHttpTemplate.exchange(dimUrl, HttpMethod.GET, reqEntity, String.class);
    					 if (dimItemsResp != null && dimItemsResp.getStatusCode() == HttpStatus.OK) {
    		    			 log.info("Dimensions Body: "+dimItemsResp.getBody());
    					 }

    				 }
    			 }

    		 }

    		 if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
 				BufferedReader br = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(respEntity.getBody().getBytes())));
 				GrpUsrDateMdl csmMdl = null;
 				String dline = "";
 				int totalCount = 0;
 				while ((dline = br.readLine()) != null) {
 					String[] usrData = dline.split(",");
 					if(totalCount == 0) {//IGNORE HEADER ROW
 						totalCount++;
 						continue;
 					}
 					totalCount++;
 					if(usrData != null && usrData.length >= 9 ) {
 						if(null != usrData[4] && usrData[4].trim().length() >1 && null != usrData[5] && usrData[5].trim().length() >1 ) {
 							UserSearchModel curUser = userSearchService.getUserStatusByEmailJJEDS(usrData[4].trim(), 1);
 							if(curUser != null) {
 								csmMdl = new GrpUsrDateMdl();
 								csmMdl.setUserId(curUser.getWwId());
 								csmMdl.setFName(curUser.getGivenNm());
 								csmMdl.setLName(curUser.getFmlyNm());
 								csmMdl.setEmailId(curUser.getJnjEmailAddrTxt());
 								csmMdl.setAdgroup(usrData[5].trim());
 								csmMdl.setEmpStatus(curUser.getEmpStatTxt());
 								csmMdl.setModelname("");
 								String modDate = usrData[6].trim();
 								String vldFrm  = usrData[7].trim();
 								String vldTo   = usrData[8].trim();
 								csmMdl.setModDate(Utility.frmStrToDt(modDate));
 								csmMdl.setVldFrom(Utility.frmStrToDt(vldFrm));
 								csmMdl.setVldTo(Utility.frmStrToDt(vldTo));
 								//csmMdl.setVldTo(Utility.ldapStrToDtUTCEST(vldTo));
 								dataList.add(csmMdl);
 							}
 						}
 					}
 				}
 			 }
    		 log.info("Total Number if Records Read :"+dataList.size());
    		 log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    		 log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
		} catch (Exception e) {
			log.error("Exception getting Exp Def:"+e.getMessage(), e);
		}
    	 return dataList;
	}







  }
