package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.dbextr.models.ADGroupRespDto;
import com.jnj.rqc.dbextr.models.CRADGroupRespDto;
import com.jnj.rqc.dbextr.models.DDMultiRespDto;
import com.jnj.rqc.dbextr.models.DDRespDto;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.CRUnitADGroupMdl;
import com.jnj.rqc.models.ExcessiveAccessModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.SysPosAdGrpModelDispMdl;
import com.jnj.rqc.models.TktApprLogMdl;
import com.jnj.rqc.models.UETktModel;
import com.jnj.rqc.models.UserRequestDispMdl;
import com.jnj.rqc.models.UserRequestModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.useridentity.models.BusinessFunctionModel;
import com.jnj.rqc.useridentity.models.BusinessProcessModel;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceStatusRespDTO;
import com.jnj.rqc.useridentity.models.UIReqDpendncMdl;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.useridentity.models.UIRequestModel;
import com.jnj.rqc.useridentity.models.UserIdentityConflictMdl;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;
import com.jnj.rqc.useridentity.models.UserRolesRespDto;




/**
 * File    : <b>UserIdentityService.java</b>
 * @author : DChauras @Created : Sep 13, 2021 2:42:24 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

public interface UserIdentityService {

	/* START - Retrieve from Master Data */
	public DDRespDto getAllMSectorRegions(String bfId, String secIds);
	public List<KeyValPair> getAllMasterSectorRegions(String bfId, String secIds);
	public DDRespDto getAllSystemsForRegns(String bfId, String secIds, String regIds);
	public List<KeyValPair> getAllMasterRegionSystems(String bfId, String secIds, String regIds);
	public DDRespDto getAllPositionForSystem(String bfId, String secIds, String regIds, String sysId);
	public List<KeyValPair> getAllMasterSystemPositions(String bfId, String secIds, String regIds, String sysId, String selPosns);
	public DDRespDto getAllAccessTypesForPosns(String bfId, String secIds, String regIds, String sysId, String posIds);
	public List<KeyValPair> getAllMasterPosnsAccsTypes(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds);
	public DDRespDto getAllPosnVarnForAcsTyps(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds);
	public List<KeyValPair> getAllMasterAcsTypsPosVarnt(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVarIds);
	public ADGroupRespDto getAllADGrpsForPosnVarns(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVars, HttpServletRequest req);
	public List<UserRoleADGrpMdl> getAllMasterPosVarntADGrp(String bfId, String secIds, String regIds, String sysId, String posIds, String acsTypIds, String posVars);
	public List<UserRoleADGrpMdl> getSystemDetail(String ldapADGroup);
	public List<UserRoleADGrpMdl> getCFINRoleDetail(String tchRole);
	public List<ExcessiveAccessModel> getAllReqExcData(String reqId);
	public List<KeyValPair> getPosVarForIDs(String varIds);
	public List<UserRoleADGrpMdl> checkExistingADGroups(List<UserRoleADGrpMdl> adGrpLst, HttpServletRequest req);
	public List<UserRoleADGrpMdl> removeExistingADGroups(List<UserRoleADGrpMdl> adGrpLst);
	public List<UserIdentityConflictMdl> checkSodConflicts(String wwId, List<String> newPosnVarIds,	List<String> extPosnVarIds);
	public int saveUIRequestData(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst, List<UserIdentityConflictMdl> confList, List<ExcessiveAccessModel> exList, UserSearchModel curUser, UserSearchModel assocUser);
	//public int saveUIRequestData(UIRequestModel reqModel, List<SysPosAdGrpModelDispMdl> dispModelLst, List<UserIdentityConflictMdl> confList, UserSearchModel curUser, UserSearchModel assocUser);
	public List<UIRequestDispModel> getAllNewRequests(String startDate, String endDate, String userWwId, int status);
	public List<UIRequestDispModel> getAllApprovalRequests(String startDate, String endDate, String userWwId);
	public List<UIRequestDispModel> getTicketData(String tktNum);
	public List<UIReqDpendncMdl> getRequestDependency(String reqId);
	public List<UserIdentityConflictMdl> getAllReqConflicts(String reqId);
	public List<UserIdentityConflictMdl> getAllUserConflicts(String userId);
	public List<KeyValPair> getAllMitigatingControls(String id, String type);
	public int saveConfApprovalStatus(List<UserIdentityConflictMdl> resolMdl, String userId);
	public List<UserIdentityConflictMdl> buildConflictApprModel(String reqId, String userId, String curUserId, String[] apprDataArray);
	public int saveExcesApprovalStatus(List<ExcessiveAccessModel> resolMdl, String userId);
	public List<ExcessiveAccessModel> buildExcesApprModel(String reqId, String userId, String curUserId, String[] apprDataArray);
	//IAM
	public List<UIRequestDispModel> getAllApprovedRequests();
	public List<UIRequestDispModel> getAllReqSubmittedToIAM();
	public boolean sendReqDataToIamGrc(UIRequestDispModel reqMdl);
	public boolean getReqStatusFromIamGrc(UIRequestDispModel reqMdl);
	public List<IAMRequestedRoleModel> sendDataToIAM(int reqId, String userId, String reqBy, String sysId, String comments, UIReqDpendncMdl detailNum);
	public IAMRequestedRoleModel createIamRoleModel(int reqId, String userId, String sysId, String comments, String reqBy,	String adGrpId, String adGrpName, String submUid, String submStatus);
	public int updateIamRequestStatus(int reqId, int i);
	public IamAdGrpServiceStatusRespDTO getStatusFromIAM(IAMRequestedRoleModel detailNum);
	public int getRequestCount(String reqId);
	public List<String> getCompltdReqStat(String reqId);
	public List<String> getAllSystemPosVariants(String bussFunc, String secCheckBx, String regCheckBx, String sysId);
	public List<ExcessiveAccessModel> checkExcessiveAccess(List<SysPosAdGrpModelDispMdl> dispLst, List<UserRoleADGrpMdl> extRoles, UserSearchModel assocUser);
	public List<KeyValPair> getAllSystemPosVariantsKV(String bfId, String secIds, String regIds, String sysId);

	/* END - Retrieve from Master Data */
	public List<KeyValPair> getBussFuncSectors(String bfIds);
	public DDRespDto getProjectSystemsData(String prjId);
	public List<KeyValPair> getProjectSystems(String prjId);
	public List<KeyValPair> getRegionSystems(String regIds);
	public DDRespDto getPositionForSystems(String sysId);
	public List<KeyValPair> getSystemPositionsKV(String[] sysIds);
	public DDRespDto getPosAccessTypes(String posIds);
	public List<KeyValPair> getAccessTypesKV(String[] posIds);
	public DDRespDto getAcsPosnVariant(String acsIds);
	public List<KeyValPair> getPosnVariants(String[] acsIds);

	public UserRolesRespDto getUserGrantedRoles(String userId);
	public List<KeyValPair> getAllRequestTypes();
	public List<KeyValPair> getAllProjects();
	public List<StrKeyValPair> getBusinesFunctions(String bfId);
	public List<BusinessFunctionModel> getAllBusinesFunctions(String bfId) throws Exception;
	public List<StrKeyValPair> getBusinesProcess(String bfId);
	public DDRespDto getBussProcessSectors();
	public List<KeyValPair> getBussProcessSectorsKV();
	public List<KeyValPair> getAllSectorRegions(String secIds);
	public List<KeyValPair> getCntryAccFunctions(String cntryIds);
	public DDMultiRespDto getAccfConsRespUnits(String cntryIds, String accfIds);
	public List<StrKeyValPair> getConsUnitCntryAccf(String cntryIds, String accfIds);
	public List<StrKeyValPair> getRespUnitCntryAccf(String cntryIds, String accfIds);
	public CRADGroupRespDto getADGroupsForConsRespUnits(String consIds, String respIds);
	public List<CRUnitADGroupMdl> getADGroupByType(String crIds, String type);


	public List<KeyValPair> getAllSectors(String projId);
	public List<KeyValPair> getAllRegions(String[] regIds);
	public DDRespDto getPrjChildObjects(String prjPlatformId);
	public List<KeyValPair> getAccFunctions(String secIds);
	public List<KeyValPair> getProjectPersonas(String projId);
	public List<KeyValPair> getProjectPositions(String projId);
	public List<KeyValPair> getPersonaRoles(String perIds);
	public List<KeyValPair> getPositionRoles(String posIds);
	public List<KeyValPair> getAllFuncRegions(String funcIds);
	public List<KeyValPair> getRegCountries(String regIds);
	public DDMultiRespDto getConsRespUnits(String cntryIds, String sectIds);
	public List<StrKeyValPair> getConsUnitCntrySec(String cntryIds, String secIds);
	public List<StrKeyValPair> getRespUnitCntrySec(String cntryIds, String secIds);
	public List<KeyValPair> getReqStatus();
	//public int saveRequestData(String reqTyp, String projects, String sctorNm, String accFunction, String regions, String countryNm, String consData, String respData, String cmnts, UserSearchModel curUser, UserSearchModel assocUser);
	public int saveRequestData(UserRequestModel reqModel, UserSearchModel curUser, UserSearchModel assocUser);
	//Request and Approvals
	public List<UserRequestDispMdl> getAllRequests(String startDate, String endDate, int projects, int status, String userWwId);
	public List<UETktModel> getTktData(String tktNum);
	public List<UserRequestDispMdl> getMyRequests(String startDate, String endDate, String userWwId);
	public List<UserRequestDispMdl> getMyApprQueData(String startDate, String endDate, int projects, /*int status,*/ String mgrId);
	public Map<String, List<String>> getApproverCategoryEmails(UserSearchModel assocUser, String projId, int seqId, int implId, UserSearchModel assMgr)throws Exception;
	public void saveApprovalData(TktApprLogMdl appLogData);


	//END Request and Approvals

	public DDRespDto getCountrySectors(String cntryIds);
	public DDRespDto getSectorConsUnit(String secIds);
	public DDRespDto getConsResponsiblityUnit(String consIds);

	public TableRespDto getEnvData(String propName);

	//LOAD ALL REFERENCE TABLES
	public void loadAllReferenceData();
	public Map<String, List<String>> readProjectApprCategory(String projId, int seqId, int implementorId);
	public List<BusinessProcessModel> getAllBusinesProcess(String bfId) throws Exception;
	public List<UserRoleADGrpMdl> getAnaplanRoleDetail(String tchRole);
	public List<UserRoleADGrpMdl> getIAMAnaplanUserRoleDetail(String tchRole);












































}
