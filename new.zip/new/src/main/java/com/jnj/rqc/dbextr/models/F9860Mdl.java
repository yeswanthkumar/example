package com.jnj.rqc.dbextr.models;

import lombok.Data;


@Data
public class F9860Mdl {
	private String sIOBNM;
	private String sIMD;
	private String sISY;
	private String sISYR;
	private String sIFUNO;
	private String sIFUNU;
	private String sIPFX;
	private String sISRCLNG;
	private String sIANSIF;
	private String sICATO;
	private String sICLDF;
	private String sICPYD;
	private String sIOMIT;
	private String sIOPDF;
	private String sIAPPLID;
	private String sICURTYP;
	private String sIBFLOCN;
	private String sIGBOPTN;
	private String sIGTFILE;
	private String sIGTTYPE;
	private String sIGTFFU1;
	private String sIJDETEXT;
	private String sIPROPID;
	private String sIMID1;
	private String sIBASE;
	private String sIPARDLL;
	private String sIPAROBN;
	private String sIPKGCOL;
	private String sIOLCD01;
	private String sIOLCD02;
	private String sIOLCD03;
	private String sIOLCD04;
	private String sIOLCD05;
	private String sIPID;
	private String sIUSER;
	private String sIJOBN;
	private String sIUPMJ;
	private String sIUPMT;
	public String getData() {
		return  sIOBNM + "~" +sIMD + "~" + sISY + "~" +sISYR + "~" + sIFUNO + "~"+sIFUNU+"~"+sIPFX+"~"+sISRCLNG+"~"+sIANSIF+"~"+sICATO+"~"+sICLDF+"~"+sICPYD+"~"+sIOMIT+"~"+sIOPDF+"~"+
				sIAPPLID+"~"+sICURTYP+"~"+sIBFLOCN+"~"+sIGBOPTN+"~"+sIGTFILE+"~"+sIGTTYPE+"~"+sIGTFFU1+"~"+sIJDETEXT+"~"+sIPROPID+"~"+sIMID1+"~"+sIBASE+"~"+sIPARDLL+"~"+sIPAROBN
				+"~"+sIPKGCOL+"~"+sIOLCD01+"~"+sIOLCD02+"~"+sIOLCD03+"~"+sIOLCD04+"~"+sIOLCD05+"~"+sIPID+"~"+sIUSER+"~"+sIJOBN+"~"+sIUPMJ+"~"+sIUPMT;
	}

}
