package com.jnj.rqc.dbconfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.ext.DestinationDataProvider;


@Configuration
@PropertySource({ "classpath:config.properties" })
public class SapAppConfig {
	private static final Logger log = LoggerFactory.getLogger(SapAppConfig.class);
	@Autowired
	Environment environment;
	int minThreadPoolSize = 10;
	int maxThreadPoolSize = 15;


	/**
	 * Method  : AppConfig.java<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2019 3:43:57 PM
	 * Purpose :
	 * @return : ThreadPoolTaskExecutor
	 */
	@Bean
	public ThreadPoolTaskExecutor taskExecutorSap() {
		final ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
		try {
			minThreadPoolSize = Integer.parseInt(environment.getRequiredProperty("thread.pool.min"));
			maxThreadPoolSize = Integer.parseInt(environment.getRequiredProperty("thread.pool.max"));
		} catch (Exception e) {
			log.error("Could not get MIN/MAX values for ThreadPool Defaulting to min:"+minThreadPoolSize+" max:"+maxThreadPoolSize);
		}
		pool.setCorePoolSize(minThreadPoolSize);
		pool.setMaxPoolSize(maxThreadPoolSize);
		pool.setWaitForTasksToCompleteOnShutdown(true);
		return pool;
	}


	@Bean
	public JCoDestination destNA_SAPSANDBOX_Sandbox_R3P700() throws JCoException, IOException {
		String SB_DST ="NA_SAPSANDBOX_Sandbox_R3P700";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty("NA_SAPSANDBOX_Sandbox_R3P700.host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty("NA_SAPSANDBOX_Sandbox_R3P700.instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty("NA_SAPSANDBOX_Sandbox_R3P700.client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty("NA_SAPSANDBOX_Sandbox_R3P700.usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty("NA_SAPSANDBOX_Sandbox_R3P700.pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SB_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, "NA_SAPSANDBOX_Sandbox_R3P700");
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SB_DST);
		return destination;
	}

	// ATLAS - START

	@Bean
	public JCoDestination destNA_ATLAS_Production_ECCProductionRPVCLNT100() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_Production_ECCProductionRPVCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}
	//NA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000
	@Bean
	public JCoDestination destNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}


	@Bean
	public JCoDestination destNA_ATLAS_Production_APOProductionAPVCLNT100() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_Production_APOProductionAPVCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}


	@Bean
	public JCoDestination destNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}

	//NA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000
	@Bean
	public JCoDestination destNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}

	@Bean
	public JCoDestination destNA_ATLAS_Production_BIProductionBPVCLNT100() throws JCoException, IOException {
		String ATLAS_DST ="NA_ATLAS_Production_BIProductionBPVCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ATLAS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ATLAS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ATLAS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ATLAS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ATLAS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ATLAS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ATLAS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ATLAS_DST);
		return destination;
	}
	//ATLAS - END

	//BIOSENSE
	@Bean
	public JCoDestination destNA_BIOSENSE_Production_BWIILCLNT400() throws JCoException, IOException {
		String BIOSENSE_DST ="NA_BIOSENSE_Production_BWIILCLNT400";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BIOSENSE_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BIOSENSE_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BIOSENSE_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BIOSENSE_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BIOSENSE_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BIOSENSE_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BIOSENSE_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BIOSENSE_DST);
		return destination;
	}
	//BIOSENSE

	//USROTC -START
	// 1. MP2

	@Bean
	public JCoDestination destNA_USROTC_Production_ECCProductionMP2CLNT100() throws JCoException, IOException {
		String USROTC_DSTMP2 ="NA_USROTC_Production_ECCProductionMP2CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(USROTC_DSTMP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(USROTC_DSTMP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(USROTC_DSTMP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(USROTC_DSTMP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(USROTC_DSTMP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(USROTC_DSTMP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+USROTC_DSTMP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(USROTC_DSTMP2);
		return destination;
	}

	// 2. MP8
	@Bean
	public JCoDestination destNA_USROTC_Production_CRMProductionMP8CLNT100() throws JCoException, IOException {
		String USROTC_DSTMP8 ="NA_USROTC_Production_CRMProductionMP8CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(USROTC_DSTMP8+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(USROTC_DSTMP8+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(USROTC_DSTMP8+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(USROTC_DSTMP8+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(USROTC_DSTMP8+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(USROTC_DSTMP8 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+USROTC_DSTMP8);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(USROTC_DSTMP8);
		return destination;
	}

	//NA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000
	@Bean
	public JCoDestination destNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000() throws JCoException, IOException {
		String USROTC_DSTMP8 ="NA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(USROTC_DSTMP8+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(USROTC_DSTMP8+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(USROTC_DSTMP8+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(USROTC_DSTMP8+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(USROTC_DSTMP8+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(USROTC_DSTMP8 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+USROTC_DSTMP8);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(USROTC_DSTMP8);
		return destination;
	}

	//NA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000
	@Bean
	public JCoDestination destNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000() throws JCoException, IOException {
		String USROTC_DSTMP8 ="NA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(USROTC_DSTMP8+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(USROTC_DSTMP8+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(USROTC_DSTMP8+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(USROTC_DSTMP8+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(USROTC_DSTMP8+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(USROTC_DSTMP8 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+USROTC_DSTMP8);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(USROTC_DSTMP8);
		return destination;
	}

	//USROTC - END

	//CONCOURSE - START

	// 1. P23
	@Bean
	public JCoDestination destNA_Concourse_Production_ATTProductionP23CLNT100() throws JCoException, IOException {
		String CONCOURSE_DSTP23 ="NA_Concourse_Production_ATTProductionP23CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(CONCOURSE_DSTP23+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(CONCOURSE_DSTP23+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(CONCOURSE_DSTP23+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(CONCOURSE_DSTP23+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(CONCOURSE_DSTP23+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(CONCOURSE_DSTP23 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+CONCOURSE_DSTP23);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(CONCOURSE_DSTP23);
		return destination;
	}

	// 2. P24
	@Bean
	public JCoDestination destNA_Concourse_Production_ATTProductionP24CLNT100() throws JCoException, IOException {
		String CONCOURSE_DSTP24 ="NA_Concourse_Production_ATTProductionP24CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(CONCOURSE_DSTP24+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(CONCOURSE_DSTP24+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(CONCOURSE_DSTP24+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(CONCOURSE_DSTP24+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(CONCOURSE_DSTP24+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(CONCOURSE_DSTP24 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+CONCOURSE_DSTP24);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(CONCOURSE_DSTP24);
		return destination;
	}

	//NA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000
	@Bean
	public JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000() throws JCoException, IOException {
		String CONCOURSE_DSTP24 ="NA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(CONCOURSE_DSTP24+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(CONCOURSE_DSTP24+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(CONCOURSE_DSTP24+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(CONCOURSE_DSTP24+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(CONCOURSE_DSTP24+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(CONCOURSE_DSTP24 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+CONCOURSE_DSTP24);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(CONCOURSE_DSTP24);
		return destination;
	}

	//NA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000
	@Bean
	public JCoDestination destNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000() throws JCoException, IOException {
		String CONCOURSE_DSTP24 ="NA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(CONCOURSE_DSTP24+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(CONCOURSE_DSTP24+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(CONCOURSE_DSTP24+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(CONCOURSE_DSTP24+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(CONCOURSE_DSTP24+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(CONCOURSE_DSTP24 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+CONCOURSE_DSTP24);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(CONCOURSE_DSTP24);
		return destination;
	}

	//CONCOURSE - END

	// CROSSROAD - START
	// 1. RPU
	@Bean
	public JCoDestination destNA_CROSSROAD_Production_ECCProductionRPUCLNT100() throws JCoException, IOException {
		String XROAD_DSTRPU ="NA_CROSSROAD_Production_ECCProductionRPUCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(XROAD_DSTRPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(XROAD_DSTRPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(XROAD_DSTRPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(XROAD_DSTRPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(XROAD_DSTRPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(XROAD_DSTRPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+XROAD_DSTRPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(XROAD_DSTRPU);
		return destination;
	}

	//NA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000
	@Bean
	public JCoDestination destNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000() throws JCoException, IOException {
		String XROAD_DSTRPU ="NA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(XROAD_DSTRPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(XROAD_DSTRPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(XROAD_DSTRPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(XROAD_DSTRPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(XROAD_DSTRPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(XROAD_DSTRPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+XROAD_DSTRPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(XROAD_DSTRPU);
		return destination;
	}
	// CROSSROAD - END

	//BTBGLOBAL - START
	// 1.APU
	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300() throws JCoException, IOException {
		String BTB_DSTAPU ="NA_BTBGLOBAL_Production_SCMProductionAPUCLNT300";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTAPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTAPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTAPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTAPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTAPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTAPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTAPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTAPU);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000() throws JCoException, IOException {
		String BTB_DSTAPU ="NA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTAPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTAPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTAPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTAPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTAPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTAPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTAPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTAPU);
		return destination;
	}

	// 2. B3G

	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550() throws JCoException, IOException {
		String BTB_DSTB3G ="NA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTB3G+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTB3G+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTB3G+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTB3G+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTB3G+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTB3G + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTB3G);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTB3G);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000() throws JCoException, IOException {
		String BTB_DSTB3G ="NA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTB3G+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTB3G+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTB3G+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTB3G+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTB3G+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTB3G + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTB3G);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTB3G);
		return destination;
	}

	// 3. BPU
	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400() throws JCoException, IOException {
		String BTB_DSTBPU ="NA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTBPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTBPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTBPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTBPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTBPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTBPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTBPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTBPU);
		return destination;
	}

	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000() throws JCoException, IOException {
		String BTB_DSTBPU ="NA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTBPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTBPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTBPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTBPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTBPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTBPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTBPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTBPU);
		return destination;
	}

	// 4. NP2

	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650() throws JCoException, IOException {
		String BTB_DSTNP2 ="NA_BTBGLOBAL_Production_GTSProductionNP2CLNT650";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTNP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTNP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTNP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTNP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTNP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTNP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTNP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTNP2);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000() throws JCoException, IOException {
		String BTB_DSTNP2 ="NA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTNP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTNP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTNP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTNP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTNP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTNP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTNP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTNP2);
		return destination;
	}


	// 5. NP3
	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220() throws JCoException, IOException {
		String BTB_DSTNP3 ="NA_BTBGLOBAL_Production_SLTProductionNP3CLNT220";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTNP3+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTNP3+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTNP3+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTNP3+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTNP3+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTNP3 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTNP3);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTNP3);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000() throws JCoException, IOException {
		String BTB_DSTNP3 ="NA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTNP3+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTNP3+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTNP3+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTNP3+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTNP3+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTNP3 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTNP3);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTNP3);
		return destination;
	}


	// 6. P53

	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_MDGProductionP53CLNT750() throws JCoException, IOException {
		String BTB_DSTP53 ="NA_BTBGLOBAL_Production_MDGProductionP53CLNT750";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTP53+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTP53+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTP53+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTP53+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTP53+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTP53 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTP53);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTP53);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000() throws JCoException, IOException {
		String BTB_DSTP53 ="NA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTP53+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTP53+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTP53+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTP53+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTP53+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTP53 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTP53);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTP53);
		return destination;
	}


	// 7. RP3
	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600() throws JCoException, IOException {
		String BTB_DSTRP3 ="NA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTRP3+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTRP3+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTRP3+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTRP3+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTRP3+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTRP3 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTRP3);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTRP3);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000() throws JCoException, IOException {
		String BTB_DSTRP3 ="NA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTRP3+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTRP3+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTRP3+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTRP3+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTRP3+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTRP3 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTRP3);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTRP3);
		return destination;
	}





	// 8. XPU
	@Bean
	public JCoDestination destNA_BTBGLOBAL_Production_PIProductionXPUCLNT200() throws JCoException, IOException {
		String BTB_DSTXPU ="NA_BTBGLOBAL_Production_PIProductionXPUCLNT200";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTXPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTXPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTXPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTXPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTXPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTXPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTXPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTXPU);
		return destination;
	}

	//NA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000
	@Bean
	public JCoDestination destNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000() throws JCoException, IOException {
		String BTB_DSTXPU ="NA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTB_DSTXPU+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTB_DSTXPU+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTB_DSTXPU+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTB_DSTXPU+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTB_DSTXPU+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTB_DSTXPU + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTB_DSTXPU);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTB_DSTXPU);
		return destination;
	}

	//BTBGLOBAL - END

	//BTB LERCAN - START
	// 1. CRM
	@Bean
	public JCoDestination destNA_BTBLERCAN_Production_CRMProductionP51CLNT500() throws JCoException, IOException {
		String LER_DSTCRM ="NA_BTBLERCAN_Production_CRMProductionP51CLNT500";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LER_DSTCRM+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LER_DSTCRM+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LER_DSTCRM+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LER_DSTCRM+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LER_DSTCRM+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LER_DSTCRM + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LER_DSTCRM);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LER_DSTCRM);
		return destination;
	}


	// 2. ECC
	@Bean
	public JCoDestination destNA_BTBLERCAN_Production_ECCProductionP50CLNT100() throws JCoException, IOException {
		String LER_DSTECC ="NA_BTBLERCAN_Production_ECCProductionP50CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LER_DSTECC+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LER_DSTECC+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LER_DSTECC+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LER_DSTECC+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LER_DSTECC+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LER_DSTECC + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LER_DSTECC);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LER_DSTECC);
		return destination;
	}

	//NA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000
	@Bean
	public JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000() throws JCoException, IOException {
		String LER_DSTCRM ="NA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LER_DSTCRM+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LER_DSTCRM+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LER_DSTCRM+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LER_DSTCRM+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LER_DSTCRM+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LER_DSTCRM + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LER_DSTCRM);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LER_DSTCRM);
		return destination;
	}

	//NA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000
	@Bean
	public JCoDestination destNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000() throws JCoException, IOException {
		String LER_DSTCRM ="NA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LER_DSTCRM+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LER_DSTCRM+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LER_DSTCRM+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LER_DSTCRM+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LER_DSTCRM+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LER_DSTCRM + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LER_DSTCRM);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LER_DSTCRM);
		return destination;
	}

	//BTB LERCAN END

	// FUSION - START

	// 1. PR1
	@Bean
	public JCoDestination destNA_FUSION_Production_ECCProductionPR1CLNT100() throws JCoException, IOException {
		String FUSION_DSTPR1 ="NA_FUSION_Production_ECCProductionPR1CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPR1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPR1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPR1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPR1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPR1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPR1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPR1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPR1);
		return destination;
	}

	// 2. PC1
	@Bean
	public JCoDestination destNA_FUSION_Production_CRMProductionPC1CLNT100() throws JCoException, IOException {
		String FUSION_DSTPC1 ="NA_FUSION_Production_CRMProductionPC1CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPC1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPC1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPC1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPC1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPC1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPC1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPC1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPC1);
		return destination;
	}

	// 3. PB1
	@Bean
	public JCoDestination destNA_FUSION_Production_BWProductionPB1CLNT100() throws JCoException, IOException {
		String FUSION_DSTPB1 ="NA_FUSION_Production_BWProductionPB1CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPB1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPB1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPB1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPB1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPB1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPB1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPB1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPB1);
		return destination;
	}

	//NA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000
	@Bean
	public JCoDestination destNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000() throws JCoException, IOException {
		String FUSION_DSTPB1 ="NA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPB1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPB1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPB1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPB1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPB1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPB1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPB1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPB1);
		return destination;
	}

	//NA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000
	@Bean
	public JCoDestination destNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000() throws JCoException, IOException {
		String FUSION_DSTPB1 ="NA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPB1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPB1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPB1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPB1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPB1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPB1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPB1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPB1);
		return destination;
	}


	//NA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000
	@Bean
	public JCoDestination destNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000() throws JCoException, IOException {
		String FUSION_DSTPB1 ="NA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(FUSION_DSTPB1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(FUSION_DSTPB1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(FUSION_DSTPB1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(FUSION_DSTPB1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(FUSION_DSTPB1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(FUSION_DSTPB1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+FUSION_DSTPB1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(FUSION_DSTPB1);
		return destination;
	}


	//FUSION - END


	//GLOBAL SOLMAN
	// 1. PROD

	@Bean
	public JCoDestination destNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230() throws JCoException, IOException {
		String GSLMPRD_DST ="NA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GSLMPRD_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GSLMPRD_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GSLMPRD_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GSLMPRD_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GSLMPRD_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GSLMPRD_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GSLMPRD_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GSLMPRD_DST);
		return destination;
	}

	// 2. Tech Clients
	@Bean
	public JCoDestination destNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000() throws JCoException, IOException {
		String GSLMTC_DST ="NA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GSLMTC_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GSLMTC_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GSLMTC_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GSLMTC_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GSLMTC_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GSLMTC_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GSLMTC_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GSLMTC_DST);
		return destination;
	}

	// GLOBAL SOLMAN - END

	// JJSV - START
	// 1. PA2
	@Bean
	public JCoDestination destNA_JJSV_Production_ECCProductionPA2CLNT050() throws JCoException, IOException {
		String JJSV_DSTPA2 ="NA_JJSV_Production_ECCProductionPA2CLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTPA2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTPA2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTPA2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTPA2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTPA2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTPA2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTPA2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTPA2);
		return destination;
	}

	// 2. APP
	@Bean
	public JCoDestination destNA_JJSV_Production_SCMProductionAPPCLNT050() throws JCoException, IOException {
		String JJSV_DSTAPP ="NA_JJSV_Production_SCMProductionAPPCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTAPP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTAPP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTAPP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTAPP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTAPP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTAPP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTAPP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTAPP);
		return destination;
	}
	// 3. BWP
	@Bean
	public JCoDestination destNA_JJSV_Production_BWProductionBWPCLNT050() throws JCoException, IOException {
		String JJSV_DSTBWP ="NA_JJSV_Production_BWProductionBWPCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTBWP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTBWP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTBWP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTBWP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTBWP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTBWP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTBWP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTBWP);
		return destination;
	}

	//NA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000
	@Bean
	public JCoDestination destNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000() throws JCoException, IOException {
		String JJSV_DSTBWP ="NA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTBWP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTBWP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTBWP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTBWP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTBWP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTBWP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTBWP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTBWP);
		return destination;
	}

	//NA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000
	@Bean
	public JCoDestination destNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000() throws JCoException, IOException {
		String JJSV_DSTBWP ="NA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTBWP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTBWP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTBWP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTBWP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTBWP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTBWP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTBWP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTBWP);
		return destination;
	}

	//NA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000
	@Bean
	public JCoDestination destNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000() throws JCoException, IOException {
		String JJSV_DSTBWP ="NA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(JJSV_DSTBWP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(JJSV_DSTBWP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(JJSV_DSTBWP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(JJSV_DSTBWP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(JJSV_DSTBWP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(JJSV_DSTBWP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+JJSV_DSTBWP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(JJSV_DSTBWP);
		return destination;
	}

	// JJSV - END

	//ANSPACH

	@Bean
	public JCoDestination destNA_ANSPACH_Production_ECCProductionR3PCLNT700() throws JCoException, IOException {
		String ANSPACH_DST ="NA_ANSPACH_Production_ECCProductionR3PCLNT700";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ANSPACH_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ANSPACH_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ANSPACH_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ANSPACH_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ANSPACH_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ANSPACH_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ANSPACH_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ANSPACH_DST);
		return destination;
	}

	//NA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000
	@Bean
	public JCoDestination destNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000() throws JCoException, IOException {
		String ANSPACH_DST ="NA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(ANSPACH_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(ANSPACH_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(ANSPACH_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(ANSPACH_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(ANSPACH_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(ANSPACH_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+ANSPACH_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(ANSPACH_DST);
		return destination;
	}

	//LYNX - START
	// 1. MP1
	@Bean
	public JCoDestination destNA_LYNX_Production_ECCProductionMP1CLNT010() throws JCoException, IOException {
		String LYNX_DSTMP1 ="NA_LYNX_Production_ECCProductionMP1CLNT010";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTMP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTMP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTMP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTMP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTMP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTMP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTMP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTMP1);
		return destination;
	}

	// 2. GP5
	@Bean
	public JCoDestination destNA_LYNX_Production_BIProductionGP5CLNT010() throws JCoException, IOException {
		String LYNX_DSTGP5 ="NA_LYNX_Production_BIProductionGP5CLNT010";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTGP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTGP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTGP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTGP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTGP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTGP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTGP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTGP5);
		return destination;
	}

	// 3. FP3
	@Bean
	public JCoDestination destNA_LYNX_Production_ECCProductionFP3CLNT010() throws JCoException, IOException {
		String LYNX_DSTFP3 ="NA_LYNX_Production_ECCProductionFP3CLNT010";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP3+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP3+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP3+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP3+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP3+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP3 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP3);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP3);
		return destination;
	}


	// 4. FP5
	@Bean
	public JCoDestination destNA_LYNX_Production_BIProductionFP5CLNT010() throws JCoException, IOException {
		String LYNX_DSTFP5 ="NA_LYNX_Production_BIProductionFP5CLNT010";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP5);
		return destination;
	}

	//NA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000
	@Bean
	public JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000() throws JCoException, IOException {
		String LYNX_DSTFP5 ="NA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP5);
		return destination;
	}

	//NA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000
	@Bean
	public JCoDestination destNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000() throws JCoException, IOException {
		String LYNX_DSTFP5 ="NA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP5);
		return destination;
	}

	//NA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000
	@Bean
	public JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000() throws JCoException, IOException {
		String LYNX_DSTFP5 ="NA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP5);
		return destination;
	}
	//NA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000
	@Bean
	public JCoDestination destNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000() throws JCoException, IOException {
		String LYNX_DSTFP5 ="NA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(LYNX_DSTFP5+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(LYNX_DSTFP5+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(LYNX_DSTFP5+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(LYNX_DSTFP5+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(LYNX_DSTFP5+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(LYNX_DSTFP5 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+LYNX_DSTFP5);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(LYNX_DSTFP5);
		return destination;
	}

	//LYNX - END

	//MERCURY - Production -STARTS
	// 1. SPN
	@Bean
	public JCoDestination destNA_MERCURY_Production_SCMProductionSPNCLNT400() throws JCoException, IOException {
		String MERCURY_DSTSPN ="NA_MERCURY_Production_SCMProductionSPNCLNT400";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTSPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTSPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTSPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTSPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTSPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTSPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTSPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTSPN);
		return destination;
	}

	// 2. RPN
	@Bean
	public JCoDestination destNA_MERCURY_Production_ECCProductionRPNCLNT120() throws JCoException, IOException {
		String MERCURY_DSTRPN ="NA_MERCURY_Production_ECCProductionRPNCLNT120";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTRPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTRPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTRPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTRPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTRPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTRPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTRPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTRPN);
		return destination;
	}

	// 3. BPN
	@Bean
	public JCoDestination destNA_MERCURY_Production_BWProductionBPNCLNT300() throws JCoException, IOException {
		String MERCURY_DSTBPN ="NA_MERCURY_Production_BWProductionBPNCLNT300";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTBPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTBPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTBPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTBPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTBPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTBPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTBPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTBPN);
		return destination;
	}

	// 4. XPN
	@Bean
	public JCoDestination destNA_MERCURY_Production_PIProductionXPNCLNT200() throws JCoException, IOException {
		String MERCURY_DSTXPN ="NA_MERCURY_Production_PIProductionXPNCLNT200";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTXPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTXPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTXPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTXPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTXPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTXPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTXPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTXPN);
		return destination;
	}

	//NA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000
	@Bean
	public JCoDestination destNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000() throws JCoException, IOException {
		String MERCURY_DSTXPN ="NA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTXPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTXPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTXPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTXPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTXPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTXPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTXPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTXPN);
		return destination;
	}

	//NA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000
	@Bean
	public JCoDestination destNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000() throws JCoException, IOException {
		String MERCURY_DSTXPN ="NA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTXPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTXPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTXPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTXPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTXPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTXPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTXPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTXPN);
		return destination;
	}

	//NA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000
	@Bean
	public JCoDestination destNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000() throws JCoException, IOException {
		String MERCURY_DSTXPN ="NA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTXPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTXPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTXPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTXPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTXPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTXPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTXPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTXPN);
		return destination;
	}

	//NA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000
	@Bean
	public JCoDestination destNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000() throws JCoException, IOException {
		String MERCURY_DSTXPN ="NA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MERCURY_DSTXPN+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MERCURY_DSTXPN+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MERCURY_DSTXPN+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MERCURY_DSTXPN+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MERCURY_DSTXPN+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MERCURY_DSTXPN + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MERCURY_DSTXPN);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MERCURY_DSTXPN);
		return destination;
	}

	//MERCURY - Production -END

	// MITEK - START
	@Bean
	public JCoDestination destNA_MITEK_Production_ECCProductionRPOCLNT777() throws JCoException, IOException {
		String MITEK_DST ="NA_MITEK_Production_ECCProductionRPOCLNT777";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MITEK_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MITEK_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MITEK_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MITEK_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MITEK_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MITEK_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MITEK_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MITEK_DST);
		return destination;
	}

	//NA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000
	@Bean
	public JCoDestination destNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000() throws JCoException, IOException {
		String MITEK_DST ="NA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MITEK_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MITEK_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MITEK_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MITEK_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MITEK_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MITEK_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MITEK_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MITEK_DST);
		return destination;
	}

	// MITEK - END

	//OURSOURCE - START

	// 1. PJ1
	@Bean
	public JCoDestination destNA_OURSOURCE_Production_ECCProductionPJ1CLNT280() throws JCoException, IOException {
		String OURSOURCE_DSTPJ1 ="NA_OURSOURCE_Production_ECCProductionPJ1CLNT280";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(OURSOURCE_DSTPJ1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+OURSOURCE_DSTPJ1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ1);
		return destination;
	}

	// 2. PJ2
		@Bean
		public JCoDestination destNA_OURSOURCE_Production_NGWProductionPJ2CLNT280() throws JCoException, IOException {
			String OURSOURCE_DSTPJ2 ="NA_OURSOURCE_Production_NGWProductionPJ2CLNT280";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ2+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ2+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ2+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ2+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ2+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(OURSOURCE_DSTPJ2 + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+OURSOURCE_DSTPJ2);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ2);
			return destination;
		}

		// 2. PJ5
		@Bean
		public JCoDestination destNA_OURSOURCE_Production_BIProductionPJ5CLNT280() throws JCoException, IOException {
			String OURSOURCE_DSTPJ5 ="NA_OURSOURCE_Production_BIProductionPJ5CLNT280";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(OURSOURCE_DSTPJ5 + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+OURSOURCE_DSTPJ5);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ5);
			return destination;
		}

		//NA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000
		@Bean
		public JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000() throws JCoException, IOException {
			String OURSOURCE_DSTPJ5 ="NA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(OURSOURCE_DSTPJ5 + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+OURSOURCE_DSTPJ5);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ5);
			return destination;
		}

		//NA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000
		@Bean
		public JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000() throws JCoException, IOException {
			String OURSOURCE_DSTPJ5 ="NA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(OURSOURCE_DSTPJ5 + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+OURSOURCE_DSTPJ5);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ5);
			return destination;
		}

		//NA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000
		@Bean
		public JCoDestination destNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000() throws JCoException, IOException {
			String OURSOURCE_DSTPJ5 ="NA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(OURSOURCE_DSTPJ5+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(OURSOURCE_DSTPJ5 + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+OURSOURCE_DSTPJ5);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(OURSOURCE_DSTPJ5);
			return destination;
		}
	//OURSOURCE - END

	//LATAM_LATAMPROJECTONE - START
	// 1. PJ5
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520() throws JCoException, IOException {
		String PROJECTONE_DSTPAP ="LATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPAP+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPAP+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPAP+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPAP+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPAP+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPAP + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPAP);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPAP);
		return destination;
	}

	// 2. PBW
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620() throws JCoException, IOException {
		String PROJECTONE_DSTPBW ="LATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPBW+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPBW+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPBW+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPBW+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPBW+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPBW + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPBW);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPBW);
		return destination;
	}

	// 2. PLA
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120() throws JCoException, IOException {
		String PROJECTONE_DSTPLA ="LATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPLA+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPLA+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPLA+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPLA+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPLA+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPLA + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPLA);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPLA);
		return destination;
	}

	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000() throws JCoException, IOException {
		String PROJECTONE_DSTPLA ="LATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPLA+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPLA+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPLA+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPLA+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPLA+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPLA + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPLA);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPLA);
		return destination;
	}
	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000() throws JCoException, IOException {
		String PROJECTONE_DSTPLA ="LATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPLA+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPLA+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPLA+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPLA+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPLA+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPLA + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPLA);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPLA);
		return destination;
	}
	//LATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000
	@Bean
	public JCoDestination destLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000() throws JCoException, IOException {
		String PROJECTONE_DSTPLA ="LATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PROJECTONE_DSTPLA+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PROJECTONE_DSTPLA+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PROJECTONE_DSTPLA+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PROJECTONE_DSTPLA+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PROJECTONE_DSTPLA+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PROJECTONE_DSTPLA + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PROJECTONE_DSTPLA);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PROJECTONE_DSTPLA);
		return destination;
	}
	//LATAM_LATAMPROJECTONE - END

	//BTBLATAM - START
	// 1.CPG
	@Bean
	public JCoDestination destLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500() throws JCoException, IOException {
		String BTBLATAM_DSTCPG ="LATAM_BTBLATAM_Production_CRMProductionCPGCLNT500";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTCPG+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTCPG+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTCPG+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTCPG+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTCPG+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTCPG + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTCPG);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTCPG);
		return destination;
	}

	// 2. RPG
	@Bean
	public JCoDestination destLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100() throws JCoException, IOException {
		String BTBLATAM_DSTRPG ="LATAM_BTBLATAM_Production_ECCProductionRPGCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTRPG+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTRPG+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTRPG+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTRPG+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTRPG+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTRPG + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTRPG);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTRPG);
		return destination;
	}

	// 3. XP2
	@Bean
	public JCoDestination destLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300() throws JCoException, IOException {
		String BTBLATAM_DSTXP2 ="LATAM_BTBLATAM_Production_NFEProductionXP2CLNT300";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTXP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTXP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTXP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTXP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTXP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTXP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTXP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTXP2);
		return destination;
	}

	//LATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000
	@Bean
	public JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000() throws JCoException, IOException {
		String BTBLATAM_DSTXP2 ="LATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTXP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTXP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTXP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTXP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTXP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTXP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTXP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTXP2);
		return destination;
	}
	//LATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000
	@Bean
	public JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000() throws JCoException, IOException {
		String BTBLATAM_DSTXP2 ="LATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTXP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTXP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTXP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTXP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTXP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTXP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTXP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTXP2);
		return destination;
	}
	//LATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000
	@Bean
	public JCoDestination destLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000() throws JCoException, IOException {
		String BTBLATAM_DSTXP2 ="LATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBLATAM_DSTXP2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBLATAM_DSTXP2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBLATAM_DSTXP2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBLATAM_DSTXP2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBLATAM_DSTXP2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBLATAM_DSTXP2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBLATAM_DSTXP2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBLATAM_DSTXP2);
		return destination;
	}
	//BTBLATAM - END

	//ASPAC - START
	//ASPAC_SYNTHES_Production_ECCProductionMBPCLNT600
	@Bean
	public JCoDestination destASPAC_SYNTHES_Production_ECCProductionMBPCLNT600() throws JCoException, IOException {
		String SYN_DST ="ASPAC_SYNTHES_Production_ECCProductionMBPCLNT600";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}

	//ASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000
	@Bean
	public JCoDestination destASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000() throws JCoException, IOException {
		String SYN_DST ="ASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}


	//BTBJAPAN
	@Bean
	public JCoDestination destASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100() throws JCoException, IOException {
		String BTBJAPAN_DSTP60 ="ASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(BTBJAPAN_DSTP60+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(BTBJAPAN_DSTP60+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(BTBJAPAN_DSTP60+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(BTBJAPAN_DSTP60+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(BTBJAPAN_DSTP60+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(BTBJAPAN_DSTP60 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+BTBJAPAN_DSTP60);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(BTBJAPAN_DSTP60);
		return destination;
	}

	//ConsumerASPAC
	// 1. APW
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888() throws JCoException, IOException {
		String Cons_DSTAPW ="ASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTAPW+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTAPW+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTAPW+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTAPW+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTAPW+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTAPW + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTAPW);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTAPW);
		return destination;
	}

	// 2. PW1
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100() throws JCoException, IOException {
		String Cons_DSTPW1 ="ASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTPW1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTPW1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTPW1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTPW1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTPW1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTPW1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTPW1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTPW1);
		return destination;
	}


	// 3. P00
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888() throws JCoException, IOException {
		String Cons_DSTP00 ="ASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTP00+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTP00+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTP00+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTP00+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTP00+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTP00 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTP00);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTP00);
		return destination;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000() throws JCoException, IOException {
		String Cons_DSTP00 ="ASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTP00+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTP00+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTP00+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTP00+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTP00+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTP00 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTP00);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTP00);
		return destination;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000() throws JCoException, IOException {
		String Cons_DSTP00 ="ASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTP00+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTP00+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTP00+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTP00+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTP00+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTP00 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTP00);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTP00);
		return destination;
	}

	//ASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000
	@Bean
	public JCoDestination destASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000() throws JCoException, IOException {
		String Cons_DSTP00 ="ASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(Cons_DSTP00+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(Cons_DSTP00+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(Cons_DSTP00+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(Cons_DSTP00+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(Cons_DSTP00+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(Cons_DSTP00 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+Cons_DSTP00);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(Cons_DSTP00);
		return destination;
	}




	//MARS
	@Bean
	public JCoDestination destASPAC_MARS_Production_ECCProductionEJ1CLNT100() throws JCoException, IOException {
		String MARS_DST ="ASPAC_MARS_Production_ECCProductionEJ1CLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MARS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MARS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MARS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MARS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MARS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MARS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MARS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MARS_DST);
		return destination;
	}

	//ASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000
	@Bean
	public JCoDestination destASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000() throws JCoException, IOException {
		String MARS_DST ="ASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(MARS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(MARS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(MARS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(MARS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(MARS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(MARS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+MARS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(MARS_DST);
		return destination;
	}

	//Panda

	// 1. BP1
	@Bean
	public JCoDestination destASPAC_Panda_Production_BIProductionBP1CLNT600() throws JCoException, IOException {
		String PANDA_DSTBP1 ="ASPAC_Panda_Production_BIProductionBP1CLNT600";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTBP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTBP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTBP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTBP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTBP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTBP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTBP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTBP1);
		return destination;
	}

	// 2. EP1
	@Bean
	public JCoDestination destASPAC_Panda_Production_ECCProductionEP1CLNT800() throws JCoException, IOException {
		String PANDA_DSTEP1 ="ASPAC_Panda_Production_ECCProductionEP1CLNT800";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTEP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTEP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTEP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTEP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTEP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTEP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTEP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTEP1);
		return destination;
	}

	// 3. XP1
	@Bean
	public JCoDestination destASPAC_Panda_Production_PIProductionXP1CLNT800() throws JCoException, IOException {
		String PANDA_DSTXP1 ="ASPAC_Panda_Production_PIProductionXP1CLNT800";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTXP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTXP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTXP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTXP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTXP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTXP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTXP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTXP1);
		return destination;
	}


	@Bean
	public JCoDestination destASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000() throws JCoException, IOException {
		String PANDA_DSTXP1 ="ASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTXP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTXP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTXP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTXP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTXP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTXP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTXP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTXP1);
		return destination;
	}


	@Bean
	public JCoDestination destASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000() throws JCoException, IOException {
		String PANDA_DSTXP1 ="ASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTXP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTXP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTXP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTXP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTXP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTXP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTXP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTXP1);
		return destination;
	}

	//ASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000
	@Bean
	public JCoDestination destASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000() throws JCoException, IOException {
		String PANDA_DSTXP1 ="ASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PANDA_DSTXP1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PANDA_DSTXP1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PANDA_DSTXP1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PANDA_DSTXP1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PANDA_DSTXP1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(PANDA_DSTXP1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+PANDA_DSTXP1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(PANDA_DSTXP1);
		return destination;
	}


	//TAISHAN
	@Bean
	public JCoDestination destASPAC_Taishan_Production_ECCProductionRPDCLNT800() throws JCoException, IOException {
		String TAISHAN_DST ="ASPAC_Taishan_Production_ECCProductionRPDCLNT800";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(TAISHAN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(TAISHAN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(TAISHAN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(TAISHAN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(TAISHAN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(TAISHAN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+TAISHAN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(TAISHAN_DST);
		return destination;
	}

	//ASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000
	@Bean
	public JCoDestination destASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000() throws JCoException, IOException {
		String TAISHAN_DST ="ASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(TAISHAN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(TAISHAN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(TAISHAN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(TAISHAN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(TAISHAN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(TAISHAN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+TAISHAN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(TAISHAN_DST);
		return destination;
	}

	//ASPAC - END

	// EMEA - START

	//EUROPE2 -APE
	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_APOProductionAPECLNT050() throws JCoException, IOException {
		String EUROPE2_DSTAPE ="EMEA_EUROPE2_Production_APOProductionAPECLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTAPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTAPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTAPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTAPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTAPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTAPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTAPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTAPE);
		return destination;
	}

	//EUROPE2 -BPE
	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_BIProductionBPECLNT050() throws JCoException, IOException {
		String EUROPE2_DSTBPE ="EMEA_EUROPE2_Production_BIProductionBPECLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTBPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTBPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTBPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTBPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTBPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTBPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTBPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTBPE);
		return destination;
	}

	//EUROPE2 -BPI
	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_FSFProductionBPICLNT050() throws JCoException, IOException {
		String EUROPE2_DSTBPI ="EMEA_EUROPE2_Production_FSFProductionBPICLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTBPI+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTBPI+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTBPI+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTBPI+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTBPI+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTBPI + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTBPI);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTBPI);
		return destination;
	}

	//EUROPE2 -OPJ
	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_EWMProductionQPJCLNT050() throws JCoException, IOException {
		String EUROPE2_DSTOPJ ="EMEA_EUROPE2_Production_EWMProductionQPJCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTOPJ+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTOPJ+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTOPJ+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTOPJ+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTOPJ+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTOPJ + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTOPJ);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTOPJ);
		return destination;
	}

	//EUROPE2 -RPE
	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_ECCProductionRPECLNT050() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_Production_ECCProductionRPECLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}


	@Bean
	public JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000() throws JCoException, IOException {
		String EUROPE2_DSTRPE ="EMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_DSTRPE+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_DSTRPE+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_DSTRPE+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_DSTRPE+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_DSTRPE+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_DSTRPE + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_DSTRPE);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_DSTRPE);
		return destination;
	}


	@Bean
	public JCoDestination destEMEA_EUROPE2_Production_EWMProductionPJECLNT050() throws JCoException, IOException {
		String EUROPE2_EWM ="EMEA_EUROPE2_Production_EWMProductionPJECLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(EUROPE2_EWM+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(EUROPE2_EWM+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(EUROPE2_EWM+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(EUROPE2_EWM+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(EUROPE2_EWM+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(EUROPE2_EWM + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+EUROPE2_EWM);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(EUROPE2_EWM);
		return destination;
	}


	//Galaxy
	//BPM
	@Bean
	public JCoDestination destEMEA_Galaxy_Production_BIProductionBPMCLNT172() throws JCoException, IOException {
		String GALAXY_DSTBPM ="EMEA_Galaxy_Production_BIProductionBPMCLNT172";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GALAXY_DSTBPM+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GALAXY_DSTBPM+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GALAXY_DSTBPM+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GALAXY_DSTBPM+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GALAXY_DSTBPM+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GALAXY_DSTBPM + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GALAXY_DSTBPM);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GALAXY_DSTBPM);
		return destination;
	}

	//RPM1
	@Bean
	public JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT232() throws JCoException, IOException {
		String GALAXY_DSTRPM1 ="EMEA_Galaxy_Production_ECCProductionRPMCLNT232";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GALAXY_DSTRPM1+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GALAXY_DSTRPM1+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GALAXY_DSTRPM1+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GALAXY_DSTRPM1+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GALAXY_DSTRPM1+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GALAXY_DSTRPM1 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GALAXY_DSTRPM1);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GALAXY_DSTRPM1);
		return destination;
	}

	//RPM2
	@Bean
	public JCoDestination destEMEA_Galaxy_Production_ECCProductionRPMCLNT050() throws JCoException, IOException {
		String GALAXY_DSTRPM2 ="EMEA_Galaxy_Production_ECCProductionRPMCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GALAXY_DSTRPM2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GALAXY_DSTRPM2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GALAXY_DSTRPM2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GALAXY_DSTRPM2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GALAXY_DSTRPM2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GALAXY_DSTRPM2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GALAXY_DSTRPM2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GALAXY_DSTRPM2);
		return destination;
	}


	@Bean
	public JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000() throws JCoException, IOException {
		String GALAXY_DSTRPM2 ="EMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GALAXY_DSTRPM2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GALAXY_DSTRPM2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GALAXY_DSTRPM2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GALAXY_DSTRPM2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GALAXY_DSTRPM2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GALAXY_DSTRPM2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GALAXY_DSTRPM2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GALAXY_DSTRPM2);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000() throws JCoException, IOException {
		String GALAXY_DSTRPM2 ="EMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GALAXY_DSTRPM2+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GALAXY_DSTRPM2+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GALAXY_DSTRPM2+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GALAXY_DSTRPM2+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GALAXY_DSTRPM2+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GALAXY_DSTRPM2 + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GALAXY_DSTRPM2);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GALAXY_DSTRPM2);
		return destination;
	}

	//GMED
	@Bean
	public JCoDestination destEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050() throws JCoException, IOException {
		String GMED_DST ="EMEA_GMED_Production_EWMCourcellesProductionP28CLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GMED_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GMED_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GMED_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GMED_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GMED_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GMED_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GMED_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GMED_DST);
		return destination;
	}


	@Bean
	public JCoDestination destEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000() throws JCoException, IOException {
		String GMED_DST ="EMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(GMED_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(GMED_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(GMED_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(GMED_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(GMED_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(GMED_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+GMED_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(GMED_DST);
		return destination;
	}
	//IML

	//B3T
	@Bean
	public JCoDestination destEMEA_ILM_Production_BIProductionB3TCLNT050() throws JCoException, IOException {
		String IML_DSTB3T ="EMEA_ILM_Production_BIProductionB3TCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTB3T+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTB3T+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTB3T+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTB3T+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTB3T+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTB3T + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTB3T);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTB3T);
		return destination;
	}

		//B4T
		@Bean
		public JCoDestination destEMEA_ILM_Production_BIProductionB4TCLNT050() throws JCoException, IOException {
			String IML_DSTB4T ="EMEA_ILM_Production_BIProductionB4TCLNT050";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTB4T+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTB4T+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTB4T+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTB4T+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTB4T+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(IML_DSTB4T + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+IML_DSTB4T);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTB4T);
			return destination;
		}

		//BPT
		@Bean
		public JCoDestination destEMEA_ILM_Production_BIProductionBPTCLNT050() throws JCoException, IOException {
			String IML_DSTBPT ="EMEA_ILM_Production_BIProductionBPTCLNT050";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTBPT+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTBPT+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTBPT+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTBPT+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTBPT+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(IML_DSTBPT + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+IML_DSTBPT);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTBPT);
			return destination;
		}

		//R3T
		@Bean
		public JCoDestination destEMEA_ILM_Production_ECCProductionR3TCLNT050() throws JCoException, IOException {
			String IML_DSTR3T ="EMEA_ILM_Production_ECCProductionR3TCLNT050";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTR3T+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTR3T+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTR3T+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTR3T+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTR3T+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(IML_DSTR3T + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+IML_DSTR3T);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTR3T);
			return destination;
		}

	//R4T
	@Bean
	public JCoDestination destEMEA_ILM_Production_ECCProductionR4TCLNT050() throws JCoException, IOException {
		String IML_DSTR4T ="EMEA_ILM_Production_ECCProductionR4TCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTR4T+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTR4T+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTR4T+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTR4T+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTR4T+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTR4T + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTR4T);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTR4T);
		return destination;
	}

	//RPT
	@Bean
	public JCoDestination destEMEA_ILM_Production_ECCProductionRPTCLNT050() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_Production_ECCProductionRPTCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}


	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	@Bean
	public JCoDestination destEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000() throws JCoException, IOException {
		String IML_DSTRPT ="EMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(IML_DSTRPT+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(IML_DSTRPT+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(IML_DSTRPT+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(IML_DSTRPT+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(IML_DSTRPT+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(IML_DSTRPT + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+IML_DSTRPT);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(IML_DSTRPT);
		return destination;
	}

	//SNC
	@Bean
	public JCoDestination destEMEA_SNC_Production_SNCProductionQPECLNT050() throws JCoException, IOException {
		String SNC_DST ="EMEA_SNC_Production_SNCProductionQPECLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SNC_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SNC_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SNC_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SNC_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SNC_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SNC_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SNC_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SNC_DST);
		return destination;
	}

	//EMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000
	@Bean
	public JCoDestination destEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000() throws JCoException, IOException {
		String SNC_DST ="EMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SNC_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SNC_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SNC_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SNC_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SNC_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SNC_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SNC_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SNC_DST);
		return destination;
	}
	//STF - START
	//EMEA_STF_Production_APOProductionAPCCLNT430
	@Bean
	public JCoDestination destEMEA_STF_Production_APOProductionAPCCLNT430() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_APOProductionAPCCLNT430";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_BIProductionBPCCLNT330
	@Bean
	public JCoDestination destEMEA_STF_Production_BIProductionBPCCLNT330() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_BIProductionBPCCLNT330";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_CRMProductionCPCCLNT100
	@Bean
	public JCoDestination destEMEA_STF_Production_CRMProductionCPCCLNT100() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_CRMProductionCPCCLNT100";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_MDGProductionOPCCLNT050
	@Bean
	public JCoDestination destEMEA_STF_Production_MDGProductionOPCCLNT050() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_MDGProductionOPCCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_NetweaverGatewayProductionP05CLNT050
	@Bean
	public JCoDestination destEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_NetweaverGatewayProductionP05CLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_ECCProductionRPCCLNT130
	@Bean
	public JCoDestination destEMEA_STF_Production_ECCProductionRPCCLNT130() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_ECCProductionRPCCLNT130";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_Production_PIProductionXPGCLNT050
	@Bean
	public JCoDestination destEMEA_STF_Production_PIProductionXPGCLNT050() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_Production_PIProductionXPGCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//EMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}
	//EMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000
	@Bean
	public JCoDestination destEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000() throws JCoException, IOException {
		String STF_DST ="EMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(STF_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(STF_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(STF_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(STF_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(STF_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(STF_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+STF_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(STF_DST);
		return destination;
	}

	//STF - END

	//SUSTAIN
	//SANDBOX : EMEA_Sustain_Sandbox_RSB910
	@Bean
	public JCoDestination destEMEA_Sustain_Sandbox_RSB910() throws JCoException, IOException {
		String SUS_DST ="EMEA_Sustain_Sandbox_RSB910";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SUS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SUS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SUS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SUS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SUS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SUS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SUS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SUS_DST);
		return destination;
	}

	//EMEA_Sustain_Production_BIProductionBPBCLNT050
	@Bean
	public JCoDestination destEMEA_Sustain_Production_BIProductionBPBCLNT050() throws JCoException, IOException {
		String SUS_DST ="EMEA_Sustain_Production_BIProductionBPBCLNT050";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SUS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SUS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SUS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SUS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SUS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SUS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SUS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SUS_DST);
		return destination;
	}

	//EMEA_Sustain_Production_ECCProductionRPBCLNT910
	@Bean
	public JCoDestination destEMEA_Sustain_Production_ECCProductionRPBCLNT910() throws JCoException, IOException {
		String SUS_DST ="EMEA_Sustain_Production_ECCProductionRPBCLNT910";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SUS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SUS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SUS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SUS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SUS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SUS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SUS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SUS_DST);
		return destination;
	}

	//EMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000
	@Bean
	public JCoDestination destEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000() throws JCoException, IOException {
		String SUS_DST ="EMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SUS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SUS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SUS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SUS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SUS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SUS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SUS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SUS_DST);
		return destination;
	}
	//EMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000
	@Bean
	public JCoDestination destEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000() throws JCoException, IOException {
		String SUS_DST ="EMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SUS_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SUS_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SUS_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SUS_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SUS_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SUS_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SUS_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SUS_DST);
		return destination;
	}

	//SYMPHONY
	//EMEA_SYMPHONY_Production_ECCProductionP30CLNT200
	@Bean
	public JCoDestination destEMEA_SYMPHONY_Production_ECCProductionP30CLNT200() throws JCoException, IOException {
		String SYMPHONY_DST ="EMEA_SYMPHONY_Production_ECCProductionP30CLNT200";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYMPHONY_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYMPHONY_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYMPHONY_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYMPHONY_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYMPHONY_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYMPHONY_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYMPHONY_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYMPHONY_DST);
		return destination;
	}

	//EMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000
	@Bean
	public JCoDestination destEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000() throws JCoException, IOException {
		String SYMPHONY_DST ="EMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYMPHONY_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYMPHONY_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYMPHONY_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYMPHONY_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYMPHONY_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYMPHONY_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYMPHONY_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYMPHONY_DST);
		return destination;
	}

	//SYNTHES
	//EMEA_SYNTHES_Production_GRCProductionACPCLNT001
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_GRCProductionACPCLNT001() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_GRCProductionACPCLNT001";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_Production_BIProductionBIPCLNT020
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_BIProductionBIPCLNT020() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_BIProductionBIPCLNT020";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}

	//EMEA_SYNTHES_Production_GTSProductionGTPCLNT001
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_GTSProductionGTPCLNT001() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_GTSProductionGTPCLNT001";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}


	//EMEA_SYNTHES_Production_ECCProductionP01CLNT020
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_ECCProductionP01CLNT020() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_ECCProductionP01CLNT020";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}

	//EMEA_SYNTHES_Production_SOLMANProductionS01CLNT001
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_SOLMANProductionS01CLNT001";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_Production_ECCProductionMBPCLNT600
	@Bean
	public JCoDestination destEMEA_SYNTHES_Production_ECCProductionMBPCLNT600() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_Production_ECCProductionMBPCLNT600";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000
	@Bean
	public JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000
	@Bean
	public JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000
	@Bean
	public JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000
	@Bean
	public JCoDestination destASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000() throws JCoException, IOException {
		String SYN_DST ="ASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000
	@Bean
	public JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}
	//EMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000
	@Bean
	public JCoDestination destEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000() throws JCoException, IOException {
		String SYN_DST ="EMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(SYN_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(SYN_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(SYN_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(SYN_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(SYN_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(SYN_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+SYN_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(SYN_DST);
		return destination;
	}

	//VDR
	//EMEA_VDR_Production_ECCProductionFRPCLNT382
	@Bean
	public JCoDestination destEMEA_VDR_Production_ECCProductionFRPCLNT382() throws JCoException, IOException {
		String VDR_DST ="EMEA_VDR_Production_ECCProductionFRPCLNT382";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(VDR_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(VDR_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(VDR_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(VDR_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(VDR_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(VDR_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+VDR_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(VDR_DST);
		return destination;
	}

	//EMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000
	@Bean
	public JCoDestination destEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000() throws JCoException, IOException {
		String VDR_DST ="EMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(VDR_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(VDR_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(VDR_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(VDR_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(VDR_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(VDR_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+VDR_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(VDR_DST);
		return destination;
	}

	// EMEA - END

	//BW4PFB --OLD- PFBPFI

	@Bean
	public JCoDestination destBW4PFB() throws JCoException, IOException {
		String pfb_DST ="BW4PFB";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(pfb_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(pfb_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(pfb_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(pfb_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(pfb_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		//prop.setProperty(DestinationDataProvider.JCO_R3NAME, "CFINBW");   //CFINBW
		//prop.setProperty(DestinationDataProvider.JCO_MSHOST, "cspfb.jnj.com"); //cspfb.jnj.com
		//prop.setProperty(DestinationDataProvider.JCO_MSSERV, "sapgw00");//sapgw00
		//prop.setProperty(DestinationDataProvider.JCO_GROUP, "PUBLIC") ;//PUBLIC

		File destCfg = new File(pfb_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+pfb_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(pfb_DST);
		return destination;
	}

	//S4PFI
	@Bean
	public JCoDestination destS4PFI() throws JCoException, IOException {
		String pfi_DST ="S4PFI";
		Properties prop = new Properties();
		prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(pfi_DST+".host"));
		prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(pfi_DST+".instance"));
		prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(pfi_DST+".client"));
		prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(pfi_DST+".usr"));
		prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(pfi_DST+".pwd"));
		prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

		File destCfg = new File(pfi_DST + ".jcoDestination");
		log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
		//if(!destCfg.exists() || !destCfg.isFile()) {
			FileOutputStream fos = new FileOutputStream(destCfg, false);
			prop.store(fos, ""+pfi_DST);
			fos.close();
		//}
		JCoDestination destination = JCoDestinationManager.getDestination(pfi_DST);
		return destination;
	}

	//GRCSYS
		@Bean
		public JCoDestination destGRCSYS() throws JCoException, IOException {
			String grc_DST ="GRCSYS";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(grc_DST+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(grc_DST+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(grc_DST+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(grc_DST+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(grc_DST+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(grc_DST + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+grc_DST);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(grc_DST);
			return destination;
		}

		// CFIN -PFICLNT000 - START

		@Bean
		public JCoDestination destNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000() throws JCoException, IOException {
			String PFICLNT_DST ="NA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PFICLNT_DST+".host"));
			//prop.setProperty(DestinationDataProvider.JCO_PROXY_PORT, "3600");
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PFICLNT_DST+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PFICLNT_DST+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PFICLNT_DST+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PFICLNT_DST+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(PFICLNT_DST + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+PFICLNT_DST);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(PFICLNT_DST);
			return destination;
		}
		// CFIN -PFICLNT000 - END


		// CFIN -PFQCLNT000 - START
		@Bean
		public JCoDestination destNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000() throws JCoException, IOException {
			String PFQCLNT_DST ="NA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000";
			Properties prop = new Properties();
			prop.setProperty(DestinationDataProvider.JCO_ASHOST, environment.getRequiredProperty(PFQCLNT_DST+".host"));
			prop.setProperty(DestinationDataProvider.JCO_SYSNR, environment.getRequiredProperty(PFQCLNT_DST+".instance"));
			prop.setProperty(DestinationDataProvider.JCO_CLIENT, environment.getRequiredProperty(PFQCLNT_DST+".client"));
			prop.setProperty(DestinationDataProvider.JCO_USER, environment.getRequiredProperty(PFQCLNT_DST+".usr"));
			prop.setProperty(DestinationDataProvider.JCO_PASSWD, environment.getRequiredProperty(PFQCLNT_DST+".pwd"));
			prop.setProperty(DestinationDataProvider.JCO_LANG, "en");

			File destCfg = new File(PFQCLNT_DST + ".jcoDestination");
			log.info("File Exists: "+destCfg.getAbsolutePath()+" - "+destCfg.exists());
			//if(!destCfg.exists() || !destCfg.isFile()) {
				FileOutputStream fos = new FileOutputStream(destCfg, false);
				prop.store(fos, ""+PFQCLNT_DST);
				fos.close();
			//}
			JCoDestination destination = JCoDestinationManager.getDestination(PFQCLNT_DST);
			return destination;
		}
		// CFIN -PFQCLNT000 - END

}

