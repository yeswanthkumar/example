package com.jnj.rqc.useridentity.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class GRCRequestDTO {
	private String REQ_ID = "";
	private String REQNO = "" ;
	private String REQ_CREATED = "";
    private String REQ_APPROVED = "";
    private int    REQTYPE = 2;
    private String PRIORITY = "";
    private String BPROC="FINANCE";
    private String MSMP_PROCESS_ID = "";
    private String FUNCAREA = "";
    private String REQ_COMPLETED = "";
    private String BGJOBID = "";
    private String REQJUSTIFICATION = "";
    private String UPDATED_BY_ID = "";
    private String UPDATED_BY_NAME = "";
    private String UPDATED_ON = "";
    private String EMPTYPE = "1";
    private String STATUS = "";
    private String ON_HOLD_BY = "";
    private String MSMP_APPROVAL_STATUS = "";
    private String TEMPLATE_ID = "";
    private String REQ_INIT_SYS = "";
    private String SKIP_MSMP = "";
    private String SLA_ID = "";
    private String Z_PROJECT_USER = "NO";
    private String ZZ_PROJECT_NAME = "NOT APPLICABLE";
    private String ZZ_MGT_REP_COMP = "";
    private String ZZ_LEGAL_ENTITY = "";
    private String ZZ_PLANT = "";
    private String ZZ_TRAINING_COMPLETED = "YES";
    private String ZZ_RF_USER = "";
    private String ZZ_INCIDENT_NUMBER = "";
    private String ZZ_PREFERRED_LANGUAGE = "";
    private String ZZ_DCM_NUMBER = "";
    private String ZZ_POSITION = "";
    private String ZZ_PLATFORM  = "";
    private String ZZ_USRGRP = "";
    List<SubmitUsern> SUBMITUSERN ;
    List<SubmitRolen> SUBMITROLEN;
    private String message_type = "";
    private String message_id = "";
    private String message = "";
 }
