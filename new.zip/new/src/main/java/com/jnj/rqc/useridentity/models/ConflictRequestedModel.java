package com.jnj.rqc.useridentity.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConflictRequestedModel {
	private String userId;
    private int reqId;
    private String riskId;
    private String riskDesc;
    private String app1;
    private String posv1;
    private String app2;
    private String posv2;
    private String conflict;
    private String riskLevel;
    private String mitId;
    private String mitDesc;
    private Date createdOn;
    private String status;
    private String acceptDeny;
    private String comments;
    private String resolvedBy;
    private Date resolvedOn;
}
