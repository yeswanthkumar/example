package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SAPUserAccessModel {
	private String sapId;
	private String gltgb;
	private String ntId;
	private String personNumber;
	private String wwid;
	private String sapPlatform;
	private String systemClient;
	private String description;
	private String details;

	public String getData() {
		return  sapPlatform+"~"+systemClient+"~"+description+"~"+details+"~"+sapId+"~"+wwid;
	}


	@Override
	public String toString() {
		return "SAPUserAccessModel [sapId=" + sapId + ", gltgb=" + gltgb + ", ntId=" + ntId + ", personNumber="	+ personNumber + ", wwid="
				+ wwid +", sapPlatform=" + sapPlatform + ", systemClient=" + systemClient + ", description=" + description + ", details=" + details + "]";
	}




}
