package com.jnj.rqc.controllers;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.jnj.rqc.models.User;
import com.jnj.rqc.service.ADUserService;
import com.jnj.rqc.service.ApplDataService;


@Controller
public class UserAuthController {
	static final Logger log = LoggerFactory.getLogger(UserAuthController.class);
	@Autowired
	ADUserService userService;

	@Autowired
	ApplDataService applDataService;









    @GetMapping("/rqcUserInfo111")
    public String getRQCAppUserInfo(Model model, HttpServletRequest req) {
    	log.info("Routing to RQC User Info page.");
    	System.out.println("Principal :"+req.getUserPrincipal().getName());
    	String userName = new com.sun.security.auth.module.NTSystem().getName();
    	System.out.println("NTSystem User: "+userName);
    	User loggedInUsr = userService.searchUserById(System.getProperty("user.name"));
    	log.info("User Info: "+loggedInUsr);
    	req.getSession().setAttribute("LoggedInUser", loggedInUsr);
    	return "rqc/appUserView";
    }
  /*
    @PostMapping("/rqcUserDetails")
    public ResponseEntity<UserNameRespDto> getRQCAppUserDetail(Model model,  @RequestBody SearchUserName searchUserName, HttpServletRequest req) {
    	log.info("Received userName: "+searchUserName.getUserName());
    	UserNameRespDto userRespDto = userService.searchUserByName(searchUserName.getUserName().trim());

    	if (userRespDto.getStatusCode() == 0) {
			return new ResponseEntity<UserNameRespDto>(userRespDto, HttpStatus.OK);
        } else if (userRespDto.getStatusCode() == 500) {
			return new ResponseEntity<UserNameRespDto>(userRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<UserNameRespDto>(userRespDto, HttpStatus.NOT_FOUND);
        }

    }


    @PostMapping("/userJustification")
    public String getUserJustification(@RequestParam("assoWwid") String assoWwid, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Displaying User Justification Page  for assoWwid:"+assoWwid);
    	if(null==assoWwid || assoWwid.length()==0) {
    		request.setAttribute("ERROR", "Please select/enter Associate's first and/or last name or WWID");
    		return "rqc/appUserView";
    	}
    	User associate = userService.searchUserByWWID(assoWwid);
    	request.getSession().setAttribute("Associate", associate);
    	User mgr = userService.searchUserByWWID(associate.getMgrId());
    	request.getSession().setAttribute("AssoMgr", mgr);
    	Calendar cal=Calendar.getInstance();
    	cal.add(Calendar.DATE, 5);
    	Date rqstDt = new Date(cal.getTimeInMillis());
    	request.getSession().setAttribute("needDt", rqstDt);
        return "rqc/appUserJustificationView";
    }


 */



}