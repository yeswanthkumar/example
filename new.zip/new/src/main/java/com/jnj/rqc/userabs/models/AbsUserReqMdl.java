package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class AbsUserReqMdl implements Serializable {
	private static final long serialVersionUID = 3624346878620751168L;

	private int 	reqid;
	private int 	typeid;
	private String  typename;
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date   	requestedon;
	private String 	requestedby;
	private String 	requestedbyname;
	private String 	userid;
	private String 	username;
	private String 	managerid;
	private String 	managername;
	private int 	reqsys;
	private String 	reqsysnames;
	private String 	bfid;
	private String 	bfname;
	private String 	secids;
	private String 	regids;
	private int 	reqStatus;
	private String  reqStatusDesc;
	private String  conflictFound;
	private String  routedToCompl;
	private String  conflictResolved;
	private Date   	dateResolved;
	private String  isExces;
	private String  updatedby;
	private Date   	updatedon;
	private String comments;
	private List<IAMReqRoleMdl> roleStatus;
	//private List<SysDpendncMdl> sysList;
	private Map<String, List<RawSysDpendncMdl>> sysList;
	private List<UserAbsConflictMdl> confList;
	private List<AbsExcesvAccsMdl> excsvList;
	private List<AbsSysLeveExcsvRestrMdl> restExcsvAcssList;
	private List<RoleADGrpMdl> duplicateList;


}
