package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmailInfoModel {
	private String 	recName;
	private String 	from;
	private String 	to;
	private String 	subject;

	@Override
	public String toString() {
		return "EmailInfoModel [recName=" + recName + ", from=" + from + ", to=" + to + ", subject=" + subject + "]";
	}

}
