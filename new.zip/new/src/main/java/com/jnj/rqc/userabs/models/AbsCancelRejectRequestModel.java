package com.jnj.rqc.userabs.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AbsCancelRejectRequestModel {
	private String 	reqid;
	private String	userid;
	private String  cancelReject;
	private String  reason ;
}


