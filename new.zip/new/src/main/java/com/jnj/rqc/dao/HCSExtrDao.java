package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;

public interface HCSExtrDao {
	//public List<SAPUserAccessModel> getJDEUserData(String templSysParam) throws SQLException, DataAccessException  ;
	public List<SapGaaUser2RoleModel> getHCSUser2RoleData(String templSysParam) throws SQLException, DataAccessException;



	/*public List<String> getAllValidUsers(String templSysParam) throws JCoException  ;
	public List<String> getUsersRoles(String user, String templSysParam) throws JCoException;
	public String getRoleDescription(String role, String templSysParam) throws JCoException;


	public String getUsersPersonNumber(String user, String templSysParam) throws JCoException;
	public String getUsersWwId(String prsnNumber, String templSysParam) throws JCoException;


*/




	//public List<HanaRoleUserPrivilegeMdl> getRolePrivilegeData(String templSysParam, String roleNames) throws SQLException, DataAccessException;
	//public List<HanaRoleUserPrivilegeMdl> getUserDirectPrivilegeData(String templSysParam)  throws SQLException, DataAccessException;

}
