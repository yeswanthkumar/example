package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConflictDispModel {
	private int wwId;
	private String userId;
	private String firstName;
	private String lastName;
	private String srcSys1;
	private String srcSys2;
	private int code1;
	private int code2;
	private String co;
	private String waivers;
	private String mitigatingControl;
	private String supvrWwid;
	private String supvrEmail;

	@Override
	public String toString() {
		return "ConflictData [wwId=" + wwId + ", userId=" + userId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", srcSys1=" + srcSys1 + ", srcSys2=" + srcSys2 + ", code1=" + code1 + ", code2=" + code2
				+ ", co=" + co + ", waivers=" + waivers + ", mitigatingControl=" + mitigatingControl + ", supvrWwid="
				+ supvrWwid + ", supvrEmail=" + supvrEmail + "]";
	}

	public String getData() {
		return  wwId + "~" + userId + "~" + firstName + "~"+ lastName + "~" + srcSys1 + "~" + srcSys2 + "~" + code1 + "~" + code2 + "~" + co + "~" + waivers + "~" + mitigatingControl + "~"+ supvrWwid + "~" + supvrEmail;
	}


}
