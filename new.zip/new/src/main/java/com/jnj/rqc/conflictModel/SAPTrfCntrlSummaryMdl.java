package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SAPTrfCntrlSummaryMdl {
	private String region;
	private String Platform;
	private String environment;
	private String system;
	private int count;


	@Override
	public String toString() {
		return "SAPTrfCntrlSummaryMdl [region=" + region + ", Platform=" + Platform + ", environment=" + environment
				+ ", system=" + system + ", count=" + count + "]";
	}








}
