package com.jnj.rqc.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.dao.CSMDataDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.util.Utility;



@Service
public class CSMDataDaoImpl  extends BaseDao implements CSMDataDao {
	static final Logger log = LoggerFactory.getLogger(CSMDataDaoImpl.class);

	@Override
	public int insertCSMArchiveData(List<CSMHistDataMdl> csmData) throws SQLException, DataAccessException {
		String delQry = " DELETE SOD_DB_USER.CSMDATA_HIST ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.CSMDATA_HIST ( DISP_NAME, PARENT, CODE, F_NAME, L_NAME, WWID, EMAIL, STATUS, ADGROUP, EFF_DATE, VLD_FROM, VLD_TO ) "
					+  " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, csmData.get(i).getDispName());
				ps.setString(2, csmData.get(i).getParent());
				ps.setString(3, csmData.get(i).getCode());
				ps.setString(4, csmData.get(i).getFName());
				ps.setString(5, csmData.get(i).getLName());
				ps.setString(6, csmData.get(i).getWwid());
				ps.setString(7, csmData.get(i).getEmail());
				ps.setString(8, (csmData.get(i).getStatus() != null)?csmData.get(i).getStatus().trim() : "");
				ps.setString(9, csmData.get(i).getAdgroup());
				ps.setDate(10,  new java.sql.Date(csmData.get(i).getEffDate().getTime()));
				ps.setDate(11,  new java.sql.Date(csmData.get(i).getVldFrom().getTime()));
				ps.setDate(12, new java.sql.Date(csmData.get(i).getVldTo().getTime()));
			}

			@Override
			public int getBatchSize() {
				return csmData.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == csmData.size() ? "Success-"+csmData.size() : "Failed-"+(csmData.size() - status.length)));
		return status.length;
	}

	@Override
	public int insertCSMCurrentData(List<GrpUsrDateMdl> csmData) throws SQLException, DataAccessException {
		//String delQry = " DELETE SOD_DB_USER.CSMDATA_HIST ";
		//int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.CSMDATA_HIST ( DISP_NAME, PARENT, CODE, F_NAME, L_NAME, WWID, EMAIL, STATUS, ADGROUP, EFF_DATE, VLD_FROM, VLD_TO ) "
					+  " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, "");
				ps.setString(2, "");
				ps.setString(3, "");
				ps.setString(4, csmData.get(i).getFName());
				ps.setString(5, csmData.get(i).getLName());
				ps.setString(6, csmData.get(i).getUserId());
				ps.setString(7, csmData.get(i).getEmailId());
				ps.setString(8, (csmData.get(i).getEmpStatus() != null)?csmData.get(i).getEmpStatus().trim() : "");
				ps.setString(9, csmData.get(i).getAdgroup());
				ps.setDate(10,  new java.sql.Date(csmData.get(i).getModDate().getTime()));
				ps.setDate(11,  new java.sql.Date(csmData.get(i).getVldFrom().getTime()));
				ps.setDate(12, new java.sql.Date(csmData.get(i).getVldTo().getTime()));
			}

			@Override
			public int getBatchSize() {
				return csmData.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == csmData.size() ? "Success-"+csmData.size() : "Failed-"+(csmData.size() - status.length)));
		return status.length;
	}




	@Override
	public int insertCSMModelData(List<CSMModelAdGrpMap> csmData) throws SQLException, DataAccessException {
		String delQry = " DELETE SOD_DB_USER.CSMMODEL_DATA ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.CSMMODEL_DATA ( ADGROUP, MODELNAME, UPDATED_DATE, UPDATED_BY ) "
					+  " VALUES (?, ?, ?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, csmData.get(i).getAdgroup());
				ps.setString(2, csmData.get(i).getModelname());
				ps.setDate(3,  new java.sql.Date(csmData.get(i).getUpdatedDate().getTime()));
				ps.setString(4,  csmData.get(i).getUpdatedBy());
			}

			@Override
			public int getBatchSize() {
				return csmData.size();
			}
		});
		log.info("Total Records inserted : "+(status.length == csmData.size() ? "Success-"+csmData.size() : "Failed-"+(csmData.size() - status.length)));
		return status.length;
	}

	@Override
	public int validateUserToAdGrpData(GrpUsrDateMdl userData, java.util.Date validDate) throws SQLException, DataAccessException {
		String qry = " Select count(*) from SOD_DB_USER.CSMDATA_HIST " +
					 " Where upper(EMAIL) = upper('"+userData.getEmailId().trim()+"') "+
					 " AND upper(ADGROUP) = upper('"+userData.getAdgroup()+"') "+
					 " and to_char(VLD_TO, 'MM/dd/yyyy HH24:mm:ss') > '"+Utility.fmtMMDDYYYYTime(validDate)+"'";
		//log.info("QRY: "+qry);
		int recCount = getJdbcTemplateSRADUtils().queryForObject(qry, new Object[] {}, Integer.class);
		log.info("Total Records Found :"+recCount);
		return recCount;
	}

	@Override
	public int compareExistingData(GrpUsrDateMdl userData) throws SQLException, DataAccessException {
		String qry = " Select count(*) from SOD_DB_USER.CSM_IAMDATA " +
					 " Where upper(EMAIL) = upper('"+userData.getEmailId().trim()+"') "+
					 " AND upper(ADGROUP) = upper('"+userData.getAdgroup()+"') ";
		int recCount = getJdbcTemplateSRADUtils().queryForObject(qry, new Object[] {}, Integer.class);
		log.info("Total Records Found :"+recCount);
		return recCount;
	}



	@Override
	//@Transactional(readOnly=true)
	public int insertIAMDataForCMS(List<GrpUsrDateMdl> iamCsmData) throws SQLException, DataAccessException{
		//String delQry = " DELETE SOD_DB_USER.CSM_IAMDATA ";
		//int count =   getJdbcTemplateSRADUtils().update(delQry);

		String insQry = " INSERT INTO SOD_DB_USER.CSM_IAMDATA ( USER_ID, F_NAME, L_NAME, WWID, EMAIL, STATUS, ADGROUP, MODELNAME, MOD_DATE,	VLD_FROM, VLD_TO, ADD_REMOVE, IS_NEW ) "
					  + " VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, iamCsmData.get(i).getUserId());
				ps.setString(2, iamCsmData.get(i).getFName());
				ps.setString(3, iamCsmData.get(i).getLName());
				ps.setString(4, iamCsmData.get(i).getWwid());
				ps.setString(5, iamCsmData.get(i).getEmailId());
				ps.setString(6, iamCsmData.get(i).getEmpStatus());
				ps.setString(7, iamCsmData.get(i).getAdgroup());
				ps.setString(8, "");
				ps.setDate(9,  new java.sql.Date(iamCsmData.get(i).getModDate().getTime()));
				ps.setDate(10,  new java.sql.Date(iamCsmData.get(i).getVldFrom().getTime()));
				ps.setDate(11, new java.sql.Date(iamCsmData.get(i).getVldTo().getTime()));
				ps.setString(12, "A");
				ps.setString(13, "Y");
			}

			@Override
			public int getBatchSize() {
				return iamCsmData.size();
			}
		});

		if(status.length > 0) {
			String updtQry = "UPDATE SOD_DB_USER.CSM_IAMDATA a SET a.Modelname = (Select DISTINCT b.modelname from SOD_DB_USER.CSMMODEL_DATA b where upper(a.adgroup) = upper(b.adgroup))";
			int updCount =   getJdbcTemplateSRADUtils().update(updtQry);
			log.info("Updated Models for IAM-CSM Data "+ updCount);
		}


		log.info("Total IAM-CSM Records inserted : "+(status.length == iamCsmData.size() ? "Success-"+iamCsmData.size() : "Failed-"+(iamCsmData.size() - status.length)));
		return status.length;
	}


	@Override
	public int updateIAMDataForCMS() throws SQLException, DataAccessException{
		String updateQry = " UPDATE SOD_DB_USER.CSM_IAMDATA SET IS_NEW = 'N' WHERE IS_NEW = 'Y' ";
		int count =   getJdbcTemplateSRADUtils().update(updateQry);
		log.info("Total IAM-CSM Records updated : "+count);
		return count;
	}





	@Override
	public List<GrpUsrDateMdl> getCSMIAMExportData() throws SQLException, DataAccessException {
		List<GrpUsrDateMdl> dataList = new ArrayList<>();
		String qry = " Select USER_ID, F_NAME, L_NAME, WWID, EMAIL as emailId, STATUS as empStatus, ADGROUP, MODELNAME, MOD_DATE, VLD_FROM, VLD_TO, ADD_REMOVE, IS_NEW " +
					 " FROM SOD_DB_USER.CSM_IAMDATA  WHERE IS_NEW = 'Y' "+
					 " ORDER BY F_NAME, L_NAME, ADGROUP ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<>(GrpUsrDateMdl.class));
		log.info("CSM-IAM Data Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}



	/*@SuppressWarnings("all")
	@Override
	public int insertUser2SodMitiData(List<SapMitiCntrlModel> dataList)throws SQLException, DataAccessException{
		String delQry = "DELETE SOD_DB_USER.GRAC_MITICTRL";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		int recUpdated=0;
	 	if(count > 0) {
	 		String qry=" Insert into SOD_DB_USER.GRAC_MITICTRL ( RISK_ID, CTRL_ID, CTRL_DESC ) Values (?, ?, ?) ";
			log.debug("Inserting Data to Genesis, Query: "+qry);
			int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, dataList.get(i).getRiskId());
					ps.setString(2, dataList.get(i).getControlId());
					ps.setString(3, dataList.get(i).getControlDesc());
				}

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return dataList.size();
				}
			});
			recUpdated =  status.length;
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
	 	}
	 	return recUpdated;
	}
*/
/*	@Override
	public List<SapMitiCntrlModel> loadMitiCntrlDBData() throws SQLException, DataAccessException {
		List<SapMitiCntrlModel> dataList = new ArrayList<SapMitiCntrlModel>();
		String qry = " Select RISK_ID, CTRL_ID AS controlId, CTRL_DESC as controlDesc " +
					 "  FROM SOD_DB_USER.GRAC_MITICTRL "+
					 " ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<SapMitiCntrlModel>(SapMitiCntrlModel.class));
		log.info("MITIGATING CNTROL Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}*/



	/*
	@Override
	public int insertMercuryUser2SodRevrData(List<StrKeyValPair> dataList) throws SQLException, DataAccessException {
		String delQry = " DELETE SOD_DB_USER.REVIEWER_DETAILS_MERCURY ";
		int count =   getJdbcTemplateSRADUtils().update(delQry);
		String insQry = " INSERT INTO SOD_DB_USER.REVIEWER_DETAILS_MERCURY ( APPR_LIST_ID, REVR_ID ) VALUES (?, ?) ";
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(insQry, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, dataList.get(i).getKey());
				ps.setString(2, dataList.get(i).getVal());
			}

			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				return dataList.size();
			}
		});
		log.info("MERCURY Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return status.length;
	}
	*/



	/*@Override
	public List<SapPlatformReviwerMdl> loadReviewerDBData() throws SQLException, DataAccessException {
		List<SapPlatformReviwerMdl> dataList = new ArrayList<SapPlatformReviwerMdl>();
		String qry = " Select PLATFORM, RISK_ID, REVR_ID as reviewerId " +
					 "  FROM SOD_DB_USER.REVIEWER_DETAILS "+
					 " ORDER BY 1,2,3 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<SapPlatformReviwerMdl>(SapPlatformReviwerMdl.class));
		log.info("REVIEWER Data Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}
*/
	/*@Override
	public List<StrKeyValPair> loadMercuryReviewerDBData() throws SQLException, DataAccessException {
		List<StrKeyValPair> dataList = new ArrayList<StrKeyValPair>();
		String qry = " Select APPR_LIST_ID as key, REVR_ID as val " +
					 "  FROM SOD_DB_USER.REVIEWER_DETAILS_MERCURY "+
					 " ORDER BY 1,2 ";
		dataList  = getJdbcTemplateSRADUtils().query(qry, new Object[] {}, new BeanPropertyRowMapper<StrKeyValPair>(StrKeyValPair.class));
		log.info("Mercury REVIEWER Data Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList ;
	}*/


}
