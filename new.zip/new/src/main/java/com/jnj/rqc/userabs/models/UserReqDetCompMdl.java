package com.jnj.rqc.userabs.models;

import java.io.Serializable;

import lombok.Data;

@Data
public class UserReqDetCompMdl implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 8121746433306498420L;

	private int 	reqid;
	private String  sysid;
	private String 	posids;
	private String 	accids;
	private String 	posvarids;
	private String 	adids;
	private String 	dt_created;

}
