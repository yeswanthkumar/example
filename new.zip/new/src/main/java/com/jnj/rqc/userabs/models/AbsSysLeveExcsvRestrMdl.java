package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.jnj.rqc.models.UserSearchModel;

import lombok.Data;

@Data
public class AbsSysLeveExcsvRestrMdl implements Serializable {
	private static final long serialVersionUID = -4074214608662816096L;
	UserSearchModel user;
	String userid;
	int    reqid;
	String sysid;
	String sysName;
	List<AbsSecExcesvRestrictedAccsMdl> sectorDataList;
	List<RoleADGrpMdl> selVarsRestricted;
	List<RoleADGrpMdl> selVarsNonRestricted;
	Date   createdon;
}