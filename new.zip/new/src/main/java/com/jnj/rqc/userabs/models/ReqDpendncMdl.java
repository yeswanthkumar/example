package com.jnj.rqc.userabs.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReqDpendncMdl {
	private int reqid;
	private String sysid;
	private String sysname;
	private String posids;
	private String accids;
	private String posvarids;
	private String adids;
	private Date dtCreated;
}
