package com.jnj.rqc.dbconfig;

import org.springframework.jdbc.core.JdbcTemplate;

public class TemplateFactory extends BaseDao {



	public JdbcTemplate getJdbcTemplateFact(String templateName) {
		JdbcTemplate templ= null;

		if("SANDBOX_Sandbox_Sandbox1".equalsIgnoreCase(templateName) ){
			templ = getJdbcTemplateSANDBOX_Sandbox_Sandbox1();//SANDBOX
		}else if("BOBI_Development_Dfx_Tenant_DB".equalsIgnoreCase(templateName) ) {
			templ = getJdbcTemplateBOBI_Development_Dfx_Tenant_DB();
		}else if("BOBI_Development_DFY_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Development_DFY_Tenant_DB();
		}else if("BOBI_Development_DFY_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Development_DFY_System_DB();
		}else if("BOBI_Development_N_1_xfx_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Development_N_1_xfx_Tenant_DB();
		}else if("BOBI_Development_N_1_xfy_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Development_N_1_xfy_Tenant_DB();
		}else if("BOBI_Development_N_1_xfy_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Development_N_1_xfy_System_DB();
		}else if("BOBI_Production_pfx_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Production_pfx_Tenant_DB();
		}else if("BOBI_Production_Pfy_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Production_Pfy_Tenant_DB();
		}else if("BOBI_Production_Pfy_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Production_Pfy_System_DB();
		}else if("BOBI_QA_QFX_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_QFX_Tenant_DB();
		}else if("BOBI_QA_QFY_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_QFY_Tenant_DB();
		}else if("BOBI_QA_QFY_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_QFY_System_DB();
		}else if("BOBI_QA_N_1_yfx_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_N_1_yfx_Tenant_DB();
		}else if("BOBI_QA_N_1_yfy_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_N_1_yfy_Tenant_DB();
		}else if("BOBI_QA_N_1_yfy_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_QA_N_1_yfy_System_DB();
		}else if("BOBI_Pre_PRD_yfx_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Pre_PRD_yfx_Tenant_DB();
		}else if("BOBI_Pre_PRD_yfy_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Pre_PRD_yfy_Tenant_DB();
		}else if("BOBI_Pre_PRD_yfy_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBOBI_Pre_PRD_yfy_System_DB();
		}else if("BODS_Production_PFF_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Production_PFF_Tenant_DB();
		}else if("BODS_Production_PFE_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Production_PFE_Tenant_DB();
		}else if("BODS_Production_PFE_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Production_PFE_System_DB();
		}
		else if("BODS_Development_DFF_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Development_DFF_Tenant_DB();
		}else if("BODS_Development_DFE_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Development_DFE_Tenant_DB();
		}else if("BODS_Development_DFE_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Development_DFE_System_DB();
		}else if("BODS_Quality_QA1_QFF_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Quality_QA1_QFF_Tenant_DB();
		}else if("BODS_Quality_QA1_QFE_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Quality_QA1_QFE_Tenant_DB();
		}else if("BODS_Quality_QA1_QFE_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBODS_Quality_QA1_QFE_System_DB();
		}else if("CTS_Development_DFU_DFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Development_DFU_DFU();
		}else if("CTS_Development_DFT_DFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Development_DFT_DFU();
		}else if("CTS_Development_SYSTEMDB_DFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Development_SYSTEMDB_DFU();
		}else if("CTS_Production_PFU_PFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Production_PFU_PFU();
		}else if("CTS_Production_PFT_PFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Production_PFT_PFU();
		}else if("CTS_Production_SYSTEMDB_PFU".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateCTS_Production_SYSTEMDB_PFU();
		}else if("BW_Production_PFA_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Production_PFA_Tenant_DB();
		}else if("BW_Production_PFB_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Production_PFB_Tenant_DB();
		}else if("BW_Production_PFA_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Production_PFA_System_DB();
		}else if("BW_Development_N_1_XFA_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_N_1_XFA_Tenant_DB();
		}else if("BW_Development_N_1_XFB_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_N_1_XFB_Tenant_DB();
		}else if("BW_Development_N_1_XFA_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_N_1_XFA_System_DB();
		}else if("BW_Development_DFA_Teanat_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_DFA_Teanat_DB();
		}else if("BW_Development_DFB_Teanant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_DFB_Teanant_DB();
		}else if("BW_Development_DFA_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_Development_DFA_System_DB();
		}else if("BW_QA_QFA_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_QFA_Tenant_DB();
		}else if("BW_QA_QFB_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_QFB_Tenant_DB();
		}else if("BW_QA_QFA_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_QFA_System_DB();
		}else if("BW_QA_N_1_YFA_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_N_1_YFA_Tenant_DB();
		}else if("BW_QA_N_1_YFB_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_N_1_YFB_Tenant_DB();
		}else if("BW_QA_N_1_YFA_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateBW_QA_N_1_YFA_System_DB();
		}else if("S4_Production_PFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Production_PFH_Tenant_DB();
		}else if("S4_Production_PFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Production_PFI_Tenant_DB();
		}else if("S4_Production_PFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Production_PFH_System_DB();
		}else if("S4_Development_N_1_XFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_N_1_XFH_Tenant_DB();
		}else if("S4_Development_N_1_XFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_N_1_XFI_Tenant_DB();
		}else if("S4_Development_N_1_XFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_N_1_XFH_System_DB();
		}else if("S4_Quality_QA3_YFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA3_YFH_Tenant_DB();
		}else if("S4_Quality_QA3_YFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA3_YFI_Tenant_DB();
		}else if("S4_Quality_QA3_YFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA3_YFH_System_DB();
		}else if("S4_Development_DFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_DFH_Tenant_DB();
		}else if("S4_Development_DFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_DFI_Tenant_DB();
		}else if("S4_Development_DFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Development_DFH_System_DB();
		}else if("S4_Quality_QA1_QFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA1_QFH_Tenant_DB();
		}else if("S4_Quality_QA1_QFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA1_QFI_Tenant_DB();
		}else if("S4_Quality_QA1_QFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA1_QFH_System_DB();
		}else if("S4_Quality_QA2_AFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA2_AFI_Tenant_DB();
		}else if("S4_Quality_QA2_AFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA2_AFH_Tenant_DB();
		}else if("S4_Quality_QA2_AFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Quality_QA2_AFH_System_DB();
		}else if("S4_Pre_QA_UFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_QA_UFH_Tenant_DB();
		}else if("S4_Pre_QA_UFI_Teanant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_QA_UFI_Teanant_DB();
		}else if("S4_Pre_QA_UFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_QA_UFH_System_DB();
		}else if("S4_Pre_Production_TFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_Production_TFH_Tenant_DB();
		}else if("S4_Pre_Production_TFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_Production_TFI_Tenant_DB();
		}else if("S4_Pre_Production_TFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_Pre_Production_TFH_System_DB();
		}else if("S4_QA_N_1_RFH_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_QA_N_1_RFH_Tenant_DB();
		}else if("S4_QA_N_1_RFI_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_QA_N_1_RFI_Tenant_DB();
		}else if("S4_QA_N_1_RFH_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateS4_QA_N_1_RFH_System_DB();
		}else if("SLT_Development_DFM_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_DFM_Tenant_DB();
		}else if("SLT_Development_DFQ_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_DFQ_Tenant_DB();
		}else if("SLT_Development_DFM_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_DFM_System_DB();
		}else if("SLT_Quality_QA1_QFM_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA1_QFM_Tenant_DB();
		}else if("SLT_Quality_QA1_QFQ_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA1_QFQ_Tenant_DB();
		}else if("SLT_Quality_QA1_QFM_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA1_QFM_System_DB();
		}else if("SLT_Quality_QA2_QFN_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA2_QFN_Tenant_DB();
		}else if("SLT_Quality_QA2_QFR_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA2_QFR_Tenant_DB();
		}else if("SLT_Quality_QA2_QFN_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA2_QFN_System_DB();
		}else if("SLT_Quality_QA3_QFS_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA3_QFS_Tenant_DB();
		}else if("SLT_Quality_QA3_QFO_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA3_QFO_Tenant_DB();
		}else if("SLT_Quality_QA3_QFO_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA3_QFO_System_DB();
		}else if("SLT_Quality_QA3_QFO_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Quality_QA3_QFO_System_DB();
		}else if("SLT_Production_PFQ_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Production_PFQ_Tenant_DB();
		}else if("SLT_Production_PFM_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Production_PFM_System_DB();
		}else if("SLT_Development_N_1_DFN_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_N_1_DFN_Tenant_DB();
		}else if("SLT_Development_N_1_DFR_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_N_1_DFR_Tenant_DB();
		}else if("SLT_Development_N_1_DFN_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Development_N_1_DFN_System_DB();
		}else if("SLT_Pre_QA_UFQ_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_QA_UFQ_Tenant_DB();
		}else if("SLT_Pre_QA_UFM_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_QA_UFM_Tenant_DB();
		}else if("SLT_Pre_QA_UFM_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_QA_UFM_System_DB();
		}else if("SLT_Pre_Production_TFM_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_Production_TFM_Tenant_DB();
		}else if("SLT_Pre_Production_TFQ_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_Production_TFQ_Tenant_DB();
		}else if("SLT_Pre_Production_TFM_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_Pre_Production_TFM_System_DB();
		}else if("SLT_QA_N_1_YFN_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_QA_N_1_YFN_Tenant_DB();
		}else if("SLT_QA_N_1_YFR_Tenant_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_QA_N_1_YFR_Tenant_DB();
		}else if("SLT_QA_N_1_YFN_System_DB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateSLT_QA_N_1_YFN_System_DB();
		}
		/*else if("NA_SAPSANDBOX_Sandbox_R3P_700".equalsIgnoreCase(templateName)) {
		templ = getJdbcTemplateNA_SAPSANDBOX_Sandbox_R3P_700();
		}*/
		//TemPlates for SAP ESTRACT gAA
		//NA_HANA  - User for Transfers
		else if("NA_BOBJ_Production_BTBBOBJBPG".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_BOBJ_Production_BTBBOBJBPG();
		}else if("NA_HANA_Production_BTBHANAHPG".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_BTBHANAHPG();
		}else if("NA_HANA_Production_FUSIONEmptyTenantDBPEA".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEA();
		}else if("NA_HANA_Production_FUSIONTenantDBPB1".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONTenantDBPB1();
		}else if("NA_HANA_Production_FUSIONSYSTEMDBPEA".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEA();
		}else if("NA_HANA_Production_FUSIONEmptyTenantDBPEB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONEmptyTenantDBPEB();
		}else if("NA_HANA_Production_FUSIONTenantDBPEC".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONTenantDBPEC();
		}else if("NA_HANA_Production_FUSIONSYSTEMDBPEB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_HANA_Production_FUSIONSYSTEMDBPEB();
		}else if("EMEA_HANA_Production_GALAXYHANA".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_GALAXYHANA();
		}

		else if("EMEA_HANA_Production_GALAXYHANASystemDB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_GALAXYHANASystemDB();
		}else if("EMEA_HANA_Production_GALAXYHANAHPM".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_GALAXYHANAHPM();
		}else if("EMEA_HANA_Production_GALAXYHANABPM".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_GALAXYHANABPM();
		}


		else if("EMEA_HANA_Production_STFHANA".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_STFHANA();
		}

		else if("EMEA_HANA_Production_STFHANASystemDB".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_STFHANASystemDB();
		}else if("EMEA_HANA_Production_STFHANAHPC".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_STFHANAHPC();
		}else if("EMEA_HANA_Production_STFHANABPC".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_STFHANABPC();
		}

		else if("EMEA_HANA_Production_EMEAHANASYNTHES".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES();
		}else if("EMEA_HANA_Production_EMEAHANASYNTHES1".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateEMEA_HANA_Production_EMEAHANASYNTHES1();
		}



		//START - JDE TEMPLETS


		else if("NA_JDEPLATFORM_Production_JDEANIMAS".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEANIMAS();
		}else if("NA_JDEPLATFORM_Production_JDEBWI".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEBWI();
		}else if("NA_JDEPLATFORM_Production_JDEDCF92".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEDCF92();
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYEMEA".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYEMEA();
		}else if("NA_JDEPLATFORM_Production_JDEDEPUYUS".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEDEPUYUS();
		}else if("NA_JDEPLATFORM_Production_JDEEES".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEEES();
		}else if("NA_JDEPLATFORM_Production_JDEETHICON".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEETHICON();
		}else if("NA_JDEPLATFORM_Production_JDEGMED".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEGMED();
		}/*else if("NA_JDEPLATFORM_Production_JDEMENTOR".equalsIgnoreCase(templateName)) {
			templ = getJdbcTemplateNA_JDEPLATFORM_Production_JDEMENTOR();
		}*/


		//START - JDE TEMPLETS















































		return templ;
	}


}
