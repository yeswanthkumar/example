package com.jnj.rqc.mastermetadata.service;

import com.jnj.rqc.mastermetadata.controller.UserAccessReqRepDTO;
import com.jnj.rqc.mastermetadata.controller.UserExcessiveReqRepDTO;

public interface UserAccessRequestReportService {
	public UserAccessReqRepDTO getUserAccessRequestResults();
	public UserAccessReqRepDTO getUserAccessRequestResults(String criteria, String value);
	public UserExcessiveReqRepDTO getUserExcessiveRequestResults();
	public UserExcessiveReqRepDTO getUserExcessiveRequestResults(String criteria, String value);
	public void getInAppSODReportResults(String reqUserId);
	public void getCrossAppSODReportResults(String reqUserId);
	public void getMultiUserReportResults(String reqUserId);
	public void getThresholdReportResults(String reqUserId);
}
