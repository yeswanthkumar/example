package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.TMUploadDataMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.models.UserTerminationReportModel;
import com.jnj.rqc.service.RqcReportService;
import com.jnj.rqc.service.UserMenuService;
import com.jnj.rqc.service.UserRoleActivityService;
import com.jnj.rqc.termdata.models.TermDataSmryModel;
import com.jnj.rqc.util.Utility;

@Controller
public class TerminationDataController {

	static final Logger log = LoggerFactory.getLogger(TerminationDataController.class);

	@Autowired
	private UserRoleActivityService userRoleActivityService;

	@Autowired
	RqcReportService rqcReportService;

	@Autowired
	UserMenuService userMenuService;

	@GetMapping("/navTermDataPage")
    public String loadReportForm(Model model) {
    	log.info("Routing to Termination Data page.");
    	return "userreview/genMonthlyTerminationPage";
    }


	@GetMapping("/navNonSoxTermDataPage")
    public String loadNonSoxReportForm(Model model) {
    	log.info("Routing to Termination Data page.");
    	return "userreview/genNonSoxMonthlyTermPage";
    }

	@GetMapping("/navManualExtrUpdates")
    public String loadManualExtrUpdatePage(Model model) {
    	log.info("Routing to Termination Data page.");
    	List<String> hcsSystems = userMenuService.getConstantList(Constants.HCS_MANUAL_SYSTEM);
    	model.addAttribute("hcsSystems", hcsSystems);
    	return "userreview/extractDataUpdatePage";
    }

	@PostMapping("/navManualExtrUpdates")
    public String processExtrUpdate(@RequestParam("file") MultipartFile file, @RequestParam("sysName") String sysName, Model model, HttpServletRequest request) {
    	log.info("Selected System :"+sysName +" File Name :"+ file.getOriginalFilename());

    	List<String> hcsSystems = userMenuService.getConstantList(Constants.HCS_MANUAL_SYSTEM);
    	model.addAttribute("hcsSystems", hcsSystems);
    	model.addAttribute("selSys", sysName);
    	model.addAttribute("selFile", file.getOriginalFilename());

    	if (file.isEmpty() || "0".equals(sysName)) {
    		log.info("Not Enough Values, one/more of the parameter missing.");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Not Enough Values, one/more of the parameter is missing.");
            return "userreview/extractDataUpdatePage";
        }

    	String ext =file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Selected resource is NOT a valid excel file!");
            return "userreview/extractDataUpdatePage";
    	}
    	try{
    		int recTotal = 0;
    		String path = Utility.saveFile(file);//FOM,PVCS,RMSJAPAN,TM
    		HttpSession session = request.getSession();
    		if("FOM".equals(sysName)) {

    		}else if("PVCS".equals(sysName)) {

    		}else if("RMSJAPAN".equals(sysName)) {

    		}else if("TM".equals(sysName)) {
    			session.removeAttribute("TMDATA");
    			List<TMUploadDataMdl> tmData = userRoleActivityService.readTMExcel(path, request);
        		if(null != tmData && !tmData.isEmpty() ) {
        			session.setAttribute("TMDATA", tmData);
        			model.addAttribute("TMDATA", tmData);
        			recTotal = tmData.size();
        		}
    		}


    		model.addAttribute("message", "True");
            model.addAttribute("success", "Status: Data Read successful - " + file.getOriginalFilename()+"  Total : "+recTotal+" Rows.");
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
         return "userreview/extractDataUpdatePage";
    }








	@PostMapping("/genNonSoxMonthlyTermFiles")
	public String createNonSoxTerminationData(@RequestParam("reportDate") String reportDate, Model model, HttpServletRequest request) {
    	log.info(" Monthly Termination Data Non-Sox reportDate:"+reportDate);
    	model.addAttribute("repParam", reportDate);

    	if(StringUtils.isEmpty(reportDate)) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter: Report Date ");
            return "userreview/genNonSoxMonthlyTermPage";
    	}
    	try{
    		Date repDt = Utility.fmtStrToDate(reportDate);
    		String strDate = Utility.fmtMDY(repDt);
    		List<TermDataSmryModel> summaryList = new ArrayList<>();
    		Map<String, List<UserActivityModel>> userData = userRoleActivityService.getNonSoxUserData(summaryList);
    		//Process Termination Report
    		Map<String, List<UserTerminationReportModel>> termDataMap = userRoleActivityService.processNonSoxTerminationReport(userData);

    		HttpSession session = request.getSession();
    		session.setAttribute("NDIRLOC", "N"+strDate);
    		session.setAttribute("NSUMMARYDATA", summaryList);
    		model.addAttribute("NSUMMARYDATA", summaryList);
    		session.setAttribute("NUSERTERMDATA", userData);
    		model.addAttribute("NUSERTERMDATA", userData);
    		//
    		session.setAttribute("NTERMREPORT", termDataMap);
    		model.addAttribute("NTERMREPORT", termDataMap);
    		//
    		model.addAttribute("message", "True");
        	log.debug("Total number of Non-Sox System Records : "+((summaryList==null)?  "0":summaryList.size()));
        	String msg  = "Status: Total Source System Combinations : "+ ((summaryList == null || summaryList.isEmpty() ) ?  "0": summaryList.size()+"");
        	model.addAttribute("success", msg);
    	} catch (Exception e) {
            log.error("Error generating RuleSet Review files :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "userreview/genNonSoxMonthlyTermPage";
    }

	@PostMapping("/genMonthlyTermFiles")
	public String createTerminationData(@RequestParam("reportDate") String reportDate, Model model, HttpServletRequest request) {
    	log.info(" Monthly Termination Data  reportDate:"+reportDate);
    	model.addAttribute("repParam", reportDate);

    	if(StringUtils.isEmpty(reportDate)) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: Missing required parameter: Report Date ");
            return "userreview/genMonthlyTerminationPage";
    	}
    	try{

    		Date repDt = Utility.fmtStrToDate(reportDate);
    		String strDate = Utility.fmtMDY(repDt);
    		List<TermDataSmryModel> summaryList = new ArrayList<>();
    		Map<String, List<UserActivityModel>> userData = userRoleActivityService.getUserData(summaryList);
    		//Process Termination Report
    		Map<String, List<UserTerminationReportModel>> termDataMap = userRoleActivityService.processTerminationReport(userData);

    		HttpSession session = request.getSession();
    		session.setAttribute("DIRLOC", strDate);
    		session.setAttribute("SUMMARYDATA", summaryList);
    		model.addAttribute("SUMMARYDATA", summaryList);
    		session.setAttribute("USERTERMDATA", userData);
    		model.addAttribute("USERTERMDATA", userData);
    		//
    		session.setAttribute("TERMREPORT", termDataMap);
    		model.addAttribute("TERMREPORT", termDataMap);
    		//
    		model.addAttribute("message", "True");
        	log.debug("Total number of System Records : "+((summaryList==null)?  "0":summaryList.size()));
        	String msg  = "Status: Total Source System Combinations : "+ ((summaryList == null || summaryList.isEmpty() ) ?  "0": summaryList.size()+"");
        	model.addAttribute("success", msg);
    	} catch (Exception e) {
            log.error("Error generating RuleSet Review files :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "userreview/genMonthlyTerminationPage";
    }

	//REPORT
	@ResponseBody
    @GetMapping("/downloadTermReportFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadTermReportFiles(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Termination Report Files");
		String fileDir =(String)request.getSession().getAttribute("DIRLOC");
		Map<String, List<UserTerminationReportModel>> userData = (Map<String, List<UserTerminationReportModel>>)request.getSession().getAttribute("TERMREPORT");
		Map<String, String> repFileMap = userRoleActivityService.generateTermReportFiles(userData, fileDir, request);
		String termFileDir =(String)request.getSession().getAttribute("DIRLOCREP");
		String filePath = Utility.createZip(Arrays.asList(termFileDir), termFileDir+".zip");
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@ResponseBody
    @GetMapping("/downloadTermFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadTermDataExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Termination Data Files");
		String fileDir =(String)request.getSession().getAttribute("DIRLOC");
		Map<String, List<UserActivityModel>> userData = (Map<String, List<UserActivityModel>>)request.getSession().getAttribute("USERTERMDATA");
		Map<String, String> ruleSetFileMap = userRoleActivityService.generateTermExcelFiles(userData, fileDir, request);
		String termFileDir =(String)request.getSession().getAttribute("DIRLOCZ");
		String filePath = Utility.createZip(Arrays.asList(termFileDir), termFileDir+".zip");
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadNonSoxTermReportFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadNonSoxTermReportFiles(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Non-Sox Termination Report Files");
		String fileDir =(String)request.getSession().getAttribute("NDIRLOC");
		Map<String, List<UserTerminationReportModel>> userData = (Map<String, List<UserTerminationReportModel>>)request.getSession().getAttribute("NTERMREPORT");
		Map<String, String> repFileMap = userRoleActivityService.generateNonSoxTermReportFiles(userData, fileDir, request);
		String termFileDir =(String)request.getSession().getAttribute("NDIRLOCREP");
		String filePath = Utility.createZip(Arrays.asList(termFileDir), termFileDir+".zip");
    	File fl = new File(filePath);
    	log.info("Download Non-Sox File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadNonSoxTermFiles")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadNonSoxTermFiles(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading NonSox Termination Data Files");
		String fileDir =(String)request.getSession().getAttribute("NDIRLOC");
		Map<String, List<UserActivityModel>> userData = (Map<String, List<UserActivityModel>>)request.getSession().getAttribute("NUSERTERMDATA");
		Map<String, String> ruleSetFileMap = userRoleActivityService.generateNonSoxTermExcelFiles(userData, fileDir, request);
		String termFileDir =(String)request.getSession().getAttribute("NDIRLOCZ");
		String filePath = Utility.createZip(Arrays.asList(termFileDir), termFileDir+".zip");
    	File fl = new File(filePath);
    	log.info("Download Non Sox File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }
}
