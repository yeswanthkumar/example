package com.jnj.rqc.dbextr.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.models.CRUnitADGroupMdl;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CRADGroupRespDto {
	private int statusCode;
	private String message;
	private String datetimeStamp;
	private String statusDesc;
	private String developerMessage;
	private String type;//PER/POS
	private List<CRUnitADGroupMdl> table1;
	private List<CRUnitADGroupMdl> table2;

}
