package com.jnj.rqc;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;

public class LdapUserGroups {

public void getUserDetail(String user_name, String passwd) throws NamingException {
    DirContext ctx = null;
    String username = user_name;
    try {
        ctx = context(user_name, passwd);
        System.out.println("User Validated");
        SearchControls searchCtls = new SearchControls();
        String returnedAtts[] = {"cn","memberOf"};
        searchCtls.setReturningAttributes(returnedAtts);
        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
//        String searchFilter = "(ui=643003319)";
//        String searchFilter = "(mail=lkodavat@its.jnj.com)";
//        String searchFilter = "(sAMAccountName=lkodavat)";
        //String searchFilter = "(&(objectclass=user)(mail="+user_name+"))";
        String searchFilter = "(&(objectclass=user)(sAMAccountName=lkodavat))";
        String searchBase = "dc=jnj,dc=com";
        NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
        while (answer.hasMoreElements()) {
            SearchResult sr =  answer.next();
            Attributes attrs = sr.getAttributes();
            if (attrs != null) {
                try {
                    String cn = attrs.get("cn").get().toString();
                    System.out.println(" cn : " + cn);

                    NamingEnumeration<?> memberOf = attrs.get("memberOf").getAll();
                    while (memberOf.hasMoreElements()) {
                        String member =(String)memberOf.next();
//                        System.out.println("memberOf : " + member);

        		        String [] groupname = member.split(",");
        		        String userGroup = groupname[0];
//        		        System.out.println(attrs.get("cn"));
        		        userGroup = userGroup.replaceAll("CN=", "").trim();
        		        System.out.println(" User Group  :  "+userGroup);
                    }
                } catch (NullPointerException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    } catch (NamingException e) {
        System.out.println(e.getMessage());
    } finally {
        if(!ctx.equals(null))
            ctx.close();       }
    }
/**
 * This method will return Directory Context to the Called method,Used to
 * bind with LDAP
 */
	public DirContext context(String user, String passwd) throws NamingException {
	    Hashtable<String, String> env = new Hashtable<>();
	    String adminName = user;
	    String adminPassword = passwd;
	    String ldapURL = "LDAP://jnjdir.jnj.com:3268";
	    //String ldapURL = "LDAP://jnjdir.jnj.com";
	    env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
	    env.put(Context.PROVIDER_URL, ldapURL);
	    env.put(Context.SECURITY_AUTHENTICATION, "simple");
	    env.put(Context.SECURITY_PRINCIPAL, adminName);
	    env.put(Context.SECURITY_CREDENTIALS, adminPassword);
	    DirContext ctx = new InitialLdapContext(env, null);
	    return ctx;
	}
	public static void main(String[] args) throws NamingException {
		LdapUserGroups ldap = new LdapUserGroups();
	    ldap.getUserDetail("dchauras@its.jnj.com","Shlok3012#");
	}





}