package com.jnj.rqc.sodrefresh.dao;

import java.sql.SQLException;

import org.springframework.dao.DataAccessException;

public interface SodRefreshDao {

	public String refreshMV(String serverEnv, String viewName) throws SQLException, DataAccessException;
	public String loadSodStagingData(String envName) throws SQLException, DataAccessException;
	public String refreshSODMailer(String envName) throws SQLException, DataAccessException;

}
