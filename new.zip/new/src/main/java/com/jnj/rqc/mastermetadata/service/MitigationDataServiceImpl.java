package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.mastermetadata.controller.MitigationData;
import com.jnj.rqc.mastermetadata.controller.MitigationDataDTO;
import com.jnj.rqc.mastermetadata.controller.MitigationReportDTO;
import com.jnj.rqc.mastermetadata.controller.MitigationRptMdl;
import com.jnj.rqc.mastermetadata.dao.MitigationDataRepository;

@Service
public class MitigationDataServiceImpl implements MitigationDataService{
	static final Logger log = LoggerFactory.getLogger(MitigationDataServiceImpl.class);

	private final MitigationDataRepository mitigationDataRepository;

    @Autowired
    public MitigationDataServiceImpl(MitigationDataRepository mitigationDataRepository) {
        this.mitigationDataRepository = mitigationDataRepository;
    }

    @Override
	public void insertMultipleRecords(List<MitigationData> records) {
    	log.debug("enter into the method");
    	mitigationDataRepository.insertMultipleRecords(records);
    	log.debug("end of the method");
    }
    @Override
	public void deleteAllRows(List<MitigationData> records) {
    	log.debug("enter into the method");
    	try {
    		mitigationDataRepository.deleteAllRows(records);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
        }
    	log.debug("end of the method");
    }

	@Override
	public MitigationDataDTO getAllMitigationData() {
		MitigationDataDTO reportDTO = new MitigationDataDTO();
		log.debug("enter into the method");
		try {
            List<MitigationData> allMitigationResults = mitigationDataRepository.getAllMitigationData();
            reportDTO.setStatusCode(200);
            reportDTO.setMitigationReports(allMitigationResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}
}
