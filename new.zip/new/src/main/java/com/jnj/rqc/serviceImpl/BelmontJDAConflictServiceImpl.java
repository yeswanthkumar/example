package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.HanaUserGrantModel;
import com.jnj.rqc.conflictModel.HanaUserPrivilegeModel;
import com.jnj.rqc.conflictModel.HanaUserRoleModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDACrsAppRoleMdl;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAMenuItemMdl;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.BelmontRoleConflictsDao;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportservice.RolesConflictPDFReportService;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.BelmontJDAConflictService;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>BelmontJDAConflictServiceImpl.java</b>
 * @author : DChauras @Created : Feb 17, 2021 4:06:19 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class BelmontJDAConflictServiceImpl implements BelmontJDAConflictService {
	static final Logger log = LoggerFactory.getLogger(BelmontJDAConflictServiceImpl.class);

	@Autowired
	BelmontRoleConflictsDao belmontRoleConflictsDao;

	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	RolesConflictPDFReportService rolesConflictPDFReportService;


	@Override
	public List<JDADBRiskModel> getUserLeverConflictsJDA(Map<String, List<String>> currentRoles) {
		List<JDADBRiskModel> user2SodLst = new ArrayList<>();

		// Read Excel
		Map<String, JDADBRiskModel> jdaDBRiskMap = null;
		if(Utility.getCache(Constants.JDA_DB_RISK) == null) {
			jdaDBRiskMap = getJDADBRiskData("");
			Utility.setCache(Constants.JDA_DB_RISK, jdaDBRiskMap);
		}else {
			jdaDBRiskMap = (Map<String, JDADBRiskModel>)Utility.getCache(Constants.JDA_DB_RISK);
		}
		user2SodLst = findViolatingRoles(currentRoles, jdaDBRiskMap);

		return user2SodLst;
	}


	@Override
	public List<JDAUser2SodModel> convertToJDAUser2SodModel(List<JDADBRiskModel> user2SodInternalNewRoles, UserSearchModel user) {
		List<JDAUser2SodModel> sodLst = new ArrayList<>();
		for(JDADBRiskModel mdl : user2SodInternalNewRoles) {
			JDAUser2SodModel sodMdl = new JDAUser2SodModel();
			sodMdl.setWwId(user.getWwId());
			sodMdl.setRiskId(mdl.getRiskId());
			sodMdl.setRiskDesc(mdl.getRiskDesc());
			sodMdl.setRoleId(mdl.getRoleId());
			sodMdl.setRoleName(mdl.getRoleName());
			sodMdl.setFuncId(mdl.getFuncId());
			sodMdl.setFuncDesc(mdl.getFuncDesc());
			sodMdl.setRiskLevel(mdl.getRiskLevel());
			sodMdl.setRegulation(mdl.getRegulation());
			sodMdl.setTrgtCon(mdl.getTrgtCon());
			sodMdl.setMitiCntrl(mdl.getMitiCntrl());
			sodMdl.setComplMgr(mdl.getComplMgr());
			sodMdl.setRulesetGpo(mdl.getRulesetGpo());
			sodLst.add(sodMdl);
		}
		return sodLst;
	}

	private List<JDADBRiskModel> findViolatingRoles(Map<String, List<String>> currentRoles, Map<String, JDADBRiskModel> jdaDBRiskMap){
		List<JDADBRiskModel> user2SodLst = new ArrayList<>();
		for (Map.Entry<String, List<String>> entry : currentRoles.entrySet()){
            String role = entry.getKey() ;
            List<String> actItems= entry.getValue();
            String key="";
            for(String item : actItems) {
            	key = role+"~"+item;
            	log.info("Serching for key :"+key);
            	if(jdaDBRiskMap.containsKey(key)) {
            		user2SodLst.add(jdaDBRiskMap.get(key));
            		log.info("Key :"+key+"...... Found in DB Risk");
            	}
            }
        }
		return user2SodLst;
	}

	@Override
	public Map<String, JDADBRiskModel> getJDADBRiskData(String riskIdFilter){
		log.info("Loding JDA Conflict Matrix Data from Database ");
		Map<String, JDADBRiskModel> dataMap = new HashMap<>();
		Map<String, JDADBRiskModel> outMap = new HashMap<>();
		try{

			List<JDADBRiskModel> matrixData =  belmontRoleConflictsDao.loadJDAConflictMatrix();
			if(matrixData != null && !matrixData.isEmpty()) {
				for(JDADBRiskModel rskMdl : matrixData) {
					dataMap.put(rskMdl.getRoleId()+"~"+rskMdl.getFuncId(), rskMdl);
				}
			}
		} catch (Exception e) {
			log.error("ERROR LOADING JDA INTRA-CONFLICT MATRIX :"+e.getMessage(), e);
		}
		//Filter User level Data
		if(riskIdFilter != null && riskIdFilter.length() > 0) {
			for(JDADBRiskModel rls:dataMap.values()) {
				if(rls.getRiskId().equals(riskIdFilter)) {
					outMap.put(rls.getRoleId()+"~"+rls.getFuncId(), rls);
				}
			}
		}else {
			outMap = dataMap;
		}
		log.info("DB Risk Total Records for Processed(outLst) : "+outMap.size());
		return outMap;
	}


	/*OLD METHOD TO READ DATA FROM EXCEL
	 * @Override
	public Map<String, JDADBRiskModel> getJDADBRiskData(String riskIdFilter){
		//String path = "D:/Users/DChauras/CSI/JDA/CONFLICT_MATRIX/JDA_DB_Risks.xlsx";
		log.info("Loding file :"+Constants.JDA_DBRISK_FILEPATH);
		Workbook nFile = Utility.loadFile(Constants.JDA_DBRISK_FILEPATH);
		Sheet dsheet = nFile.getSheetAt(0);
		Map<String, JDADBRiskModel> dataMap = new HashMap<String, JDADBRiskModel>();
		Map<String, JDADBRiskModel> outMap = new HashMap<String, JDADBRiskModel>();

		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				JDADBRiskModel rskMdl	= new JDADBRiskModel();
				String riskId	 		= Utility.getCellValue(rw.getCell(0));
				rskMdl.setRiskId(riskId);
				String riskDesc 		= Utility.getCellValue(rw.getCell(1));
				rskMdl.setRiskDesc(riskDesc);
				String roleName 			= Utility.getCellValue(rw.getCell(2));
				rskMdl.setRoleName(roleName);
				String roleId  		= Utility.getCellValue(rw.getCell(3));
				rskMdl.setRoleId(roleId);
				String funcId 			= Utility.getCellValue(rw.getCell(4));
				rskMdl.setFuncId(funcId);
				String funcDesc	  	= Utility.getCellValue(rw.getCell(5));
				rskMdl.setFuncDesc(funcDesc);
				String riskLevel  		= Utility.getCellValue(rw.getCell(6));
				rskMdl.setRiskLevel(riskLevel);
				String regulation		= Utility.getCellValue(rw.getCell(7));
				rskMdl.setRegulation(regulation);
				String trgtCon	 		= Utility.getCellValue(rw.getCell(8));
				rskMdl.setTrgtCon(trgtCon);
				String mitiCntrl		= Utility.getCellValue(rw.getCell(9));
				rskMdl.setMitiCntrl(mitiCntrl);
				String complMgr			= Utility.getCellValue(rw.getCell(10));
				rskMdl.setComplMgr(complMgr);
				String rulesetGpo 		= Utility.getCellValue(rw.getCell(11));
				rskMdl.setRulesetGpo(rulesetGpo);

				dataMap.put(rskMdl.getRoleId()+"~"+rskMdl.getFuncId(), rskMdl);
				i++;
			}
		}

		//Filter User level Data
		if(riskIdFilter != null && riskIdFilter.length() > 0) {
			for(JDADBRiskModel rls:dataMap.values()) {
				if(rls.getRiskId().equals(riskIdFilter)) {
					outMap.put(rls.getRoleId()+"~"+rls.getFuncId(), rls);
				}
			}
		}else {
			outMap = dataMap;
		}
		log.info("DB Risk Total Records for Processed(outLst) : "+outMap.size());
		return outMap;
	}
*/

	@Override
	public Map<String, JDACrossAppMatrixModel> loadJDACrossAppMatrix(String riskIdFilter){
		//String path = "D:/Users/DChauras/CSI/JDA/CONFLICT_MATRIX/JDA Cross-App Role and Conflict Matrix.xlsx";
		Map<String, JDACrossAppMatrixModel> dataMap = new HashMap<>();

		try {
			List<JDACrossAppMatrixModel> crsAppConfLst =  belmontRoleConflictsDao.loadJDACrossAppConflicts();
			if(crsAppConfLst != null && !crsAppConfLst.isEmpty()) {
				for(JDACrossAppMatrixModel appMdl: crsAppConfLst) {
					dataMap.put(appMdl.getRole1()+"~"+appMdl.getRole2(), appMdl);
				}
			}
		} catch (Exception e) {
			log.error("ERROR LOADING JDA CROSS-APP CONFLICT MATRIX :"+e.getMessage(), e);
		}
		log.info("JDA CROSS-APP Conflict MATRIX Total Records : "+dataMap.size());

		/*
		 log.info("Loding file :"+Constants.JDA_CROSSAPP_MATRIX_FILEPATH);
		Workbook nFile = Utility.loadFile(Constants.JDA_CROSSAPP_MATRIX_FILEPATH);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				JDACrossAppMatrixModel appMdl	= new JDACrossAppMatrixModel();
				String app1	 					= Utility.getCellValue(rw.getCell(0));
				appMdl.setApp1(app1);
				String app2 					= Utility.getCellValue(rw.getCell(1));
				appMdl.setApp2(app2);
				String role1 					= Utility.getCellValue(rw.getCell(2));
				appMdl.setRole1(role1);
				String role2  					= Utility.getCellValue(rw.getCell(3));
				appMdl.setRole2(role2);
				String conflict 		= role1+"\\"+role2;
				appMdl.setConflict(conflict);
				String mitigatingControl		= Utility.getCellValue(rw.getCell(4));
				appMdl.setMitigatingControl(mitigatingControl);


				dataMap.put(appMdl.getRole1()+"~"+appMdl.getRole2(), appMdl);
				i++;
			}
		}

		log.info("JDA CROSS-APP Conflict MATRIX Total Records : "+dataMap.size());
*/		return dataMap;
	}



	@Override
	public Map<String, List<StrKeyValPair>> loadJDATechNames(){
		//String path = "D:/Users/DChauras/CSI/JDA/CONFLICT_MATRIX/JDA Role Mapping.xlsx";
		log.info("Loding Technicle Role Mappings from DataBase.");
		Map<String, List<StrKeyValPair>> dataMap = new HashMap<>();
		try {
			List<StrKeyValPair> techDataLst =  belmontRoleConflictsDao.loadJDATechRoleMappings();
			if(techDataLst != null && !techDataLst.isEmpty()) {
				for(StrKeyValPair mdl : techDataLst) {
					String key = mdl.getKey();
					if(dataMap.containsKey(key)) {
						List<StrKeyValPair> dataLst = dataMap.get(key);
						if(!dataLst.contains(mdl)) {
							dataLst.add(mdl);
							dataMap.put(key, dataLst);
						}
					}else {
						List<StrKeyValPair> dataLst = new ArrayList<>();
						dataLst.add(mdl);
						dataMap.put(key, dataLst);
					}
				}
			}
			log.info("JDA ROLES Tech Names Total Records : "+dataMap.size());

		} catch (Exception e) {
			// TODO: handle exception
		}
		//Mapping Tech Names to Get User Friendly Names
		Map<String, String> techToUserFriendly = new HashMap<>();
		for(Map.Entry<String, List<StrKeyValPair>> entry:dataMap.entrySet()) {
			List<StrKeyValPair> tRls = entry.getValue();
			for(StrKeyValPair kv: tRls) {
				techToUserFriendly.put(kv.getVal(), kv.getKey());
			}
		}
		Utility.setCache(Constants.JDA_TECH_USRFR_NAMES,  techToUserFriendly);
		//END

		return dataMap;


		/*log.info("Loding file :"+Constants.JDA_TECH_ROLEMAP_FILEPATH);
		Workbook nFile = Utility.loadFile(Constants.JDA_TECH_ROLEMAP_FILEPATH);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows in Excel: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				StrKeyValPair mdl	= new StrKeyValPair();
				String key	 			= Utility.getCellValue(rw.getCell(0));
				mdl.setKey(key);
				String val 				= Utility.getCellValue(rw.getCell(1));
				mdl.setVal(val);

				if(dataMap.containsKey(key)) {
					List<StrKeyValPair> dataLst = dataMap.get(key);
					if(!dataLst.contains(mdl)) {
						dataLst.add(mdl);
						dataMap.put(key, dataLst);
					}
				}else {
					List<StrKeyValPair> dataLst = new ArrayList<StrKeyValPair>();
					dataLst.add(mdl);
					dataMap.put(key, dataLst);
				}
				i++;
			}
		}
		log.info("JDA ROLES Tech Names Total Records : "+dataMap.size());
		//Mapping Tech Names to Get User Friendly Names
			Map<String, String> techToUserFriendly = new HashMap<String, String>();
			for(Map.Entry<String, List<StrKeyValPair>> entry:dataMap.entrySet()) {
				List<StrKeyValPair> tRls = entry.getValue();
				for(StrKeyValPair kv: tRls) {
					techToUserFriendly.put(kv.getVal(), kv.getKey());
				}
			}
			Utility.setCache(Constants.JDA_TECH_USRFR_NAMES,  techToUserFriendly);
		//END

		return dataMap;*/
	}

	@Override
	@SuppressWarnings("all")
	public Map<String, List<String>> getMapForNewRoles(String data, int system){
		Map<String, List<String>> roleMap = new HashMap<>();
		try {
			List<JDAMenuItemMdl> result =  belmontRoleConflictsDao.getNewRolesActionJDA(data, system);
			if(result != null && !result.isEmpty()) {
				for(JDAMenuItemMdl pMdl:result) {
					if(roleMap.containsKey(pMdl.getRole())) {
						List<String> privLst = roleMap.get(pMdl.getRole());
						if(!privLst.contains(pMdl.getMenuItem())) {
							privLst.add(pMdl.getMenuItem());
							roleMap.put(pMdl.getRole(), privLst);
						}
					}else {
						List<String> privLst = new ArrayList<>();
						privLst.add(pMdl.getMenuItem());
						roleMap.put(pMdl.getRole(), privLst);
					}
				}
			}
			//This is a Fall back block --Need to remove this once Data is proper in Database
			String[] dataArr = data.split(",");
			for(String str:dataArr) {
				if(!roleMap.containsKey(str)) {
					roleMap.put(str, new ArrayList<>());
				}
			}
			//END fall back

		//Getting Menu Items

			if(roleMap != null  && !roleMap.isEmpty()) {
				Set<String> keySet = roleMap.keySet();
				for(String key : keySet) {
					List<JDAMenuItemMdl> menuList = belmontRoleConflictsDao.getJDAMenuItem(key, system);
					if(menuList !=null && menuList.size() >0) {
						List<String> roleLst = roleMap.get(key);
						for(JDAMenuItemMdl menu:menuList) {
							roleLst.add(menu.getMenuItem());
						}
						roleMap.put(key, roleLst);
					}
				}
			}
		} catch (Exception e) {
			log.error("Error getting Data for Role: "+e.getMessage(),e);
		}
		return roleMap;
	}

	@Override
	@SuppressWarnings("all")
	public Map<String, List<String>> getUserExistingRoles(String empWwid, int system){
		Map<String, List<String>> result = getUserRolesData(empWwid, system);
		if(result != null  && !result.isEmpty()) {
			Set<String> keySet = result.keySet();
			for(String key : keySet) {
				try {
					List<JDAMenuItemMdl> menuList = belmontRoleConflictsDao.getJDAMenuItem(key, system);
					if(menuList !=null && menuList.size() >0) {
						List<String> roleLst = result.get(key);
						for(JDAMenuItemMdl menu:menuList) {
							roleLst.add(menu.getMenuItem());
						}
						result.put(key, roleLst);
					}
				} catch (Exception e) {
					log.error("Error getting Menu Data for Role: "+key+"\n"+e.getMessage(),e);
				}
			}
		}
		return result;
	}

	@Override
	public Map<String, List<String>> getUserRolesData(String empWwid, int system){
		List<JDAPersonalSysMdl> result = new ArrayList<>();
		List<JDAPersonalSysMdl> otherRoles = new ArrayList<>();
		Map<String, List<String>> roleMap = new HashMap<>();
		try{
			result = belmontRoleConflictsDao.getUsersExistingRolesJDA(empWwid, system);
			//New Method of Data collection added on 03/18/2022
			otherRoles = belmontRoleConflictsDao.getUsersExistingClientRolesJDA(empWwid, system);
			if(otherRoles != null && !otherRoles.isEmpty()) {
				result.addAll(otherRoles);
			}
			//END of addition on 03/18/2022

			if(result != null && !result.isEmpty()) {
				//JDAPersonalSysMdl usrMdl= result.get(0);
				for(JDAPersonalSysMdl pMdl:result) {
					if(roleMap.containsKey(pMdl.getRole())) {
						List<String> privLst = roleMap.get(pMdl.getRole());
						if(!privLst.contains(pMdl.getAction())) {
							privLst.add(pMdl.getAction());
							roleMap.put(pMdl.getRole(), privLst);
						}
					}else {
						List<String> privLst = new ArrayList<>();
						privLst.add(pMdl.getAction());
						roleMap.put(pMdl.getRole(), privLst);
					}
				}
			}
		} catch (Exception e) {
			log.error("Error getting User Roles: "+e.getMessage(),e);
		}
		return roleMap;
	}

	@Override
	public List<JDAPersonalSysMdl> buildCurrentRolesData(HttpSession session, Map<String, List<String>> currentRoleMap, UserSearchModel userData) {
		List<JDAPersonalSysMdl> outLst = new ArrayList<>();
		for(Map.Entry<String, List<String>> entry:currentRoleMap.entrySet()) {
			String role = entry.getKey();
			List<String> actLst= entry.getValue();
			if(actLst != null && !actLst.isEmpty()) {
				for(String action:actLst) {
					JDAPersonalSysMdl mdl = new JDAPersonalSysMdl();
					mdl.setUserId(userData.getJnjMsftUsrnmTxt());
					mdl.setWwid(userData.getWwId());
					mdl.setFirstName(userData.getGivenNm());
					mdl.setLastName(userData.getFmlyNm());
					mdl.setUsrSts(userData.getEmpStatTxt());
					mdl.setRole(role);
					mdl.setSrcSystem("JDA");
					mdl.setSodCode("");
					mdl.setAction(action);
					outLst.add(mdl);
				}
			}   /*else {
				JDAPersonalSysMdl mdl = new JDAPersonalSysMdl();
				mdl.setUserId(userData.getJnjMsftUsrnmTxt());
				mdl.setWwid(userData.getWwId());
				mdl.setFirstName(userData.getGivenNm());
				mdl.setLastName(userData.getFmlyNm());
				mdl.setUsrSts(userData.getEmpStatTxt());
				mdl.setRole(role);
				mdl.setSrcSystem("JDA");
				mdl.setSodCode("");
				mdl.setAction("NO DATA FOUND");
				outLst.add(mdl);
			}*/
		}
		return outLst;
	}


	@SuppressWarnings("all")
	public Map<String, HanaUserRoleModel> readJDAMatrixData(String templSysParam) {
		Map<String, HanaUserRoleModel> roleMap = new HashMap<>();
		try {
			List<HanaUserGrantModel> grntData =null; //hANADataDao.getUserGrants(templSysParam);

			if(grntData != null) {
				int i=1;
				for(HanaUserGrantModel grntMdl:grntData) {
					if(Utility.isNumeric(grntMdl.getWwId())) {
						//log.info(i+". "+grntMdl);
						String wwid =  grntMdl.getWwId();
						if(roleMap.containsKey(wwid)) {
							HanaUserRoleModel rlMdl =  roleMap.get(wwid);
							String rlName = grntMdl.getRoleName();
							Map<String, List<HanaUserPrivilegeModel>> privMap = rlMdl.getRoles();
							if(privMap.containsKey(rlName)) {
								List<HanaUserPrivilegeModel> rivLst = privMap.get(rlName);
								HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
								newPriv.setRoleName(grntMdl.getRoleName());
								newPriv.setObjType(grntMdl.getObjType());
								newPriv.setObjName(grntMdl.getObjName());
								newPriv.setColName(grntMdl.getColName());
								newPriv.setPrivilege(grntMdl.getPrivilege());
								newPriv.setValid(grntMdl.getValid());
								rivLst.add(newPriv);
								privMap.put(rlName, rivLst);
							}else {
								List<HanaUserPrivilegeModel> rivLst = new ArrayList<>();
								HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
								newPriv.setRoleName(grntMdl.getRoleName());
								newPriv.setObjType(grntMdl.getObjType());
								newPriv.setObjName(grntMdl.getObjName());
								newPriv.setColName(grntMdl.getColName());
								newPriv.setPrivilege(grntMdl.getPrivilege());
								newPriv.setValid(grntMdl.getValid());
								rivLst.add(newPriv);
								privMap.put(rlName, rivLst);
							}
							rlMdl.setRoles(privMap);
							roleMap.put(wwid, rlMdl);
						}else {
							HanaUserRoleModel rlMdl =  new HanaUserRoleModel();
							rlMdl.setWwId(grntMdl.getWwId());
							rlMdl.setType(grntMdl.getType());

							List<HanaUserPrivilegeModel> privLst = new ArrayList<>();
							HanaUserPrivilegeModel newPriv = new HanaUserPrivilegeModel();
							newPriv.setRoleName(grntMdl.getRoleName());
							newPriv.setObjType(grntMdl.getObjType());
							newPriv.setObjName(grntMdl.getObjName());
							newPriv.setColName(grntMdl.getColName());
							newPriv.setPrivilege(grntMdl.getPrivilege());
							newPriv.setValid(grntMdl.getValid());
							privLst.add(newPriv);

							Map<String, List<HanaUserPrivilegeModel>> privMap = new HashMap<>();
							privMap.put(grntMdl.getRoleName(), privLst);
							rlMdl.setRoles(privMap);
							roleMap.put(grntMdl.getWwId(), rlMdl);
						}
					}
					i++;
				}
				log.info("User Grants - Total Records filtered : "+i +" Total Unique User Records collected: "+roleMap.size());

			}
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return roleMap;
	}


	@Override
	public List<String>getRolesFromPersonalSystem(String idToUse){
		List<String> psRoles = new ArrayList<>();
		try{
			List<JDACrsAppRoleMdl> currRlLst =  belmontRoleConflictsDao.getCrossAppRoles(idToUse);
			if(currRlLst != null && !currRlLst.isEmpty()) {
				for(JDACrsAppRoleMdl mtr: currRlLst) {
					psRoles.add(mtr.getAccessRole());
				}
			}
	} catch (Exception e) {
		log.error("Error: "+e.getMessage(),e);
	}
	return psRoles;
}



	@SuppressWarnings("all")
	@Override
	public List<MatrixModel> getCurConflictDetails(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> existingRoleConflicts = new ArrayList<>();
		try{
				existingRoleConflicts =  belmontRoleConflictsDao.getCurrentRolesConflict(data, empWwid);
				if(existingRoleConflicts != null && !existingRoleConflicts.isEmpty()) {
					for(MatrixModel mtr: existingRoleConflicts) {
						mtr.setWwid(empWwid);
					}
				}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return existingRoleConflicts;
	}

	@Override
	@SuppressWarnings("all")
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> newRoleConflicts = new ArrayList<>();
		try{
				if(data.length >1) {
					String sql = buildQuery(data);
					newRoleConflicts =  belmontRoleConflictsDao.getNewRolesConflict(sql);
					if(newRoleConflicts != null && !newRoleConflicts.isEmpty()) {
						for(MatrixModel mtr: newRoleConflicts) {
							mtr.setWwid(empWwid);
						}
					}
				}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		return newRoleConflicts;
	}

	@Override
	@SuppressWarnings("all")
	public List<JDACrossAppMatrixModel> getCrossAppConflictDetails(String empWwid, List<String> data){
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.size());
		List<JDACrossAppMatrixModel> conflicts = new LinkedList<>();
		try{
			Map<String, JDACrossAppMatrixModel> jdaCrsAppMap = null;
			if(Utility.getCache(Constants.JDA_CROSSAPP_MATRIX) == null) {
				jdaCrsAppMap = loadJDACrossAppMatrix("");
				Utility.setCache(Constants.JDA_CROSSAPP_MATRIX, jdaCrsAppMap);
			}else {
				jdaCrsAppMap = (Map<String, JDACrossAppMatrixModel>)Utility.getCache(Constants.JDA_CROSSAPP_MATRIX);
			}

			for (int i = 0; i < data.size(); i++) {
				for (int j = i+1; j < data.size(); j++) {
					String key1 = data.get(i) +"~"+data.get(j);
					String key2 = data.get(j) +"~"+data.get(i);
					if(jdaCrsAppMap.containsKey(key1)) {//Search key1
						JDACrossAppMatrixModel mdl =jdaCrsAppMap.get(key1);
						mdl.setWwid(empWwid);
						conflicts.add(mdl);
					}

					if(jdaCrsAppMap.containsKey(key2)) {//Search key2
						JDACrossAppMatrixModel mdl =jdaCrsAppMap.get(key2);
						mdl.setWwid(empWwid);
						conflicts.add(mdl);
					}
				}
			}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return conflicts;
	}


	private String buildQuery(String[] data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_EXTR.CONFLICT_MATRIX");
		sql.append(" WHERE (");
		for (int i = 0; i < data.length; i++) {
			for (int j = i+1; j < data.length; j++) {
				sql.append(" ( ROLE1 = "+data[i] +" AND ROLE2 = "+data[j]+") OR (ROLE2 = "+data[i] +" AND ROLE1 = "+data[j]+") ");
				if(i < (data.length -2)) {
					sql.append(" OR ");
				}
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, ROLE1, ROLE2 ");

		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}

	private String buildQuery(String[] data, String[] data2) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_EXTR.CONFLICT_MATRIX");
		sql.append(" WHERE (");
		for (String element : data) {
			for (int j = 0; j < data2.length; j++) {
				sql.append(" ( ROLE1 = "+element +" AND ROLE2 = "+data2[j]+") OR (ROLE2 = "+element +" AND ROLE1 = "+data2[j]+") ");
				if(j < (data2.length -1)) {
					sql.append(" OR ");
				}
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, ROLE1, ROLE2 ");

		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}










	@Override
	public String[] getRoleIdsPersonalSys(List<JDAPersonalSysMdl> psList) {
		String[] ids = new String[psList.size()];
		int i=0;
		for(JDAPersonalSysMdl ps:psList) {
			ids[i] = ps.getSodCode();
			i++;
		}
		return ids;
	}

	@Override
	public List<MatrixModel> getUserLevelConflictingRoles(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> newRoleConflicts = new ArrayList<>();
		try{
				if(data.length >1) {
					String sql = buildQuery(data);
					newRoleConflicts =  belmontRoleConflictsDao.getNewRolesConflict(sql);
					if(newRoleConflicts != null && !newRoleConflicts.isEmpty()) {
						for(MatrixModel mtr: newRoleConflicts) {
							mtr.setWwid(empWwid);
						}
					}
				}
		} catch (Exception e) {
			log.error("Error getting user conflicts: "+e.getMessage(),e);
		}

		return newRoleConflicts;
	}

	@Override
	public Map<String, SystemCodeModel> getSystemCodes() {
		Map<String, SystemCodeModel> sysMap = new HashMap<>();
		List<SystemCodeModel> sysCodeLst = new ArrayList<>();
		try{
			sysCodeLst = belmontRoleConflictsDao.getSystemCodes();
			if(sysCodeLst != null && !sysCodeLst.isEmpty()) {
				sysCodeLst.forEach(item ->{
					sysMap.put(item.getAccessRole().toUpperCase(), item);
				});
			}
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}

		return sysMap;
	}

	@Override
	public List<JDADBRiskModel> getConflictMatrix() {
		List<JDADBRiskModel> matrixMdlLst = new ArrayList<>();
		try{
			Map<String, JDADBRiskModel> jdaDBRiskMap = null;
			if(Utility.getCache(Constants.JDA_DB_RISK) == null) {
				jdaDBRiskMap = getJDADBRiskData("");
				Utility.setCache(Constants.JDA_DB_RISK, jdaDBRiskMap);
			}else {
				jdaDBRiskMap = (Map<String, JDADBRiskModel>)Utility.getCache(Constants.JDA_DB_RISK);
			}

			matrixMdlLst.addAll(jdaDBRiskMap.values());

		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}
		return matrixMdlLst;
	}

	@Override
	@SuppressWarnings("all")
	public List<JDACrossAppMatrixModel> getCrossAppConflictMatrix() {
		List<JDACrossAppMatrixModel> matrixMdl = new ArrayList<>();
		try{
			Map<String, JDACrossAppMatrixModel> jdaCrsAppMap = null;
			if(Utility.getCache(Constants.JDA_CROSSAPP_MATRIX) == null) {
				jdaCrsAppMap = loadJDACrossAppMatrix("");
				Utility.setCache(Constants.JDA_CROSSAPP_MATRIX, jdaCrsAppMap);
			}else {
				jdaCrsAppMap = (Map<String, JDACrossAppMatrixModel>)Utility.getCache(Constants.JDA_CROSSAPP_MATRIX);
			}
			matrixMdl.addAll(jdaCrsAppMap.values());
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}
		return matrixMdl;
	}

	@Override
	public List<StrKeyValPair> getTechRoleNames() {
		List<StrKeyValPair> techNms = new ArrayList<>();
		try{
			Map<String, List<StrKeyValPair>> techNmMap = null;
			if(Utility.getCache(Constants.JDA_ROLES_TECHNM) == null) {
				techNmMap = loadJDATechNames();
				Utility.setCache(Constants.JDA_ROLES_TECHNM, techNmMap);
			}else {
				techNmMap = (Map<String, List<StrKeyValPair>>)Utility.getCache(Constants.JDA_ROLES_TECHNM);
			}

			for(Map.Entry<String, List<StrKeyValPair>> entry:techNmMap.entrySet()) {
				techNms.addAll(entry.getValue());
			}
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}
		return techNms;
	}


	@Override
	@SuppressWarnings("all")
	public String getRoleUFNamesToTechNames(String ufName) {
		String[] ufArray = ufName.split(",");
		String outData = "";
		try{
			Map<String, List<StrKeyValPair>> techNmMap = null;
			if(Utility.getCache(Constants.JDA_ROLES_TECHNM) == null) {
				techNmMap = loadJDATechNames();
				Utility.setCache(Constants.JDA_ROLES_TECHNM, techNmMap);
			}else {
				techNmMap = (Map<String, List<StrKeyValPair>>)Utility.getCache(Constants.JDA_ROLES_TECHNM);
			}

			for(String ufNm:ufArray) {
				if(techNmMap.containsKey(ufNm)) {
					List<StrKeyValPair> techNms= techNmMap.get(ufNm);
					for(StrKeyValPair data:techNms) {
						if(outData.length() == 0) {
							outData+=data.getVal();
						}else {
							outData+=","+data.getVal();
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}
		return outData;
	}

	@Override
	public List<String>convertTechToUserFriendly(List<String> techNames){
		List<String> ufNames = new ArrayList<>();
		Map<String, String> techToUfMap = null;
		if(Utility.getCache(Constants.JDA_TECH_USRFR_NAMES)==null) {
			loadJDATechNames();
		}
		techToUfMap = (Map<String, String>)Utility.getCache(Constants.JDA_TECH_USRFR_NAMES);

		for(String tchNm:techNames) {
			if(techToUfMap.containsKey(tchNm)) {
				if(!ufNames.contains(techToUfMap.get(tchNm))) {
					ufNames.add(techToUfMap.get(tchNm));
				}
			}else {
				if(!ufNames.contains(tchNm)) {
					ufNames.add(tchNm);
				}
			}
		}
		return ufNames;
	}



	@Override
	public Map<String, List<String>> getSystemCodes(String data) {
		Map<String, List<String>> sysCdMap = getCodes(data.split(","));
		return sysCdMap;
	}

	@Override
	public Map<String, List<String>> getSystemCodes(String[] data) {
		Map<String, List<String>> sysCdMap = getCodes(data);
		return sysCdMap;
	}


	private Map<String, List<String>> getCodes(String[] data) {
		Map<String, List<String>> sysCdMap = new HashMap<>();
		List<String> sodLst = new ArrayList<>();
		List<String> invldRoles = new ArrayList<>();
		for(String rlName : data) {
			String sodCd = Utility.getSystemCode(rlName.toUpperCase());
			if(sodCd==null) {
				invldRoles.add(rlName);
			}else {
				sodLst.add(sodCd);
			}
		}
		sysCdMap.put("SYSCDLST", sodLst);
		sysCdMap.put("INVLDLST", invldRoles);
		return sysCdMap;
	}



	@Override
	public String writeTechRoleMapCSVReport(String fileNm, List<StrKeyValPair> userRoles) {
		String filePath = csvReportWriter.writeJDATechRolesCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", userRoles);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeUserRoleCSVReport(String fileNm, List<JDAPersonalSysMdl> userRoles) {
		String filePath = csvReportWriter.writeJDAUserRolesCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", userRoles);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeConfCSVReport(String fileNm, List<JDAUser2SodModel> roleConflictList) {
		String filePath = csvReportWriter.writeJDAConfCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", roleConflictList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeCrossAppConfCSVReport(String fileNm, List<JDACrossAppMatrixModel> roleConflictList) {
		String filePath = csvReportWriter.writeJDACrossAppConfCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", roleConflictList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}



	@Override
	public String writeSystemCodeCSVReport(String fileNm, List<SystemCodeModel> sysCdLst) {
		String filePath = csvReportWriter.writeSystemCdCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", sysCdLst);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeConflictMatrixCSVReport(String fileNm, List<JDADBRiskModel> matrixList) {
		String filePath = csvReportWriter.writeJDAItraMatrixCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", matrixList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeCrossAppMatrixCSVReport(String fileNm, List<JDACrossAppMatrixModel> matrixList) {
		String filePath = csvReportWriter.writeJDACrossAppMatrixCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", matrixList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}




	@Override
	public Map<String, List<JDAPersonalSysMdl>> getMultiUserExistingRoles(List<String> empIds) {
		Map<String, List<JDAPersonalSysMdl>> outMap = new HashMap<>();
		try{
			List<JDAPersonalSysMdl> dataList = belmontRoleConflictsDao.getUsersExistingRoles(empIds);
			for(JDAPersonalSysMdl pmodel:dataList) {
				//String usrKey = pmodel.getUserId()+"_"+pmodel.getWwid();
				String usrKey = ""+pmodel.getWwid();
				if(outMap.containsKey(usrKey)) {
					List<JDAPersonalSysMdl> usrLst = outMap.get(usrKey);
					usrLst.add(pmodel);
					outMap.put(usrKey, usrLst);
				}else {
					List<JDAPersonalSysMdl> usrLst = new ArrayList<>();
					usrLst.add(pmodel);
					outMap.put(usrKey, usrLst);
				}
			}
		} catch (Exception e) {
			log.error("Error getting User Roles: "+e.getMessage(),e);
		}
		return outMap;
	}




}
