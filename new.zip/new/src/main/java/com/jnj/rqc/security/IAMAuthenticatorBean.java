package com.jnj.rqc.security;


import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.constants.AuthRespMdl;
import com.jnj.rqc.constants.AuthStrMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.util.Utility;




/**
 * File    : <b>IAMAuthenticatorBean.java</b>
 * @author : DChauras @Created : Jun 21, 2022 9:47:56 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Component ("IAMAuthenticatorBean")
public class IAMAuthenticatorBean
{
	static final Logger log = LoggerFactory.getLogger(IAMAuthenticatorBean.class);
	private String sessionId;
	private String userSAAcct;
	private Date loginTime;
	private RestTemplate restHttpTemplate;

	private static IAMAuthenticatorBean iamAuth;


	private IAMAuthenticatorBean() {
		super();
		loginTime = new Date();
	}


	public IAMAuthenticatorBean initIAMAuth(RestTemplate restHttpTemplate) {
		log.info("Checking Connection status to IAM");
		if(iamAuth == null || !isSessAlive()) {
			iamAuth = new IAMAuthenticatorBean();
			iamAuth.setTemplate(restHttpTemplate);
			try{
				log.info("Login to IDMS ");
				Gson gson = new Gson();
				AuthStrMdl mdl= new AuthStrMdl();
				mdl.setAuthString(Constants.IAM_MODULE+Constants.IAM_USER+Constants.IAM_PWD);

				String reqElement = gson.toJson(mdl);
				log.info("Request: "+reqElement);

				// set headers
				HttpHeaders headers = getHeaders("JSON", null);
				HttpEntity<String> entity = new HttpEntity<>(reqElement, headers);

				// send request and parse result
				//ResponseEntity<String> authResp = restTemplate.exchange(authURL, HttpMethod.POST, entity, String.class);
				ResponseEntity<String> authResp = restHttpTemplate.exchange(Constants.authURLIAM, HttpMethod.POST, entity, String.class);

				if (authResp != null && authResp.getStatusCode() == HttpStatus.OK) {
					log.info("Login successfully to IAM");
					AuthRespMdl resp = new AuthRespMdl();
					resp = gson.fromJson(authResp.getBody(), AuthRespMdl.class);
					iamAuth.sessionId = resp.getSessionId();
					iamAuth.userSAAcct=resp.getUserName();
					log.info("IAM Details USER: "+resp.getUserName()+" Session ID: "+resp.getSessionId());
				}else {
					iamAuth.sessionId  = null;
					iamAuth.userSAAcct = null;
				}
			}catch(Exception ex) {
				log.error("Exception "+ ex.getMessage(), ex);
				iamAuth.sessionId  = null;
				iamAuth.userSAAcct = null;
			}
		}
		return iamAuth;
    }


	private boolean isSessAlive() {
		boolean valid = true;
		if(iamAuth == null || iamAuth.sessionId == null) {
			valid = false;
		}else {
			Date curTime = new Date();
			long timeDiff = (curTime.getTime() - iamAuth.loginTime.getTime());
			if(timeDiff > (1000*60*50)) {
				valid = false;
			}else {
				valid = true;
			}
		}
		return valid;
	}

	public String getSessId() {
		return iamAuth.sessionId;
	}

	public void setTemplate(RestTemplate restTemp) {
		iamAuth.restHttpTemplate = restTemp;
	}

	private HttpHeaders getHeaders(String mediaTyp, String sessionId) {
		HttpHeaders headers = new HttpHeaders();
		if(Utility.isEmpty(mediaTyp) || "JSON".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}else if("TEXT".equals(mediaTyp)) {
			headers.setContentType(MediaType.TEXT_PLAIN);
		}

		if(!Utility.isEmpty(sessionId)) {
			headers.add("Cookie", "ss-id="+sessionId);
		}
		return headers;
	}



}