package com.jnj.rqc.service;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.jnj.rqc.models.UserRole;


/**
 * File    : <b>PVCSUserExtract.java</b>
 * @author : DChauras @Created : Apr 26, 2019 11:42:53 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface PVCSUserDataService {
	public List<UserRole> createUserCSV(Path filePath, HttpSession session);
	public Map<String, List<String>> readPVCSUserData(Path filePath);
}
