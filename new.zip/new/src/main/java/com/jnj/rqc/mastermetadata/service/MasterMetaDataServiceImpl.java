package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.mastermetadata.controller.MasterData;
import com.jnj.rqc.mastermetadata.dao.MasterMetaDataRepository;

@Service
public class MasterMetaDataServiceImpl implements MasterMetaDataService{
	static final Logger log = LoggerFactory.getLogger(MasterMetaDataServiceImpl.class);

	private final MasterMetaDataRepository masterRepository;

    @Autowired
    public MasterMetaDataServiceImpl(MasterMetaDataRepository masterRepository) {
        this.masterRepository = masterRepository;
    }

    @Override
	public void insertMultipleRecords(List<MasterData> records) {
    	log.debug("enter into the method");
    	masterRepository.insertMultipleRecords(records);
    	log.debug("end of the method");
    }
    @Override
	public void deleteAllRows() {
    	masterRepository.deleteAllRows();
    }
}
