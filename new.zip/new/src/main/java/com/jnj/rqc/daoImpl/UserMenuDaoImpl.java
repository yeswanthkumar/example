package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.util.Utility;



/**
 * File    : <b>UserMenuServiceDaoImpl.java</b>
 * @author : DChauras @Created : Feb 18, 2021 12:53:56 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Repository
public class UserMenuDaoImpl  extends BaseDao implements UserMenuDao {
	static final Logger log = LoggerFactory.getLogger(UserMenuDaoImpl.class);

	@Override
	public Map<Integer, String> getUserHeaderMenus(String userId, String adGrp, HttpServletRequest request) throws SQLException, DataAccessException {
		Map<Integer, String> menuMap = new HashMap<>();
		String enableAdGrpMenu = Utility.getServerProp("ENABLE_ADGROUP_MENUS");
		UserSearchModel usr = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		userId = usr.getJnjMsftUsrnmTxt().toUpperCase();
		boolean isAdmin = checkAdminAccess(userId);

		String userName = "";
		if(usr != null) {
			userName = usr.getFmlyNm()+", "+usr.getGivenNm();
		}
		int menuCounter=0;
		List<String> userGroups = (List<String>)request.getSession().getAttribute(Constants.USER_GROUPS);
		menuMap.put(++menuCounter, "<a href='/RQCUtils/home'><img src='/RQCUtils/images/homeicon.jpg' height=25 width=85 /></a>");
		menuMap.put(++menuCounter, "<a href='http://browsejjeds.jnj.com' target='_blank'>JJEDS</a>");
		menuMap.put(++menuCounter, "<a href='https://jnjprod.service-now.com/iris?id=irisgl_home' target='_blank'>IRIS</a>");

		if(null == enableAdGrpMenu || "N".equals(enableAdGrpMenu)) {
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/HCS' >HCS</a>");
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/HANA' >HANA</a>");
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/CSI' >CSI Based</a>");
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/BELMONT' >BlueYonder/JDA</a>");
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/SAPEXTRGAA' >SAP Extraction</a>");
			/*menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/SAPEXTRCSI' >SAP Extraction - CSI</a>");*/
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/ADMIN' >Administration</a>");
			menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/USERS' >User Request</a>");
			/*menuMap.put(++menuCounter, "<input type='text' placeholder='Search..' name='search'><button type='submit'><i class='fa fa-search'></i></button>");*/


		}else{
			if(userGroups != null && !userGroups.isEmpty()) {
				if(userGroups.contains("JJC-Tools-HCS-SOD-Analysis")) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/HCS' >HCS</a>");
				}
				if(userGroups.contains("JJC-Tools-HANA-SOD-Analysis")) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/HANA' >HANA</a>");
				}
				if(userGroups.contains("JJC-Tools-CSI-SOD-Reporting")) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/CSI' >CSI Based</a>");
				}
				if(userGroups.contains("JJC-Tools-BelmontJDA-IntraCrossAppMatrix-SOD-Reporting")) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/BELMONT' >BlueYonder/JDA</a>");
				}
				if(userGroups.contains("JJC-Tools-SAPExtraction-SAPGAA-Control")) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/SAPEXTRGAA' >SAP Extraction</a>");
				}
				/*if(userGroups.contains("JJC-Tools-SAPExtraction-TransferControls-Region") || userGroups.contains("JJC-Tools-SAPExtraction-UsertoRole-Region") || isAdmin) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/ADMIN' >Administration</a>");
				}*/
				if(isAdmin) {
					menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/ADMIN' >Administration</a>");
				}
				menuMap.put(++menuCounter, "<a href='/RQCUtils/homeOrg/USERS' >Users</a>");
			}
		}

		/*menuMap.put(++menuCounter, "<a href='/RQCUtils/contact' class='right'>Contact Us</a>");*/
		menuMap.put(++menuCounter, "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' class='right' placeholder='Search..' name='search'><img src='/RQCUtils/images/srch.jpg' height=18 width=22  valign='bottom'/>");
		menuMap.put(++menuCounter, "<a href='/RQCUtils/logout' class='right'><img src='/RQCUtils/images/logout.jpg' height=25 width=75 /></a>");
		menuMap.put(++menuCounter, "<a href='#' onclick=\"window.open('/RQCUtils/getUserPersonalInfo/2', 'userProfileWindow', 'location=no,toolbar=no,menubar=no,directories=no,resizable=no, width=600, height=400, top=150, left=500');\" class='right'> <img src='/RQCUtils/images/user3.jpg' height='16' width='22' valign='bottom' />&nbsp;"+userName+"</a>");

		return menuMap;
	}

	@Override
	public Map<Integer, String> getMenuSideNav(String menuId, UserSearchModel user, HttpServletRequest request) throws SQLException, DataAccessException {
		Map<Integer, String> menuMap = new HashMap<>();
		menuMap.put(1, getMenuByName(menuId, user, request));
		return menuMap;
	}

	@SuppressWarnings("unchecked")
	private String getMenuByName(String name, UserSearchModel user, HttpServletRequest request) {
		String userId = user.getJnjMsftUsrnmTxt().toUpperCase();
		boolean isAdmin = checkAdminAccess(userId);
		List<String> userGroups = (List<String>)request.getSession().getAttribute(Constants.USER_GROUPS);
		String enableAdGrpMenu = Utility.getServerProp("ENABLE_ADGROUP_MENUS");
		String retMenu="";
		String reqContext = "/RQCUtils";
		String HCS = "<li><div class='dropdown'><button onclick='togDDConflicts()' class='dropbtn'>HCS SOD Matrix &amp; Reports</button>"+
					 "<div id='conflictDropdown' class='dropdown-content'>";
					 if(null == enableAdGrpMenu || "N".equals(enableAdGrpMenu)) {
						 HCS+="<a href='"+reqContext+"/searchUserConflicts'>User Level SOD Analysis &amp; Reports</a>"+
								 "<a href='"+reqContext+"/reviewMultiUser'>View(multi-users) Roles/Conflicts</a>"+
								 "<a href='"+reqContext+"/searchSystemCodesPage'>View Application Role Names</a>"+
								 "<a href='"+reqContext+"/loadConflicts'>View Conflict Matrix </a>"+
								 "<a href='"+reqContext+"/navManualExtrUpdates'>Update Extract Table Data</a>";
					 }else {
						 if(userGroups.contains("JJC-Tools-HCS-SOD-Analysis") || isAdmin) {
							 HCS+="<a href='"+reqContext+"/searchUserConflicts'>User Level SOD Analysis &amp; Reports</a>"+
									 "<a href='"+reqContext+"/reviewMultiUser'>View(multi-users) Roles/Conflicts</a>"+
									 "<a href='"+reqContext+"/searchSystemCodesPage'>View Application Role Names</a>"+
									 "<a href='"+reqContext+"/loadConflicts'>View Conflict Matrix </a>"+
									 "<a href='"+reqContext+"/navManualExtrUpdates'>Update Extract Table Data</a>";
						 }
					 }

					 //<a th:href="@{/rqcSapConflictInfo}">Check Conflicts of New Role(s)</a>
					 HCS+="</div></div></li>";
		String HANA = "<li><div class='dropdown'><button onclick='togDDCsiCm();' class='dropbtn'>HANA SOD Matrix &amp; Reports</button>"+
					"<div id='csiCmDropdown' class='dropdown-content'>"+
					"<a href='"+reqContext+"/loadHanaUserToSODPage'>User Level SOD Analysis &amp; Reports</a>"+
					"<a href='"+reqContext+"/loadHanaRolesToSODPage'>Role Level SOD Analysis &amp; Reports</a>"+
					"<a href='"+reqContext+"/loadHanaConflictMatrix'>HANA - Conflict Matrix</a>"+
					"</div></div></li>";
		String CSI = "<li><div class='dropdown'><button onclick='togDDCsi();' class='dropbtn'>CSI SOD Matrix &amp; Reports</button>"+
					"<div id='csiDropdown' class='dropdown-content'>"+
					"<a href='"+reqContext+"/loadCSIUserToSODPage'>User Level SOD Analysis &amp; Reports</a>"+
					"<a href='"+reqContext+"/loadCSIRoleToSODPage'>Role Level SOD Analysis &amp; Reports</a>"+
					"<a href='"+reqContext+"/loadCSISodRisk'>SOD Risk </a>"+
					"<a href='"+reqContext+"/loadCSICriticalActRisk'>Critical Action Risk </a>"+
					"<a href='"+reqContext+"/loadCSIFunctionAction'>Function Action</a>"+
					"<a href='"+reqContext+"/loadCSIFunctionPermission'>Function Permission</a> "+
					"</div></div></li>";
		String SAPEXTRGAA = "<li><div class='dropdown'><button onclick='togSapExtraction();' class='dropbtn'>SAP Extraction - Controls</button>"+
					"<div id='sapExtractionDropdown' class='dropdown-content'>";
					if(null == enableAdGrpMenu || "N".equals(enableAdGrpMenu)) {
						SAPEXTRGAA +="<a href='"+reqContext+"/loadSapUserAccessProvPage'>SAP-Transfer Control</a>"+
								"<a href='"+reqContext+"/loadSapExtrPageAM03'>SAP-User to Role </a>"+
								"<a href='"+reqContext+"/loadSapExtrUser2CriticalPage'>SAP User-Critical Role</a>"+
								"<a href='"+reqContext+"/loadJdeTrfControl'>JDE-Transfer Control</a>"+
								"<a href='"+reqContext+"/loadJDEUser2RolePage'>JDE-User to Role</a>"+
								"<a href='"+reqContext+"/loadJDEUser2CriticalPage'>JDE-User to Critical Role</a>"+
								"<a href='"+reqContext+"/loadHCSUser2RolePage'>HCS/BRAVO-User to Role</a>"+
								"<a href='"+reqContext+"/loadHanaTrfControl'>HANA - Transfer Control</a>"+
								"<a href='"+reqContext+"/loadHanaUser2RolePage'>HANA - User to Role</a>"+
								"<a href='"+reqContext+"/loadUser2SodPage'>SAP - User to SOD</a>"+
								"<a href='"+reqContext+"/loadDialogUser2Role'>User to Role -(Non-Dialog Users) </a>";
					}else {
						if(userGroups.contains("JJC-Tools-SAPExtraction-SAPGAA-Control") || isAdmin) {
							SAPEXTRGAA +="<a href='"+reqContext+"/loadSapUserAccessProvPage'>SAP-Transfer Control</a>"+
									"<a href='"+reqContext+"/loadSapExtrPageAM03'>SAP-User to Role </a>"+
									"<a href='"+reqContext+"/loadSapExtrUser2CriticalPage'>SAP User-Critical Role</a>"+
									"<a href='"+reqContext+"/loadJdeTrfControl'>JDE-Transfer Control</a>"+
									"<a href='"+reqContext+"/loadJDEUser2RolePage'>JDE-User to Role</a>"+
									"<a href='"+reqContext+"/loadJDEUser2CriticalPage'>JDE-User to Critical Role</a>"+
									"<a href='"+reqContext+"/loadHCSUser2RolePage'>HCS/BRAVO-User to Role</a>"+
									"<a href='"+reqContext+"/loadHanaTrfControl'>HANA - Transfer Control</a>"+
									"<a href='"+reqContext+"/loadHanaUser2RolePage'>HANA - User to Role</a>"+
									"<a href='"+reqContext+"/loadUser2SodPage'>SAP - User to SOD</a>"+
									"<a href='"+reqContext+"/loadDialogUser2Role'>User to Role -(Non-Dialog Users) </a>";
						}
					}

				if(userGroups.contains("JJC-Tools-SAPExtraction-TransferControls-Region") || isAdmin) {
					SAPEXTRGAA += "<a href='"+reqContext+"/sapExtrTrfCntrl1ClickPage'>Transfer Control - Region wise</a>";
				}
				if(userGroups.contains("JJC-Tools-SAPExtraction-UsertoRole-Region") || isAdmin) {
					SAPEXTRGAA += " <a href='"+reqContext+"/sapUser2RoleOneClickPage'>User to Role - Region wise</a>"+
							"<a href='"+reqContext+"/sapUser2CriticalRoleOneClickPage'>User-Critical Role - Region wise</a>"+
							"<a href='"+reqContext+"/sapExtrUser2Sod1ClickPage'>User to SOD - Region wise</a>";
				}

				SAPEXTRGAA += "</div></div></li>";
				/*"<a href='"+reqContext+"/duUser2RoleOneClickPage'>User to Role - Region wise(Non-Dialog Users)</a>"+*/


		String BELMONT = "<li><div class='dropdown'><button onclick='togDDBelmont();' class='dropbtn'>BlueYonder/JDA Intra &amp; Cross-App SOD Matrix&amp; Reports</button>"+
					"<div id='belmontDropdown' class='dropdown-content'>"+
					"<a href='"+reqContext+"/searchBelmontUserConflicts'>User Level SOD Analysis &amp; Reports</a>"+
					"<a href='"+reqContext+"/loadBelmontConflictMatrix'>JDA(INTRA) Conflict Matrix </a>"+
					"<a href='"+reqContext+"/loadJDACrossAppConflictMatrix'>JDA(CROSS-APP) Conflict Matrix </a>"+
					"<a href='"+reqContext+"/loadJDATechRoleNames'>View Role Mappings</a>"+
					/*"<a href='"+reqContext+"/reviewBelmontMultiUser'>View(multi-users) Roles/Conflicts</a>"+*/
					/*"<a href='"+reqContext+"/searchBelmontSystemCodesPage'>View Application Role Names</a>"+*/
					"</div></div></li>";

		String USERS = "<li><div class='dropdown'><button onclick='togDDUserActions();' class='dropbtn'>User Request</button>"+
				"<div id='userActionsDropdown' class='dropdown-content'>"+
				"<a href='"+reqContext+"/startUserRequest'>Create New User Request</a>"+
				"<a href='"+reqContext+"/showAllNewRequests'>Retrieve Existing Request</a>"+
				"<a href='"+reqContext+"/approveNewRequests'>Compliance Page</a>"+
				"<a href='"+reqContext+"/updateUIMasterData'>Update Master Data</a>"+
				"<a href='"+reqContext+"/updateUIConflictMetrixData'>Update Conflict Metrics</a>"+
				"<a href='"+reqContext+"/updatUIExcessiveAccess'>Update Excessive Access</a>"+
				"<a href='"+reqContext+"/login2Anaplan'> Anaplan Connect</a>"+
				"<a href='"+reqContext+"/getExpDef'> Anaplan Download</a>"+
				"<a href='"+reqContext+"/uploadNewDef'> Anaplan Upload</a>"+
				"<a href='"+reqContext+"/getIndividualExportDef?emailId=dchauras@its.jnj.com'> Anaplan Email Dimension</a>"+
				/*"<a href='"+reqContext+"/login2Iam'> IAM Connect</a>"+
				"<a href='"+reqContext+"/getNewAccessSelectionPage'> New Work Flow</a>"+
				"<a href='"+reqContext+"/loadNewUserRoleSelection'>Create New Request</a>"+
				"<a href='"+reqContext+"/loadUserRoleSelection'>New Request</a>"+
				"<a href='"+reqContext+"/showAllRequests'>Search Request</a>"+
				"<a href='"+reqContext+"/getMyRequestData'>My Request's</a>"+
				"<a href='"+reqContext+"/getApprovalQueue'>My Approval Queue</a>"+*/
				"</div></div></li>";

		String ADMIN = "<li><div class='dropdown'><button onclick='togAdminCntrls();' class='dropbtn'>Admin - Controls</button>"+
				"<div id='adminDropdown' class='dropdown-content'>";
				//if("VE1".equals(userId) || "DKASTUR2".equals(userId) || "DCHAURAS".equals(userId) || "LKODAVAT".equals(userId) || "AACOST12".equals(userId) || "AMUNUSW2".equals(userId) || "JDABAO".equals(userId)) {
				if(isAdmin) {
					ADMIN +="<a href='"+reqContext+"/triggerTransferControlWeeklyReport'>Trigger TRF CNTRL Weekly Emails/Report</a>"+
							"<a href='"+reqContext+"/triggerUser2RoleWeeklyReport'>Trigger USER2ROLE Weekly Emails/Report</a>"+
							"<a href='"+reqContext+"/triggerUser2SodWeeklyReport'>Trigger USER2SOD Weekly Emails/Report</a>"+
							"<a href='"+reqContext+"/processUser2RoleDeltaReport'>Trigger - USER2ROLE Delta Report</a>"+
							"<a href='"+reqContext+"/processUser2SodDeltaReport'>Trigger - USER2SOD Delta Report</a>"+
							"<a href='"+reqContext+"/uploadManualTrfContrlData'>Manual - Process Transfer Control</a>"+
							"<a href='"+reqContext+"/uploadManualUser2RoleData'>Manual - Process User to Role</a>"+
							"<a href='"+reqContext+"/uploadManualUser2SodData'>Manual - Process User to SOD</a>"+
							"<a href='"+reqContext+"/uploadMitigatingCntrlFile'>UpLoad Mitigating Cntrl(USER2SOD)</a>"+
							"<a href='"+reqContext+"/uploadReviverDetails'>Load SAP Reviewer Data(USER2SOD)</a>"+
							"<a href='"+reqContext+"/uploadMerReviverDetails'>Load Mercury Reviewer Data(USER2SOD)</a>"+
							"<a href='"+reqContext+"/triggerSodRefresh'>Trigger - SOD REFRESH (HCS)</a>"+
							"<a href='"+reqContext+"/'>Archive Transfer Controls - Data</a>"+
							"<a href='"+reqContext+"/'>Archive User to Role - Data</a>";
				}
				//Added for CSM DATA
				ADMIN += "<a href='"+reqContext+"/processInitCSMData'>Build CSM Data(LDAP)</a>";
				ADMIN += "<a href='"+reqContext+"/uploadCSMHistData'>Upload - CSM Archieve Data  </a>";
				ADMIN += "<a href='"+reqContext+"/uploadCSMModelData'>Upload - CSM Model Data  </a>";
				ADMIN +="</div></div></li>";

		/*<li>
		<div class="dropdown">
				<button onclick="togDDCsiMatrix()" class="dropbtn">SOD Matrix - CSI</button>
				<div id="csiMatrixDropdown" class="dropdown-content">
					<a th:href="@{/loadCSISodRisk}">SOD Risk </a>
					<a th:href="@{/loadCSICriticalActRisk}">Critical Action Risk </a>
					<a th:href="@{/loadCSIFunctionAction}">Function Action</a>
					<a th:href="@{/loadCSIFunctionPermission}">Function Permission</a>
				</div>
		</div>
	</li>*/
		if("HCS".equals(name)) {
			retMenu = HCS;
		}else if("HANA".equals(name)) {
			retMenu = HANA;
		}else if("CSI".equals(name)) {
			retMenu = CSI;
		}else if("SAPEXTRGAA".equals(name)) {
			retMenu = SAPEXTRGAA;
		}else if("BELMONT".equals(name)) {
			retMenu = BELMONT;
		}
		else if("ADMIN".equals(name)) {
			retMenu = ADMIN;
		}
		else if("USERS".equals(name)) {
			retMenu = USERS;
		}
		return retMenu;
	}

	private boolean checkAdminAccess(String userId) {
		boolean isAdm = false;
		try{
			String ids = getUtilsConstVals(Constants.ADM_IDS);
			if(ids != null && ids.length() > 0){
				String[] idArr = ids.split(",");
				if(idArr != null && idArr.length > 0) {
					for (String element : idArr) {
						if(userId.equals(element.trim().toUpperCase())) {
							isAdm = true;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Error getting CONSTANT Values : "+e.getMessage(), e);
		}
		return isAdm;
	}

	@Override
	public String getUtilsConstVals(String cid) throws SQLException, DataAccessException {
		String value="";
		String qry = " SELECT C_VAL FROM SOD_DB_USER.UTILS_CONST " +
					 " WHERE C_VALID= 'Y' AND C_ID = ? ";
		value = getJdbcTemplateSRADUtils().queryForObject(qry, new Object[] {cid}, String.class);
		return value;
	}


	@Override
	public int getUtilsConstExcsvVals(String cid) throws SQLException, DataAccessException {
		int percentage = 70;
		String value = getUtilsConstVals(cid);
		if(!StringUtils.isEmpty(value)) {
			try {
				percentage = Integer.parseInt(value);
			} catch (Exception e) {
				percentage = 70;
				log.error("Error getting Excessive/Restrictive Access value: "+e.getMessage(), e);
			}
		}
		return percentage;
	}

}
