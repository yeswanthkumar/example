package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class HanaRoleUserPrivilegeMdl {
	private String granteeSchemaName;
	private String grantee;
	private String granteeType;
	private String grantor;
	private String objectType;
	private String schemaName;
	private String objectName;
	private String columnName;
	private String privilege;
	private String isGrantable;
	private String isValid;


	@Override
	public String toString() {
		return "HanaRoleUserPrivilegeMdl [granteeSchemaName=" + granteeSchemaName + ", grantee=" + grantee
				+ ", granteeType=" + granteeType + ", grantor=" + grantor + ", objectType=" + objectType
				+ ", schemaName=" + schemaName + ", objectName=" + objectName + ", columnName=" + columnName
				+ ", privilege=" + privilege + ", isGrantable=" + isGrantable + ", isValid=" + isValid + "]";
	}

}
