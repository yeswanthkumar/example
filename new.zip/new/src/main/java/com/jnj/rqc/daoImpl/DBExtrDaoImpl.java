package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.dbextr.models.CcraConversionMdl;
import com.jnj.rqc.dbextr.models.CcraExtractMdl;
import com.jnj.rqc.dbextr.models.CcraStageMdl;
import com.jnj.rqc.dbextr.models.ConflictMatrixMdl;
import com.jnj.rqc.dbextr.models.F0005Mdl;
import com.jnj.rqc.dbextr.models.F00821Mdl;
import com.jnj.rqc.dbextr.models.F0082Mdl;
import com.jnj.rqc.dbextr.models.F983051Mdl;
import com.jnj.rqc.dbextr.models.F9860Mdl;
import com.jnj.rqc.dbextr.models.F9861Mdl;
import com.jnj.rqc.dbextr.models.F9865Mdl;
import com.jnj.rqc.dbextr.models.SystemCodeMdl;
import com.jnj.rqc.reportmodels.ReportDataModel;




@Service
public class DBExtrDaoImpl  extends BaseDao implements DBExtrDao {
	static final Logger log = LoggerFactory.getLogger(DBExtrDaoImpl.class);



	@Override
	public List<SystemCodeMdl> getSystemCodeData()throws SQLException, DataAccessException {
		List<SystemCodeMdl> sysData = new ArrayList<>();
		String sql = " SELECT SRC_SYSTEM, ACCESS_ROLE, SOD_CODE FROM SOD_EXTR.SYSTEM_CODE";

		sysData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SystemCodeMdl.class));
		log.info("Total rows returned : "+((sysData !=null) ? sysData.size():"0"));
		return sysData;
	}


	@Override
	public List<ConflictMatrixMdl> getConflictMatrixData() throws SQLException, DataAccessException {
		List<ConflictMatrixMdl> confData = new ArrayList<>();
		String sql = " SELECT ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL FROM SOD_EXTR.CONFLICT_MATRIX ";
		confData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(ConflictMatrixMdl.class));
		log.info("Total rows returned : "+((confData !=null) ? confData.size():"0"));
		return confData;
	}



	@Override
	public List<CcraConversionMdl> getCCRAConversionData() throws SQLException, DataAccessException {
		List<CcraConversionMdl> conData = new ArrayList<>();
		String sql = " SELECT ROLE_NAME, SOD_CODE, SRC_SYSTEM, NOTES FROM SOD_EXTR.CCRA_CONVERSION ";
		conData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(CcraConversionMdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	@Override
	public List<CcraExtractMdl> getCCRAExtractData() throws SQLException, DataAccessException {
		List<CcraExtractMdl> conData = new ArrayList<>();
		String sql = " SELECT USER_ID, USER_FIRST_NM, USER_LAST_NM, STAT, ROLE_NM FROM SOD_EXTR.CCRA_EXTR_MV ";
		conData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(CcraExtractMdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	@Override
	public List<CcraStageMdl> getCCRAStageData() throws SQLException, DataAccessException {
		List<CcraStageMdl> conData = new ArrayList<>();
		String sql = " SELECT WWID,USERID, FIRST_NM, LAST_NM, CO, APPL_ROLE, ADD_DT, UPDATE_DT FROM SOD_EXTR.CCRA_STAGE ";
		conData = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(CcraStageMdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	//METHOD Designed to search by Ticket Number
	@Override
	public List<ReportDataModel> searchTktInfo(String tktNo)throws SQLException, DataAccessException {
		List<ReportDataModel> reportData = new ArrayList<>();
		log.info("Query Data for TicketNo: "+tktNo);

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.TICKT_NO, c.FMLY_NM||','||c.GIVEN_NM AS REQ_NM, a.REQSTOR_ID AS REQ_WWID, b.FMLY_NM||','||b.GIVEN_NM AS ASSOC_NM, a.CLI_ID AS ASSOC_WWID, b.JNJ_MSFT_USRNM_TXT AS ASSOC_NT_ID, ");
		sql.append(" b.JNJ_SUPVR_WW_ID AS MGR_WWID, d.FMLY_NM||','||d.GIVEN_NM AS MGR_NM, a.REQST_DT AS DT_CREATED, e.BUSN_JUSTN AS BUSN_JSTN, a.APPLN_CMNTS AS ADD_CMNTS ");
		sql.append(" FROM TIPTOP.TICKT_REQSTOR a, SOD_EXTR.JJEDS_EMP_EXTR_MV b, SOD_EXTR.JJEDS_EMP_EXTR_MV c, SOD_EXTR.JJEDS_EMP_EXTR_MV d, TIPTOP.CLI_INFO e ");
		sql.append(" Where a.CLI_ID = b.WW_ID AND a.REQSTOR_ID = c.ww_id AND b.JNJ_SUPVR_WW_ID = d.WW_ID AND a.TICKT_NO = e.TICKT_NO ");
		sql.append(" AND a.TICKT_NO = ? ");
		sql.append(" order by a.TICKT_NO DESC ");

		reportData = getJdbcTemplate().query(sql.toString(), new Object[] {tktNo}, new BeanPropertyRowMapper<>(ReportDataModel.class));
		log.info("Total rows returned : "+((reportData !=null) ? reportData.size():"0"));
		return reportData;
	}



	@Override
	public List<F9860Mdl> getF9860Data() throws SQLException, DataAccessException {
		List<F9860Mdl> conData = new ArrayList<>();
		String sql = " SELECT SIOBNM, SIMD, SISY, SISYR, SIFUNO,SIFUNU, SIPFX, SISRCLNG, SIANSIF, SICATO, SICLDF, SICPYD, SIOMIT, SIOPDF, SIAPPLID,SICURTYP, SIBFLOCN, SIGBOPTN, SIGTFILE, " +
					 " SIGTTYPE, SIGTFFU1, SIJDETEXT, SIPROPID, SIMID1, SIBASE, SIPARDLL, SIPAROBN, SIPKGCOL, SIOLCD01, SIOLCD02,SIOLCD03, SIOLCD04, SIOLCD05, SIPID, SIUSER, SIJOBN, SIUPMJ, SIUPMT "+
					 " FROM OBJ7333.F9860";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F9860Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}

	@Override
	public List<F9861Mdl> getF9861Data() throws SQLException, DataAccessException {
		List<F9861Mdl> conData = new ArrayList<>();
		String sql = " SELECT SIOBNM, SIMKEY, SIENHV, SIUSER, SIDM, SIJDEVERS, SIMSAR, SISTCE, SIDVP, SIMRGMOD, SIMRGOPT, SIRLS, SIPATHCD, "+
					 " SIMODCMT, SIPID, SIJOBN, SIUPMJ, SIUPMT FROM OBJ7333.F9861";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F9861Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	@Override
	public List<F9865Mdl> getF9865Data() throws SQLException, DataAccessException {
		List<F9865Mdl> conData = new ArrayList<>();
		String sql = " SELECT SWFMNM, SWFMID, SWMD, SWFMPT, SWRLS, SWENTRYPT, SWSY, SWFUNO, SWOBNM, SWAPPLID, SWHELPID1, SWHFNAME, SWJDEVERS,"+
					 " SWMRGMOD, SWMRGOPT, SWFMC1, SWFMC2, SWFMC3, SWFMC4, SWFMC5, SWUSER, SWPID, SWJOBN, SWUPMJ, SWUPMT "+
					 " FROM OBJ7333.F9865";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F9865Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}

	@Override
	public List<F983051Mdl> getF983051Data() throws SQLException, DataAccessException {
		List<F983051Mdl> conData = new ArrayList<>();
		String sql = " SELECT VRPID, VRVERS, VRREPORTID, VRVERSIONID, VRJD, VREXCL, VRUSER, VRVCD, VRVED, VRPROPTMID, VRPOID, VROPCR, "+
					 " VRVLISTMODE, VRVERTXTID, VRCHKOUTSTS, VRCHKOUTDAT, VRUSR0, VRVRSAVAIL, VRENHV, VRMKEY, VRPODATA, VRDSTNM, VRVCC1, "+
					 " VRVCC2, VRVCC3, VRVCC4, VRVCC5, VRFRMTSTR FROM PD7333.F983051 ";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F983051Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}

	@Override
	public List<F0005Mdl> getF0005Data() throws SQLException, DataAccessException {
		List<F0005Mdl> conData = new ArrayList<>();
		String sql = " SELECT DRSY, DRRT, DRKY, DRDL01, DRDL02, DRSPHD, DRUDCO, DRHRDC, DRUSER, DRPID, " +
					 "  DRUPMJ, DRJOBN, DRUPMT FROM PDCTL.F0005 ";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F0005Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	@Override
	public List<F0082Mdl> getF0082Data() throws SQLException, DataAccessException {
		List<F0082Mdl> conData = new ArrayList<>();
		String sql = " SELECT MNMNI, MNSY, MNXMN, MNOCMN, MNLOD, MNDSST, MNTXIC, MNMNUT, MNUSER, MNPID, " +
					 " MNUPMJ, MNJOBN, MNUPMT, MNMSKA, MNMSKJ, MNMSKK, MNMSKD, MNMSKF FROM PDCTL.F0082 ";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F0082Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


	@Override
	public List<F00821Mdl> getF00821Data() throws SQLException, DataAccessException {
		List<F00821Mdl> conData = new ArrayList<>();
		String sql = " SELECT DRSY, DRRT, DRKY, DRDL01, DRDL02, DRSPHD, DRUDCO, DRHRDC, DRUSER, DRPID, " +
					 "  DRUPMJ, DRJOBN, DRUPMT FROM PDCTL.F0005 ";
		conData = getJdbcTemplateMrap0561().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(F00821Mdl.class));
		log.info("Total rows returned : "+((conData !=null) ? conData.size():"0"));
		return conData;
	}


/*	@Override
	public List<AppRoles> getTktRoles(String[] ticketNo) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<AppRoles>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<AppRoles>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}


	@Override
	public List<AppRoles> getTktAppRoles(String[] ticketNo, List<Integer> appIds ) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<AppRoles>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		if(appIds != null && !appIds.isEmpty()) {
			sql.append(" AND a.APPLN_GRP_ID in ( ");
			for(int j=0;j<appIds.size();j++) {
				if(j==0) {
					sql.append(" "+appIds.get(j));
				}else {
					sql.append(", "+appIds.get(j));
				}
			}
			sql.append(" ) ");
		}

		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<AppRoles>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}



	@Override
	public List<ReqLogModel> getTktReqLogs(String[] ticketNo) throws SQLException, DataAccessException {
		List<ReqLogModel> appData = new ArrayList<ReqLogModel>();
		StringBuilder sql = new StringBuilder();
		sql.append(" select a.TICKT_NO, a.CLI_ID AS USER_ID, b.JNJ_MSFT_USRNM_TXT as NT_ID, b.GIVEN_NM|| ' '||FMLY_NM AS USER_NM, ");
		sql.append(" a.ROW_ADD_TMS as COM_DATE, to_char(a.ROW_ADD_TMS, 'hh24:mi:ss') as COM_TIME, CMNTS ");
		sql.append(" from tiptop.TICKT_REQSTOR_LOG a, SOD_EXTR.JJEDS_EMP_EXTR_MV b ");
		sql.append(" where a.CLI_ID = b.ww_id ");
		sql.append(" AND a.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" order by a.TICKT_NO, a.LOG_SEQ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<ReqLogModel>(ReqLogModel.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}


*/


}
