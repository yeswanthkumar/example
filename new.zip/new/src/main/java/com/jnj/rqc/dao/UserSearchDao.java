package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.UserSearchModel;


public interface UserSearchDao {
	public List<UserSearchModel> getAllUsersByNTId(List<Object> ids, int status)throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByWWId(List<Object> ids, int status)throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByFmlyNm(List<Object> ids)throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByFirstNm(List<Object> ids)throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByFirstNmLstNm(String firstNm, String lstNm, int status)throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByEmail(List<Object> emailIds, int status) throws SQLException, DataAccessException;
	public List<UserSearchModel> getAllUsersByWWIdReport(List<Object> ids, int status)throws SQLException, DataAccessException;
	public List<UserSearchModel> getUserByWWIdFromJJEDS(String userId)throws SQLException, DataAccessException;
	public List<UserSearchModel> getUserByEMailIdFromJJEDS(String mailId)throws SQLException, DataAccessException;
}
