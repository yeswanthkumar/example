package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class JJEDsUserLookupMdl {
	private String 	wwId;
	private String 	jnjMsftUsrnmTxt;
	private String 	userName;
	private String 	empStatTxt; //Status
	private Date 	termnnDt;
	private String 	jnjEmailAddrTxt;
	private String 	jnjSupvrWwId;
	private String 	jnjSupvrNtId;
	private String 	jnjSupvrName;
	private String 	jnjSupvrEmail;

	@Override
	public String toString() {
		return "JJEDsUserLookupMdl [wwId=" + wwId + ", jnjMsftUsrnmTxt=" + jnjMsftUsrnmTxt + ", userName=" + userName
				+ ", empStatTxt=" + empStatTxt + ", termnnDt=" + termnnDt + ", jnjEmailAddrTxt=" + jnjEmailAddrTxt
				+ ", jnjSupvrWwId=" + jnjSupvrWwId + ", jnjSupvrNtId=" + jnjSupvrNtId + ", jnjSupvrName=" + jnjSupvrName
				+ ", jnjSupvrEmail=" + jnjSupvrEmail + "]";
	}

	public String getData() {
		return wwId + "~" + jnjMsftUsrnmTxt + "~" + userName+ "~" + jnjEmailAddrTxt	+ "~" + jnjSupvrWwId + "~" + jnjSupvrNtId + "~" + jnjSupvrName
				+ "~" + jnjSupvrEmail+"~"+empStatTxt;
	}

}
