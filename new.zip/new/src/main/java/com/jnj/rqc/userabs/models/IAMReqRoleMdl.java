package com.jnj.rqc.userabs.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IAMReqRoleMdl {
	private int    reqId;
	private int    seqId;
	private String userId;
	private String sysId;
	private String sysName;
	private String posId;
	private String posName;
	private String pvId;
	private String pvName;
	private String adgrpId;
	private String adgrpName;
	private String reqBy;
	private String comments;
	private String submUid;
	private Date   submDate;
	private String submStatus;
	private String apiStatus;
	private String apiMsg;
	private Date   updDate ;
	private String apiErrorMsg;
}
