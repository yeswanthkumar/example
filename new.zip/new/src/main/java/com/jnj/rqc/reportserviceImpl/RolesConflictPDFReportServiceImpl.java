package com.jnj.rqc.reportserviceImpl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.reportservice.RolesConflictPDFReportService;
import com.jnj.rqc.util.Utility;

@Service
public class RolesConflictPDFReportServiceImpl implements RolesConflictPDFReportService {

	@Override
	public String writeUserRolesReport(String fileNm, List<PersonalSysModel> userRoles) {
		Document document = new Document();
	    String filePath= "";
	    try
	    {
	    	File outfile = new File(Constants.REPO_OUT_LOC+fileNm);
	    	filePath = outfile.getAbsolutePath();
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outfile));
	        document.open();
	        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 6, BaseColor.BLACK);

	        Paragraph title = new Paragraph("User Existing Role(s) in Application on "+Utility.fmtMMDDYYYY(new Date()), titleFont);
	        title.setAlignment(Element.ALIGN_CENTER);
	        document.add(title);


	        String [] header = "SRNO,WWID,USER ID,FIRST NAME,LAST NAME,SOD CODE,ACCESS ROLE,CO,SRC SYSTEM,USER TYPE,JOB,WAIVERS".split(",");
	        PdfPTable table = new PdfPTable(header.length);

	        table.setWidthPercentage(100);
	        table.setSpacingBefore(10f);
	        table.setSpacingAfter(10f);
	        //table.addCell(new PageNumberCellGenerator(pageNumber, BackgroundColorGeneratorDEFAULT_BACKGROUND_COLOR).generateTile());
	        Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 4, BaseColor.BLACK);
	        Font dataFont = FontFactory.getFont(FontFactory.HELVETICA, 4);

	        //Set Column widths
	        float[] columnWidths = {1f, 1f, 1f, 2f, 2f, 1f, 4f, 1.5f, 2f, 1f, 1f, 1f};
	        table.setWidths(columnWidths);
	        PdfPCell headerCell = null;
	        for(String headstr:header) {
	        	headerCell = new PdfPCell(new Phrase(headstr, headFont));
	        	headerCell.setBorderColor(BaseColor.DARK_GRAY);
	        	headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        	headerCell.setPaddingLeft(1);
	        	headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
	        	headerCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        	headerCell.setUseBorderPadding(true);
		        table.addCell(headerCell);
	        }
	        table.setHeaderRows(1);
	        int i=1;
	        for(PersonalSysModel nmodel:userRoles) {

	        	PdfPCell srno = new PdfPCell(new Phrase(i+"", dataFont));
	        	table.addCell(srno);

	        	PdfPCell wwid = new PdfPCell(new Phrase(nmodel.getWwid()+"", dataFont));
	        	table.addCell(wwid);

	        	PdfPCell usrId = new PdfPCell(new Phrase(nmodel.getUserId(), dataFont));
	        	table.addCell(usrId);

	        	PdfPCell fstNm = new PdfPCell(new Phrase(nmodel.getFirstName(), dataFont));
	        	table.addCell(fstNm);

	        	PdfPCell lstNm = new PdfPCell(new Phrase(nmodel.getLastName(), dataFont));
	        	table.addCell(lstNm);

	        	PdfPCell  sodCd = new PdfPCell(new Phrase(""+nmodel.getCode(), dataFont));
	        	table.addCell(sodCd);

	        	PdfPCell accRole = new PdfPCell(new Phrase(nmodel.getRole(), dataFont));
	        	table.addCell(accRole);

	        	PdfPCell co = new PdfPCell(new Phrase(nmodel.getCo(), dataFont));
	        	table.addCell(co);

	        	PdfPCell srcSys = new PdfPCell(new Phrase(nmodel.getSrcSystem(), dataFont));
	        	table.addCell(srcSys);

	        	PdfPCell usrTyp = new PdfPCell(new Phrase(nmodel.getUserType(), dataFont));
	        	table.addCell(usrTyp);

	        	PdfPCell job = new PdfPCell(new Phrase(nmodel.getJob(), dataFont));
	        	table.addCell(job);

	        	PdfPCell waiv = new PdfPCell(new Phrase(nmodel.getWaivers(), dataFont));
	        	table.addCell(waiv);

	        	//table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	/*String [] bdyData = nmodel.getData().split("~");
	        	for(String bodyStr:bdyData) {
	        		table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	}*/
	        	i++;
	        }
	        document.add(table);
	        document.close();
	        writer.close();
	        System.out.println("File "+outfile.getAbsolutePath()+" creation completed.");
	    } catch (Exception e)
	    {
	        System.out.println("Error creating PDF Document :"+e.getMessage());
	    	e.printStackTrace();
	    }

	    return filePath;

	}

	@Override
	public String writeUserConflictsReport(String title, String fileNm, List<MatrixModel> roleConflictList) {
		Document document = new Document();
	    String filePath= "";
	    try
	    {
	    	File outfile = new File(Constants.REPO_OUT_LOC+fileNm);
	    	filePath = outfile.getAbsolutePath();
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outfile));
	        document.open();
	        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 6, BaseColor.BLACK);

	        Paragraph titleParah = new Paragraph(title+" "+Utility.fmtMMDDYYYY(new Date()), titleFont);
	        titleParah.setAlignment(Element.ALIGN_CENTER);
	        document.add(titleParah);

	        String [] header = "SRNO,WWID,SOD CODE1,SOD CODE2,APP1,APP2,CONFLICTING ROLE(s),MITIGATING CONTROL".split(",");
	        PdfPTable table = new PdfPTable(header.length);

	        table.setWidthPercentage(100);
	        table.setSpacingBefore(10f);
	        table.setSpacingAfter(10f);
	        //table.addCell(new PageNumberCellGenerator(pageNumber, BackgroundColorGeneratorDEFAULT_BACKGROUND_COLOR).generateTile());
	        Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 4, BaseColor.BLACK);
	        Font dataFont = FontFactory.getFont(FontFactory.HELVETICA, 4);

	        //Set Column widths
	        float[] columnWidths = {1f, 1f, 1f, 1f, 1.5f, 1.5f, 5f, 4f};
	        table.setWidths(columnWidths);
	        PdfPCell headerCell = null;
	        for(String headstr:header) {
	        	headerCell = new PdfPCell(new Phrase(headstr, headFont));
	        	headerCell.setBorderColor(BaseColor.DARK_GRAY);
	        	headerCell.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        	headerCell.setPaddingLeft(1);
	        	headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
	        	headerCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	        	headerCell.setUseBorderPadding(true);
		        table.addCell(headerCell);
	        }
	        table.setHeaderRows(1);
	        int i=1;
	        for(MatrixModel model:roleConflictList) {
	        	//CONFLICTING ROLE(s),MITIGATING CONTROL
	        	PdfPCell srno = new PdfPCell(new Phrase(i+"", dataFont));
	        	table.addCell(srno);

	        	PdfPCell wwid = new PdfPCell(new Phrase(model.getWwid()+"", dataFont));
	        	table.addCell(wwid);

	        	PdfPCell sod1 = new PdfPCell(new Phrase(model.getRole1()+"", dataFont));
	        	table.addCell(sod1);

	        	PdfPCell sod2 = new PdfPCell(new Phrase(model.getRole2()+"", dataFont));
	        	table.addCell(sod2);

	        	PdfPCell app1 = new PdfPCell(new Phrase(model.getApp1(), dataFont));
	        	table.addCell(app1);

	        	PdfPCell  app2 = new PdfPCell(new Phrase(model.getApp2(), dataFont));
	        	table.addCell(app2);

	        	PdfPCell conf = new PdfPCell(new Phrase(model.getConflict(), dataFont));
	        	table.addCell(conf);

	        	PdfPCell miti = new PdfPCell(new Phrase(model.getMitigatingControl(), dataFont));
	        	table.addCell(miti);

	        	//table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	/*String [] bdyData = nmodel.getData().split("~");
	        	for(String bodyStr:bdyData) {
	        		table.addCell(new PdfPCell(new Phrase((StringUtils.isEmpty(bodyStr)?"-":bodyStr), dataFont)));
	        	}*/
	        	i++;
	        }
	        document.add(table);
	        document.close();
	        writer.close();
	        System.out.println("File "+outfile.getAbsolutePath()+" creation completed.");
	    } catch (Exception e)
	    {
	        System.out.println("Error creating PDF Document :"+e.getMessage());
	    	e.printStackTrace();
	    }

	    return filePath;
	}

}
