package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDACrsAppRoleMdl;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAMenuItemMdl;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.dao.BelmontRoleConflictsDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.StrKeyValPair;


/**
 * File    : <b>BelmontRoleConflictsDaoImpl.java</b>
 * @author : DChauras @Created : Feb 17, 2021 4:29:08 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class BelmontRoleConflictsDaoImpl  extends BaseDao implements BelmontRoleConflictsDao {
	static final Logger log = LoggerFactory.getLogger(BelmontRoleConflictsDaoImpl.class);

	@Override
	public List<JDAMenuItemMdl> getNewRolesActionJDA(String data, int system)throws SQLException, DataAccessException {
		log.info("Role ID Received:"+ data);
		String[] dataArr = data.split(",");
		StringBuffer sql = new StringBuffer();
		sql.append(" Select ATH_ID AS ROLE, OPT_NAM AS MENU_ITEM ");
		sql.append(" FROM "+getSchemaName(system)+"."+"LES_REFS_OPT_ATH ");
		sql.append(" Where ATH_ID ");
		if(dataArr.length == 1) {
			sql.append(" ='"+dataArr[0]+"' ");
		}else {
			sql.append(" IN ( " );
			for(int i=0; i<dataArr.length; i++) {
				if(i < (dataArr.length -1)) {
					sql.append(" '"+dataArr[i]+"', ");
				}else {
					sql.append(" '"+dataArr[i]+"' )");
				}
			}
		}
		sql.append(" ORDER BY 1,2 ");
		final List<JDAMenuItemMdl> userRoles = getTemplate(system).query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(JDAMenuItemMdl.class));
		//final List<JDAMenuItemMdl> userRoles = getJdbcTemplateJDADevelopment().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<JDAMenuItemMdl>(JDAMenuItemMdl.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


	@Override
	public List<JDAPersonalSysMdl> getUsersExistingRolesJDA(String wwid, int system)throws SQLException, DataAccessException {
		log.info("User ID Received WebUI Roles:"+ wwid);
		String sql = " Select a.USR_ID, a.LOGIN_ID as WWID, a.FIRST_NAME, a.LAST_NAME, a.USR_STS, b.ROLE_ID as ROLE, 'JDA' as SRC_SYSTEM, '' as SOD_CODE, c.OPT_NAM as ACTION " +
				"FROM "+getSchemaName(system)+".users_view a, "+getSchemaName(system)+".LES_USR_ROLE b , "+getSchemaName(system)+".LES_REFS_OPT_ATH c " +
				"WHERE a.LOGIN_ID=b.USR_ID AND b.ROLE_ID = c.ATH_ID " +
				"AND a.LOGIN_ID= ? " +
				"ORDER BY b.ROLE_ID,c.OPT_NAM";
		final List<JDAPersonalSysMdl> userRoles = getTemplate(system).query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<>(JDAPersonalSysMdl.class));
		//final List<JDAPersonalSysMdl> userRoles = getJdbcTemplateJDADevelopment().query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<JDAPersonalSysMdl>(JDAPersonalSysMdl.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


	@Override
	public List<JDAPersonalSysMdl> getUsersExistingClientRolesJDA(String wwid, int system)throws SQLException, DataAccessException {
		log.info("User ID Received Client Side Roles:"+ wwid);
		String sql = " Select a.USR_ID, a.LOGIN_ID as WWID, a.FIRST_NAME, a.LAST_NAME, a.USR_STS, b.ROLE_ID as ROLE, 'JDA' as SRC_SYSTEM, '' as SOD_CODE, c.OPT_NAM as ACTION " +
				"FROM "+getSchemaName(system)+".users_view a, "+getSchemaName(system)+".LES_USR_ROLE b , "+getSchemaName(system)+".LES_OPT_ATH c " +
				"WHERE a.LOGIN_ID=b.USR_ID AND b.ROLE_ID = c.ATH_ID " +
				"AND a.LOGIN_ID= ? " +
				"ORDER BY b.ROLE_ID,c.OPT_NAM";
		final List<JDAPersonalSysMdl> userRoles = getTemplate(system).query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<>(JDAPersonalSysMdl.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}



	@Override
	public List<JDAMenuItemMdl> getJDAMenuItem(String role, int system)throws SQLException, DataAccessException {
		log.info("Query Data for Role ID : "+ role);
		String sql = " SELECT MENU_ITEM_ID as MENU_ITEM, '"+role+ "' as ROLE" +
					 " FROM "+getMSchemaName(system)+".MENU_ITEM WHERE permissions like '%"+role+"%' ";

		final List<JDAMenuItemMdl> menuItems = getTemplate(system).query(sql, new Object[] {}, new BeanPropertyRowMapper<>(JDAMenuItemMdl.class));
		//final List<JDAMenuItemMdl> menuItems = getJdbcTemplateJDADevelopment().query(sql, new Object[] {}, new BeanPropertyRowMapper<JDAMenuItemMdl>(JDAMenuItemMdl.class));
		log.info("Total Rows : "+((menuItems !=null)? menuItems.size(): 0)+"  .......END");
		return menuItems;
	}


	@Override
	public List<MatrixModel> getCurrentRolesConflict(String[] roles, String wwid ) throws SQLException, DataAccessException {
		List<MatrixModel> confInExistingRoles = new ArrayList<>();

		for(String roleId : roles) {
			List<MatrixModel> tmp = getLRConflicts(roleId,  wwid);
			if(tmp != null && !tmp.isEmpty()) {
				confInExistingRoles.addAll(tmp);
			}
		}
		log.info("Total Conflicts in NEW-EXISTING :"+confInExistingRoles.size());
		return confInExistingRoles;
	}


	@Override
	public List<MatrixModel> getNewRolesConflict(String sql) throws SQLException, DataAccessException {
		List<MatrixModel> roleMatrixList = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("roleMatrix size : "+((roleMatrixList !=null)? roleMatrixList.size(): 0)+" ");
		return roleMatrixList;
	}


	@Override
	public List<JDACrsAppRoleMdl> getCrossAppRoles(String empId) throws SQLException, DataAccessException {
		String sql= " SELECT a.WWID, a.CODE,b.ACCESS_ROLE,b.SRC_SYSTEM "+
					" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b "+
					" WHERE a.WWID='"+empId+"' AND (a.SRC_SYSTEM LIKE '%SAP%' OR a.SRC_SYSTEM='MDM') "+
					" AND a.CODE = b.SOD_CODE ";
		List<JDACrsAppRoleMdl> roleMatrixList = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(JDACrsAppRoleMdl.class));
		log.info("roleMatrix size : "+((roleMatrixList !=null)? roleMatrixList.size(): 0)+" ");
		return roleMatrixList;
	}


	private List<MatrixModel>getLRConflicts(String roleId, String wwid){
		List<MatrixModel> allConfRoles = new ArrayList<>();

		String sqlLtoR = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE1 = ? and a.ROLE2 = b.CODE "
				+" and b.WWID = ? ";
		List<MatrixModel> roleMatrix = getJdbcTemplate().query(sqlLtoR, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("Role ID : "+roleId+"  Total Rows LtoR => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			allConfRoles.addAll(roleMatrix);
		}

		String sqlRtoL = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE2 = ? and a.ROLE1 = b.CODE "
				+" and b.WWID = ? ";
		roleMatrix = null;
		roleMatrix = getJdbcTemplate().query(sqlRtoL, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("Role ID :"+roleId+"  Total Rows RtoL => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			allConfRoles.addAll(roleMatrix);
		}

	return allConfRoles;
	}

/*
	private List<MatrixModel>getNewRoleConflicts(int roleId, int wwid){
		List<MatrixModel> confInExistingRoles = new ArrayList<MatrixModel>();

		String sqlLtoR = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE1 = ? and a.ROLE2 = b.CODE "
				+" and b.WWID = ? ";
		List<MatrixModel> roleMatrix = getJdbcTemplate().query(sqlLtoR, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<MatrixModel>(MatrixModel.class));
		log.info("Total Rows LtoR => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			confInExistingRoles.addAll(roleMatrix);
		}

		String sqlRtoL = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE2 = ? and a.ROLE1 = b.CODE "
				+" and b.WWID = ? ";
		roleMatrix = null;
		roleMatrix = getJdbcTemplate().query(sqlRtoL, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<MatrixModel>(MatrixModel.class));
		log.info("Total Rows RtoL => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			confInExistingRoles.addAll(roleMatrix);
		}

	return confInExistingRoles;
	}*/




	/**
	 * Method  : RoleConflictsDaoImpl.java.getUsersExistingRoles()
	 *		   :<b>@param empWwid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Jan 15, 2020 4:26:35 PM
	 * Purpose :Query All the Existing User Roles for a given WWID
	 * @return : List<PersonalSysModel>
	 */
	@Override
	public List<JDAPersonalSysMdl> getUsersExistingRoles(String wwid)throws SQLException, DataAccessException {
		log.info("User ID Received:"+ wwid);
		String sql = " SELECT a.WWID, a.USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " +
				" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b" +
				" WHERE a.CODE = b.SOD_CODE AND a.WWID = ? ORDER BY a.CODE ";

		final List<JDAPersonalSysMdl> userRoles = getJdbcTemplate().query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<>(JDAPersonalSysMdl.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}



	@Override
	public List<SystemCodeModel> getSystemCodes() throws SQLException, DataAccessException {
		log.info("QUERY SYSTEM_CODE");
		String sql = " SELECT SRC_SYSTEM, ACCESS_ROLE, SOD_CODE FROM SOD_EXTR.SYSTEM_CODE ORDER BY SRC_SYSTEM ";

		final List<SystemCodeModel> sysCdLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SystemCodeModel.class));
		log.info("Total Rows : "+((sysCdLst !=null)? sysCdLst.size(): 0)+"  .......END");
		return sysCdLst;
	}


	@Override
	public List<JDAPersonalSysMdl> getUsersExistingRoles(List<String> empIds) throws SQLException, DataAccessException {
		log.info("User ID Received:"+ empIds);
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.WWID, UPPER(a.USER_ID) AS USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " );
		sql.append(" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b " );
		sql.append(" WHERE a.CODE = b.SOD_CODE AND a.WWID in ( ");
		String vars="";

		for(int i=0; i<empIds.size(); i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" ORDER BY a.WWID,  a.CODE ");

		final List<JDAPersonalSysMdl> userRoles = getJdbcTemplate().query(sql.toString(), empIds.toArray(), new BeanPropertyRowMapper<>(JDAPersonalSysMdl.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}

	@Override
	public List<JDADBRiskModel> loadJDAConflictMatrix()throws SQLException, DataAccessException{
		String sql= " SELECT RISK_ID, RISK_DESC, ROLE_NAME, ROLE_ID, FUNC_ID, FUNC_DESC, RISK_LEVEL, REGULATION, "+
				    " TARGET_CONN AS TRGT_CON, MITIGATING_CNTRL AS MITI_CNTRL, COMPL_MGR, RULESET_BUSS_OWNR AS RULESET_GPO "+
					" FROM JDA_CONFLICT_MATRIX "+
					" ORDER BY RISK_ID, ROLE_ID, FUNC_ID ";
		List<JDADBRiskModel> confMatrixList = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(JDADBRiskModel.class));
		log.info("JDA Conflict Matrix size : "+((confMatrixList !=null)? confMatrixList.size(): 0)+" ");
		return confMatrixList;
	}

	@Override
	public List<StrKeyValPair> loadJDATechRoleMappings()throws SQLException, DataAccessException {
		String sql= " SELECT ROLE_NAME as key, TECH_NAME as val "+
			    " FROM JDA_ROLE_MAPPING "+
				" ORDER BY ROLE_NAME, TECH_NAME ";
		List<StrKeyValPair> techMappingsList = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("JDA Conflict Matrix size : "+((techMappingsList !=null)? techMappingsList.size(): 0)+" ");
		return techMappingsList;
	}

	@Override
	public List<JDACrossAppMatrixModel> loadJDACrossAppConflicts()throws SQLException, DataAccessException{
		String sql= " SELECT '', APP1, APP2, ROLE1, ROLE2, '', MITIGATING_CONTROL "+
			    " FROM JDA_CROSSAPP_CONFLICTS "+
				" ORDER BY APP1, APP2, ROLE1, ROLE2 ";
		List<JDACrossAppMatrixModel> crossAppConfList = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(JDACrossAppMatrixModel.class));
		log.info("JDA CROSS APP Conflict Matrix size : "+((crossAppConfList !=null)? crossAppConfList.size(): 0)+" ");
		return crossAppConfList;
	}

	private JdbcTemplate getTemplate(int system) {
		JdbcTemplate jdbcTempl=null;
		if(system == 1) {
			jdbcTempl =getJdbcTemplateJDADevelopment();
		}else if(system == 2) {
			jdbcTempl =getJdbcTemplateJDAQuality();
		}else if(system == 3) {
			jdbcTempl =getJdbcTemplateJDAPreQuality();
		}else {
			jdbcTempl = getJdbcTemplateJDAProduction();
		}
		return jdbcTempl;
	}

	private String getSchemaName(int system) {
		String schema="";
		if(1 == system) {
			schema = "MDWMD";
		}else if(2 == system) {
			schema = "MDWMQ";
		}else if(3 == system) {
			schema = "MDWMS";
		}else {
			schema = "MDWMP";
		}
		return schema;
	}

	private String getMSchemaName(int system) {
		String schema="";
		if(1 == system) {
			schema = "MDPTLWD";
		}else if(2 == system) {
			schema = "MDPTLWQ";
		}else if(3 == system) {
			schema = "MDPTLWS";
		}else {
			schema = "MDPTLWP";
		}
		return schema;
	}

}
