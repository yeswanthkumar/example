package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dao.HCSExtrDao;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.HCSExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;


@Service
public class HCSExtrDataServiceImpl implements HCSExtrDataService{

	static final Logger log = LoggerFactory.getLogger(HCSExtrDataServiceImpl.class);

	@Autowired
	Environment environment;
	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	GenesisDao genesisDao;
	@Autowired
	HCSExtrDao hCSExtrDao;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;


	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;



	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadHCSProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}


	@Override
	public List<SapGaaUser2RoleModel> readHcsBravoActData(String templSysParam) {
		log.info("templSysParam :"+templSysParam);
		//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();

		List<SapGaaUser2RoleModel> userRoleData = readUser2RoleData(templSysParam, "R");
		//START -  SAVE ALL RAW DATA
		sAPExtrGaaDataService.saveUser2RoleAllRawData(userRoleData, templSysParam);
		//END -  SAVE ALL RAW DATA

		if(userRoleData != null && !userRoleData.isEmpty()) {
			for(SapGaaUser2RoleModel mdl:userRoleData) {
	    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
	    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
	    				activeTrfData.add(mdl);
	    			}
	    		}else {
	    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
	    				String usrId = mdl.getUserId();
	    				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(mdl.getUserId(), 0);
	    				if(srchUsr != null) {
							mdl.setUserStatus(srchUsr.getEmpStatTxt());
						}else {
							mdl.setUserStatus("NO DATA FOUND");
						}
	    				incompleteData.add(mdl);
	    			}
	    		}
	    	}
		}

		if(incompleteData != null && !incompleteData.isEmpty()) {
			sAPExtrGaaDataService.sendInvldDataEmail(templSysParam, incompleteData);
		}
		return activeTrfData;
	}




	@Override
	public List<SapGaaUser2RoleModel> readUser2RoleData(String templSysParam, String calledBy) {
		LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
		try{
			log.info("Get User Data for System: "+templSysParam);
			List<SapGaaUser2RoleModel> userLst = hCSExtrDao.getHCSUser2RoleData(templSysParam);//Get All Users for the given System
			// START - Store Raw Data into USER2ROLE_RAWDATA
			if("R".equals(calledBy)) {
				saveUser2RoleRawData(userLst, templSysParam);
			}
			// END - Store Raw Data into USER2ROLE_RAWDATA
			log.info("Total Records for User2Role Data  ("+(userLst !=null? userLst.size():"0")+") for System: "+templSysParam);
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			for(SapGaaUser2RoleModel usrMdl : userLst) {
				String usrID = usrMdl.getUserId().trim();
				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usrID, 1);
				usrMdl.setRevUserId("");
				usrMdl.setUserId(((srchUsr != null)?srchUsr.getWwId():usrID));
				usrMdl.setFirstName((srchUsr != null)?srchUsr.getGivenNm():"");
				usrMdl.setLastName((srchUsr != null)?srchUsr.getFmlyNm():"");
				usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
				//Logic added to replace role desc for roles not found
				String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
				if(rlDesc==null || rlDesc=="" || rlDesc == "0" || rlDesc.length()<=2) {//WMS has Roles lik LC3/LC1 etc.
					rlDesc = (usrMdl.getRoleId() == null)? "":usrMdl.getRoleId().trim();
				}
				//END
				usrMdl.setPrimaryReviewInfo2(rlDesc);
				usrMdl.setPrimaryReviewInfo3(" Within "+Utility.getSapClientName(systemInfo[3]));
				usrMdl.setAdditionalInfo1(Utility.getSapClientName(systemInfo[3]));
				usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
				usrMdl.setAdditionalInfo3((usrMdl.getRoleId() == null)? "":usrMdl.getRoleId().trim());
				usrMdl.setUserStatus((srchUsr != null)?srchUsr.getEmpStatTxt():"NOT FOUND");
				allUserData.add(usrMdl);
			}
			log.info("All User ROLE Data for "+systemInfo[1]+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}


	//RAW DATA COLLECTION STARTS HERE

		private void saveUser2RoleRawData(List<SapGaaUser2RoleModel> userLst, String templSysParam){
			List<User2RoleRawDataMdl> allUserData = new ArrayList<>();
			String[] sysInfoArr = templSysParam.split("_");
			for(SapGaaUser2RoleModel usrRlMdl : userLst){
				User2RoleRawDataMdl usrMdl = new User2RoleRawDataMdl();
				usrMdl.setRegion(sysInfoArr[0]);
				usrMdl.setPlatform(sysInfoArr[1]);
				usrMdl.setEnvironment(sysInfoArr[2]);
				usrMdl.setSystem(sysInfoArr[3]);
				usrMdl.setUserId(usrRlMdl.getUserId());
				usrMdl.setRoleId(usrRlMdl.getRoleId());
				usrMdl.setRoleDesc(Utility.isEmpty(usrRlMdl.getRoleDesc()) ? usrRlMdl.getRoleId() :usrRlMdl.getRoleDesc());
				allUserData.add(usrMdl);
			}
			//Insert Data
			if(!allUserData.isEmpty()) {
				int totalRec = sAPExtrGaaDataService.insertUser2RoleRawData(allUserData);
				log.info("TOTAL RAW DATA for System ("+templSysParam+") :"+allUserData.size()+"  INSERTED: "+totalRec);
			}
		}


}
