package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.ruleset.models.RuleSetModel;
import com.jnj.rqc.ruleset.models.RuleSetSmryModel;

public interface RuleSetReviewService {
	public List<RuleSetSmryModel> getRuleSetSummary();
	public Map<String, List<RuleSetModel>> getRuleSetData(List<RuleSetSmryModel> summaryList);
	public Map<String, String> generateRuleSetFiles(Map<String, List<RuleSetModel>> dataMap, String strDate, HttpServletRequest request);
	public String createCSV(List<RuleSetModel> data, String fileName);
	public void updateFileLocation(List<RuleSetSmryModel>summaryList, Map<String, String> ruleSetFileMap);
	public String createSummaryCSV(List<RuleSetSmryModel> data, String fileName);

}
