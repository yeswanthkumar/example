package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.ConflictResponseDTO;
import com.jnj.rqc.conflictModel.EmailInfoModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

@Controller
public class RqcSapConflictController {
	static final Logger log = LoggerFactory.getLogger(RqcSapConflictController.class);

	@Autowired
	private RqcSapConflictService RqcSapConflictService;

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	EmailUtil emailUtil;

/**
 * Method  : RqcSapConflictController.java.loadConflictForm()
 *		   :<b>@param model
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Jan 15, 2020 1:52:38 PM
 * Purpose :Loads the New Role Add Conflict Page
 * @return : String
 */
	@GetMapping("/rqcSapConflictInfo")
    public String loadConflictForm(Model model) {
    	log.info("Routing to Conflict Test page.");
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
    	return "conflictcheck/conflictInfo";
    }


/**
 * Method  : RqcSapConflictController.java.searchUserDetails()
 *		   :<b>@param empWwid
 *		   :<b>@param data
 *		   :<b>@param model
 *		   :<b>@param request
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Jan 15, 2020 1:50:54 PM
 * Purpose :Check for Role Conflicts when User is Adding a new Role.
 * @return : String
 */
	@PostMapping("/newUserRoleConflicts")
    public String searchUserDetails(@RequestParam("idType") int idType, @RequestParam("empId") String empId,  @RequestParam("data") String data, Model model, HttpServletRequest request) {
		log.info("EMPID :"+empId+"  idType: "+idType+"   Data:"+data);
    	model.addAttribute("empIdParam",empId);
    	model.addAttribute("params",data);
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		model.addAttribute("idParam", idType);

		if(!(empId != null && empId.length() > 0) || (idType == 0) || StringUtils.isEmpty(data)) {
			log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values : "+((idType == 0)?"Search By":(empId == null || empId.length()==0) ? " WWID/NTID ": " Role Names" ));
            return "conflictcheck/conflictInfo";
    	}

		try{
			Map<String, List<String>> sysCdMap = RqcSapConflictService.getSystemCodes(data);
			List<String> sodCds = sysCdMap.get("SYSCDLST");
			List<String> invldRls = sysCdMap.get("INVLDLST");
			String[] dataArr = sodCds.toArray(new String[sodCds.size()]);

			String idToUse = "";
			String userName ="";
			if(idType == 2) {
				List<UserSearchModel> userLst = userSearchService.getUserDataByNtId(empId, 1);
				if(userLst != null && !userLst.isEmpty()) {
					idToUse = userLst.get(0).getWwId();
					userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
				}else {
					model.addAttribute("message", "True");
		            model.addAttribute("error", "Invalid NTID, Please correct the NTID and Search again.");
		            return "conflictcheck/conflictInfo";
				}
			}else {
				idToUse = empId;
				List<UserSearchModel> userLst = userSearchService.getUserData(1, idToUse, 1);
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}
			List<MatrixModel> curRoleConflictList = RqcSapConflictService.getCurConflictDetails(idToUse, dataArr);
    		List<MatrixModel> newRoleConflictList = RqcSapConflictService.getNewConflictDetails(idToUse, dataArr);

    		HttpSession session = request.getSession();
    		session.setAttribute(Constants.ACTIVE_USER, userName);
    		//Ensure Cache data is removed
    		if(session.getAttribute("curRoleConflictList") != null) {
    			session.removeAttribute("curRoleConflictList");
    		}
    		if(session.getAttribute("newRoleConflictList") != null) {
    			session.removeAttribute("newRoleConflictList");
    		}
    		//END
    		if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
    			session.setAttribute("curRoleConflictList", curRoleConflictList);
    			model.addAttribute("curRoleConflictList", curRoleConflictList);
    		}

    		if(newRoleConflictList!= null && !newRoleConflictList.isEmpty()) {
    			session.setAttribute("newRoleConflictList", newRoleConflictList);
    			model.addAttribute("newRoleConflictList", newRoleConflictList);
    		}

    		if(invldRls != null && !invldRls.isEmpty()) {
    			session.setAttribute("invldRls", invldRls);
    			model.addAttribute("invldRls", invldRls.toString());
    		}
    		model.addAttribute("message", "True");
    		log.debug("Conflicts with Existing Roles : "+((curRoleConflictList==null)?  "0":curRoleConflictList.size()));
    		log.debug("Conflicts within new Roles : "+((newRoleConflictList==null)?  "0":newRoleConflictList.size()));

    		String msg  = "Status: Conflicts with existing roles: "+ ((curRoleConflictList == null || curRoleConflictList.isEmpty() ) ?  "0": curRoleConflictList.size()+"");
    		String msg1 = "Status: Conflicts within New roles: "+((newRoleConflictList == null || newRoleConflictList.isEmpty()) ? "0" : newRoleConflictList.size()+"");
    		model.addAttribute("success", msg);
    		model.addAttribute("success1", msg1);
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/conflictInfo";
    }



	/**
	 * Method  : RqcSapConflictController.java.loadSearchConflictForm()
	 *		   :<b>@param model
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jan 15, 2020 3:19:48 PM
	 * Purpose :User level Sod Conflict/Roles Report
	 * @return : String
	 */
	@GetMapping("/searchUserConflicts")
    public String loadSearchConflictForm(Model model) {
		List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		log.info("Routing to Conflict Search page.");
    	return "conflictcheck/userConflictSearchInfo";
    }


	/**
	 * Method  : RqcSapConflictController.java.searchUserLevelDetails()
	 *		   :<b>@param empWwid
	 *		   :<b>@param model
	 *		   :<b>@param request
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jan 16, 2020 10:18:58 AM
	 * Purpose : Method designed to search for User level Roles and Conflicts for given WWID
	 * @return : String
	 */
	@PostMapping("/srchUserLvlConflicts")
    public String searchUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empId") String empId, @RequestParam("data") String data, Model model, HttpServletRequest request) {
		log.info(" Received idType: "+idType+ " WWID/NTID :"+empId+" Data:"+data);
    	model.addAttribute("empIdParam",empId);
    	model.addAttribute("idParam", idType);
    	model.addAttribute("params",data);
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		String idToUse = "";
		String userName = "";

		if(!(empId != null && empId.length() > 0) || (idType == 0)) {
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Search By or User WWID/NTID ");
            return "conflictcheck/userConflictSearchInfo";
    	}

		if(idType == 2) {
			List<UserSearchModel> userLst = userSearchService.getUserDataByNtId(empId, 1);
			if(userLst != null && !userLst.isEmpty()) {
				idToUse = userLst.get(0).getWwId();
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}else {
				model.addAttribute("message", "True");
	            model.addAttribute("error", "Invalid NTID, Please correct the NTID and Search again.");
	            return "conflictcheck/userConflictSearchInfo";
			}
		}else {
			idToUse = empId;
			List<UserSearchModel> userLst = userSearchService.getUserData(1, idToUse, 1);
			if(userLst != null && !userLst.isEmpty()) {
				userName = userLst.get(0).getGivenNm()+" "+userLst.get(0).getFmlyNm();
			}
		}

    	try{
    		String[] roleIds=null;
    		List<PersonalSysModel> currentRoleList = RqcSapConflictService.getUserExistingRoles(idToUse);
    		List<MatrixModel> userLvlConflictRoles = new ArrayList<>();

    		if(currentRoleList != null && currentRoleList.size() > 1) {
    			roleIds = RqcSapConflictService.getRoleIdsPersonalSys(currentRoleList);
    			userLvlConflictRoles = RqcSapConflictService.getUserLevelConflictingRoles(idToUse, roleIds);
    		}

    		//Conflicts in New Role
    		Map<String, List<String>> sysCdMap = RqcSapConflictService.getSystemCodes(data);
			List<String> sodCds = sysCdMap.get("SYSCDLST");
			List<String> invldRls = sysCdMap.get("INVLDLST");
			String[] dataArr = sodCds.toArray(new String[sodCds.size()]);
    		List<MatrixModel> newRoleConflictList = RqcSapConflictService.getNewConflictDetails(idToUse, dataArr, roleIds);

    		HttpSession session = request.getSession();
    		session.setAttribute(Constants.ACTIVE_USER, userName);
    		if(currentRoleList != null && !currentRoleList.isEmpty()) {
    			session.setAttribute("currentRoleList", currentRoleList);
    			model.addAttribute("currentRoleList", currentRoleList);
    		}

    		if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
    			session.setAttribute("userLvlConflictRoles", userLvlConflictRoles);
        		model.addAttribute("userLvlConflictRoles", userLvlConflictRoles);
    		}

    		if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
    			session.setAttribute("newRoleConflictList", newRoleConflictList);
        		model.addAttribute("newRoleConflictList", newRoleConflictList);
    		}
    		log.debug("Current Roles Count: "+((currentRoleList == null || currentRoleList.isEmpty())? "0" : currentRoleList.size()));
    		log.debug("Conflicting Roles Count: "+((userLvlConflictRoles == null || userLvlConflictRoles.isEmpty())? "0" : userLvlConflictRoles.size()));

    		String msg  = ((currentRoleList == null || currentRoleList.isEmpty())? "Total existing roles: 0, Potential invalid ID or New User?" : "Total existing roles: "+currentRoleList.size());
    		String msg1 = "Total conflicting roles: "+((userLvlConflictRoles == null || userLvlConflictRoles.isEmpty())? "0" : userLvlConflictRoles.size());
    		String msg2 = "Total conflicts with New Roles roles: "+((newRoleConflictList == null || newRoleConflictList.isEmpty())? "0" : newRoleConflictList.size());
    		model.addAttribute("message", "True");
    		model.addAttribute("success" , "Status: "+msg);
    		model.addAttribute("success1", "Status: "+msg1);
    		model.addAttribute("success2", "Status: "+msg2);
    	} catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/userConflictSearchInfo";
    }

	@ResponseBody
    @GetMapping("/downloadUserLvlExcel/{type}")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> downloadUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		List<PersonalSysModel> currentRoleList = null;
		List<MatrixModel> userLvlConflictRoles = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			filePath = RqcSapConflictService.writeUserRoleCSVReport(fileNm, currentRoleList);
		}else if("usrConf".equals(type)){
			fileNm ="UserRolesConflictList";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			filePath = RqcSapConflictService.writeConfCSVReport(fileNm, userLvlConflictRoles);
		}else {
			fileNm ="UserRolesNewConflictList";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			filePath = RqcSapConflictService.writeConfCSVReport(fileNm, userLvlConflictRoles);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadUserLvlPDF/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadUserLevelPdf(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="";
		List<PersonalSysModel> currentRoleList = null;
		List<MatrixModel> userLvlConflictRoles = null;

		if("userroles".equals(type)) {
			fileNm ="UserRolesList.pdf";
			currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			filePath = RqcSapConflictService.writeUserRolePDFReport(fileNm, currentRoleList);
		}else if("usrConf".equals(type)){
			fileNm ="UserRolesConflictList.pdf";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			String title = "User level SOD Conflicts between Application Role(s)";
			filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, userLvlConflictRoles);
		}else{
			fileNm ="UserNewRolesConflictList.pdf";
			userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			String title = "User level SOD Conflicts between New Application Role(s)";
			filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, userLvlConflictRoles);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.APPLICATION_PDF)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadCurConfExcel/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm ="ExistingAndRequestedRoleConflicts";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}


		String filePath = RqcSapConflictService.writeConfCSVReport(fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadCurConfPDF/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		String title="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested.pdf";
			title="Requested New Role(s) SOD Conflicts with each other";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm = "ExistingAndRequestedRoleConflicts.pdf";
			title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}
		String filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }






/**
 * Method  : RqcSapConflictController.java.getUserConflicts()
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Jan 15, 2020 1:53:31 PM
 * Purpose : This is a Open Method designed to provide JSON response to the requesting system -Still needs to be completed
 * @return : ResponseEntity<List<ConflictResponseDTO>>
 */
    @GetMapping("/getUserConflicts")
    public ResponseEntity<List<ConflictResponseDTO>> getUserConflicts() {
        log.info("Conflict List");

        List<ConflictResponseDTO> list = new ArrayList<>();
        ConflictResponseDTO dto = new ConflictResponseDTO();
        dto.setTimeStamp(new Date());
        list.add(dto);

        return new ResponseEntity<>(list, HttpStatus.OK);
    }


    @GetMapping("/searchSystemCodesPage")
    public String searchSystemCodes(Model model) {
    	List<String> sysCodes = Utility.getSystemNameList();
    	model.addAttribute("sysCodes", sysCodes);
    	model.addAttribute("system","0");
    	return "conflictcheck/systemCodes";
    }


	@PostMapping("/getSystemCodes")
    public String getSystemCodes(@RequestParam("system") String system, Model model, HttpServletRequest request) {
		log.info("Selected System : "+system);
    	model.addAttribute("system",system);
    	List<String> sysCodes = Utility.getSystemNameList();
    	model.addAttribute("sysCodes", sysCodes);

		try{
			HttpSession session = request.getSession();
			List<SystemCodeModel> sysCdList = Utility.getSystemCodeList(system);
			session.setAttribute("sysCdList", sysCdList);
			model.addAttribute("sysCdList", sysCdList);
    		model.addAttribute("message", "True");
    		log.debug("System Codes size : "+((sysCdList==null)?  "0":sysCdList.size()));
    		model.addAttribute("success", "Status: Search successful for System Codes... total records : "+((sysCdList == null)?  "0":sysCdList.size()));
    	} catch (Exception e) {
            log.error("Error getting system codes :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/systemCodes";
    }




	/**
	 * Method  : RqcSapConflictController.java.loadConflicts()
	 *		   :<b>@param model
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Nov 23, 2020 1:47:19 PM
	 * Purpose : Display the contents of Conflict_Matrix Table
	 * @return : String
	 */

	@GetMapping("/loadConflicts")
    public String loadConflicts(Model model, HttpServletRequest request) {
    	List<MatrixModel> confMatrix = RqcSapConflictService.getConflictMatrix();
    	model.addAttribute("MatrixData", confMatrix);
    	request.getSession().setAttribute("MatrixData", confMatrix);
    	model.addAttribute("system","0");
    	return "conflictcheck/conflictMatrix";
    }



	@ResponseBody
    @GetMapping("/downloadSysCodeExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadSysCodeExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SysCodes ");
		String fileNm ="SystemCodes";
		List<SystemCodeModel> sysCdLst = (List<SystemCodeModel>)request.getSession().getAttribute("sysCdList");
		String filePath = RqcSapConflictService.writeSystemCodeCSVReport(fileNm, sysCdLst);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

	@ResponseBody
    @GetMapping("/downloadCoflictMatrixExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadCoflictMatrixExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Conflict Matrix ");
		String fileNm ="ConflictMatrix";
		List<MatrixModel> confMatrix = (List<MatrixModel>)request.getSession().getAttribute("MatrixData");
		String filePath = RqcSapConflictService.writeConflictMatrixCSVReport(fileNm, confMatrix);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	/*Multi User Role Review*/

	@GetMapping("/reviewMultiUser")
    public String multiUserRoleForm(Model model) {
    	log.info("Routing to Multi-User Role Review page.");
    	List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
    	return "conflictcheck/multiUserRoleReview";
    }

	@PostMapping("/srchMultiUserRoles")
    public String searchMultiUserLevelDetails(@RequestParam("idType") int idType, @RequestParam("empIds") String empIds, Model model, HttpServletRequest request){
		log.info("idType: "+idType+" empIds: "+empIds);
		List<KeyValPair> userIdValue = Utility.getIdParams();
		model.addAttribute("idVal", userIdValue );
		model.addAttribute("empIdParams",empIds);
		model.addAttribute("idTParam", idType);
		if(idType == 0 || empIds == null || empIds.length() == 0) {
    		log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Search By/WWID/NTID ");
            return "conflictcheck/multiUserRoleReview";
    	}
		List<String>idToUse = new ArrayList<>();
		if(idType == 2) {
			List<UserSearchModel> userLst = userSearchService.getUserData(2, empIds, 1);
			if(userLst != null && !userLst.isEmpty()) {
				for(UserSearchModel item : userLst){
					idToUse.add(item.getWwId());
				}
			}else {
				model.addAttribute("message", "True");
	            model.addAttribute("error", "Invalid NTID's, Please correct the NTID and Search again.");
	            return "conflictcheck/multiUserRoleReview";
			}
		}else {
			idToUse = Arrays.asList(empIds.split(","));
		}

		try{
			Map<String, List<MatrixModel>> userLvlConfRlsMaps = new HashMap<>();
			Map<String, List<PersonalSysModel>> curRoleMap = RqcSapConflictService.getMultiUserExistingRoles(idToUse);

    		HttpSession session = request.getSession();
    		if(curRoleMap != null && !curRoleMap.isEmpty()) {
    			session.setAttribute("curRoleMap", curRoleMap);
        		model.addAttribute("curRoleMap", curRoleMap);
        		model.addAttribute("message", "True");
        	}

    		if(curRoleMap != null && curRoleMap.size() > 1) {
    			for (Map.Entry<String, List<PersonalSysModel>> entry : curRoleMap.entrySet()) {
    				String[] roleIds = RqcSapConflictService.getRoleIdsPersonalSys(entry.getValue());
        			List<MatrixModel> confList = RqcSapConflictService.getUserLevelConflictingRoles(entry.getKey(), roleIds);
        			if(confList != null && !confList.isEmpty()) {
        				userLvlConfRlsMaps.put(entry.getKey(), confList);
        			}
        		}
    		}
    		if(userLvlConfRlsMaps != null && !userLvlConfRlsMaps.isEmpty()) {
    			session.setAttribute("curUserConflicts", userLvlConfRlsMaps);
        		model.addAttribute("curUserConflicts", userLvlConfRlsMaps);
    		}

    		model.addAttribute("success", "Status: Count of total users found : "+((curRoleMap == null || curRoleMap.isEmpty())? "0" : curRoleMap.size()));
    		model.addAttribute("success1", "Status: Count of total users found : "+((userLvlConfRlsMaps == null || userLvlConfRlsMaps.isEmpty())? "0" : userLvlConfRlsMaps.size()));
    	} catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "conflictcheck/multiUserRoleReview";
    }




	@ResponseBody
    @GetMapping("/downloadMultiUserLvlExcel/{type}")
    @SuppressWarnings("all")
	public ResponseEntity<InputStreamResource> downloadMultiUserLvlRoleExcel(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		Map<String,List<PersonalSysModel>> currentRoleMap = null;
		Map<String, List<MatrixModel>> userLvlConflictMap = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
			filePath = RqcSapConflictService.writeMultiUserRolePDFCSVReport("CSV", fileNm, currentRoleMap);
		}else {
			fileNm ="UserRolesConflictList";
			userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
			filePath = RqcSapConflictService.writeMultiConfPDFCSVReport("CSV", fileNm, userLvlConflictMap);
		}
		File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


	@ResponseBody
    @GetMapping("/dwnMultiUserLvlPDF/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> dwnMultiUserConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String filePath = "";
		String fileNm ="UserRolesList";
		Map<String,List<PersonalSysModel>> currentRoleMap = null;
		Map<String, List<MatrixModel>> userLvlConflictMap = null;
		if("userroles".equals(type)) {
			fileNm ="UserRolesList";
			currentRoleMap = (Map<String, List<PersonalSysModel>>)request.getSession().getAttribute("curRoleMap");
			filePath = RqcSapConflictService.writeMultiUserRolePDFCSVReport("PDF", fileNm, currentRoleMap);
		}else {
			fileNm ="UserRolesConflictList";
			userLvlConflictMap = (Map<String, List<MatrixModel>>)request.getSession().getAttribute("curUserConflicts");
			filePath = RqcSapConflictService.writeMultiConfPDFCSVReport("PDF", fileNm, userLvlConflictMap);
		}
		File fl = new File(filePath);

    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	/***New Methods Designed to send User Leve Roles/Conflicts Info to Email***/


	//emailUtil.sendEmail("User Role and Conflict Details Review for - "+name,  Constants.ROLE_CONFLICT_MSG1, roleFilePath+";"+confFilePath, null);


    @GetMapping("/getUserEmailDetails")
	@SuppressWarnings("all")
    public String getUserEmailDetails(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Path Variable received ");
		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", '0');
		return "conflictcheck/sendEmail";
    }


	@PostMapping("/sendUserDataEmail")
	@SuppressWarnings("all")
    public String sendUserDataEmail(@RequestParam("txtEmailToAddress") String txtEmailToAddress, @RequestParam("txtEmailFromAddress") String txtEmailFromAddress, @RequestParam("txtEmailSubject") String txtEmailSubject, @RequestParam("dataType") String dataType,RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Variable received \n txtEmailToAddress :"+txtEmailToAddress+"\n txtEmailFromAddress :"+txtEmailFromAddress+"\n txtEmailSubject : "+txtEmailSubject+"\n dataType : "+dataType);

		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		emlInfo.setTo(txtEmailToAddress);
		emlInfo.setSubject(txtEmailSubject);
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", dataType);

		String roleFileNm ="";
		String confFileNm ="";
		String newConfFileNm ="";

		String roleFilePath = "";
		String confFilePath = "";
		String newConfFilePath = "";
		try {
			List<PersonalSysModel> currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			List<MatrixModel> userLvlConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("userLvlConflictRoles");
			List<MatrixModel> newRoleConflictRoles = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			//PDF Generation
			if("PDF".equals(dataType)) {
				if(currentRoleList != null && !currentRoleList.isEmpty()) {
					roleFileNm 		="UserRolesList.pdf";
					roleFilePath	= RqcSapConflictService.writeUserRolePDFReport(roleFileNm, currentRoleList);
				}

				if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
					confFileNm ="UserRolesConflictList.pdf";
					String title = "User level SOD Conflicts between Application Role(s)";
					confFilePath = RqcSapConflictService.writeConfPDFReport(title, confFileNm, userLvlConflictRoles);
				}

				if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
					newConfFileNm ="NewRolesConflictList.pdf";
					String title = "User level SOD Conflicts between New Application Role(s)";
					newConfFilePath = RqcSapConflictService.writeConfPDFReport(title, newConfFileNm, newRoleConflictRoles);
				}
			}else {
				if(currentRoleList != null && !currentRoleList.isEmpty()) {
					roleFileNm ="UserRolesList";
					roleFilePath = RqcSapConflictService.writeUserRoleCSVReport(roleFileNm, currentRoleList);
				}
				if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
					confFileNm ="UserRolesConflictList";
					confFilePath = RqcSapConflictService.writeConfCSVReport(confFileNm, userLvlConflictRoles);
				}
				if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
					newConfFileNm ="NewRolesConflictList";
					newConfFilePath = RqcSapConflictService.writeConfCSVReport(newConfFileNm, newRoleConflictRoles);
				}

			}

			String fileLocations ="";
			if(currentRoleList != null && !currentRoleList.isEmpty()) {
				fileLocations = roleFilePath;
			}
			if(userLvlConflictRoles != null && !userLvlConflictRoles.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+confFilePath;
				}
			}

			if(newRoleConflictRoles != null && !newRoleConflictRoles.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+newConfFilePath;
				}
			}

			model.addAttribute("message", "True");
			emailUtil.sendEmail(txtEmailSubject,  Constants.ROLE_CONFLICT_MSG1, fileLocations, null, txtEmailToAddress, txtEmailFromAddress);

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage(), e);
			model.addAttribute("error : Failure sending email", e.getMessage());
			return "conflictcheck/sendEmail";
		}
		model.addAttribute("success", "User Role/Conflict review email send successfully ("+dataType+").....!");
    	return "conflictcheck/sendEmail";
    }

	@GetMapping("/getUserConfEmailDetails")
	@SuppressWarnings("all")
    public String getUserConfEmailDetails(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Path Variable received :");
		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", '0');
		return "conflictcheck/sendEmailNewRoles";
    }

	@PostMapping("/sendUserConfDataEmail")
	@SuppressWarnings("all")
    public String sendUserConfDataEmail(@RequestParam("txtEmailToAddress") String txtEmailToAddress, @RequestParam("txtEmailFromAddress") String txtEmailFromAddress, @RequestParam("txtEmailSubject") String txtEmailSubject, @RequestParam("dataType") String dataType,RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Variable received \n txtEmailToAddress :"+txtEmailToAddress+"\n txtEmailFromAddress :"+txtEmailFromAddress+"\n txtEmailSubject : "+txtEmailSubject+"\n dataType : "+dataType);

		EmailInfoModel emlInfo = emailUtil.getEmailInfo((String)request.getSession().getAttribute(Constants.ACTIVE_USER));
		emlInfo.setTo(txtEmailToAddress);
		emlInfo.setSubject(txtEmailSubject);
		model.addAttribute("emlInfo", emlInfo);
		model.addAttribute("format", dataType);

		String newRolesConfFile ="";
		String newRolesConfFilePath = "";

		String newAndExtngConfFile="";
		String newAndExtngConfFilePath = "";
		try {

			//List<PersonalSysModel> currentRoleList = (List<PersonalSysModel>)request.getSession().getAttribute("currentRoleList");
			List<MatrixModel> curRoleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
			List<MatrixModel> newRoleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
			List<String>invldRls = (List<String>)request.getSession().getAttribute("invldRls");
			//PDF Generation

			if("PDF".equals(dataType)) {
				if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
					newAndExtngConfFile	="ExistingAndRequestedRoleConflicts.pdf";
					String title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
					newAndExtngConfFilePath	= RqcSapConflictService.writeConfPDFReport(title, newAndExtngConfFile, curRoleConflictList);
				}

				if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
					newRolesConfFile ="ConflictsInRolesRequested.pdf";
					String title = "Requested New Role(s) SOD Conflicts with each other";
					newRolesConfFilePath = RqcSapConflictService.writeConfPDFReport(title, newRolesConfFile, newRoleConflictList);
				}
			}else {
				if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
					newAndExtngConfFile ="ExistingAndRequestedRoleConflicts";
					newAndExtngConfFilePath = RqcSapConflictService.writeConfCSVReport(newAndExtngConfFile, curRoleConflictList);
				}
				if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
					newRolesConfFile ="ConflictsInRolesRequested";
					newRolesConfFilePath = RqcSapConflictService.writeConfCSVReport(newRolesConfFile, newRoleConflictList);
				}
			}

			String fileLocations ="";
			if(curRoleConflictList != null && !curRoleConflictList.isEmpty()) {
				fileLocations = newAndExtngConfFilePath;
			}
			if(newRoleConflictList != null && !newRoleConflictList.isEmpty()) {
				if(fileLocations.length() > 0) {
					fileLocations +=";"+newRolesConfFilePath;
				}
			}
			model.addAttribute("message", "True");
			emailUtil.sendEmail(txtEmailSubject,  Constants.ROLE_CONFLICT_MSG1, fileLocations, invldRls, txtEmailToAddress, txtEmailFromAddress);

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage(), e);
			model.addAttribute("error : Failure sending email", e.getMessage());
			return "conflictcheck/sendEmailNewRoles";
		}
		model.addAttribute("success", "User Role/Conflict review email send successful.....!");
    	return "conflictcheck/sendEmailNewRoles";
    }

}
