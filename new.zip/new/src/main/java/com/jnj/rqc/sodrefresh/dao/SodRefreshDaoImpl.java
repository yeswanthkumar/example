package com.jnj.rqc.sodrefresh.dao;

import java.sql.SQLException;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.util.Utility;




@Service
public class SodRefreshDaoImpl  extends BaseDao implements SodRefreshDao {
	static final Logger log = LoggerFactory.getLogger(SodRefreshDaoImpl.class);
	SimpleJdbcCall simJdbcCall;


	@Override
	public String refreshMV(String serverEnv, String viewName) throws SQLException, DataAccessException {
		JdbcTemplate template = getServerTemplate(serverEnv);
		template.execute("BEGIN dbms_mview.refresh('"+viewName+"', 'c');END;");
		log.info(serverEnv+" View Refresh complete :: "+viewName +"@ Time: "+Utility.fmtMMDDYYYYTime(Calendar.getInstance().getTime()));
		return "success";
	}


	@Override
	public String loadSodStagingData(String envName)  throws SQLException, DataAccessException{
		JdbcTemplate template = getServerTemplate(envName);
		template.execute("BEGIN sod_extr.pkg_sod_maint.load_all_sources();END;");
		log.info(envName+" LOAD ALL STAGE DATA (sod_extr.pkg_sod_maint.load_all_sources) Complete:: @ Time: "+Utility.fmtMMDDYYYYTime(Calendar.getInstance().getTime()));
		return "success";
	}

	@Override
	public String refreshSODMailer(String envName) throws SQLException, DataAccessException {
		JdbcTemplate template = getServerTemplate(envName);

		String delSql = " DELETE FROM sod_extr.sod_mailer ";
	 	int deletedRecords =   template.update(delSql);
	 	log.info("Total Records Deleted from SOD_EXTR.SOD_MAILER : "+ deletedRecords);

	 	String insSql = " insert into sod_extr.sod_mailer(wwid, user_id, first_name, last_name, src_sys1, src_sys2, code1, code2, co, waivers, mitigating_control, supvr_wwid, supvr_email, load_date) "+
	 					" SELECT vw.wwid, vw.user_id, vw.first_name, vw.last_name, vw.src_sys1, vw.src_sys2, vw.code1, vw.code2, vw.co, vw.waivers, vw.mitigating_control, "+
	 					" mv.jnj_supvr_wwid_nbr, mv_supvr.jnj_email_addr_txt, sysdate "+
	 					" FROM SOD_EXTR.sod_mailer_vw vw, SOD_EXTR.jjeds_emp_extr_mv mv,  SOD_EXTR.jjeds_emp_extr_mv mv_supvr "+
	 					" WHERE vw.WWID = mv.WWID_NBR and mv.jnj_supvr_wwid_nbr = mv_supvr.wwid_nbr ";
	 	int result = template.update(insSql);
	 	log.info("Total Records Inserted into SOD_EXTR.SOD_MAILER : "+ result);

	 	return "Total Records Inserted into SOD_EXTR.SOD_MAILER : "+result;
	}












		/**
		 * Method  : SodRefreshDaoImpl.java.getServerTemplate()
		 *		   :<b>@param serverEnv
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Nov 10, 2021 5:14:14 PM
		 * Purpose : Based on current environemnt, method returns DEV/PROD Template
		 * @return : JdbcTemplate
		 */
	private JdbcTemplate getServerTemplate(String serverEnv ) {
		JdbcTemplate template = null;
		if("PRODUCTION".equalsIgnoreCase(serverEnv)) {
			template = getJdbcTemplatePRODSodRefresh();
		}else {
			template = getJdbcTemplateQASodRefresh();
		}
		return template;
	}



}
