package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class HanaRole2SodModel {
	private String role1;
	private String role2;
	private String riskId;
	private String riskDesc;
	private String funcA;
	private String funcADesc;
	private String funcB;
	private String funcBDesc;
	private String riskLevel;
	private String regulation;
	private String trgtCon;
	private String mitiCntrl;
	private String complMgr;
	private String rulesetGpo;


	@Override
	public String toString() {
		return "HanaDBRiskModel [role1="+ role1 + "role2=" + role1+ "riskId=" + riskId + ", riskDesc=" + riskDesc + ", funcA=" + funcA + ", funcADesc="
				+ funcADesc + ", funcB=" + funcB + ", funcBDesc=" + funcBDesc + ", riskLevel=" + riskLevel
				+ ", regulation=" + regulation + ", trgtCon=" + trgtCon + ", mitiCntrl=" + mitiCntrl + ", complMgr="
				+ complMgr + ", rulesetGpo=" + rulesetGpo + "]";
	}


	public String getData() {
		return  role1+"~"+role2 + "~" + riskId + "~" + riskDesc + "~" + funcA + "~" + funcADesc + "~" + funcB + "~" + funcBDesc + "~" + riskLevel
				+ "~" + regulation + "~" + trgtCon + "~" + mitiCntrl + "~" + complMgr + "~" + rulesetGpo;
	}




}
