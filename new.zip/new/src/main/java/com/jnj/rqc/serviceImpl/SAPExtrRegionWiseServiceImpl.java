package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.U2RFinalSummaryMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dao.SAPExtrGaaDao;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.sch.CriticalRoleModel;
import com.jnj.rqc.sch.SchAdminModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;



@Service
public class SAPExtrRegionWiseServiceImpl implements SAPExtrRegionWiseService{

	static final Logger log = LoggerFactory.getLogger(SAPExtrRegionWiseServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;

	@Autowired
	SAPExtrGaaDao sAPExtrGaaDao;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	EmailUtil emailUtil;

	@Autowired
	GenesisDao genesisDao;



	@Override
	public List<TrfCntrlSchModel> getAllTrfCntlScheduls(List<String> regions) {
		List<TrfCntrlSchModel> schList = new ArrayList<>();
		try{
			 schList = sAPExtrRegionWiseDao.getAllTrfCntrlSchedules(regions);

		} catch (Exception e) {
			log.error("ERROR Getting Schedules:"+e.getMessage(), e);
		}
		return schList;
	}

	@Override
	public List<TrfCntrlSchModel> getAllUser2RoleScheduls(List<String> regions) {
		List<TrfCntrlSchModel> schList = new ArrayList<>();
		try{
			 schList = sAPExtrRegionWiseDao.getAllUser2RoleSchedules(regions);

		} catch (Exception e) {
			log.error("ERROR Getting USER2ROLE Schedules:"+e.getMessage(), e);
		}
		return schList;
	}


	@Override
	public List<TrfCntrlSchModel> getAllUser2CriticalRoleScheduls(List<String> regions) {
		List<TrfCntrlSchModel> schList = new ArrayList<>();
		try{
			 schList = sAPExtrRegionWiseDao.getAllUser2CriticalRoleSchedules(regions);

		} catch (Exception e) {
			log.error("ERROR Getting USER2CRITICALROLE Schedules:"+e.getMessage(), e);
		}
		return schList;
	}

	@Override
	public List<TrfCntrlSchModel> getAllUser2SodScheduls(List<String> regions) {
		List<TrfCntrlSchModel> schList = new ArrayList<>();
		try{
			 schList = sAPExtrRegionWiseDao.getAllUser2SodSchedules(regions);

		} catch (Exception e) {
			log.error("ERROR Getting USER2SOD Schedules:"+e.getMessage(), e);
		}
		return schList;
	}


	@Override
	public Map<String, List<TrfCntrlSchModel>> getTrfCntlRegionSchedule(String region) {
		Map<String, List<TrfCntrlSchModel>> schMap = new HashMap<>();
		try {
			 List<TrfCntrlSchModel> schedules = sAPExtrRegionWiseDao.getSchedulerStatus(region);
			 if(schedules != null && !schedules.isEmpty()) {
				 List<TrfCntrlSchModel> schLst= null;
				 for(TrfCntrlSchModel sch : schedules) {
					 if(sch.getSchStatus().equals("C")) {
						 if(schMap.containsKey(Constants.COMPLETED_SCH)) {
							 schLst = schMap.get(Constants.COMPLETED_SCH);
						 }else {
							 schLst = new ArrayList<>();
						 }
						 schLst.add(sch);
						 schMap.put(Constants.COMPLETED_SCH, schLst);
					 }else {
						 if(schMap.containsKey(Constants.WIP_SCH)) {
							 schLst = schMap.get(Constants.WIP_SCH);
						 }else {
							 schLst = new ArrayList<>();
						 }
						 schLst.add(sch);
						 schMap.put(Constants.WIP_SCH, schLst);
					 }
				 }
			 }
		} catch (Exception e) {
			log.error("ERROR Getting Schedules:"+e.getMessage(), e);
		}
		return schMap;
	}

	@Override
	public boolean saveScheduleTrfContol(String region, UserSearchModel curUser, String type) {
		boolean result = false;
		try {
			result = sAPExtrRegionWiseDao.saveSchedule(region, curUser, type);
		} catch (Exception e) {
			log.error("ERROR Saving Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public boolean saveScheduleUser2Role(String region, UserSearchModel curUser, String type) {
		boolean result = false;
		try {
			result = sAPExtrRegionWiseDao.saveScheduleUser2Role(region, curUser, type);
		} catch (Exception e) {
			log.error("ERROR Saving Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public boolean saveScheduleUser2CriticalRole(String region, UserSearchModel curUser, String type) {
		boolean result = false;
		try {
			result = sAPExtrRegionWiseDao.saveScheduleUser2CriticalRole(region, curUser, type);
		} catch (Exception e) {
			log.error("ERROR Saving Critical Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public boolean saveScheduleUser2Sod(String region, UserSearchModel curUser, String type) {
		boolean result = false;
		try {
			result = sAPExtrRegionWiseDao.saveScheduleUser2Sod(region, curUser, type);
		} catch (Exception e) {
			log.error("ERROR Saving User to Sod Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	/* (non-Javadoc)
	 * @see com.jnj.rqc.service.SAPExtrRegionWiseService#getCurrentTrfSchedule(java.lang.String)
	 * Returns Currently Active Schedules
	 */
	@Override
	public List<TrfCntrlSchModel> getCurrentTrfSchedule(String region, String status, String sType){
		List<TrfCntrlSchModel> result = new ArrayList<>();
		try {
			result = sAPExtrRegionWiseDao.getCurActTrfSchedule(region, status, sType);
		} catch (Exception e) {
			log.error("ERROR getting current Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public List<TrfCntrlSchModel> getCurrentUser2RoleSchedule(String region, String status, String sType){
		List<TrfCntrlSchModel> result = new ArrayList<>();
		try {
			result = sAPExtrRegionWiseDao.getCurActUser2RoleSchedule(region, status, sType);
		} catch (Exception e) {
			log.error("ERROR getting current Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public List<TrfCntrlSchModel> getCurrentUser2CriticalRoleSchedule(String region, String status, String sType){
		List<TrfCntrlSchModel> result = new ArrayList<>();
		try {
			result = sAPExtrRegionWiseDao.getCurActUser2CriticalRoleSchedule(region, status, sType);
		} catch (Exception e) {
			log.error("ERROR getting current Critical Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public List<TrfCntrlSchModel> getCurrentUser2SodSchedule(String region, String status, String sType){
		List<TrfCntrlSchModel> result = new ArrayList<>();
		try {
			result = sAPExtrRegionWiseDao.getCurActUser2SodSchedule(region, status, sType);
		} catch (Exception e) {
			log.error("ERROR getting current User2Sod Schedules: "+e.getMessage(), e);
		}
		return result;
	}
	@Override
	public List<SchAdminModel> getAllActiveSchedulers(){
		List<SchAdminModel> schList = new ArrayList<>();
		try {
			schList = sAPExtrRegionWiseDao.getActiveSchedulers();
		} catch (Exception e) {
			log.error("ERROR Retrieving Active Schedule: "+e.getMessage(), e);
		}
		return schList;
	}




	@Override
	public int updateTrnferSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType) {
		int count=0;
		try {
			count = sAPExtrRegionWiseDao.updateTransferSchStatus(activeSchedule.getRegion(), status, activeSchedule.getCreatedBy(), sType);
		} catch (Exception e) {
			log.error("ERROR Updating Transfer Scheduler Status "+e.getMessage(), e);
		}
		return count;
	}

	@Override
	public int updateUser2RoleSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType) {
		int count=0;
		try {
			count = sAPExtrRegionWiseDao.updateUser2RoleSchStatus(activeSchedule.getRegion(), status, activeSchedule.getCreatedBy(), sType);
		} catch (Exception e) {
			log.error("ERROR Updating Transfer Scheduler Status "+e.getMessage(), e);
		}
		return count;
	}


	@Override
	public int updateUser2CriticalRoleSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType) {
		int count=0;
		try {
			count = sAPExtrRegionWiseDao.updateUser2CriticalRoleSchStatus(activeSchedule.getRegion(), status, activeSchedule.getCreatedBy(), sType);
		} catch (Exception e) {
			log.error("ERROR Updating User To Critical  Scheduler Status "+e.getMessage(), e);
		}
		return count;
	}

	@Override
	public int updateUser2SodSchStatus(TrfCntrlSchModel activeSchedule, String status, String sType) {
		int count=0;
		try {
			count = sAPExtrRegionWiseDao.updateUser2SodSchStatus(activeSchedule.getRegion(), status, activeSchedule.getCreatedBy(), sType);
		} catch (Exception e) {
			log.error("ERROR Updating User To Sod  Scheduler Status "+e.getMessage(), e);
		}
		return count;
	}

	@Override
	public String sendProcessEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String userId = activeSchedule.getCreatedBy();
			UserSearchModel user = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
			String regId  = activeSchedule.getRegion();
			String subject=("C".equals(sType))? "ERP TRANSFER CONTROL Data Created for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date()):"ERP TRANSFER CONTROL Data Export to GENESIS for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendSapTrfEmail(envName+" - "+subject, summary, user,  "CS&MRequ@HCSUS.JNJ.com", activeSchedule.getRegion(), sType, proc);
		} catch (Exception e) {
			log.error("ERROR Sending "+envName+" Transfer Control message: "+e.getMessage(), e);
		}
		return null;
	}

	@Override
	public String sendUser2RoleEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String userId = activeSchedule.getCreatedBy();
			UserSearchModel user = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
			String regId  = activeSchedule.getRegion();
			String subject=("C".equals(sType))? "ERP USER TO ROLE Data Created for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date()):"ERP USER TO ROLE Data Export to Genesis for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendSapTrfEmail(envName+" - "+subject, summary, user,  "CS&MRequ@HCSUS.JNJ.com", activeSchedule.getRegion(), sType, proc);
		} catch (Exception e) {
			log.error("Error Sending "+envName+" USER To ROLE message: "+e.getMessage(), e);
		}
		return null;
	}

	@Override
	public String sendUser2CriticalRoleEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String userId = activeSchedule.getCreatedBy();
			UserSearchModel user = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
			String regId  = activeSchedule.getRegion();
			String subject=("C".equals(sType))? "ERP USER TO CRITICAL ROLE Data Created for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date()):"ERP USER TO CRITICAL ROLE Data Export to Genesis for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendSapUser2CriticalEmail(envName+" - "+subject, summary, user,  "CS&MRequ@HCSUS.JNJ.com", activeSchedule.getRegion(), sType);
		} catch (Exception e) {
			log.error("Error Sending "+envName+" USER To ROLE message: "+e.getMessage(), e);
		}
		return null;
	}

	@Override
	public String sendUser2SodEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String userId = activeSchedule.getCreatedBy();
			UserSearchModel user = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
			String regId  = activeSchedule.getRegion();
			String subject=("C".equals(sType))? "ERP USER TO SOD Data Created for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date()):"ERP USER TO SOD Data Export to Genesis for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendSapUser2SodEmail(envName+" - "+subject, summary, user,  "CS&MRequ@HCSUS.JNJ.com", activeSchedule.getRegion(), sType);
		} catch (Exception e) {
			log.error("Error Sending "+envName+" USER To ROLE message: "+e.getMessage(), e);
		}
		return null;
	}


	@Override
	public List<String> allowRegionsForSch(List<String> regNames, List<TrfCntrlSchModel> schList) {
		List<String> rgnList = new ArrayList<>();
		rgnList.addAll(regNames);
		for(TrfCntrlSchModel trfSchMdl : schList) {
			if(trfSchMdl.getType().equals("C")) {
				for (int i = 0; i < rgnList.size(); i++) {
			        if (Objects.equals(trfSchMdl.getRegion(), rgnList.get(i))) {
			        	rgnList.remove(i);
			            i--;
			        }
			    }
			}
		}
		return rgnList;
	}


	@Override
	public List<TrfCntrlSummaryMdl> getTransferSummary() {
		List<TrfCntrlSummaryMdl> sumList = new ArrayList<>();
		try {
			sumList = sAPExtrRegionWiseDao.getTrfContrlSummary();
		} catch (Exception e) {
			log.error("ERROR Saving Schedule: "+e.getMessage(), e);
		}
		return sumList;
	}


	@Override
	public List<TrfCntrlSummaryMdl> getUser2RoleSummary() {
		List<TrfCntrlSummaryMdl> sumList = new ArrayList<>();
		try {
			sumList = sAPExtrRegionWiseDao.getUser2RoleSummary();
		} catch (Exception e) {
			log.error("ERROR Saving Schedule: "+e.getMessage(), e);
		}
		return sumList;
	}


	@Override
	public List<TrfCntrlSummaryMdl> getUser2CriticalRoleSummary() {
		List<TrfCntrlSummaryMdl> sumList = new ArrayList<>();
		try {
			sumList = sAPExtrRegionWiseDao.getUser2CriticalRoleSummary();
		} catch (Exception e) {
			log.error("ERROR Getting Critical Role Summary: "+e.getMessage(), e);
		}
		return sumList;
	}

	@Override
	public List<TrfCntrlSummaryMdl> getUser2SodSummary() {
		List<TrfCntrlSummaryMdl> sumList = new ArrayList<>();
		try {
			sumList = sAPExtrRegionWiseDao.getUser2SodSummary();
		} catch (Exception e) {
			log.error("ERROR Getting User to Sod Summary: "+e.getMessage(), e);
		}
		return sumList;
	}

	@Override
	public int getExistingScheduleCount(String region, String sType, String dataType) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.countScheduleforRegion(region, sType, dataType);
		} catch (Exception e) {
			log.error("ERROR getting Schedule count: "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int getExistingU2SSchCount(String region, String sType, String dataType) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.countU2SSchforRegion(region, sType, dataType);
		} catch (Exception e) {
			log.error("ERROR getting Schedule count: "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int deleteTrfTransData(String region, String platform, String env, String sysm) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.deleteTrfTransactionData(region, platform, env, sysm);
		} catch (Exception e) {
			log.error("ERROR Saving Schedule: "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int deleteUser2RoleTransData(String region, String platform, String env, String sysm) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.deleteUser2RoleTransactionData(region, platform, env, sysm);
		} catch (Exception e) {
			log.error("ERROR Deleting Transaction Data: "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int deleteUser2SodTransData(String region, String platform, String env, String sysm) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.deleteUser2SodTransactionData(region, platform, env, sysm);
		} catch (Exception e) {
			log.error("ERROR Deleting Transaction Data: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public Map<String, String> loadAllCriticalRoles() {
		Map<String, String> criticalRoleMap = new HashMap<>();
		try{
			criticalRoleMap = Utility.getUser2CriticalMatrix();
			if(criticalRoleMap == null || criticalRoleMap.isEmpty()) {
				criticalRoleMap = new HashMap<>();
				List<CriticalRoleModel> result = sAPExtrRegionWiseDao.getAllCriticalRoles();
				if(result != null && !result.isEmpty()) {
					for(CriticalRoleModel cm : result) {
						criticalRoleMap.put(cm.getPlatform().toUpperCase().trim()+"_"+cm.getRole().toUpperCase().trim(), cm.getPlatform().toUpperCase().trim()+"_"+cm.getRole().toUpperCase().trim());
					}
					Utility.setUser2CriticalMatrix(criticalRoleMap);
				}
			}
		} catch (Exception e) {
			log.error("ERROR Reading CRITICAL ROLE MATRIX: "+e.getMessage(), e);
		}
		return criticalRoleMap;
	}

	@Override
	public List<TrfCntrlSchModel> getExistingCriticalSchedules(String region, String sType) {
		List<TrfCntrlSchModel> result = null;
		try {
			  result = sAPExtrRegionWiseDao.getCriticalScheduleforRegion(region, sType);
		} catch (Exception e) {
			log.error("ERROR getting User2Critical Schedules : "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<TrfCntrlSchModel> getExistingU2SSchedules(String region, String sType) {
		List<TrfCntrlSchModel> result = null;
		try {
			  result = sAPExtrRegionWiseDao.getUserToSodScheduleforRegion(region, sType);
		} catch (Exception e) {
			log.error("ERROR getting User 2 Sod Schedule : "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<TrfCntrlSchModel> getExistingTRForU2RSchedules(String region, String sType, String process){
		List<TrfCntrlSchModel> result = null;
		try {
			  result = sAPExtrRegionWiseDao.getTRFOrU2RScheduleforRegion(region, sType, process);
		} catch (Exception e) {
			log.error("ERROR getting Schedule count: "+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int delUser2CriticalRoleTransData(String region, String platform, String env, String sysm) {
		int result = 0;
		try {
			result = sAPExtrRegionWiseDao.delUser2CriticalRoleTransactionData(region, platform, env, sysm);
		} catch (Exception e) {
			log.error("ERROR Deleting Schedule: "+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public String sendUser2RoleCompleteDataEmail(TrfCntrlSchModel activeSchedule, List<SAPTrfCntrlSummaryMdl> summary, String sType, String proc) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			String userId = activeSchedule.getCreatedBy();
			UserSearchModel user = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 1);
			String regId  = activeSchedule.getRegion();
			List<SAPTrfCntrlSummaryMdl> rawDataSum = getRawDataSummary(regId);

			List<U2RFinalSummaryMdl> finSumLst = getRegnFinalSum(rawDataSum, summary);

			String subject="ERP USER TO ROLE Data Created for Region: "+regId+" Date:"+Utility.fmtMMDDYYYYTime(new Date());
			emailUtil.sendUser2RoleSummEmail(envName+" - "+subject, finSumLst, user,  "CS&MRequ@HCSUS.JNJ.com", activeSchedule.getRegion(), sType, proc);
		} catch (Exception e) {
			log.error("Error Sending "+envName+" USER To ROLE message: "+e.getMessage(), e);
		}
		return null;
	}


	@Override
	public List<SAPTrfCntrlSummaryMdl> getRawDataSummary(String regId) {
		List<SAPTrfCntrlSummaryMdl> resultLst = new ArrayList<>();
		try {
			resultLst = sAPExtrRegionWiseDao.getRawDataRegnSummary(regId);
		} catch (Exception e) {
			log.error("ERROR Getting Raw Data Summary: "+e.getMessage(), e);
		}
		return resultLst;
	}


private List<U2RFinalSummaryMdl> getRegnFinalSum(List<SAPTrfCntrlSummaryMdl> rawDataSum, List<SAPTrfCntrlSummaryMdl> actDataSum) {

		List<U2RFinalSummaryMdl> result = new ArrayList<>();

		Map<String, Integer> raw = new HashMap<>();
		Map<String, Integer> act = new HashMap<>();

		for(SAPTrfCntrlSummaryMdl mdl:rawDataSum) {
			String syst=mdl.getSystem().trim().replaceAll("[^\\.A-Za-z0-9]", "");
			String key=mdl.getRegion()+"_"+mdl.getPlatform()+"_"+mdl.getEnvironment()+"_"+syst;
			raw.put(key.toUpperCase(), mdl.getCount());
		}

		for(SAPTrfCntrlSummaryMdl mdl:actDataSum) {
			String syst=mdl.getSystem().trim().replaceAll("[^\\.A-Za-z0-9]", "");
			String key=mdl.getRegion()+"_"+mdl.getPlatform()+"_"+mdl.getEnvironment()+"_"+syst;
			act.put(key.toUpperCase(), mdl.getCount());
		}

		for(String id:raw.keySet()) {
			String[] idArr=id.split("_");
			U2RFinalSummaryMdl data = new U2RFinalSummaryMdl();
			data.setRegion(idArr[0]);
			data.setPlatform(idArr[1]);
			data.setEnvironment(idArr[2]);
			data.setSystem(idArr[3]);
			data.setTotal(raw.get(id));
			int actCnt = act.containsKey(id) ? act.get(id):0;
			data.setActvCount(actCnt);
			data.setInvlCount((data.getTotal() - actCnt));
			result.add(data);
		}

		//START  Dharm : Added the block to check if any system returned  ZERO Records
		if(act.size() > raw.size()) {
			for(String id:act.keySet()) {
				if(!raw.containsKey(id)) {
					String[] idArr=id.split("_");
					U2RFinalSummaryMdl data = new U2RFinalSummaryMdl();
					data.setRegion(idArr[0]);
					data.setPlatform(idArr[1]);
					data.setEnvironment(idArr[2]);
					data.setSystem(idArr[3]);
					data.setTotal(0);
					data.setActvCount(act.get(id));
					data.setInvlCount(0);
					result.add(data);
				}
			}
		}
		//END  Dharm : Added the block to check if any system returned  ZERO Records
		return result;
	}


}
