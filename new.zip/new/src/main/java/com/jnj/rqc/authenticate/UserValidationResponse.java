package com.jnj.rqc.authenticate;

public class UserValidationResponse {
	private String status;
    private String authenticatedUserEmail;

	public UserValidationResponse(String status, String authenticatedUserEmail) {
		super();
		this.status = status;
		this.authenticatedUserEmail = authenticatedUserEmail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAuthenticatedUserEmail() {
		return authenticatedUserEmail;
	}
	public void setAuthenticatedUserEmail(String authenticatedUserEmail) {
		this.authenticatedUserEmail = authenticatedUserEmail;
	}

}
