package com.jnj.rqc.models;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class UETktModel {
	private int 	reqId;
	private int 	reqTyp;
	private String  reqTypName;
	private Date   	reqDt;
	private String 	reqBy;
	private String 	reqByName;
	private String 	reqByNtId;
	private String 	userId;
	private String 	userNtId;
	private String 	userName;
	private String 	mgrWwid;
	private String 	mgrNtId;
	private String 	mgrName;
	private int 	prjId;
	private String 	prjName;
	//
	private String personaIds;
	private List<KeyValPair> personas;
	private String positionIds;
	private List<KeyValPair> positions;
	private String roleIds;
	private List<KeyValPair> roles;
	//

	private String 	secIds;
	private List<KeyValPair> sectors;
	private String 	accfIds;
	private List<KeyValPair> accfunctions;
	private String 	regIds;
	private List<KeyValPair> regions;
	private String 	cntryIds;
	private List<KeyValPair> countries;
	private String 	consIds;
	private List<KeyValPair> consUnits;
	private String 	respIds;
	private List<StrKeyValPair> respUnits;
	private int 	reqStatus;
	private String 	reqStatusDesc;
	private Date   	dtUpdated;
	private String  updtBy;
	private String comments;
	private int apprSeq;
	private List<TktApprLogMdl>approverLog;



}
