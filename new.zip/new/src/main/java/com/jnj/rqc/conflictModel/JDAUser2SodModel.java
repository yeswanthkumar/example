package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDAUser2SodModel extends JDADBRiskModel {

		private String wwId;  		//SYS.GRANTED_ROLES
		private String firstName;
		private String lastName;
		private String userStat;
		/*private String roleName;
		private String funcId;
		private String funcDesc;
		private String riskLevel;
		private String regulation;
		private String trgtCon;
		private String mitiCntrl;
		private String complMgr;
		private String rulesetGpo;
			*/


		@Override
		public String getData() {
			return   wwId+"~"+riskId + "~" + riskDesc +"~"+roleId+ "~"+roleName+"~" + funcId + "~" + funcDesc + "~" + riskLevel
					+ "~" + regulation + "~" + trgtCon + "~" + mitiCntrl + "~" + complMgr + "~" + rulesetGpo;
		}



	@Override
	public String toString() {
		return "JDAUser2SodModel [ riskId=" + riskId + ", riskDesc=" + riskDesc + ", roleId=" + roleId
				+ ", funcId=" + funcId + ", funcDesc=" + funcDesc + ", riskLevel="
				+ riskLevel + ", regulation=" + regulation + ", trgtCon=" + trgtCon + ", mitiCntrl=" + mitiCntrl
				+ ", complMgr=" + complMgr + ", rulesetGpo=" + rulesetGpo +  "]";
	}




}
