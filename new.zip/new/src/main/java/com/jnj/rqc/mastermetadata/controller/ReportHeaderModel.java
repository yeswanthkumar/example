package com.jnj.rqc.mastermetadata.controller;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportHeaderModel {
	private String reqId;
	private String typeId;
	private String requestedOn;
	private String reqStatus;
}
