package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.UserRole;
import com.jnj.rqc.service.PVCSUserDataService;

@Controller
public class PVCSUserDataController {
	static final Logger log = LoggerFactory.getLogger(PVCSUserDataController.class);
	@Autowired
	PVCSUserDataService pvcsUserDataService;


    @GetMapping("/uploadpage")
    public String gotoUpload() {
    	log.info("Routing to PVCS Upload page.");
        return "pvcs/upload";
    }

    @PostMapping("/upload")
    public String singleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Selected file :"+file.getOriginalFilename()+" for PVCS User Data upload");
    	if (file.isEmpty()) {
    		log.info("No file selected for upload OR file is empty.");
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("error", "File Status: No file selected, Please select file to upload...!");
            return "redirect:uploadStatus";
        }
    	try{
    		// Get the file and save it in Constants.UPLOAD_DIR
            byte[] bytes = file.getBytes();
            String fileNm = file.getOriginalFilename();
            if(fileNm.indexOf("\\") > 0) {
            	fileNm = fileNm.substring(fileNm.lastIndexOf("\\")+1);
            }
            Path path = Paths.get(Constants.UPLOAD_DIR + fileNm);

            Files.write(path, bytes);
            List<UserRole> userList = pvcsUserDataService.createUserCSV(path, request.getSession());
            redirectAttributes.addFlashAttribute("userList", userList);
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("success", "File Status: Uploaded successful file - " + file.getOriginalFilename());
        } catch (IOException e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "redirect:/uploadStatus";
    }

    @GetMapping("/uploadStatus")
    public String uploadStatus() {
        return "pvcs/upload";
    }

    @ResponseBody
    @GetMapping("/downloadExcel_OLD")
    public void download1(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) {
    	log.info("Starting download excel......!");
    	String filePath = request.getSession().getAttribute("PVCSUserFile").toString();
    	log.info("Starting download CSV file :"+filePath);
    	try{
    		FileInputStream fin = new FileInputStream(filePath);

    		// Set the content type and attachment header.  for txt file
            response.addHeader("Content-disposition", "attachment;filename="+filePath);
            response.setContentType("txt/plain");
            /* xls file
            response.addHeader("Content-disposition", "attachment;filename=sample.xls");
            response.setContentType("application/octet-stream");*/

            // Copy the stream to the response's output stream.
            IOUtils.copy(fin, response.getOutputStream());
            response.flushBuffer();
		} catch (Exception e) {
			 log.error("Error Downloading file:"+e.getMessage());
			 e.printStackTrace();
		}
    }

    @ResponseBody
    @GetMapping("/downloadExcel")
    public ResponseEntity<InputStreamResource> download(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	String filePath = request.getSession().getAttribute("PVCSUserFile").toString();
    	log.info("Starting download CSV file :"+filePath);
    	File fl = new File(filePath);

    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + filePath)
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

}