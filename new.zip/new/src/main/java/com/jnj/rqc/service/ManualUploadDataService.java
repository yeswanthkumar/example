package com.jnj.rqc.service;

import java.util.List;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapUser2SodModel;





/**
 * File    : <b>ManualUploadDataService.java</b>
 * @author : DChauras @Created : Aug 30, 2021 5:20:14 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface ManualUploadDataService {
	public List<SAPUserAccessModel> readTrfControlExcel(String path);
	public List<SapGaaUser2RoleModel> readUser2RoleExcel(String path);
	public List<SapUser2SodModel> readUser2SodExcel(String path);


	/*public List<UserRole> createUserCSV(Path filePath, HttpSession session);
	public Map<String, List<String>> readPVCSUserData(Path filePath);
	public String saveFile(MultipartFile file) throws IOException;
	public List<MemRevieModel> processNagsData(String path, int mon, int year, HttpServletRequest request)throws Exception;
	public List<MemRevieModel> readNagsData(String path, int mon, int year);

	public String writePdfOrCsv(String type, int mon, int year, List<MemRevieModel> data);

	public List<SrcSysMemRoleModel> processMemReport(String srcsystem) throws Exception;
	public String writeCsvReport(List<SrcSysMemRoleModel> data, String fileName);
	public UsrJJEdsMdl getJJEDSData(String winId);
*/


}
