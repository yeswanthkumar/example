package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.models.GrpUsrDateMdl;






/**
 * File    : <b>CSMDataService.java</b>
 * @author : DChauras @Created : Aug 8, 2022 2:26:45 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface CSMDataService {
	public String buildCSMDataExcel(List<GrpUsrDateMdl> adDataLst, String flName);
	public List<CSMHistDataMdl> readCSMExcel(String path, HttpServletRequest request);
	public int saveCSMDataToDB(List<CSMHistDataMdl> csmData);
	public String writeCSMDataCSV(List<CSMHistDataMdl> data, String fileName);
	public List<GrpUsrDateMdl> validateAndFilterData(Map<String, List<GrpUsrDateMdl>> adDataMap);
	public List<CSMModelAdGrpMap> readCSMModelDataXls(String path, HttpServletRequest request);
	public String writeCSMModelDataCSV(List<CSMModelAdGrpMap> data, String fileName);
	public int saveCSMModelDataToDB(List<CSMModelAdGrpMap> csmData);
	public int saveIAMCSMDataToDB(List<GrpUsrDateMdl> iamCsmData);
	public List<GrpUsrDateMdl> compareWithPreviousRun(List<GrpUsrDateMdl> step1DataList);
	public List<GrpUsrDateMdl> getAllIAMCSMDataFromDB();
	public int updateIAMCSMDataToComplete();



	//public List<SAPUserAccessModel> readTrfControlExcel(String path);
	//public List<SapGaaUser2RoleModel> readUser2RoleExcel(String path);
	//public List<SapUser2SodModel> readUser2SodExcel(String path);
}
