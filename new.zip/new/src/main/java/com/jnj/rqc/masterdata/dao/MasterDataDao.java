package com.jnj.rqc.masterdata.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.masterdata.dto.ZAccessTypeMdl;
import com.jnj.rqc.masterdata.dto.ZBussFuncMdl;
import com.jnj.rqc.masterdata.dto.ZPosVariantMdl;
import com.jnj.rqc.masterdata.dto.ZPositionMdl;
import com.jnj.rqc.masterdata.dto.ZRegionMdl;
import com.jnj.rqc.masterdata.dto.ZReqTypMdl;
import com.jnj.rqc.masterdata.dto.ZSectorMdl;
import com.jnj.rqc.masterdata.dto.ZSystemMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.userabs.models.BfSctrRegSystemMdl;
import com.jnj.rqc.userabs.models.BfSctrRegnMdl;
import com.jnj.rqc.userabs.models.BsnsFuncSctrsMdl;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarMdl;
import com.jnj.rqc.userabs.models.ZSysPosAccessMdl;
import com.jnj.rqc.userabs.models.ZSysPositionsMdl;

/**
 * File    : <b>MasterDataDao.java</b>
 * @author : DChauras @Created : Feb 1, 2023 3:24:05 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface MasterDataDao {

	/**
	 * Method  : MasterDataDao.java.getAllZBussFunc()
	 *		   :<b>@param bfid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:24:18 PM
	 * Purpose :
	 * @return : List<ZBussFuncMdl>
	*/
	public List<ZBussFuncMdl> getAllZBussFunc(int bfid)  throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZReqTyp()
	 *		   :<b>@param typid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:24:24 PM
	 * Purpose :
	 * @return : List<ZReqTypMdl>
	*/
	public List<ZReqTypMdl> getAllZReqTyp(int typid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZSectors()
	 *		   :<b>@param secid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:24:33 PM
	 * Purpose :
	 * @return : List<ZSectorMdl>
	*/
	public List<ZSectorMdl> getAllZSectors(int secid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZRegions()
	 *		   :<b>@param regid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:24:44 PM
	 * Purpose :
	 * @return : List<ZRegionMdl>
	*/
	public List<ZRegionMdl> getAllZRegions(int regid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZSystems()
	 *		   :<b>@param sysid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:24:53 PM
	 * Purpose :
	 * @return : List<ZSystemMdl>
	*/
	public List<ZSystemMdl> getAllZSystems(int sysid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZPositions()
	 *		   :<b>@param posid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:58:59 PM
	 * Purpose :
	 * @return : List<ZPositionMdl>
	*/
	public List<ZPositionMdl> getAllZPositions(int posid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZAccessTypes()
	 *		   :<b>@param accid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 3, 2023 3:49:34 PM
	 * Purpose : Lists all Access Types
	 * @return : List<ZAccessTypeMdl>
	*/
	public List<ZAccessTypeMdl> getAllZAccessTypes(int accid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZPosVariants()
	 *		   :<b>@param posvarid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Feb 9, 2023 5:04:14 PM
	 * Purpose : List All Position Variants
	 * @return : List<ZPosVariantMdl>
	*/
	public List<ZPosVariantMdl> getAllZPosVariants(int posvarid) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZBfSectors()
	 *		   :<b>@param bfId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 9, 2023 10:48:16 AM
	 * Purpose :Get All Mapping Data for Bufiness Function to Sectors
	 * @return : List<BsnsFuncSctrsMdl>
	*/
	public List<BsnsFuncSctrsMdl> getAllZBfSectors(String bfId) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZBfSecRegions()
	 *		   :<b>@param bfId
	 *		   :<b>@param secIds
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 10, 2023 10:18:33 AM
	 * Purpose :
	 * @return : List<BfSctrRegnMdl>
	*/
	public List<BfSctrRegnMdl> getAllZBfSecRegions(String bfId, String[] secIds) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZBfSecRegSystems()
	 *		   :<b>@param bfId
	 *		   :<b>@param secIds
	 *		   :<b>@param regIds
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 10, 2023 5:19:46 PM
	 * Purpose :
	 * @return : List<BfSctrRegSystemMdl>
	*/
	public List<BfSctrRegSystemMdl> getAllZBfSecRegSystems(String bfId, String[] secIds, String[] regIds) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZSystemPositions()
	 *		   :<b>@param sysId
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 13, 2023 3:24:19 PM
	 * Purpose : Method to Query all the POSITIONS for given System
	 * @return : List<ZSysPositionsMdl>
	*/
	public List<ZSysPositionsMdl> getAllZSystemPositions(String bfId, String[] secIds, String[] regIds, String sysIds) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZSysPosnsAccess()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 13, 2023 5:36:59 PM
	 * Purpose : Query all ZAccess Types for given System & Positions
	 * @return : List<ZSysPosAccessMdl>
	*/
	//public List<ZSysPosAccessMdl> getAllZSysPosnsAccess(String sysId, String[] posIds) throws SQLException, DataAccessException;
	public List<ZSysPosAccessMdl> getAllZSysPosnsAccess(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getAllZSysPosAccPvar()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@param accIds
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Mar 15, 2023 5:13:50 PM
	 * Purpose : All Positions for given ACCID's
	 * @return : List<ZSysPosAccPvarMdl>
	*/
	//public List<ZSysPosAccPvarMdl> getAllZSysPosAccPvar(String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException;
	public List<ZSysPosAccPvarMdl> getAllZSysPosAccPvar(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException;

	/**
	 * Method  : MasterDataDao.java.getSelectedExcsvPosVariants()
	 *		   :<b>@param sysid
	 *		   :<b>@param posvarids
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Apr 17, 2023 12:26:16 PM
	 * Purpose : Get All Position Variant Details for Accessive access.
	 * @return : List<RawSysDpendncMdl>
	*/
	public List<RawSysDpendncMdl> getSelectedExcsvPosVariants(String sysid, String[] posvarids) throws SQLException, DataAccessException;

	public List<StrKeyValPair> getStatusForVariants(String reqId, String sysid, String posid, String accid,	String posvarid) throws SQLException, DataAccessException;

	/**
		 * Method  : MasterDataDao.java.getZPosVariantName()
		 *		   :<b>@param sysId
		 *		   :<b>@param posvarid
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 17, 2023 3:48:30 PM
		 * Purpose : Get Position Variant Name for given System
		 * @return : List<String>
		 */
	public List<String> getZPosVariantName(String sysId, String posvarid) throws SQLException, DataAccessException;



}
