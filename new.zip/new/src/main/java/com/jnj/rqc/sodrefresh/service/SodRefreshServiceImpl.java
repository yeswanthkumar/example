package com.jnj.rqc.sodrefresh.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.sodrefresh.dao.SodRefreshDao;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


@Service
public class SodRefreshServiceImpl implements SodRefreshService{
	static final Logger log = LoggerFactory.getLogger(SodRefreshServiceImpl.class);

	@Autowired
	Environment environment;
	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	UserIdentityDao userIdentityDao;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	SodRefreshDao sodRefreshDao;


	@Override
	public Map<String, Object> runSodRefresh(String serverEnv, Map<String, Object> errorMap) {
		Calendar startTime = Calendar.getInstance(), endTime = null;
		try{
			//START STEP - 1
			log.info("SOD REFRESH ==> Refresh All Materialised Views for "+serverEnv+" Started @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    		refreshAllMVs(serverEnv, errorMap);
    		log.info("SOD REFRESH ==> Refresh All Materialised Views for "+serverEnv+" Completed @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		//END STEP - 1

    		//START STEP - 2
    		log.info("SOD REFRESH ==> Load All Staging Data for "+serverEnv+" Started @ "+Utility.fmtMMDDYYYYTime(new Date()));
        	loadAllStagingData(serverEnv, errorMap);
        	log.info("SOD REFRESH ==> Load All Staging Data for "+serverEnv+" Completed @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		//END STEP - 2

        	//START STEP - 3
			log.info("SOD REFRESH ==> Refresh Manager Mailer Materialised Views for "+serverEnv+" Started @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		refreshNamedMV(serverEnv, "SOD_EXTR.ALL_ACCESS_MGR_MAILER_MV", errorMap);
    		log.info("SOD REFRESH ==> Refresh Manager Mailer Materialised Views for "+serverEnv+" Completed @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		//END STEP - 3

    		//START STEP - 4
    		log.info("SOD REFRESH ==> Refresh NAGS_DATA Materialised Views for "+serverEnv+" Started @ "+Utility.fmtMMDDYYYYTime(new Date()));
        	refreshNamedMV(serverEnv, "SOD_EXTR.NAGS_DATA", errorMap);
        	log.info("SOD REFRESH ==> Refresh Manager Mailer Materialised Views for "+serverEnv+" Completed @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		//END STEP - 4

        	//START STEP - 5
    		log.info("SOD REFRESH ==> Refresh SOD_MAILER  for "+serverEnv+" Started @ "+Utility.fmtMMDDYYYYTime(new Date()));
        	refreshSodMailer(serverEnv, errorMap);
        	log.info("SOD REFRESH ==> Refresh SOD_MAILER for "+serverEnv+" Completed @ "+Utility.fmtMMDDYYYYTime(new Date()));
    		//END STEP - 5

		} catch (Exception e) {
			log.error("ERROR in SOD_REFRESH(Refresh All Materialised Views) :"+e.getMessage(), e);
		}


		/*if(!errorMap.isEmpty()) {
		errorMap.forEach((key, value) -> System.out.println(key + ":" + value.toString()));
		}*/
		return errorMap;
	}



	@Override
	public Map<String, Object> refreshSodMailer(String serverEnv, Map<String, Object> errorMap) {
		try{
			sodRefreshDao.refreshSODMailer(serverEnv);
		} catch (Exception e) {
			log.error("Exception in sod_extr.SOD_MAILER Refresh Msg:"+e.getMessage());
			errorMap.put("sod_extr.SOD_MAILER", e.getMessage());
		}
		return errorMap;
	}



	@SuppressWarnings("all")
	@Override
	public Map<String, Object> refreshAllMVs(String serverEnv, Map<String, Object> errorMap) {
		List<String> viewList = Utility.loadOneClickPropertyU2R("SOD_VIEWS");
		if(!viewList.isEmpty()) {
			int counter=0;
			for(String viewName : viewList) {
				viewName = viewName.toUpperCase();
				log.info((++counter)+". Refreshing Materialised View : "+viewName);
				//sodRefreshDao.refreshMV(serverEnv, viewName);
				refreshNamedMV(serverEnv, viewName, errorMap);
			}
		}
		return errorMap;
	}





	@Override
	public Map<String, Object> loadAllStagingData(String envName, Map<String, Object> errorMap) {
		try{
			sodRefreshDao.loadSodStagingData(envName);
		} catch (Exception e) {
			log.error("Exception in sod_extr.pkg_sod_maint.load_all_sources Msg:"+e.getMessage());
			errorMap.put("sod_extr.pkg_sod_maint.load_all_sources", e.getMessage());
		}
		return errorMap;
	}


	@SuppressWarnings("all")
	@Override
	public Map<String, Object> refreshNamedMV(String serverEnv, String viewName, Map<String, Object> errorMap) {
		try{
			log.info("Refreshing Materialised View : "+viewName);
			sodRefreshDao.refreshMV(serverEnv, viewName);
		} catch (Exception e) {
			log.error("Exception Refreshing View : "+viewName+"  Msg: "+e.getMessage());
			errorMap.put(viewName, e.getMessage());
		}
		return errorMap;
	}




}
