package com.jnj.rqc.useridentity.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SubmitUsern {
		private String REQ_ID = "";
		private String USERID = "";
		private String FNAME = "";
		private String LNAME = "";
		private String PROVUSER = "";
		private String SNC_NAME = "";//  "p:CN=dgandava@its.jnj.com";
		private String UNSEC_SNC = "";
		private String ACCNO = "";
		private String VALID_FROM = "";
		private String VALID_TO = "";
		private String EMPPOSITION = "";
		private String EMPJOB = "";
		private String PERSONNELNO = "";
		private String PERSONNELAREA = "";
		private String EMAIL = "";
		private String TELNUMBER = "";
		private String DEPARTMENT = "";
		private int COMPANY = 7555;
		private String LOCATION = "";
		private String COSTCENTER = "";
		private String PRINTER = "";
		private String SECTELNUMBER = "";
		private String ORGUNIT  = "";
		private String EMPTYPE = "";
		private String FULLNAME = "";
		private String BUSS_PROC = "FINANCE";
		private String BUSINESS_AREA = "";
		private String FUNCTIONAL_AREA  = "";
		private String BUILDING  = "";
		private String FLOOR = "";
		private String ROOM_NO = "";
		private String COMM_TYPE = "";
		private String ACADEMIC_TITLE = "";
		private String USERALIAS = "";
		private String USER_TYPE = "";
		private String TEL_EXTENSION = "";
		private String FAX_NUMBER = "";
		private String USER_DEFAULT_ID = "";
		private String START_MENU = "";
		private String LOGON_LANGU;
		private String DEC_NOTATION = "";
		private int    DATE_FORMAT = 5;
		private String TIME_ZONE = "";
		private String MANAGER  = "";
		private String FUNCTION = "";
		private String MANAGER_NAME = "";
		private String EMP_TYP_DES = "";
		private String MANAGER_EDIT = "";
		private String COMMENTS = "";
		private String VALID = "";
}
