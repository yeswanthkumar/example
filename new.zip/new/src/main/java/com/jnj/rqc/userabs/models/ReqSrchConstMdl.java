package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReqSrchConstMdl {
	private int skey;
	private String sval;
	private String sdesc;
	private String isactive;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ReqSrchConstMdl other = (ReqSrchConstMdl) obj;
		if (skey != other.skey)
			return false;
		if (sval == null) {
			if (other.sval != null)
				return false;
		} else if (!sval.equals(other.sval))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + skey;
		result = prime * result + ((sval == null) ? 0 : sval.hashCode());
		return result;
	}



}