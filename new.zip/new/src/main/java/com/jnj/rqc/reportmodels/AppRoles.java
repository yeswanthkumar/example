package com.jnj.rqc.reportmodels;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class AppRoles implements Serializable{
	private static final long serialVersionUID = 1L;

	private String	ticktNo;
	private String	parntEvnt;
	private String	applnShrtNm;
	private String	applnNm;
	private String	statCd;
	private String	applnId;
	/*private int		rmvd;
	private int		appRoleView;
	private int		appRoleAdd;
	private int		appRoleChange;
	private int		appRoleDelete;
	private int		appModify;*/
	private Date	aprvdate;
	private Date	scheddate;
	private Date	impdate;




	public String getData() {
		return ticktNo + "~" +applnShrtNm + "~" + applnNm + "~" + statCd ;
	}

	public String getDataCSV() {
		return applnShrtNm + "~" + applnNm ;
	}



	@Override
	public String toString() {
		return "AppRoles [ticktNo=" + ticktNo + ", parntEvnt=" + parntEvnt + ", applnShrtNm=" + applnShrtNm
				+ ", applnNm=" + applnNm + ", statCd=" + statCd + ", applnId=" + applnId + ", aprvdate=" + aprvdate
				+ ", scheddate=" + scheddate + ", impdate=" + impdate + "]";
	}

}
