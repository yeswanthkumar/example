package com.jnj.rqc.dbconfig;

import java.sql.SQLException;
import java.time.Duration;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import com.jnj.rqc.util.Utility;

import oracle.jdbc.pool.OracleDataSource;



@Configuration
@PropertySource({ "classpath:config.properties" })
@EnableTransactionManagement
public class AppConfig {
	private static final Logger log = LoggerFactory.getLogger(AppConfig.class);
	@Autowired
	Environment environment;
	int minThreadPoolSize = 20;
	int maxThreadPoolSize = 30;
	String envName = Utility.getServerProp("ENVIRONMENT");



/*	@Bean
   public PlatformTransactionManager transactionManager() {
      JpaTransactionManager transactionManager = new JpaTransactionManager();
      transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
      return transactionManager;
   }
*/


/**
 * Method  : AppConfig.java<b>@return
 * Method  : AppConfig.java<b>@throws SQLException</b>
 * @author : DChauras  @Created :Mar 13, 2019 3:44:12 PM
 * Purpose :PROD Data source
 * @return : DataSource
 */

	@Bean
	public DataSource dataSource() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.SAdtsrc.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.SAdtsrc.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceMn() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.SAdtsrc.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.SAdtsrc.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}


	@Bean
	public DataSource dataSource0335() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.SAdtsrcdevTip.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.SAdtsrcdevTip.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url0335"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSource0459() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.SAdtsrcdev.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.SAdtsrcdev.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url0459"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}
	//SOD REFRESH DATASOURCE
	@Bean
	public DataSource dataSourceQASodRefresh() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("qa.orc.sod_ref_usr"));
	     dataSource.setPassword(environment.getRequiredProperty("qa.orc.sod_ref_pwd"));
	     dataSource.setURL(environment.getRequiredProperty("qa.orc.sod_ref_url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourcePRODSodRefresh() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("pr.orc.sod_ref_usr"));
	     dataSource.setPassword(environment.getRequiredProperty("pr.orc.sod_ref_pwd"));
	     dataSource.setURL(environment.getRequiredProperty("pr.orc.sod_ref_url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	//END SOD REFRESH
	/*Datasource for User Data from different systems - Termination Report*/

	@Bean
	public DataSource dataSourceCcra() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
		 dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     //dataSource.setPassword("#Test1234#");
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-ccra"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceCore() throws SQLException {//Request Denied
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-core"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceGps() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-gps"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceHcsop11() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-hscop11"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}


	@Bean
	public DataSource dataSourceIcs() throws SQLException {//Request Denied
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-ics"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceMdm() throws SQLException {//Table or View Does not exists -Error
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-mdm"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceWmsMlc() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 //dataSource.setUser("dchauras");
		 //dataSource.setPassword("#Diamond2022#");
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-wmsmlc"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public DataSource dataSourceWmsSdc() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.saaccount.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.saaccount.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-wmssdc"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}


	@Bean
	public DataSource dataSourceMrap0561() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYUS.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYUS.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-mrap0561"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	//GENESIS DATA SOURCE
	@Bean
	public DataSource dataSourceGenesisDev() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 if("PRODUCTION".equals(envName)) {
			 dataSource.setUser(environment.getRequiredProperty("prod.genesis.dtsrc.usrnm"));
		     dataSource.setPassword(environment.getRequiredProperty("prod.genesis.dtsrc.pwd"));
		     dataSource.setURL(environment.getRequiredProperty("prod.genesis.dtsrc.url"));
		 }else if("QUALITY".equals(envName)) {
			 dataSource.setUser(environment.getRequiredProperty("qa.genesis.dtsrc.usrnm"));
		     dataSource.setPassword(environment.getRequiredProperty("qa.genesis.dtsrc.pwd"));
		     dataSource.setURL(environment.getRequiredProperty("qa.genesis.dtsrc.url"));
		 }else {
			 dataSource.setUser(environment.getRequiredProperty("dev.genesis.dtsrc.usrnm"));
		     dataSource.setPassword(environment.getRequiredProperty("dev.genesis.dtsrc.pwd"));
		     dataSource.setURL(environment.getRequiredProperty("dev.genesis.dtsrc.url"));
		 }
		 dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}
	//END GENESIS DATASOURCE

	//UTILS DATA SOURCE
	@Bean
	public DataSource dataSourceSRADUtils() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 if("PRODUCTION".equals(envName)) {
			 dataSource.setUser(environment.getRequiredProperty("prod.dtsrc.orc.util.usr"));
		     dataSource.setPassword(environment.getRequiredProperty("prod.dtsrc.orc.util.pass"));
		     dataSource.setURL(environment.getRequiredProperty("prod.dtsrc.orc.util.dtsrc"));
		 }else if("QUALITY".equals(envName)) {
			 dataSource.setUser(environment.getRequiredProperty("qa.dtsrc.orc.util.usr"));
		     dataSource.setPassword(environment.getRequiredProperty("qa.dtsrc.orc.util.pass"));
		     dataSource.setURL(environment.getRequiredProperty("qa.dtsrc.orc.util.dtsrc"));
		 }else {
			 dataSource.setUser(environment.getRequiredProperty("dev.dtsrc.orc.util.usr"));
		     dataSource.setPassword(environment.getRequiredProperty("dev.dtsrc.orc.util.pass"));
		     dataSource.setURL(environment.getRequiredProperty("dev.dtsrc.orc.util.dtsrc"));
		 }
		 dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	 @Bean
     public PlatformTransactionManager platformTransactionManager() throws SQLException {
         return new DataSourceTransactionManager(dataSourceSRADUtils());
     }



	//END UTILS DATASOURCE


	/**
	 * Method  : AppConfig.java<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2019 3:43:57 PM
	 * Purpose :
	 * @return : ThreadPoolTaskExecutor
	 */
	@Bean
	public ThreadPoolTaskExecutor taskExecutor() {
		final ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
		try {
			minThreadPoolSize = Integer.parseInt(environment.getRequiredProperty("thread.pool.min"));
			maxThreadPoolSize = Integer.parseInt(environment.getRequiredProperty("thread.pool.max"));
		} catch (Exception e) {
			log.error("Could not get MIN/MAX values for ThreadPool Defaulting to min:"+minThreadPoolSize+" max:"+maxThreadPoolSize);
		}
		pool.setCorePoolSize(minThreadPoolSize);
		pool.setMaxPoolSize(maxThreadPoolSize);
		pool.setWaitForTasksToCompleteOnShutdown(true);
		return pool;
	}




	/*@Bean
	public DataSource dataSourceCarsIs() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.sox.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-carsis"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}
	@Bean
	public DataSource dataSourceCarsMa() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.sox.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url-carsma"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}*/

	/*@Bean
	public DataSource dataSource() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("orc.dtsrc.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("orc.dtsrc.pwd.dev"));
	     dataSource.setURL(environment.getRequiredProperty("orc.dtsrc.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}*/


	/* SAP HANA CONFIGURATION  -- BEGIN*/



	/**
	 * Method  : AppConfig.java.dataSource()
	 *		   :<b>@return
	 *		   :<b>@throws SQLException</b>
	 * @author : DChauras  @Created :Dec 23, 2020 4:41:47 PM
	 * Purpose : Hana Data Source
	 * @return : DataSource
	 */



	/* SAP HANA CONFIGURATION  -- BEGIN*/

	@Bean
	public DataSource dataSourceSANDBOX_Sandbox_Sandbox1() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("hanasb.dtsrc.usr"));
		dataSource.setPassword(environment.getRequiredProperty("hanasb.dtsrc.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("SANDBOX_Sandbox_Sandbox1"));
		dataSource.setDriverClassName(environment.getRequiredProperty("hanasb.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//BOBI

	@Bean
	public DataSource dataSourceBOBI_Development_Dfx_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_Dfx_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Development_DFY_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_DFY_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Development_DFY_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_DFY_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Development_N_1_xfx_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_N_1_xfx_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Development_N_1_xfy_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_N_1_xfy_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Development_N_1_xfy_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Development_N_1_xfy_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Production_pfx_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Production_pfx_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Production_Pfy_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Production_Pfy_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Production_Pfy_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Production_Pfy_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_QFX_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_QFX_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_QFY_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_QFY_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_QFY_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_QFY_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_N_1_yfx_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_N_1_yfx_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_N_1_yfy_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_N_1_yfy_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_QA_N_1_yfy_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_QA_N_1_yfy_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Pre_PRD_yfx_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Pre_PRD_yfx_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Pre_PRD_yfy_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Pre_PRD_yfy_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBOBI_Pre_PRD_yfy_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bobi_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bobi_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BOBI_Pre_PRD_yfy_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bobi.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//BODS PROD
	@Bean
	public DataSource dataSourceBODS_Production_PFF_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Production_PFF_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Production_PFE_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Production_PFE_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Production_PFE_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Production_PFE_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Development_DFF_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Development_DFF_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Development_DFE_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Development_DFE_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Development_DFE_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Development_DFE_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Quality_QA1_QFF_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Quality_QA1_QFF_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	@Bean
	public DataSource dataSourceBODS_Quality_QA1_QFE_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Quality_QA1_QFE_Tenant_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBODS_Quality_QA1_QFE_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bods_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bods_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("BODS_Quality_QA1_QFE_System_DB"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bods.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceCTS_Development_DFU_DFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Development_DFU_DFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceCTS_Development_DFT_DFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Development_DFT_DFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceCTS_Development_SYSTEMDB_DFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Development_SYSTEMDB_DFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}


	@Bean
	public DataSource dataSourceCTS_Production_PFU_PFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Production_PFU_PFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceCTS_Production_PFT_PFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Production_PFT_PFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceCTS_Production_SYSTEMDB_PFU() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("cts_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("cts_usr_pwd"));
		dataSource.setUrl(environment.getRequiredProperty("CTS_Production_SYSTEMDB_PFU"));
		dataSource.setDriverClassName(environment.getRequiredProperty("cts.dtsrc.drvr-cls-nm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Production_PFA_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Production_PFA_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Production_PFB_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Production_PFB_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Production_PFA_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Production_PFA_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_N_1_XFA_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_N_1_XFA_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_N_1_XFB_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_N_1_XFB_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_N_1_XFA_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_N_1_XFA_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_DFA_Teanat_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_DFA_Teanat_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_DFB_Teanant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_DFB_Teanant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_Development_DFA_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_Development_DFA_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_QA_QFA_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_QFA_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_QA_QFB_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_QFB_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	@Bean
	public DataSource dataSourceBW_QA_QFA_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_QFA_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_QA_N_1_YFA_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_N_1_YFA_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	@Bean
	public DataSource dataSourceBW_QA_N_1_YFB_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_N_1_YFB_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceBW_QA_N_1_YFA_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("bw_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("bw_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("bw.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("BW_QA_N_1_YFA_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Production_PFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Production_PFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Production_PFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Production_PFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Production_PFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Production_PFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_N_1_XFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_N_1_XFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_N_1_XFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_N_1_XFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_N_1_XFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_N_1_XFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA3_YFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA3_YFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA3_YFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA3_YFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA3_YFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA3_YFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_DFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_DFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_DFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_DFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Development_DFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Development_DFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA1_QFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA1_QFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA1_QFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA1_QFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA1_QFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA1_QFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA2_AFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA2_AFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA2_AFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA2_AFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Quality_QA2_AFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Quality_QA2_AFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_QA_UFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_QA_UFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_QA_UFI_Teanant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_QA_UFI_Teanant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_QA_UFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_QA_UFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_Production_TFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_Production_TFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_Production_TFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_Production_TFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_Pre_Production_TFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_Pre_Production_TFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_QA_N_1_RFH_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_QA_N_1_RFH_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_QA_N_1_RFI_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_QA_N_1_RFI_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceS4_QA_N_1_RFH_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("s4_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("s4_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("s4.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("S4_QA_N_1_RFH_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Development_DFM_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_DFM_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Development_DFQ_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_DFQ_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Development_DFM_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_DFM_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA1_QFM_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA1_QFM_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA1_QFQ_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA1_QFQ_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA1_QFM_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA1_QFM_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA2_QFN_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA2_QFN_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA2_QFR_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA2_QFR_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA2_QFN_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA2_QFN_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}


	@Bean
	public DataSource dataSourceSLT_Quality_QA3_QFS_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA3_QFS_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA3_QFO_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA3_QFO_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Quality_QA3_QFO_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Quality_QA3_QFO_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Production_PFM_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Production_PFM_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Production_PFQ_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Production_PFQ_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Production_PFM_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Production_PFM_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}


	@Bean
	public DataSource dataSourceSLT_Development_N_1_DFN_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_N_1_DFN_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Development_N_1_DFR_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_N_1_DFR_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Development_N_1_DFN_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Development_N_1_DFN_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}


	@Bean
	public DataSource dataSourceSLT_Pre_QA_UFQ_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_QA_UFQ_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Pre_QA_UFM_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_QA_UFM_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Pre_QA_UFM_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_QA_UFM_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Pre_Production_TFM_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_Production_TFM_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Pre_Production_TFQ_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_Production_TFQ_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_Pre_Production_TFM_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_Pre_Production_TFM_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_QA_N_1_YFN_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_QA_N_1_YFN_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_QA_N_1_YFR_Tenant_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_QA_N_1_YFR_Tenant_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	@Bean
	public DataSource dataSourceSLT_QA_N_1_YFN_System_DB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("slt_usr_nm"));
		dataSource.setPassword(environment.getRequiredProperty("slt_usr_pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("slt.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("SLT_QA_N_1_YFN_System_DB"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_BOBJ_Production_BTBBOBJBPG
	@Bean
	public DataSource dataSourceNA_BOBJ_Production_BTBBOBJBPG() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_BOBJ_Production_BTBBOBJBPG.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_BOBJ_Production_BTBBOBJBPG.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_BOBJ_Production_BTBBOBJBPG.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_BOBJ_Production_BTBBOBJBPG.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_BTBHANAHPG
	@Bean
	public DataSource dataSourceNA_HANA_Production_BTBHANAHPG() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_BTBHANAHPG.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_BTBHANAHPG.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_BTBHANAHPG.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_BTBHANAHPG.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONEmptyTenantDBPEA
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEA() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEA.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEA.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEA.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEA.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONTenantDBPB1
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONTenantDBPB1() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPB1.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPB1.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPB1.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPB1.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONSYSTEMDBPEA
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEA() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEA.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEA.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEA.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEA.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONEmptyTenantDBPEB
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONEmptyTenantDBPEB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEB.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEB.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEB.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONEmptyTenantDBPEB.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONTenantDBPEC
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONTenantDBPEC() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPEC.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPEC.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPEC.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONTenantDBPEC.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//NA_HANA_Production_FUSIONSYSTEMDBPEB
	@Bean
	public DataSource dataSourceNA_HANA_Production_FUSIONSYSTEMDBPEB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEB.usr"));
		dataSource.setPassword(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEB.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEB.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("NA_HANA_Production_FUSIONSYSTEMDBPEB.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_GALAXYHANA
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_GALAXYHANA() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANA.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANA.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANA.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANA.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_GALAXYHANASystemDB
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_GALAXYHANASystemDB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANASystemDB.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANASystemDB.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANASystemDB.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANASystemDB.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	//EMEA_HANA_Production_GALAXYHANAHPM
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_GALAXYHANAHPM() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANAHPM.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANAHPM.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANAHPM.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANAHPM.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_GALAXYHANABPM
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_GALAXYHANABPM() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANABPM.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANABPM.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANABPM.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_GALAXYHANABPM.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_STFHANA
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_STFHANA() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_STFHANA.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_STFHANA.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_STFHANA.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_STFHANA.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_STFHANASystemDB
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_STFHANASystemDB() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_STFHANASystemDB.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_STFHANASystemDB.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_STFHANASystemDB.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_STFHANASystemDB.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_STFHANAHPC
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_STFHANAHPC() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_STFHANAHPC.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_STFHANAHPC.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_STFHANAHPC.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_STFHANAHPC.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	//EMEA_HANA_Production_STFHANABPC
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_STFHANABPC() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_STFHANABPC.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_STFHANABPC.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_STFHANABPC.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_STFHANABPC.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_EMEAHANASYNTHES
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_EMEAHANASYNTHES() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//EMEA_HANA_Production_EMEAHANASYNTHES1
	@Bean
	public DataSource dataSourceEMEA_HANA_Production_EMEAHANASYNTHES1() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES1.usr"));
		dataSource.setPassword(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES1.pwd"));
		dataSource.setUrl(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES1.url"));
		dataSource.setDriverClassName(environment.getRequiredProperty("EMEA_HANA_Production_EMEAHANASYNTHES1.drvrclsnm"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//END HANA


	//JDA DEV Connection
	@Bean
	public DataSource dataSourceJDADevelopment() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("jda.dev.dtsrc.usrnm"));
		dataSource.setPassword(environment.getRequiredProperty("jda.dev.dtsrc.pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("jda.dev.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("jda.dev.dtsrc.url"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}
	//JDA QA Connection
	@Bean
	public DataSource dataSourceJDAQuality() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("jda.qa.dtsrc.usrnm"));
		dataSource.setPassword(environment.getRequiredProperty("jda.qa.dtsrc.pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("jda.qa.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("jda.qa.dtsrc.url"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}


	//JDA PREQA Connection
	@Bean
	public DataSource dataSourceJDAPreQuality() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("jda.preqa.dtsrc.usrnm"));
		dataSource.setPassword(environment.getRequiredProperty("jda.preqa.dtsrc.pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("jda.preqa.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("jda.preqa.dtsrc.url"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//JDA PROD Connection
	@Bean
	public DataSource dataSourceJDAProduction() throws SQLException {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(environment.getRequiredProperty("jda.prod.dtsrc.usrnm"));
		dataSource.setPassword(environment.getRequiredProperty("jda.prod.dtsrc.pwd"));
		dataSource.setDriverClassName(environment.getRequiredProperty("jda.prod.dtsrc.drvr-cls-nm"));
		dataSource.setUrl(environment.getRequiredProperty("jda.prod.dtsrc.url"));
		dataSource.setCacheState(true);
		dataSource.setFastFailValidation(true);
		return dataSource;
	}

	//JDE Data Sources

	// 1. NA_JDEPLATFORM_Production_JDEANIMAS
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEANIMAS() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEANIMAS.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEANIMAS.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEANIMAS.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 2. NA_JDEPLATFORM_Production_JDEBWI
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEBWI() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEBWI.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEBWI.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEBWI.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 3. NA_JDEPLATFORM_Production_JDEDCF92
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEDCF92() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDCF92.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDCF92.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDCF92.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 4. NA_JDEPLATFORM_Production_JDEDEPUYEMEA
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEDEPUYEMEA() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYEMEA.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYEMEA.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYEMEA.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 5. NA_JDEPLATFORM_Production_JDEDEPUYUS
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEDEPUYUS() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYUS.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYUS.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEDEPUYUS.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 6. NA_JDEPLATFORM_Production_JDEEES
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEEES() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEEES.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEEES.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEEES.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 7. NA_JDEPLATFORM_Production_JDEETHICON
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEETHICON() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEETHICON.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEETHICON.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEETHICON.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	// 8. NA_JDEPLATFORM_Production_JDEGMED
	@Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEGMED() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEGMED.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEGMED.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEGMED.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	/*
	 //9. NA_JDEPLATFORM_Production_JDEMENTOR - NO TNS
	 @Bean
	public DataSource dataSourceNA_JDEPLATFORM_Production_JDEMENTOR() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEMENTOR.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEMENTOR.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_JDEPLATFORM_Production_JDEMENTOR.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}
	 */
	//BRAVO DATASOURCE SONFIGURATION

	//1. NA_BRAVO_Development_BRAVO
	@Bean
	public DataSource dataSourceNA_BRAVO_Development_BRAVO() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_BRAVO_Development_BRAVO.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_BRAVO_Development_BRAVO.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_BRAVO_Development_BRAVO.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	//2. NA_BRAVO_Quality_BRAVO
	@Bean
	public DataSource dataSourceNA_BRAVO_Quality_BRAVO() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_BRAVO_Quality_BRAVO.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_BRAVO_Quality_BRAVO.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_BRAVO_Quality_BRAVO.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	//3. NA_BRAVO_Production_BRAVO
	@Bean
	public DataSource dataSourceNA_BRAVO_Production_BRAVO() throws SQLException {
		 OracleDataSource dataSource = new OracleDataSource();
		 dataSource.setUser(environment.getRequiredProperty("NA_BRAVO_Production_BRAVO.usrnm"));
	     dataSource.setPassword(environment.getRequiredProperty("NA_BRAVO_Production_BRAVO.pwd"));
	     dataSource.setURL(environment.getRequiredProperty("NA_BRAVO_Production_BRAVO.url"));
	     dataSource.setDriverType("oracle.jdbc.driver.OracleDriver");
	     dataSource.setImplicitCachingEnabled(true);
	     dataSource.setFastConnectionFailoverEnabled(true);
	     return dataSource;
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.setConnectTimeout(Duration.ofMillis(10000))
	            .setReadTimeout(Duration.ofMillis(10000))//5000-increased to 10 seconds, change it back to 3-5 seconds
	            .setConnectTimeout(Duration.ofMillis(10000))//5000
	            .build();
	}

	@Bean
	public RestTemplate restHttpTemplate() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		//factory.setConnectTimeout(10000);//5000 -increased to 10 seconds, change it back to 3-5 seconds
		//factory.setReadTimeout(10000);//5000
		factory.setConnectTimeout(60000);//5000 -increased to 10 seconds, change it back to 3-5 seconds
		factory.setReadTimeout(60000);//60000
		return new RestTemplate(factory);
	}

	/*

	   RestTemplate restTemplate = new RestTemplate();
		HttpEntity<Foo> request = new HttpEntity<>(new Foo("bar"));
		ResponseEntity<Foo> response = restTemplate.exchange(fooResourceUrl, HttpMethod.POST, request, Foo.class);

	   ResponseEntity<List<POJO>> responseEntity = restTemplate.exchange(
	    URL,
	    HttpMethod.GET,
	    null,
	    new ParameterizedTypeReference<List<POJO>>() {
	    });
	List<POJO> pojoObjList = responseEntity.getBody();

	@RequestMapping(value = "/post")
    public String getPostResponse(){
        HttpHeaders headers=new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity=new HttpEntity<String>(headers);
        return restTemplate.exchange("http://localhost:8080/postdata",HttpMethod.POST,entity,String.class).getBody();
    }

	///WEBCLIENT
	@Bean
	public WebClient.Builder getWebClientBuilder(){
	    return WebClient.builder();
	}

	@Autowired


	private WebClient.Builder webClientBuilder;
	Product product = webClientBuilder.build()
            .get()
            .uri("http://localhost:8080/api/products")
            .retrieve()
            .bodyToMono(Product.class)
            .block();

	---------------------
	@GetMapping(value = "/download/file/pdf/", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<Resource> downloadFilePdf() throws IOException {
        String url = "http://www.orimi.com/pdf-test.pdf";

        RestTemplate restTemplate = new RestTemplate();
        byte[] byteContent = restTemplate.getForObject(url, String.class).getBytes(StandardCharsets.ISO_8859_1);
        InputStream resourceInputStream = new ByteArrayInputStream(byteContent);

        return ResponseEntity.ok()
                .header("Content-disposition", "attachment; filename=" + "pdf-with-my-API_pdf-test.pdf")
                .contentType(MediaType.parseMediaType("application/pdf;"))
                .contentLength(byteContent.length)
                .body(new InputStreamResource(resourceInputStream));
    }





	*/


}

