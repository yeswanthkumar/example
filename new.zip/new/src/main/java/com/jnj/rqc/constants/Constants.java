package com.jnj.rqc.constants;

public interface Constants {
	public static String ADM_IDS 		= "ADM_IDS";
	public static String TOEMAIL_DIST_LIST_PERIODIC_REPORTS	= "TOEMAIL_DIST_LIST_PERIODIC_REPORTS";
	public static String CCEMAIL_DIST_LIST_PERIODIC_REPORTS	= "CCEMAIL_DIST_LIST_PERIODIC_REPORTS";
	public static String  HCS_MANUAL_SYSTEM = "HCS_MANUAL_SYSTEM";

	//START IAM- LOGIN & SECURITY
	//String str ="{\"AuthString\":  \"Module=RoleBasedManualADS;User=JNJ\\\\SA-HCS-SOD_DB_USER; Password=System#321\"}";
	/*START - IAM PRODUCTION CONFIGURATION*/
	public static String IAM_MODULE 		= "Module=RoleBasedManualADS;";
	public static String IAM_USER			= "User=JNJ\\SA-HCS-SOD_DB_USER;";
	public static String IAM_PWD			= "Password=System#321";
	public static String authURLIAM			= "https://1imapi.jnj.com/D1IMAppServer/auth/apphost";
	public static String cccWebReqUrlIAM 	= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesREQUEST";
	public static String cccGrpUrlIAM 		= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesGROUP";
	public static String cccPrsnUrlIAM		= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesPERSON";
	public static String cccServerUrlIAM 	= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesSERVER";
	public static String logoutUrlIAM		= "https://1imapi.jnj.com/D1IMAppServer/auth/logout";
	/*END - IAM PRODUCTION CONFIGURATION*/

	/*START - IAM STAGING CONFIGURATION*/
	//"AuthString":  "Module=RoleBasedPerson;User=SA-ITS-QASA-HCS-SODD;Password=System#321"
	/*public static String IAM_MODULE 		= "Module=RoleBasedPerson;";
	public static String IAM_USER			= "User=SA-ITS-QASA-HCS-SODD;";//SJNJ\SA-ITS-QASA-HCS-SODD
	public static String IAM_PWD			= "Password=System#321";
	public static String authURLIAM			= "https://ITSUSRAWSP10696.jnj.com/D1IMAppServer/auth/apphost";
	public static String cccWebReqUrlIAM 	= "https://ITSUSRAWSP10696.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesREQUEST";
	public static String cccGrpUrlIAM 		= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesGROUP";
	public static String cccPrsnUrlIAM		= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesPERSON";
	public static String cccServerUrlIAM 	= "https://1imapi.jnj.com/D1IMAppServer/api/entity/CCC_WebservicesSERVER";
	public static String logoutUrlIAM		= "https://1imapi.jnj.com/D1IMAppServer/auth/logout";*/
	/*END - IAM STAGING CONFIGURATION*/

	//GRC Variables
	public static String GRC_API_AUTH = "GRC_API_AUTH";
	public static String GRC_API_URL  = "GRC_API_URL";


	public static String IAM_ACTIVITY_FLG  	=  "TRIGGER_IAM_REQUEST";
	public static String EDALIAM_ACTIVITY_FLG = "TRIGGER_EDALIAM_REQUEST";
	public static String EDAL_FETCH_ALL_ROLES = "EDAL_FETCH_ALL_ROLES";
	public static String GRP_MEMBERSHIP  	=  "Membership";
	public static String TYPE_ADD  			=  "ADD";
	public static String TYPE_REMOVE 		=  "REMOVE";
	public static int 	 SYS_EXCSV_LIMIT	= 70;
	public static String SYS_EXCSV_REST_LIMIT	= "SYS_EXCSV_LIMIT";

	//CSM Data
	public static String CSM_FLAG  	= "PROCESS_CSM_DATA";
	public static String CSM_UNAM 	= "Dchauras@its.jnj.com";
	public static String CSM_UPWD 	= "Shlok3012#";

	//USER REQUEST
	public static final int REQ_SAVED_MGR_ROUTING	= 1;
	public static final int REQ_COMPL_ROUTING		= 2;
	public static final int REQ_BUSS_ROUTING		= 3;
	public static final int ROUTED_IAM_GRC			= 4;
	public static final int PROVISIONING_WIP		= 5;
	public static String  	ST_COMPLTED  			=  "C";
	public static String  	ST_PENDING  			=  "P";
	public static String  	ST_ERROR  				=  "E";
	public static String  	ST_REJECTED  			=  "R";
	public static String  	ST_CANCELLED  			=  "X";
	public static String  	ST_PARTIALAP  			=  "L";


	public static String USER_VALIDATED 		= "USER_VALIDATED";
	public static String USER_AUTH_ERROR 		= "Authentication failure : User details not found or Invalid User ID/Password entered.";
	public static String USER_GROUPS			= "USER_GROUPS";
	public static String AUTH_USER				= "AUTH_USER";
	public static String ASSOC_EXISTING_ROLES	= "ASSOC_EXISTING_ROLES";
	public static String SAP_ADGRP_BW4PFB		= "BW4PFB";
	public static String SAP_ADGRP_S4PFI		= "S4PFI";
	public static String SAP_GRC_SYSTEM			= "GRCSYS";
	public static String SAP_CSM_SYSTEM			= "CSM_ANAPLAN";

	public static String ALL_TRF_SCH			= "ALL_TRF_SCH";
	public static String ENABLE_TRF_EXPORT		= "ENABLE_TRF_EXPORT";

	public static String COMPLETED_SCH			= "COMPLETED_SCH";
	public static String WIP_SCH				= "WIP_SCH";
	public static String ALL_U2CR_SCH			= "ALL_U2CR_SCH";
	public static String ENABLE_U2CR_EXPORT		= "ENABLE_U2CR_EXPORT";
	public static String ALL_U2SOD_SCH			= "ALL_U2SOD_SCH";
	public static String ENABLE_U2SOD_EXPORT	= "ENABLE_U2SOD_EXPORT";
	//END - LOGIN & SECURITY

	public static String UPLOAD_DIR 			= "/tmp/rqcutilupload/"; //Uload Directory location
	public static final String PVCS_OUT_LOC 	= "/tmp/rqcutilsextract/";//Location to store the output/extract file
	public static final String REPO_OUT_LOC 	= "/tmp/rqcutilsextract/";//Location to store the output/extract file
	public static final String RULESET_OUT_LOC 	= "/tmp/ruleset/";//Location to store the output/extract RuleSetfile
	public static final String TERM_OUT_LOC 	= "/tmp/termination/";//Location to store the output/extract RuleSetfile
	public static final String RQC_TKT_DATA 	= "RQC_TKT_DATA";

	public static final int SUCCESS 			= 0;
	public static final int ERROR 				= 1;//Missing Parameters
	public static final int SERV_ERR 			= 500;//Service Exception

	public static final String REQUEST_STATUS	= "REQUEST_STATUS";
	public static final String ROLE_CONFLICT_MSG1= 	"The attached document(s) provides a listing of User Role &/Or Conflict Details across all HCS systems as of (CURRENTDATE).\n\n"+
													"Kindly download and save a copy for future reference.\n\n";

	public static final String ROLE_CONFLICT_MSG2=	"If you have any questions, please do not hesitate to ask! \n\n\r\n\r\n"+
													"Regards, \n\n"+
													"CS&M Requests Team\n\n";
	//User Level Variables
	public static final String ACTIVE_USER 		= "ACTIVE_USER";
	public static final String  EML_SUBJECT 	= "User Role and Conflict Details Review for - ";

	public static final String TRF_REPORT_SO_SYSTEMS = "TRF_REPORT_SO_SYSTEMS";
	public static final String U2R_REPORT_SO_SYSTEMS = "U2R_REPORT_SO_SYSTEMS";
	public static final String U2S_REPORT_SO_SYSTEMS = "U2S_REPORT_SO_SYSTEMS";

	//CSI Properties
	public static final int 	CSI_PAGE_LIMIT			= 3000;
	public static final String 	CSI_SOD_RISK_TABLE 		= "SOD_RISK_TABLE.xlsx";
	public static final String 	CSI_CRITICAL_RISK_ACT_TABLE = "Critical_Action_Risk_Table.xlsx";
	public static final String 	CSI_FUNCTION_ACT_TABLE 	= "Function_Action.xlsx";
	public static final String 	CSI_FUNCTION_PERMISSIONS_TABLE = "Function_Permission.xlsx";
	public static final String  CSI_USER2SOD 			= "SoD conflict,Description,Norm,New norm,Reason Code,Reason code (Norm),Control ID,Control measure,Definition,Expression,Variant,User id,User description,Super?,Group,Type,Status,User status,Logical System,Query,Query name,Query description,Norm,Norm Id,Authorization,T-code,Executed,CausingT-Codes,Query T-Codes,Query,Query name,Query description,Norm,Norm Id,Authorization,T-code,Executed,Causing T-Code,Query  T-Codes";
	public static final String  CSI_ROLE2SOD 			= "SoD conflict,Description,Norm Id,New Norm Id,Reason Code,Norm Reason Code,Definition,Expression,Variant,Role,Role description,C,Super?,Logical System,Query,Query name,Query description,Norm,Norm Id,Authorization,T-code,Executed,Query,Query name,Query description,Norm,Norm Id,Authorization,T-code,Executed";
	public static final String  CSI_SODRISK 			= "Application Scope,Source,Domain,Business Process,Risk ID,Function ID 1,Function 1 Description (and source),Function ID 2,Function 2 Description (and source),Function ID 3,Function 3 Description (and source),Short Description of Risk,Long Description of risk,Risk Level,Regulation,Status,Change Comment";
	public static final String  CSI_CRI_ACT_RISK 		= "Disposition,Business Process,Risk ID,Function ID 1,Function 1 Description,Short Description of Risk,Long Description of risk,Risk Level,Change Comment,Status (Enabled/ Disabled)";
	public static final String  CSI_FUNC_ACT_DATA 		= "Disposition,Application Scope,Function ID,Function Description,T-Code,T-Code Description,Status (Enabled/ Disabled),Source,Change Comment";
	public static final String  CSI_FUNC_PERM_DATA 		= "Disposition,Application Scope,Function ID,Function Description,T-Code,T-Code Description,Authorization Object,Authorization Object Description,Field,Field Description,From  Value,To Value,Logical Operator,Status (Enabled/ Disabled),Source,Change Comment";

	//HANA
	public static final String  HANA_DB_RISK			= "HANA_DB_RISK";
	public static final String  HANA_USER2SOD 			= "User Id,Access Risk ID,Risk Description,Role1,Role2,Function A,Function Desc,Function B,Function Desc,Risk Level,Regulation,Target Connector,Mitigating Control,Compliance Manager,Ruleset GPO";
	public static final String  HANA_ROLE2SOD 			= "Role 1, Role 2,Access Risk ID,Risk Description,Function A,Function Desc,Function B,Function Desc,Risk Level,Regulation,Target Connector,Mitigating Control,Compliance Manager,Ruleset GPO";
	public static final String  HANA_CONF_MATRIX 		= "Access Risk ID,Risk Description,Function A,Function Desc,Function B,Function Desc,Risk Level,Regulation,Target Connector,Mitigating Control,Compliance Manager,Ruleset GPO";
	//JDA
	public static final String  JDA_USER_ROLES_HEADER 			= "WWID,USER ID,FIRST NAME,LAST NAME,SOD CODE,ACCESS ROLE,STATUS,SRC SYSTEM,ACTION_MENU";
	public static final String  JDA_INTRA_CONFLICT_HEADER		= "WWID,RISK ID,RISK DESC,ROLE ID,ROLE NAME,FUNC ID,FUNC DESC,RISK LEVEL,REGULATION,TRGT CONN,MITIGATING CONTROL,COMPL MGR,RULESET BUSINESS OWNER";
	public static final String  JDA_INTRA_CONFMATRIX_HEADER		= "RISK ID,RISK DESC,ROLE ID,ROLE NAME,FUNC ID,FUNC DESC,RISK LEVEL,REGULATION,TRGT CONN,MITIGATING CONTROL,COMPL MGR,RULESET BUSINESS OWNER";
	public static final String  JDA_CROSSAPP_CONFLICT_HEADER	= "WWID,APP1,APP2,ROLE1,ROLE2,CONFLICT,MITIGATING CONTROL";

	public static final String  JDA_DB_RISK					= "JDA_DB_RISK";
	public static final String  JDA_CROSSAPP_MATRIX			= "JDA_CROSSAPP_MATRIX";
	public static final String  JDA_ROLES_TECHNM			= "JDA_ROLES_TECHNM";
	public static final String  JDA_TECH_USRFR_NAMES		= "JDA_TECH_USRFR_NAMES";
	public static final String  JDE_DSIBWI_USER_FILEPATH	="\\\\N1W0000090\\SecurityInformation\\dsiUsers.txt";
	public static final String  JDE_DSIBWI_USERROLE_FILEPATH="\\\\N1W0000090\\SecurityInformation\\dsiUserRoles.txt";

	//SAP GAA
	public static final String  SAP_GAA_USER2ROLE 			= "REVIEWER_USER_ID,USER_ID,PRIMARY_REVIEW_INFO1,PRIMARY_REVIEW_INFO2,PRIMARY_REVIEW_INFO3,ADDITIONAL_INFO1,ADDITIONAL_INFO2,ADDITIONAL_INFO3,STATUS";
	public static final String  SAP_GAA_TRFCNTRL 			= "SAP_PLATFORM,SYSTEM_CLIENT,DESCRIPTION,DETAILS,USER_SAPID/NTID,USER_WWID";
	public static final int		GEN_BATCH_SIZE				= 400;
	public static final String  GEN_SO_TRFREPORT 			= "REVIEW_NAME,SAP_PLATFROM,SAP_SYSTEM,GROUP_DESCRIPTION,ACCOUNT_NAME,ACCOUNT_OWNER,ACCOUNT_OWNER_WWID,ACCOUNT_OWNER_TITLE,DESIGNATED_REVIEWER,DESIGNATED_REVIEWER_WWID,REVIEWED_BY_NAME,REVIEWED_BY_WWID,CREATION_DATE,DATE_REVIEWED,REVIEW_STATUS,DATE_ENTERED";
	public static final String  GEN_SO_U2RREPORT 			= "REVIEW_NAME,GROUP_DESCRIPTION,GROUP_SHORT_NAME,GROUP_OTHER_2,GROUP_OTHER_3,ACCOUNT_NAME,ACCOUNT_OWNER_NAME,ACCOUNT_OWNER_TITLE,ACCOUNT_OWNER_USER_ID,ACCOUNT_OWNER_USER_NAME,ACCOUNT_OWNER_EMAIL,ACCOUNT_OWNER_MRC,ACCOUNT_OWNER_DEPARTMENT,GROUP_TYPE,DESIGNATED_REVIEWER,DESIGNATED_REVIEWER_WWID,REVIEWED_BY_NAME,REVIEWED_BY_WWID,REVIEW_STATUS,REVIEWER_COMMENTS,DATE_ENTERED";
	public static final String  GEN_DELTA_U2RREPORT 		= "REVIEWER_USER_ID,USER_ID,PRIMARY_REVIEW_INFO1,PRIMARY_REVIEW_INFO2,PRIMARY_REVIEW_INFO3,ADDITIONAL_INFO1,ADDITIONAL_INFO2,ADDITIONAL_INFO3,DATE_ENTERED,REPORT_DATE,USER_STATUS";
	public static final String 	TRF_CNTRL_TRANSDATA			= "REGION,PLATFORM,ENVIRONMENT,SYSTEM,DESCRIPTION,DETAILS,USER_NT_ID,WWID,CREATED_DT,CREATED_BY";
	public static final String 	USER2ROLE_TRANSDATA			= "REGION,PLATFORM,ENVIRONMENT,SYSTEM,USER_ID,FIRST_NAME,LAST_NAME,ROLE_ID,ROLE_DESC,PRIMARY_REVIEW_INFO1,PRIMARY_REVIEW_INFO2,PRIMARY_REVIEW_INFO3,ADDITIONAL_INFO1,ADDITIONAL_INFO2,ADDITIONAL_INFO3,USER_STATUS,CREATED_DT,CREATED_BY";
	//USER 2 SOD
	public static final String  SAP_USER2SOD_HDR 			= "REVIEWER USER ID,USER_ID,PRIMARY_REVIEW_INFO1,ADDITIONAL_INFO1,ADDITIONAL_INFO2,MITIGATING ID,ADDITIONAL_INFO3,PLATFORM NAME,RISK ID and RISK DESCRIPTION,REVIEWER ACKNOWLEDGEMENT / DESCRIPTION, USER STATUS";
	public static final String  SAP_USER2SOD_TRNSHDR 		= "REGION,PLATFORM,ENVIRONMENT,SYSTEM,REVIEWER USER ID,USER_ID,PRIMARY_REVIEW_INFO1,ADDITIONAL_INFO1,ADDITIONAL_INFO2,MITIGATING ID,ADDITIONAL_INFO3,PLATFORM NAME,RISK ID and RISK DESCRIPTION,REVIEWER ACKNOWLEDGEMENT / DESCRIPTION";
	public static final String  GEN_SO_U2SREPORT 			= "REVIEW_NAME,GROUP_PLATFORM,GROUP_DESCRIPTION,GROUP_SHORT_NAME,GROUP_OTHER_1,GROUP_OTHER_2,GROUP_OTHER_3,ACCOUNT_NAME,ACCOUNT_OWNER_NAME,ACCOUNT_OWNER_TITLE,ACCOUNT_OWNER_USER_NAME,ACCOUNT_OWNER_EMAIL,ACCOUNT_OWNER_DEPARTMENT,DESIGNATED_REVIEWER,DESIGNATED_REVIEWER_WWID,REVIEWED_BY_NAME,REVIEWED_BY_WWID,DATE_GENERATED,DATE_REVIEWED,REVIEW_STATUS,REVIEWER_COMMENTS,DATE_ENTERED";
	public static final String  U2R_REPORT 					= "ERP USER TO ROLE REPORT";

	//LOCAL PROPERTIES
	/*
	public static final String  CSI_BASE_LOC_USR2SOD		= "D:/Users/YKurella/CSI/USR2SOD";
	public static final String  CSI_BASE_LOC_ROLE2SOD		= "D:/Users/YKurella/CSI/ROLE2SOD";
	public static final String  CSI_BASE_LOC_MATRIX			= "D:/Users/YKurella/CSI/CONFLICT_MATRIX";
	public static final String 	HANA_DBRISK_FILEPATH 		= "D:/Users/YKurella/CSI/HANA/CONFLICT_MATRIX/HNDB_Risks.xlsx";
	public static final String 	JDA_DBRISK_FILEPATH 		= "D:/Users/YKurella/CSI/JDA/CONFLICT_MATRIX/JDA_DB_Risks.xlsx";
	public static final String 	JDA_CROSSAPP_MATRIX_FILEPATH= "D:/Users/YKurella/CSI/JDA/CONFLICT_MATRIX/JDA Cross-App Role and Conflict Matrix.xlsx";
	public static final String 	JDA_TECH_ROLEMAP_FILEPATH	= "D:/Users/YKurella/CSI/JDA/CONFLICT_MATRIX/JDA Role Mapping.xlsx";
	public static final String 	csiFilePath 				= "D:/Users/YKurella/CSI_FOLDER_STRUCTURE.PROPERTIES";
	public static final String 	dbFilePath 					= "D:/Users/YKurella/DB.PROPERTIES";
	public static final String  hanaFilePath 				= "D:/Users/YKurella/HANA_FOLDER_STRUCTURE.PROPERTIES";
	public static final String 	sapGaaFilePath 				= "D:/Users/YKurella/SAPGAA_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickFilePath 		= "D:/Users/YKurella/SAP1CLICK_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickU2RFilePath 		= "D:/Users/YKurella/SAP1CLICK_USER2ROLE_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	jdeFilePath 				= "D:/Users/YKurella/JDE_STRUCTURE.PROPERTIES";
	public static final String 	leadDistEmailPath			= "D:/Users/YKurella/LEAD_DIST_EMAIL.PROPERTIES";
	public static final String 	userFilePath 				= "D:/Users/YKurella/USER_DATA.PROPERTIES"; //User Identity
	public static final String 	hcsFilePath 				= "D:/Users/YKurella/HCS_STRUCTURE.PROPERTIES";
	public static final String 	user2SodFilePath 			= "D:/Users/YKurella/USER2SOD_STRUCTURE.PROPERTIES";
	public static final String 	sharePointPFXFile 			= "D:/Users/YKurella/SharePointAPICert.pfx";
	*/
	
	// QA - OPCITSNAW01RB
	
	public static final String  CSI_BASE_LOC_USR2SOD			= "D:/HCSSecurityTool/properties/CSI/USR2SOD";
	public static final String  CSI_BASE_LOC_ROLE2SOD			= "D:/HCSSecurityTool/properties/CSI/ROLE2SOD";
	public static final String  CSI_BASE_LOC_MATRIX				= "D:/HCSSecurityTool/properties/CSI/CONFLICT_MATRIX";
	public static final String 	HANA_DBRISK_FILEPATH 			= "D:/HCSSecurityTool/properties/HANA/CONFLICT_MATRIX/HNDB_Risks.xlsx";
	public static final String 	JDA_DBRISK_FILEPATH 			= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA_DB_Risks.xlsx";
	public static final String 	JDA_CROSSAPP_MATRIX_FILEPATH	= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA Cross-App Role and Conflict Matrix.xlsx";
	public static final String 	JDA_TECH_ROLEMAP_FILEPATH		= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA Role Mapping.xlsx";
	public static final String 	csiFilePath 					= "D:/HCSSecurityTool/properties/CSI_FOLDER_STRUCTURE.PROPERTIES"; //Server CSI Properties
	public static final String 	dbFilePath 						= "D:/HCSSecurityTool/properties/DB.PROPERTIES"; //Server DB Properties
	public static final String  hanaFilePath 					= "D:/HCSSecurityTool/properties/HANA_FOLDER_STRUCTURE.PROPERTIES";
	public static final String 	sapGaaFilePath 					= "D:/HCSSecurityTool/properties/SAPGAA_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickFilePath 			= "D:/HCSSecurityTool/properties/SAP1CLICK_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickU2RFilePath 			= "D:/HCSSecurityTool/properties/SAP1CLICK_USER2ROLE_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	jdeFilePath 					= "D:/HCSSecurityTool/properties/JDE_STRUCTURE.PROPERTIES";
	public static final String 	leadDistEmailPath				= "D:/HCSSecurityTool/properties/LEAD_DIST_EMAIL.PROPERTIES";
	public static final String 	userFilePath 					= "D:/HCSSecurityTool/properties/USER_DATA.PROPERTIES"; //User Identity
	public static final String 	hcsFilePath 					= "D:/HCSSecurityTool/properties/HCS_STRUCTURE.PROPERTIES";//HCS
	public static final String 	user2SodFilePath 				= "D:/HCSSecurityTool/properties/USER2SOD_STRUCTURE.PROPERTIES";
	public static final String 	sharePointPFXFile 			    = "D:/HCSSecurityTool/properties/SharePointAPICert.pfx";
	
	
	//SERVER PROPERTIES -
	//DEV - OPCITSNAW0090
	/*
	public static final String  CSI_BASE_LOC_USR2SOD			= "D:/HCSSecurityTool/properties/CSI/USR2SOD";
	public static final String  CSI_BASE_LOC_ROLE2SOD			= "D:/HCSSecurityTool/properties/CSI/ROLE2SOD";
	public static final String  CSI_BASE_LOC_MATRIX				= "D:/HCSSecurityTool/properties/CSI/CONFLICT_MATRIX";
	public static final String 	HANA_DBRISK_FILEPATH 			= "D:/HCSSecurityTool/properties/HANA/CONFLICT_MATRIX/HNDB_Risks.xlsx";
	public static final String 	JDA_DBRISK_FILEPATH 			= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA_DB_Risks.xlsx";
	public static final String 	JDA_CROSSAPP_MATRIX_FILEPATH	= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA Cross-App Role and Conflict Matrix.xlsx";
	public static final String 	JDA_TECH_ROLEMAP_FILEPATH		= "D:/HCSSecurityTool/properties/JDA/CONFLICT_MATRIX/JDA Role Mapping.xlsx";
	public static final String 	csiFilePath 					= "D:/HCSSecurityTool/properties/CSI_FOLDER_STRUCTURE.PROPERTIES"; //Server CSI Properties
	public static final String 	dbFilePath 						= "D:/HCSSecurityTool/properties/DB.PROPERTIES"; //Server DB Properties
	public static final String  hanaFilePath 					= "D:/HCSSecurityTool/properties/HANA_FOLDER_STRUCTURE.PROPERTIES";
	public static final String 	sapGaaFilePath 					= "D:/HCSSecurityTool/properties/SAPGAA_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickFilePath 			= "D:/HCSSecurityTool/properties/SAP1CLICK_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickU2RFilePath 			= "D:/HCSSecurityTool/properties/SAP1CLICK_USER2ROLE_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	jdeFilePath 					= "D:/HCSSecurityTool/properties/JDE_STRUCTURE.PROPERTIES";
	public static final String 	leadDistEmailPath				= "D:/HCSSecurityTool/properties/LEAD_DIST_EMAIL.PROPERTIES";
	public static final String 	userFilePath 					= "D:/HCSSecurityTool/properties/USER_DATA.PROPERTIES"; //User Identity
	public static final String 	hcsFilePath 					= "D:/HCSSecurityTool/properties/HCS_STRUCTURE.PROPERTIES";//HCS
	public static final String 	user2SodFilePath 				= "D:/HCSSecurityTool/properties/USER2SOD_STRUCTURE.PROPERTIES";
	public static final String 	sharePointPFXFile 			    = "D:/HCSSecurityTool/properties/SharePointAPICert.pfx";*/



	//CSI MACHINE  PROPERTIES
	/*
	public static final String  CSI_BASE_LOC_USR2SOD	= "C:/OneMD/CSI/USR2SOD";
	public static final String  CSI_BASE_LOC_ROLE2SOD	= "C:/OneMD/CSI/ROLE2SOD";
	public static final String  CSI_BASE_LOC_MATRIX		= "C:/OneMD/CSI/CONFLICT_MATRIX";
	public static final String 	HANA_DBRISK_FILEPATH 	= "C:/OneMD/CSI/HANA/CONFLICT_MATRIX/HNDB_Risks.xlsx";
	public static final String 	JDA_DBRISK_FILEPATH 	= "C:/OneMD/CSI/JDA/CONFLICT_MATRIX/JDA_DB_Risks.xlsx";
	public static final String 	JDA_CROSSAPP_MATRIX_FILEPATH	= "C:/OneMD/CSI/JDA/CONFLICT_MATRIX/JDA Cross-App Role and Conflict Matrix.xlsx";
	public static final String 	JDA_TECH_ROLEMAP_FILEPATH		= "C:/OneMD/CSI/JDA/CONFLICT_MATRIX/JDA Role Mapping.xlsx";
	public static final String 	csiFilePath 			= "C:/OneMD/CSI_FOLDER_STRUCTURE.PROPERTIES"; //Server CSI Properties
	public static final String 	dbFilePath 				= "C:/OneMD/DB.PROPERTIES"; //Server DB Properties
	public static final String  hanaFilePath 			= "C:/OneMD/HANA_FOLDER_STRUCTURE.PROPERTIES";
	public static final String 	sapGaaFilePath 			= "C:/OneMD/SAPGAA_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickFilePath 	= "C:/OneMD/SAP1CLICK_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	sapOneClickU2RFilePath 	= "C:/OneMD/SAP1CLICK_USER2ROLE_EXTR_STRUCTURE.PROPERTIES";
	public static final String 	jdeFilePath 			= "C:/OneMD/JDE_STRUCTURE.PROPERTIES";
	public static final String 	leadDistEmailPath		= "C:/OneMD/LEAD_DIST_EMAIL.PROPERTIES";
	*/


}
