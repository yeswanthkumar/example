package com.jnj.rqc.common.sorting;

import java.util.Comparator;

import com.jnj.rqc.reportmodels.ReportDataModel;

public class RQCReportComparator implements Comparator<ReportDataModel> {

	@Override
	public int compare(ReportDataModel r1, ReportDataModel r2) {
		    return r1.getDtCreated().compareTo(r2.getDtCreated());
    }
}
