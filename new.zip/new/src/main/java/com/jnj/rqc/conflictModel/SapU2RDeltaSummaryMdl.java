package com.jnj.rqc.conflictModel;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapU2RDeltaSummaryMdl {
	private String userId;
	private int rolesIn;
	private int rolesCol;
	private Date reportDate;


	@Override
	public String toString() {
		return "SapU2RDeltaSummaryMdl [userId=" + userId + ", rolesIn=" + rolesIn + ", rolesCol=" + rolesCol
				+ ", reportDate=" + reportDate + "]";
	}








}
