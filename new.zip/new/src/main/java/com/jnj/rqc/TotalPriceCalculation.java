package com.jnj.rqc;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class TotalPriceCalculation {
	public static DateFormat dtFmt  = new SimpleDateFormat("MM-dd-yyyy");
	public static void main(String[] args) {
		int rate=400;
		// Create a Scanner object to read input.
	     Scanner console = new Scanner(System.in);
	     System.out.println("Rate Per Day: "+rate);
	     System.out.print("AVAILABLE VIHICLE :\n\tBUS\n\tCAR\n\tVAN\n");
		 System.out.println("SELECT VEHICLE :");
	     String selVehicle = console.next();

	     // Get Dates.
	     System.out.print("Enter Start Date(mm-dd-yyyy) :");
	     String startDt = console.next();

	     System.out.print("Enter End Date(mm-dd-yyyy) :");
	     String endDt = console.next();


	     System.out.println("************************************************");
	      // Display Data.
	      System.out.println("Selected Vehicle " +selVehicle );
	      System.out.println("Start Date " +startDt );
	      System.out.println("End Date " +endDt );
	      long time_difference = ((fmtStrToDate(endDt).getTime())-(fmtStrToDate(startDt).getTime()));
	      long days_difference = (time_difference / (1000*60*60*24)) % 365;
	      System.out.println("Total Days: " +days_difference );

	      System.out.println("Total Price: " +(days_difference*rate) );

	}

	public static Date fmtStrToDate(String dtStr) {
		Date dt=null;
		if(dtStr != null) {
			try {
				dt = dtFmt.parse(dtStr);
			} catch (Exception e) {
				System.out.println("Exception Parsing Date ("+dtStr+") :"+e.getMessage());
				e.printStackTrace();
			}
		}
		return dt;
	}

}
