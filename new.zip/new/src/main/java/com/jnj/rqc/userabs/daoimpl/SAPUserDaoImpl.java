package com.jnj.rqc.userabs.daoimpl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.dbconfig.SAPTemplateFactory;
import com.jnj.rqc.mastermetadata.dao.MasterMetaDataRepository;
import com.jnj.rqc.security.AnaplanAuthenticatorBean;
import com.jnj.rqc.userabs.dao.SAPUserDao;
import com.jnj.rqc.util.Utility;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;

import au.com.bytecode.opencsv.CSVReader;




@Service
public class SAPUserDaoImpl  extends SAPTemplateFactory implements SAPUserDao {
	static final Logger log = LoggerFactory.getLogger(SAPUserDaoImpl.class);
	@Autowired
	private  MasterMetaDataRepository masterRepository;
	
	@Autowired
	private AnaplanAuthenticatorBean anaplanAuthenticatorBean;
	
	@Autowired
	private RestTemplate restHttpTemplate;
	
	@Autowired
	private UserMenuDao userMenuDao;
	
	@Override
	public List<IAMRolesADGrpMdl> getPFBRoleADGrps(String sysTempl, String userId) throws JCoException {
		List<IAMRolesADGrpMdl> usrData = new ArrayList<>();
		JCoDestination destination = getDestination(sysTempl);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "ZFINM_USER_LDAP");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        String dt = Utility.fmtYMD(new Date());
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USER1 EQ '"+userId+"'");

        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MANDT");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USER1");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AD_GROUP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MDATE");//Access Start Dated
        //STOP_DATE
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "STOP_DATE");//
        function.execute(destination);


        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                //log.info("sMessage: "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
                umdl.setClient(dataArr[0].trim());
                umdl.setUser(dataArr[1].trim());
                umdl.setLdapADGroup(dataArr[2].trim().toUpperCase());
                umdl.setMdate(dataArr[3].trim());
                umdl.setStopdate(dataArr[4]);//END Date
                if(!usrData.contains(umdl)) {
                	usrData.add(umdl);
                }
            }
        }
        log.info("Total AD Group for User: "+userId +" Records returned : "+((usrData !=null) ? usrData.size():"0")+" for System : BW4PFB");
        return usrData;
	}



	@Override
	public List<IAMRolesADGrpMdl> getPFIRoleADGrps(String templSysParam, String user ) throws JCoException {
		log.info("getPFIUsersRoles() for Template Name : "+templSysParam+ " - User :"+user);
		List<IAMRolesADGrpMdl> rlsData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        //FROM_DAT, TO_DAT
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "FROM_DAT");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "TO_DAT");

        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                //log.info("sMessage CFIN: "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
                umdl.setUser(dataArr[0].trim());
                umdl.setLdapADGroup(dataArr[1].trim().toUpperCase());
                umdl.setMdate(dataArr[2].trim());//Modified Date
                umdl.setStopdate(dataArr[3]);//END Date
                if(!rlsData.contains(umdl)) {
                	rlsData.add(umdl);
                }
                //log.info("UNAME > " + dataArr[0]+" AGR_NAME > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}


	@Override
	public List<IAMRolesADGrpMdl> getGRCRoleADGrps(String templSysParam, String user ) throws JCoException {
		log.info("getGRCRoleADGrps() for Template Name : "+templSysParam+ " - User :"+user);
		List<IAMRolesADGrpMdl> rlsData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        //FROM_DAT, TO_DAT
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "FROM_DAT");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "TO_DAT");

        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                log.info("sMessage GRC: "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
                umdl.setUser(dataArr[0].trim());
                umdl.setLdapADGroup(dataArr[1].trim());
                umdl.setMdate(dataArr[2].trim());//Modified Date
                umdl.setStopdate(dataArr[3]);//END Date
                if(!rlsData.contains(umdl)) {
                	rlsData.add(umdl);
                }
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}





	/*@Override
	public List<String> getAllValidUsers(String templSysParam) throws JCoException {
		log.info("Gell All Users for Template Name : "+templSysParam);
		List<String> usrData = new ArrayList<String>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR02");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        //log.debug("Setting OPTIONS");
        Date date = new Date(1410152400000L);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = formatter.format(date);
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USTYP EQ 'A'");
        log.debug("Setting QUERY FIELDS");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGV");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGB");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USTYP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "CLASS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UFLAG");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "ERDAT");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                Object sValue = sMessage.trim();
                if ((sValue instanceof Date)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
                    sValue = sdf.format(sValue);
                }
                String[] dataArr = sMessage.trim().split(",");
                String usrNm = dataArr[0].trim().replaceAll("[^\\.A-Za-z0-9_-]", "");
                if(!usrData.contains(usrNm)) {
                	usrData.add(usrNm);
                }
                //log.info("BNAME > " + dataArr[0]+" GLTGV > "+dataArr[1]+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]);
            }
        }
        log.info("Total User Records returned(SAP-USR02 - "+"templSysParam"+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}
*/



	/*@Override
	public List<String> getGRCUserRoleADGrps(String templSysParam, String user ) throws JCoException {
		log.info("getGRCUserRoleADGrps() for Template Name : "+templSysParam+ " - User :"+user);
		List<String> rlsData = new ArrayList<String>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        //function.getImportParameterList().setValue("QUERY_TABLE", "ZGRC_BROLE");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                if(!rlsData.contains(dataArr[1].trim())) {
                	rlsData.add(dataArr[1].trim());
                }
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}
*/
	@Override
	public void fetchExistingRolesCFIN(String templSysParam) throws JCoException {
		log.info("CFIN block enter into the block");
		//String user = "152980053";
		masterRepository.deleteAllRowsFromCFIN();
		List<IAMRolesADGrpMdl> rlsData = new ArrayList<>();
		List<IAMRolesADGrpMdl> records = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
	    sapRepository = destination.getRepository();
	    log.debug("getUsersRoles() check block  1 " );
	    JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
	    JCoFunction function = template.getFunction();
	    function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
	    function.getImportParameterList().setValue("DELIMITER", ",");
	    function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
	    function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
	    log.debug("getUsersRoles() check block  2 " );
	    //Setting options
	   // JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
	    //returnOptions.appendRow();
	    //System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
	    //returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
	   // returnOptions.appendRow();
	   //setValue("TEXT", " AND COL_FLAG NE 'X'");
	    //TODO - Add condition TO_DAT >= todays Date
	    log.debug("getUsersRoles() check block  3 " );
	    //Setting Fields
	    JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
	    returnFields.appendRow();
	    returnFields.setValue("FIELDNAME", "UNAME");
	    returnFields.appendRow();
	    returnFields.setValue("FIELDNAME", "AGR_NAME");
	    //FROM_DAT, TO_DAT
	    returnFields.appendRow();
	    returnFields.setValue("FIELDNAME", "FROM_DAT");
	    returnFields.appendRow();
	    returnFields.setValue("FIELDNAME", "TO_DAT");
	    log.debug("getUsersRoles() check block  4 " );
	    function.execute(destination);
	    log.debug("getUsersRoles() check block  5 " );
	    JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
	    JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
	    int icodeOffSet = 0;
	    int icodeLength = 0;
	    int numRows = jcoTabled.getNumRows();
	    log.debug("getUsersRoles() Totla numRows returned  > " + numRows);
	    log.debug("getUsersRoles() check block  6 " );
	    if (numRows > 0 ) {
	        for (int iRow = 0; iRow < numRows; iRow++) {
	            jcoTablef.setRow(0);
	            icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
	            icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
	            icodeLength += icodeOffSet;
	            jcoTabled.setRow(iRow);
	            String sMessage = jcoTabled.getString("WA");
	            //log.info("sMessage CFIN: "+sMessage);
	            String[] dataArr = sMessage.trim().split(",");
	            IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
	            umdl.setUser(dataArr[0].trim());
	            umdl.setLdapADGroup(dataArr[1].trim());
	            umdl.setMdate(dataArr[2].trim());//Modified Date
	            umdl.setStopdate(dataArr[3]);//END Date
	            if(!rlsData.contains(umdl)) {
	            	rlsData.add(umdl);
	            }
	        }
	    }
	    log.info("------------> size of the CFIN RFC query output  :"+rlsData.size());

        records = rlsData.parallelStream().filter(e -> {
									       	String user = e.getUser();
									       	return isNumeric(user);
								       }).collect(Collectors.toList());
        
        List<IAMRolesADGrpMdl> filteredRecords = records.stream()
        	    .filter(record -> record.getLdapADGroup() != null && record.getLdapADGroup().startsWith("Z"))
        	    .collect(Collectors.toList());
        log.debug("------------> size of the CFIN after filtering adgroup names start with Z");       
              
	    masterRepository.insertCFINMultipleRecords(filteredRecords);
	}
	private boolean isNumeric(String str) {
	    if (str == null || str.isEmpty()) {
	        return false;
	    }
	    for (char c : str.toCharArray()) {
	        if (!Character.isDigit(c)) {
	            return false;
	        }
	    }
	    return true;
	}

	public void fetchExistingRolesDDGR(String templSysParam) throws JCoException {
		masterRepository.deleteAllRowsFromDDGR();
		List<IAMRolesADGrpMdl> usrData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "ZFINM_USER_LDAP");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        //JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        //String dt = Utility.fmtYMD(new Date());
        //returnOptions.appendRow();
        //returnOptions.setValue("TEXT", "USER1 EQ '"+userId+"'");

        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MANDT");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USER1");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AD_GROUP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MDATE");//Access Start Dated
        //STOP_DATE
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "STOP_DATE");//
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                //log.info("sMessage: "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
                umdl.setClient(dataArr[0].trim());
                umdl.setUser(dataArr[1].trim());
                umdl.setLdapADGroup(dataArr[2].trim());
                umdl.setMdate(dataArr[3].trim());
                umdl.setStopdate(dataArr[4]);//END Date
                if(!usrData.contains(umdl)) {
                	usrData.add(umdl);
                }
            }
        }
        log.info("Total AD Group for Records returned : "+((usrData !=null) ? usrData.size():"0")+" for System : BW4PFB");
        usrData.stream().limit(100)
        .forEach(e -> {
        	System.out.println("------------------User   >: "+e.getUser());
        	System.out.println("------------------Ad name>: " +e.getLdapADGroup());
        	System.out.println("--------------client name>: " +e.getClient());
        });
        masterRepository.insertDDGRMultipleRecords(usrData);
	}
	public void fetchExistingRolesAnaplan() {
		log.info("Reading Individual Export Data for Anaplan : ");
   	 long start = System.currentTimeMillis();
   	 List<IAMRolesADGrpMdl> dataList = new ArrayList<>();
   	 masterRepository.deleteAllRowsFromAnaplan();
   	 try{
   		start = System.currentTimeMillis();
   		anaplanAuthenticatorBean = AnaplanAuthenticatorBean.initAnaplanAuth(restHttpTemplate, userMenuDao);
   		log.info("<<<<<<<<<<  Total time taken for AnaPlan Authentication : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
   		log.info("Session ID: "+anaplanAuthenticatorBean.getTokenInfo().getTokenId()+"\n Token Value: "+anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
   		HttpHeaders headers = Utility.getHeaders("JSON", anaplanAuthenticatorBean.getTokenInfo().getTokenValue());
   		HttpEntity<String> reqEntity = new HttpEntity<>(headers);
   		Gson gson = new Gson();
   		String anaplanViewUri = userMenuDao.getUtilsConstVals("ANAPLAN_VIEW_ALL_USERS_URI");
   		//String anaplanViewUri = "https://api.anaplan.com/2/0/models/9B832460B2D64B8C9EF8C5F5385116E4/views/327000000016";
   		log.info("---------> anaplanViewUri :"+anaplanViewUri+"/data");
   		ResponseEntity<String> respEntity = restHttpTemplate.exchange(anaplanViewUri+"/data", HttpMethod.GET, reqEntity, String.class);
   		if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
   			String body = respEntity.getBody();
   			log.info("calling parseCSV logic");
   			List<IAMRolesADGrpMdl> userList = parseCSV(body);
   			log.info("end of parseCSV logic");
   			masterRepository.insertAnaplanMultipleRecords(userList);
   		}
   	 }catch (Exception e) {
			log.error("Exception getting Exp Def:"+e.getMessage(), e);
		}
	}
	public List<IAMRolesADGrpMdl> parseCSV(String csvData) {
		log.info("enter into the block");
		List<IAMRolesADGrpMdl> dataList = new ArrayList<>();
		try {
			CSVReader reader = new CSVReader(new StringReader(csvData));		
			List<String[]> csvRows = reader.readAll();	
			log.info("------------------> parseCSV csvRows.size() :"+csvRows.size());
		        for (int i = 1; i < csvRows.size(); i++) {
		        	IAMRolesADGrpMdl csmMdl = new IAMRolesADGrpMdl();
		        	String[] data = csvRows.get(i);
		        	csmMdl.setClient("4");
		        	csmMdl.setLdapADGroup(data[6]);
		        	csmMdl.setUser(data[3]); //WWID
		        	csmMdl.setMdate(data[13]); // From date
		        	csmMdl.setStopdate(data[14]); // End date
		        	dataList.add(csmMdl);
		        }	
		        dataList.stream()
		        .limit(20)
		        .forEach(e -> {
		        	log.info("--------------------anaplan :"+e.getClient());
		        	log.info("--------------------anaplan :"+e.getLdapADGroup());
		        	log.info("--------------------anaplan :"+e.getUser());	
		        	log.info("------------------------------------------------ :");
		        });
		        log.info("end of the block");
		}catch(Exception e) {
			log.error("Exception :"+e.getMessage());
		}		   
		return dataList;		
	}

}
