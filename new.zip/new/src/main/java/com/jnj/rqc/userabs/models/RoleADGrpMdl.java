package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleADGrpMdl implements Serializable{
	private static final long serialVersionUID = -1108320057625924930L;

	private int 	reqId;
	private String userId;
	private String secId;
	private String secName;
	private String sysId;
	private String sysName;
	private String regId;
	private String regName;
	private String posId;
	private String posName;
	private String accId;
	private String accName;
	private String pvId;
	private String pvName;
	private String adgrpId;
	private String adgrpName;
	private String isRestricted;
	private String reqBy;
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date reqDate;
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date updDate ;
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date endDate ;
	private String isExisting;
	//Approval Variables
	private String acceptDeny;
	private String resolved;
	private String resolutionCmnts;
	private String resolvedby;
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date   resolvedon;

	/*private String acceptedVarids;
	private String denedVarids;
	private int    cntrlSelected;
	*/


}