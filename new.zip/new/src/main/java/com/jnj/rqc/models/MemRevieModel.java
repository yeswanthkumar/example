package com.jnj.rqc.models;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;

@Data
public class MemRevieModel {
	private String accountName;
	private Date   accountFstCol;
	private Date   accountLstCol;
	private String wwid;
	private String fullName;
	private String netId;
	private String email;
	private String title;
	private String dept;
	private String grpShrtNm;
	private String grpNm;
	private String grp;
	private String role;
	private Date   dtAdded;
	private String sodCd;
	private String rqcTkt;
	private String asignerName;
	private String isSelfAdmin;
	private String isSecTeam;
	private String isRoleMatch;



	public String getData() {
		return accountName+"~"+Utility.dtFmt.format(accountFstCol)+"~"+Utility.dtFmt.format(accountLstCol)+"~"+wwid+"~"+fullName+"~"+netId+"~"+email+"~"+title+"~"+dept+"~"+grpShrtNm+"~"+grpNm+"~"+grp+"~"+role+"~"+Utility.dtFmt.format(dtAdded)+"~"+sodCd+"~"+rqcTkt+"~"+asignerName+"~"+isSelfAdmin+"~"+isSecTeam+"~"+isRoleMatch;

	}




	@Override
	public String toString() {
		return "NagsModel [accountName=" + accountName + ", accountFstCol=" + accountFstCol + ", accountLstCol="
				+ accountLstCol + ", wwid=" + wwid + ", fullName=" + fullName + ", netId=" + netId + ", email=" + email
				+ ", title=" + title + ", dept=" + dept + ", grpShrtNm=" + grpShrtNm + ", grpNm=" + grpNm + ", grp="
				+ grp + ", role=" + role + ", dtAdded=" + dtAdded + ", sodCd=" + sodCd + ", rqcTkt=" + rqcTkt
				+ ", asignerName=" + asignerName + "]";
	}

}
