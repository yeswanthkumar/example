package com.jnj.rqc.autotask;

import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.models.UserSearchModel;

@WebListener
public class RQCUtilsSessionListener implements HttpSessionListener {
	static final Logger log = LoggerFactory.getLogger(RQCUtilsSessionListener.class);
	private final AtomicInteger counter = new AtomicInteger();

    @Override
    public void sessionCreated(HttpSessionEvent se) {
    	log.info("New session is created. Adding Session to the counter.");
    	se.getSession().setMaxInactiveInterval(60*60);
    	counter.incrementAndGet();  //incrementing the counter
    	updateSessionCounter(se);

    	//User Popup Cookie
    	Cookie cookie = new Cookie("LOAD_DATA", "Y");
    	se.getSession().setAttribute("TEST_COOKIE", cookie);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
    	try {
    		UserSearchModel usr =(UserSearchModel)se.getSession().getAttribute(Constants.AUTH_USER);
        	if(usr != null) {
        		log.info("REMOVING SESSION FOR USER : "+usr.getFmlyNm()+", "+usr.getGivenNm()+" ("+usr.getWwId()+"="+usr.getJnjMsftUsrnmTxt()+")");
        	}
		} catch (Exception e) {
			// TODO: handle exception
		}

    	log.info("Session destroyed. Removing the Session from the counter.");
        se.getSession().removeAttribute("USER_VALIDATED");
        se.getSession().removeAttribute(Constants.AUTH_USER);
		counter.decrementAndGet();  //decrementing counter
        updateSessionCounter(se);
    }

    private void updateSessionCounter(HttpSessionEvent httpSessionEvent){
        httpSessionEvent.getSession().getServletContext().setAttribute("activeSession", counter.get());
        log.info("TOTAL NUMBER OF USERS LOGGED IN : "+counter.get());
    }

}