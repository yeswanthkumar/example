package com.jnj.rqc.useridentity.models;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class UIRequestDispModel {
	private int 	reqId;
	private int 	reqTyp;
	private String  reqTypName;
	private Date   	reqDt;
	private String 	reqBy;
	private String 	reqByName;
	private String 	userId;
	private String 	assoUserName;
	private String 	mgrWwid;
	private String 	mgrName;
	private int 	bfId;
	private String 	bfName;
	private String 	secIds;
	private String 	regIds;
	private int 	reqStatus;
	private String  reqStatusDesc;
	private String  conflFound;
	private String  isExces;
	private String  conflResolved;
	private String  routedToCompl;
	private Date   	conflUpdated;
	private Date   	dtUpdated;
	private String  updtBy;
	private String comments;
	private List<IAMRequestedRoleModel> roleStatus;












}
