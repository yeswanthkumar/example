package com.jnj.rqc.mastermetadata.dao;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.MitigationData;

public class MitigationListData {

	 private List<MitigationData> records;

	    public List<MitigationData> getRecords() {
	        return records;
	    }

	    public void setRecords(List<MitigationData> records) {
	        this.records = records;
	    }

		@Override
		public String toString() {
			return "MyDataInput [records=" + records + ", getRecords()=" + getRecords() + ", getClass()=" + getClass()
					+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}
}
