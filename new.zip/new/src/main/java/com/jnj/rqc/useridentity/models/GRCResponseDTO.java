package com.jnj.rqc.useridentity.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GRCResponseDTO {
	private String BGJOBID = "";
	private String BPROC   ="FINANCE";
	private int EMPTYPE    = 0;
	private String FUNCAREA;
	private String MESSAGE;
	private String MESSAGE_ID;
	private String MESSAGE_TYPE;
	private String MSMP_APPROVAL_STATUS;
	private String MSMP_PROCESS_ID;
	private String ON_HOLD_BY;
	private int PRIORITY = 0;
	private String REQ_APPROVED;
	private String REQ_COMPLETED;
	private int REQ_CREATED = 0;
	private String REQ_ID;
	private String REQ_INIT_SYS;
	private String REQJUSTIFICATION;
	private String REQNO;
	private int    REQTYPE = 2;
	private String SKIP_MSMP;
	private int SLA_ID = 0;
	private String STATUS;
	private String TEMPLATE_ID;
	private String UPDATED_BY_ID;
    private String UPDATED_BY_NAME;
    private String UPDATED_ON;
    private String Z_PROJECT_USER = "NO";
    private String ZZ_PROJECT_NAME = "NOT APPLICABLE";
    private String ZZ_DCM_NUMBER;
    private String ZZ_INCIDENT_NUMBER;
    private String ZZ_LEGAL_ENTITY;
    private String ZZ_MGT_REP_COMP;
    private String ZZ_PLANT;
    private String ZZ_TRAINING_COMPLETED = "YES";
    private String ZZ_POSITION;
    private String ZZ_PLATFORM;
    private String ZZ_PREFERRED_LANGUAGE;
    private String ZZ_RF_USER;
    private String ZZ_USRGRP;
	List<SubmitRolen> SUBMITROLEN;
	List<SubmitUsern> SUBMITUSERN;








}
