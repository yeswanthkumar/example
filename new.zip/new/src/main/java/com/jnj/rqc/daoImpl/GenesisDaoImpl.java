package com.jnj.rqc.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dbconfig.BaseDao;



@Service
public class GenesisDaoImpl  extends BaseDao implements GenesisDao {
	static final Logger log = LoggerFactory.getLogger(GenesisDaoImpl.class);

	@SuppressWarnings("all")
	@Override
	public int insertTrfCntrlData(List<SAPUserAccessModel> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into ERP_TRANSFER_DATA (SAP_PLATFORM, SAP_SYSTEM, DESCRIPTION_DETAILS, DETAILS, USER_NTID, WWID)  Values  (?, ?, ?, ?, ?, ?) ";
		log.debug("Inserting Data to Genesis, Query: "+qry);
		int[] status = getJdbcTemplateGenesisDev().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getSapPlatform());
						ps.setString(2, dataList.get(i).getSystemClient());
						ps.setString(3, dataList.get(i).getDescription());
						ps.setString(4, dataList.get(i).getDetails());
						ps.setString(5, dataList.get(i).getSapId());
						ps.setString(6, dataList.get(i).getWwid());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}



	@SuppressWarnings("all")
	@Override
	public int insertUser2SodData(List<SapUser2SodModel> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER_2_SOD "
				+ "( REVIEWER_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID, ADDITIONAL_INFO3, PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION, REVIEWER_DESCRIPTION ) "
				+ " Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		log.debug("Inserting Data to Genesis, Query: "+qry);
		int[] status = getJdbcTemplateGenesisDev().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRevUserId());
						ps.setString(2, dataList.get(i).getUserId());
						ps.setString(3, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(4, dataList.get(i).getAdditionalInfo1());
						ps.setString(5, dataList.get(i).getAdditionalInfo2());
						ps.setString(6, dataList.get(i).getMitigatingId());
						ps.setString(7, dataList.get(i).getAdditionalInfo3());
						ps.setString(8, dataList.get(i).getPlatformName());
						ps.setString(9, dataList.get(i).getRiskIdAndRiskDescription());
						ps.setString(10, dataList.get(i).getReviewerDescription());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}




	@SuppressWarnings("all")
	@Override
	public int insertUser2RoleData(List<SapGaaUser2RoleModel> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER_2_ROLE "
				+ "( REVIEWER_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3 ) "
				+ " Values  (?, ?, ?, ?, ?, ?, ?, ?) ";
		log.debug("Inserting Data to Genesis, Query: "+qry);
		int[] status = getJdbcTemplateGenesisDev().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRevUserId());
						ps.setString(2, dataList.get(i).getUserId());
						ps.setString(3, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(4, dataList.get(i).getPrimaryReviewInfo2());
						ps.setString(5, dataList.get(i).getPrimaryReviewInfo3());
						ps.setString(6, dataList.get(i).getAdditionalInfo1());
						ps.setString(7, dataList.get(i).getAdditionalInfo2());
						ps.setString(8, dataList.get(i).getAdditionalInfo3());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}



	@Override
	public List<SapDataTransferReportMdl> getGenesisTransferCtrlReportData() throws SQLException, DataAccessException {
		log.info("Query GENESIS Transfer Control Report Data");
		String sql = " SELECT REVIEW_NAME, SAP_PLATFROM, SAP_SYSTEM, GROUP_DESCRIPTION, ACCOUNT_NAME, ACCOUNT_OWNER, ACCOUNT_OWNER_WWID, ACCOUNT_OWNER_TITLE, "+
					 " DESIGNATED_REVIEWER, DESIGNATED_REVIEWER_WWID, REVIEWED_BY_NAME, REVIEWED_BY_WWID, CREATION_DATE, DATE_REVIEWED, REVIEW_STATUS, DATE_ENTERED " +
					 " FROM ERP_DATATRANSFER_REPORT ORDER BY SAP_PLATFROM, SAP_SYSTEM ";
					 //" FROM  GENESIS_EP_DEV.ERP_DATATRANSFER_REPORT ORDER BY SAP_PLATFROM, SAP_SYSTEM ";

		final List<SapDataTransferReportMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SapDataTransferReportMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}

	@Override
	public List<String> getGenesisUser2RoleSysData() throws SQLException, DataAccessException{
		log.info("Query GENESIS User to Role Platform Names Data");
		String sql = " SELECT DISTINCT GROUP_PLATFORM FROM USER_2_ROLE_REPORT ORDER BY GROUP_PLATFORM ";
		final List<String> sysLst = getJdbcTemplateGenesisDev().queryForList(sql, String.class);
		log.info("Total Platforms : "+((sysLst !=null)? sysLst.size(): 0)+"  .......END");
		return sysLst;
	}


	@Override
	public List<SapUser2RoleReportMdl> getGenesisUser2RolePlatformReportData(String platform) throws SQLException, DataAccessException {
		log.info("Query GENESIS User to Role Report Data");
		String sql = " SELECT REVIEW_NAME, GROUP_PLATFORM, GROUP_DESCRIPTION, GROUP_SHORT_NAME, GROUP_OTHER_2, GROUP_OTHER_3, ACCOUNT_NAME, ACCOUNT_OWNER_NAME, ACCOUNT_OWNER_TITLE, "+
					 " ACCOUNT_OWNER_USER_ID, ACCOUNT_OWNER_USER_NAME, ACCOUNT_OWNER_EMAIL, ACCOUNT_OWNER_MRC, ACCOUNT_OWNER_DEPARTMENT, GROUP_TYPE, DESIGNATED_REVIEWER, "+
					 " DESIGNATED_REVIEWER_WWID, REVIEWED_BY_NAME, REVIEWED_BY_WWID, REVIEW_STATUS, REVIEWER_COMMENTS, DATE_ENTERED "+
					 " FROM USER_2_ROLE_REPORT "+
					 " WHERE GROUP_PLATFORM = ? "+
					 " ORDER BY GROUP_PLATFORM, GROUP_OTHER_2 ";
		final List<SapUser2RoleReportMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {platform}, new BeanPropertyRowMapper<>(SapUser2RoleReportMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}

	@Override
	public List<SapUser2RoleReportMdl> getGenesisUser2RoleReportData() throws SQLException, DataAccessException {
		log.info("Query GENESIS User to Role Report Data");
		String sql = " SELECT REVIEW_NAME, GROUP_PLATFORM, GROUP_DESCRIPTION, GROUP_SHORT_NAME, GROUP_OTHER_2, GROUP_OTHER_3, ACCOUNT_NAME, ACCOUNT_OWNER_NAME, ACCOUNT_OWNER_TITLE, "+
					 " ACCOUNT_OWNER_USER_ID, ACCOUNT_OWNER_USER_NAME, ACCOUNT_OWNER_EMAIL, ACCOUNT_OWNER_MRC, ACCOUNT_OWNER_DEPARTMENT, GROUP_TYPE, DESIGNATED_REVIEWER, "+
					 " DESIGNATED_REVIEWER_WWID, REVIEWED_BY_NAME, REVIEWED_BY_WWID, REVIEW_STATUS, REVIEWER_COMMENTS, DATE_ENTERED "+
					 " FROM USER_2_ROLE_REPORT ORDER BY GROUP_PLATFORM, GROUP_OTHER_2 ";/*, SAP_SYSTEM */
		final List<SapUser2RoleReportMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SapUser2RoleReportMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}


	@Override
	public List<SapUser2SodReportMdl> getGenesisUser2SodReportData() throws SQLException, DataAccessException {
		log.info("Query GENESIS User To Sod Report Data");
		String sql = " SELECT REVIEW_NAME, GROUP_PLATFORM, GROUP_DESCRIPTION, GROUP_SHORT_NAME , GROUP_OTHER_1 as groupOther1, GROUP_OTHER_2 as groupOther2, GROUP_OTHER_3 as groupOther3, "+
				  	 " ACCOUNT_NAME, ACCOUNT_OWNER_NAME, ACCOUNT_OWNER_TITLE, ACCOUNT_OWNER_USER_NAME, ACCOUNT_OWNER_EMAIL, ACCOUNT_OWNER_DEPARTMENT, DESIGNATED_REVIEWER, "+
				  	 " DESIGNATED_REVIEWER_WWID, REVIEWED_BY_NAME, REVIEWED_BY_WWID, DATE_GENERATED, DATE_REVIEWED, REVIEW_STATUS, REVIEWER_COMMENTS, DATE_ENTERED "+
				  	 " FROM USER_2_SOD_REPORT ORDER BY GROUP_PLATFORM,  ACCOUNT_NAME, REVIEW_STATUS ";
		final List<SapUser2SodReportMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SapUser2SodReportMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}


	@Override
	public List<SapUser2RoleDeltaMdl> getGenesisUser2RoleData(List<String> users) throws SQLException, DataAccessException{
		log.info("Query GENESIS User To Role Data");
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT REVIEWER_USER_ID AS REV_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, DATE_ENTERED");
		sql.append(" FROM USER_2_ROLE WHERE USER_ID IN ( ");
		String vars="";
		for(int i=0; i<users.size(); i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+	vars+" )");
		sql.append(" ORDER BY ADDITIONAL_INFO1, PRIMARY_REVIEW_INFO3 ");/*, SAP_SYSTEM */
		final List<SapUser2RoleDeltaMdl> reportLst = getJdbcTemplateGenesisDev().query(sql.toString(), users.toArray(), new BeanPropertyRowMapper<>(SapUser2RoleDeltaMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}

	@Override
	public List<SapUser2SodDeltaMdl> getGenesisUser2SodData(List<String> users) throws SQLException, DataAccessException{
		log.info("Query GENESIS User To Sod Data");
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT REVIEWER_USER_ID AS revUserId, USER_ID, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID, ADDITIONAL_INFO3, PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION, REVIEWER_DESCRIPTION, DATE_ENTERED ");
		sql.append(" FROM USER_2_SOD WHERE USER_ID IN ( ");
		String vars="";
		for(int i=0; i<users.size(); i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+	vars+" )");
		sql.append(" ORDER BY USER_ID, PLATFORM_NAME ");
		final List<SapUser2SodDeltaMdl> reportLst = getJdbcTemplateGenesisDev().query(sql.toString(), users.toArray(), new BeanPropertyRowMapper<>(SapUser2SodDeltaMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}


	@Override
	public int checkUser2RoleReportRecord(String userId, String primaryReviewInfo3, String additionalInfo3 ) throws SQLException, DataAccessException{
		log.info("Checking records for User2Role Delta for : "+userId+" - "+primaryReviewInfo3+" - "+additionalInfo3);
		String sql = " SELECT count(*) from USER_2_ROLE_REPORT "+
					 " WHERE trim(upper(ACCOUNT_NAME)) = trim(upper('"+userId+"')) "+
					 " AND trim(upper(GROUP_OTHER_2)) = trim(upper('"+primaryReviewInfo3+"')) "+
					 " AND trim(upper(GROUP_OTHER_3)) = trim(upper('"+additionalInfo3+"')) ";
		int numRecords = getJdbcTemplateGenesisDev().queryForObject(sql, Integer.class);
		log.info("Total Rows : "+numRecords);
		return 0;
	}

	@Override
	public List<SapU2RDeltaSummaryMdl> getGenesisUserWiseCounts(String type) throws SQLException, DataAccessException{
		log.info("Query User2Role Data counts from USER TO ROLE & USER TO ROLE REPORT TABLES ");
		String sql="";
		if("IN".equals(type)) {
			sql 	 = " Select trim(upper(USER_ID)) AS USER_ID, count(*) AS ROLES_IN FROM USER_2_ROLE GROUP BY USER_ID " ;
		}else
			if("COL".equals(type)) {
			sql= " Select trim(upper(ACCOUNT_NAME)) AS USER_ID, count(*) AS ROLES_COL FROM USER_2_ROLE_REPORT GROUP BY ACCOUNT_NAME ";
		}
		final List<SapU2RDeltaSummaryMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SapU2RDeltaSummaryMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}


	@Override
	public List<SapU2RDeltaSummaryMdl> getGenesisUser2SodDataCounts(String type) throws SQLException, DataAccessException{
		log.info("Query User2Sod Data counts from USER TO SOD & USER TO SOD REPORT TABLES ");
		String sql="";
		if("IN".equals(type)) {
			sql 	 = " Select trim(upper(USER_ID)) AS USER_ID, count(*) AS ROLES_IN FROM USER_2_SOD GROUP BY USER_ID " ;
		}else
			if("COL".equals(type)) {
			sql= " Select trim(upper(ACCOUNT_NAME)) AS USER_ID, count(*) AS ROLES_COL FROM USER_2_SOD_REPORT GROUP BY ACCOUNT_NAME ";
		}
		final List<SapU2RDeltaSummaryMdl> reportLst = getJdbcTemplateGenesisDev().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SapU2RDeltaSummaryMdl.class));
		log.info("Total Rows : "+((reportLst !=null)? reportLst.size(): 0)+"  .......END");
		return reportLst;
	}


}
