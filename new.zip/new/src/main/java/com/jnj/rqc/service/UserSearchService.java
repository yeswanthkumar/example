package com.jnj.rqc.service;

import java.util.List;

import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.JJEDsUserLookupMdl;
import com.jnj.rqc.models.UserSearchModel;

public interface UserSearchService {
	public List<UserSearchModel> getUserData(int srchParam, String data, int status);
	public String writeUserCSVReport(List<UserSearchModel> data);
	public List<UserSearchModel> getUserDataByNtId(String data, int status);

	//USER IDENTITY METHODS
	public TableRespDto getEnvData(String propName);

	//User Search
	public List<String> readUserIdExcel(String path);
	public List<JJEDsUserLookupMdl> getAllUserData(List<String> usrIds);
	public String writeAllUserCSVReport(List<JJEDsUserLookupMdl> data);
	public List<UserSearchModel> getUserDataByFN(String firstName, String lastName, int status);
	public UserSearchModel getUserStatusJJEDS(String userId, int active);
	public List<UserSearchModel> getUserListFromJJEDS(String userId, int active);
	public UserSearchModel getUserStatusByEmailJJEDS(String emailId, int active);
	public UserSearchModel getUserStatusJJEDSForReport(String userId, int active);
	public List<UserSearchModel> getUserListFromJJEDSReport(String userId, int active);
	public List<UserSearchModel> getUserDataForReport(int srchParam, String data, int status);


}
