package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.CSMHistDataMdl;
import com.jnj.rqc.conflictModel.CSMModelAdGrpMap;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.controllers.CSMDataController;
import com.jnj.rqc.dao.CSMDataDao;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.service.CSMDataService;
import com.jnj.rqc.util.Utility;





@Service
public class CSMDataServiceImpl implements CSMDataService {
	static final Logger log = LoggerFactory.getLogger(CSMDataController.class);

	@Autowired
	CSMDataDao cSMDataDao;
	@Autowired
	ExcelReportWriter excelReportWriter;
	@Autowired
	CSVReportWriter cSVReportWriter;



	@Override
	public String buildCSMDataExcel(List<GrpUsrDateMdl> dataList, String flName) {
		String filePath = "";
		try{
			filePath = excelReportWriter.writeCSMDataExcel(dataList, flName+"_"+Utility.fmtMDY(new Date()), "CSM DATA");
		} catch (Exception e) {
			log.error("Error Building CSM Excel :"+e.getMessage(), e);
		}
		log.info("IAM - CSM Data File Path :"+filePath);
		return filePath;
	}



	@Override
	public List<CSMHistDataMdl> readCSMExcel(String path, HttpServletRequest request){
		log.info("Loding file :"+path);
		List<CSMHistDataMdl> csmHstLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows(Header): "+rowTotal);
			request.getSession().setAttribute("CSMFILE_TOTALCOUNT", rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}

				String status 	= Utility.getCellValue(rw.getCell(4));
				if(null == status || "INVALID".equals(status) || "TERMINATED".equals(status)) {
					i++;
					continue;
				}


				CSMHistDataMdl dtaMdl	= new CSMHistDataMdl();

				dtaMdl.setStatus(status);
				//String disp				= Utility.getCellValue(rw.getCell(0));
				//dtaMdl.setDispName(disp);
				//String parent	= Utility.getCellValue(rw.getCell(1));
				//dtaMdl.setParent(parent);
				//String code 		= Utility.getCellValue(rw.getCell(2));
				//dtaMdl.setCode(code);
				String fName 		= Utility.getCellValue(rw.getCell(0));
				dtaMdl.setFName(fName);
				String lName 		= Utility.getCellValue(rw.getCell(1));
				dtaMdl.setLName(lName);
				String wwid 	= Utility.getCellValue(rw.getCell(2));
				dtaMdl.setWwid(wwid);
				String email 	= Utility.getCellValue(rw.getCell(3));
				dtaMdl.setEmail(email);
				/*String status 	= Utility.getCellValue(rw.getCell(7));
				dtaMdl.setStatus(status);*/
				String adgroup	  	= Utility.getCellValue(rw.getCell(5));
				dtaMdl.setAdgroup(adgroup);

				String efDt	  	= Utility.getCellValue(rw.getCell(6));
				Date effDate = Utility.fmtCsmStr2Dt(efDt);
				dtaMdl.setEffDate(effDate);

				String vldfrm	  	= Utility.getCellValue(rw.getCell(7));
				Date vldFrom = Utility.fmtCsmStr2Dt(vldfrm);
				dtaMdl.setVldFrom(vldFrom);

				String vldto	  	= Utility.getCellValue(rw.getCell(8));
				Date vldTo = Utility.fmtCsmStr2Dt(vldto);
				dtaMdl.setVldTo(vldTo);

				if(null == effDate || null == vldFrom || null == vldTo) {
					i++;
					continue;
				}

				if(null != vldTo && (vldTo.getTime() < new Date().getTime())) {
					i++;
					continue;
				}


				//if(!csmHstLst.contains(dtaMdl)) {
				csmHstLst.add(dtaMdl);
				//}
				i++;
			}
		}
		log.info("Total CSM Records to Process : "+csmHstLst.size());
		return csmHstLst;
	}


	@Override
	public int saveCSMDataToDB(List<CSMHistDataMdl> csmData){
		int result = 0;
		try {
				result = cSMDataDao.insertCSMArchiveData(csmData);
		} catch (Exception e) {
			log.error("Error inserting CSM Archive Data :"+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int saveCSMModelDataToDB(List<CSMModelAdGrpMap> csmData){
		int result = 0;
		try {
				result = cSMDataDao.insertCSMModelData(csmData);
		} catch (Exception e) {
			log.error("Error inserting CSM Model Data :"+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<CSMModelAdGrpMap> readCSMModelDataXls(String path, HttpServletRequest request){
		log.info("Loding file :"+path);
		List<CSMModelAdGrpMap> csmMdlLst = new ArrayList<>();
		UserSearchModel user =(UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		Date cur = new Date();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows(Header): "+rowTotal);
			request.getSession().setAttribute("CSMMODEL_TOTALCOUNT", rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}

				String adgrp 	= Utility.getCellValue(rw.getCell(0));
				String mdlName 	= Utility.getCellValue(rw.getCell(1));

				if(null == adgrp || "".equals(adgrp) || null ==mdlName || "".equals(mdlName)) {
					i++;
					continue;
				}


				CSMModelAdGrpMap dtaMdl	= new CSMModelAdGrpMap();

				dtaMdl.setAdgroup(adgrp);
				dtaMdl.setModelname(mdlName);
				dtaMdl.setUpdatedBy(user.getWwId());
				dtaMdl.setUpdatedDate(cur);
				csmMdlLst.add(dtaMdl);

				i++;
			}
		}
		log.info("Total CSM Model Records to Process : "+csmMdlLst.size());
		return csmMdlLst;
	}

	@Override
	public String writeCSMDataCSV(List<CSMHistDataMdl> data, String fileName) {
		String filePath = "";
		filePath = cSVReportWriter.writeCSMArchieveCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}


	@Override
	public String writeCSMModelDataCSV(List<CSMModelAdGrpMap> data, String fileName) {
		String filePath = "";
		filePath = cSVReportWriter.writeCSMModelCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public List<GrpUsrDateMdl> validateAndFilterData(Map<String, List<GrpUsrDateMdl>> adDataMap) {
		List<GrpUsrDateMdl> finalList = new ArrayList<>();
		List<GrpUsrDateMdl> dataList = new ArrayList<>();
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 1);
		cal.set(Calendar.SECOND, 1);

		try{
			for (Map.Entry<String,List<GrpUsrDateMdl>> entry : adDataMap.entrySet()) {
				dataList.addAll(entry.getValue());
			}

			for(GrpUsrDateMdl userData:dataList) {
				int rcds = cSMDataDao.validateUserToAdGrpData(userData, cal.getTime());
				if(rcds <= 0) {
					finalList.add(userData);
				}
			}
		} catch (Exception e) {
			log.error("Error Building CSM Excel :"+e.getMessage(), e);
		}
		return finalList;
	}


	@Override
	public List<GrpUsrDateMdl> compareWithPreviousRun(List<GrpUsrDateMdl> step1DataList){
		List<GrpUsrDateMdl> finalList = new ArrayList<>();
		try{
			for(GrpUsrDateMdl userData:step1DataList) {
				int rcds = cSMDataDao.compareExistingData(userData);
				if(rcds <= 0) {
					finalList.add(userData);
				}
			}
		} catch (Exception e) {
			log.error("Error Building CSM Excel :"+e.getMessage(), e);
		}
		return finalList;
	}



	@Override
	public int saveIAMCSMDataToDB(List<GrpUsrDateMdl> iamCsmData){
		int result = 0;
		try {
				result = cSMDataDao.insertIAMDataForCMS(iamCsmData);
		} catch (Exception e) {
			log.error("Error inserting CSM Archive Data :"+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public List<GrpUsrDateMdl> getAllIAMCSMDataFromDB(){
		List<GrpUsrDateMdl> iamCsmData = new ArrayList<>();
		try {
			iamCsmData = cSMDataDao.getCSMIAMExportData();
		} catch (Exception e) {
			log.error("Error Querying CSM-IAM Data :"+e.getMessage(), e);
		}
		return iamCsmData;
	}


	@Override
	public int updateIAMCSMDataToComplete(){
		int result = 0;
		try {
				result = cSMDataDao.updateIAMDataForCMS();
		} catch (Exception e) {
			log.error("Error Updating CSM-IAM Data :"+e.getMessage(), e);
		}
		return result;
	}

}
