package com.jnj.rqc.userabs.models;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SysDpendncMdl implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -4930981150356148440L;
	private String reqid;
	private String sysid;
	private String sysname;
	List<PosnDpendncMdl> posns;
}
