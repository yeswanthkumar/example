package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.conflictModel.CSIFunctionActionModel;
import com.jnj.rqc.conflictModel.CSIFunctionPermModel;
import com.jnj.rqc.conflictModel.CSISodCriticalActRiskModel;
import com.jnj.rqc.conflictModel.CSISodRiskModel;
import com.jnj.rqc.conflictModel.RoleToSodModel;
import com.jnj.rqc.conflictModel.UserToSodModel;
import com.jnj.rqc.dbextr.models.TableRespDto;




/**
 * File    : <b>MemberReviewService.java</b>
 * @author : DChauras @Created : May 17, 2019 3:33:44 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface CSIDataService {

	public Map<String, List<UserToSodModel>> readUserToSodData(String path, String empId, String roleIds);
	public List<RoleToSodModel> readRoleToSodData(String path, String roleId);

	public String writeCSIUser2SodCsvReport(List<UserToSodModel> data, String fileName);
	public String writeCSIRole2SodCsvReport(List<RoleToSodModel> data, String fileName);

	public TableRespDto getEnvData(String propName);
	public List<CSISodRiskModel> readSodRiskData(String path);
	public String writeCSISodRiskCsvReport(List<CSISodRiskModel> data, String fileName);

	public List<CSISodCriticalActRiskModel> readSodCriticalActRiskData(String path);
	public String writeCSISodCriticalActRiskCsvReport(List<CSISodCriticalActRiskModel> data, String fileName);

	public List<CSIFunctionActionModel> readSodFunctionActData(String path);
	public String writeCSISodFunctionActCsvReport(List<CSIFunctionActionModel> data, String fileName);

	public List<CSIFunctionPermModel> readSodFunctionPermData(String path);
	public String writeCSISodFunctionPermCsvReport(List<CSIFunctionPermModel> data, String fileName);
}
