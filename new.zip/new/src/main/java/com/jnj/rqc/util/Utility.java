package com.jnj.rqc.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.CSIFunctionPermModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDAUser2SodModel;
import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.constants.RoleConstants;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.models.PosRoles;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;

import au.com.bytecode.opencsv.CSVWriter;

public class Utility {
	private static String ANAPLAN_PAGEID ="";
	/*public static void main(String[] args) {
		System.out.println("Date:"+Utility.fmtMDY(new Date()));
	}*/
	private static ObjectMapper mapper = new ObjectMapper();

	private static HashMap<String, UserSearchModel> USER_MAP = new HashMap<>();
	private static String hostname;
	static final Logger log = LoggerFactory.getLogger(Utility.class);
	public static DateFormat dtFmt  = new SimpleDateFormat("MM/dd/yyyy");
	public static DateFormat dtFmtTime  = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	public static DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
	public static  DateFormat iamFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.ENGLISH);
	//public static  DateFormat csmFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static  DateFormat csmFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");//CSM Changed the date format
	public static DateFormat dtFmtMDY  = new SimpleDateFormat("MMddyyyy");
	public static DateFormat dtFmtYMD  = new SimpleDateFormat("yyyyMMdd");
	public static  DateFormat adFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSS", Locale.ENGLISH);//20220214200450.0Z
	//For ABS
	public static DateFormat dMonYear = new SimpleDateFormat("MMMM dd, yyyy");

	public static Map<String, String> ROLES;
	public static Map<Integer, List<PosRoles>> POSROLES;
	public static Map<String, List<UserActivityModel>> USERACTDATA = new HashMap<>();
	public static Map<String, SystemCodeModel>  SYSTEMCODEMAP = new HashMap<>();//System Code Cache
	public static List<String> SYSTEM_NAME = new ArrayList<>();
	public static Map<String,List<Integer>> RQC_APP_NAMES = new TreeMap<>();
	private static final int BUFFER_SIZE = 4096;
	private static Properties dbProperties = new Properties();
	public static DateFormat formFmt  = new SimpleDateFormat("yyyy-MM-dd");//Format for form Input
	private static Map<String, String> USER2CRITICALROLES = new HashMap<>();


	private static Properties csiProperties = new Properties();
	private static Properties hanaProperties = new Properties();
	private static Properties sapGaaProperties = new Properties(); //SAP gAA Extraction properties
	private static Properties jdeProperties = new Properties(); //JDE Extraction properties
	private static Properties sapOneClickProperties = new Properties();
	private static Properties sapOneClickPropertiesU2R = new Properties();
	public static Map<String, String> sapClientNames=new HashMap<>();
	public static Map<String, String> sapPlatformInfo=new HashMap<>();
	private static Properties hcsProperties = new Properties(); //HCS Extraction properties
	private static Properties user2SodProperties = new Properties(); //SAP User to Sod properties

	public static Map<String, Object> cache = new HashMap<>();
	public static Properties platformEmails = new Properties();
	private static  Map<String, SapMitiCntrlModel> sapMitiCntrlMap = new HashMap<>();
	private static  Map<String, SapPlatformReviwerMdl> sapReviewersDataMap = new HashMap<>();
	private static  Map<String, String> mercuryReviewersDataMap = new HashMap<>();



	//USER CACHE METHODS
	public static UserSearchModel getUser(String userId) {
		UserSearchModel usrSrch=null;
		if(USER_MAP.containsKey(userId.toUpperCase())) {
			usrSrch = USER_MAP.get(userId.toUpperCase());
		}
		return usrSrch;
	}

	public static void setUser(String userId, UserSearchModel usrSrch) {
		USER_MAP.put(userId.toUpperCase(),usrSrch);
	}

	public static void clearUserData() {
		synchronized (USER_MAP) {
			USER_MAP.clear();
		}
	}
	//END


	public static void setCache(String id, Object obj) {
		cache.put(id, obj);
	}

	public static Map<String, SystemCodeModel> getSYSTEMCODEMAP() {
		return SYSTEMCODEMAP;
	}

	public static void setSYSTEMCODEMAP(Map<String, SystemCodeModel> sYSTEMCODEMAP) {
		SYSTEMCODEMAP = sYSTEMCODEMAP;
	}

	public static String getSystemCode(String role) {
		String code= null;
		if(SYSTEMCODEMAP != null && SYSTEMCODEMAP.containsKey(role)) {
			code = SYSTEMCODEMAP.get(role).getSodCode();
		}
		return code;
	}

	public static Object getCache(String id) {
		Object retObj = null;
		if(cache.containsKey(id)) {
			retObj =  cache.get(id);
		}
		return retObj;
	}


	public static boolean isEmpty(String string) {
	    return string == null || string.length() == 0;
	}

	public static int strToNum(String string) {
	    int retVal = 0;
		try {
			retVal = Integer.parseInt(string);
		} catch (Exception e) {
			log.error("Error converting String("+string+" into Number");
		}
		return retVal;
	}

/**
 * Method  : Utility.java.frmStrToDt()
 *		   :<b>@param dt
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Feb 18, 2020 4:18:49 PM
 * Purpose : format String : yyyy-MM-dd to Date
 * @return : Date
 */
	public static Date frmStrToDt(String dt) {
		Date addDate = null;
		try {
			addDate = formFmt.parse(dt);
		} catch (Exception e) {
			System.out.println("Exception Parsing Date String : "+dt+"\nMsg:"+e.getMessage());
			e.printStackTrace();
		}
		return addDate;
	}

	public static Date fullStrToDt(String dt) {
		Date addDate = null;
		//String dt = "2022-06-24T19:17:55.4630000Z";
		try {
			addDate = iamFormat.parse(dt);

		} catch (Exception e) {
			System.out.println("Exception Parsing Date String : "+dt+"\nMsg:"+e.getMessage());
			addDate = new Date();
		}
		return addDate;
	}


	public static Date ldapStrToDtUTCEST(String dt) {
		Date addDate = new Date();
		//String dt = "20220214200450.0Z"; UTC Time
		try {
			adFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			addDate = adFormat.parse(dt);
		} catch (Exception e) {
			System.out.println("Exception Parsing Date String : "+dt+"\nMsg:"+e.getMessage());
		}
		return addDate;
	}


	public static Date strToDt(String dt) {
		Date addDate = null;
		try {
			addDate = formatter.parse(dt);
		} catch (Exception e) {
			System.out.println("Exception Parsing Date String : "+dt+"\nMsg:"+e.getMessage());
			e.printStackTrace();
			addDate=new Date();
		}
		return addDate;
	}

	public static Date strToDt(String dt, String msg) {
		 Date addDate = null;
		 if(dt!= null) {
			 dt = dt.trim();
		 }
		 try {
			 addDate = formatter.parse(dt);
		} catch (Exception e) {
			System.out.println(msg);
			System.out.println("Exception Parsing Date :"+e.getMessage());
			e.printStackTrace();
		}
		return addDate;
	 }

	public static String fmtMMDDYYYY(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dtFmt.format(date);
	}


	public static Date fmtStrToDate(String dtStr) {
		Date dt=null;
		if(dtStr != null) {
			try {
				dt = dtFmt.parse(dtStr);
			} catch (Exception e) {
				log.error("Exception Parsing Date ("+dtStr+") :"+e.getMessage());
				e.printStackTrace();
			}
		}
		return dt;
	}


	public static String fmtMMDDYYYYTime(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dtFmtTime.format(date);
	}

	public static Date fmtCsmStr2Dt(String dt) {
		Date addDate = null;
		 if(dt!= null) {
			 dt = dt.trim();
		 }
		 try {
			 addDate = csmFormat.parse(dt);
		} catch (Exception e) {
			log.error("Exception Parsing Date :"+e.getMessage(), e);
		}
		return addDate;
	}


	public static String fmtCsmDt2Str(Date dt) {
		String addDate = "";
		if(dt == null) {
			 dt = new Date();
		 }
		 return csmFormat.format(dt);
	}





	public static String fmtMDY(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dtFmtMDY.format(date);
	}

	public static String fmtYMD(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dtFmtYMD.format(date);
	}

	public static Date fmtYMDStr(String dt) {
		Date addDate = null;
		try {
			addDate = dtFmtYMD.parse(dt);
		} catch (Exception e) {
			System.out.println("Exception Parsing Date String : "+dt+"\nMsg:"+e.getMessage());
			e.printStackTrace();
		}
		return addDate;
	}



	public static String fmtddMonYYYY(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dMonYear.format(date);
	}



	public static String esDtToUsFormat(Date date) {
		final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

		inputFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		String convertedDate = null;
		try {
			convertedDate = inputFormat.format(date);
		} catch (final Exception e) {
			System.out.println("Error parsing the es date");
		}
		return convertedDate;
	}





	public static int substractMonth(int currMon, int subtractor) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		if(currMon > 0) {
			cal.set(Calendar.MONTH, (currMon-1));
		}

		if(subtractor > 0) {
			cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) - subtractor));
		}
		return (cal.get(Calendar.MONTH)+1);
	}

	public static String backDate3M(int currMon, int currYear) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		if(currMon > 0) {
			cal.set(Calendar.MONTH, (currMon-1));//Setting the value received from Front end...Months 0..11
		}
		if(currYear > 0) {
			cal.set(Calendar.YEAR, currYear);
		}
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) - 3));//3 Months Back date
		return dtFmt.format(cal.getTime());
	}

	public static String backDate6M(int currMon, int currYear) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		if(currMon > 0) {
			cal.set(Calendar.MONTH, (currMon-1));//Setting the value received from Front end...Months 0..11
		}
		if(currYear > 0) {
			cal.set(Calendar.YEAR, currYear);
		}
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) - 6));//6 Months Back date
		return dtFmt.format(cal.getTime());
	}

	public static String backDate1Yrs(int currMon, int currYear) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		if(currMon > 0) {
			cal.set(Calendar.MONTH, (currMon-1));//Setting the value received from Front end...Months 0..11
		}
		if(currYear > 0) {
			cal.set(Calendar.YEAR, (currYear - 1));
		}
		//cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) - 6));//6 Months Back date
		return dtFmt.format(cal.getTime());
	}


	private static void populateRoles(){
		ROLES = new HashMap<>();
		ROLES.put("CHANGECONTROL", "CHANGE_CONTROL");
		ROLES.put("DBA", "DBA");
		ROLES.put("DEVELOPER", "DEVELOPER");
		ROLES.put("SUPERUSER", "SUPERUSER");
		ROLES.put("UNLIMITED", "UNLIMITED");
	}

	public static String getRole(String key) {
		if(null == ROLES || ROLES.isEmpty()) {
			populateRoles();
		}
		return ROLES.get(key);
	}



	public static List<KeyValPair> getSearchByList(){
		List<KeyValPair> types = new ArrayList<>();
		KeyValPair typ = new KeyValPair(1, "WWID");
		types.add(typ);
		typ = new KeyValPair(2, "NTID/UserId");
		types.add(typ);
		typ = new KeyValPair(3, "Last Name");
		types.add(typ);
		typ = new KeyValPair(4, "First Name");
		types.add(typ);
		typ = new KeyValPair(5, "TKT Number");
		types.add(typ);

		return types;
	}

	public static List<KeyValPair> getLogParamList(){
		List<KeyValPair> types = new ArrayList<>();
		KeyValPair typ = new KeyValPair(1, "Yes");
		types.add(typ);
		typ = new KeyValPair(2, "No");
		types.add(typ);
		return types;
	}

	public static List<KeyValPair> getMonthList(){
		List<KeyValPair> months = new ArrayList<>();
		KeyValPair mon = new KeyValPair(1, "Janaury");
		months.add(mon);
		mon = new KeyValPair(2, "February");
		months.add(mon);
		mon = new KeyValPair(3, "March");
		months.add(mon);
		mon = new KeyValPair(4, "April");
		months.add(mon);
		mon = new KeyValPair(5, "May");
		months.add(mon);
		mon = new KeyValPair(6, "June");
		months.add(mon);
		mon = new KeyValPair(7, "July");
		months.add(mon);
		mon = new KeyValPair(8, "August");
		months.add(mon);
		mon = new KeyValPair(9, "September");
		months.add(mon);
		mon = new KeyValPair(10, "October");
		months.add(mon);
		mon = new KeyValPair(11, "November");
		months.add(mon);
		mon = new KeyValPair(12, "December");
		months.add(mon);
		return months;
	}


	public static List<KeyValPair> getYearList(){
		List<KeyValPair> years = new ArrayList<>();
		for(int i=2015; i<2030;i++){
			KeyValPair year = new KeyValPair(i, i+"");
			years.add(year);
		}
		return years;
	}

	public static List<KeyValPair> getIdParams(){
		List<KeyValPair> ids = new ArrayList<>();
		KeyValPair id = new KeyValPair(1, "WWID");
		ids.add(id);
		id = new KeyValPair(2, "User ID");
		ids.add(id);
		return ids;
	}

	public static List<KeyValPair> getRoleTyp(){
		List<KeyValPair> ids = new ArrayList<>();
		KeyValPair id = new KeyValPair(1, "Technical");
		ids.add(id);
		id = new KeyValPair(2, "User Friendly");
		ids.add(id);
		return ids;
	}

	public static List<KeyValPair> getJDAEnvironment(){
		List<KeyValPair> ids = new ArrayList<>();
		KeyValPair id = new KeyValPair(1, "Development");
		ids.add(id);
		id = new KeyValPair(2, "Quality");
		ids.add(id);
		id = new KeyValPair(3, "PreQuality");
		ids.add(id);
		id = new KeyValPair(4, "Production");
		ids.add(id);
		return ids;
	}

	public static Workbook loadFile(String path){
		Workbook dataFile = null;
		try {
			File f = new File(path);
			System.out.println("Reading File : "+f.getName());
			dataFile = new XSSFWorkbook(f);
		} catch (Exception e) {
			System.out.println("Error Loading file :"+path+" MSG:"+e.getMessage());
			e.printStackTrace();
		}
		return dataFile;
	}

	public static String saveFile(MultipartFile file) throws IOException{
		byte[] bytes = file.getBytes();
		String fileNm = file.getOriginalFilename();
		if(fileNm.indexOf("\\") > 0) {
			fileNm = fileNm.substring(fileNm.lastIndexOf("\\")+1);
		}
		Path path;
		String serverEnv = Utility.getServerProp("ENVIRONMENT");
		if("PRODUCTION".equals(serverEnv)) {
			File currDir = new File("");
			String pathAbs = currDir.getAbsolutePath();
			path = Paths.get(pathAbs + "/" + fileNm);
		}else {
			path = Paths.get(Constants.UPLOAD_DIR + fileNm);
		}
		//fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
		//if(!path.toFile().exists()) {
			Files.write(path, bytes);
		//}else {
		//	log.debug("File :"+path.getFileName()+" ... is Present");
		//}

		return path.toString();
	}

	public static String writeLogData(StringBuilder data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 writer.writeNext(new String[]{ data.toString()});
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing Log Data: "+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	public static String getCellValue(Cell cell) {
	     String val = "";
	     if(cell == null) {
	    	 val = "";
	     }else {
	    	 if(cell.getCellType().equals(CellType.BOOLEAN)) {
		    	 val = cell.getBooleanCellValue()+"";
		     }else
		     if(cell.getCellType().equals(CellType.STRING)) {
		    	 val = cell.getRichStringCellValue().getString();
			 }else
			 if(cell.getCellType().equals(CellType.NUMERIC)) {
				 if (DateUtil.isCellDateFormatted(cell)) {
	                 val = cell.getDateCellValue()+"";
	             } else {
	            	 val = NumberToTextConverter.toText(cell.getNumericCellValue());
	            	 //val = cell.getNumericCellValue()+"";
	             }
			 }else
			 if(cell.getCellType().equals(CellType.FORMULA)) {
			   	 val =  cell.getCellFormula()+"";
			 }else
			 if(cell.getCellType().equals(CellType.BLANK)) {
			   	 val =  "";
			 }
	     }
	     if(null != val) {
	    	 val = val.trim();
	     }

		 return val;
	 }


	public static String asciiToHex(String asciiValue)
	 {
	     char[] chars = asciiValue.toCharArray();
	     StringBuffer hex = new StringBuffer();
	     for (char element : chars) {
	         hex.append(Integer.toHexString(element));
	     }
	     return hex.toString();
	 }
	public static String hexToASCII(String hexValue)
	 {
	     StringBuilder output = new StringBuilder("");
	     for (int i = 0; i < hexValue.length(); i += 2) {
	         String str = hexValue.substring(i, i + 2);
	         output.append((char) Integer.parseInt(str, 16));
	     }
	     return output.toString();
	 }


		public static List<MemRevieModel> updateTicketNumber(List<MemRevieModel>ngsDataLst, Map<String, String>tktDetails){
		List<MemRevieModel> result = new ArrayList<>();
		int count = 1;
		String keyStr = "";
		String shrtNm = "";
		String matchRl = "";
		StringBuilder sb = new StringBuilder(); //Error Data
		sb.append("\n");
		sb.append("ERRORS: RECORDS NOT FOUND \n");
		sb.append("--START---------------------------------------------------------------- \n");
		for(MemRevieModel ndata: ngsDataLst) {
			shrtNm  = ndata.getGrpShrtNm().trim().toUpperCase();
			keyStr = shrtNm+"~"+ndata.getWwid();
			if(tktDetails.containsKey(keyStr)) {
				String val = tktDetails.get(keyStr);
				ndata.setRqcTkt(val);
			}else {
				matchRl = RoleConstants.getRole(shrtNm);  //Getting RoleNames from Constants for Matching Roles
				if(null != matchRl) {
					matchRl = matchRl.trim();
				}
				if(!("".equals(matchRl))) { //Mapping Roles
					keyStr = matchRl+"~"+ndata.getWwid();
					if(tktDetails.containsKey(keyStr)) {
						String val = tktDetails.get(keyStr);
						ndata.setRqcTkt(val);
					}else {
						sb.append(count+". Key:"+keyStr+" Name:"+ndata.getFullName()+" Date added: "+dtFmt.format(ndata.getDtAdded())+"\n");
						count++;
					}
				}else {
					sb.append(count+". Key:"+keyStr+" Name:"+ndata.getFullName()+" Date added: "+dtFmt.format(ndata.getDtAdded())+"\n");
					count++;
				}
			}
			result.add(ndata);

			//Re-initialize KEY's to BLANK
			shrtNm  = "";
			matchRl = "";
			keyStr  = "";
		}
		sb.append("--END------------------------------------------------------------------\n");
		System.out.println(sb.toString());
		return result;
	 }


	private static void populatePosRoles(){
		POSROLES = new HashMap<>();
		List<PosRoles> rlList = new ArrayList<>();
		//19391
		PosRoles rl1 = new PosRoles(1, "FINANCE", "Finance");
		PosRoles rl2 = new PosRoles(2, "DELIVER", "Deliver");
		PosRoles rl3 = new PosRoles(3, "GRC (Governance Risk & Compliance)", "Governance Risk & Compliance");

		rlList = new ArrayList<>();
		rlList.add(rl1);
		rlList.add(rl2);
		rlList.add(rl3);
		POSROLES.put(19391, rlList);

		//19394
		PosRoles rl4 = new PosRoles(4,"IT (Information Technology)", "Information Technology");
		PosRoles rl5 = new PosRoles(5, "MDM (Master Data Management)","Master Data Management ");


		rlList = new ArrayList<>();
		rlList.add(rl4);
		rlList.add(rl5);

		POSROLES.put(19394, rlList);
	}


	public static List<PosRoles> getPosRole(int appId) {
		if(null == POSROLES || POSROLES.isEmpty()) {
			populatePosRoles();
		}
		return POSROLES.get(appId);
	}


	public static List<SrcSysMemRoleModel> checkTicketNumber(List<SrcSysMemRoleModel>dataLst, Map<String, String>tktDetails){
		List<SrcSysMemRoleModel> result = new ArrayList<>();
		int count = 1;
		String keyStr = "";
		String shrtNm = "";
		String matchRl = "";
		StringBuilder sb = new StringBuilder(); //Error Data
		sb.append("\n");
		sb.append("ERRORS: RECORDS NOT FOUND \n");
		sb.append("--START---------------------------------------------------------------- \n");
		for(SrcSysMemRoleModel ndata: dataLst) {
			shrtNm  = ndata.getApplRole();
			shrtNm = (shrtNm != null)? shrtNm.trim().toUpperCase() : "" ;
			//Getting RoleNames from Constants for Matching Roles
			matchRl = RoleConstants.getRole(shrtNm);
			if(!("".equals(matchRl))) { //Mapping Roles
				keyStr = matchRl;
			}else {
				keyStr = shrtNm;
			}
			keyStr = keyStr+"~"+ndata.getWwid();

			if(tktDetails.containsKey(keyStr)) {
				String val = tktDetails.get(keyStr);
				ndata.setRqcTkt(val);
			}else {
				sb.append(count+". Key:"+keyStr+" Name:"+ndata.getFirstNm()+", "+ndata.getLastNm()+"\n");
				count++;
			}
			result.add(ndata);

			//Re-initialize KEY's to BLANK
			shrtNm  = "";
			matchRl = "";
			keyStr  = "";
		}
		sb.append("--END------------------------------------------------------------------\n");
		System.out.println(sb.toString());
		return result;
	 }


	public static List<String> getSourceSystems(){
		String[] sysArray = {"CARS", "CARSMA", "CCPS", "CCRA", "CMW", "CORE", "Crossroads", "DBROLE", "EMSNEXTGEN", "FALCON", "FOM", "FTCC", "GPS", "ICS", "INTERACT", "JJ340B", "MDM","PVCS","RMSJAPAN", "SAP", "TM", "WILDCAT", "WMS", "WMSSDC"};
		return Arrays.asList(sysArray);
	}

	public static void addUserActCache(List<UserActivityModel> userdata) {
		if(userdata != null && !userdata.isEmpty()) {
			for(UserActivityModel user: userdata) {
				if(USERACTDATA.containsKey(user.getUserId())) {
					List<UserActivityModel> extData = USERACTDATA.get(user.getUserId());
					extData.add(user);
					USERACTDATA.put(user.getUserId(), extData);
				}else {
					List<UserActivityModel> newData = new ArrayList<>();
					newData.add(user);
					USERACTDATA.put(user.getUserId(), newData);
				}
			}
		}
	}

	public static List<UserActivityModel> getUserActCache(String userId){
		List<UserActivityModel> extData = null;
		if(USERACTDATA.containsKey(userId)) {
			extData = USERACTDATA.get(userId);
		}
		return extData;
	}

	public static boolean clearUserActCache(){
		boolean clr = false;
		if(USERACTDATA.size() >0) {
			synchronized (USERACTDATA) {
				USERACTDATA.clear();
				clr=true;
			}
		}
		return clr;
	}


	public static List<String>getSystemNameList(){
		if(SYSTEM_NAME.isEmpty()) {
			for(SystemCodeModel sys: SYSTEMCODEMAP.values()) {
				String sysCd = sys.getSrcSystem();
				if(!SYSTEM_NAME.contains(sysCd)) {
					SYSTEM_NAME.add(sysCd);
				}
			}
		}
		return SYSTEM_NAME;
	}

	public static List<SystemCodeModel>getSystemCodeList(String srcSys){
		List<SystemCodeModel> sysLst = new ArrayList<>();
		for(SystemCodeModel sys: SYSTEMCODEMAP.values()) {
			if("0".equals(srcSys)) {
				sysLst.add(sys);
			}else
				if(srcSys.equals(sys.getSrcSystem()))
			{
				sysLst.add(sys);
			}
		}

		Collections.sort(sysLst);
		return sysLst;
	}

	public static List<KeyValPair> getStatusParams(){
		List<KeyValPair> ids = new ArrayList<>();
		KeyValPair id = new KeyValPair(1, "ALL");
		ids.add(id);
		id = new KeyValPair(2, "MGR Approved");
		ids.add(id);
		return ids;
	}


	public static Set<String> getAppList(){
		if(RQC_APP_NAMES.isEmpty()) {
			intiRQCAppNames();
		}

		return RQC_APP_NAMES.keySet();
	}

	public static List<Integer> getSubAppIds(String app){
		List<Integer> subApp = new ArrayList<>();
		if(null != app && app.length() > 0 ) {
			if(RQC_APP_NAMES.isEmpty()) {
				intiRQCAppNames();
			}
			if(RQC_APP_NAMES.containsKey(app)) {
				subApp = RQC_APP_NAMES.get(app);
			}
		}
		return subApp;
	}

	//Method will be used for JavaScript Variables
	public static String addSingleQuote(String str, String delimiter) {
		String finalStr="";
		String[] tempData = str.split(delimiter);
		if(tempData.length == 1) {
			finalStr="\""+tempData[0]+"\"";
		}else if(tempData.length > 1) {
			for(String nstr:tempData) {
				if(finalStr.length() == 0) {
					finalStr+="\""+nstr+"\"";
				}else {
					finalStr+=",\""+nstr+"\"";
				}
			}
		}
		return finalStr;
	}

	private static void intiRQCAppNames() {
		List<Integer> sapList 		= Arrays.asList(305,409,349,352,353,354,355,356,359,360,361,367,428,471,526,534,535,536,537,552,553,554,555,556,557,558);
		List<Integer> wmsSdcList 	= Arrays.asList(539,540,541,542,543,544);
		List<Integer> wmsMlcList 	= Arrays.asList(467,431,432,433,434,308);
		List<Integer> oracleList 	= Arrays.asList(545,532,527,528,518,519,520,521,522,523,524,525,510,511,512,514,515,516,10);
		List<Integer> gpsList 		= Arrays.asList(311,386,387,388);
		List<Integer> ccraList 		= Arrays.asList(357,358,411,412,435,468);
		List<Integer> mdmList 		= Arrays.asList(322,323,324,325);
		List<Integer> informticList	= Arrays.asList(436,437,438,321);
		List<Integer> tmList 		= Arrays.asList(484,486,488,513);
		List<Integer> rmsJapanList 	= Arrays.asList(529,530,531);
		List<Integer> icsList 		= Arrays.asList(440,441,442,443,444,445,446,452,457,459,460,461,462,463,465);
		List<Integer> coreList 		= Arrays.asList(562,546,547,551);
		List<Integer> fomList 		= Arrays.asList(485,483,487,517);
		List<Integer> ftccList 		= Arrays.asList(380,389,439);
		List<Integer> br2340List	= Arrays.asList(533,538);
		List<Integer> emsNxtGenList = Arrays.asList(559,560);
		List<Integer> falconList	= Arrays.asList(548,550);
		List<Integer> citrixCList	= Arrays.asList(1);
		//List<Integer> imptCList 	= Arrays.asList(2);
		//List<Integer> win2000List 	= Arrays.asList(8);
		List<Integer> otherAppList 	= Arrays.asList(9);
		//List<Integer> winAccExtList = Arrays.asList(326);
		List<Integer> interactList	= Arrays.asList(307);
		List<Integer> hpeCMList 	= Arrays.asList(563);
		List<Integer> pvcsList 		= Arrays.asList(365);
		//List<Integer> aclSfList 	= Arrays.asList(368);
		//List<Integer> portalList 	= Arrays.asList(410);
		//List<Integer> ethiconList 		= Arrays.asList(416);
		//List<Integer> linyxList 		= Arrays.asList(427);

		RQC_APP_NAMES.put("SAP", sapList);
		RQC_APP_NAMES.put("WMS-SDC", wmsSdcList);
		RQC_APP_NAMES.put("WMS-MLC", wmsMlcList);
		RQC_APP_NAMES.put("ORACLE", oracleList);
		RQC_APP_NAMES.put("GPS", gpsList);
		RQC_APP_NAMES.put("CCRA", ccraList);
		RQC_APP_NAMES.put("MDM", mdmList);
		RQC_APP_NAMES.put("INFORMATICA", informticList);
		RQC_APP_NAMES.put("TM", tmList);
		RQC_APP_NAMES.put("RMSJAPAN", rmsJapanList);
		RQC_APP_NAMES.put("ICS", icsList);
		RQC_APP_NAMES.put("CORE", coreList);
		RQC_APP_NAMES.put("FOM", fomList);
		RQC_APP_NAMES.put("FTCC", ftccList);
		RQC_APP_NAMES.put("340BR2", br2340List);
		RQC_APP_NAMES.put("EMS NextGen", emsNxtGenList);
		RQC_APP_NAMES.put("FALCON", falconList);
		RQC_APP_NAMES.put("CITRIX CLIENT", citrixCList);
		//RQC_APP_NAMES.put("IMPROMPTU CLIENT", imptCList);
		//RQC_APP_NAMES.put("WINDOWS 2000", win2000List);
		RQC_APP_NAMES.put("OTHER APPLICATION", otherAppList);
		//RQC_APP_NAMES.put("WINDOWS ACC EXT", winAccExtList);
		RQC_APP_NAMES.put("INTERACT_RO", interactList);
		RQC_APP_NAMES.put("HPE Content Mgr", hpeCMList);
		RQC_APP_NAMES.put("PVCS", pvcsList);
		//RQC_APP_NAMES.put("ACL Software", aclSfList);
		//RQC_APP_NAMES.put("Portal QA", portalList);
		//RQC_APP_NAMES.put("ETHICON ENDO", ethiconList);
		//RQC_APP_NAMES.put("LINYX", linyxList);
	}



public static String getSapClientName(String client) {
	if(sapClientNames == null || sapClientNames.isEmpty()) {
		loadSapClientDetails();
	}
	String clientNm="";
	if(sapClientNames.containsKey(client)) {
		clientNm = sapClientNames.get(client);
	}else {
		clientNm = client;
	}
	return clientNm;
}


public static String getSapPlatformInfo(String platform) {
	if(sapPlatformInfo == null || sapPlatformInfo.isEmpty()) {
		loadPatformInfo();
	}
	String info="";
	if(sapPlatformInfo.containsKey(platform)) {
		info = sapPlatformInfo.get(platform);
	}else {
		info = platform;
	}
	return info;
}




private static void loadSapClientDetails() {
	sapClientNames.clear();
	//PROD ATLAS
	sapClientNames.put("ECCProductionRPVCLNT100", "ECC Production RPVCLNT100");
	sapClientNames.put("APOProductionAPVCLNT100", "APO  Production APVCLNT100");
	sapClientNames.put("BIProductionBPVCLNT100", "BI  Production BPVCLNT100");
	//BIOSENSE
	sapClientNames.put("BWIILCLNT400", "ECC Production BWIILCLNT400");
	//USROTC
	sapClientNames.put("ECCProductionMP2CLNT100", "ECC Production MP2CLNT100");
	sapClientNames.put("CRMProductionMP8CLNT100", "CRM Production MP8CLNT100");


	sapClientNames.put("ECCProductionMP2CLNT000", "ECC Production MP2CLNT000");
	sapClientNames.put("CRMProductionMP8CLNT000", "CRM Production MP8CLNT000");

	//CONCOURSE
	sapClientNames.put("ATTProductionP23CLNT100", "ATT Production P23CLNT100");
	sapClientNames.put("ATTProductionP24CLNT100", "ATT Production P24CLNT100");
	//CROSSROAD
	sapClientNames.put("ECCProductionRPUCLNT100", "ECC Production RPUCLNT100");
	sapClientNames.put("ECCProductionRPUCLNT000", "ECC Production RPUCLNT000");
	//ANSPACH
	sapClientNames.put("ECCProductionR3PCLNT700", "ECC  Production R3PCLNT700");
	//BTBGLOBAL
	sapClientNames.put("SCMProductionAPUCLNT300", "SCM  Production APUCLNT300");
	sapClientNames.put("BWonHANAProductionB3GCLNT550", "BW on HANA  Production B3GCLNT550");
	sapClientNames.put("BWforAPOProductionBPUCLNT400", "BW for APO  Production BPUCLNT400");
	sapClientNames.put("GTSProductionNP2CLNT650", "GTS  Production NP2CLNT650");
	sapClientNames.put("SLTProductionNP3CLNT220", "SLT  Production NP3CLNT220");
	sapClientNames.put("MDGProductionP53CLNT750", "MDG  Production P53CLNT750");
	sapClientNames.put("FSCMProductionRP3CLNT600", "FSCM  Production RP3CLNT600");
	sapClientNames.put("PIProductionXPUCLNT200", "PI  Production XPUCLNT200");


	//Tech Clients
	sapClientNames.put("SCMProductionAPUCLNT000", "SCM Production APUCLNT000");
	sapClientNames.put("MDGProductionP53CLNT000", "MDG Production P53CLNT000");
	sapClientNames.put("FSCMProductionRP3CLNT000", "FSCM Production RP3CLNT000");
	sapClientNames.put("BWonHANAB3GCLNT000", "BW on HANA B3GCLNT000");
	sapClientNames.put("BWforAPOBPUCLNT000", "BW for APO BPUCLNT000");
	sapClientNames.put("GTSProductionNP2CLNT000", "GTS Production NP2CLNT000");
	sapClientNames.put("SLTProductionNP3CLNT000", "SLTProductionNP3CLNT000");
	sapClientNames.put("PIProductionXPUCLNT000", "PI Production XPUCLNT000");
	//BTB LERCAN
	sapClientNames.put("CRMProductionP51CLNT500", "CRM  Production P51CLNT500");
	sapClientNames.put("ECCProductionP50CLNT100", "ECC  Production P50CLNT100");
	sapClientNames.put("CRMProductionP51CLNT000", "CRM Production P51CLNT000");
	sapClientNames.put("ECCProductionP50CLNT000", "ECC Production P50CLNT000");
	//FUSION

	sapClientNames.put("ECCProductionPR1CLNT100", "ECC Production PR1CLNT100");
	sapClientNames.put("CRMProductionPC1CLNT100", "CRMP roduction PC1CLNT100");
	sapClientNames.put("BWProductionPB1CLNT100",  "BW Production PB1CLNT100");
	sapClientNames.put("ECCProductionPR1CLNT000", "ECC Production PR1CLNT000");
	sapClientNames.put("CRMProductionPC1CLNT000", "CRMP roduction PC1CLNT000");
	sapClientNames.put("BWProductionPB1CLNT000",  "BW Production PB1CLNT000");

	//GLOBAL SOLMAN
	sapClientNames.put("SolManProductionMPCCLNT230", "SolMan Production MPCCLNT230");
	sapClientNames.put("SolManProductionMPCCLNT000", "SolMan Production MPCCLNT000");
	sapClientNames.put("ProductionTechnicalClients", "Production Technical Clients");

	//JJSV
	sapClientNames.put("ECCProductionPA2CLNT050", "ECC Production PA2CLNT050");
	sapClientNames.put("SCMProductionAPPCLNT050", "SCM Production APPCLNT050");
	sapClientNames.put("BWProductionBWPCLNT050", "BW Production BWPCLNT050");
	sapClientNames.put("ECCProductionPA2CLNT000", "ECC Production PA2CLNT000");
	sapClientNames.put("SCMProductionAPPCLNT000", "SCM Production APPCLNT000");
	sapClientNames.put("BWProductionBWPCLNT000", "BW Production BWPCLNT000");

	//LYNX
	sapClientNames.put("ECCProductionMP1CLNT010", "ECC  Production MP1CLNT010");
	sapClientNames.put("BIProductionGP5CLNT010", "BI  Production GP5CLNT010");
	sapClientNames.put("ECCProductionFP3CLNT010", "ECC  Production FP3CLNT010");
	sapClientNames.put("BIProductionFP5CLNT010", "BI  Production FP5CLNT010");
	sapClientNames.put("ECCProductionMP1CLNT000", "ECC Production MP1CLNT000");
	sapClientNames.put("ECCProductionFP3CLNT000", "ECC Production FP3CLNT000");
	sapClientNames.put("BIProductionFP5CLNT000", "BI Production FP5CLNT000");
	sapClientNames.put("BIProductionGP5CLNT000", "BI Production GP5CLNT000");
	//MERCURY
	sapClientNames.put("SCMProductionSPNCLNT400", "SCM  Production SPNCLNT400");
	sapClientNames.put("ECCProductionRPNCLNT120", "ECC  Production RPNCLNT120");
	sapClientNames.put("BWProductionBPNCLNT300", "BW  Production BPNCLNT300");
	sapClientNames.put("PIProductionXPNCLNT200", "PI  Production XPNCLNT200");

	sapClientNames.put("SCMProductionSPNCLNT000", "SCM Production SPNCLNT000");
	sapClientNames.put("ECCProductionRPNCLNT000", "ECC Production RPNCLNT000");
	sapClientNames.put("BWProductionBPNCLNT000", "BW Production BPNCLNT000");
	sapClientNames.put("PIProductionXPNCLNT000", "PI Production XPNCLNT000");
	//MITEK
	sapClientNames.put("ECCProductionRPOCLNT777", "ECC  Production RPOCLNT777");
	//OURSOURCE
	sapClientNames.put("ECCProductionPJ1CLNT280", "ECC  Production PJ1CLNT280");
	sapClientNames.put("NGWProductionPJ2CLNT280", "NGW  Production PJ2CLNT280");
	sapClientNames.put("BIProductionPJ5CLNT280", "BI  Production PJ5CLNT280");
	//LATAMPROJECTONE
	sapClientNames.put("SCMProductionPAPCLNT520", "SCM  Production PAPCLNT520");
	sapClientNames.put("BWProductionPBWCLNT620", "BW  Production PBWCLNT620");
	sapClientNames.put("ECCProductionPLACLNT120", "ECC  Production PLACLNT120");
	sapClientNames.put("ECCProductionPLACLNT000", "ECC Production PLACLNT000");
	sapClientNames.put("BWProductionPBWCLNT000", "BW Production PBWCLNT000");
	sapClientNames.put("SCMProductionPAPCLNT000", "SCM Production PAPCLNT000");

	//LATAM_BTBLATAM
	sapClientNames.put("CRMProductionCPGCLNT500", "CRM  Production CPGCLNT500");
	sapClientNames.put("ECCProductionRPGCLNT100", "ECC  Production RPGCLNT100");
	sapClientNames.put("NFEProductionXP2CLNT300", "NFE  Production XP2CLNT300");
	sapClientNames.put("ECCProductionRPGCLNT000", "ECC Production RPGCLNT000");
	sapClientNames.put("CRMProductionCPGCLNT000", "CRM Production CPGCLNT000");
	sapClientNames.put("NFEProductionXP2CLNT000", "NFE Production XP2CLNT000");

	//BTBJAPAN
	sapClientNames.put("ECCProductionP60CLNT100", "ECC  Production P60CLNT100");
	sapClientNames.put("ECCProductionP60CLNT000", "ECC Production P60CLNT000");
	//ConsumerAspac
	sapClientNames.put("SCMProductionAPWCLNT888", "SCM  Production APWCLNT888");
	sapClientNames.put("BIProductionPW1CLNT100", "BI  Production PW1CLNT100");
	sapClientNames.put("ECCProductionP00CLNT888", "ECC  Production P00CLNT888");

	sapClientNames.put("SCMProductionAPWCLNT000", "SCM Production APWCLNT000");
	sapClientNames.put("ECCProductionP00CLNT000", "ECCP roduction P00CLNT000");
	sapClientNames.put("BIProductionPW1CLNT000", "BI Production PW1CLNT000");
	//MARS
	sapClientNames.put("ECCProductionEJ1CLNT100", "ECC  Production EJ1CLNT100");
	sapClientNames.put("ECCProductionEJ1CLNT000", "ECC Production EJ1CLNT000");

	//Panda
	sapClientNames.put("BIProductionBP1CLNT600", "BI  Production BP1CLNT600");
	sapClientNames.put("ECCProductionEP1CLNT800", "ECC  Production EP1CLNT800");
	sapClientNames.put("PIProductionXP1CLNT800", "PI  Production XP1CLNT800");

	sapClientNames.put("ECCProductionEP1CLNT000", "ECC Production EP1CLNT000");
	sapClientNames.put("BIProductionBP1CLNT000", "BI Production BP1CLNT000");
	sapClientNames.put("PIProductionXP1CLNT000", "PI Production XP1CLNT000");
	//TAISHAN
	sapClientNames.put("ECCProductionRPDCLNT800", "ECC  Production RPDCLNT800");
	sapClientNames.put("ECCProductionRPDCLNT000", "ECC Production RPDCLNT000");

	//EUROPE2
	sapClientNames.put("APOProductionAPECLNT050", "APO  Production APECLNT050");
	sapClientNames.put("BIProductionBPECLNT050", "BI  Production BPECLNT050");
	sapClientNames.put("FSFProductionBPICLNT050", "FSF  Production BPICLNT050");
	sapClientNames.put("EWMProductionQPJCLNT050", "EWM  Production QPJCLNT050");
	sapClientNames.put("ECCProductionRPECLNT050", "ECC  Production RPECLNT050");

	sapClientNames.put("ECCProductionRPECLNT000", "ECC Production RPECLNT000");
	sapClientNames.put("APOProductionAPECLNT000", "APO Production APECLNT000");
	sapClientNames.put("BIProductionBPECLNT000", "BI Production BPECLNT000");
	sapClientNames.put("EWMProductionQPJCLNT000", "EWM Production QPJCLNT000");
	sapClientNames.put("FSFProductionBPICLNT000", "FSF Production BPICLNT000");
	sapClientNames.put("EWMProductionPJECLNT050", "EWM Production PJECLNT050");//Added 10/12/2022


	//Galaxy
	sapClientNames.put("BIProductionBPMCLNT172", "BI  Production BPMCLNT172");
	sapClientNames.put("ECCProductionRPMCLNT232", "ECC  Production RPMCLNT232");
	sapClientNames.put("ECCProductionRPMCLNT050", "ECC  Production RPMCLNT050");
	sapClientNames.put("BIProductionBPMCLNT000", "BI Production BPMCLNT000");
	sapClientNames.put("ECCProductionRPMCLNT000", "ECC Production RPMCLNT000");
	//GMED
	sapClientNames.put("EWMCourcellesProductionP28CLNT050", "EWM Courcelles  Production P28CLNT050");
	sapClientNames.put("EWMCourcellesProductionP28CLNT000", "EWM Courcelles Production P28CLNT000");
	//IML
	sapClientNames.put("BIProductionB3TCLNT050", "BI  Production B3TCLNT050");
	sapClientNames.put("BIProductionB4TCLNT050", "BI  Production B4TCLNT050");
	sapClientNames.put("BIProductionBPTCLNT050", "BI  Production BPTCLNT050");
	sapClientNames.put("ECCProductionR3TCLNT050", "ECC  Production R3TCLNT050");
	sapClientNames.put("ECCProductionR4TCLNT050", "ECC  Production R4TCLNT050");
	sapClientNames.put("ECCProductionRPTCLNT050", "ECC  Production RPTCLNT050");

	sapClientNames.put("BIProductionB3TCLNT000", "BI Production B3TCLNT000");
	sapClientNames.put("BIProductionB4TCLNT000", "BI Production B4TCLNT000");
	sapClientNames.put("BIProductionBPTCLNT000", "BI Production BPTCLNT000");
	sapClientNames.put("ECCProductionR3TCLNT000", "ECC Production R3TCLNT000");
	sapClientNames.put("ECCProductionR4TCLNT000", "ECC Production R4TCLNT000");
	sapClientNames.put("ECCProductionRPTCLNT000", "ECC Production RPTCLNT000");

	//SNC
	sapClientNames.put("SNCProductionQPECLNT050", "SNC  Production QPECLNT050");
	sapClientNames.put("SNCProductionQPECLNT000", "SNCProductionQPECLNT000");

	//STF
	sapClientNames.put("APOProductionAPCCLNT430", "APO  Production APCCLNT430");
	sapClientNames.put("BIProductionBPCCLNT330", "BI  Production BPCCLNT330");
	sapClientNames.put("CRMProductionCPCCLNT100", "CRM  Production CPCCLNT100");
	sapClientNames.put("MDGProductionOPCCLNT050", "MDG  Production OPCCLNT050");
	sapClientNames.put("NetweaverGatewayProductionP05CLNT050", "Netweaver Gateway  Production P05CLNT050");
	sapClientNames.put("ECCProductionRPCCLNT130", "ECC  Production RPCCLNT130");
	sapClientNames.put("PIProductionXPGCLNT050", "PI  Production XPGCLNT050");

	sapClientNames.put("APOProductionAPCCLNT000", "APO Production APCCLNT000");
	sapClientNames.put("BIProductionBPCCLNT000", "BI Production BPCCLNT000");
	sapClientNames.put("CRMProductionCPCCLNT000", "CRM Production CPCCLNT000");
	sapClientNames.put("MDGProductionOPCCLNT000", "MDG Production OPCCLNT000");
	sapClientNames.put("NetweaverGatewayProductionP05CLNT000", "Netweaver Gateway Production P05CLNT000");
	sapClientNames.put("ECCProductionRPCCLNT000", "ECC Production RPCCLNT000");
	sapClientNames.put("PIProductionXPGCLNT000", "PI Production XPGCLNT000");



	//SUSTAIN
	sapClientNames.put("BIProductionBPBCLNT050", "BI  Production BPBCLNT050");
	sapClientNames.put("ECCProductionRPBCLNT910", "ECC  Production RPBCLNT910");

	sapClientNames.put("BIProductionBPBCLNT000", "BI Production BPBCLNT000");
	sapClientNames.put("ECCProductionRPBCLNT000", "ECC Production RPBCLNT000");
	//SYMPHONY
	sapClientNames.put("ECCProductionP30CLNT200", "ECC  Production P30CLNT200");
	sapClientNames.put("ECCProductionP30CLNT000", "ECC Production P30CLNT000");

	//SYNTHES
	sapClientNames.put("GRCProductionACPCLNT001", "GRC  Production ACPCLNT001");
	sapClientNames.put("BIProductionBIPCLNT020", "BI  Production BIPCLNT020");
	sapClientNames.put("GTSProductionGTPCLNT001", "GTS  Production GTPCLNT001");
	sapClientNames.put("ECCProductionMBPCLNT600", "ECC  Production MBPCLNT600");
	sapClientNames.put("ECCProductionP01CLNT020", "ECC  Production P01CLNT020");
	sapClientNames.put("SOLMANProductionS01CLNT001", "SOLMAN  Production S01CLNT001");
	sapClientNames.put("ECCProductionMBPCLNT600", "ECC Production MBPCLNT600");

	sapClientNames.put("GRCProductionACPCLNT000", "GRC Production ACPCLNT000");
	sapClientNames.put("BIProductionBIPCLNT000", "BI Production BIPCLNT000");
	sapClientNames.put("GTSProductionGTPCLNT000", "GTS Production GTPCLNT000");
	sapClientNames.put("ECCProductionMBPCLNT000", "ECC Production MBPCLNT000");
	sapClientNames.put("ECCProductionP01CLNT000", "ECC Production P01CLNT000");
	sapClientNames.put("SOLMANProductionS01CLNT000", "SOLMAN Production S01CLNT000");

	//VDR
	sapClientNames.put("ECCProductionFRPCLNT382", "ECC  Production FRPCLNT382");
	sapClientNames.put("ECCProductionFRPCLNT000", "ECC Production FRPCLNT000");


	//JDE
	sapClientNames.put("JDEANIMAS", "JDE ANIMAS");
	sapClientNames.put("JDEBWI", "JDE BWI");
	sapClientNames.put("JDEDCF92", "JDE DCF92");
	sapClientNames.put("JDEDEPUYEMEA", "JDE DEPUY EMEA");
	sapClientNames.put("JDEDEPUYUS", "JDE DEPUY US");
	sapClientNames.put("JDEEES", "JDE EES");
	sapClientNames.put("JDEEMS", "JDE EMS");
	sapClientNames.put("JDEETHICON", "JDE ETHICON");
	sapClientNames.put("JDEGMED", "JDE GMED");
	sapClientNames.put("JDEMENTOR", "JDE MENTOR");

	sapClientNames.put("DSIBWI", "DSI BWI");
	sapClientNames.put("DSIEES", "DSI EES");
	sapClientNames.put("DSIETHICONUS", "DSI ETHICON US");
	sapClientNames.put("DSIGMED", "DSI GMED");
	sapClientNames.put("DSIMENTOR", "DSI MENTOR");
	sapClientNames.put("JDEPLATFORM", "JDE PLATFORM");

	//HANA
	sapClientNames.put("BTBBOBJBPG", "BTB BOBJ - BPG");

	sapClientNames.put("BTBHANAHPG", "BTB HANA - HPG");
	sapClientNames.put("FUSIONEmptyTenantDBPEA", "FUSION Empty Tenant DB - PEA");
	sapClientNames.put("FUSIONTenantDBPB1", "FUSION Tenant DB - PB1");
	sapClientNames.put("FUSIONSYSTEMDBPEA", "FUSION SYSTEM DB - PEA");
	sapClientNames.put("FUSIONEmptyTenantDBPEB", "FUSION  Empty Tenant DB - PEB");
	sapClientNames.put("FUSIONTenantDBPEC", "FUSION  Tenant DB - PEC");
	sapClientNames.put("FUSIONSYSTEMDBPEB", "FUSION  SYSTEM DB - PEB");

	sapClientNames.put("GALAXYHANA", "GALAXY HANA");
	sapClientNames.put("STFHANA", "STF HANA");

	sapClientNames.put("GALAXYHANASystemDB", "SystemDB@HPM");
	sapClientNames.put("GALAXYHANAHPM", "HPM@HPM");
	sapClientNames.put("GALAXYHANABPM", "BPM@HPM");
	sapClientNames.put("STFHANASystemDB", "SystemDB@HPC");
	sapClientNames.put("STFHANAHPC", "HPC@HPC");
	sapClientNames.put("STFHANABPC", "BPC@HPC");


	//sapClientNames.put("", "");
}

private static void loadPatformInfo() {
	//Missing CROSSROADS, Concourse,ENTERPRISEGRC,
	sapPlatformInfo.put("BIOSENSE",  "Access is granted to the BWIIL - SAP Production system application.");
	sapPlatformInfo.put("BTBBOBJ",  "Access has been granted in the BTB BOBJ-Production System");
	sapPlatformInfo.put("BTBHANAHPG",  "Access has been granted in the BTB HANA HPG-Production System");
	sapPlatformInfo.put("CONSUMERASPAC",  "Access is Granted in SAP CONSUMERASPAC system which is a Global Consumer product system for ASPAC region");
	sapPlatformInfo.put("FUSIONHANA",  "Access has been granted in the FUSION HANA-Production System");
	sapPlatformInfo.put("JDEBWI",  "Access is Granted in JDE BWI");
	sapPlatformInfo.put("JDEEES",  "Access is Granted in JDE EES");
	sapPlatformInfo.put("JDEETHICONUS",  "Access is Granted in JDE ETHICON US");
	sapPlatformInfo.put("JDEGMED",  "Access is Granted in JDE GMED");
	sapPlatformInfo.put("JDEMENTOR",  "Access is Granted in JDE MENTOR");
	sapPlatformInfo.put("JDESYNTHES",  "Access is Granted in JDE SYNTHES");
	sapPlatformInfo.put("DSIANIMAS",  "Access is Granted in DSI ANIMAS");
	sapPlatformInfo.put("JDEANIMAS",  "Access is Granted in JDE ANIMAS");
	sapPlatformInfo.put("DSIBWI",  "Access is Granted in DSI BWI");
	sapPlatformInfo.put("JDEDEPUYUS",  "Access is Granted in JDE DEPUY US");
	sapPlatformInfo.put("JDEDEPUYUK",  "Access is Granted in JDE DEPUY UK");
	sapPlatformInfo.put("JDEDEPUYEMEA",  "Access is Granted in JDE DEPUY EMEA");
	sapPlatformInfo.put("DSIEES",  "Access is Granted in DSI EES");
	sapPlatformInfo.put("JDEEMS",  "Access is Granted in JDE EMS");
	sapPlatformInfo.put("JDEEMSOW",  "Access is Granted in JDE EMS OW");
	sapPlatformInfo.put("DSIETHICONUS",  "Access is Granted in DSI ETHICON US");
	sapPlatformInfo.put("DSIGMED",  "Access is Granted in DSI GMED");
	sapPlatformInfo.put("JDEDCF92",  "Access is Granted in JDE DCF 92");
	sapPlatformInfo.put("DSIMENTOR",  "Access is Granted in DSI MENTOR");
	sapPlatformInfo.put("ANSPACH",  "Access is Granted in SAP ANSPACH which is the Global Medical Devices systems");
	sapPlatformInfo.put("ATLAS",  "Access is Granted in SAP Atlas which is the Global Pharma Supply chain systems");
	sapPlatformInfo.put("BTBGLOBAL",  "Access is Granted in SAP Back to Basics which is the Global Supply chain systems");
	sapPlatformInfo.put("BTBJAPAN",  "Access is Granted in SAP Back to Basics which is the Global Supply chain systems");
	sapPlatformInfo.put("BTBLATAM",  "Access is Granted in SAP Back to Basics which is the Global Supply chain systems");
	sapPlatformInfo.put("BTBLERCAN",  "Access is Granted in SAP Back to Basics which is the Global Supply chain systems");
	sapPlatformInfo.put("EUROPE2",  "Access is Granted in SAP Europe 2 which is the Global Pharma Supply chain systems");
	sapPlatformInfo.put("FUSION",  "Acess is Granted in SAP Fusion, which is the Global Consumer Systems of North America");
	sapPlatformInfo.put("GALAXY",  "Access is Granted in SAP GALAXY which is the Global Pharma Supply chain systems");
	sapPlatformInfo.put("GLOBALSOLMAN",  "Access is Granted in SAP GlobalSolman which is the Global Medical Devices systems");
	sapPlatformInfo.put("GMED",  "Access is Granted in SAP GMED which is the Global Pharma Supply chain system");
	sapPlatformInfo.put("ILM",  "Access is Granted in SAP ILM which is the Global Medical Devices systems");
	sapPlatformInfo.put("JJSV",  "Access is Granted in SAP JJSV which is the Global Consumer Supply chain systems");
	sapPlatformInfo.put("LATAMPROJECTONE",  "Access is Granted in SAP Latam Project One which is the Global Consumer Supply chain systems");
	sapPlatformInfo.put("LYNX",  "Access is Granted in SAP Lynx which is the Corporte Finance systems");
	sapPlatformInfo.put("MARS",  "Access is Granted in SAP MARS which is the Global Medical Device systems");
	sapPlatformInfo.put("MERCURY",  "Access is Granted in SAP Mercury which is the Global Consumer Supply chain systems");
	sapPlatformInfo.put("MITEK",  "Access is Granted in SAP Mitek which is the Medical Devices systems");
	sapPlatformInfo.put("OURSOURCE",  "Access is Granted in SAP OURSOURCE which is the Global Human Resource systems");
	sapPlatformInfo.put("PANDA",  "Access is Granted in SAP PANDA");
	sapPlatformInfo.put("STF",  "Access is Granted in SAP  STF which is the EMEA Consumer systems");
	sapPlatformInfo.put("SUSTAIN",  "Access is Granted in SAP Sustain which is the Global Pharma Supply chain systems");
	sapPlatformInfo.put("SYMPHONY",  "Access is Granted in SAP Symphony which is the Global Treasury system");
	sapPlatformInfo.put("SYNTHES",  "Access is Granted in SAP Synthes which is the Global Medical Devices systems");
	sapPlatformInfo.put("TAISHAN",  "Access is Granted in SAP TAISHAN");
	sapPlatformInfo.put("USROTC",  "Access is Granted in SAP USROTC which is the GlobalMedical Devices systems");
	sapPlatformInfo.put("VDR",  "Access is Granted in SAP VDR which is the Global Pharma Supply chain systems");


}






	public static List<String[]> getKeySetList(String[] keys, int chunkSize){
		List<String[]> lst = new ArrayList<>();
		int totalSize = keys.length;
		if(totalSize < chunkSize ){
		   chunkSize = totalSize;
		}
		int from = 0;
		int to = chunkSize;

		while(from < totalSize){
		    String[] partArray = Arrays.copyOfRange(keys, from, to);
		    lst.add(partArray);
		    from+= chunkSize;
		    to = from + chunkSize;
		    if(to > totalSize){
		        to = totalSize;
		    }
		}
		return lst;
	}


	public static void createDirectory(String dirName) {
		try {
			File dir = new File(dirName);
			if(!dir.exists()) {
				Path mydir = Paths.get(dir.getAbsolutePath());
				Path result = Files.createDirectory(dir.toPath()); //dir.mkdir();
				log.info("Directory create : "+result);
			}
		} catch (Exception e) {
			log.error("Error Creating Directory:"+e.getMessage(), e);
		}
	}

	public static String createZip(List<String> fileList, String zipFile) throws FileNotFoundException, IOException{
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
		for (String fileNm : fileList) {
			File rfile = new File(fileNm);
			if(rfile.isDirectory()){
				zipDirectory(rfile, rfile.getName(), zos);
			} else {
				zipFile(rfile, zos);
			}
		}
		zos.flush();
		zos.close();
		return zipFile;
	}


	private static void zipDirectory(File folder, String parentFolder, ZipOutputStream zos) throws FileNotFoundException, IOException {
		for (File file : folder.listFiles()){
			if(file.isDirectory()){
				zipDirectory(file, parentFolder + "/" + file.getName(), zos);
				continue;
			}
			zos.putNextEntry(new ZipEntry(parentFolder + "/" + file.getName()));
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
			long bytesRead = 0;
			byte[] bytesIn = new byte[BUFFER_SIZE];
			int read = 0;
			while ((read = bis.read(bytesIn)) != -1) {
				zos.write(bytesIn, 0, read);
				bytesRead += read;
			}
				zos.closeEntry();
		}
	}


	private static void zipFile(File file, ZipOutputStream zos) throws FileNotFoundException, IOException {
		zos.putNextEntry(new ZipEntry(file.getName()));
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
		long bytesRead = 0;
		byte[] bytesIn = new byte[BUFFER_SIZE];
		int read = 0;
		while((read = bis.read(bytesIn)) != -1){
			zos.write(bytesIn, 0, read);
			bytesRead += read;
		}
		zos.closeEntry();
	}


	public static List<String>loadProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(dbProperties.isEmpty()) {
			try {
				dbProperties = loadPropertiesFromFileSystem(Constants.dbFilePath);
			} catch (Exception e) {
				log.error("Error Loding properties file:"+e, e.getStackTrace());
			}
		}
		String data = (String)dbProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	 public static Properties loadPropertiesFromFileSystem(String dbFilePath) throws IOException {
		 InputStream input = null;
		 // initialize properties object which will hold properties
		 Properties prop = new Properties();
		 try {
		 // create an input stream pointing to the properties file
			 input = new FileInputStream(new File(dbFilePath));
			 // load properties from input stream into properties object
			 prop.load(input);
			 //log.info(prop.getProperty("SOD_EXTR"));
		 } catch (IOException e) {
			 e.printStackTrace();
		 }finally {
			 if (input != null) {
				 input.close();
			 }
		 }

		 return prop;
	 }



	 	/**
		 * Method  : Utility.java.loadCSIProperty()
		 *		   :<b>@param propId
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Dec 10, 2020 4:39:35 PM
		 * Purpose :Loading CSI Properties
		 * @return : List<String>
		 */
	public static List<String>loadCSIProperty(String propId){
			List<String> dataList = new ArrayList<>();
			if(csiProperties.isEmpty()) {
				try {
					csiProperties = loadPropertiesFromFileSystem(Constants.csiFilePath);
				} catch (Exception e) {
					log.error("Error Loding CSI properties file:"+e, e.getStackTrace());
				}
			}
			String data = (String)csiProperties.get(propId);
			if(data != null && data.length() > 0) {
				dataList = Arrays.asList(data.split(","));
			}
			return dataList;
	}

	public static List<String>loadHANAProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(hanaProperties.isEmpty()) {
			try {
				hanaProperties = loadPropertiesFromFileSystem(Constants.hanaFilePath);
			} catch (Exception e) {
				log.error("Error Loding HANA properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)hanaProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static List<String>loadSAPGaaProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(sapGaaProperties.isEmpty()) {
			try {
				sapGaaProperties = loadPropertiesFromFileSystem(Constants.sapGaaFilePath);
			} catch (Exception e) {
				log.error("Error Loding SAP GAA properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)sapGaaProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static List<String>loadUser2SodProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(user2SodProperties.isEmpty()) {
			try {
				user2SodProperties = loadPropertiesFromFileSystem(Constants.user2SodFilePath);
			} catch (Exception e) {
				log.error("Error Loding USER TO SOD properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)user2SodProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static String getUser2SodProperty(String propId) {
		String val = "";
		List<String> dataList = loadUser2SodProperty(propId);
		if(dataList != null && !dataList.isEmpty()) {
			val = dataList.get(0);
		}
		return val;
	}

	public static List<String>loadJDEProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(jdeProperties.isEmpty()) {
			try {
				jdeProperties = loadPropertiesFromFileSystem(Constants.jdeFilePath);
			} catch (Exception e) {
				log.error("Error Loding JDE properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)jdeProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}


	public static List<String>loadHCSProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(hcsProperties.isEmpty()) {
			try {
				hcsProperties = loadPropertiesFromFileSystem(Constants.hcsFilePath);
			} catch (Exception e) {
				log.error("Error Loding HCS properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)hcsProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static List<String>loadOneClickProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(sapOneClickProperties.isEmpty()) {
			try {
				sapOneClickProperties = loadPropertiesFromFileSystem(Constants.sapOneClickFilePath);
			} catch (Exception e) {
				log.error("Error Loding SAP One Click properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)sapOneClickProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static List<String>loadOneClickPropertyU2R(String propId){
		List<String> dataList = new ArrayList<>();
		if(sapOneClickPropertiesU2R.isEmpty()) {
			try {
				sapOneClickPropertiesU2R = loadPropertiesFromFileSystem(Constants.sapOneClickU2RFilePath);
				log.debug("Constants.sapOneClickU2RFilePat :"+Constants.sapOneClickU2RFilePath);
			} catch (Exception e) {
				log.error("Error Loding SAP One Click properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)sapOneClickPropertiesU2R.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}

	public static String getServerProp(String prop) {
		String env = "";
		List<String> envLst = loadOneClickPropertyU2R(prop);
		if(envLst != null && !envLst.isEmpty()) {
			env = envLst.get(0);
		}
		return env;
	}


	public static List<String>loadRiskLevel(){
		List<String> dataList = new ArrayList<>();
		dataList.add("Medium");
		dataList.add("High");
		dataList.add("Critical");

		return dataList;
}


	public static Map<Integer, List<CSIFunctionPermModel>> paginateData(List<CSIFunctionPermModel> dataLst, int pageSize){
		int totalPages=0;
		int startPos = 0;
		int endPos = pageSize;
		Map<Integer, List<CSIFunctionPermModel>> pgMap = new TreeMap<>();

		if(dataLst != null && dataLst.size()>1) {
			if(dataLst.size() > pageSize) {
				totalPages = (dataLst.size()/pageSize);
				if(dataLst.size()%pageSize > 0) {
					totalPages++;
				}
				for(int i=0; i<totalPages; i++) {
					pgMap.put((i+1), dataLst.subList(startPos, endPos));
					startPos = startPos + pageSize;
					endPos = endPos + pageSize;
					if(endPos >dataLst.size()) {
						endPos = dataLst.size();
					}
				}
			}else {
				totalPages =1;
				pgMap.put(1, dataLst);
			}
		}
		System.out.println("totalPages:"+totalPages+" pgMap:"+pgMap.keySet());
		return pgMap;
	}

	public static int getPageCount(int totalRec, int pageSize){
		int totalPages=(totalRec/pageSize);
		if(totalRec%pageSize > 0) {
			totalPages++;
		}
		return totalPages;
	}

	private static Pattern numberPattern = Pattern.compile("-?\\d+(\\.\\d+)?");


	public static boolean isNumeric(String strNum) {
	    if (strNum == null) {
	        return false;
	    }
	    return numberPattern.matcher(strNum).matches();
	}

	public static boolean isListNullOrEmpty(List<Object> data){
		boolean result = false;
		if(data == null || data.isEmpty()) {
			result = true;
		}
		return result;
	}

	public static List<Integer> getPageList(int totalPages){
		List<Integer> pgLst = new ArrayList<>();
		for(int i=0;i<totalPages; i++) {
			pgLst.add(i+1);
		}
		return pgLst;
	}


	/*private static void createFileIn_NIO()  throws IOException
    {
        String data = "Test data";
        Files.write(Paths.get("c://temp//testFile3.txt"), data.getBytes());

        //or

        List<String> lines = Arrays.asList("1st line", "2nd line");

        Files.write(Paths.get("file6.txt"),
                    lines,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
    }

public static void usingBufferedWritter() throws IOException
{
    String textToAppend = "Happy Learning !!";

    BufferedWriter writer = new BufferedWriter(
                                new FileWriter("c:/temp/samplefile.txt", true)  //Set true for append mode
                            );
    writer.newLine();   //Add new line
    writer.write(textToAppend);
    writer.close();
}

   public static void usingPath() throws IOException
{
    String textToAppend = "\r\n Happy Learning !!"; //new line in content

    Path path = Paths.get("c:/temp/samplefile.txt");

    Files.write(path, textToAppend.getBytes(), StandardOpenOption.APPEND);  //Append mode
}
    */



	/*AUTHENTICATION*/
	public static String jwtTokenDateToLMFormat(String date) {
		final DateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		//final DateFormat outputFormat = new SimpleDateFormat( "MM/dd/yyyy HH:mm:ss aaa");
		final DateFormat outputFormat = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ssZ");
		outputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		String convertedDate = null;
		try {
			convertedDate = outputFormat.format(inputFormat.parse(date));
		} catch (final ParseException e) {
			log.error("Error parsing the es date");
		}
		return convertedDate;
	}




		/**
		 * Method  : Utility.java.getRegionWiseTrfCntrlSummary()
		 *		   :<b>@param regTrfCntrlData
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Apr 30, 2021 4:44:11 PM
		 * Purpose : Region-Transfer Control Summary
		 * @return : List<SAPTrfCntrlSummaryMdl>
		 */
	public static List<SAPTrfCntrlSummaryMdl>getRegionWiseTrfCntrlSummary(Map<String, List<SAPUserAccessModel>> regTrfCntrlData){
		List<SAPTrfCntrlSummaryMdl> summary = new ArrayList<>();
		for(Map.Entry<String, List<SAPUserAccessModel>> entry:regTrfCntrlData.entrySet()) {
			String key = entry.getKey();
			String[] keyArr =key.split("_");
			List<SAPUserAccessModel> value = entry.getValue();
			SAPTrfCntrlSummaryMdl summ = new SAPTrfCntrlSummaryMdl();
			summ.setRegion(keyArr[0]);
			summ.setPlatform(keyArr[1]);
			summ.setEnvironment(keyArr[2]);
			summ.setSystem(Utility.getSapClientName(keyArr[3]));
			summ.setCount(value.size());
			summary.add(summ);
		}
		return summary;
	 }



	public static List<SAPTrfCntrlSummaryMdl>getRegionWiseUser2RoleSummary(Map<String, List<SapGaaUser2RoleModel>> regUser2RoleData){
		List<SAPTrfCntrlSummaryMdl> summary = new ArrayList<>();
		for(Map.Entry<String, List<SapGaaUser2RoleModel>> entry : regUser2RoleData.entrySet()) {
			String key = entry.getKey();
			String[] keyArr =key.split("_");
			List<SapGaaUser2RoleModel> value = entry.getValue();
			SAPTrfCntrlSummaryMdl summ = new SAPTrfCntrlSummaryMdl();
			summ.setRegion(keyArr[0]);
			summ.setPlatform(keyArr[1]);
			summ.setEnvironment(keyArr[2]);
			summ.setSystem(Utility.getSapClientName(keyArr[3]));
			summ.setCount(value.size());
			summary.add(summ);
		}
		return summary;
	 }

	public static List<SAPTrfCntrlSummaryMdl> getRegionWiseUser2SodSummary(Map<String, List<SapUser2SodModel>> regUser2SodData){
		List<SAPTrfCntrlSummaryMdl> summary = new ArrayList<>();
		for(Map.Entry<String, List<SapUser2SodModel>> entry : regUser2SodData.entrySet()) {
			String key = entry.getKey();
			String[] keyArr = key.split("_");
			List<SapUser2SodModel> value = entry.getValue();
			SAPTrfCntrlSummaryMdl summ = new SAPTrfCntrlSummaryMdl();
			summ.setRegion(keyArr[0]);
			summ.setPlatform(keyArr[1]);
			summ.setEnvironment(keyArr[2]);
			summ.setSystem(Utility.getSapClientName(keyArr[3]));
			summ.setCount(value.size());
			summary.add(summ);
		}
		return summary;
	 }

	public static int getGenesisRecordCount(Map<String, LinkedList<SAPUserAccessModel>> trfCntrlData){
		int count = 0;
		if(trfCntrlData != null && !trfCntrlData.isEmpty()) {
			for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry : trfCntrlData.entrySet()) {
				List<SAPUserAccessModel> valLst = entry.getValue();
				if(valLst != null && !valLst.isEmpty()) {
					count = count+valLst.size();
				}
			}
		}
		return count;
	}


	public static String getServerName(){
		if(StringUtils.isEmpty(hostname)){
			try
			{
				NetworkInterface iface = null;
				int i =0;
				for(Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();ifaces.hasMoreElements();){
					iface = ifaces.nextElement();
					if(iface.isLoopback()){
						continue;
					}
					InetAddress ia = null;
					for(Enumeration<InetAddress> ips = iface.getInetAddresses();ips.hasMoreElements();){
						ia = ips.nextElement();
						if(ia.isSiteLocalAddress()){
							if(i==0){
								hostname = ia.getHostAddress();
								i++;
							}
						}
					}
				}
				log.debug("Your current Hostname : " + hostname);
	        }catch (Exception se) {
	            log.error("Error getting HOST:"+se.getMessage(), se);
	        }
		}
		return hostname;
	}

	/*public static String getPlatformEmailAddress_OLD(String platformName) {
		String email="DChauras@its.jnj.com,pmani1@ITS.JNJ.com,ve1@its.jnj.com";//BACKUP EMAIL ADDR
		platformName=platformName.toUpperCase();
		//TODO - NEED CO COMMENT FOR DEV & UNCOMMENT FOR PROD
		if(platformEmails == null || platformEmails.isEmpty()) {
			loadPlatformEmail();
		}

		if(platformEmails.containsKey(platformName)) {
			email=platformEmails.get(platformName);
		}
		return email;
	}*/




	private static void loadPlatformEmail() {
	//START - ASPAC
		platformEmails.put("MARS", "DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,DL-NCSUS-ASPAC-MDDSECURITYSUPPORT@ITS.JNJ.COM,fzhu8@its.jnj.com");
		platformEmails.put("BTB JAPAN", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,rsingh82@its.jnj.com");
		platformEmails.put("CONSUMER ASPAC", "DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,DL-NCSUS-ASPAC-MDDSECURITYSUPPORT@ITS.JNJ.COM,rsingh82@its.jnj.com");
		platformEmails.put("TAISHAN", "dl-mddcnsz-taishan-app-l2@its.jnj.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,fyang3@its.jnj.com");
		platformEmails.put("PANDA", "DL-JANCNBJ-PANDA-L2-SEC@ITS.JNJ.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,fzhu8@its.jnj.com");
		//ASPAC APPENDED WITH SAP
		platformEmails.put("SAP MARS", "DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,DL-NCSUS-ASPAC-MDDSECURITYSUPPORT@ITS.JNJ.COM,fzhu8@its.jnj.com");
		platformEmails.put("SAP BTB JAPAN", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,rsingh82@its.jnj.com");
		platformEmails.put("SAP CONSUMER ASPAC", "DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,DL-NCSUS-ASPAC-MDDSECURITYSUPPORT@ITS.JNJ.COM,rsingh82@its.jnj.com");
		platformEmails.put("SAP TAISHAN", "dl-mddcnsz-taishan-app-l2@its.jnj.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,fyang3@its.jnj.com");
		platformEmails.put("SAP PANDA", "DL-JANCNBJ-PANDA-L2-SEC@ITS.JNJ.com,DL-JANCNBJ-ASPAC-SEC-L3@ITS.JNJ.com,fzhu8@its.jnj.com");
	//END - ASPAC

	//START - LATAM
		platformEmails.put("LATAM PROJECT ONE", "dl-conbr-aslasapsecurity@its.jnj.com,dlima6@its.jnj.com");
		platformEmails.put("BTBLATAM", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		//SAP APPENDED
		platformEmails.put("SAP LATAM PROJECT ONE", "dl-conbr-aslasapsecurity@its.jnj.com,dlima6@its.jnj.com");
		platformEmails.put("SAP BTBLATAM", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
	//END - LATAM

	//START - EMEA
		platformEmails.put("SUSTAIN", "dl-cntnl-sustainsolmanl2security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("ILM", "bwillem2@its.jnj.com");
		platformEmails.put("EMEA HANA", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("EUROPE2", "dl-jjcus-e2-gal-snc-security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("GALAXY", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("GMED", "dl-jjcus-e2-gal-snc-security@its.jnj.com,bwillem2@its.jnj.com");
		platformEmails.put("SNC", "dl-jjcus-e2-gal-snc-security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("STF", "dl-ncsus-stfsecurity@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("SYNTHES", "DL-NCSUS-DPYSYN-L2-SECURITY-TEAM@ITS.JNJ.com,dhonig1@its.jnj.com");
		platformEmails.put("SYMPHONY", "KVermee1@ITS.JNJ.com,ECUYPER2@its.jnj.com");
		platformEmails.put("VDR", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
		//SAP APPENDED
		platformEmails.put("SAP SUSTAIN", "dl-cntnl-sustainsolmanl2security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("SAP ILM", "bwillem2@its.jnj.com");
		platformEmails.put("SAP EMEA HANA", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("SAP EUROPE2", "dl-jjcus-e2-gal-snc-security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("SAP GALAXY", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("SAP GMED", "dl-jjcus-e2-gal-snc-security@its.jnj.com,bwillem2@its.jnj.com");
		platformEmails.put("SAP SNC", "dl-jjcus-e2-gal-snc-security@its.jnj.com,adevabha@its.jnj.com");
		platformEmails.put("SAP STF", "dl-ncsus-stfsecurity@its.jnj.com,nnighti1@its.jnj.com");
		platformEmails.put("SAP SYNTHES", "DL-NCSUS-DPYSYN-L2-SECURITY-TEAM@ITS.JNJ.com,dhonig1@its.jnj.com");
		platformEmails.put("SAP SYMPHONY", "KVermee1@ITS.JNJ.com,ECUYPER2@its.jnj.com");
		platformEmails.put("SAP VDR", "dl-jjcus-e2-gal-snc-security@its.jnj.com,nnighti1@its.jnj.com");
	//END - EMEA

	//START - NA
		platformEmails.put("ANSPACH", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("ATLAS", "DL-CNTNL-ATLASSOLMANL2SECURITY@ITS.JNJ.COM,Dking30@its.jnj.com");
		platformEmails.put("BTB GLOBAL", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("BTB LERCAN", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("CONCOURSE", "dl-slcus-concoursesolman-sec-cps4@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("CROSS ROAD", "abanerje@its.jnj.com,abanerje@its.jnj.com");
		platformEmails.put("FUSION", "dl-visus-sap-security-run@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("GLOBAL SOLMAN", "DL-MEDCA-JJTS-SOLMAN-SECURITY@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("JJSV", "DL-JJCUS-JJT-AMOSAPSecurity@ITS.JNJ.com,Dking30@its.jnj.com");
		platformEmails.put("LYNX", "DL-JJCUS-TCS-LYNXSECURITYTEAM@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("MERCURY", "DL-CPCUS-NASAPOCSecurity@cpcus.jnj.com,Dking30@its.jnj.com");
		platformEmails.put("MITEK", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,jvroom@its.jnj.com");
		platformEmails.put("NA HANA", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("OURSOURCE", "DL-NCSUS-OS-Security-L3@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("USROTC", "RA-HCSUS-SAPSecurAdm@HCSUS.JNJ.com,jvroom@its.jnj.com");
		//SAP APPENDED
		platformEmails.put("SAP ANSPACH", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("SAP ATLAS", "DL-CNTNL-ATLASSOLMANL2SECURITY@ITS.JNJ.COM,Dking30@its.jnj.com");
		platformEmails.put("SAP BTB GLOBAL", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("SAP BTB LERCAN", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("SAP CONCOURSE", "dl-slcus-concoursesolman-sec-cps4@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("SAP CROSS ROAD", "abanerje@its.jnj.com,abanerje@its.jnj.com");
		platformEmails.put("SAP FUSION", "dl-visus-sap-security-run@its.jnj.com,jphilips@its.jnj.com");
		platformEmails.put("SAP GLOBAL SOLMAN", "DL-MEDCA-JJTS-SOLMAN-SECURITY@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("SAP JJSV", "DL-JJCUS-JJT-AMOSAPSecurity@ITS.JNJ.com,Dking30@its.jnj.com");
		platformEmails.put("SAP LYNX", "DL-JJCUS-TCS-LYNXSECURITYTEAM@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("SAP MERCURY", "DL-CPCUS-NASAPOCSecurity@cpcus.jnj.com,Dking30@its.jnj.com");
		platformEmails.put("SAP MITEK", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,jvroom@its.jnj.com");
		platformEmails.put("SAP NA HANA", "dl-hcsus-btbsolmansecurityl2@its.jnj.com,somolola@its.jnj.com");
		platformEmails.put("SAP OURSOURCE", "DL-NCSUS-OS-Security-L3@ITS.JNJ.com,somolola@its.jnj.com");
		platformEmails.put("SAP USROTC", "RA-HCSUS-SAPSecurAdm@HCSUS.JNJ.com,jvroom@its.jnj.com");
	//END - NA

		//START - JDE
		platformEmails.put("DSI BWI", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("DSI EES", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("DSI ETHICON US", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("DSI GMED", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("DSI MENTOR", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE ANIMAS", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE BWI", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE DCF92", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE DEPUY EMEA", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE DEPUY US", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE EES", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE EMS", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE ETHICON", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE GMED", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE MENTOR", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		//
		platformEmails.put("JDE PLATFORMS DSI BWI", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS DSI EES", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS DSI ETHICON US", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS DSI GMED", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS DSI MENTOR", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE ANIMAS", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE BWI", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE DCF92", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE DEPUY EMEA", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE DEPUY US", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE EES", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE EMS", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE ETHICON", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE GMED", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		platformEmails.put("JDE PLATFORMS JDE MENTOR", "kwright4@its.jnj.com,kwright4@its.jnj.com,fmuzzupa@its.jnj.com");
		//END - JED

		//platformEmails.put("", "");


	}

	public static Map<String, String> getUser2CriticalMatrix() {
		return USER2CRITICALROLES;
	}

	public static void setUser2CriticalMatrix(Map<String, String> dataMap) {
		USER2CRITICALROLES = dataMap;
	}

	//START - USER IDENTITY VALUES
	private static Properties userProperties = new Properties(); //JDE Extraction properties

	public static List<String>loadUserProperty(String propId){
		List<String> dataList = new ArrayList<>();
		if(userProperties.isEmpty()) {
			try {
				userProperties = loadPropertiesFromFileSystem(Constants.userFilePath);
			} catch (Exception e) {
				log.error("Error Loding USER properties file:"+e.getMessage(), e);
			}
		}
		String data = (String)userProperties.get(propId);
		if(data != null && data.length() > 0) {
			dataList = Arrays.asList(data.split(","));
		}
		return dataList;
	}


	public static Map<String, String> allIdeRefTables(String tblName){
		Map<String, String> tableMap = new HashMap<>();
		String reqTyp = " SELECT ID AS KEY, NAME AS VAL FROM SOD_DB_USER.REQ_TYPE WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";
		String platformPrj = " SELECT ID AS KEY, NAME AS VAL FROM SOD_DB_USER.PLATFORM_PROJECT WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";
		String regions = " SELECT REG_ID AS KEY, REG_NAME AS VAL FROM SOD_DB_USER.REGIONS WHERE IS_ACTIVE='Y' ORDER BY KEY, VAL ";

		tableMap.put("REQ_TYPE", reqTyp);
		tableMap.put("PLATFORM_PROJECT", platformPrj);
		tableMap.put("REGIONS", regions);
		tableMap.put("", "");
		tableMap.put("", "");
		tableMap.put("", "");
		tableMap.put("", "");
		tableMap.put("", "");
		tableMap.put("", "");
		tableMap.put("", "");



		return tableMap;
	}

	public static String getStringValues(List<KeyValPair> data) {
		String vls="";
		if(data != null && !data.isEmpty()) {
			for(KeyValPair kv : data){
				if(vls.equals("")) {
					vls = kv.getVal();
				}else {
					vls+=","+kv.getVal();
				}
			}
		}
		return vls;
	}


	public static String getStringValuesStr(List<StrKeyValPair> data) {
		String vls="";
		if(data != null && !data.isEmpty()) {
			for(StrKeyValPair kv : data){
				if(vls.equals("")) {
					vls = kv.getVal();
				}else {
					vls+=","+kv.getVal();
				}
			}
		}
		return vls;
	}
	//END - USER IDENTITY VALUES

	public static Map<String, SapMitiCntrlModel> getSapMitiCntrlMap() {
		return sapMitiCntrlMap;
	}
	public static void setSapMitiCntrlMap(Map<String, SapMitiCntrlModel> cntrlMap) {
		sapMitiCntrlMap = cntrlMap;
	}

	public static Map<String, SapPlatformReviwerMdl> getSapReviewersDataMap() {
		return sapReviewersDataMap;
	}
	public static void setSapReviewersDataMap(Map<String, SapPlatformReviwerMdl> revMap) {
		sapReviewersDataMap = revMap;
	}

	public static Map<String, String> getMercuryReviewersDataMap() {
		return mercuryReviewersDataMap;
	}

	public static void setMercuryReviewersDataMap(Map<String, String> merReviewersDataMap) {
		mercuryReviewersDataMap = merReviewersDataMap;
	}

	public static String fixLen4000(String dataStr) {
		String val="";
		dataStr =dataStr.replaceAll("[^_:,-\\[\\]/+*a-zA-Z0-9]", " ");
		if(dataStr != null && dataStr.length() > 4000){
			val= (dataStr.substring(0, 3999)).trim();
		}else {
			val = dataStr.trim();
		}
		return val;
	}

	public static String getUid() {
		return UUID.randomUUID().toString();
	}

	public static String getPlatformEmailAddress(String platformName){
		String defaultEmail="DChauras@its.jnj.com,pmani1@ITS.JNJ.com,dkastur2@its.jnj.com";//BACKUP EMAIL ADDR
		String email="";
		String env =  Utility.getServerProp("ENVIRONMENT");
		platformName = (platformName.replaceAll(" ", "_")).toUpperCase();
		if(platformEmails.isEmpty()) {
			try {
				platformEmails = loadPropertiesFromFileSystem(Constants.leadDistEmailPath);
				//loadPlatformEmail();
			} catch (Exception e) {
				log.error("Error Loding LEAD DIST EMAILS properties file:"+e.getMessage(), e);
			}
		}
		email = (String)platformEmails.get(platformName);
		if("LOCALSERVER".equals(env) || "DEVELOPMENT".equals(env) || "QUALITY".equals(env) || email == null || email.length() <=1 ){
			log.info("<<<<<<<<<<< EMAIL ADDRESS NOT FOUND/LOCAL/DEV/QA PLATFORM:"+platformName+" ROUTING TO DEFAULT.");
			email = (Utility.isEmpty((String)platformEmails.get("DEFAULT_EMAIL"))? defaultEmail: ((String)platformEmails.get("DEFAULT_EMAIL")));
		}
		return email;
	}

	public static String getArrValues(String[] strArray) {
		String returnVal="";
		if(strArray != null && strArray.length > 0) {
			for(String kv:strArray) {
				if(returnVal.equals("")||returnVal.length() ==0) {
					returnVal=kv+"";
				} else {
					returnVal+=","+kv;
				}
			}
		}
		return returnVal;
	}

	public static String removeFirstComma(String dataStr) {
		if(!dataStr.isEmpty() && dataStr.startsWith(",")) {
			dataStr = dataStr.substring(1);
		}
		return dataStr;
	}


	public static Date atStartOfDay(Date date) {
	    LocalDateTime localDateTime = dateToLocalDateTime(date);
	    LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
	    //startOfDay = startOfDay.minusDays(1);
	    return localDateTimeToDate(startOfDay);
	}

	public static Date atEndOfDay(Date date) {
	    LocalDateTime localDateTime = dateToLocalDateTime(date);
	    LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
	    return localDateTimeToDate(endOfDay);
	}

	private static LocalDateTime dateToLocalDateTime(Date date) {
	    return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
	}

	private static Date localDateTimeToDate(LocalDateTime localDateTime) {
	    return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	public static Date getValUptoDate() {
		//END of Year 2199
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2199);
		cal.set(Calendar.MONTH, 11);
		cal.set(Calendar.DAY_OF_MONTH, 31);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		//Date endYear = atEndOfDay(cal.getTime());
		Date endYear = cal.getTime();
		return endYear;
	}

	public static Map<String, String> buildIDMap(String[] ids){
		Map<String, String> dataMap = new HashMap<>();
		if(ids != null && ids.length > 0) {
			for(String id:ids) {
				dataMap.put(id, "");
			}
		}
		return dataMap;
	}

	public static List<JDAUser2SodModel> processFinalConfIntData(List<JDAUser2SodModel> allUser2SodInternal, Map<String, String> usrConterMap) {
		if(allUser2SodInternal != null && allUser2SodInternal.size() > 0 ) {
			for(JDAUser2SodModel usr : allUser2SodInternal) {
				if(usrConterMap.containsKey(usr.getWwId())) {
					usrConterMap.remove(usr.getWwId());
				}
			}
		}
		if(usrConterMap.size() > 0 ) {
			for(String wwid : usrConterMap.keySet()) {
				JDAUser2SodModel mdl = new JDAUser2SodModel();
				mdl.setWwId(wwid);
				mdl.setRiskId("NA");
				mdl.setRiskDesc("NA");
				mdl.setRoleId("NA");
				mdl.setRoleName("NA");
				mdl.setFuncId("NA");
				mdl.setFuncDesc("NA");
				mdl.setRiskLevel("NA");
				mdl.setMitiCntrl("No Violations");
				allUser2SodInternal.add(mdl);
			}
		}
		return allUser2SodInternal;
	}

	public static List<JDACrossAppMatrixModel> processFinalConfData(List<JDACrossAppMatrixModel> crossAppRoleConflictList, Map<String, String> usrConterMap) {
		if(crossAppRoleConflictList != null && crossAppRoleConflictList.size() > 0 ) {
			for(JDACrossAppMatrixModel cusr:crossAppRoleConflictList) {
				if(usrConterMap.containsKey(cusr.getWwid())) {
					usrConterMap.remove(cusr.getWwid());
				}
			}
		}
		if(usrConterMap.size() > 0 ) {
			for(String wwid : usrConterMap.keySet()) {
				JDACrossAppMatrixModel mdl = new JDACrossAppMatrixModel();
				mdl.setWwid(wwid);
				mdl.setApp1("NA");
				mdl.setApp2("NA");
				mdl.setRole1("NA");
				mdl.setRole2("NA");
				mdl.setConflict("");
				mdl.setMitigatingControl("No Violations");
				crossAppRoleConflictList.add(mdl);
			}
		}
		return crossAppRoleConflictList;
	}


	/**
	 * Method  : Utility.java.buildQuery()
	 *		   :<b>@param counter
	 *		   :<b>@param varName
	 *		   :<b>@param recdArr
	 *		   :<b>@param inparams
	 *		   :<b>@param sql
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 10, 2023 4:44:57 PM
	 * Purpose :Method desinged to Build Query
	 * @return : int
	*/
	public static int buildQuery(int counter, String varName, String[] recdArr, Object [] inparams, StringBuilder sql ) {
		String qmrk="";
		if(recdArr.length == 1) {
			sql.append(" AND "+varName+" = ? ");
			inparams[counter] = recdArr[0];
			counter++;
		}else if(recdArr.length > 1){
			sql.append(" AND "+varName+"  in ( ");
			for (String element : recdArr) {
				inparams[counter] = element;
				if(qmrk.equals("")) {
					qmrk = " ? ";
				}else {
					qmrk +=", ? ";
				}
				counter++;
			}
			sql.append(qmrk+" )");
		}
		return counter;
	}


	//Adding Cache for USER's EXISTING ACCESS
	private static Map<String, Map<String, List<RoleADGrpMdl>>> USER_ACCESS_MAP = new HashMap<>();

	public static Map<String, List<RoleADGrpMdl>> getUserAccess(String userId) {
		if(USER_ACCESS_MAP.containsKey(userId.toUpperCase())) {
			return USER_ACCESS_MAP.get(userId.toUpperCase());
		}
		return null;
	}

	public static boolean hasUserAccess(String userId) {
		return USER_ACCESS_MAP.containsKey(userId.toUpperCase());
	}

	public static void setUserAccess(String userId, Map<String, List<RoleADGrpMdl>> dataMap) {
		USER_ACCESS_MAP.put(userId.toUpperCase(),dataMap);
	}

	public static void clearUserAccessData() {
		synchronized (USER_ACCESS_MAP) {
			USER_ACCESS_MAP.clear();
		}
	}



	public static String toJson(Object mdl) {
		String jsonStr = "";
		try {
			jsonStr = mapper.writeValueAsString(mdl);
		} catch (JsonProcessingException e) {
			log.error("Error Parsing Object :"+e.getMessage(), e);
		}
		return jsonStr;
	}

	public static HttpHeaders getHeaders(String mediaTyp, String authToken) {
		HttpHeaders headers = new HttpHeaders();
		if(Utility.isEmpty(mediaTyp) || "JSON".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}else if("TEXT".equals(mediaTyp)) {
			headers.setContentType(MediaType.TEXT_PLAIN);
		}else if("FILE".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			//headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		}

		if(!Utility.isEmpty(authToken)) {
			//Authorization:AnaplanAuthToken {anaplan_auth_token}
			headers.add("Authorization", "AnaplanAuthToken "+authToken);
		}
		return headers;
	}

	public static void setAnaPlanPageId(String pageId) {
		ANAPLAN_PAGEID = pageId;
	}
	public static String getAnaPlanPageId() {
		return ANAPLAN_PAGEID;
	}

	//DATE FORMAT for GRC
	public static DateFormat yyyyMMdt = new SimpleDateFormat("yyyy-MM-dd");
	public static String fmtYyyyMMdt(Date date) {
		if(date == null) {
			date = new Date();
		}
		return yyyyMMdt.format(date);
	}



}
