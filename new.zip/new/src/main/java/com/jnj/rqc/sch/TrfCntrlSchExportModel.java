package com.jnj.rqc.sch;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TrfCntrlSchExportModel {
	private String region;
	private String type; /*C=Create Data, E=Export Data*/
	private Date schDt;
	private String schStatus;
	private String details;
	private Date createdDt;
	private String createdBy;
	private Date completedDt;
	private String export;
	@Override
	public String toString() {
		return "TrfCntrlSchExportModel [region=" + region + ", type=" + type + ", schDt=" + schDt + ", schStatus="
				+ schStatus + ", details=" + details + ", createdDt=" + createdDt + ", createdBy=" + createdBy
				+ ", completedDt=" + completedDt + ", isReadytoExport=" + export + "]";
	}







}


