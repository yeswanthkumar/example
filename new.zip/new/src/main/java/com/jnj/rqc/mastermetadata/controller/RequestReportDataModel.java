package com.jnj.rqc.mastermetadata.controller;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestReportDataModel {
	//private String year;
    //private ReportStats stats;
	private String requestCreated;
	 private String month;
	 private String mm;
	 private int yyyy;
	 private int reqCreated;
	 private int complianceReview;
	 private int partiallyApproved;
	 private int complianceReviewed;
	 private int gRCIAMApprovalInProgress;
	 private int requestClosed;
	 private int provisionedWithError;
	 private int complianceRejected;
	 private int requestCancelled;
	 
	
}
