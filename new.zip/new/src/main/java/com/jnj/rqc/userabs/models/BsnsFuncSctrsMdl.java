package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BsnsFuncSctrsMdl {
	String bfid;
	String secid;
	String seccode;
	String secname;
	String secdesc;
	String secimg;
	String secloc;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BsnsFuncSctrsMdl other = (BsnsFuncSctrsMdl) obj;
		if (bfid == null) {
			if (other.bfid != null)
				return false;
		} else if (!bfid.equals(other.bfid))
			return false;
		if (seccode == null) {
			if (other.seccode != null)
				return false;
		} else if (!seccode.equals(other.seccode))
			return false;
		if (secdesc == null) {
			if (other.secdesc != null)
				return false;
		} else if (!secdesc.equals(other.secdesc))
			return false;
		if (secid == null) {
			if (other.secid != null)
				return false;
		} else if (!secid.equals(other.secid))
			return false;
		if (secname == null) {
			if (other.secname != null)
				return false;
		} else if (!secname.equals(other.secname))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfid == null) ? 0 : bfid.hashCode());
		result = prime * result + ((seccode == null) ? 0 : seccode.hashCode());
		result = prime * result + ((secdesc == null) ? 0 : secdesc.hashCode());
		result = prime * result + ((secid == null) ? 0 : secid.hashCode());
		result = prime * result + ((secname == null) ? 0 : secname.hashCode());
		return result;
	}


}