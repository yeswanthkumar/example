package com.jnj.rqc.models;

public class FuncTransaction {


}
