package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZReqTypMdl {
	private int typeid;
	private String typename;
	private String typedesc;
	private String isactive;
	private  String createdby;
	private Date createdon;
	private  String cchangedby;
	private Date changedon;


	@Override
	public String toString() {
		return "ZReqTypMdl [typeid=" + typeid + ", typename=" + typename + ", typedesc=" + typedesc + ", isactive="
				+ isactive + ", createdby=" + createdby + ", createdon=" + createdon + ", cchangedby=" + cchangedby
				+ ", changedon=" + changedon + "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZReqTypMdl other = (ZReqTypMdl) obj;
		if (isactive == null) {
			if (other.isactive != null)
				return false;
		} else if (!isactive.equals(other.isactive))
			return false;
		if (typedesc == null) {
			if (other.typedesc != null)
				return false;
		} else if (!typedesc.equals(other.typedesc))
			return false;
		if (typeid != other.typeid)
			return false;
		if (typename == null) {
			if (other.typename != null)
				return false;
		} else if (!typename.equals(other.typename))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isactive == null) ? 0 : isactive.hashCode());
		result = prime * result + ((typedesc == null) ? 0 : typedesc.hashCode());
		result = prime * result + typeid;
		result = prime * result + ((typename == null) ? 0 : typename.hashCode());
		return result;
	}







}
