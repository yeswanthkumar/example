package com.jnj.rqc.useridentity.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserIdentityConflictMdl {
	String userId;
	String reqId;
	String riskId;
	String riskDesc;
	String app1;
	String appName1;
	String app2;
	String appName2;
	String posv1;
	String posvName1;
	String posv2;
	String posvName2;
	String conflict;
	String mitigatingControl;
	Date   dtCreated;
	String resolStatus;
	String acceptDeny;
	int    mitiCntrlSel;
	String reslCmnts;
	String reslBy;
	Date   dtResolved;
}

