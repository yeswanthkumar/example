package com.jnj.rqc.common.sorting;

import java.util.Comparator;

import com.jnj.rqc.models.UserSearchModel;

public class UserMdlComparatorLF implements Comparator<UserSearchModel> {

	@Override
	public int compare(UserSearchModel u1, UserSearchModel u2) {
		int lNmCmp = u1.getFmlyNm().compareTo(u2.getFmlyNm());
        int fNmCmp = u1.getGivenNm().compareTo(u2.getGivenNm());
		if (lNmCmp == 0) {
            return ((fNmCmp == 0) ? lNmCmp : fNmCmp);
        } else {
            return lNmCmp;
        }
	}
}
