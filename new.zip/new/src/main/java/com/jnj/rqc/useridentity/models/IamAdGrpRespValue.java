package com.jnj.rqc.useridentity.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamAdGrpRespValue {
	private String 	CCC_ActionType;
	private String 	CCC_ApplicationName;
	private String 	CCC_ErrorMessage;
	private String 	CCC_ExpiresInHours;
	private boolean CCC_IsComplete;
	private boolean CCC_IsError;
	private boolean CCC_IsTempAccess;
	private String 	CCC_Reason;
	private String 	CCC_Recipient;
	private String 	CCC_RequestDetails;
	private String 	CCC_Requestor;
	private String 	CCC_RequestType;
	private String 	CCC_ResourceName;
	private String 	CCC_UID_PersonWantsOrg;
	private String 	UID_CCC_WebservicesREQUEST;
	private Date 	XDateInserted;
	private Date 	XDateUpdated;
	private int 	XMarkedForDeletion;
	private Object 	XObjectKey;
	private String 	XTouched;
	private String 	XUserInserted;
	private String 	XUserUpdated;
	private Object	displayValues;

}
