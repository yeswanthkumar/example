package com.jnj.rqc.conflictModel;

import java.util.Date;

import com.jnj.rqc.util.Utility;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapUser2RoleDeltaMdl {
	private String revUserId;
	private String userId;
	private String primaryReviewInfo1;
	private String primaryReviewInfo2;
	private String primaryReviewInfo3;
	private String additionalInfo1;
	private String additionalInfo2;
	private String additionalInfo3;
	private Date dateEntered;
	private Date reportDate;
	private String userStatus;

	public String getData() {
		return revUserId + "~"+userId + "~"+ primaryReviewInfo1 + "~" + primaryReviewInfo2 + "~"+ primaryReviewInfo3 + "~" + additionalInfo1 + "~" + additionalInfo2+ "~"
	+ additionalInfo3 + "~" + (dateEntered != null? Utility.fmtMMDDYYYY(dateEntered):"") + "~" + (reportDate != null? Utility.fmtMMDDYYYY(reportDate):"")+ "~" + userStatus;
	}

	@Override
	public String toString() {
		return "SapUser2RoleDeltaMdl [revUserId=" + revUserId + ", userId=" + userId + ", primaryReviewInfo1="
				+ primaryReviewInfo1 + ", primaryReviewInfo2=" + primaryReviewInfo2 + ", primaryReviewInfo3="
				+ primaryReviewInfo3 + ", additionalInfo1=" + additionalInfo1 + ", additionalInfo2=" + additionalInfo2
				+ ", additionalInfo3=" + additionalInfo3 + ", dateEntered=" + dateEntered + ", reportDate=" + reportDate
				+ ", userStatus=" + userStatus + "]";
	}






}
