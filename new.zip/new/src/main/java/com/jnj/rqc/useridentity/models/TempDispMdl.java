package com.jnj.rqc.useridentity.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TempDispMdl {
	private String sysName;
	List<TmpPosnsMdl> posns;
}
