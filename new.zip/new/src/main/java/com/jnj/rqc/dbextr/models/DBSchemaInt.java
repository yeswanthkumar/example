package com.jnj.rqc.dbextr.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DBSchemaInt {
	int schema;
}
