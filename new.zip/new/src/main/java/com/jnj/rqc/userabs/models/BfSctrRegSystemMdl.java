package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BfSctrRegSystemMdl {
	String bfid;
	String secid;
	String regid;
	String sysid;
	String sysname;
	String sysdesc;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BfSctrRegSystemMdl other = (BfSctrRegSystemMdl) obj;
		if (bfid == null) {
			if (other.bfid != null)
				return false;
		} else if (!bfid.equals(other.bfid))
			return false;
		if (regid == null) {
			if (other.regid != null)
				return false;
		} else if (!regid.equals(other.regid))
			return false;
		if (secid == null) {
			if (other.secid != null)
				return false;
		} else if (!secid.equals(other.secid))
			return false;
		if (sysdesc == null) {
			if (other.sysdesc != null)
				return false;
		} else if (!sysdesc.equals(other.sysdesc))
			return false;
		if (sysid == null) {
			if (other.sysid != null)
				return false;
		} else if (!sysid.equals(other.sysid))
			return false;
		if (sysname == null) {
			if (other.sysname != null)
				return false;
		} else if (!sysname.equals(other.sysname))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfid == null) ? 0 : bfid.hashCode());
		result = prime * result + ((regid == null) ? 0 : regid.hashCode());
		result = prime * result + ((secid == null) ? 0 : secid.hashCode());
		result = prime * result + ((sysdesc == null) ? 0 : sysdesc.hashCode());
		result = prime * result + ((sysid == null) ? 0 : sysid.hashCode());
		result = prime * result + ((sysname == null) ? 0 : sysname.hashCode());
		return result;
	}





}