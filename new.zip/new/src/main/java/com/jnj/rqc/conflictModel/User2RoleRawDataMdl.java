package com.jnj.rqc.conflictModel;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class User2RoleRawDataMdl {
	private String 	region;
	private String 	platform;
	private String 	environment;
	private String 	system;
	private String userId;
	private String roleId;
	private String roleDesc;
	private Date createdDt;
}
