package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.models.U2REmailLogMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.CriticalRoleModel;
import com.jnj.rqc.sch.SchAdminModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;

/**
 * File    : <b>SAPExtrRegionWiseDao.java</b>
 * @author : DChauras @Created : May 10, 2021 1:42:43 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface SAPExtrRegionWiseDao {
	public List<TrfCntrlSchModel> getSchedulerStatus(String region) throws SQLException, DataAccessException;
	public boolean saveSchedule(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException;
	public List<SchAdminModel> getActiveSchedulers() throws SQLException, DataAccessException ;
	public List<TrfCntrlSchModel> getCurActTrfSchedule(String region, String status, String sType) throws SQLException, DataAccessException;
	boolean saveTrfDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public int insertTrfCntrlTransData(List<TrfCntrlTransDataMdl> dataList) throws SQLException, DataAccessException;
	public int updateTransferSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException;

	/**
	 * Method  : SAPExtrRegionWiseDao.java.getAllTrfCntrlSchedules()
	 *		   :<b>@param regions
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 17, 2021 1:53:52 PM
	 * Purpose : Get All Schedules for All Regions
	 * @return : List<TrfCntrlSchModel>
	 */
	public List<TrfCntrlSchModel> getAllTrfCntrlSchedules(List<String> regions) throws SQLException, DataAccessException;



		/**
		 * Method  : SAPExtrRegionWiseDao.java.getExportDataForRegPlatform()
		 *		   :<b>@param templSysParam
		 *		   :<b>@return
		 *		   :<b>@throws SQLException
		 *		   :<b>@throws DataAccessException</b>
		 * @author : DChauras  @Created :May 20, 2021 3:47:11 PM
		 * Purpose : Query Transfer Control Data to be Exported to Genesis
		 * @return : List<TrfCntrlTransDataMdl>
		 */
	public List<TrfCntrlTransDataMdl> getExportDataForRegPlatform(String templSysParam) throws SQLException, DataAccessException;

	public List<SapGaaUser2RoleTransModel> getUser2RoleExportDataForRegPlatform(String templSysParam) throws SQLException, DataAccessException;

	/**
	 * Method  : SAPExtrRegionWiseDao.java.updateTrfExportSummary()
	 *		   :<b>@param sumMdl
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :May 20, 2021 5:42:53 PM
	 * Purpose : Method Designed to Update Export Data Summary for Transfer Control.
	 * @return : boolean
	 */
	public boolean updateTrfExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public boolean updateUser2RoleExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;

	public List<TrfCntrlSummaryMdl> getTrfContrlSummary() throws SQLException, DataAccessException ;

	public int countScheduleforRegion(String region, String sType, String dataType) throws SQLException, DataAccessException;
	public int countU2SSchforRegion(String region, String sType, String dataType) throws SQLException, DataAccessException;

	/*  USER TO ROLE*/
	public List<TrfCntrlSchModel> getCurActUser2RoleSchedule(String region, String status, String sType) throws SQLException, DataAccessException;
	public int updateUser2RoleSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getAllUser2RoleSchedules(List<String> regions) throws SQLException, DataAccessException;
	public List<TrfCntrlSummaryMdl> getUser2RoleSummary() throws SQLException, DataAccessException ;
	public boolean saveScheduleUser2Role(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException;
	boolean saveUser2RoleDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public int insertUser2RoleTransData(List<SapGaaUser2RoleTransModel> dataList) throws SQLException, DataAccessException;
	public int insertUser2SodTransData(List<SapUser2SodModel> dataList, String templSystem, String crtdBy) throws SQLException, DataAccessException;

	//DELETE
	public int deleteTrfTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException;
	public int deleteUser2RoleTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException;
	public int deleteUser2SodTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException;
	public int insertUser2RoleDeltaReport(List<SapUser2RoleDeltaMdl> dataList) throws SQLException, DataAccessException;
	public int insertUser2RoleDeltaSummary(List<SapU2RDeltaSummaryMdl> dataList) throws SQLException, DataAccessException;
	//CRITICAL ROLES
	public List<CriticalRoleModel> getAllCriticalRoles() throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getCriticalScheduleforRegion(String region, String sType) throws SQLException, DataAccessException;
	public int delUser2CriticalRoleTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException;
	public int insertUser2CriticalRoleTransData(List<SapGaaUser2RoleTransModel> dataList) throws SQLException, DataAccessException;
	boolean saveUser2CriticalRoleDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getAllUser2CriticalRoleSchedules(List<String> regions) throws SQLException, DataAccessException;
	public List<TrfCntrlSummaryMdl> getUser2CriticalRoleSummary() throws SQLException, DataAccessException ;
	public boolean saveScheduleUser2CriticalRole(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getCurActUser2CriticalRoleSchedule(String region, String status, String sType) throws SQLException, DataAccessException;
	public int updateUser2CriticalRoleSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException;
	public List<SapGaaUser2RoleTransModel> getUser2CriticalRoleExportDataForRegPlatform(String templSysParam) throws SQLException, DataAccessException;
	public boolean updateUser2CriticalRoleExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public String clearDeltaData()throws SQLException, DataAccessException;

	public  List<TrfCntrlSchModel> getTRFOrU2RScheduleforRegion(String region, String sType, String process)throws SQLException, DataAccessException;
	public List<TrfCntrlTransDataMdl> getAllTRFCntrlExportableData(String regn) throws SQLException, DataAccessException;//Method Designed to Download Transfer Control Data
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn) throws SQLException, DataAccessException;//Method Designed to Download User To Role Data

	//USER2SOD
	public List<TrfCntrlSchModel> getAllUser2SodSchedules(List<String> regions) throws SQLException, DataAccessException;
	public List<TrfCntrlSummaryMdl> getUser2SodSummary() throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getUserToSodScheduleforRegion(String region, String sType) throws SQLException, DataAccessException;
	public boolean saveScheduleUser2Sod(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException;
	public List<TrfCntrlSchModel> getCurActUser2SodSchedule(String region, String status, String sType) throws SQLException, DataAccessException;
	public int updateUser2SodSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException;
	public boolean updateUser2SodExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public List<SapUser2SodModel> getUser2SodExportDataForRegPlatform(String templSysParam) throws SQLException, DataAccessException;
	boolean saveUser2SodDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException;
	public String clearUser2SodDeltaData() throws SQLException, DataAccessException;
	public List<SapUser2SodTrnsModel> getAllUser2SodExportableData(String regn) throws SQLException, DataAccessException;//Method Designed to Download User To Role Data
	public int insertUser2SodDeltaSummary(List<SapU2RDeltaSummaryMdl> dataList) throws SQLException, DataAccessException;
	public int insertUser2SodDeltaReport(List<SapUser2SodDeltaMdl> dataList) throws SQLException, DataAccessException;

	//RAW DATA SAVING - USER TO ROLE
	public int insertUser2RoleRawData(List<User2RoleRawDataMdl> dataList) throws SQLException, DataAccessException;
	int insertUser2RoleTransRawData(List<SapGaaUser2RoleTransModel> dataList) throws SQLException, DataAccessException;
	public List<SAPTrfCntrlSummaryMdl> getRawDataRegnSummary(String regId) throws SQLException, DataAccessException;

	public int getUer2RoleSeq(String reportName) throws SQLException, DataAccessException;
	public int saveU2RRepPlatformEmailLog(int seq, List<String> sysIDs, String reportNm, String triggeredBy) throws SQLException, DataAccessException;
	public int updateU2RRepPlatformEmailLog(int seq, String sysID, String reportNm, String toEmail, String fileNames) throws SQLException, DataAccessException;
	public List<U2REmailLogMdl> getU2RWeeklyLogDetails() throws SQLException, DataAccessException;
	public List<U2REmailLogMdl> getU2RWeeklyLogData(int seqId) throws SQLException, DataAccessException;
	public int updateWeeklyRptStatus(int seqIdParam, String platform, String userId) throws SQLException, DataAccessException;

}
