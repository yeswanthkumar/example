package com.jnj.rqc.serviceImpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.TerminationsDao;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.TerminationReportService;
import com.jnj.rqc.terminations.models.AppStatusModel;
import com.jnj.rqc.terminations.models.TerminationModel;
import com.jnj.rqc.util.Utility;

@Service
public class TerminationReportServiceImpl implements TerminationReportService {
	static final Logger log = LoggerFactory.getLogger(TerminationReportServiceImpl.class);

	@Autowired
	TerminationsDao terminationsDao;
	@Autowired
	CSVReportWriter csvReportWriter;

	@Override
	public String saveFile(MultipartFile file) throws IOException {
		byte[] bytes = file.getBytes();
		String fileNm = file.getOriginalFilename();
		if(fileNm.indexOf("\\") > 0) {
			fileNm = fileNm.substring(fileNm.lastIndexOf("\\")+1);
		}
		Path path = Paths.get(Constants.UPLOAD_DIR + fileNm);
		if(!path.toFile().exists()) {
			Files.write(path, bytes);
			log.debug("File :"+path.getFileName()+" CREATED1");
		}else {
			if(path.toFile().exists() && (TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - path.toFile().lastModified()) > 0)) {  //Should be 60 or more
				path.toFile().delete();
				Files.write(path, bytes);
				log.debug("File :"+path.getFileName()+" CREATED2");
			}else {
				log.debug("File :"+path.getFileName()+" ... ALREADY EXISTS");
			}

		}
		return path.toString();
	}

	@Override
	public List<TerminationModel> processTerminationReport(String path, HttpServletRequest request) {
		//Map<String, TerminationModel> terminationDataMap = loadTerminationFile(path); //Getting all Unique records from Excel File
		List<TerminationModel> terminationDataMap = loadTerminationFile(path); //Getting all records from Excel File
		log.info("Total Unique records :"+terminationDataMap.size());
		List<TerminationModel> dbData = populateTermDBData(terminationDataMap);
		return dbData;
	}

	@Override
	public String writeTerminationCSVReview(String type, List<TerminationModel> data) {
		String filePath = "";
		if("XLS".equals(type)){
			filePath = csvReportWriter.writeTerminationCSVReport(data, "HCSTerminationReport_"+Utility.fmtMDY(new Date())+".csv");
		}
		/*else
		if("PDF".equals(type)){
			filePath = pdfReportWriter.buildTerminationReport(data, "HCSTerminationReport_"+Utility.fmtMDY(new Date())+".csv");
		}*/
		log.info(type+ " File Path: "+filePath);
		return filePath;
	}


	 @Override
	public List<TerminationModel> populateTermDBData(List<TerminationModel> dataList){
		 List<TerminationModel> finalList = new ArrayList<>();
		 try{
			 for(TerminationModel termMdl:dataList) {
				 List<AppStatusModel> mdlLst = null;
				 /*if(termMdl.getResourceName().contains("HCSOP62")) {
					//Insert data in Missing records Table
					 //continue;
					 String result = terminationsDao.insertMissingData(termMdl);
					 log.info("Saved Data for User : "+termMdl.getAccName()+" : HCSOP62 ");
				 }*/
				 mdlLst =  terminationsDao.findTermUserData(termMdl.getAccName(), termMdl.getResourceName().trim().toUpperCase());
				 if(mdlLst == null || mdlLst.isEmpty()) {
					 mdlLst =  terminationsDao.findTermNagsData(termMdl.getAccName(), termMdl.getResourceName().trim().toUpperCase());
					 if(mdlLst == null || mdlLst.isEmpty()) {
						 mdlLst =  terminationsDao.findTermMissingUserData(termMdl.getAccName(), termMdl.getResourceName().trim().toUpperCase());
						 if(mdlLst == null || mdlLst.isEmpty()) {
							 mdlLst = terminationsDao.getUserJJEDSData(termMdl.getAccName(), termMdl.getResourceName().trim().toUpperCase());
							 if(!mdlLst.isEmpty()) {
								for(AppStatusModel appM : mdlLst) {
									 appM.setEmpStatus("NOT FOUND");
								}
							 }
						 }
					 }
				 }
				 termMdl.setAppstat(mdlLst);
				 finalList.add(termMdl);
			 }
		 }catch (Exception e) {
			 System.out.println("ERROR Loading Data:"+e.getMessage()+"\n");
			 e.printStackTrace();
		 }
		 return finalList;
	 }



	/* public List<TerminationModel> populateTermDBData(Map<String, TerminationModel> dataMap){
		 List<TerminationModel> finalList = new ArrayList<TerminationModel>();
		 try{
			 for(Map.Entry<String,TerminationModel> entry : dataMap.entrySet()) {
				 String accName = entry.getKey();
				 TerminationModel tMdl = (TerminationModel)entry.getValue();
				 List<AppStatusModel> mdlLst =  terminationsDao.findTermUserData(accName, tMdl.getResourceName().trim().toUpperCase());
				 if(mdlLst == null || mdlLst.isEmpty()) {
					 mdlLst =  terminationsDao.findTermNagsData(accName, tMdl.getResourceName().trim().toUpperCase());
					 if(mdlLst == null || mdlLst.isEmpty()) {
						 mdlLst = terminationsDao.getUserJJEDSData(accName, tMdl.getResourceName().trim().toUpperCase());
						 if(!mdlLst.isEmpty()) {
							 for(AppStatusModel appM : mdlLst) {
								 appM.setEmpStatus("NOT FOUND");
							}
						 }
					 }
				 }
				 tMdl.setAppstat(mdlLst);
				 finalList.add(tMdl);
			 }
		 }catch (Exception e) {
			 System.out.println("ERROR Loading Data:"+e.getMessage()+"\n");
			 e.printStackTrace();
		 }
		 return finalList;
	 }*/


	 //public Map<String, TerminationModel> loadTerminationFile(String path){
	 @Override
	public List<TerminationModel> loadTerminationFile(String path){
			Workbook nFile = Utility.loadFile(path);
			Sheet dsheet = nFile.getSheetAt(0);
			//Map <String, TerminationModel> dataMap = new HashMap<String, TerminationModel>();
			List<TerminationModel> termData = new ArrayList<>();
			int i = 0;
			if(dsheet != null) {
				int rowTotal = dsheet.getLastRowNum();
				if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
				    rowTotal++;
				}
				System.out.println("Total number of Rows: "+rowTotal);

				for(Row rw:dsheet) {
					if(i<1) {//Skipping Header Row
						i++;
						continue;
					}
					TerminationModel tmdl = new TerminationModel();
					String crNm		= Utility.getCellValue(rw.getCell(0));
					String appNm 	= Utility.getCellValue(rw.getCell(1));
					String reqTyp 	= Utility.getCellValue(rw.getCell(2));
					String accOwner	= Utility.getCellValue(rw.getCell(3));
					String accNm 	= Utility.getCellValue(rw.getCell(4));
					String accStat 	= Utility.getCellValue(rw.getCell(5));
					String resourceNm= Utility.getCellValue(rw.getCell(6));
					String grpNm  	= Utility.getCellValue(rw.getCell(7));
					String crstat	= Utility.getCellValue(rw.getCell(8));
					String crdtopen	= Utility.getCellValue(rw.getCell(9));
					String crdtcomp = Utility.getCellValue(rw.getCell(10));
					String notes 	= Utility.getCellValue(rw.getCell(11));

					tmdl.setCrName(crNm);
					tmdl.setAppName(appNm.toUpperCase());
					tmdl.setReqType(reqTyp.toUpperCase());
					tmdl.setAccOwner(accOwner.toUpperCase());

					String winID = "";
					if(null != accNm && accNm.length() >0) {
						String[] nmArr = accNm.split(":");
						if(nmArr != null && nmArr.length > 0 ) {
							winID = nmArr[(nmArr.length -1 )].trim();
						}
					}

					tmdl.setAccName(winID.trim().toUpperCase());
					tmdl.setAccStatus(accStat);
					tmdl.setResourceName(resourceNm);
					tmdl.setGroupName(grpNm);
					tmdl.setCrStatus(crstat);
					tmdl.setCrDateOpen(crdtopen);
					tmdl.setCrDateCompleted(crdtcomp);
					tmdl.setNotes(notes);

					//dataMap.put(tmdl.getAccName(), tmdl);
					termData.add(tmdl);
					i++;
				}
			}
			//return dataMap;
			return termData;
		}



}
