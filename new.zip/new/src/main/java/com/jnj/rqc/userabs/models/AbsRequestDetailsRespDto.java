package com.jnj.rqc.userabs.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AbsRequestDetailsRespDto {
	private int 	statusCode;
	private String	message;
	private String 	datetimeStamp;
	private String 	statusDesc;
	private String 	developerMessage;
	private String IsCompilanceMgr;
	private AbsUserReqMdl reqData;
}
