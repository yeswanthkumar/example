package com.jnj.rqc.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.constants.AuthRespMdl;
import com.jnj.rqc.constants.AuthStrMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserIdentityDao;
import com.jnj.rqc.security.IAMAuthenticatorBean;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserIdentityService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.useridentity.models.UIRequestDispModel;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;




/**
 * File    : <b>ExchangeDataController.java</b>
 * @author : DChauras @Created : Jun 16, 2022 2:49:26 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class ExchangeDataController {
	static final Logger log = LoggerFactory.getLogger(ExchangeDataController.class);
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	UserIdentityService userIdentityService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	UserIdentityDao userIdentityDao;

	/*@Autowired
	RestTemplate restTemplate;*/
	@Autowired
	RestTemplate restHttpTemplate;

	@Autowired
	IAMAuthenticatorBean iAMAuthenticatorBean;



	public void submitApprovedReqToGRCIAM(List<UIRequestDispModel> allReqLst) {
		log.info("Process Request");
   	 	long start = System.currentTimeMillis();
   	 	//iAMAuthenticatorBean = iAMAuthenticatorBean.initIAMAuth(restHttpTemplate);
   	 	for(UIRequestDispModel reqMdl : allReqLst) {
   	 		boolean result = userIdentityService.sendReqDataToIamGrc(reqMdl);
   	 		if(result) {
   	 			userIdentityService.updateIamRequestStatus(reqMdl.getReqId(), Constants.ROUTED_IAM_GRC);//Status updating to : Submitted To IAM
   	 		}
   	 	}
   	 	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
   	 	log.info("Session ID: "+iAMAuthenticatorBean.getSessId());
	}


	public void getSubmittedReqStatusGRCIAM(List<UIRequestDispModel> allReqLst) {
		log.info("Get Request Status from IAM");
   	 	long start = System.currentTimeMillis();
   	 	for(UIRequestDispModel reqMdl : allReqLst) {
   	 		boolean result = userIdentityService.getReqStatusFromIamGrc(reqMdl);//getReqStatusFromIamGrc
   	 		if(result) {
   	 			int totCount = userIdentityService.getRequestCount(reqMdl.getReqId()+"");
   	 			List<String> comStatList = userIdentityService.getCompltdReqStat(reqMdl.getReqId()+"");
   	 			if(!comStatList.isEmpty() && totCount == comStatList.size()) {
   	 				int updateStatus = 7;//Request Complete
   	 				for(String st : comStatList) {
   	 					if(st.equals(Constants.ST_ERROR)) {
   	 						updateStatus = 8;//Completed With Error
   	 					}
   	 				}
   	 				userIdentityService.updateIamRequestStatus(reqMdl.getReqId(), updateStatus);//Status updating to : Submitted To IAM
   	 			}
   	 		}
   	 	}
   	 	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
   	 	log.info("Session ID: "+iAMAuthenticatorBean.getSessId());
	}

		/**
		 * Method  : ExchangeDataController.java.getIamRequestSession()
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :Jun 22, 2022 2:50:03 PM
		 * Purpose : Connects to IAM if not connected and get new SessionID.
		 * @return : String
		 */
	public String getIamRequestSession() {
    	log.info("Connecting to IDMS System");
    	long start = System.currentTimeMillis();
    	iAMAuthenticatorBean = iAMAuthenticatorBean.initIAMAuth(restHttpTemplate);
    	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    	log.info("Session ID: "+iAMAuthenticatorBean.getSessId());
    	return iAMAuthenticatorBean.getSessId();
    }


	@GetMapping("/login2Iam")
    public String connctToIam(Model model,  HttpServletRequest req) {//Test Method
    	log.info("Login to IDMS");
    	 long start = System.currentTimeMillis();
    	iAMAuthenticatorBean = iAMAuthenticatorBean.initIAMAuth(restHttpTemplate);
    	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    	log.info("Session ID: "+iAMAuthenticatorBean.getSessId());
    	/*log.info("RETRY......!");
    	start = System.currentTimeMillis();
    	iAMAuthenticatorBean = iAMAuthenticatorBean.initIAMAuth(restHttpTemplate);
    	log.info("<<<<<<<<<<  Total time taken to RE-Connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    	log.info("Session ID2: "+iAMAuthenticatorBean.getSessId());*/

    	return "home";
    }




	public HttpHeaders getHeaders(String mediaTyp, String sessionId) {
		HttpHeaders headers = new HttpHeaders();
		if(Utility.isEmpty(mediaTyp) || "JSON".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}else if("TEXT".equals(mediaTyp)) {
			headers.setContentType(MediaType.TEXT_PLAIN);
		}

		if(!Utility.isEmpty(sessionId)) {
			//'Cookie': `ss-id=${IAMSessionID}`
			headers.add("Cookie", "ss-id="+sessionId);
			//headers.add("sessionId", sessionId);
		}
		return headers;
	}



	/*@GetMapping("/login2Iam")
    public String connctToIam(Model model,  HttpServletRequest req) {
    	log.info("Login to IDMS ");
    	iAMAuthenticatorBean = iAMAuthenticatorBean.intiIAMAuth(restHttpTemplate);
    	log.info("Session ID: "+iAMAuthenticatorBean.getSessId());

    	//String str ="{\"AuthString\":  \"Module=RoleBasedManualADS;User=JNJ\\\\SA-HCS-SOD_DB_USER; Password=System#321\"}";
    	 try{
    		 Gson gson = new Gson();
        	 AuthStrMdl mdl= new AuthStrMdl();
        	 mdl.setAuthString(Constants.IAM_MODULE+Constants.IAM_USER+Constants.IAM_PWD);
    		 String reqElement = gson.toJson(mdl);
    		 log.info("Request: "+reqElement);

			 // set headers
			 HttpHeaders headers = new HttpHeaders();
			 headers.setContentType(MediaType.APPLICATION_JSON);
			 HttpEntity<String> entity = new HttpEntity<String>(reqElement, headers);

			 // send request and parse result
			 //ResponseEntity<String> authResp = restTemplate.exchange(authURL, HttpMethod.POST, entity, String.class);
			 ResponseEntity<String> authResp = restHttpTemplate.exchange(Constants.authURL, HttpMethod.POST, entity, String.class);

			 if (authResp != null && authResp.getStatusCode() == HttpStatus.OK) {
				 AuthRespMdl resp = new AuthRespMdl();
				 resp = gson.fromJson(authResp.getBody(), AuthRespMdl.class);
				 log.info("resp.objMdl :"+resp.getUserName()+" Session ID: "+resp.getSessionId());
			 }
    	 }catch(Exception ex) {
    		 log.error("Exception "+ ex.getMessage(), ex);
    	 }
		 return "home";
    }
*/

	public boolean loginToIam() {
		//String str ="{\"AuthString\":  \"Module=RoleBasedManualADS;User=JNJ\\\\SA-HCS-SOD_DB_USER; Password=System#321\"}";
    	log.info("Login to IDMS ");
    	boolean success=true;
    	 try{
    		 Gson gson = new Gson();
        	 AuthStrMdl mdl= new AuthStrMdl();
        	 mdl.setAuthString(Constants.IAM_MODULE+Constants.IAM_USER+Constants.IAM_PWD);

    		 String reqElement = gson.toJson(mdl);
    		 log.info("Request: "+reqElement);

			 // set headers
			 HttpHeaders headers = new HttpHeaders();
			 headers.setContentType(MediaType.APPLICATION_JSON);
			 HttpEntity<String> entity = new HttpEntity<>(reqElement, headers);

			 // send request and parse result
			 //ResponseEntity<String> authResp = restTemplate.exchange(authURL, HttpMethod.POST, entity, String.class);
			 ResponseEntity<String> authResp = restHttpTemplate.exchange(Constants.authURLIAM, HttpMethod.POST, entity, String.class);

			 if (authResp != null && authResp.getStatusCode() == HttpStatus.OK) {
				 //log.info("authResp.body :"+authResp.getBody());
				 AuthRespMdl resp = new AuthRespMdl();
				 resp = gson.fromJson(authResp.getBody(), AuthRespMdl.class);
				 log.info("resp.objMdl :"+resp.getUserName()+" Session ID: "+resp.getSessionId());
			 }else {
				 success = false;
			 }
    	 }catch(Exception ex) {
    		 log.error("Exception "+ ex.getMessage(), ex);
    		 success = false;
		 }
		 return success;
    }


	/*START - Adding All New Methods for Data Collection HERE*/


	/*END - Adding All New Methods for Data Collection HERE*/




  }
