package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZSysPosAccessMdl {
	String sysid;
	String posid;
	String accid;
	String accname;
	String accdesc;


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZSysPosAccessMdl other = (ZSysPosAccessMdl) obj;
		if (accdesc == null) {
			if (other.accdesc != null)
				return false;
		} else if (!accdesc.equals(other.accdesc))
			return false;
		if (accid == null) {
			if (other.accid != null)
				return false;
		} else if (!accid.equals(other.accid))
			return false;
		if (accname == null) {
			if (other.accname != null)
				return false;
		} else if (!accname.equals(other.accname))
			return false;
		if (posid == null) {
			if (other.posid != null)
				return false;
		} else if (!posid.equals(other.posid))
			return false;
		if (sysid == null) {
			if (other.sysid != null)
				return false;
		} else if (!sysid.equals(other.sysid))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accdesc == null) ? 0 : accdesc.hashCode());
		result = prime * result + ((accid == null) ? 0 : accid.hashCode());
		result = prime * result + ((accname == null) ? 0 : accname.hashCode());
		result = prime * result + ((posid == null) ? 0 : posid.hashCode());
		result = prime * result + ((sysid == null) ? 0 : sysid.hashCode());
		return result;
	}




}