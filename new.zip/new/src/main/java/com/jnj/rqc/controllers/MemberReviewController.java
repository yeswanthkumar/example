package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.models.BstMetricsModel;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.service.MemberReviewService;
import com.jnj.rqc.util.Utility;


@Controller
public class MemberReviewController {
	static final Logger log = LoggerFactory.getLogger(MemberReviewController.class);
	@Autowired
	MemberReviewService memberReviewService;


	@GetMapping("/ymdBstMetrics")
    public String ymdBstMetrics(Model model) {
    	log.info("Routing to YMD BST Metrics .");
    	return "userreview/ymdBstMetrics";
    }


	@PostMapping("/ymdBstMetricsData")
    public String ymdBstMetricsData(@RequestParam("file") MultipartFile file, Model model, HttpServletRequest request) {
    	log.info("Selected YMD BST Metrics file :"+file.getOriginalFilename());

    	if (file.isEmpty()) {
    		log.info("FILE is missing.");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Status: XLS file are required!");
            return "userreview/ymdBstMetrics";
        }

    	String ext =file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
    		model.addAttribute("message", "True");
    		model.addAttribute("error", "Status: Not a valid excel file!");
            return "userreview/ymdBstMetrics";
    	}
    	try{
    		String path = memberReviewService.saveFile(file);
    		List<BstMetricsModel> result = memberReviewService.processBstMetricsData(path, request);
    		HttpSession session = request.getSession();
    		if(result != null && !result.isEmpty()) {
    			session.setAttribute("BSTDATA", result);
    		}

    		model.addAttribute("selFile", file);
    		model.addAttribute("BSTDATA", result);
    		model.addAttribute("message", "True");
    		model.addAttribute("success", "Status: Processing successful - " + file.getOriginalFilename());
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "userreview/ymdBstMetrics";
    }

	@ResponseBody
    @GetMapping("/downloadBstExcel")
    public ResponseEntity<InputStreamResource> downloadBstExcel(Model model, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<BstMetricsModel> result = (List<BstMetricsModel>)request.getSession().getAttribute("BSTDATA");
    	String filePath = memberReviewService.writeBstCsv(result);
    	log.info("Starting download CSV file :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


    @GetMapping("/uploadMemReview")
    public String gotoUpload(Model model) {
    	log.info("Routing to NAGs Upload page.");
    	List<KeyValPair> months = Utility.getMonthList();
    	List<KeyValPair> years = Utility.getYearList();
    	model.addAttribute("months", months);
    	model.addAttribute("years", years);
    	return "userreview/nagsupload";
    }

    @PostMapping("/nagsupload")
    public String singleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam("months") int mon, @RequestParam("years") int yrs, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Selected NAGs file :"+file.getOriginalFilename()+" for Month:"+mon+"  Year:"+yrs);

    	if (file.isEmpty() || mon<1 || yrs<1) {
    		log.info("MONTH/YEAR/FILE one of the parameter missing.");
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("error", "Status: Month, Year and XLS file are required!");
            return "redirect:uploadMemStatus";
        }

    	String ext =file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".")+1);
    	if(!"xlsx".equalsIgnoreCase(ext)) {
    		log.info("NOT a Valid Excel file.");
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("error", "Status: Not a valid excel file!");
            return "redirect:uploadMemStatus";
    	}
    	try{
    		String path = Utility.saveFile(file);
    		List<MemRevieModel> result = memberReviewService.processNagsData(path, mon, yrs, request);
    		HttpSession session = request.getSession();
    		session.removeAttribute("NAGSREVIEWDATA");
    		session.setAttribute("NAGSREVIEWDATA", result);
    		session.setAttribute("MON", mon);
    		session.setAttribute("YRS", yrs);
    		redirectAttributes.addFlashAttribute("selMon", mon);
    		redirectAttributes.addFlashAttribute("selYear", yrs);
    		redirectAttributes.addFlashAttribute("selFile", file);
    		redirectAttributes.addFlashAttribute("result", result);
            redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("success", "Status: Uploaded successful - " + file.getOriginalFilename());
        } catch (Exception e) {
            log.error("Error uploading file :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "redirect:/uploadMemStatus";
    }

    @GetMapping("/uploadMemStatus")
    public String uploadStatus(Model model) {
    	List<KeyValPair> months = Utility.getMonthList();
    	List<KeyValPair> years = Utility.getYearList();
    	model.addAttribute("months", months);
    	model.addAttribute("years", years);
        return "userreview/nagsupload";
    }


    @ResponseBody
    @GetMapping("/downloadMemExcel")
    public ResponseEntity<InputStreamResource> downloadExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<MemRevieModel> result = (List<MemRevieModel>)request.getSession().getAttribute("NAGSREVIEWDATA");
    	int mon = (Integer)request.getSession().getAttribute("MON");
    	int yrs = (Integer)request.getSession().getAttribute("YRS");
    	String filePath = memberReviewService.writePdfOrCsv("XLS", mon, yrs, result);

    	log.info("Starting download CSV file :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

    @ResponseBody
    @GetMapping("/downloadMemPdf")
    public ResponseEntity<InputStreamResource> downloadPdf(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<MemRevieModel> result = (List<MemRevieModel>)request.getSession().getAttribute("NAGSREVIEWDATA");
    	int mon = (Integer)request.getSession().getAttribute("MON");
    	int yrs = (Integer)request.getSession().getAttribute("YRS");
    	String filePath = memberReviewService.writePdfOrCsv("PDF", mon, yrs, result);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.APPLICATION_PDF)
        	.contentLength(fl.length())
        	.body(resource);
    }


    //Method Created for Getting SRC_SYS wise Member Role Assignments
    @GetMapping("/srcMemWiseAppRoles")
    public String memReport(Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Starting srcMemWiseAppRoles ");

    		List<String> srcSystem = Utility.getSourceSystems();
    		srcSystem.forEach(sysID ->{
    			try{
    				log.info("<======== Starting Report for SRC_SYS :"+sysID+" ========>");
    				List<SrcSysMemRoleModel> result = memberReviewService.processMemReport(sysID);
    				String filePath = memberReviewService.writeCsvReport(result, sysID);
    				log.info("filePath: "+filePath);
    				log.info("<======== Completed Report for SRC_SYS :"+sysID+" ========>");
    				//redirectAttributes.addFlashAttribute("result", result);

    			} catch (Exception e) {
    	            log.error("Error uploading file :"+e.getMessage(), e);
    	        	e.printStackTrace();
    	        }
    		});
    		redirectAttributes.addFlashAttribute("message", "True");
            redirectAttributes.addFlashAttribute("success", "Status: SUCCESS");

        return "";
    }





}