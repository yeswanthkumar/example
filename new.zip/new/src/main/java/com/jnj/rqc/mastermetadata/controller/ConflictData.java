package com.jnj.rqc.mastermetadata.controller;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConflictData {
		@JsonProperty("RISKID")
	    private String RISKID;

		@JsonProperty("RISKDESC")
	    private String RISKDESC;

		@JsonProperty("APP1")
	    private String APP1;

		@JsonProperty("APPNAME1")
	    private String APPNAME1;

		@JsonProperty("POSV1")
	    private String POSV1;

		@JsonProperty("POSVNAME1")
	    private String POSVNAME1;

		@JsonProperty("APP2")
	    private String APP2;

		@JsonProperty("APPNAME2")
	    private String APPNAME2;

		@JsonProperty("POSV2")
	    private String POSV2;

		@JsonProperty("POSVNAME2")
	    private String POSVNAME2;

		@JsonProperty("CONFLICT")
	    private String CONFLICT;

		@JsonProperty("RISK_LEVEL")
	    private String RISK_LEVEL;

		@JsonProperty("MIT_ID")
	    private String MIT_ID;

		@JsonProperty("MIT_DESC")
	    private String MIT_DESC;

		@JsonProperty("CREATEDON")
	    private Date CREATEDON;

	    public String getRISKID() {
	        return RISKID;
	    }

	    public void setRISKID(String RISKID) {
	        this.RISKID = RISKID;
	    }

	    public String getRISKDESC() {
	        return RISKDESC;
	    }

	    public void setRISKDESC(String RISKDESC) {
	        this.RISKDESC = RISKDESC;
	    }

	    public String getAPP1() {
	        return APP1;
	    }

	    public void setAPP1(String APP1) {
	        this.APP1 = APP1;
	    }

	    public String getAPPNAME1() {
	        return APPNAME1;
	    }

	    public void setAPPNAME1(String APPNAME1) {
	        this.APPNAME1 = APPNAME1;
	    }

	    public String getPOSV1() {
	        return POSV1;
	    }

	    public void setPOSV1(String POSV1) {
	        this.POSV1 = POSV1;
	    }

	    public String getPOSVNAME1() {
	        return POSVNAME1;
	    }

	    public void setPOSVNAME1(String POSVNAME1) {
	        this.POSVNAME1 = POSVNAME1;
	    }

	    public String getAPP2() {
	        return APP2;
	    }

	    public void setAPP2(String APP2) {
	        this.APP2 = APP2;
	    }

	    public String getAPPNAME2() {
	        return APPNAME2;
	    }

	    public void setAPPNAME2(String APPNAME2) {
	        this.APPNAME2 = APPNAME2;
	    }

	    public String getPOSV2() {
	        return POSV2;
	    }

	    public void setPOSV2(String POSV2) {
	        this.POSV2 = POSV2;
	    }

	    public String getPOSVNAME2() {
	        return POSVNAME2;
	    }

	    public void setPOSVNAME2(String POSVNAME2) {
	        this.POSVNAME2 = POSVNAME2;
	    }

	    public String getCONFLICT() {
	        return CONFLICT;
	    }

	    public void setCONFLICT(String CONFLICT) {
	        this.CONFLICT = CONFLICT;
	    }

	    public String getRISK_LEVEL() {
	        return RISK_LEVEL;
	    }

	    public void setRISK_LEVEL(String RISK_LEVEL) {
	        this.RISK_LEVEL = RISK_LEVEL;
	    }

	    public String getMIT_ID() {
	        return MIT_ID;
	    }

	    public void setMIT_ID(String MIT_ID) {
	        this.MIT_ID = MIT_ID;
	    }

	    public String getMIT_DESC() {
	        return MIT_DESC;
	    }

	    public void setMIT_DESC(String MIT_DESC) {
	        this.MIT_DESC = MIT_DESC;
	    }

	    public Date getCREATEDON() {
	        return CREATEDON;
	    }

	    public void setCREATEDON(Date CREATEDON) {
	        this.CREATEDON = CREATEDON;
	    }

}
