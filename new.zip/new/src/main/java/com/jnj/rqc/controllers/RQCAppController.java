package com.jnj.rqc.controllers;


import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.models.AppDataModel;
import com.jnj.rqc.models.SearchUserName;
import com.jnj.rqc.models.User;
import com.jnj.rqc.responseDto.UserNameRespDto;
import com.jnj.rqc.service.ADUserService;
import com.jnj.rqc.service.ApplDataService;


@Controller
public class RQCAppController {
	static final Logger log = LoggerFactory.getLogger(RQCAppController.class);
	@Autowired
	ADUserService userService;

	@Autowired
	ApplDataService applDataService;

    @GetMapping("/rqcUserInfo")
    public String getRQCAppUserInfo(Model model, HttpServletRequest req) {
    	log.info("Routing to RQC User Info page.");
    	/*System.out.println("Principal :"+req.getUserPrincipal().getName());
    	String userName = new com.sun.security.auth.module.NTSystem().getName();
    	System.out.println("NTSystem User: "+userName);*/
    	User loggedInUsr = userService.searchUserById(System.getProperty("user.name"));
    	log.info("User Info: "+loggedInUsr);
    	req.getSession().setAttribute("LoggedInUser", loggedInUsr);
    	return "rqc/appUserView";
    }

    @PostMapping("/rqcUserDetails")
    public ResponseEntity<UserNameRespDto> getRQCAppUserDetail(Model model,  @RequestBody SearchUserName searchUserName, HttpServletRequest req) {
    	log.info("Received userName: "+searchUserName.getUserName());
    	UserNameRespDto userRespDto = userService.searchUserByName(searchUserName.getUserName().trim());

    	if (userRespDto.getStatusCode() == 0) {
			return new ResponseEntity<>(userRespDto, HttpStatus.OK);
        } else if (userRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(userRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(userRespDto, HttpStatus.NOT_FOUND);
        }

    }


    @PostMapping("/userJustification")
    public String getUserJustification(@RequestParam("assoWwid") String assoWwid, RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	log.info("Displaying User Justification Page  for assoWwid:"+assoWwid);
    	if(null==assoWwid || assoWwid.length()==0) {
    		request.setAttribute("ERROR", "Please select/enter Associate's first and/or last name or WWID");
    		return "rqc/appUserView";
    	}
    	User associate = userService.searchUserByWWID(assoWwid);
    	request.getSession().setAttribute("Associate", associate);
    	User mgr = userService.searchUserByWWID(associate.getMgrId());
    	request.getSession().setAttribute("AssoMgr", mgr);
    	Calendar cal=Calendar.getInstance();
    	cal.add(Calendar.DATE, 5);
    	Date rqstDt = new Date(cal.getTimeInMillis());
    	request.getSession().setAttribute("needDt", rqstDt);
        return "rqc/appUserJustificationView";
    }





    @PostMapping("/getRQCSoftwares")
    public String getSoftwareList(@RequestParam("reqstd_evnt_dt") Date reqDate, @RequestParam("submit_dt") Date submDate,
    		@RequestParam("justification") String justification, @RequestParam("comments") String comments, RedirectAttributes redirectAttributes, HttpServletRequest request, Model model)
    {
    	log.info("Getting Software List ");
    	log.debug("Params  reqDate: "+reqDate+"  submDate: "+submDate+"\n  justification: "+justification+"\n  comments: "+comments);
    	int rqcTktNumber = 6578902;
    	request.getSession().setAttribute("RQCTktNumber", rqcTktNumber+"");
    	request.getSession().setAttribute("BussJustif", justification);
    	request.getSession().setAttribute("Comments", comments);

    	Map<String, List<AppDataModel>> allAppMap = applDataService.getApplicationData(rqcTktNumber);
    	model.addAttribute("allAppMap", allAppMap);

    	User associate = (User)request.getSession().getAttribute("Associate");
    	User mgr = (User)request.getSession().getAttribute("AssoMgr");
    	Calendar cal=Calendar.getInstance();
    	cal.add(Calendar.DATE, 5);
    	Date rqstDt = new Date(cal.getTimeInMillis());
    	return "rqc/appSoftwareDeckSelection";
    }

/*
    @GetMapping("/uploadMemStatus")
    public String uploadStatus(Model model) {
    	List<KeyValPair> months = Utility.getMonthList();
    	List<KeyValPair> years = Utility.getYearList();
    	model.addAttribute("months", months);
    	model.addAttribute("years", years);
        return "userreview/nagsupload";
    }


    @ResponseBody
    @GetMapping("/downloadMemExcel")
    public ResponseEntity<InputStreamResource> downloadExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
    	List<NagsModel> result = (List<NagsModel>)request.getSession().getAttribute("NAGSREVIEWDATA");
    	int mon = (Integer)request.getSession().getAttribute("MON");
    	int yrs = (Integer)request.getSession().getAttribute("YRS");
    	String filePath = memberReviewService.writePdfOrCsv("XLS", mon, yrs, result);

    	log.info("Starting download CSV file :"+filePath);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

    */


}