package com.jnj.rqc.dbextr.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dbextr.handlers.CCRAConversionHandler;
import com.jnj.rqc.dbextr.handlers.CCRAExtractHandler;
import com.jnj.rqc.dbextr.handlers.CCRAStageHandler;
import com.jnj.rqc.dbextr.handlers.ConflictMatrixHandler;
import com.jnj.rqc.dbextr.handlers.F0005Handler;
import com.jnj.rqc.dbextr.handlers.F00821Handler;
import com.jnj.rqc.dbextr.handlers.F0082Handler;
import com.jnj.rqc.dbextr.handlers.F983051Handler;
import com.jnj.rqc.dbextr.handlers.F9860Handler;
import com.jnj.rqc.dbextr.handlers.F9861Handler;
import com.jnj.rqc.dbextr.handlers.F9865Handler;
import com.jnj.rqc.dbextr.handlers.SystemCodeHandler;


@Service
public class DBExtFactory {
	static final Logger log = LoggerFactory.getLogger(DBExtFactory.class);

	@Autowired
	SystemCodeHandler systemCodeHandler;
	@Autowired
	ConflictMatrixHandler conflictMatrixHandler;
	@Autowired
	CCRAConversionHandler cCRAConversionHandler;
	@Autowired
	CCRAExtractHandler cCRAExtractHandler;
	@Autowired
	CCRAStageHandler cCRAStageHandler;

	//JDE- OBJ7333
	@Autowired
	F9860Handler f9860Handler;
	@Autowired
	F9861Handler f9861Handler;
	@Autowired
	F9865Handler f9865Handler;
	@Autowired
	F983051Handler f983051Handler;
	@Autowired
	F0005Handler f0005Handler;
	@Autowired
	F0082Handler f0082Handler;
	@Autowired
	F00821Handler f00821Handler;
	public IDBExtProcessor getProcessor(String tableName) {
		IDBExtProcessor proc = null;
		if(tableName.equals("SYSTEM_CODE")) {

			proc = systemCodeHandler;
		}else if(tableName.equals("CONFLICT_MATRIX")) {
			proc = conflictMatrixHandler;
		}else if(tableName.equals("CCRA_CONVERSION")) {
			proc = cCRAConversionHandler;
		}else if(tableName.equals("CCRA_EXTR_MV")) {
			proc = cCRAExtractHandler;
		}else if(tableName.equals("CCRA_STAGE")) {
			proc = cCRAStageHandler;
		}
		//JDE-OBJ7333
		else if(tableName.equals("F9860")) {
			proc = f9860Handler;
		}else if(tableName.equals("F9861")) {
			proc = f9861Handler;
		}else if(tableName.equals("F9865")) {
			proc = f9865Handler;
		}

		//JDE-PD7333
		else if(tableName.equals("F983051")) {
			proc = f983051Handler;
		}
		//PDCTL : F0005,F0082,F00821,F0083,F9000,F9001,F9005,F9006
		else if(tableName.equals("F0005")) {
			proc = f0005Handler;
		}else if(tableName.equals("F0082")) {
			proc = f0082Handler;
		}else if(tableName.equals("F00821")) {
			proc = f00821Handler;

		}else if(tableName.equals("F0005")) {
			proc = f0005Handler;
		}	else if(tableName.equals("F0005")) {
			proc = f0005Handler;
		}else if(tableName.equals("F0005")) {
			proc = f0005Handler;
		}else if(tableName.equals("F0005")) {
			proc = f0005Handler;
		}





		return proc;
	}


}
