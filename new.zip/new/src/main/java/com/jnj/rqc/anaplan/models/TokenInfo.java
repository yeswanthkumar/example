package com.jnj.rqc.anaplan.models;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TokenInfo {
	private long expiresAt ;
	private String tokenId;
	private String tokenValue;
	private String refreshTokenId;
}
