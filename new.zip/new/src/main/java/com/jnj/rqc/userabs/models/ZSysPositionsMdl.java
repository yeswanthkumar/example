package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZSysPositionsMdl {
	String sysid;
	String posid;
	String posname;
	String posdesc;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZSysPositionsMdl other = (ZSysPositionsMdl) obj;
		if (posdesc == null) {
			if (other.posdesc != null)
				return false;
		} else if (!posdesc.equals(other.posdesc))
			return false;
		if (posid == null) {
			if (other.posid != null)
				return false;
		} else if (!posid.equals(other.posid))
			return false;
		if (posname == null) {
			if (other.posname != null)
				return false;
		} else if (!posname.equals(other.posname))
			return false;
		if (sysid == null) {
			if (other.sysid != null)
				return false;
		} else if (!sysid.equals(other.sysid))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((posdesc == null) ? 0 : posdesc.hashCode());
		result = prime * result + ((posid == null) ? 0 : posid.hashCode());
		result = prime * result + ((posname == null) ? 0 : posname.hashCode());
		result = prime * result + ((sysid == null) ? 0 : sysid.hashCode());
		return result;
	}





}