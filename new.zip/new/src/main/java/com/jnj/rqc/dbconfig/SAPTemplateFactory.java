package com.jnj.rqc.dbconfig;


import com.sap.conn.jco.JCoDestination;

public class SAPTemplateFactory extends SAPBaseDao {

	public JCoDestination getDestination(String templateName) {
		JCoDestination templ= null;

		//TemPlates for SAP ESTRACT gAA

		if("NA_SAPSANDBOX_Sandbox_R3P700".equalsIgnoreCase(templateName)) {
			templ = getDestNA_SAPSANDBOX_Sandbox_R3P700();
		}
		//ATLAS
		else if ("NA_ATLAS_Production_ECCProductionRPVCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_Production_ECCProductionRPVCLNT100();
		}else if ("NA_ATLAS_Production_APOProductionAPVCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_Production_APOProductionAPVCLNT100();
		}else if ("NA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_ProductionTechnicalClients_APOProductionAPVCLNT000();
		}else if ("NA_ATLAS_Production_BIProductionBPVCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_Production_BIProductionBPVCLNT100();
		}else if ("NA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_ProductionTechnicalClients_BIProductionBPVCLNT000();
		}else if ("NA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ATLAS_ProductionTechnicalClients_ECCProductionRPVCLNT000();
		}
		//BIOSENSE
		else if ("NA_BIOSENSE_Production_BWIILCLNT400".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BIOSENSE_Production_BWIILCLNT400();
		}
		//BIOSENSE
		//USROTC
		else if ("NA_USROTC_Production_ECCProductionMP2CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_USROTC_Production_ECCProductionMP2CLNT100();
		}
		else if ("NA_USROTC_Production_CRMProductionMP8CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_USROTC_Production_CRMProductionMP8CLNT100();
		}

		else if ("NA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_USROTC_ProductionTechnicalClients_ECCProductionMP2CLNT000();
		}

		else if ("NA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_USROTC_ProductionTechnicalClients_CRMProductionMP8CLNT000();
		}

		//CONCOURSE
		else if ("NA_Concourse_Production_ATTProductionP23CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_Concourse_Production_ATTProductionP23CLNT100();
		}else if ("NA_Concourse_Production_ATTProductionP24CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_Concourse_Production_ATTProductionP24CLNT100();
		}else if ("NA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_Concourse_ProductionTechnicalClients_ATTProductionP23CLNT000();
		}else if ("NA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_Concourse_ProductionTechnicalClients_ATTProductionP24CLNT000();
		}


		//CROSSROAD
		else if ("NA_CROSSROAD_Production_ECCProductionRPUCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_CROSSROAD_Production_ECCProductionRPUCLNT100();
		}else if ("NA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_CROSSROAD_ProductionTechnicalClients_ECCProductionRPUCLNT000();
		}

		//BTB GLOBAL
		else if ("NA_BTBGLOBAL_Production_SCMProductionAPUCLNT300".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_SCMProductionAPUCLNT300();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_SCMProductionAPUCLNT000();
		}
		else if ("NA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_BWonHANAProductionB3GCLNT550();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_BWonHANAB3GCLNT000();
		}

		else if ("NA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_BWforAPOProductionBPUCLNT400();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_BWforAPOBPUCLNT000();
		}

		else if ("NA_BTBGLOBAL_Production_GTSProductionNP2CLNT650".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_GTSProductionNP2CLNT650();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_GTSProductionNP2CLNT000();
		}


		else if ("NA_BTBGLOBAL_Production_SLTProductionNP3CLNT220".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_SLTProductionNP3CLNT220();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_SLTProductionNP3CLNT000();
		}

		else if ("NA_BTBGLOBAL_Production_MDGProductionP53CLNT750".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_MDGProductionP53CLNT750();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_MDGProductionP53CLNT000();
		}

		else if ("NA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_FSCMProductionRP3CLNT600();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_FSCMProductionRP3CLNT000();
		}

		else if ("NA_BTBGLOBAL_Production_PIProductionXPUCLNT200".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_Production_PIProductionXPUCLNT200();
		}else if ("NA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBGLOBAL_ProductionTechnicalClients_PIProductionXPUCLNT000();
		}


		//BTB LERCAN
		else if ("NA_BTBLERCAN_Production_CRMProductionP51CLNT500".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBLERCAN_Production_CRMProductionP51CLNT500();
		}else if ("NA_BTBLERCAN_Production_ECCProductionP50CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBLERCAN_Production_ECCProductionP50CLNT100();
		}else if ("NA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBLERCAN_ProductionTechnicalClients_CRMProductionP51CLNT000();
		}else if ("NA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_BTBLERCAN_ProductionTechnicalClients_ECCProductionP50CLNT000();
		}

		//FUSION
		else if ("NA_FUSION_Production_ECCProductionPR1CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_Production_ECCProductionPR1CLNT100();
		}else if ("NA_FUSION_Production_CRMProductionPC1CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_Production_CRMProductionPC1CLNT100();
		}else if ("NA_FUSION_Production_BWProductionPB1CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_Production_BWProductionPB1CLNT100();
		}else if ("NA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_ProductionTechnicalClients_ECCProductionPR1CLNT000();
		}else if ("NA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_ProductionTechnicalClients_CRMProductionPC1CLNT000();
		}else if ("NA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_FUSION_ProductionTechnicalClients_BWProductionPB1CLNT000();
		}
		//ANSPACH
		else if ("NA_ANSPACH_Production_ECCProductionR3PCLNT700".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ANSPACH_Production_ECCProductionR3PCLNT700();
		}else if ("NA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_ANSPACH_ProductionTechnicalClients_ECCProductionR3PCLNT000();
		}

		//GLOBAL SOLMAN
		else if ("NA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230".equalsIgnoreCase(templateName)) {
			templ = getDestNA_GLOBALSOLMAN_Production_SolManProductionMPCCLNT230();
		}else if ("NA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_GLOBALSOLMAN_ProductionTechnicalClients_SolManProductionMPCCLNT000();
		}

		//JJSV
		else if ("NA_JJSV_Production_ECCProductionPA2CLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_Production_ECCProductionPA2CLNT050();
		}else if ("NA_JJSV_Production_SCMProductionAPPCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_Production_SCMProductionAPPCLNT050();
		}else if ("NA_JJSV_Production_BWProductionBWPCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_Production_BWProductionBWPCLNT050();
		}


		else if ("NA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_ProductionTechnicalClients_ECCProductionPA2CLNT000();
		}else if ("NA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_ProductionTechnicalClients_SCMProductionAPPCLNT000();
		}else if ("NA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_JJSV_ProductionTechnicalClients_BWProductionBWPCLNT000();
		}
		//LYNX - START
		else if ("NA_LYNX_Production_ECCProductionMP1CLNT010".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_Production_ECCProductionMP1CLNT010();
		}else if ("NA_LYNX_Production_BIProductionGP5CLNT010".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_Production_BIProductionGP5CLNT010();
		}else if ("NA_LYNX_Production_ECCProductionFP3CLNT010".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_Production_ECCProductionFP3CLNT010();
		}else if ("NA_LYNX_Production_BIProductionFP5CLNT010".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_Production_BIProductionFP5CLNT010();
		}else if ("NA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_ProductionTechnicalClients_BIProductionGP5CLNT000();
		}



		else if ("NA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_ProductionTechnicalClients_ECCProductionMP1CLNT000();
		}else if ("NA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_ProductionTechnicalClients_ECCProductionFP3CLNT000();
		}else if ("NA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_LYNX_ProductionTechnicalClients_BIProductionFP5CLNT000();
		}
		//LYNX - END

		//MERCURY - Production -STARTS
		else if ("NA_MERCURY_Production_SCMProductionSPNCLNT400".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_Production_SCMProductionSPNCLNT400();
		}else if ("NA_MERCURY_Production_ECCProductionRPNCLNT120".equalsIgnoreCase(templateName)) {
					templ = getDestNA_MERCURY_Production_ECCProductionRPNCLNT120();
		}else if ("NA_MERCURY_Production_BWProductionBPNCLNT300".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_Production_BWProductionBPNCLNT300();
		}else if ("NA_MERCURY_Production_PIProductionXPNCLNT200".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_Production_PIProductionXPNCLNT200();
		}


		else if ("NA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_ProductionTechnicalClients_SCMProductionSPNCLNT000();
		}

		else if ("NA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_ProductionTechnicalClients_ECCProductionRPNCLNT000();
		}

		else if ("NA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_ProductionTechnicalClients_BWProductionBPNCLNT000();
		}

		else if ("NA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MERCURY_ProductionTechnicalClients_PIProductionXPNCLNT000();
		}

		//MERCURY - Production -END

		// MITEK  - START
		else if ("NA_MITEK_Production_ECCProductionRPOCLNT777".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MITEK_Production_ECCProductionRPOCLNT777();
		}

		else if ("NA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_MITEK_ProductionTechnicalClients_ECCProductionRPOCLNT000();
		}
		// MITEK  - END

		//OURSOURCE - START
		else if ("NA_OURSOURCE_Production_ECCProductionPJ1CLNT280".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_Production_ECCProductionPJ1CLNT280();
		}else if ("NA_OURSOURCE_Production_NGWProductionPJ2CLNT280".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_Production_NGWProductionPJ2CLNT280();
		}else if ("NA_OURSOURCE_Production_BIProductionPJ5CLNT280".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_Production_BIProductionPJ5CLNT280();
		}

		else if ("NA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_ProductionTechnicalClients_ECCProductionPJ1CLNT000();
		}

		else if ("NA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_ProductionTechnicalClients_NGWProductionPJ2CLNT000();
		}

		else if ("NA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_OURSOURCE_ProductionTechnicalClients_BIProductionPJ5CLNT000();
		}
		//OURSOURCE - END

		//LATAM_LATAMPROJECTONE - START
		else if ("LATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_Production_SCMProductionPAPCLNT520();
		}else if ("LATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_Production_BWProductionPBWCLNT620();
		}else if ("LATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_Production_ECCProductionPLACLNT120();
		}


		else if ("LATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_ECCProductionPLACLNT000();
		}else if ("LATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_BWProductionPBWCLNT000();
		}else if ("LATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_LATAMPROJECTONE_ProductionTechnicalClients_SCMProductionPAPCLNT000();
		}
		//LATAM_LATAMPROJECTONE - END

		//BTBLATAM - START
		else if ("LATAM_BTBLATAM_Production_CRMProductionCPGCLNT500".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_Production_CRMProductionCPGCLNT500();
		}else if ("LATAM_BTBLATAM_Production_ECCProductionRPGCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_Production_ECCProductionRPGCLNT100();
		}else if ("LATAM_BTBLATAM_Production_NFEProductionXP2CLNT300".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_Production_NFEProductionXP2CLNT300();
		}

		else if ("LATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_ProductionTechnicalClients_ECCProductionRPGCLNT000();
		}else if ("LATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_ProductionTechnicalClients_CRMProductionCPGCLNT000();
		}else if ("LATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestLATAM_BTBLATAM_ProductionTechnicalClients_NFEProductionXP2CLNT000();
		}

		//BTBLATAM - END

		//BTBJAPAN
		else if ("ASPAC_SYNTHES_Production_ECCProductionMBPCLNT600".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_SYNTHES_Production_ECCProductionMBPCLNT600();
		}else if ("ASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_BTBJAPAN_Production_ECCProductionP60CLNT100();
		}

		else if ("ASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_BTBJAPAN_ProductionTechnicalClients_ECCProductionP60CLNT000();
		}
		//ConsumerASPAC
		else if ("ASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_Production_SCMProductionAPWCLNT888();
		}else if ("ASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_Production_BIProductionPW1CLNT100();
		}else if ("ASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_Production_ECCProductionP00CLNT888();
		}

		else if ("ASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_SCMProductionAPWCLNT000();
		}else if ("ASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_ECCProductionP00CLNT000();
		}else if ("ASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_ConsumerASPAC_ProductionTechnicalClients_BIProductionPW1CLNT000();
		}


		//MARS
		else if ("ASPAC_MARS_Production_ECCProductionEJ1CLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_MARS_Production_ECCProductionEJ1CLNT100();
		}else if ("ASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_MARS_ProductionTechnicalClients_ECCProductionEJ1CLNT000();
		}

		//Panda
		else if ("ASPAC_Panda_Production_BIProductionBP1CLNT600".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_Production_BIProductionBP1CLNT600();
		}else if ("ASPAC_Panda_Production_ECCProductionEP1CLNT800".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_Production_ECCProductionEP1CLNT800();
		}else if ("ASPAC_Panda_Production_PIProductionXP1CLNT800".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_Production_PIProductionXP1CLNT800();
		}

		else if ("ASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_ProductionTechnicalClients_ECCProductionEP1CLNT000();
		}else if ("ASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_ProductionTechnicalClients_BIProductionBP1CLNT000();
		}else if ("ASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Panda_ProductionTechnicalClients_PIProductionXP1CLNT000();
		}

		//TAISHAN
		else if ("ASPAC_Taishan_Production_ECCProductionRPDCLNT800".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Taishan_Production_ECCProductionRPDCLNT800();
		}else if ("ASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_Taishan_ProductionTechnicalClients_ECCProductionRPDCLNT000();
		}


		// EMEA - START
		//EUROPE2
		else if ("EMEA_EUROPE2_Production_APOProductionAPECLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_APOProductionAPECLNT050();
		}else if ("EMEA_EUROPE2_Production_BIProductionBPECLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_BIProductionBPECLNT050();
		}else if ("EMEA_EUROPE2_Production_FSFProductionBPICLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_FSFProductionBPICLNT050();
		}else if ("EMEA_EUROPE2_Production_EWMProductionQPJCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_EWMProductionQPJCLNT050();
		}else if ("EMEA_EUROPE2_Production_ECCProductionRPECLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_ECCProductionRPECLNT050();
		}

		//EMEA_EUROPE2_Production_EWMProductionPJECLNT050
		else if ("EMEA_EUROPE2_Production_EWMProductionPJECLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_Production_EWMProductionPJECLNT050();
		}

		else if ("EMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_ProductionTechnicalClients_ECCProductionRPECLNT000();
		}else if ("EMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_ProductionTechnicalClients_APOProductionAPECLNT000();
		}else if ("EMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_ProductionTechnicalClients_BIProductionBPECLNT000();
		}else if ("EMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_ProductionTechnicalClients_EWMProductionQPJCLNT000();
		}else if ("EMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_EUROPE2_ProductionTechnicalClients_FSFProductionBPICLNT000();
		}

		//Galaxy
		else if ("EMEA_Galaxy_Production_BIProductionBPMCLNT172".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Galaxy_Production_BIProductionBPMCLNT172();
		}else if ("EMEA_Galaxy_Production_ECCProductionRPMCLNT232".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Galaxy_Production_ECCProductionRPMCLNT232();
		}else if ("EMEA_Galaxy_Production_ECCProductionRPMCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Galaxy_Production_ECCProductionRPMCLNT050();
		}


		else if ("EMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Galaxy_ProductionTechnicalClients_BIProductionBPMCLNT000();
		}else if ("EMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Galaxy_ProductionTechnicalClients_ECCProductionRPMCLNT000();
		}

		//GMED
		else if ("EMEA_GMED_Production_EWMCourcellesProductionP28CLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_GMED_Production_EWMCourcellesProductionP28CLNT050();
		}else if ("EMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_GMED_ProductionTechnicalClients_EWMCourcellesProductionP28CLNT000();
		}


		//IML
		else if ("EMEA_ILM_Production_BIProductionB3TCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_BIProductionB3TCLNT050();
		}else if ("EMEA_ILM_Production_BIProductionB4TCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_BIProductionB4TCLNT050();
		}else if ("EMEA_ILM_Production_BIProductionBPTCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_BIProductionBPTCLNT050();
		}else if ("EMEA_ILM_Production_ECCProductionR3TCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_ECCProductionR3TCLNT050();
		}else if ("EMEA_ILM_Production_ECCProductionR4TCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_ECCProductionR4TCLNT050();
		}else if ("EMEA_ILM_Production_ECCProductionRPTCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_Production_ECCProductionRPTCLNT050();
		}

		else if ("EMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_BIProductionB3TCLNT000();
		}else if ("EMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_BIProductionB4TCLNT000();
		}else if ("EMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_BIProductionBPTCLNT000();
		}else if ("EMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR3TCLNT000();
		}else if ("EMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionR4TCLNT000();
		}else if ("EMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_ILM_ProductionTechnicalClients_ECCProductionRPTCLNT000();
		}

		//SNC
		else if ("EMEA_SNC_Production_SNCProductionQPECLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SNC_Production_SNCProductionQPECLNT050();
		}else if ("EMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SNC_ProductionTechnicalClients_SNCProductionQPECLNT000();
		}


		//STF - START

		else if ("EMEA_STF_Production_APOProductionAPCCLNT430".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_APOProductionAPCCLNT430();
		}else if ("EMEA_STF_Production_BIProductionBPCCLNT330".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_BIProductionBPCCLNT330();
		}else if ("EMEA_STF_Production_CRMProductionCPCCLNT100".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_CRMProductionCPCCLNT100();
		}else if ("EMEA_STF_Production_MDGProductionOPCCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_MDGProductionOPCCLNT050();
		}else if ("EMEA_STF_Production_NetweaverGatewayProductionP05CLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_NetweaverGatewayProductionP05CLNT050();
		}else if ("EMEA_STF_Production_ECCProductionRPCCLNT130".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_ECCProductionRPCCLNT130();
		}else if ("EMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000();
		}else if ("EMEA_STF_Production_PIProductionXPGCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_Production_PIProductionXPGCLNT050();
		}


		else if ("EMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_PIProductionXPGCLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_APOProductionAPCCLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_BIProductionBPCCLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_CRMProductionCPCCLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_MDGProductionOPCCLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_NetweaverGatewayProductionP05CLNT000();
		}else if ("EMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_STF_ProductionTechnicalClients_ECCProductionRPCCLNT000();
		}
		//STF - END

		//SUSTAIN
		else if ("EMEA_Sustain_Production_BIProductionBPBCLNT050".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Sustain_Production_BIProductionBPBCLNT050();
		}else if ("EMEA_Sustain_Production_ECCProductionRPBCLNT910".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Sustain_Production_ECCProductionRPBCLNT910();
		}else if ("EMEA_Sustain_Sandbox_RSB910".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Sustain_Sandbox_RSB910();
		}

		else if ("EMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Sustain_ProductionTechnicalClients_BIProductionBPBCLNT000();
		}else if ("EMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_Sustain_ProductionTechnicalClients_ECCProductionRPBCLNT000();
		}

		//SYMPHONY
		else if ("EMEA_SYMPHONY_Production_ECCProductionP30CLNT200".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYMPHONY_Production_ECCProductionP30CLNT200();
		}else if ("EMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYMPHONY_ProductionTechnicalClients_ECCProductionP30CLNT000();
		}

		//SYNTHES
		else if ("EMEA_SYNTHES_Production_GRCProductionACPCLNT001".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_GRCProductionACPCLNT001();
		}else if ("EMEA_SYNTHES_Production_BIProductionBIPCLNT020".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_BIProductionBIPCLNT020();
		}else if ("EMEA_SYNTHES_Production_GTSProductionGTPCLNT001".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_GTSProductionGTPCLNT001();
		}else if ("EMEA_SYNTHES_Production_ECCProductionP01CLNT020".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_ECCProductionP01CLNT020();
		}else if ("EMEA_SYNTHES_Production_SOLMANProductionS01CLNT001".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_SOLMANProductionS01CLNT001();
		}

		else if ("EMEA_SYNTHES_Production_ECCProductionMBPCLNT600".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_Production_ECCProductionMBPCLNT600();
		}else if ("EMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_ProductionTechnicalClients_GRCProductionACPCLNT000();
		}else if ("EMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_ProductionTechnicalClients_BIProductionBIPCLNT000();
		}else if ("EMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_ProductionTechnicalClients_GTSProductionGTPCLNT000();
		}else if ("ASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestASPAC_SYNTHES_ProductionTechnicalClients_ECCProductionMBPCLNT000();
		}else if ("EMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_ProductionTechnicalClients_ECCProductionP01CLNT000();
		}else if ("EMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_SYNTHES_ProductionTechnicalClients_SOLMANProductionS01CLNT000();
		}


		//VDR
		else if ("EMEA_VDR_Production_ECCProductionFRPCLNT382".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_VDR_Production_ECCProductionFRPCLNT382();
		}else if ("EMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestEMEA_VDR_ProductionTechnicalClients_ECCProductionFRPCLNT000();
		}

		// EMEA - END

		//Getting User AD Groups PFBPFI(BW4PFB and S4PFI)
		else if ("BW4PFB".equalsIgnoreCase(templateName)) {
			templ = getDestBW4PFB();
		}else if ("S4PFI".equalsIgnoreCase(templateName)) {
			templ = getDestS4PFI();
		}

		//CFIN -PFI/PFQ CLNT

		else if ("NA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_CFIN_ProductionTechnicalClients_S4HANAProductionPFICLNT000();
		}else if ("NA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000".equalsIgnoreCase(templateName)) {
			templ = getDestNA_CFIN_ProductionTechnicalClients_SLTProductionPFQCLNT000();
		}

		//

		else if ("GRCSYS".equalsIgnoreCase(templateName)) {
			templ = getDestGRCSYS();
		}
		//Getting User AD Groups

		return templ;
	}


}
