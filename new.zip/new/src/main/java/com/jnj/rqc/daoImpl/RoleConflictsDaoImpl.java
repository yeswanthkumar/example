package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.dao.RoleConflictsDao;
import com.jnj.rqc.dbconfig.BaseDao;



/**
 * File    : <b>RoleConflictsDaoImpl.java</b>
 * @author : DChauras @Created : Jan 10, 2020 3:21:52 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class RoleConflictsDaoImpl  extends BaseDao implements RoleConflictsDao {
	static final Logger log = LoggerFactory.getLogger(RoleConflictsDaoImpl.class);




	/**
	 * Method  : RoleConflictsDaoImpl.java.getCurrentRolesConflict()
	 *		   :<b>@param roles
	 *		   :<b>@param wwid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Jan 13, 2020 2:04:03 PM
	 * Purpose : Query the DB to return any conflicts Left-Right and Right-Left
	 * @return : List<ConflictDispModel>
	 */
	@Override
	public List<MatrixModel> getCurrentRolesConflict(String[] roles, String wwid ) throws SQLException, DataAccessException {
		List<MatrixModel> confInExistingRoles = new ArrayList<>();

		for(String roleId : roles) {
			List<MatrixModel> tmp = getLRConflicts(roleId,  wwid);
			if(tmp != null && !tmp.isEmpty()) {
				confInExistingRoles.addAll(tmp);
			}
		}

		log.info("Total Conflicts in NEW-EXISTING :"+confInExistingRoles.size());

		return confInExistingRoles;
	}


	@Override
	public List<MatrixModel> getNewRolesConflict(String sql) throws SQLException, DataAccessException {
		List<MatrixModel> roleMatrixList = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("roleMatrix size : "+((roleMatrixList !=null)? roleMatrixList.size(): 0)+" ");
		return roleMatrixList;
	}



/**
 * Method  : RoleConflictsDaoImpl.java.getLRConflicts()
 *		   :<b>@param roleId
 *		   :<b>@param wwid
 *		   :<b>@return</b>
 * @author : DChauras  @Created :Jan 13, 2020 4:48:15 PM
 * Purpose : Checks if Conflict exists in requested Roles and Existing Roles
 * @return : List<MatrixModel>
 */
	private List<MatrixModel>getLRConflicts(String roleId, String wwid){
		List<MatrixModel> allConfRoles = new ArrayList<>();

		String sqlLtoR = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE1 = ? and a.ROLE2 = b.CODE "
				+" and b.WWID = ? ";
		List<MatrixModel> roleMatrix = getJdbcTemplate().query(sqlLtoR, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("Role ID : "+roleId+"  Total Rows LtoR => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			allConfRoles.addAll(roleMatrix);
		}

		String sqlRtoL = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE2 = ? and a.ROLE1 = b.CODE "
				+" and b.WWID = ? ";
		roleMatrix = null;
		roleMatrix = getJdbcTemplate().query(sqlRtoL, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("Role ID :"+roleId+"  Total Rows RtoL => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			allConfRoles.addAll(roleMatrix);
		}

	return allConfRoles;
	}

/*
	private List<MatrixModel>getNewRoleConflicts(int roleId, int wwid){
		List<MatrixModel> confInExistingRoles = new ArrayList<MatrixModel>();

		String sqlLtoR = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE1 = ? and a.ROLE2 = b.CODE "
				+" and b.WWID = ? ";
		List<MatrixModel> roleMatrix = getJdbcTemplate().query(sqlLtoR, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<MatrixModel>(MatrixModel.class));
		log.info("Total Rows LtoR => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			confInExistingRoles.addAll(roleMatrix);
		}

		String sqlRtoL = " SELECT a.ROLE1, a.ROLE2, a.APP1, a.APP2, a.CONFLICT, a.MITIGATING_CONTROL "
				+" FROM SOD_EXTR.CONFLICT_MATRIX a, SOD_EXTR.PERSONAL_SYSTEM b "
				+" WHERE a.ROLE2 = ? and a.ROLE1 = b.CODE "
				+" and b.WWID = ? ";
		roleMatrix = null;
		roleMatrix = getJdbcTemplate().query(sqlRtoL, new Object[] {roleId, wwid}, new BeanPropertyRowMapper<MatrixModel>(MatrixModel.class));
		log.info("Total Rows RtoL => "+((roleMatrix !=null)? roleMatrix.size(): 0)+" ");
		if(roleMatrix != null && !roleMatrix.isEmpty()) {
			confInExistingRoles.addAll(roleMatrix);
		}

	return confInExistingRoles;
	}*/




	/**
	 * Method  : RoleConflictsDaoImpl.java.getUsersExistingRoles()
	 *		   :<b>@param empWwid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Jan 15, 2020 4:26:35 PM
	 * Purpose :Query All the Existing User Roles for a given WWID
	 * @return : List<PersonalSysModel>
	 */
	@Override
	public List<PersonalSysModel> getUsersExistingRoles(String wwid)throws SQLException, DataAccessException {
		log.info("User ID Received:"+ wwid);
		String sql = " SELECT a.WWID, a.USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " +
				" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b" +
				" WHERE a.CODE = b.SOD_CODE AND a.WWID = ? ORDER BY a.CODE ";

		final List<PersonalSysModel> userRoles = getJdbcTemplate().query(sql, new Object[] {wwid}, new BeanPropertyRowMapper<>(PersonalSysModel.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


	@Override
	public List<SystemCodeModel> getSystemCodes() throws SQLException, DataAccessException {
		log.info("QUERY SYSTEM_CODE");
		String sql = " SELECT SRC_SYSTEM, ACCESS_ROLE, SOD_CODE FROM SOD_EXTR.SYSTEM_CODE ORDER BY SRC_SYSTEM ";

		final List<SystemCodeModel> sysCdLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SystemCodeModel.class));
		log.info("Total Rows : "+((sysCdLst !=null)? sysCdLst.size(): 0)+"  .......END");
		return sysCdLst;
	}


	@Override
	public List<PersonalSysModel> getUsersExistingRoles(List<String> empIds) throws SQLException, DataAccessException {
		log.info("User ID Received:"+ empIds);
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.WWID, UPPER(a.USER_ID) AS USER_ID, a.FIRST_NAME, a.LAST_NAME, a.USER_TYPE, a.CODE, b.ACCESS_ROLE as ROLE, a.CO, a.SRC_SYSTEM, a.JOB, a.WAIVERS " );
		sql.append(" FROM SOD_EXTR.PERSONAL_SYSTEM a, SOD_EXTR.SYSTEM_CODE b " );
		sql.append(" WHERE a.CODE = b.SOD_CODE AND a.WWID in ( ");
		String vars="";

		for(int i=0; i<empIds.size(); i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" ORDER BY a.WWID,  a.CODE ");

		final List<PersonalSysModel> userRoles = getJdbcTemplate().query(sql.toString(), empIds.toArray(), new BeanPropertyRowMapper<>(PersonalSysModel.class));
		log.info("Total Rows : "+((userRoles !=null)? userRoles.size(): 0)+"  .......END");
		return userRoles;
	}


	@Override
	public List<MatrixModel> getConflictMatrix() throws SQLException, DataAccessException {
		log.info("QUERY SOD_EXTR.CONFLICT_MATRIX");
		String sql = " SELECT '' as WWID, ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL FROM SOD_EXTR.CONFLICT_MATRIX ORDER BY APP1, APP2, ROLE1, ROLE2 ";

		final List<MatrixModel> mtrxLst = getJdbcTemplate().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(MatrixModel.class));
		log.info("Total Rows : "+((mtrxLst !=null)? mtrxLst.size(): 0)+"  .......END");
		return mtrxLst;
	}






	/*@Override
	public List<UserSearchModel> getAllUsersByNTId(List<Object> ids)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);

		String sql = " Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, "+
					 " EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID "+
					 " From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where JNJ_MSFT_USRNM_TXT in (:ids) "+
					 " ORDER BY JNJ_MSFT_USRNM_TXT";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql, params, new BeanPropertyRowMapper<UserSearchModel>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}




	@Override
	public List<UserSearchModel> getAllUsersByFmlyNm(List<Object> ids)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);

		String sql = " Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, "+
					 " EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID "+
					 " From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where FMLY_NM in (:ids) "+
					 " ORDER BY JNJ_MSFT_USRNM_TXT";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql, params, new BeanPropertyRowMapper<UserSearchModel>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}


	@Override
	public List<UserSearchModel> getAllUsersByFirstNm(List<Object> ids)throws SQLException, DataAccessException {
		log.info("ID's Received:"+ ids);

		String sql = " Select WW_ID, GIVEN_NM, FMLY_NM, JNJ_EMAIL_ADDR_TXT, JNJ_SUPVR_WW_ID, JNJ_MSFT_USRNM_TXT, "+
					 " EMP_STAT_TXT, TERMNN_DT, LAST_HIRE_DT, JNJ_DEPTM_CD, JNJ_DEPTM_DESCN_TXT, BUSN_TEL_NO, LOCN_ID "+
					 " From SOD_EXTR.JJEDS_EMP_EXTR_MV  Where GIVEN_NM in (:ids) "+
					 " ORDER BY JNJ_MSFT_USRNM_TXT";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("ids", ids);
		final List<UserSearchModel> userData = getJdbcTemplateNm().query(sql, params, new BeanPropertyRowMapper<UserSearchModel>(UserSearchModel.class));
		log.info("Total Rows: "+((userData !=null)? userData.size(): 0)+"  .......END");
		return userData;
	}


*/


	/*@Override
	public String insertUserActivityData(List<UserActivityModel> dataList)throws SQLException, DataAccessException{
		 SimpleJdbcInsert devJdbcInsert = getUserSimpleJdbcInsert459();
	        List<Map<String, Object>> batchValues = new ArrayList<>(dataList.size());
	        Date addedDate = new Date();
	        for (UserActivityModel actMdl : dataList) {
	            Map<String, Object> map = new HashMap<String, Object>();
	            String userId = actMdl.getUserId();
	            if(userId != null && userId.length() > 16) {
	            	userId = userId.substring(0,15);
	            }
	            map.put("USER_ID", userId);
	            map.put("FIRST_NAME", actMdl.getFirstName());
	            map.put("LAST_NAME", actMdl.getLastName());
	            map.put("ROLE", actMdl.getRole());
	            map.put("SRC_SYS", actMdl.getSrcSys());
	            map.put("EMP_ACTIVE", actMdl.getEmpActive());
	            map.put("DT_UPDATED", actMdl.getDtUpdated());
	            map.put("DT_ADDED", addedDate);
	            batchValues.add(map);
	        }

	        if (!devJdbcInsert.isCompiled()) {
	        	devJdbcInsert.includeSynonymsForTableColumnMetaData()
	        	.withSchemaName("SOD_EXTR")
	        	.withTableName("USER_STAT_DATA");
	        }
	        int[] status = devJdbcInsert.executeBatch(batchValues.toArray(new Map[batchValues.size()]));
	        return status.length == batchValues.size() ? "Success" : "Failed";
	}


	public boolean clearUserCache()throws SQLException, DataAccessException{
		//String sql = " DELETE FROM SOD_EXTR.USER_STAT_DATA WHERE SRC_SYS <> 'CARSMA' ";
		String sql = " DELETE SOD_EXTR.USER_STAT_DATA";
	 	int count =   getJdbcTemplate0459().update(sql);
	 	return (count > 0) ? true:false;
	}
*/

}
