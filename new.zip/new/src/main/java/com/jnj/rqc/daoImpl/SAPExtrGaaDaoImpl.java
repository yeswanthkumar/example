package com.jnj.rqc.daoImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.IAMRolesADGrpMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.dao.SAPExtrGaaDao;
import com.jnj.rqc.dbconfig.SAPTemplateFactory;
import com.jnj.rqc.util.Utility;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;




@Service
public class SAPExtrGaaDaoImpl  extends SAPTemplateFactory implements SAPExtrGaaDao {
	static final Logger log = LoggerFactory.getLogger(SAPExtrGaaDaoImpl.class);


	@Override
	public List<String> getAllValidUsers(String templSysParam) throws JCoException {
		log.info("Gell All Users for Template Name : "+templSysParam);
		List<String> usrData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR02");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        //log.debug("Setting OPTIONS");
        Date date = new Date(1410152400000L);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = formatter.format(date);
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USTYP EQ 'A'");
        log.debug("Setting QUERY FIELDS");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGV");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGB");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USTYP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "CLASS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UFLAG");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "ERDAT");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                /*Object sValue = sMessage.trim();
                if ((sValue instanceof Date)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
                    sValue = sdf.format(sValue);
                }*/
                String[] dataArr = sMessage.trim().split(",");
                String usrNm = dataArr[0].trim().replaceAll("[^\\.A-Za-z0-9_-]", "");
                if(!usrData.contains(usrNm)) {
                	usrData.add(usrNm);
                }
                //log.info("BNAME > " + dataArr[0]+" GLTGV > "+dataArr[1]+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]);
            }
        }
        log.info("Total User Records returned(SAP-USR02 - "+"templSysParam"+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}


	@Override
	public List<String> getUsersRoles(String user, String templSysParam) throws JCoException {
		//log.info("getUsersRoles() for Template Name : "+templSysParam+ " - User :"+user);
		List<String> rlsData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                if(!rlsData.contains(dataArr[1].trim())) {
                	rlsData.add(dataArr[1].trim());
                }
                //log.info("UNAME > " + dataArr[0]+" AGR_NAME > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}


	@Override
	public String getRoleDescription(String role, String templSysParam) throws JCoException {
		//log.info("ROLE NAME: "+role+"  Template Name : "+templSysParam);
		String rlsdesc = "";
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        //function.getImportParameterList().setValue("QUERY_TABLE", "AGR_DEFINE");
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_TEXTS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AGR_NAME EQ '"+role+"'");

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
       /* returnFields.appendRow();
          returnFields.setValue("FIELDNAME", "\'TEXT\'");*/

        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.debug("getRoleDescription() Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
        	for (int iRow = 0; iRow < numRows; iRow++) {
        		jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                //log.debug(1+". AGR_NAME & ROLE DESC  > "+sMessage);
                String[] dataArr = sMessage.trim().split(",");
                /*if(dataArr != null && dataArr.length >0) {
                	if(dataArr.length>3 && dataArr[3].equals("00000"))
                	rlsdesc = dataArr[(dataArr.length - 1)].trim();
                	break;
                }*/

                if(dataArr != null && dataArr.length >0) {
                	if(dataArr.length>3 && dataArr[3].equals("00000")) {
                		for(int i=4; i<dataArr.length;i++) {
                			rlsdesc +=" "+dataArr[i].trim();
                		}
                		log.info("Role Desc >>> "+rlsdesc);
                		break;
                	}
                }
                //log.info("AGR_NAME > " + dataArr[0]+" PARENT_AGR > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
        	}
        }
        //log.debug("ROLE: "+role+" ROLE DESC : "+rlsdesc);
		return rlsdesc;
	}



	@Override
	public List<SAPUserAccessModel> getValidUsersWithDate(String templSysParam) throws JCoException {
		//log.info("Template Name : "+templSysParam);
		List<SAPUserAccessModel> usrData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR02");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        //String dt = "99991231"; //TODO -Modify to be >= todays Date
        String dt = Utility.fmtYMD(new Date());
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USTYP EQ 'A' AND GLTGB GE '"+dt+"'");

        //START - Added a EXTRA Cluase for OurSource
        String system=templSysParam.split("_")[1];
        if("OURSOURCE".equals(system)) {
        	returnOptions.appendRow();
        	returnOptions.setValue("TEXT", " AND CLASS NE 'USER' ");
        }
        //END of Addition for OurSource

        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGB");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                SAPUserAccessModel umdl = new SAPUserAccessModel();
                umdl.setSapId(dataArr[0].trim());
                umdl.setGltgb(dataArr[1].trim());

                if(!usrData.contains(umdl)) {
                	usrData.add(umdl);
                }
                //log.info("BNAME > " + dataArr[0]+" GLTGV > "+dataArr[1]+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]);
            }
        }
        log.info("Total User Records returned : "+((usrData !=null) ? usrData.size():"0")+" for System :"+templSysParam);
        return usrData;
	}

	@Override
	public String getUsersPersonNumber(String user, String templSysParam) throws JCoException {
		log.info("Template Name : "+templSysParam+" User:"+user);
		String usrPrsn = "";
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR21");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "BNAME EQ '"+user+"'");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        /*returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");*/
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "PERSNUMBER");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                usrPrsn= sMessage.trim();

            }
        }
        //log.info("User Records : "+user+" : "+usrPrsn);
        return usrPrsn;
	}

	@Override
	public String getUsersWwId(String prsnNumber, String templSysParam) throws JCoException	{
		//log.info("Template Name : "+templSysParam+" prsnNumber:"+prsnNumber);
		String wwid = "";
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "ADRP");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "PERSNUMBER EQ '"+prsnNumber+"'");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "SORT1");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "SORT2");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                ///ADD A condition to check both fields for Data
                String[] msgArr =sMessage.split(",");
                if(msgArr[0].trim().length() > 0) {
                	wwid= msgArr[0].trim();
                }else if(msgArr.length > 1) {
                	wwid= msgArr[1].trim();
                }
            }
        }
        //log.info("User Person Number: "+prsnNumber+" WWID: "+wwid);
        return wwid;
	}


	@Override
	public Map<String, String> getDialogUsers(String templSysParam) throws JCoException {
		log.info("Gell All NON-Dialog Users for Template Name : "+templSysParam);
		Map<String, String> usrData = new HashMap<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        //log.debug("Getting template");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "USR02");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        //log.debug("Setting OPTIONS");
        Date date = new Date(1410152400000L);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateString = formatter.format(date);
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        //returnOptions.setValue("TEXT", "USTYP EQ 'A'");
        // “L”, “S”, “C” and “B”
        returnOptions.setValue("TEXT", "USTYP EQ 'L' OR USTYP EQ 'S' OR USTYP EQ 'C' OR USTYP EQ 'B' ");
        log.debug("Setting QUERY FIELDS");
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "BNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGV");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "GLTGB");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USTYP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "CLASS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UFLAG");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "ERDAT");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        //log.info("Totla numRows returned > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                /*Object sValue = sMessage.trim();
                if ((sValue instanceof Date)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
                    sValue = sdf.format(sValue);
                }*/
                String[] dataArr = sMessage.trim().split(",");
                String usrNm = dataArr[0].trim();
                String usrTyp="";
                if(dataArr.length > 3) {
                	usrTyp=dataArr[3].trim();
                }
                usrData.put(usrNm, usrTyp);
                //log.info("BNAME > " + dataArr[0]+" GLTGV > "+dataArr[1]+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]);
            }
        }
        //log.info("Total User Records returned(SAP-USR02 - "+"templSysParam"+") : "+((usrData !=null) ? usrData.size():"0"));
        return usrData;
	}



	@Override
	public List<IAMRolesADGrpMdl> getPFBUserRoleADGrps(String sysTempl, String userId) throws JCoException {
		List<IAMRolesADGrpMdl> usrData = new ArrayList<>();
		JCoDestination destination = getDestination(sysTempl);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "ZFINM_USER_LDAP");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));

        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        String dt = Utility.fmtYMD(new Date());
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", "USER1 EQ '"+userId+"'");

        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MANDT");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "USER1");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AD_GROUP");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "MDATE");
        function.execute(destination);


        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                IAMRolesADGrpMdl umdl = new IAMRolesADGrpMdl();
                umdl.setClient(dataArr[0].trim());
                umdl.setUser(dataArr[1].trim());
                umdl.setLdapADGroup(dataArr[2].trim());
                umdl.setMdate(dataArr[3].trim());
                if(!usrData.contains(umdl)) {
                	usrData.add(umdl);
                }
            }
        }
        log.info("Total AD Group for User: "+userId +" Records returned : "+((usrData !=null) ? usrData.size():"0")+" for System : BW4PFB");
        return usrData;
	}



	@Override
	public List<String> getPFIUserRoleADGrps(String templSysParam, String user ) throws JCoException {
		log.info("getPFIUsersRoles() for Template Name : "+templSysParam+ " - User :"+user);
		List<String> rlsData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                if(!rlsData.contains(dataArr[1].trim())) {
                	rlsData.add(dataArr[1].trim());
                }
                //log.info("UNAME > " + dataArr[0]+" AGR_NAME > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}



	@Override
	public List<String> getGRCUserRoleADGrps(String templSysParam, String user ) throws JCoException {
		log.info("getGRCUserRoleADGrps() for Template Name : "+templSysParam+ " - User :"+user);
		List<String> rlsData = new ArrayList<>();
		JCoDestination destination = getDestination(templSysParam);
		JCoRepository sapRepository;
		JCoContext.begin(destination);
        sapRepository = destination.getRepository();

        JCoFunctionTemplate template = sapRepository.getFunctionTemplate("RFC_READ_TABLE");
        JCoFunction function = template.getFunction();
        function.getImportParameterList().setValue("QUERY_TABLE", "AGR_USERS");
        //function.getImportParameterList().setValue("QUERY_TABLE", "ZGRC_BROLE");
        function.getImportParameterList().setValue("DELIMITER", ",");
        function.getImportParameterList().setValue("ROWSKIPS", Integer.valueOf(0));
        function.getImportParameterList().setValue("ROWCOUNT", Integer.valueOf(0));
        //Setting options
        JCoTable returnOptions = function.getTableParameterList().getTable("OPTIONS");
        returnOptions.appendRow();
        System.out.println("<<<<<<<< USER:"+user+">>>>>>>>>>");
        returnOptions.setValue("TEXT", " UNAME EQ '"+user+"'");
        returnOptions.appendRow();
        returnOptions.setValue("TEXT", " AND COL_FLAG NE 'X'");
        //TODO - Add condition TO_DAT >= todays Date

        //Setting Fields
        JCoTable returnFields = function.getTableParameterList().getTable("FIELDS");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "UNAME");
        returnFields.appendRow();
        returnFields.setValue("FIELDNAME", "AGR_NAME");
        function.execute(destination);

        JCoTable jcoTablef = function.getTableParameterList().getTable("FIELDS");
        JCoTable jcoTabled = function.getTableParameterList().getTable("DATA");
        int icodeOffSet = 0;
        int icodeLength = 0;
        int numRows = jcoTabled.getNumRows();
        log.debug("getUsersRoles() Totla numRows returned  > " + numRows);

        if (numRows > 0 ) {
            for (int iRow = 0; iRow < numRows; iRow++) {
                jcoTablef.setRow(0);
                icodeOffSet = Integer.parseInt(jcoTablef.getString("OFFSET"));
                icodeLength = Integer.parseInt(jcoTablef.getString("LENGTH"));
                icodeLength += icodeOffSet;
                jcoTabled.setRow(iRow);
                String sMessage = jcoTabled.getString("WA");
                String[] dataArr = sMessage.trim().split(",");
                if(!rlsData.contains(dataArr[1].trim())) {
                	rlsData.add(dataArr[1].trim());
                }
                //log.info("UNAME > " + dataArr[0]+" AGR_NAME > "+dataArr[1]/*+" GLTGB > "+dataArr[2]+" USTYP > "+dataArr[3]+" CLASS > "+dataArr[4]+" UFLAG"+dataArr[5]+" ERDAT > "+dataArr[6]*/);
            }
        }
        log.info("Total Roles returned for User ("+user+" - "+templSysParam+"): "+((rlsData !=null) ? rlsData.size():"0"));
        return rlsData;
	}





}
