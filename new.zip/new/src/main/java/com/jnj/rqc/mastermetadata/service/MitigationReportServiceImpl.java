package com.jnj.rqc.mastermetadata.service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.jnj.rqc.autotask.RQCUtilSchedular;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.mastermetadata.controller.MitigationReportDTO;
import com.jnj.rqc.mastermetadata.controller.MitigationRptMdl;
import com.jnj.rqc.mastermetadata.controller.ReportErrorDTO;
import com.jnj.rqc.mastermetadata.controller.ReportErrorModel;
import com.jnj.rqc.mastermetadata.controller.ReportHeaderModel;
import com.jnj.rqc.mastermetadata.controller.ReportResponse;
import com.jnj.rqc.mastermetadata.controller.ReportStats;
import com.jnj.rqc.mastermetadata.controller.RequestMonitorReportDTO;
import com.jnj.rqc.mastermetadata.controller.RequestReportDataModel;
import com.jnj.rqc.mastermetadata.controller.SchedularStatusDTO;
import com.jnj.rqc.mastermetadata.controller.SchedularStatusModel;
import com.jnj.rqc.mastermetadata.controller.SysNameWiseStats;
import com.jnj.rqc.mastermetadata.controller.MonitorReportDTO;
import com.jnj.rqc.mastermetadata.controller.ReportDataModel;
import com.jnj.rqc.mastermetadata.controller.SystemStatusDTO;
import com.jnj.rqc.mastermetadata.dao.MasterMetaDataRepository;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.dao.UserUtilsDao;
import com.jnj.rqc.userabs.iamgrcservice.IamGrcRequestSumbissionService;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMultiUserMdl;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.userreq.dao.AbsUserRequesDao;

@Service
public class MitigationReportServiceImpl implements MitigationReportService {
	
	static final Logger log = LoggerFactory.getLogger(MitigationReportServiceImpl.class);
	private final MasterMetaDataRepository masterRepository;
	
	@Autowired
	private AbsUserRequesDao absUserRequesDao;
	
	@Autowired
	private UserSearchService userSearchService;
	
	@Autowired
	private UserUtilsDao userUtilsDao;
	
	@Autowired
	private MasterDataInMemoryService masterDataInMemoryService;
	
	@Autowired
	public MitigationReportServiceImpl(MasterMetaDataRepository masterRepository) {
		this.masterRepository = masterRepository;		
	}
	@Autowired
    IamGrcRequestSumbissionService iamGrcRequestSumbissionService;
	
	@Autowired
	RQCUtilSchedular rqcUtilSchedular;
	
	@Override
	public MitigationReportDTO getMitigationResults() {
		MitigationReportDTO reportDTO = new MitigationReportDTO();
		log.debug("enter into the method");
		try {
            List<MitigationRptMdl> allMitigationResults = masterRepository.getAllMitigation();
            allMitigationResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setMitigationReports(allMitigationResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}
	
	@Override
	public MitigationReportDTO getMitigationResults(String criteria, String value) {
		MitigationReportDTO reportDTO = new MitigationReportDTO();
		log.debug("enter into the method");
		try {
            List<MitigationRptMdl> allMitigationResults = masterRepository.getAllMitigation(criteria, value);
            allMitigationResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setMitigationReports(allMitigationResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}
	
	public ReportErrorDTO getErrorReport( Date fromDate, Date toDate		
			)  {
		ReportErrorDTO reportDTO = new ReportErrorDTO();
		try {			
			log.debug("received fromDate as :"+fromDate);
			log.debug("received toDate as :"+toDate);
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.S");
			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
            Date fromDateTime = sdf.parse(fromDate + " 00:00:00");
            Date toDateTime = sdf.parse(toDate + " 23:59:00");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            fromDateTime = calendar.getTime();

            calendar.setTime(toDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            toDateTime = calendar.getTime();
            
            log.debug("fromDateTime as :"+fromDateTime);
            log.debug("toDateTime as :"+toDateTime); 
            
			List<ReportErrorModel> results = masterRepository.getAllErrorReport(fromDateTime, toDateTime);
			log.debug("Total cout received :"+results.size());
			log.debug("object received from db :"+results);	
			
			for(ReportErrorModel result :results) {							
				String roleName = result.getRoleName();
				String sysId = result.getSystemId();
				if(!sysId.equals("1")) {					
					result.setSubm_status("E");	
					
				}
				if(sysId.equals("1")) {
					String errorMsg =result.getSubm_uid();
					result.setErrorMsg(errorMsg);
				}
				String inputDate = result.getSubm_date();				
				LocalDateTime localDateTime = LocalDateTime.parse(inputDate, inputFormatter);
				String outputDate = localDateTime.format(outputFormatter);
				result.setSubm_date(outputDate);				
				log.debug("getting roles for roleName :"+roleName+" sysId :"+sysId);	
				List<RoleADGrpMultiUserMdl> masterCacheRolesList = masterDataInMemoryService.findBySYS_IDAndAD_NAME(sysId,roleName);
				
				/*List<RoleADGrpMdl> rolesList = userUtilsDao.getMstRolesDataForADGrp(roleName,sysId);
				if(rolesList!=null && rolesList.size() >0) {
					RoleADGrpMdl model = rolesList.stream().findFirst().orElse(null);
					result.setCuName(model.getPvName());
					result.setSystemName(model.getSysName());					
					result.setPositionName(model.getPosName());		
				}*/
				if(masterCacheRolesList !=null && masterCacheRolesList.size()>0) {
					RoleADGrpMultiUserMdl model = masterCacheRolesList.stream().findFirst().orElse(null);
					result.setCuName(model.getPvName());
					result.setSystemName(model.getSysName());
					result.setPositionName(model.getPosName());										
				}
			}						
			reportDTO.setStatusCode(200);			
			reportDTO.setErrorReports(results);
		}catch(Exception ee) {
			log.error("Exception: " + ee.getMessage());
            reportDTO.setStatusCode(500); 
		}
		return reportDTO;		
	}
	public SystemStatusDTO getGRCStatus()  {
		SystemStatusDTO statusDTO = new SystemStatusDTO();
		boolean status = iamGrcRequestSumbissionService.pingGRC("status check");
		if(status) {
			statusDTO.setMessage("up");
		}else {
			statusDTO.setMessage("down");
		}
		statusDTO.setStatusCode(200);	
		return statusDTO;
		
	}
	public SystemStatusDTO getIAMStatus()  {
		SystemStatusDTO statusDTO = new SystemStatusDTO();
		boolean status = iamGrcRequestSumbissionService.pingIAM("status check");
		if(status) {
			statusDTO.setMessage("up");
		}else {
			statusDTO.setMessage("down");
		}
		statusDTO.setStatusCode(200);	
		return statusDTO;
		
	}
	public static Map<String, List<ReportErrorModel>> convertMapKeysToString(Map<Object, List<ReportErrorModel>> originalMap) {
	    Map<String, List<ReportErrorModel>> newMap = new HashMap<>();
	    
	    for (Map.Entry<Object, List<ReportErrorModel>> entry : originalMap.entrySet()) {
	        String key = entry.getKey().toString(); // Convert the key to a string
	        List<ReportErrorModel> value = entry.getValue(); // Keep the value as is

	        newMap.put(key, value);
	    }
	    
	    return newMap;
	}
	/*public static Map<String, List<ReportErrorModel>> groupByMonth(List<ReportErrorModel> reportErrorModels) {
	    // Your existing code...
		//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy h:mm:ss a", Locale.ENGLISH);
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S", Locale.ENGLISH); // Updated date format pattern
	    Map<Object, List<ReportErrorModel>> groupedByMonth = reportErrorModels.stream()
	        .collect(Collectors.groupingBy(
	            model -> {
	            	log.debug("date format received as :"+model.getSubm_date());
	            	log.debug("formatter as :"+formatter);
	                LocalDateTime dateTime = LocalDateTime.parse(model.getSubm_date(), formatter);
	                return dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM")); // Extract month in yyyy-MM format
	            },
	            Collectors.toList()
	        ));

	    // Convert the map keys from Object to String
	    Map<String, List<ReportErrorModel>> convertedMap = convertMapKeysToString(groupedByMonth);

	    return convertedMap;
	  //  return groupedByMonth;
	}*/
	public Map<String, List<ReportErrorModel>> groupByMonth(List<ReportErrorModel> reportErrorModels) {
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S", Locale.ENGLISH);
	    log.debug("groupByMonth : enter into this block");
	    Map<String, List<ReportErrorModel>> groupedByMonth = new HashMap<>();

	    for (ReportErrorModel model : reportErrorModels) {
	        String subm_date = model.getSubm_date();
	        if (subm_date != null) {
	            try {
	                LocalDateTime dateTime = LocalDateTime.parse(subm_date, formatter);
	                String month = dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM"));

	                groupedByMonth
	                    .computeIfAbsent(month, k -> new ArrayList<>())
	                    .add(model);
	            } catch (Exception e) {
	                // Handle parsing exceptions, e.g., log or skip the invalid date
	                log.error("Error parsing date: " + subm_date);
	            }
	        }
	    }
	    log.debug("end of this block");

	    return groupedByMonth;
	}

	private SysNameWiseStats createSysNameWiseStats(String month, List<ReportErrorModel> data, String sysName) {
	    log.debug("enter into the createSysNameWiseStats block");
	    int pCount =0;
	    int notAllCount=0;
	    HashMap<String, String> hashMap = new HashMap<>();        
        hashMap.put("1", "CFIN");
        hashMap.put("2", "DataHub");
        hashMap.put("3", "Bravo");
        hashMap.put("4", "Anaplan");
        hashMap.put("5", "A1 Adjustments");
        hashMap.put("6", "SAC");
        List<String> allowedStatus = Arrays.asList("P", "E", "C");
        YearMonth yearMonth = YearMonth.parse(month);
        int year = yearMonth.getYear();
        String monthAbbreviation = yearMonth.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
        
	    SysNameWiseStats stats = new SysNameWiseStats();
	    stats.setMonth(month);
	    stats.setSysName(sysName);	  
	    stats.setSysNm(hashMap.get(sysName));
	    stats.setMm(monthAbbreviation);  
	    stats.setYyyy(year);
	    if (data != null && !data.isEmpty()) {
	        stats.setReqCreatedcount(data.size());
	        List<ReportErrorModel> successCount = data.stream().filter(e -> "C".equals(e.getApi_status())).collect(Collectors.toList());
	        List<ReportErrorModel> failedCount = data.stream().filter(e -> "E".equals(e.getApi_status())).collect(Collectors.toList());
	        List<ReportErrorModel> pendingCount = data.stream().filter(e -> "P".equals(e.getApi_status())).collect(Collectors.toList());
	        List<ReportErrorModel> notAllowedList = data.stream()
	        	    .filter(e -> !allowedStatus.contains(e.getApi_status()))
	        	    .collect(Collectors.toList());
	        if(pendingCount.size() > 0) {
	        	pCount = pendingCount.size();
	        }
	        if(notAllowedList.size()>0) {
	        	notAllCount = notAllowedList.size();
	        }
	        //stats.setRequestSubmitted(String.valueOf(successCount.size()));
	        stats.setRequestSubmitted(successCount.size() + pCount + notAllCount);
	        stats.setRequestFailed(failedCount.size());
	    } else {
	        
	        stats.setReqCreatedcount(0);
	        stats.setRequestSubmitted(0);
	        stats.setRequestFailed(0);
	    }

	    log.debug("end of the createSysNameWiseStats block");
	    return stats;
	}
	public Map<String, List<ReportHeaderModel>> groupByMonthHeaderData(List<ReportHeaderModel> reportErrorModels) {
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S", Locale.ENGLISH);
	    log.debug("groupByMonth : enter into this block");
	    Map<String, List<ReportHeaderModel>> groupedByMonth = new HashMap<>();

	    for (ReportHeaderModel model : reportErrorModels) {
	        String subm_date = model.getRequestedOn();
	        if (subm_date != null) {
	            try {
	                LocalDateTime dateTime = LocalDateTime.parse(subm_date, formatter);
	                String month = dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM"));
	                groupedByMonth
	                    .computeIfAbsent(month, k -> new ArrayList<>())
	                    .add(model);
	            } catch (Exception e) {
	                // Handle parsing exceptions, e.g., log or skip the invalid date
	                log.error("Error parsing date: " + subm_date);
	            }
	        }
	    }
	    log.debug("end of this block");

	    return groupedByMonth;
	}
	private List<RequestReportDataModel> generateRequestIdHeaderData(List<ReportHeaderModel> results) {
		Map<String, List<ReportHeaderModel>> groupedByMonth = groupByMonthHeaderData(results);
	    List<RequestReportDataModel> reportDataModels = new ArrayList<>();
	    log.debug("enter into the generateRequestIdHeaderData method call");

	    try {
	        for (Map.Entry<String, List<ReportHeaderModel>> entry : groupedByMonth.entrySet()) {
	        	RequestReportDataModel dataModel = new RequestReportDataModel();
	        	String month = entry.getKey();
		        List<ReportHeaderModel> data = entry.getValue();
		        YearMonth yearMonth = YearMonth.parse(month);
		        int year = yearMonth.getYear();
		       // int monthValue = yearMonth.getMonthValue();
		        String monthAbbreviation = yearMonth.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
		    	List<ReportHeaderModel> reqCreated 			= data.stream().filter(e -> "1".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> complianceReview 	= data.stream().filter(e -> "2".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> partiallyApproved 	= data.stream().filter(e -> "3".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> complianceReviewed 	= data.stream().filter(e -> "4".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> gRCIAMApprovalInProgress = data.stream().filter(e -> "5".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> requestClosed 			= data.stream().filter(e -> "6".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> provisionedWithError 	= data.stream().filter(e -> "7".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> complianceRejected 		= data.stream().filter(e -> "8".equals(e.getReqStatus())).collect(Collectors.toList());
		    	List<ReportHeaderModel> requestCancelled 		= data.stream().filter(e -> "9".equals(e.getReqStatus())).collect(Collectors.toList());
		    	
		    	dataModel.setMonth(month);	
		    	dataModel.setYyyy(year);
		    	dataModel.setMm(monthAbbreviation);		    	
		    	//dataModel.setReqCreated(reqCreated.size()+"");
		    	dataModel.setReqCreated(data.size());
		    	dataModel.setComplianceReview(complianceReview.size());
		    	dataModel.setPartiallyApproved(partiallyApproved.size());
		    	dataModel.setComplianceReviewed(complianceReviewed.size());
		    	dataModel.setGRCIAMApprovalInProgress(gRCIAMApprovalInProgress.size());
		    	dataModel.setRequestClosed(requestClosed.size());
		    	dataModel.setProvisionedWithError(provisionedWithError.size());
		    	dataModel.setComplianceRejected(complianceRejected.size());
		    	dataModel.setRequestCancelled(requestCancelled.size());
		    	
		    	reportDataModels.add(dataModel);
	        }
	   
	    } catch (Exception e) {
	        log.error("Exception: " + e.getMessage(), e);
	    }
	    log.debug("end of generateReportData method call");

	    return reportDataModels;
	}
	private List<RequestReportDataModel> generateRequestIdReportData(List<ReportErrorModel> results) {
	    Map<String, List<ReportErrorModel>> groupedByMonth = groupByMonth(results);
	    List<RequestReportDataModel> reportDataModels = new ArrayList<>();
	    log.debug("enter into the generateReportData method call");

	    try {
	        for (Map.Entry<String, List<ReportErrorModel>> entry : groupedByMonth.entrySet()) {
	            String month = entry.getKey();
	            List<ReportErrorModel> data = entry.getValue();
	            Map<String, List<ReportErrorModel>> reqMap = data.stream().collect(Collectors.groupingBy(e -> e.getReqId(), Collectors.toList()));            	           
	            RequestReportDataModel reportDataModel = new RequestReportDataModel();
	            int keySize = reqMap.keySet().size();
	            reportDataModel.setRequestCreated(keySize+"");
	            reportDataModel.setMonth(month);
	            reportDataModels.add(reportDataModel);
	        }
	    } catch (Exception e) {
	        log.error("Exception: " + e.getMessage(), e);
	    }
	    log.debug("end of generateReportData method call");

	    return reportDataModels;
	}
	private List<ReportDataModel> generateReportData(List<ReportErrorModel> results) {
	    Map<String, List<ReportErrorModel>> groupedByMonth = groupByMonth(results);
	    List<ReportDataModel> reportDataModels = new ArrayList<>();
	    log.debug("enter into the generateReportData method call");

	    try {
	        for (Map.Entry<String, List<ReportErrorModel>> entry : groupedByMonth.entrySet()) {
	            String month = entry.getKey();
	            List<ReportErrorModel> data = entry.getValue();	            
	            List<ReportErrorModel> cfinResults = data.stream().filter(cfin -> "1".equals(cfin.getSystemId())).collect(Collectors.toList());
	            List<ReportErrorModel> dathubResults = data.stream().filter(dathub -> "2".equals(dathub.getSystemId())).collect(Collectors.toList());
	            List<ReportErrorModel> bravoResults = data.stream().filter(bravo -> bravo.getSystemId().equals("3")).collect(Collectors.toList());
				List<ReportErrorModel> anaplanResults = data.stream().filter(anaplan -> anaplan.getSystemId().equals("4")).collect(Collectors.toList());
				List<ReportErrorModel> a1Results = data.stream().filter(a1 -> a1.getSystemId().equals("5")).collect(Collectors.toList());
				List<ReportErrorModel> sacResults = data.stream().filter(sac -> sac.getSystemId().equals("6")).collect(Collectors.toList());
				
	            Optional<String> sysNameCfin = cfinResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameDatahub = dathubResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            
	            Optional<String> sysNameBravo = bravoResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameAnaplan = anaplanResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameA1 = a1Results.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameSac = sacResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();

	            ReportDataModel reportDataModel = new ReportDataModel();
	           // reportDataModel.setYear(month);

	            ReportStats reportStats = new ReportStats();
	            
	            if (sysNameCfin.isPresent()) {
	                log.debug("enter into the cfin logic");
	               // reportStats.setSysName(sysNameCfin.get());
	                SysNameWiseStats cfinStats = createSysNameWiseStats(month, cfinResults, sysNameCfin.get());
	                reportStats.setSysNamewiseStats(new ArrayList<>(Collections.singletonList(cfinStats))); // Convert to mutable list
	            }/* else {
	                reportStats.setSysName("No Name Available"); // Handle the case when sysName is not present
	                reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list
	            } */
	            log.debug("end of cfin logic");

	            if (sysNameDatahub.isPresent()) {
	                log.debug("enter into the ddgr logic");
	                SysNameWiseStats dathubStats = createSysNameWiseStats(month, dathubResults, sysNameDatahub.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(dathubStats);
	                log.debug("end of ddgr logic");
	            }
	            
	            if (sysNameBravo.isPresent()) {
	                log.debug("enter into the bravo logic");
	                SysNameWiseStats bravoStats = createSysNameWiseStats(month, bravoResults, sysNameBravo.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(bravoStats);
	                log.debug("end of bravo logic");
	            }
	            
	            if (sysNameAnaplan.isPresent()) {
	                log.debug("enter into the anaplanStats logic");
	                SysNameWiseStats anaplanStats = createSysNameWiseStats(month, anaplanResults, sysNameAnaplan.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(anaplanStats);
	                log.debug("end of anaplanStats logic");
	            }
	            
	            if (sysNameA1.isPresent()) {
	                log.debug("enter into the a1 logic");
	                SysNameWiseStats a1Stats = createSysNameWiseStats(month, a1Results, sysNameA1.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(a1Stats);
	                log.debug("end of a1 logic");
	            }
	            
	            if (sysNameSac.isPresent()) {
	                log.debug("enter into the sac logic");
	                SysNameWiseStats sacStats = createSysNameWiseStats(month, sacResults, sysNameSac.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(sacStats);
	                log.debug("end of sac logic");
	            }

	            reportDataModel.setStats(reportStats);
	            reportDataModels.add(reportDataModel);
	        }
	    } catch (Exception e) {
	        log.error("Exception: " + e.getMessage(), e);
	    }
	    log.debug("end of generateReportData method call");

	    return reportDataModels;
	}
	private List<ReportDataModel> generateReportIdData(List<ReportErrorModel> results) {
	    Map<String, List<ReportErrorModel>> groupedByMonth = groupByMonth(results);
	    List<ReportDataModel> reportDataModels = new ArrayList<>();
	    log.debug("enter into the generateReportData method call");

	    try {
	        for (Map.Entry<String, List<ReportErrorModel>> entry : groupedByMonth.entrySet()) {
	            String month = entry.getKey();
	            List<ReportErrorModel> data = entry.getValue();
	            List<ReportErrorModel> cfinResults = data.stream().filter(cfin -> "1".equals(cfin.getSystemId())).collect(Collectors.toList());
	            List<ReportErrorModel> dathubResults = data.stream().filter(dathub -> "2".equals(dathub.getSystemId())).collect(Collectors.toList());
	            List<ReportErrorModel> bravoResults = results.stream().filter(bravo -> bravo.getSystemId().equals("3")).collect(Collectors.toList());
				List<ReportErrorModel> anaplanResults = results.stream().filter(anaplan -> anaplan.getSystemId().equals("4")).collect(Collectors.toList());
				List<ReportErrorModel> a1Results = results.stream().filter(a1 -> a1.getSystemId().equals("5")).collect(Collectors.toList());
				List<ReportErrorModel> sacResults = results.stream().filter(sac -> sac.getSystemId().equals("6")).collect(Collectors.toList());
				
	            Optional<String> sysNameCfin = cfinResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameDatahub = dathubResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            
	            Optional<String> sysNameBravo = bravoResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameAnaplan = anaplanResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameA1 = a1Results.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();
	            Optional<String> sysNameSac = sacResults.stream().map(ReportErrorModel::getSystemId).distinct().findFirst();

	            ReportDataModel reportDataModel = new ReportDataModel();
	           // reportDataModel.setYear(month);

	            ReportStats reportStats = new ReportStats();

	            if (sysNameCfin.isPresent()) {
	                log.debug("enter into the cfin logic");
	               // reportStats.setSysName(sysNameCfin.get());
	                SysNameWiseStats cfinStats = createSysNameWiseStats(month, cfinResults, sysNameCfin.get());
	                reportStats.setSysNamewiseStats(new ArrayList<>(Collections.singletonList(cfinStats))); // Convert to mutable list
	            }/* else {
	                reportStats.setSysName("No Name Available"); // Handle the case when sysName is not present
	                reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list
	            } */
	            log.debug("end of cfin logic");

	            if (sysNameDatahub.isPresent()) {
	                log.debug("enter into the ddgr logic");
	                SysNameWiseStats dathubStats = createSysNameWiseStats(month, dathubResults, sysNameDatahub.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(dathubStats);
	                log.debug("end of ddgr logic");
	            }
	            
	            if (sysNameBravo.isPresent()) {
	                log.debug("enter into the bravo logic");
	                SysNameWiseStats bravoStats = createSysNameWiseStats(month, bravoResults, sysNameBravo.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(bravoStats);
	                log.debug("end of bravo logic");
	            }
	            
	            if (sysNameAnaplan.isPresent()) {
	                log.debug("enter into the anaplanStats logic");
	                SysNameWiseStats anaplanStats = createSysNameWiseStats(month, anaplanResults, sysNameAnaplan.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(anaplanStats);
	                log.debug("end of anaplanStats logic");
	            }
	            
	            if (sysNameA1.isPresent()) {
	                log.debug("enter into the a1 logic");
	                SysNameWiseStats a1Stats = createSysNameWiseStats(month, a1Results, sysNameA1.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(a1Stats);
	                log.debug("end of a1 logic");
	            }
	            
	            if (sysNameSac.isPresent()) {
	                log.debug("enter into the sac logic");
	                SysNameWiseStats sacStats = createSysNameWiseStats(month, sacResults, sysNameSac.get());
	                if (reportStats.getSysNamewiseStats() == null) {
	                    reportStats.setSysNamewiseStats(new ArrayList<>()); // Initialize an empty list if it's null
	                }
	                reportStats.getSysNamewiseStats().add(sacStats);
	                log.debug("end of sac logic");
	            }

	            reportDataModel.setStats(reportStats);
	            reportDataModels.add(reportDataModel);
	        }
	    } catch (Exception e) {
	        log.error("Exception: " + e.getMessage(), e);
	    }
	    log.debug("end of generateReportData method call");

	    return reportDataModels;
	}



	public MonitorReportDTO requestsubmitcount( String year)  {	
		Date fromDate = null;
		Date toDate = null;
		MonitorReportDTO countDTO = new MonitorReportDTO();
		if (year == null || year.isEmpty()) {
	        year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
	    }	
		log.debug("year as :"+year);		
		try {			
			/*
			Calendar fromCalendar = Calendar.getInstance();	       
	        int yearValue = Integer.parseInt(year);	        
	        fromCalendar.set(Calendar.YEAR, yearValue);
	        fromCalendar.set(Calendar.MONTH, Calendar.JANUARY);
	        fromCalendar.set(Calendar.DAY_OF_MONTH, 1);
	        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
	        fromCalendar.set(Calendar.MINUTE, 0);
	        fromCalendar.set(Calendar.SECOND, 0);
	        fromCalendar.set(Calendar.MILLISECOND, 0);
	        Date fromDate = fromCalendar.getTime();
		        
	        Date toDate = new Date();
			
			log.debug("received fromDate as :"+fromDate);
			log.debug("received toDate as :"+toDate);
						
			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
            Date fromDateTime = sdf.parse(fromDate + " 00:00:00");
            Date toDateTime = sdf.parse(toDate + " 23:59:00");
            
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            fromDateTime = calendar.getTime();

            calendar.setTime(toDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            toDateTime = calendar.getTime();
            */
			int frYearValue = Integer.parseInt(year);	  
	        Calendar today = Calendar.getInstance();
	        int currentYear = today.get(Calendar.YEAR);
	       // Calendar toCalendar = Calendar.getInstance();
	        Calendar fromCalendar = Calendar.getInstance();	      		              
	        fromCalendar.set(Calendar.YEAR, frYearValue);
	        fromCalendar.set(Calendar.MONTH, Calendar.JANUARY);
	        fromCalendar.set(Calendar.DAY_OF_MONTH, 1);
	        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
	        fromCalendar.set(Calendar.MINUTE, 0);
	        fromCalendar.set(Calendar.SECOND, 0);
	        fromCalendar.set(Calendar.MILLISECOND, 0);
	        fromDate = fromCalendar.getTime();
	        
	       /* if(frYearValue < currentYear) {
	        	Calendar toCalendar = Calendar.getInstance();	      		              
	        	toCalendar.set(Calendar.YEAR, frYearValue);
	        	toCalendar.set(Calendar.MONTH, Calendar.JANUARY);
	        	toCalendar.set(Calendar.DAY_OF_MONTH, 1);
	        	toCalendar.set(Calendar.HOUR_OF_DAY, 0);
	        	toCalendar.set(Calendar.MINUTE, 0);
	        	toCalendar.set(Calendar.SECOND, 0);
	        	toCalendar.set(Calendar.MILLISECOND, 0);
		        toDate = toCalendar.getTime();
	        }else {
	        	toDate = new Date();
	        } */
	        Calendar toCalendar = Calendar.getInstance();	      		              
        	toCalendar.set(Calendar.YEAR, frYearValue);
        	toCalendar.set(Calendar.MONTH, Calendar.DECEMBER);
        	toCalendar.set(Calendar.DAY_OF_MONTH, 31);
        	toCalendar.set(Calendar.HOUR_OF_DAY, 0);
        	toCalendar.set(Calendar.MINUTE, 0);
        	toCalendar.set(Calendar.SECOND, 0);
        	toCalendar.set(Calendar.MILLISECOND, 0);
	        toDate = toCalendar.getTime();
	        	        			
			log.debug("received fromDate as :"+fromDate);
			log.debug("received toDate as :"+frYearValue);
						
			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
            Date fromDateTime = sdf.parse(fromDate + " 00:00:00");
            Date toDateTime   = sdf.parse(toDate + " 23:59:00");
            
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            fromDateTime = calendar.getTime();

            calendar.setTime(toDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            toDateTime = calendar.getTime();
            log.debug("fromDateTime as :"+fromDateTime);
            log.debug("toDateTime as :"+toDateTime); 
            
			List<ReportErrorModel> results = masterRepository.getAllRecordsCount(fromDateTime, toDateTime);
			log.debug("Total cout received :"+results.size());
			log.debug("object received from db :"+results);	
						
			List<ReportDataModel> reportDataModels = generateReportData(results);
			countDTO.setReports(reportDataModels);
	        countDTO.setStatusCode(200);
	        countDTO.setMessage("Success");					
		}catch(Exception ee) {
			log.error("Exception: " + ee.getMessage());
			countDTO.setStatusCode(500); 
		}
		
		return countDTO;		
	}
public RequestMonitorReportDTO requestidsubmitcount( String year)  {	
	Date fromDate = null;
	Date toDate = null;
		RequestMonitorReportDTO countDTO = new RequestMonitorReportDTO();		
		if (year == null || year.isEmpty()) {
	        year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
	    }	
		log.debug("year as :"+year);		
		try {	
			int frYearValue = Integer.parseInt(year);	  
	        Calendar today = Calendar.getInstance();
	        int currentYear = today.get(Calendar.YEAR);
	       // Calendar toCalendar = Calendar.getInstance();
	        Calendar fromCalendar = Calendar.getInstance();	      		              
	        fromCalendar.set(Calendar.YEAR, frYearValue);
	        fromCalendar.set(Calendar.MONTH, Calendar.JANUARY);
	        fromCalendar.set(Calendar.DAY_OF_MONTH, 1);
	        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
	        fromCalendar.set(Calendar.MINUTE, 0);
	        fromCalendar.set(Calendar.SECOND, 0);
	        fromCalendar.set(Calendar.MILLISECOND, 0);
	        fromDate = fromCalendar.getTime();
	        /*
	        if(frYearValue < currentYear) {
	        	Calendar toCalendar = Calendar.getInstance();	      		              
	        	toCalendar.set(Calendar.YEAR, frYearValue);
	        	toCalendar.set(Calendar.MONTH, Calendar.JANUARY);
	        	toCalendar.set(Calendar.DAY_OF_MONTH, 1);
	        	toCalendar.set(Calendar.HOUR_OF_DAY, 0);
	        	toCalendar.set(Calendar.MINUTE, 0);
	        	toCalendar.set(Calendar.SECOND, 0);
	        	toCalendar.set(Calendar.MILLISECOND, 0);
		        toDate = toCalendar.getTime();
	        }else {
	        	toDate = new Date();
	        } */
	        Calendar toCalendar = Calendar.getInstance();	      		              
        	toCalendar.set(Calendar.YEAR, frYearValue);
        	toCalendar.set(Calendar.MONTH, Calendar.DECEMBER);
        	toCalendar.set(Calendar.DAY_OF_MONTH, 31);
        	toCalendar.set(Calendar.HOUR_OF_DAY, 0);
        	toCalendar.set(Calendar.MINUTE, 0);
        	toCalendar.set(Calendar.SECOND, 0);
        	toCalendar.set(Calendar.MILLISECOND, 0);
	        toDate = toCalendar.getTime();
	        	        			
			log.debug("received fromDate as :"+fromDate);
			log.debug("received toDate as :"+frYearValue);
						
			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
            Date fromDateTime = sdf.parse(fromDate + " 00:00:00");
            Date toDateTime   = sdf.parse(toDate + " 23:59:00");
            
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            fromDateTime = calendar.getTime();

            calendar.setTime(toDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            toDateTime = calendar.getTime();
            
            log.debug("fromDateTime as :"+fromDateTime);
            log.debug("toDateTime as :"+toDateTime); 
            
			//List<ReportErrorModel> results = masterRepository.getAllRecordsCount(fromDateTime, toDateTime);
			//log.debug("Total cout received :"+results.size());
			//log.debug("object received from db :"+results);	
									
			//List<RequestReportDataModel> reportDataModels = generateRequestIdReportData(results);
			
			List<ReportHeaderModel> headerResults = masterRepository.getAllHeaderRecordsCount(fromDateTime, toDateTime);			
			List<RequestReportDataModel> reportDataModels = generateRequestIdHeaderData(headerResults);
			
			countDTO.setReports(reportDataModels);
	        countDTO.setStatusCode(200);
	        countDTO.setMessage("Success");	
	        
		}catch(Exception ee) {
			log.error("Exception: " + ee.getMessage());
			countDTO.setStatusCode(500); 
		}
		
		return countDTO;		
	}
	public SchedularStatusDTO schedularStatus(){
		 SchedularStatusDTO statusDTO = new SchedularStatusDTO();
	        Map<String, Object> statusMap = new HashMap<>();

	        statusMap.put("IAM/GRC Job Scheduler", getSchedulerDetails("edalIAMRequestScheduler"));
	        statusMap.put("IAM/GRC Status Scheduler", getSchedulerDetails("edalstatusScheduler"));

	        statusDTO.setStatus(statusMap);
	        statusDTO.setStatusCode(200);
	        return statusDTO;				
	}
	private Map<String, Object> getSchedulerDetails(String schedulerName) {
        Map<String, Object> details = new HashMap<>();
        details.put("lastExecutionTime", rqcUtilSchedular.getLastExecutionTime(schedulerName));
        details.put("fixedDelay", rqcUtilSchedular.getFixedDelay(schedulerName));
        return details;
    }
	public ReportErrorDTO getSuccessReport( Date fromDate, Date toDate)  {
		ReportErrorDTO reportDTO = new ReportErrorDTO();
		try {			
			log.debug("received fromDate as :"+fromDate);
			log.debug("received toDate as :"+toDate);
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.S");
			
			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
            Date fromDateTime = sdf.parse(fromDate + " 00:00:00");
            Date toDateTime = sdf.parse(toDate + " 23:59:00");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            fromDateTime = calendar.getTime();

            calendar.setTime(toDateTime);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            toDateTime = calendar.getTime();
            
            log.debug("fromDateTime as :"+fromDateTime);
            log.debug("toDateTime as :"+toDateTime); 
            
			List<ReportErrorModel> results = masterRepository.getAllSuccessReport(fromDateTime, toDateTime);
			log.debug("Total cout received :"+results.size());
			log.debug("object received from db :"+results);	
			
			for(ReportErrorModel result :results) {							
				String roleName = result.getRoleName();
				String sysId = result.getSystemId();
				/*if(!sysId.equals("1")) {					
					result.setSubm_status("E");	
					
				}
				if(sysId.equals("1")) {
					String errorMsg =result.getSubm_uid();
					result.setErrorMsg(errorMsg);
				}*/
				String inputDate = result.getSubm_date();				
				LocalDateTime localDateTime = LocalDateTime.parse(inputDate, inputFormatter);
				String outputDate = localDateTime.format(outputFormatter);
				result.setSubm_date(outputDate);				
				log.debug("getting roles for roleName :"+roleName+" sysId :"+sysId);	
				List<RoleADGrpMultiUserMdl> masterCacheRolesList = masterDataInMemoryService.findBySYS_IDAndAD_NAME(sysId,roleName);								
				if(masterCacheRolesList !=null && masterCacheRolesList.size()>0) {
					RoleADGrpMultiUserMdl model = masterCacheRolesList.stream().findFirst().orElse(null);
					result.setCuName(model.getPvName());
					result.setSystemName(model.getSysName());
					result.setPositionName(model.getPvName());										
				}
			}						
			reportDTO.setStatusCode(200);			
			reportDTO.setErrorReports(results);
		}catch(Exception ee) {
			log.error("Exception: " + ee.getMessage());
            reportDTO.setStatusCode(500); 
		}
		return reportDTO;		
	}
	public ReportResponse sendRequestTodownstream(ReportErrorModel reportErrorModel){
		boolean result = false;
		ReportResponse resonse = new ReportResponse();
		try {		
			log.debug("enter into the block");
			if (reportErrorModel.getSystemId().equals("1") ) {
				log.debug("enter into sysid block 1");
				int requId = Integer.parseInt(reportErrorModel.getReqId());
				ReqDpendncMdl detailNum = new ReqDpendncMdl();
				String adgrpid = reportErrorModel.getAdgrpid();
				log.debug("adgrpid as :"+adgrpid);
				detailNum.setAdids(adgrpid);
				//List<IAMRequestedRoleModel> respList = new ArrayList<>();
				
				List<IAMRequestedRoleModel> respList = iamGrcRequestSumbissionService.sendDataToGRC(requId, 1, reportErrorModel.getUserId(), reportErrorModel.getUserId(), reportErrorModel.getSystemId(), "re submit ", detailNum);
				
				//respList.add(createIAMRequestedRole(194, 100, "702205758", "1", "1", "pos1", "Position 1", "pv1", "PV 1", "1", "ZS1-FI-EXCHNGRT-MNT", "requester1", "re-submit", "N", "N", "Success", "API Message 1", "No Error"));
				if(respList != null && !respList.isEmpty()) {
					log.debug("recieved reposne as :"+respList);
					respList.stream().forEach(e -> {
						log.debug("received response as :"+e.getSubmStatus());
						log.debug("received response as :"+e.getSubmUid());						
					});				
					int recsInserted = absUserRequesDao.updateIamReqstedDataHubAnaplanRoles(respList);
					 if(recsInserted == respList.size()) {
						 result = true;
					 }
				}
			}else if(reportErrorModel.getSystemId().equals("2") || reportErrorModel.getSystemId().equals("3") || reportErrorModel.getSystemId().equals("4") || reportErrorModel.getSystemId().equals("5") || reportErrorModel.getSystemId().equals("6") ) {
				log.debug("enter into sysid block 2, 3, 4, 5, 6");
				int requId = Integer.parseInt(reportErrorModel.getReqId());
				ReqDpendncMdl detailNum = new ReqDpendncMdl();
				detailNum.setAdids(reportErrorModel.getAdgrpid());
				log.debug("adgrpid as :"+reportErrorModel.getAdgrpid());
				List<IAMRequestedRoleModel> respList = iamGrcRequestSumbissionService.sendDataToIAM(requId, 1, reportErrorModel.getUserId(),reportErrorModel.getUserId(), reportErrorModel.getSystemId(), "re submit ", detailNum);				
				if(respList != null && !respList.isEmpty()) {	
					respList.stream().forEach(e -> {
						log.debug("-----> submstatus value :"+e.getSubmStatus());
						log.debug("-----> submUid value :"+e.getSubmUid());						
					});
					log.debug("roles to update :"+respList);					
					int recsInserted = absUserRequesDao.updateIamReqstedDataHubAnaplanRoles(respList);
					 if(recsInserted == respList.size()) {
						 result = true;
					 }			       
				}
			}
			if(result) {				
				int requId = Integer.parseInt(reportErrorModel.getReqId());
				List<IAMRequestedRoleModel> userErrorList = absUserRequesDao.getEdalIamReqSubmittedErrorRoles(requId,"1");
				log.debug("size of the error list :"+userErrorList.size());
				
				if (userErrorList !=null && userErrorList.size() >0 ) {
					log.debug("not changing flag in header table since user has Error transactions");
					resonse.setStatusCode(500);
					resonse.setMessage("User's requests have errors. Check the view details for more information");					
				}else {
					log.debug("change the flag to the update the header table");
					iamGrcRequestSumbissionService.updateIamGrcRequestStatus(requId, Constants.PROVISIONING_WIP);
					resonse.setStatusCode(200);
					resonse.setMessage("User request is successful");
				}							
			}			
		}catch(Exception ee) {
			log.error("Exception :"+ee.getMessage());
		}
		return resonse;
	}
	  public  IAMRequestedRoleModel createIAMRequestedRole(
	            int reqId, int seqId, String userId, String sysId, String sysName, String posId, String posName,
	            String pvId, String pvName, String adgrpId, String adgrpName, String reqBy, String comments,
	            String submUid, String submStatus, String apiStatus, String apiMsg, String apiErrorMsg) {
	        IAMRequestedRoleModel role = new IAMRequestedRoleModel();
	        role.setReqId(reqId);
	        role.setSeqId(seqId);
	        role.setUserId(userId);
	        role.setSysId(sysId);
	        role.setSysName(sysName);
	        role.setPosId(posId);
	        role.setPosName(posName);
	        role.setPvId(pvId);
	        role.setPvName(pvName);
	        role.setAdgrpId(adgrpId);
	        role.setAdgrpName(adgrpName);
	        role.setReqBy(reqBy);
	        role.setComments(comments);
	        role.setSubmUid(submUid);
	        role.setSubmStatus(submStatus);
	        role.setApiStatus(apiStatus);
	        role.setApiMsg(apiMsg);
	        role.setUpdDate(new Date());
	        role.setApiErrorMsg(apiErrorMsg);
	        return role;
	    }
	}

	

