package com.jnj.rqc.controllers;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserSearchDao;
import com.jnj.rqc.mastermetadata.controller.MitigationRptMdl;
import com.jnj.rqc.mastermetadata.dao.MasterMetaDataRepository;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.models.AbsRestrictiveExcsvAccRespDto;
import com.jnj.rqc.userabs.models.AbsSodConflictRespDto;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RolesRespDto;
import com.jnj.rqc.userabs.models.UserConflictChckMdl;
import com.jnj.rqc.userabs.models.UserExcsvAccessChckMdl;
import com.jnj.rqc.userabs.models.ZUserDetailRespDto;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.userreq.dao.AbsUserRequesDao;
import com.jnj.rqc.util.Utility;





/**
 * File    : <b>UserAccessDataController.java</b>
 * @author : DChauras @Created : Mar 7, 2023 2:26:19 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */


@RestController
@RequestMapping("/v2/user")
public class UserAccessDataController {
	static final Logger log = LoggerFactory.getLogger(UserAccessDataController.class);

	@Autowired
	private UserSearchService userSearchService;
	@Autowired
	private UserAccessDataService userAccessDataService;
	@Autowired
	private AbsUserRequesDao absUserRequesDao;
	@Autowired
	UserSearchDao userSearchDao;


	@PostMapping("/getuserbyparams")
    public ResponseEntity<ZUserDetailRespDto> getUserByEmail(Model model, @RequestParam(name="userEmail", required = false) String userEmail, @RequestParam(name="userId", required = false) String userId, HttpServletRequest req) {
    	log.info("Received User EMAIL ID : "+userEmail+ " User ID: "+userId);
    	String currentEmail = "";
		if(userEmail!=null)
			currentEmail = userEmail.toLowerCase();
    	UserSearchModel assocUser = null;
    	ZUserDetailRespDto uRespDto = new ZUserDetailRespDto();
    	try {
    		if(userId != null && userId.length() > 0) {
        		assocUser = userSearchService.getUserStatusJJEDS(userId, 1);
        	}else if (userEmail != null && userEmail.length() > 0) {
        		assocUser = userSearchService.getUserStatusByEmailJJEDS(userEmail, 1);
        	}
    		
    		if(assocUser == null) {
    			if(userId != null && userId.length() > 0) {
            		assocUser = userSearchDao.getUserByWWIdFromJJEDS(userId).get(0);
            	}else if (userEmail != null && userEmail.length() > 0) {
            		assocUser = userSearchDao.getUserByEMailIdFromJJEDS(userEmail).get(0);
            	}
    		}

        	if(assocUser == null) {
        		uRespDto.setStatusCode(Constants.SERV_ERR);
        		uRespDto.setStatusDesc("Invalid or missing required parameters UserId/EmailId.");
        	}else {
        		UserSearchModel mgr = userSearchService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
        		if(mgr != null) {
        			assocUser.setJnjSupvrName(mgr.getFmlyNm()+", "+mgr.getGivenNm());
        			assocUser.setJnjSupvrEmail(mgr.getJnjEmailAddrTxt());
        		}
        		List<String> sysList = Arrays.asList("1","2","3","4");
        		try {
        			List<String> appEmailsLst = absUserRequesDao.getApproverCategoryEmails(sysList, 3);
    	    		Set<String> distinctEmails = appEmailsLst.stream()
    	    	    		.flatMap(emails -> Arrays.stream(emails.split(",")))
    	    	    		.map(String::trim)
    	    	    		.map(String::toLowerCase)
    	    	    		.collect(Collectors.toSet());
    	    		if(distinctEmails.contains(currentEmail)){
    	    			assocUser.setIsCompilanceMgr("Y");
    	    		}else {
    	    			assocUser.setIsCompilanceMgr("N");
    	    		}    	    		
        		} catch (Exception e) {
                    log.error("Exception: " + e.getMessage());
                    
                }
        		
        		uRespDto.setUserDetail(assocUser);
        		uRespDto.setStatusCode(0);
        		uRespDto.setStatusDesc("Found 1 User Data");
        	}
        	
        	uRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		} catch (Exception e) {
			uRespDto.setStatusCode(Constants.SERV_ERR);
			uRespDto.setStatusDesc("Error Looking up User Details : "+e.getMessage());
			log.error("Error Looking up User Details :"+e.getMessage(), e);
		}
    	if (uRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(uRespDto, HttpStatus.OK);
        } else if (uRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(uRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(uRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getExistingAccess")
    public ResponseEntity<RolesRespDto> getUserAccessDetails(Model model, @RequestParam("userId") String userId, HttpServletRequest req) {
    	log.info("Received User ID : "+userId);
    	System.out.println("USER REQUEST START CONTROLLER >>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));
    	UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userId, 1);
    	if(assocUser == null) {
    		try {
				assocUser = userSearchDao.getUserByWWIdFromJJEDS(userId).get(0);
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	RolesRespDto tableRespDto = userAccessDataService.getExistingRoles(userId);
    	System.out.println("USER REQUEST END CONTROLLER >>>>>>>>>>>>>>"+new java.util.Date(System.currentTimeMillis()));

    	tableRespDto.setAssocUser(assocUser);
    	if (tableRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }


	/*@PostMapping("/getExistingAccess")
    public ResponseEntity<RolesRespDto> getUserAccessDetails(Model model, @RequestParam("userId") String userId, HttpServletRequest req) {
    	log.info("Received User ID : "+userId);
    	UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userId, 1);
    	RolesRespDto tableRespDto = userAccessDataService.getExistingRoles(userId);

    	tableRespDto.setAssocUser(assocUser);
    	if (tableRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<RolesRespDto>(tableRespDto, HttpStatus.OK);
        } else if (tableRespDto.getStatusCode() == 500) {
			return new ResponseEntity<RolesRespDto>(tableRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<RolesRespDto>(tableRespDto, HttpStatus.NOT_FOUND);
        }
    }
*/

	@PostMapping("/checkAbsSodConflicts")
    public ResponseEntity<AbsSodConflictRespDto> checkAbsSodConflicts(@RequestBody UserConflictChckMdl userConflictChckMdl, HttpServletRequest request) {
		log.info(" checkAbsSodConflicts for REQOBJ: \n"+Utility.toJson(userConflictChckMdl));
		//log.info("userConflictChckMdl.userId: "+userConflictChckMdl.getUserid()+" Existing Roles : "+userConflictChckMdl.getExistingAccess().size()+" New Roles: "+userConflictChckMdl.getNewAccess().size());
    	AbsSodConflictRespDto respDto = new AbsSodConflictRespDto();

    	try{
    		UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userConflictChckMdl.getUserid(), 1);
    		List<RoleADGrpMdl> extRoles = (userConflictChckMdl.getExistingAccess() == null)? new ArrayList<>() :userConflictChckMdl.getExistingAccess();
    		List<RoleADGrpMdl> newRoles = userConflictChckMdl.getNewAccess();
    		//START - ROLES CONFLICTS
    		respDto =  userAccessDataService.checkAbsSodConflicts(assocUser.getWwId(), newRoles, extRoles);
    		//END - ROLES CONFLICTS
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	if (respDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(respDto, HttpStatus.NOT_FOUND);
        }
    }

	//OLD Method - Will be removed
	/*@PostMapping("/checkAbsExcsvAccess")
    public ResponseEntity<AbsExcsvAccessRespDto> checkAbsExcsvAccess(@RequestBody UserExcsvAccessChckMdl userExcsvAccessChckMdl, HttpServletRequest request) {
		log.info(" checkAbsExcsvAccess for REQOBJ: \n"+Utility.toJson(userExcsvAccessChckMdl));
		log.info("Excessive Access Check for User ID : "+userExcsvAccessChckMdl.getUserid());
    	AbsExcsvAccessRespDto respDto = new AbsExcsvAccessRespDto();

    	try{
    		UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userExcsvAccessChckMdl.getUserid(), 1);
    		Map<String, List<RoleADGrpMdl>> extRoles = userExcsvAccessChckMdl.getExistingAccess();
    		Map<String, List<RoleADGrpMdl>> newRoles = userExcsvAccessChckMdl.getNewAccess();
    		//START - EXCESSIVE ACCESS CHECK
    		List<AbsExcesvAccsMdl> excsvList = userAccessDataService.checkExcessiveAccess(assocUser, extRoles, newRoles);
    		respDto.setExcsvAccessList(excsvList);
    		respDto.setStatusCode(0);
    		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    		//END - EXCESSIVE ACCESS CHECK
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
			respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc("Error Getting Excessive Access Info :"+e.getMessage());
		}
    	if (respDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<AbsExcsvAccessRespDto>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<AbsExcsvAccessRespDto>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<AbsExcsvAccessRespDto>(respDto, HttpStatus.NOT_FOUND);
        }
    }*/

	//New Method
	@PostMapping("/checkAbsRestrictiveAcss")
    public ResponseEntity<AbsRestrictiveExcsvAccRespDto> checkAbsResExcsvAccess(@RequestBody UserExcsvAccessChckMdl userExcsvAccessChckMdl, HttpServletRequest request) {
		log.info(" checkAbsRestrictiveAcss for REQOBJ: \n"+Utility.toJson(userExcsvAccessChckMdl));
		log.info("Restrictive/Excessive Access Check for User ID : "+userExcsvAccessChckMdl.getUserid());
		AbsRestrictiveExcsvAccRespDto respDto = new AbsRestrictiveExcsvAccRespDto();

    	try{
    		UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userExcsvAccessChckMdl.getUserid(), 1);
    		Map<String, List<RoleADGrpMdl>> extRoles = userExcsvAccessChckMdl.getExistingAccess();
    		Map<String, List<RoleADGrpMdl>> newRoles = userExcsvAccessChckMdl.getNewAccess();
    		//START - EXCESSIVE ACCESS CHECK
    		List<AbsSysLeveExcsvRestrMdl> restExcsvList = userAccessDataService.checkRestrtvExcessiveAccess(assocUser, extRoles, newRoles, false);
    		respDto.setRestExcsvAcssList(restExcsvList);
    		respDto.setStatusCode(0);
    		respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
    		//END - EXCESSIVE ACCESS CHECK
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
			respDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc("Error Getting Excessive Access Info :"+e.getMessage());
		}
    	if (respDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(respDto, HttpStatus.NOT_FOUND);
        }
    }





	/*


	@PostMapping("/newAccessSelectionConfirmation")
    public String newAccessSelectionConfirmation(@RequestParam("bussFunc") String bussFunc, @RequestParam("secCheckBx") String secCheckBx, @RequestParam("regCheckBx") String regCheckBx,
    		@RequestParam("selectedSystems") String selectedSystems, Model model, HttpServletRequest request) {
    	log.info("bussFunc: "+bussFunc+" secCheckBx: "+secCheckBx+" regCheckBx: "+regCheckBx+" selectedSystems:"+selectedSystems);

    	List<KeyValPair> newPosVarLst = new ArrayList<KeyValPair>();
    	List<KeyValPair> extPosVarLst = new ArrayList<KeyValPair>();
    	Map<String, List<KeyValPair>> adGrpMap = new HashMap<String, List<KeyValPair>>();
    	Map<String, String> systemMap = new HashMap<String, String>();
    	List<KeyValPair> systemLst = userIdentityService.getAllMasterRegionSystems(bussFunc, secCheckBx, regCheckBx);
    	model.addAttribute("systemLst", systemLst);
    	model.addAttribute("sysParam", selectedSystems);
    	request.getSession().setAttribute("sysParam", selectedSystems);
    	for(KeyValPair sysKv:systemLst) {
    		systemMap.put(sysKv.getKey()+"", sysKv.getVal());
    	}

    	List<SysPosAdGrpModelDispMdl> dispModelLst = new LinkedList<SysPosAdGrpModelDispMdl>();
    	for(String ky:selectedSystems.split(",")) {
    		String[] arrPosns 	= request.getParameterValues("usrPosition_"+ky);
    		String selPosns 	= Utility.getArrValues(arrPosns);
    		List<KeyValPair> posLst = userIdentityService.getAllMasterSystemPositions(bussFunc, secCheckBx, regCheckBx, ky, selPosns);//Position List
    		String[] arrAcssTyp = request.getParameterValues("accessType_"+ky);
    		String selAcssTyp 	= Utility.getArrValues(arrAcssTyp);
    		List<KeyValPair> acsTypLst = userIdentityService.getAllMasterPosnsAccsTypes(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp);
    		String[] arrPosnVr 	= request.getParameterValues("posnVariant_"+ky);
    		String selPosnVr  	= Utility.getArrValues(arrPosnVr);
    		List<KeyValPair> posVarLst = userIdentityService.getAllMasterAcsTypsPosVarnt(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp, selPosnVr);//Position Variants
    		newPosVarLst.addAll(posVarLst);//Collecting all Position Variants selected by User
    		List<KeyValPair> appAdGrps = new ArrayList<KeyValPair>();
    		List<UserRoleADGrpMdl> appUrAdGrps  = userIdentityService.getAllMasterPosVarntADGrp(bussFunc, secCheckBx, regCheckBx, ky, selPosns, selAcssTyp, selPosnVr);
    		appUrAdGrps = userIdentityService.checkExistingADGroups(appUrAdGrps, request);
    		appUrAdGrps = userIdentityService.removeExistingADGroups(appUrAdGrps);
    		String adGrpIds="";
    		for(UserRoleADGrpMdl obj:appUrAdGrps){
    			KeyValPair kv = new KeyValPair();
    			kv.setKey(Integer.parseInt(obj.getAdgrpId()));
    			kv.setVal(obj.getAdgrpName());
    			appAdGrps.add(kv);
    			if("".equals(adGrpIds)) {
    				adGrpIds=obj.getAdgrpId();
    			}else {
    				adGrpIds+=","+obj.getAdgrpId();
    			}
    		}

    		List<String> allSysVarList = userIdentityService.getAllSystemPosVariants(bussFunc, secCheckBx, regCheckBx, ky);
    		List<KeyValPair> allSysVarListKV = userIdentityService.getAllSystemPosVariantsKV(bussFunc, secCheckBx, regCheckBx, ky);

    		SysPosAdGrpModelDispMdl dispMdl = new SysPosAdGrpModelDispMdl();
    		dispMdl.setBussFunc(bussFunc);
    		dispMdl.setSecIds(secCheckBx);
    		dispMdl.setRegIds(regCheckBx);
    		dispMdl.setSysId(ky);
    		dispMdl.setSysName(systemMap.get(ky));
    		dispMdl.setPosIds(selPosns);
    		dispMdl.setPositions(posLst);
    		dispMdl.setAscTypIds(selAcssTyp);
    		dispMdl.setAcsTypes(acsTypLst);
    		dispMdl.setPosVarIds(selPosnVr);
    		dispMdl.setPosnVariants(posVarLst);
    		dispMdl.setAdGrpIds(adGrpIds);
    		dispMdl.setAppAdGrps(appUrAdGrps);
    		dispMdl.setAllSysVarList(allSysVarList);
    		dispMdl.setAllSysVarListKV(allSysVarListKV);
    		dispModelLst.add(dispMdl);
    	}

    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	UserSearchModel assocUser = (UserSearchModel)request.getSession().getAttribute("assocUser");
    	model.addAttribute("assocUser", assocUser);
    	model.addAttribute("AUTH_USER", curUser);

    	model.addAttribute("assocWwidPrm", assocUser.getWwId());
    	model.addAttribute("assocNamePrm", assocUser.getFmlyNm()+" "+assocUser.getGivenNm());

    	List<KeyValPair> reqType 	= userIdentityService.getAllRequestTypes();
    	String rqTypParam 			= (String) request.getSession().getAttribute("reqTyp");
		model.addAttribute("rqTypParam", Integer.parseInt(rqTypParam));
    	model.addAttribute("reqType", reqType );

    	List<StrKeyValPair> bussFunctions = userIdentityService.getBusinesFunctions("");
		model.addAttribute("bussFunctions", bussFunctions);
		model.addAttribute("bfuncParam", bussFunc);
		request.getSession().setAttribute("bfuncParam", bussFunc);

    	List<KeyValPair> sectrChkLst = userIdentityService.getBussFuncSectors(bussFunc);
    	model.addAttribute("sectrChkLst", sectrChkLst );
    	model.addAttribute("sectrParam", Arrays.asList(secCheckBx.split(",")));
    	request.getSession().setAttribute("sectrParam", secCheckBx);

    	List<KeyValPair> regnChkLst = userIdentityService.getAllMasterSectorRegions(bussFunc, secCheckBx);
    	model.addAttribute("regnChkLst", regnChkLst);
    	model.addAttribute("regnParam", Arrays.asList(regCheckBx.split(",")));
    	request.getSession().setAttribute("regnParam", regCheckBx);

    	model.addAttribute("dispDataLst", dispModelLst);//Data to Display
    	request.getSession().setAttribute("dispDataLst", dispModelLst);

    	try{
    		List<UserRoleADGrpMdl> extRoles = (request.getSession().getAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+assocUser.getWwId()) == null)? new ArrayList<UserRoleADGrpMdl>() : (List<UserRoleADGrpMdl>)request.getSession().getAttribute(Constants.ASSOC_EXISTING_ROLES+"_"+assocUser.getWwId());
    		List<String> newPosnVarIds = new ArrayList<String>();
    		List<String> extPosnVarIds = new ArrayList<String>();
    		//newPosVarLst
    		newPosVarLst.forEach(er ->{
    			newPosnVarIds.add(er.getKey()+"");
    		});
    		//ExistingPosVarLst
    		extRoles.forEach(er ->{
    			if(er.getPvId() != null && er.getPvId().length() > 0) {
    				extPosnVarIds.add(er.getPvId());
    			}
    		});


    		//Calculate EXCESSIVE ACCESS var = SYS_ACCESS_LIMIT
    		List<ExcessiveAccessModel> exList = userIdentityService.checkExcessiveAccess(dispModelLst, extRoles, assocUser);
    		request.getSession().removeAttribute("EXCESSIVE_ACCESS");
    		if(!exList.isEmpty()) {
    			model.addAttribute("EXCESSIVE_ACCESS", exList);
    			request.getSession().setAttribute("EXCESSIVE_ACCESS", exList);
    		}
    		//END Excessive Access

        	//START - ROLES CONFLICTS
    		List<UserIdentityConflictMdl> confList = userIdentityService.checkSodConflicts(assocUser.getWwId(), newPosnVarIds, extPosnVarIds);
    		if(confList != null && !confList.isEmpty()) {
    			model.addAttribute("confList", confList);
    			request.getSession().setAttribute("confList", confList);
    			request.getSession().setAttribute("CONFLICTS", "Y");
    		}else {
    			request.getSession().removeAttribute("confList");
        		request.getSession().setAttribute("CONFLICTS", "N");
    		}
    		//END - ROLES CONFLICTS
    	} catch (Exception e) {
			log.error("Error :"+e.getMessage(), e);
		}
    	return "useridm/newAccessConfPageData";
    }


	/*END - Adding All New Methods for Data Collection HERE*/




  }
