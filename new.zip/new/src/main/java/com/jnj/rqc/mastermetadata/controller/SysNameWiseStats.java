package com.jnj.rqc.mastermetadata.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SysNameWiseStats {	
	 private String month;
	 private String requestCreated;
	 private int requestSubmitted;
	 private int requestFailed;
	 private String sysName;
	 private int ReqCreatedcount;
	 private String sysNm;
	 private String mm;
	 private int yyyy;
}
