package com.jnj.rqc.pos.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PosAppModel {
	private int applnId;
	private String applnNm;
	private String applnDescn;
	private int display;
	private String helpfullTip;
	private String chk;
	private String remChk;
    private int grpId;
    private int applnCatId;
    private int applnSubCatId;
    private String grpNm;
    private String appOrd;

}
