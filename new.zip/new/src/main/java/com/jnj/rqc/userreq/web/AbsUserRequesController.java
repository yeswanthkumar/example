package com.jnj.rqc.userreq.web;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserSearchDao;
import com.jnj.rqc.masterdata.dto.CancelRejectRespDto;
import com.jnj.rqc.masterdata.dto.ComplianceApprRespDto;
import com.jnj.rqc.masterdata.dto.ZMitigatingControlRespDto;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.models.AbsCancelRejectRequestModel;
import com.jnj.rqc.userabs.models.AbsComplianceRequest;
import com.jnj.rqc.userabs.models.AbsReqSubmitRespDto;
import com.jnj.rqc.userabs.models.AbsRequestDetailsRespDto;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.AbsUserRequestRespDto;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ReqCountRespDto;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.ReqSrchConstDto;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.userreq.dao.AbsUserRequesDao;
import com.jnj.rqc.userreq.service.AbsUserRequestService;
import com.jnj.rqc.util.Utility;

@RestController
@RequestMapping("/v2/absuser")
public class AbsUserRequesController {

	static final Logger log = LoggerFactory.getLogger(AbsUserRequesController.class);

	@Autowired
	private AbsUserRequestService absUserRequestService;

	@Autowired
	private UserSearchService userSearchService;
	
	@Autowired
	private AbsUserRequesDao absUserRequesDao;
	
	@Autowired
	UserSearchDao userSearchDao;

	@GetMapping("/getpendingrequestcount/{userId}")
    public ResponseEntity<ReqCountRespDto> getPendingRequestCount(@PathVariable("userId") String userId, HttpServletRequest request) {
		log.info(" Get search constant values");
		ReqCountRespDto pRespDto = absUserRequestService.searchPendingReqCount(userId);

    	if (pRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(pRespDto, HttpStatus.OK);
        } else if (pRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(pRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(pRespDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getsearchconst")
    public ResponseEntity<ReqSrchConstDto> getRequestSearchConstants(HttpServletRequest request) {
		log.info(" Get search constant values");
		ReqSrchConstDto srchCnsDto = absUserRequestService.getSearchConstants();

    	if (srchCnsDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(srchCnsDto, HttpStatus.OK);
        } else if (srchCnsDto.getStatusCode() == 500) {
			return new ResponseEntity<>(srchCnsDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(srchCnsDto, HttpStatus.NOT_FOUND);
        }
    }


	@PostMapping("/getuserrequests")
    public ResponseEntity<AbsUserRequestRespDto> getUserRequestData(@RequestParam(name = "startDate", required = true) String startDate, @RequestParam(name = "endDate", required = true) String endDate,
    		@RequestParam(name="paramType", required = false, defaultValue = "0") int paramType, @RequestParam(name = "paramValue", required = false) String paramValue, HttpServletRequest request) {
		log.info("startDate :"+startDate+"  endDate:"+endDate+"  paramType: "+paramType+"  paramValue: "+paramValue);
		AbsUserRequestRespDto reqRespDto = new AbsUserRequestRespDto();
		//if()
		reqRespDto = absUserRequestService.getAllRequestData(startDate, endDate, paramType, paramValue);

    	if (reqRespDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(reqRespDto, HttpStatus.OK);
        } else if (reqRespDto.getStatusCode() == 500) {
			return new ResponseEntity<>(reqRespDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(reqRespDto, HttpStatus.NOT_FOUND);
        }
    }



	/**
		 * Method  : AbsUserRequesController.java.absRequestSubmit()
		 *		   :<b>@param userReqCompMdl
		 *		   :<b>@param request
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 5, 2023 1:46:26 PM
		 * Purpose : Save Request Data
		 * @return : ResponseEntity<AbsReqSubmitRespDto>
		 */
	@PostMapping("/absRequestSubmit")
    public ResponseEntity<AbsReqSubmitRespDto> absRequestSubmit(@RequestBody UserReqCompMdl userReqCompMdl, HttpServletRequest request) {
    	log.info("Starting Request Submit Process for REQOBJ: \n"+Utility.toJson(userReqCompMdl));

    	AbsReqSubmitRespDto subDto = new AbsReqSubmitRespDto();
    	try{
    		UserSearchModel curUser = userSearchService.getUserStatusJJEDS(userReqCompMdl.getRequestedby(), 1);
    		//Added as part of new User fix
    	 	if(curUser == null) { 
    	 		log.info("curUser is not available in view. Pulling user details from source db :"+userReqCompMdl.getRequestedby());   	 		
        		curUser = userSearchDao.getUserByWWIdFromJJEDS(userReqCompMdl.getRequestedby()).get(0);    			
        	}
    		userReqCompMdl.setRequestedbyname(curUser.getGivenNm()+" "+curUser.getFmlyNm());
    		
        	UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(userReqCompMdl.getUserid(), 1);        			
    		//Added as part of new User fix
    	 	if(assocUser == null) {
    	 		log.info("assocUser is not available in view. Pulling user details from source db :"+userReqCompMdl.getUserid());
        		assocUser = userSearchDao.getUserByWWIdFromJJEDS(userReqCompMdl.getUserid()).get(0);      							        			
        	}
        	userReqCompMdl.setUsername(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
        	UserSearchModel mgrUser = userSearchService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(), 1);
        	userReqCompMdl.setManagername(mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm());
    		int requestId = absUserRequestService.saveAbsRequestData(userReqCompMdl, curUser, assocUser, mgrUser);
    		subDto.setReqid(requestId+"");
    		subDto.setStatusCode(Constants.SUCCESS);
    	} catch (Exception e) {
    		subDto.setStatusCode(Constants.SERV_ERR);
    		subDto.setStatusDesc(e.getMessage());
			log.error("Error :"+e.getMessage(), e);
		}
    	if (subDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(subDto, HttpStatus.OK);
        } else if (subDto.getStatusCode() == 500) {
			return new ResponseEntity<>(subDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(subDto, HttpStatus.NOT_FOUND);
        }
    }



	/**
	 * Method  : AbsUserRequesController.java.getDetailsByTktNum()
	 *		   :<b>@param tktnumber
	 *		   :<b>@param request
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Apr 12, 2023 3:59:14 PM
	 * Purpose : Get Requet/Ticket Details by Request ID/Tkt Number
	 * @return : String
	*/
	@GetMapping("/getDetailsByTktNum")
	public ResponseEntity<AbsRequestDetailsRespDto> getDetailsByTktNum(@RequestParam String tktnumber, @RequestParam String userEmail, HttpServletRequest request) {
		log.info("Received Ticket number: "+tktnumber);
		String currentEmail = "";
		if(userEmail!=null)
			currentEmail = userEmail.toLowerCase();
		AbsRequestDetailsRespDto reqRespDto = new AbsRequestDetailsRespDto();
		AbsUserReqMdl tktData = absUserRequestService.getRequestDataByID(tktnumber);
		reqRespDto.setReqData(tktData);

		if(tktData != null) {
			List<ReqDpendncMdl> systemDepncs =  absUserRequestService.getTktDependency(tktnumber);
			//List<SysDpendncMdl> sysDataList = new ArrayList<>();
			Map<String, List<RawSysDpendncMdl>>sysData = new HashMap<>();
			tktData.setSysList(sysData);
			for(ReqDpendncMdl sysDep:systemDepncs) {
				List<RawSysDpendncMdl> sysDpndncLst = absUserRequestService.getSysDependencies(sysDep.getSysid(), sysDep.getPosids(), sysDep.getAccids(), sysDep.getPosvarids());//Position List
	    		if(sysDpndncLst != null && !sysDpndncLst.isEmpty()) {
	    			sysData.put(sysDpndncLst.get(0).getSysid()+"-"+sysDpndncLst.get(0).getSysname(), sysDpndncLst);
	    		}
	    	}
			if(tktData.getTypeid() != 2 ) {							
		    	if("Y".equals(tktData.getConflictFound())) {
		    		List<UserAbsConflictMdl> confList = absUserRequestService.getAllReqLvlConflicts(tktData.getReqid()+"");
		    		if(confList != null && !confList.isEmpty()) {
		    			tktData.setConfList(confList);
		    		}
		    	}
	
		    	if("Y".equals(tktData.getIsExces())) {
		    		//List<AbsExcesvAccsMdl> exList  = absUserRequestService.getReqLvlExcData(tktData.getReqid()+"");
		    		//tktData.setExcsvList(exList);
		    		List<AbsSysLeveExcsvRestrMdl> restExcsvAcssList = absUserRequestService.getReqLvlRestrExcsvData(tktData.getReqid()+"");
		    		tktData.setRestExcsvAcssList(restExcsvAcssList);
		    	}
		    	
		    	List<RoleADGrpMdl> duplicateList = absUserRequestService.getDuplicateRecords(tktData.getReqid()+"", tktData.getUserid());
		    	if(duplicateList != null && !duplicateList.isEmpty()) {	    	
		    		tktData.setDuplicateList(duplicateList);
		    	}
			}
			
	    	List<String> sysList = Arrays.asList("1","2","3","4");
	    	try {
	    		//Added code to segrigate the compliance manager for Support IT BF
	    		List<AbsUserReqMdl> bfnList = absUserRequesDao.getRequestedDetailsFromHeader(tktData.getReqid()+"");
	    		
	    		boolean bfnAnyMatch = bfnList.stream()
	                    .anyMatch(e -> e.getBfid().equals("9"));
	    		
	    		if(bfnAnyMatch) {
	    			List<String> bfsysList = Arrays.asList("5");
	    			List<String> appEmailsLst = absUserRequesDao.getApproverCategoryEmails(bfsysList, 4);
	    			Set<String> distinctEmBF = appEmailsLst.stream()
	    								.flatMap(e -> Arrays.stream(e.split(",")))
	    								.map(String::trim)
	    								.map(String::toLowerCase)
	    								.collect(Collectors.toSet());
	    											
	    			if(distinctEmBF.contains(currentEmail)) {
	    				reqRespDto.setIsCompilanceMgr("Y");
	    			}else {
	    				reqRespDto.setIsCompilanceMgr("N");
	    			}
	    			
	    		} else {  		
		    		List<String> appEmailsLst = absUserRequesDao.getApproverCategoryEmails(sysList, 3);
		    		Set<String> distinctEmails = appEmailsLst.stream()
		    		.flatMap(emails -> Arrays.stream(emails.split(",")))
		    		.map(String::trim)
		    		.map(String::toLowerCase)
		    		.collect(Collectors.toSet());
		    		log.debug("List of compilance managers :"+distinctEmails);
		    		log.debug("currentEmail received from request after lowercase :"+currentEmail);
		    		
		    		if(distinctEmails.contains(currentEmail)){
		    			reqRespDto.setIsCompilanceMgr("Y");
		    		}else {
		    			reqRespDto.setIsCompilanceMgr("N");
		    		}
	    		}
	    	}catch(Exception ee) {
	    		log.error("Excetion : while getting the emails for compilace review"+ee.getMessage());
	    	}
	    }
		return new ResponseEntity<>(reqRespDto, HttpStatus.OK);
	}


	/**
		 * Method  : AbsUserRequesController.java.getMitigatingControls()
		 *		   :<b>@param mitigatingid
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 5, 2023 1:47:23 PM
		 * Purpose : Get All the Mitigating Controls from DB
		 * @return : ResponseEntity<ZMitigatingControlRespDto>
		 */
	@GetMapping("/getmitigatingcntrls")
	public ResponseEntity<ZMitigatingControlRespDto> getMitigatingControls(@RequestParam(name="mitigatingid", required = false, defaultValue = "0") String mitigatingid){
		log.info("Received mitigatingid: "+mitigatingid);
		List<StrKeyValPair> mitiCntrlLst = absUserRequestService.getAllMitigatingControls(mitigatingid, "C");//MITIGATING CONTROLS
		ZMitigatingControlRespDto cntrlDto = new ZMitigatingControlRespDto();
		cntrlDto.setMitiCntrlLst(mitiCntrlLst);
		cntrlDto.setStatusCode(Constants.SUCCESS);
		cntrlDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
    	if (cntrlDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(cntrlDto, HttpStatus.OK);
        } else if (cntrlDto.getStatusCode() == 500) {
			return new ResponseEntity<>(cntrlDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(cntrlDto, HttpStatus.NOT_FOUND);
        }
	}



	/**
		 * Method  : AbsUserRequesController.java.saveApprovalStage()
		 *		   :<b>@param absComplianceRequest
		 *		   :<b>@param request
		 *		   :<b>@return</b>
		 * @author : DChauras  @Created :May 5, 2023 1:47:04 PM
		 * Purpose : Save Compliance Approval
		 * @return : ResponseEntity<ComplianceApprRespDto>
		 */
	@PostMapping("/saveComplianceApprovalData")
    public ResponseEntity<ComplianceApprRespDto> saveApprovalStage(@RequestBody AbsComplianceRequest absComplianceRequest, HttpServletRequest request) {
		log.info(" APPROVAL DATA for (AbsComplianceRequest) REQOBJ: \n"+Utility.toJson(absComplianceRequest));
		log.info("SAVE APPROVAL DATA : Request Id: "+absComplianceRequest.getReqid()+" Approver User Id: "+ absComplianceRequest.getUserid());
    	UserSearchModel approveUser = userSearchService.getUserStatusJJEDS(absComplianceRequest.getUserid(), 1);
    	String result = absUserRequestService.saveComplApprovalData(approveUser, absComplianceRequest);
    	ComplianceApprRespDto respDto = new ComplianceApprRespDto();
    	respDto.setReqid(absComplianceRequest.getReqid());
    	respDto.setStatusDesc(result);
    	respDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
    	if("Success".equals(result)) {
    		respDto.setStatusCode(Constants.SUCCESS);
    	}else {
    		respDto.setStatusCode(Constants.ERROR);
    	}

    	if (respDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(respDto, HttpStatus.BAD_REQUEST);
        }
    }



	@PostMapping("/cancelRejectRequest")
    public ResponseEntity<CancelRejectRespDto> cancelRejectRequest(@RequestBody AbsCancelRejectRequestModel absCancelRejectRequestModel, HttpServletRequest request) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		log.info(" CANCEL/REJECT DATA for (cancelRejectRequest) REQOBJ: \n"+Utility.toJson(absCancelRejectRequestModel));
		log.info("CANCEL/REJECT DATA : Request Id: "+absCancelRejectRequestModel.getReqid()+" Approver User Id: "+ absCancelRejectRequestModel.getUserid());
    	UserSearchModel approveUser = userSearchService.getUserStatusJJEDS(absCancelRejectRequestModel.getUserid(), 1);

    	String result = absUserRequestService.saveCancelRejectStatus(approveUser, absCancelRejectRequestModel);
    	CancelRejectRespDto respDto = new CancelRejectRespDto();
    	respDto.setReqid(absCancelRejectRequestModel.getReqid());
    	respDto.setStatusDesc(result);
    	respDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
    	if("Success".equals(result)) {
    		respDto.setStatusCode(Constants.SUCCESS);
    	}else {
    		respDto.setStatusCode(Constants.ERROR);
    		respDto.setMessage(result);
    	}
    	//UserSearchModel assocUser =  userSearchService.getUserStatusJJEDS
    	if (respDto.getStatusCode() == Constants.SUCCESS) {
			return new ResponseEntity<>(respDto, HttpStatus.OK);
        } else if (respDto.getStatusCode() == 500) {
			return new ResponseEntity<>(respDto, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
            return new ResponseEntity<>(respDto, HttpStatus.BAD_REQUEST);
        }
    }



}
