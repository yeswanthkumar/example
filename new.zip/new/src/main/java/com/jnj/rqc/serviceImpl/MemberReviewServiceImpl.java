package com.jnj.rqc.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.MemberReviewDao;
import com.jnj.rqc.models.Assigner;
import com.jnj.rqc.models.BstMetricsModel;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.models.UserRole;
import com.jnj.rqc.models.UsrJJEdsMdl;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.MemberReviewService;
import com.jnj.rqc.util.Utility;



/**
 * File    : <b>MemberReviewServiceImpl.java</b>
 * @author : DChauras @Created : May 17, 2019 3:35:24 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class MemberReviewServiceImpl implements MemberReviewService{

	static final Logger log = LoggerFactory.getLogger(MemberReviewServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	MemberReviewDao memberReviewDao;
	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;



	@Override
	public List<UserRole> createUserCSV(Path filePath,  HttpSession session) {
		Map<String, List<String>> userRoleMap = readPVCSUserData(filePath);
		String targetFile = filePath.getFileName().toString();
		targetFile = targetFile.substring(0, targetFile.lastIndexOf("."));
		String outFilePath = Constants.PVCS_OUT_LOC+targetFile+"_"+Utility.fmtMDY(new Date())+".csv";
		List<UserRole> UserToRole = new ArrayList<>();//List for Printing on Screen
		try {
			File out = new File(outFilePath);
			StringBuilder sb = new StringBuilder();
			userRoleMap.forEach((user, roles)-> {
				UserRole usr = new UserRole();
				usr.setUserName(user);
				List<String>rlList = new ArrayList<>();
				roles.forEach(role ->{
					rlList.add(role);
					sb.append(user+","+role+"\r\n");
				});
				usr.setRoles(rlList);
				UserToRole.add(usr);
			});
			sb.append("\n");
			FileUtils.writeStringToFile(out, sb.toString(), "utf-8");
			//Session
			session.setAttribute("PVCSUserFile", outFilePath);
		} catch (Exception e) {
			log.error("ERROR writing CSV:"+outFilePath+"\nMessage: "+e.getMessage());
			e.printStackTrace();
		}
		return UserToRole;
	}



	/**
	 * Method  : PVCSUserDataServiceImpl.java.readPVCSUserData()
	 *		   :<b>@param filePath
	 * @author : DChauras  @Created :May 7, 2019 11:09:01 AM
	 * Purpose : Reads the Uploaded file, and creates Map of UserName to List of Roles
	 * @return : Map<String,List<String>>
	 */
	@Override
	public Map<String, List<String>> readPVCSUserData(Path filePath){
		log.info("Reading PVCS User File: "+filePath);

		List<String> result = new ArrayList<>();
		Map<String, List<String>> usrRlMap = new HashMap<>();
		try {
			List<String> lines = FileUtils.readLines(filePath.toFile(), "utf-8");
			result = lines.stream()
					.filter(ln -> !"".equals(ln.trim())) 		//Removing all BLANK Lines
					.map(s -> s.replaceAll(" ", "").toUpperCase())
					.collect(Collectors.toList());
			result.remove(0); //Removing the Header ROW

			String dbID = "";
			for(String str:result) {
				if(str.startsWith("PROJECTDATABASE")){
					dbID = getDBId(str);
					continue;
				}
				str = (str.substring(5)).replaceAll("\"", "");
				String[] data = str.split("\\|");
				String usrId = "";
				List<String> roleList = new ArrayList<>();
				if(data != null && data.length > 0) {
					usrId = data[0];
					roleList = getRole(dbID, data);
					if(usrRlMap.containsKey(usrId)) {
						List<String> tmp = usrRlMap.get(usrId);
						tmp.addAll(roleList);
						usrRlMap.put(usrId, tmp);
					}else {
						usrRlMap.put(usrId, roleList);
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Error reading User Data :"+e.getMessage());
			e.printStackTrace();
		}
		//System.out.println("Total Number of PVCS USERS :"+usrRlMap.size());
		return usrRlMap;
	}


	private String getDBId(String str) {
		String dbId = str.substring((str.lastIndexOf("\\")+1), str.indexOf("("));
		return dbId;
	}

	private List<String> getRole(String dbID, String[] data){
		List<String> rlLst = new ArrayList<>();
		if(data != null && data.length > 1){
			for(int i=1; i<data.length; i++) {
				if(Utility.getRole(data[i]) != null) {
					rlLst.add(dbID+"_"+Utility.getRole(data[i]));
				}
			}
		}
		return rlLst;
	}


	@Override
	public String saveFile(MultipartFile file) throws IOException{
		byte[] bytes = file.getBytes();
		String fileNm = file.getOriginalFilename();
		if(fileNm.indexOf("\\") > 0) {
			fileNm = fileNm.substring(fileNm.lastIndexOf("\\")+1);
		}
		Path path = Paths.get(Constants.UPLOAD_DIR + fileNm);
		//if(!path.toFile().exists()) {
			Files.write(path, bytes);
		//}else {
		//	log.debug("File :"+path.getFileName()+" ... is Present");
		//}

		return path.toString();
	}


	@Override
	public List<BstMetricsModel> processBstMetricsData(String path, HttpServletRequest request)throws Exception{
	List<BstMetricsModel> mDataLst= readMetricsData(path);
	return mDataLst;

}


	@Override
	public List<MemRevieModel> processNagsData(String path, int mon, int year, HttpServletRequest request) throws Exception{
		List<MemRevieModel> ngsDataLst= readNagsData(path, mon, year);
		Map<String, String> tktData = memberReviewDao.getRQCTktDetails(mon, year);
		List<MemRevieModel> tmpResult = Utility.updateTicketNumber(ngsDataLst, tktData);
		List<MemRevieModel> result =  populateAssignerDetails(tmpResult, mon, year);
		List<MemRevieModel> finalResult =  checkSelfAssignment(result);
		return finalResult;
	}

	public List<MemRevieModel> populateAssignerDetails(List<MemRevieModel>result, int mon, int year) {
		Map<String, Assigner> asgnrMap = new HashMap<>();
		List<MemRevieModel> tmpList = new ArrayList<>();
		try {
			List<Assigner> asgnrDataLst = memberReviewDao.getAssignerDetails(mon, year);
			log.info("asgnrDataLst.size: "+asgnrDataLst.size());
			asgnrDataLst.forEach(asgnr ->{
				String key = asgnr.getTicktNo();
				if(asgnrMap.containsKey(key)) {
					Assigner asgnrOld = asgnrMap.get(key);
					if((asgnr.getLogSeq() > asgnrOld.getLogSeq())) {
						asgnrMap.put(key, asgnr);
					}
				}else{
					asgnrMap.put(key, asgnr);
				}
			});

			log.info("asgnrMap.size: "+asgnrMap.size());

			for(MemRevieModel ngsData: result) {
				if(asgnrMap.containsKey(ngsData.getRqcTkt())) {
					String rqcTkt = ngsData.getRqcTkt();
					Assigner asgnr = asgnrMap.get(rqcTkt);
					ngsData.setAsignerName(asgnr.getAssigneeName());
					//ngsData.setRowAddTms(asgnr.getRowAddTms());
				}
				tmpList.add(ngsData);
			}

		} catch (Exception e) {
			log.error("ERROR:"+e.getMessage(), e);
		}
		return tmpList;
	}


	private List<MemRevieModel> checkSelfAssignment(List<MemRevieModel>result) {
		List<MemRevieModel> tmpList = new ArrayList<>();
		try{
			for(MemRevieModel memData : result) {
				String flNm = memData.getFullName();
				String asgnr= memData.getAsignerName();

				flNm	=(flNm != null)? flNm.trim().toUpperCase():"";
				asgnr 	= (asgnr != null)? asgnr.trim().toUpperCase():"";
				if(memData.getRqcTkt() != null && asgnr != null && !asgnr.equalsIgnoreCase("null") && asgnr.length()>0) {
					if(flNm.equals(asgnr)) {
						memData.setIsSelfAdmin("TRUE");
					}else {
						memData.setIsSelfAdmin("FALSE");
					}

					if(checkRQCMember(asgnr)) {
						memData.setIsSecTeam("TRUE");
					}else {
						memData.setIsSecTeam("FALSE");
					}
				}

				if((memData.getGrpShrtNm().trim()).equals(memData.getRole().toString())) {
					memData.setIsRoleMatch("TRUE");
				}else {
					memData.setIsRoleMatch("FALSE");
				}

				tmpList.add(memData);
			}

		} catch (Exception e) {
			log.error("ERROR:"+e.getMessage(), e);
		}
		return tmpList;
	}

	@Override
	public String writeBstCsv(List<BstMetricsModel> data){
		String filePath = csvReportWriter.writeCSVBstReview(data, "YMDBstMetrics_"+Utility.fmtYMD(new Date())+".csv");
		log.info(" File Path: "+filePath);
		return filePath;
	}


	@Override
	public String writePdfOrCsv(String type, int mon, int year, List<MemRevieModel> data) {
		String filePath = "";
		if("XLS".equals(type)){
			filePath = csvReportWriter.writeCSVReview(data, "HCSMembershipReviewSOXApp_"+(mon<10 ? "0"+mon:mon)+"-"+year+".csv");
		}else
		if("PDF".equals(type)){
			filePath = pdfReportWriter.buildReport(data, "HCSMembershipReviewSOXApp_"+(mon<10 ? "0"+mon : mon)+"-"+year+".pdf", mon, year);
		}
		log.info(type+ " File Path: "+filePath);
		return filePath;
	}

	@Override
	public List<BstMetricsModel> readMetricsData(String path){
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<BstMetricsModel> dataLst = new ArrayList<>();
		int i = 0;
		int criteriaTotal = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			System.out.println("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				String firstVarEventVal = Utility.getCellValue(rw.getCell(13));
				if(!firstVarEventVal.startsWith("R3TR")) {
					continue;
				}
				String cDate 			= Utility.getCellValue(rw.getCell(2));
				Date ccDate 			= Utility.strToDt(cDate, "");
				String userId  			= Utility.getCellValue(rw.getCell(6));


				BstMetricsModel ngm 	= new BstMetricsModel();
				ngm.setCDate(ccDate);
				ngm.setUserId(userId);
				firstVarEventVal = firstVarEventVal.substring(10, (firstVarEventVal.length() - 1));
				if(firstVarEventVal.indexOf(" ") > 0) {
					firstVarEventVal = firstVarEventVal.substring(0, firstVarEventVal.indexOf(" "));
				}
				ngm.setFirstVarEventVal(firstVarEventVal);
				dataLst.add(ngm);
				i++;
				rowTotal++;
			}
		}
		log.info("Total Records Collected from File  : "+dataLst.size());
		return dataLst;
	}



	@Override
	public List<MemRevieModel> readNagsData(String path, int mon, int year){
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<MemRevieModel> dataLst = new ArrayList<>();
		int i = 0;
		int criteriaTotal = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			System.out.println("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				MemRevieModel ngm 		= new MemRevieModel();
				String accName 		= Utility.getCellValue(rw.getCell(0));
				String accFstColl 	= Utility.getCellValue(rw.getCell(1));
				String accLstColl 	= Utility.getCellValue(rw.getCell(2));
				String flNm  		= Utility.getCellValue(rw.getCell(3));
				String ntId 		= Utility.getCellValue(rw.getCell(4));
				String wId  		= Utility.getCellValue(rw.getCell(5));
				String eml  		= Utility.getCellValue(rw.getCell(6));
				String ttl  		= Utility.getCellValue(rw.getCell(7));
				String dpt	  		= Utility.getCellValue(rw.getCell(8));
				String grpShrtNm	= Utility.getCellValue(rw.getCell(11));
				String grpData 		= Utility.getCellValue(rw.getCell(13));
				String memAdDt 		= Utility.getCellValue(rw.getCell(14));
				//Adding Date Error
				String dtErrMsg="Skipping Record for WWID :"+wId+" Acc Name: "+accName+" Full Name:"+flNm+"  groupData :"+grpData+" Date added:"+memAdDt;
				Date addDate = Utility.strToDt(memAdDt, dtErrMsg);

				if(memAdDt != null && addDate != null) {
					ngm.setDtAdded(addDate);
					Calendar cal = Calendar.getInstance();
					cal.setTime(addDate);
					if(!((cal.get(Calendar.YEAR) == year) && (cal.get(Calendar.MONTH)+1 == mon ))) {
						i++;
						//System.out.println("Skipping Record for WWID :"+wId+" Full Name:"+flNm+"  groupData :"+grpData+" Date added:"+memAdDt);
						continue;
					}
				}else{
					i++;
					//System.out.println("Skipping Record for WWID :"+wId+" Full Name:"+flNm+"  groupData :"+grpData+" Date added:"+memAdDt);
					continue;
				}

				criteriaTotal ++;
				if(wId == null || wId.isEmpty() || wId.equals("") ) {
					i++;
					UsrJJEdsMdl jjmdl = null;
					String []acNameArr = accName.split(":");
					String winId ="";
					if(acNameArr != null && acNameArr.length > 0) {
						winId = (acNameArr[acNameArr.length -1]).trim();
						if(winId != null && winId.length() > 1) {
							jjmdl =  getJJEDSData(winId);
							if(jjmdl != null && !jjmdl.getWwid().isEmpty()) {
								flNm = jjmdl.getFullName();
								wId = jjmdl.getWwid();
								ntId = jjmdl.getNtId();
								dpt = jjmdl.getDept();
								eml = jjmdl.getEmail();
								ttl = jjmdl.getTitle();
							}
						}
					}
				}


				/*if(wId.isEmpty() || grpData.isEmpty()) {
					i++;
					System.out.println("INVALID Record Found  ***  for WWID: "+wId+" Acc Name: "+accName +"  Full Name: "+flNm+"  groupData :"+grpData+" Date added:"+Utility.dtFmt.format(addDate));
					continue;
				}*/

				ngm.setAccountName(accName);
				ngm.setAccountFstCol(Utility.strToDt(accFstColl));
				ngm.setAccountLstCol(Utility.strToDt(accLstColl));
				ngm.setFullName(flNm.toUpperCase());
				ngm.setNetId(ntId);
				ngm.setWwid(wId);
				ngm.setEmail(eml != null ? eml.toUpperCase():"");
				ngm.setTitle(ttl != null? ttl.toUpperCase():"");
				ngm.setDept(dpt != null ? dpt.toUpperCase():"");
				ngm.setGrpShrtNm(grpShrtNm.trim().toUpperCase());
				ngm.setGrpNm(grpData);
				String[] grpArr = grpData.split(":");
				if(grpArr != null && grpArr.length >2) {
					ngm.setGrp(grpArr[0].trim().toUpperCase());
					if(grpArr.length >3){
						ngm.setRole((grpArr[1].trim()+":"+grpArr[2].trim()).toUpperCase());
						ngm.setSodCd(grpArr[3].trim());
					}else {
						ngm.setRole(grpArr[1].trim().toUpperCase());
						ngm.setSodCd(grpArr[2].trim());
					}
				}
				dataLst.add(ngm);
				i++;
			}
		}
		log.info("Total Records for Month("+mon+"-"+year+")            : "+criteriaTotal);
		log.info("Records skipped for missing data Month("+mon+"-"+year+"): "+(criteriaTotal - dataLst.size()));
		log.info("Total Records Collected for Month("+mon+"-"+year+")  : "+dataLst.size()+"\n");
		return dataLst;
	}

	@Override
	public UsrJJEdsMdl getJJEDSData(String winId) {
		UsrJJEdsMdl usrMdl = null;
		try{
			List<UsrJJEdsMdl> usrList = memberReviewDao.readJJEDSMemData(winId);
			if(usrList != null && !usrList.isEmpty()) {
				if(usrList.size() == 1) {
					usrMdl = usrList.get(0);
				}else {
					for(UsrJJEdsMdl obj : usrList) {
						if(obj.getTermDt() != null) {
							if(usrMdl != null) {
								if(obj.getTermDt().compareTo(usrMdl.getTermDt()) > 0) {
									usrMdl = obj;
								}
							}else {
								usrMdl = obj;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception getting JJEDS Data"+e.getMessage(), e);
		}

		return usrMdl;
	}



	@Override
	@SuppressWarnings("unchecked")
	public List<SrcSysMemRoleModel> processMemReport(String srcsystem) throws Exception{
		List<SrcSysMemRoleModel> srcSysList= memberReviewDao.readSrcSysMemData(srcsystem);
		Map<String, String> tktData = null;
		if(Utility.getCache(Constants.RQC_TKT_DATA) == null) {
			tktData = memberReviewDao.readMemRQCTktData();
			Utility.setCache(Constants.RQC_TKT_DATA, tktData);
		}else {
			tktData =(Map<String, String>)Utility.getCache(Constants.RQC_TKT_DATA);
		}
		List<SrcSysMemRoleModel> tmpResult = Utility.checkTicketNumber(srcSysList, tktData);
		List<SrcSysMemRoleModel> result =  getAssignerDetails(tmpResult);
		return result;
	}


	public List<SrcSysMemRoleModel> getAssignerDetails(List<SrcSysMemRoleModel>result) {
		Map<String, Assigner> asgnrMap = new HashMap<>();
		List<SrcSysMemRoleModel> tmpList = new ArrayList<>();
		try {
			List<Assigner> asgnrDataLst = memberReviewDao.queryMemAssignerData();
			log.info("asgnrDataLst.size: "+asgnrDataLst.size());
			asgnrDataLst.forEach(asgnr ->{
				String key = asgnr.getTicktNo();
				if(asgnrMap.containsKey(key)) {
					Assigner asgnrOld = asgnrMap.get(key);
					if((asgnr.getLogSeq() > asgnrOld.getLogSeq())) {
						asgnrMap.put(key, asgnr);
					}
				}else{
					asgnrMap.put(key, asgnr);
				}
			});

			log.info("asgnrMap.size: "+asgnrMap.size());

			for(SrcSysMemRoleModel ngsData: result) {
				if(asgnrMap.containsKey(ngsData.getRqcTkt())) {
					String rqcTkt = ngsData.getRqcTkt();
					Assigner asgnr = asgnrMap.get(rqcTkt);
					ngsData.setAsignerName(asgnr.getAssigneeName());
				}
				tmpList.add(ngsData);
			}

		} catch (Exception e) {
			log.error("ERROR:"+e.getMessage(), e);
		}
		return tmpList;
	}


	@Override
	public String writeCsvReport(List<SrcSysMemRoleModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSV(data, "ROLE_ASSIGNMENT_"+fileName+".csv");
		return filePath;
	}


	private boolean checkRQCMember(String name) {
		boolean result = false;
		//List<String> memList =  Arrays.asList(new String[] { "ACOSTA, ALEXANDER", "CHAURASIYA, DHARMINDRA", "LEE, CARL", "CRUDUP, MICHELLE", "WRIGHT, KEN" });
		List<String> memList =  Arrays.asList(environment.getRequiredProperty("rqc.memberlist").split("~"));
		if(name != null && !name.equals("null") && memList.contains(name)) {
	    	result= true;
	    }
		return result;
	}



}
