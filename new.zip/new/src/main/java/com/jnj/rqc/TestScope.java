package com.jnj.rqc;

public class TestScope {

	public static void main(String[] args) {

		double num = 3.141414141414;

        // Rounding off above double number to 2 precision
        double ans = Math.round(num * 100) / 100.0;

        // Printing the above precised value
        // of double value
        System.out.println(ans);



	}

}
