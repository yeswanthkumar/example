package com.jnj.rqc.useridentity.models;

import lombok.Data;

@Data
public class Pages {
	String name;
	String id;
}
