package com.jnj.rqc.useridentity.models;

import lombok.Data;

@Data
public class Status{
	int code;
	String message;
}