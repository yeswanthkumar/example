package com.jnj.rqc.userabs.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BfSctrRegnMdl {
	String bfid;
	String secid;
	String regid;
	String regname;
	String regdesc;
	String regimg;
	String regloc;


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		BfSctrRegnMdl other = (BfSctrRegnMdl) obj;
		if (bfid == null) {
			if (other.bfid != null)
				return false;
		} else if (!bfid.equals(other.bfid))
			return false;
		if (regdesc == null) {
			if (other.regdesc != null)
				return false;
		} else if (!regdesc.equals(other.regdesc))
			return false;
		if (regid == null) {
			if (other.regid != null)
				return false;
		} else if (!regid.equals(other.regid))
			return false;
		if (regname == null) {
			if (other.regname != null)
				return false;
		} else if (!regname.equals(other.regname))
			return false;
		if (secid == null) {
			if (other.secid != null)
				return false;
		} else if (!secid.equals(other.secid))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfid == null) ? 0 : bfid.hashCode());
		result = prime * result + ((regdesc == null) ? 0 : regdesc.hashCode());
		result = prime * result + ((regid == null) ? 0 : regid.hashCode());
		result = prime * result + ((regname == null) ? 0 : regname.hashCode());
		result = prime * result + ((secid == null) ? 0 : secid.hashCode());
		return result;
	}




}