package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dbextr.factory.DBExtFactory;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.service.DBExtService;
import com.jnj.rqc.util.Utility;



@Service
public class DBExtServiceImpl implements DBExtService {
	static final Logger log = LoggerFactory.getLogger(DBExtServiceImpl.class);

	@Autowired
	DBExtFactory dBExtFactory;
	@Override
	public TableRespDto getSchemaTables(String schemaNm) {
		List<String> tableNames= new ArrayList<>();
		tableNames = Utility.loadProperty(schemaNm);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(tableNames);

		return tableRespDto;
	}



	@Override
	public String createExcelData(String tblName) {
		IDBExtProcessor proc = dBExtFactory.getProcessor(tblName);
		String filePath = "";
		try {
			filePath = proc.process();
		} catch (Exception e) {
			log.error("Exception :"+e.getMessage(), e);
		}
		return filePath;
	}





}
