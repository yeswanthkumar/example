package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JDACrsAppRoleMdl {

	private String wwid;
	private String code;
	private String accessRole;
	private String srcSystem;

}
