package com.jnj.rqc.userreq.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.masterdata.dao.MasterDataDao;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.models.AbsCancelRejectRequestModel;
import com.jnj.rqc.userabs.models.AbsComplianceRequest;
import com.jnj.rqc.userabs.models.AbsExcesvAccsMdl;
import com.jnj.rqc.userabs.models.AbsSecExcesvRestrictedAccsMdl;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.AbsUserRequestRespDto;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ReqCountRespDto;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.ReqSrchConstDto;
import com.jnj.rqc.userabs.models.ReqSrchConstMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RolesRespDto;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.models.UserReqCompMdl;
import com.jnj.rqc.userabs.models.UserReqDetCompMdl;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.useridentity.models.ConflictRequestedModel;
import com.jnj.rqc.userreq.dao.AbsUserRequesDao;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;

@Service
public class AbsUserRequestServiceImpl implements AbsUserRequestService {
	static final Logger log = LoggerFactory.getLogger(AbsUserRequestServiceImpl.class);

	@Autowired
	private AbsUserRequesDao absUserRequesDao;

	@Autowired
	private UserSearchService userSearchService;

	@Autowired
	private MasterDataDao  masterDataDao;

	@Autowired
	private EmailUtil emailUtil;
	
	@Autowired
	private UserAccessDataService userAccessDataService;

	@Override
	public AbsUserRequestRespDto getAllRequestData(String startDate, String endDate, int paramType, String paramValue) {
		AbsUserRequestRespDto reqRespDto = new AbsUserRequestRespDto();
		List<AbsUserReqMdl> userReqs = new ArrayList<>();
		startDate = startDate+" 00:00:00";
		endDate = endDate+" 23:59:59";
		try{
			List<AbsUserReqMdl> allReqs = absUserRequesDao.getAllSavedUserRequests(startDate, endDate, paramType, paramValue);
			for(AbsUserReqMdl reqMdl:allReqs ) {
				UserSearchModel reqByUser = userSearchService.getUserStatusJJEDS(reqMdl.getRequestedby(), 0);
				reqMdl.setRequestedbyname(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = userSearchService.getUserStatusJJEDS(reqMdl.getUserid(), 1);
				reqMdl.setUsername(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = userSearchService.getUserStatusJJEDS(reqMdl.getManagerid(), 1);
				reqMdl.setManagername(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
				if(reqMdl.getReqStatus() > 6) {
					reqMdl.setRoleStatus(absUserRequesDao.getRequestRoleStatus(reqMdl.getReqid()+""));
				}
			}
			/*if(allReqs != null && !allReqs.isEmpty()) {
			userReqs = getRequestDependencies(allReqs);
			}*/
			reqRespDto.setReqData(allReqs);
			reqRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			reqRespDto.setStatusCode(Constants.SERV_ERR);
			reqRespDto.setStatusDesc(e.getMessage());
			log.error("ERROR getting Request Data :"+e.getMessage(), e);
		}
		reqRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return reqRespDto;

	}




	@Override
	public int saveAbsRequestData(UserReqCompMdl reqModel, UserSearchModel curUser, UserSearchModel assocUser, UserSearchModel assocMgr)  throws Exception{
		int requestId = 0;
		String envName = Utility.getServerProp("ENVIRONMENT");
		try{
			//Populate AD Group IDS
			if(reqModel.getSysList() != null && !reqModel.getSysList().isEmpty()) {
				for(UserReqDetCompMdl detailMdl: reqModel.getSysList()) {
					detailMdl.setAdids(absUserRequesDao.getAllADGrpBySystem(detailMdl.getSysid(), detailMdl.getPosids().split(","), detailMdl.getAccids().split(","), detailMdl.getPosvarids().split(",")));
				}
			}

			//Sending for Compliance approval, when there is Excessive/SOD Conflicts
			if(("Y".equals(reqModel.getConflictFound()) && !reqModel.getConfList().isEmpty()) || ("Y".equals(reqModel.getIsExces()) && !reqModel.getRestExcsvAcssList().isEmpty())) {
				reqModel.setReqStatus(2);
			}
			requestId = absUserRequesDao.saveAbsUserRequest(reqModel);
			if(requestId > 0) {//Save Successfull, Routing for Manager/Compliance Approval(Trigger Email)
				if("Y".equals(reqModel.getConflictFound()) && !reqModel.getConfList().isEmpty()) {
					int confRecs = absUserRequesDao.saveAbsUserConflicts(requestId, assocUser, reqModel.getConfList());
					log.info("Saved Conflicts to Database for REQID:"+requestId+" - Total Rows: "+confRecs);
				}
				//Excessive Access
				/*if("Y".equals(reqModel.getIsExces()) && !reqModel.getExcList().isEmpty()) {
					int excsReq = absUserRequesDao.saveAbsExcsvAccess(requestId, assocUser, reqModel.getExcList());
					log.info("Saved Excessive Data to Database :"+excsReq);
				}*/

				//Restricted/Accessive Access restExcsvAcssList
				if("Y".equals(reqModel.getIsExces()) && !reqModel.getRestExcsvAcssList().isEmpty()) {
					List<AbsSecExcesvRestrictedAccsMdl> sectorDataList = new ArrayList<>();
					List<RoleADGrpMdl> seletedVars = new ArrayList<>();
					for(AbsSysLeveExcsvRestrMdl resMdl:reqModel.getRestExcsvAcssList()) {
						sectorDataList.addAll(resMdl.getSectorDataList());
						seletedVars.addAll(resMdl.getSelVarsNonRestricted());
						seletedVars.addAll(resMdl.getSelVarsRestricted());
					}

					int[] excsReq = absUserRequesDao.saveAbsRestExcsvAccessSystemData(requestId, assocUser, sectorDataList, seletedVars);
					log.info("Saved Excessive Data to Database Sectordata:"+excsReq[0]+" Roles:"+excsReq[1]);
				}
				
				Map<String, List<String>> emailMap = new HashMap<>();
				List<String> toList = new ArrayList<>();
				List<String> ccList = new ArrayList<>();
				
				
				
				if(requestId > 0) {
					toList.add(assocUser.getJnjEmailAddrTxt());//Associate email
					ccList.add(assocMgr.getJnjEmailAddrTxt().toUpperCase());//Manager email					
					//ccList.add(curUser.getJnjEmailAddrTxt()); //Current User/Requestor Added to email on 07/03/2023
					log.debug("----------------> assocUser.getJnjEmailAddrTxt() :"+assocUser.getJnjEmailAddrTxt());
					log.debug("---------------------> assocMgr.getJnjEmailAddrTxt() :"+assocMgr.getJnjEmailAddrTxt());
					log.debug("----------------------------> curUser.getJnjEmailAddrTxt() :"+ curUser.getJnjEmailAddrTxt());
					String curUserEmail = curUser.getJnjEmailAddrTxt();
					if(curUserEmail!=null) {
						if (!curUserEmail.equalsIgnoreCase(assocUser.getJnjEmailAddrTxt())){
							ccList.add(curUser.getJnjEmailAddrTxt().toUpperCase());
						}
					}
					if ("Y".equals(reqModel.getIsExces()) || "Y".equals(reqModel.getConflictFound())) {
						List<String> sysList = new ArrayList<>();
						reqModel.getSysList().stream().forEach(e -> sysList.add(e.getSysid()));
						List<String> appCatgEmails = absUserRequesDao.getApproverCategoryEmails(sysList, 3);
						for(String eml : appCatgEmails ) {
							Arrays.asList(eml.split(",")).stream().forEach(e ->ccList.add(e.toUpperCase()));
						}
					}
				}	
				ArrayList<String> ccListCopy = new ArrayList<>(ccList);
				
				for (String toEmail : toList) {
				    ccListCopy.removeIf(email -> email.equals(toEmail));
				}			
				
				List<String> ccListUnique = ccListCopy.stream().map(e -> e.toUpperCase()).distinct().collect(Collectors.toList());
				emailMap.put("TO", toList);
				emailMap.put("CC", ccListUnique);
				String emlSubject = "("+envName+") ";
				if(reqModel.getTypeid() == 2) {
					//emlSubject += " Your access Removal has been requested ";
					emlSubject += " Your Access Request Has Been Submitted ";
				}else{
					//emlSubject += " Your access has been requested ";
					emlSubject += " Your Access Request Has Been Submitted ";
				}
				List<AbsSysLeveExcsvRestrMdl> execuvAccList = reqModel.getRestExcsvAcssList();
				if(execuvAccList != null) {
					log.debug("------------excsvAcssList as :"+execuvAccList);
				}
				emailUtil.sendAbsNewRequestEmail(emlSubject, assocUser, curUser, requestId, reqModel, reqModel.getRestExcsvAcssList(), emailMap);
			log.info("duplicate logic code before reqModel.getTypeid() :"+reqModel.getTypeid());
			if(reqModel.getTypeid() == 1 ) {
				//duplicate check	
				log.info("duplicate logic code start");
				RolesRespDto userExistRoleRespDto = userAccessDataService.getExistingRoles(assocUser.getWwId());
				Map<String, List<RoleADGrpMdl>> mapList = userExistRoleRespDto.getRoles();
				if (mapList != null && !mapList.isEmpty()) {
					log.info("enter into the duplicate logic check block");
					List<String> pvIdexistingroleslist1 = new ArrayList<String>();
					List<String> pvIdnewroleslist2 = new ArrayList<String>();
				    for (Map.Entry<String, List<RoleADGrpMdl>> entry : mapList.entrySet()) {
				        String key = entry.getKey();
				        List<RoleADGrpMdl> roleList = entry.getValue();						       
				        log.info(" duplicate Key :" + key);				       
				        for (RoleADGrpMdl role : roleList) {
				        	if(role!=null && role.getPvId() != null) {
				                String pvIdString = role.getPvId().trim(); 
				                String[] pvIds = pvIdString.split(","); 			                
				                for (String pvId : pvIds) {
				                    pvIdexistingroleslist1.add(pvId.trim());
				                }
				        	}
			            }				       
				    }
				    if(reqModel.getSysList() != null && !reqModel.getSysList().isEmpty()) {
				    	log.info("enter into the duplicate logic new roles block entered");						
				    	for (UserReqDetCompMdl detailMdl : reqModel.getSysList()) {
				            String posvaridsString = detailMdl.getPosvarids().trim(); 
				            String[] pvIds = posvaridsString.split(","); 				            
				            for (String pvId : pvIds) {
				                pvIdnewroleslist2.add(pvId.trim());
				            }
				        }
					}
				    log.info("enter into the duplicate logic new pvIdExistingList :"+pvIdexistingroleslist1);
				    log.info("enter into the duplicate logic  pvIdNewList :"+pvIdnewroleslist2);				    
				   /* boolean isNewRolesSubset = isSubset(pvIdnewroleslist2, pvIdexistingroleslist1);
				    log.info("enter into the duplicate logic  isNewRolesSubset :"+isNewRolesSubset);
				    if(isNewRolesSubset) {
				    	absUserRequesDao.confUpdateRequestStatus(requestId+"", 6, "Y");
				    }*/			    				    
				}
			}// if close
			}
		} catch (Exception e) {
			log.error("Error Saving Abs Request Info:"+e.getMessage(), e);
			throw e;
		}
		return requestId;
	}
	 public boolean isSubset(List<String> subList, List<String> superList) {
		 log.info("enter into the duplicate logic isSubset subList :"+subList);
		 log.info("enter into the duplicate logic isSubset superList :"+superList);
		 for (String subListEle : subList) {	            
	            log.info("enter into the duplicate logic isSubset for subList :"+subListEle);
	     }
		 for (String superListEle : superList) {	            
	            log.info("enter into the duplicate logic isSubset for superList :"+superListEle);
	     }
	     return superList.containsAll(subList);
	 }
	
	@Override
	public ReqSrchConstDto getSearchConstants() {
		ReqSrchConstDto respDto = new ReqSrchConstDto();
		try {
			List<ReqSrchConstMdl> consLst = getAllSrchConstants();
			respDto.setSrchConst(consLst);
			respDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc(e.getMessage());
			log.error("ERROR search constants Data :"+e.getMessage(), e);
		}
		return respDto;
	}


	@Override
	public List<ReqSrchConstMdl> getAllSrchConstants() throws Exception {
		List<ReqSrchConstMdl> consLst = new ArrayList<>();
		consLst = absUserRequesDao.getAllSrchConstants();
		return consLst;
	}


	@Override
	public ReqCountRespDto searchPendingReqCount(String userId) {
		ReqCountRespDto respDto = new ReqCountRespDto();
		respDto.setUserId(userId);
		int pendingReqCount = 0;
		try{
			pendingReqCount = absUserRequesDao.getCountOfPendingRequest(userId);
			respDto.setPendingReqCount(pendingReqCount);
			respDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc(e.getMessage());
			respDto.setPendingReqCount(pendingReqCount);
			log.error("ERROR Getting pending request counts Data :"+e.getMessage(), e);
		}
		return respDto;
	}




	@Override
	public List<ReqDpendncMdl> getTktDependency(String reqId) {
		List<ReqDpendncMdl> depnLst = new ArrayList<>();
		try {
			depnLst =  absUserRequesDao.getTktDependencies(reqId);
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return depnLst;
	}


	@Override
	public List<RawSysDpendncMdl> getSysDependencies(String sysid, String posnids, String accids, String posvarids) {
		List<RawSysDpendncMdl> sysDepLst = new ArrayList<>();
		String[] posnIdArr = Utility.isEmpty(posnids)? new String[] {}:posnids.split(",");
		String[] accIdArr  = Utility.isEmpty(accids)? new String[] {}:accids.split(",");
		String[] pvarIdArr    = Utility.isEmpty(posvarids)? new String[] {}:posvarids.split(",");

		try{
			sysDepLst = absUserRequesDao.getSysDependencies(sysid, posnIdArr, accIdArr, pvarIdArr);
			log.info("Total Records for SYSTEM ("+sysid+"): "+sysDepLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return sysDepLst;
	}


	@Override
	public AbsUserReqMdl getRequestDataByID(String reqId) {
		AbsUserReqMdl reqMdl = null;
		try{
			List<AbsUserReqMdl> allReqs = absUserRequesDao.getRequestDataByReqID(reqId);
			if(allReqs != null && !allReqs.isEmpty() ) {
				reqMdl = allReqs.get(0);
				UserSearchModel reqByUser = userSearchService.getUserStatusJJEDS(reqMdl.getRequestedby(), 0);
				reqMdl.setRequestedbyname(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel asUser = userSearchService.getUserStatusJJEDS(reqMdl.getUserid(), 1);
				reqMdl.setUsername(asUser.getFmlyNm()+" "+asUser.getGivenNm()+"("+asUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = userSearchService.getUserStatusJJEDS(reqMdl.getManagerid(), 1);
				reqMdl.setManagername(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				//if(reqMdl.getReqStatus() >= 6) {
				if(reqMdl.getReqStatus() >= 5) {
					reqMdl.setRoleStatus(absUserRequesDao.getRequestRoleStatus(reqMdl.getReqid()+""));
				}
			}
			/*if(allReqs != null && !allReqs.isEmpty()) {
			userReqs = getRequestDependencies(allReqs);
			}*/
		} catch (Exception e) {
			log.error("ERROR getting Request Data :"+e.getMessage(), e);
		}
		return reqMdl;
	}



	@Override
	public List<UserAbsConflictMdl> getAllReqLvlConflicts(String reqId) {
		List<UserAbsConflictMdl> confLst = new ArrayList<>();
		try {
			confLst = absUserRequesDao.getRequestLvlConflicts(reqId);

			if(confLst != null && !confLst.isEmpty()) {
				for(UserAbsConflictMdl mdl : confLst) {
					List<String> vrName1 = masterDataDao.getZPosVariantName(mdl.getApp1(), mdl.getPosv1());
					List<String> vrName2 = masterDataDao.getZPosVariantName(mdl.getApp2(), mdl.getPosv2());
					if(vrName1 != null && !vrName1.isEmpty() ) {
						mdl.setPosvName1(vrName1.get(0));
					}
					if(vrName2 != null && !vrName2.isEmpty() ) {
						mdl.setPosvName2(vrName2.get(0));
					}
				}
			}
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return confLst;
	}
	
	@Override
	public List<RoleADGrpMdl> getDuplicateRecords(String reqId, String userId) {
		List<RoleADGrpMdl> duplicateList = new ArrayList<>();
		List<ReqDpendncMdl> depnLst = new ArrayList<>();
		try {
			depnLst =  absUserRequesDao.getTktDependencies(reqId);
			
			RolesRespDto userExistRoleRespDto = userAccessDataService.getExistingRoles(userId);					  
			  Map<String, List<RoleADGrpMdl>> mapList = userExistRoleRespDto.getRoles();
			  if (mapList != null && !mapList.isEmpty()) {
				  log.info("Variants duplicate logic after filter called start");
				    for (Map.Entry<String, List<RoleADGrpMdl>> entry : mapList.entrySet()) {
				        String key = entry.getKey();
				        List<RoleADGrpMdl> roleList = entry.getValue();						       
				        log.info("Variants duplicate Key: " + key);
				        for (RoleADGrpMdl role : roleList) {
				        	for (ReqDpendncMdl reqRole : depnLst) {
				        		List<String> posVarID = Arrays.asList(reqRole.getPosvarids().split(","));
				        		List<String> posID = Arrays.asList(reqRole.getPosids().split(","));
				        		if((reqRole.getSysid().equals(role.getSysId())) && posVarID.contains(role.getPvId()) && posID.contains(role.getPosId()))
				        			duplicateList.add(role);
				        	}				        	
				        } 
				    }
			  }
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return duplicateList;
	}

	@Override
	public List<AbsExcesvAccsMdl> getReqLvlExcData(String reqId) {
		List<AbsExcesvAccsMdl> excLst = new ArrayList<>();
		try {
			excLst = absUserRequesDao.getRequestLvlExcData(reqId);
			if(excLst != null && !excLst.isEmpty()) {
				for(AbsExcesvAccsMdl eMdl : excLst) {
					String sysid = eMdl.getSysid();
					String[] selVars = (eMdl.getSelVarids() == null || eMdl.getSelVarids().length() == 0)? new String[0]: eMdl.getSelVarids().split(",");
					List<RawSysDpendncMdl> vrList = masterDataDao.getSelectedExcsvPosVariants(sysid, selVars);
					for(RawSysDpendncMdl e : vrList ){
						e.setSysid(eMdl.getSysid());
						e.setSysname(eMdl.getSysName());
						//Call a method to populate data
						List<StrKeyValPair> keyValLst = masterDataDao.getStatusForVariants(reqId, e.getSysid(), e.getPosid(), e.getAccid(), e.getPosvarid());
						if(keyValLst != null && !keyValLst.isEmpty()) {
							e.setAcceptDeny(keyValLst.get(0).getKey());
							e.setResolutionCmnts(keyValLst.get(0).getVal());
						}
					}
					eMdl.setVariantDetails(vrList);
				}
			}
		} catch (Exception e) {
			log.error("Error getting Request Excessive Data: "+e.getMessage(), e);
		}
		return excLst;
	}





	/* (non-Javadoc)
	 * @see com.jnj.rqc.userreq.service.AbsUserRequestService#getAllMitigatingControls(int, java.lang.String)
	 */
	@Override
	public List<StrKeyValPair> getAllMitigatingControls(String id, String type) {
		List<StrKeyValPair> mitiLst = new ArrayList<>();
		//StrKeyValPair topRow = new StrKeyValPair("N/A", "  Select  ");
		//mitiLst.add(topRow);
		try {
			List<StrKeyValPair> mitiLst1 = absUserRequesDao.getMitigatingControls(id, type);
			if(!mitiLst1.isEmpty()) {
				mitiLst.addAll(mitiLst1);
			}
		} catch (Exception e) {
			log.error("Error getting Conflicts Data: "+e.getMessage(), e);
		}
		return mitiLst;
	}


	@Override
	public String saveCancelRejectStatus(UserSearchModel approveUser, AbsCancelRejectRequestModel absCancelRejectRequestModel) {
		String result = "Success";
		String envName = Utility.getServerProp("ENVIRONMENT");
		try{//1. Save Cancel/Rejected status of the Request
			int status = 0;
			status = absUserRequesDao.updReqCancelRejectStatus(absCancelRejectRequestModel, approveUser);
			if(status <= 0) {
				result="failed, Request cannot be cancelled/rejected";
			}else {
				status = absUserRequesDao.updateReqCancelRejectStatusChildTable(absCancelRejectRequestModel, approveUser);
				if(status <= 0) {
					result="failed, Request cannot be cancelled/rejected";
				}else {
					//Send Cancellation/Rejection Email
					Map<String, List<String>> emailMap = new HashMap<>();
					List<String> toList = new ArrayList<>();
					List<String> ccList = new ArrayList<>();
					AbsUserReqMdl reqData = getRequestDataByID(absCancelRejectRequestModel.getReqid());
					UserSearchModel assocUser =  userSearchService.getUserStatusJJEDS(reqData.getUserid(), 1);
					UserSearchModel requestorUser =  userSearchService.getUserStatusJJEDS(reqData.getRequestedby(), 1);
					List<UserAbsConflictMdl> confList = absUserRequesDao.getRequestLvlConflicts(absCancelRejectRequestModel.getReqid());
					List<RoleADGrpMdl> restRoles = absUserRequesDao.getRequestLvlRestExcRoleData(absCancelRejectRequestModel.getReqid());
					//String emlSubject = "("+envName+") Your Access Request is Rejected";
					String emlSubject = "("+envName+") Your Access Has Been Rejected by Compliance Manager";
					toList.add(assocUser.getJnjEmailAddrTxt());
					log.info("saveCancelRejectStatus : assocUser.getJnjEmailAddrTxt() :"+assocUser.getJnjEmailAddrTxt());
					log.info("saveCancelRejectStatus : approveUser.getJnjEmailAddrTxt() :"+approveUser.getJnjEmailAddrTxt());
					ccList.add(approveUser.getJnjEmailAddrTxt());
					if(requestorUser!=null) {
						if (requestorUser.getJnjEmailAddrTxt() != null) {
							if (!assocUser.getJnjEmailAddrTxt().equalsIgnoreCase(requestorUser.getJnjEmailAddrTxt())) {
								ccList.add(requestorUser.getJnjEmailAddrTxt());
							}						
						}
					}
					UserSearchModel superwiserDetails = userSearchService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(),1);
					String supEmail = superwiserDetails.getJnjEmailAddrTxt();
					log.debug("superwise email after get :"+supEmail);				
					ccList.add(supEmail);
					emailMap.put("TO", toList);
					List<String> ccListDistinct = ccList.stream().map(e -> e).distinct().collect(Collectors.toList());
					emailMap.put("CC", ccListDistinct);
					//emailUtil.sendAbsRequestApprovalEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
					//public void sendAbsCancelRequestApprovalEmail(String subject, UserSearchModel assocUser, UserSearchModel requestorUser, UserSearchModel approverUser, AbsUserReqMdl reqData,  Map<String, List<String>> emailMap ) throws Exception {
					emailUtil.sendAbsCancelRequestApprovalEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, emailMap, confList, restRoles);

				}
			}
		} catch (Exception e) {
			log.error("Error Saving Approval Data: "+e.getMessage(), e);
			result = "Failed :"+e.getMessage();
		}
		return result;
	}




	@Override
	public String saveComplApprovalData(UserSearchModel approveUser, AbsComplianceRequest absComlianceRequest) {
		log.debug("saveComplApprovalData  enter into the block");
		log.debug("saveComplApprovalData  absComlianceRequest :"+absComlianceRequest);
		String result = "Success";
		String envName = Utility.getServerProp("ENVIRONMENT");
		try{
			//1. Save Conflicts Approval  3. Update Request Header
			int confUpdated = 0;
			int confSize = 0;
			List<UserAbsConflictMdl> confList = absComlianceRequest.getConfApprovalList();
			log.debug("saveComplApprovalData before the condition :"+confList);
			if(confList != null && !confList.isEmpty()) {
				log.debug("saveComplApprovalData confList :"+confList);
				confSize = confList.size();
				log.debug("saveComplApprovalData confList.size :"+confSize);
				confUpdated = absUserRequesDao.updReqConflictStatus(confList, approveUser);
			}

			//2. Save Excessive Access Approval
			/*int excsvUpdated = 0;
			int excsvSize = 0;
			List<AbsExcesvAccsMdl> excessiveApprovalList = absComlianceRequest.getExcessiveApprovalList();
			if(excessiveApprovalList != null && !excessiveApprovalList.isEmpty()) {
				excsvSize = excessiveApprovalList.size();
				excsvUpdated = absUserRequesDao.updReqExcsvAccessStatus(excessiveApprovalList, approveUser);
				List<RawSysDpendncMdl> variantDetails = new ArrayList<RawSysDpendncMdl>();
				excessiveApprovalList.stream().forEach(e -> {
					variantDetails.addAll(e.getVariantDetails());
				});

				if(excsvUpdated > 0 && variantDetails.size() > 0) {
					int appDnTotal =  absUserRequesDao.saveVariantApprovalStatus(variantDetails, absComlianceRequest.getReqid());
					log.info("Total Records inserted : "+appDnTotal);
				}
			}*/

			//Updating Status for Restrictive/Accessive Approval List

			int excsvUpdated = 0;
			int excsvSize = 0;
			List<AbsSysLeveExcsvRestrMdl> restExcsvAcssList = absComlianceRequest.getRestExcsvAcssList();
			log.debug("saveComplApprovalData restExcsvAcssList "+restExcsvAcssList);
			if(restExcsvAcssList != null && !restExcsvAcssList.isEmpty()) {
				log.debug("saveComplApprovalData restExcsvAcssList :"+restExcsvAcssList);
				List<RoleADGrpMdl> allSysVariants = null;
				for(AbsSysLeveExcsvRestrMdl restExcsvMdl : restExcsvAcssList) {
					allSysVariants = new ArrayList<>();
					if(restExcsvMdl.getSelVarsRestricted() != null && !restExcsvMdl.getSelVarsRestricted().isEmpty()) {
						allSysVariants.addAll(restExcsvMdl.getSelVarsRestricted());
					}
					if(restExcsvMdl.getSelVarsNonRestricted() != null && !restExcsvMdl.getSelVarsNonRestricted().isEmpty()) {
						allSysVariants.addAll(restExcsvMdl.getSelVarsNonRestricted());
					}
					excsvSize += allSysVariants.size();
					excsvUpdated += absUserRequesDao.updReqExcsvRestrictiveAccessStatus(allSysVariants, approveUser);
				}
			}
			log.debug("-------------saveComplApprovalData confUpdated excsvUpdated :"+excsvUpdated);
			log.debug("-------------saveComplApprovalData confUpdated confUpdated :"+confUpdated);
			log.debug("-------------saveComplApprovalData confUpdated confSize :"+confSize);
			log.debug("-------------saveComplApprovalData confUpdated excsvUpdated :"+excsvSize);

			if((confUpdated == confSize) && (excsvUpdated == excsvSize)) {
				log.debug("-------------saveComplApprovalData enter into the block:");
				// yeswanth modified code. Need to rewrite the code
				// change the status to 8 if all rejected by user
				List<RoleADGrpMdl> restRoles = absUserRequesDao.getRequestLvlRestExcRoleData(absComlianceRequest.getReqid());
				int totalSize = restRoles.size();
				int accptSize = 0;
				int failSize = 0;
				int conflict = 0;
				for (RoleADGrpMdl roleADGrp : restRoles) {
		            if ("A".equals(roleADGrp.getAcceptDeny())) {
		            	accptSize++;
		            }
		            if ("F".equals(roleADGrp.getAcceptDeny())) {
		            	failSize++;
		            }
		        }
				//List<ConflictRequestedModel> deniedPositions = absUserRequesDao.getConflictsDeniedPositions(absComlianceRequest.getReqid()+"", "");
				List<ConflictRequestedModel> deniedPositions = absUserRequesDao.getConflictCount(absComlianceRequest.getReqid()+"", "");
				if (deniedPositions!=null && deniedPositions.size() > 0) {
					conflict = deniedPositions.size();
				}
				log.debug("-------------saveComplApprovalData confUpdated failSize :"+failSize);
				log.debug("-------------saveComplApprovalData confUpdated totalSize :"+totalSize);
				log.debug("-------------saveComplApprovalData confUpdated conflict :"+conflict);

				if (failSize == totalSize && conflict == 0) {
					log.debug("-------------saveComplApprovalData enter into conflict 8 block :");
					absUserRequesDao.confUpdateRequestStatus(absComlianceRequest.getReqid(), 8, "Y");
				}else if(failSize == totalSize && conflict > 0) {
					log.debug("-------------saveComplApprovalData enter into conflict else if block failSize == totalSize && conflict > 0 :");
					List<ConflictRequestedModel> deniedPos = absUserRequesDao.getConflictsDeniedPositions(absComlianceRequest.getReqid()+"", "");
					if(deniedPos !=null && deniedPos.size() >0) {
						log.debug("-------------saveComplApprovalData enter into  deniedPos :"+deniedPos.size());
					}
					if(conflict == deniedPos.size() ) {
						log.debug("-------------saveComplApprovalData conflict > 0 enter into conflict 8 block :");
						absUserRequesDao.confUpdateRequestStatus(absComlianceRequest.getReqid(), 8, "Y");
					}else {
						log.debug("-------------saveComplApprovalData enter into 4 deniedPos "+deniedPos.size());
						absUserRequesDao.confUpdateRequestStatus(absComlianceRequest.getReqid(), 4, "Y");
					}
				}else {
					log.debug("-------------saveComplApprovalData enter into normal 4 block :");
					absUserRequesDao.confUpdateRequestStatus(absComlianceRequest.getReqid(), 4, "Y");
				}

			}else {
				absUserRequesDao.confUpdateRequestStatus(absComlianceRequest.getReqid(), 3, "Y");
			}

			log.debug("saveComplApprovalData(confUpdated :"+confUpdated+" excsvUpdated :"+excsvUpdated);
			if(confUpdated > 0 ||  excsvUpdated > 0) {
				log.debug("saveComplApprovalData enter into the condition confUpdated  excsvUpdated :"+excsvUpdated);
				List<RoleADGrpMdl> restRoles = absUserRequesDao.getRequestLvlRestExcRoleData(absComlianceRequest.getReqid());
				int totalSize = restRoles.size();
				int accptSize = 0;
				int failSize = 0;
				int conflict = 0;
				for (RoleADGrpMdl roleADGrp : restRoles) {
		            if ("A".equals(roleADGrp.getAcceptDeny())) {
		            	accptSize++;
		            }
		            if ("F".equals(roleADGrp.getAcceptDeny())) {
		            	failSize++;
		            }
		        }

				List<ConflictRequestedModel> deniedPositions = absUserRequesDao.getConflictCount(absComlianceRequest.getReqid()+"", "");
				if (deniedPositions!=null && deniedPositions.size() > 0) {
					conflict = deniedPositions.size();
				}
				log.debug("saveComplApprovalData totalSize :"+totalSize);
				log.debug("saveComplApprovalData aSize :"+accptSize);
				log.debug("saveComplApprovalData fSize :"+failSize);
				log.debug("saveComplApprovalData conflict :"+conflict);
				//SEND APPROVAL EMAIL
				Map<String, List<String>> emailMap = new HashMap<>();
				List<String> toList = new ArrayList<>();
				List<String> ccList = new ArrayList<>();
				AbsUserReqMdl reqData = getRequestDataByID(absComlianceRequest.getReqid());
				UserSearchModel assocUser =  userSearchService.getUserStatusJJEDS(reqData.getUserid(), 1);
				UserSearchModel requestorUser =  userSearchService.getUserStatusJJEDS(reqData.getRequestedby(), 1);
				toList.add(assocUser.getJnjEmailAddrTxt());
				ccList.add(approveUser.getJnjEmailAddrTxt());
				if(requestorUser!=null) {
					if (requestorUser.getJnjEmailAddrTxt() != null) {
						if (!assocUser.getJnjEmailAddrTxt().equalsIgnoreCase(requestorUser.getJnjEmailAddrTxt())) {
							ccList.add(requestorUser.getJnjEmailAddrTxt());
						}						
					}
				}
				UserSearchModel superwiserDetails = userSearchService.getUserStatusJJEDS(assocUser.getJnjSupvrWwId(),1);
				String supEmail = superwiserDetails.getJnjEmailAddrTxt();
				log.debug("superwise email after get :"+supEmail);				
				ccList.add(supEmail);
				//List<String> ccListDistinct = ccList.stream().map(e -> e).distinct().collect(Collectors.toList());)
				emailMap.put("TO", toList);
				List<String> ccListDistinct = ccList.stream().map(e -> e).distinct().collect(Collectors.toList());
				emailMap.put("CC", ccListDistinct);
				String emlSubject = "("+envName+") ";

				log.debug("saveComplApprovalData emlSubject :"+emlSubject);
				log.debug("saveComplApprovalData assocUser :"+assocUser);
				log.debug("saveComplApprovalData requestorUser :"+requestorUser);
				log.debug("saveComplApprovalData approveUser :"+approveUser);
				log.debug("saveComplApprovalData confList :"+confList);
				log.debug("saveComplApprovalData restExcsvAcssList :"+restExcsvAcssList);
				log.debug("saveComplApprovalData emailMap :"+emailMap);
				if(accptSize == totalSize && conflict == 0) {
					log.debug(" saveComplApprovalData Your Access Request is Approved");
		            //emlSubject += " Your Access Request is Approved ";
					emlSubject += " Your Access Has Been Approved by Compliance Manager ";
		            reqData.setReqStatusDesc("Compliance Reviewed");
		            emailUtil.sendAbsRequestApprovalEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
				}else if (accptSize == totalSize && conflict > 0) {
					List<ConflictRequestedModel> deniedPos = absUserRequesDao.getConflictsDeniedPositions(absComlianceRequest.getReqid()+"", "");
					if(deniedPos !=null && deniedPos.size() >0) {
						log.debug("saveComplApprovalData all acceptsize conflict request denied found :"+deniedPos.size());
					}
					if( deniedPos != null && deniedPos.size() == 0) {
						log.debug("saveComplApprovalData conflict request with all accepted block :"+deniedPos.size());
						//emlSubject += " Your Access Request is Approved ";
						emlSubject += " Your Access Has Been Approved by Compliance Manager ";
			            reqData.setReqStatusDesc("Compliance Reviewed");
			            emailUtil.sendAbsRequestApprovalEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
					}else {
						log.debug("saveComplApprovalData conflict request denied and accepted count :"+deniedPos.size());
						reqData.setReqStatusDesc("Compliance Partially Approved");
				        log.debug("saveComplApprovalData Your Access Request is Partially Approved");
				        //emlSubject += " Your Access Request is Partially Approved ";
				        emlSubject += " Your Access Has Been Partially Approved by Compliance Manager ";
				        emailUtil.sendAbsRequestPartialEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
					}
		        } else if (failSize == totalSize && conflict == 0) {
		            log.debug("saveComplApprovalData Your Access Request is Rejected");
		        	reqData.setReqStatusDesc("Compliance Rejected");
		        	//emlSubject += " Your Access Request is Rejected ";
		        	emlSubject += " Your Access Has Been Rejected by Compliance Manager ";
		        	emailUtil.sendAbsRequestAllRejectEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
		        } else if(failSize == totalSize && conflict > 0) {
		        	List<ConflictRequestedModel> deniedPos = absUserRequesDao.getConflictsDeniedPositions(absComlianceRequest.getReqid()+"", "");
					if(deniedPos !=null && deniedPos.size() >0) {
						log.debug("saveComplApprovalData conflict request denied found :"+deniedPos.size());
					}
					if(conflict == deniedPos.size() ) {
						log.debug("saveComplApprovalData conflict request all denied :");
						reqData.setReqStatusDesc("Compliance Rejected");
			        	//emlSubject += " Your Access Request is Rejected ";
						emlSubject += " Your Access Has Been Rejected by Compliance Manager ";
			        	emailUtil.sendAbsRequestAllRejectEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
					}else {
						log.debug("saveComplApprovalData conflict request denied and accepted count :"+deniedPos.size());
						reqData.setReqStatusDesc("Compliance Partially Approved");
				        log.debug("saveComplApprovalData Your Access Request is Partially Approved");
				        //emlSubject += " Your Access Request is Partially Approved ";
				        emlSubject += " Your Access Has Been Partially Approved by Compliance Manager ";
				        emailUtil.sendAbsRequestPartialEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
					}
		        } else {
		        	reqData.setReqStatusDesc("Compliance Partially Approved");
			        log.debug("saveComplApprovalData Your Access Request is Partially Approved");
			        //emlSubject += " Your Access Request is Partially Approved ";
			        emlSubject += " Your Access Has Been Partially Approved by Compliance Manager ";
			        emailUtil.sendAbsRequestPartialEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
		        }

				//String emlSubject = "("+envName+") Your Access Request is Approved";
				//emailUtil.sendAbsRequestApprovalEmail(emlSubject, assocUser, requestorUser, approveUser, reqData, confList, restExcsvAcssList, emailMap);
			}

		} catch (Exception e) {
			log.error("Error Saving Approval Data: "+e.getMessage(), e);
			result = "Failed :"+e.getMessage();
		}
		log.debug("saveComplApprovalData  end of the block");
		return result;
	}


	@Override
	public List<AbsSysLeveExcsvRestrMdl> getReqLvlRestrExcsvData(String reqId) {
		List<AbsSysLeveExcsvRestrMdl> excLst = new ArrayList<>();
		Map<String, AbsSysLeveExcsvRestrMdl> sysMap = new HashMap<>();
		try {

			//PART - 1 Get Sector Data
			List<AbsSecExcesvRestrictedAccsMdl> sectorDataList = absUserRequesDao.getRequestLvlRestExcSecData(reqId);
			sectorDataList.forEach(secD ->{
				AbsSysLeveExcsvRestrMdl sysMdl = null;
				List<AbsSecExcesvRestrictedAccsMdl> sLst = null;
				if(sysMap.containsKey(secD.getSysid())) {
					sysMdl= sysMap.get(secD.getSysid());
					sLst = sysMdl.getSectorDataList();
					sLst.add(secD);
					sysMdl.setSectorDataList(sLst);
				}else {
					sysMdl= new AbsSysLeveExcsvRestrMdl();
					sysMdl.setReqid(secD.getReqid());
					sysMdl.setSysid(secD.getSysid());
					sysMdl.setSysName(secD.getSysName());
					sysMdl.setUserid(secD.getUserid());
					sLst = new ArrayList<>();
					sLst.add(secD);
					sysMdl.setSectorDataList(sLst);
				}
				sysMap.put(secD.getSysid(), sysMdl);
			});


			//PART - 2 Get All Roles(RESTRICTED/NON-RESTRICTED)
			List<RoleADGrpMdl> restRoles = absUserRequesDao.getRequestLvlRestExcRoleData(reqId);
			restRoles.forEach(rls ->{
				if(sysMap.containsKey(rls.getSysId())) {
					AbsSysLeveExcsvRestrMdl sysMdl = sysMap.get(rls.getSysId());
					if("Yes".equalsIgnoreCase(rls.getIsRestricted())) {
						List<RoleADGrpMdl> resLst =  (sysMdl.getSelVarsRestricted() == null || sysMdl.getSelVarsRestricted().isEmpty())? new ArrayList<>() : sysMdl.getSelVarsRestricted();
						resLst.add(rls);
						sysMdl.setSelVarsRestricted(resLst);
					}else {
						List<RoleADGrpMdl> nonResLst =  (sysMdl.getSelVarsNonRestricted() == null || sysMdl.getSelVarsNonRestricted().isEmpty())? new ArrayList<>() : sysMdl.getSelVarsNonRestricted();
						nonResLst.add(rls);
						sysMdl.setSelVarsNonRestricted(nonResLst);
					}
					sysMap.put(rls.getSysId(), sysMdl);
				}
			});
		} catch (Exception e) {
			log.error("Error getting Request Excessive Data: "+e.getMessage(), e);
		}
		excLst.addAll(sysMap.values());
		return excLst;
	}


}
