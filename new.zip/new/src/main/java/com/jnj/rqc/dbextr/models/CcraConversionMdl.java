package com.jnj.rqc.dbextr.models;

import lombok.Data;


@Data
public class CcraConversionMdl {
	private String roleName;
	private String sodCode;
	private String srcSystem;
	private String notes;

	public String getData() {
		return   roleName + "~" + sodCode + "~" +srcSystem + "~" + notes  ;
	}


	@Override
	public String toString() {
		return "ConflictModel [ roleName=" + roleName + ", sodCode=" + sodCode + ", srcSystem=" + srcSystem + ", notes=" + notes + "]";
	}
}
