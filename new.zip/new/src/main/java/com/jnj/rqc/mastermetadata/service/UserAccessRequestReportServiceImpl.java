package com.jnj.rqc.mastermetadata.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.jnj.rqc.mastermetadata.controller.AnaplanRoleModel;
import com.jnj.rqc.mastermetadata.controller.CrossAppRoleModel;
import com.jnj.rqc.mastermetadata.controller.UserAccessReqRepDTO;
import com.jnj.rqc.mastermetadata.controller.UserAccessReqRptMdl;
import com.jnj.rqc.mastermetadata.controller.UserExcessiveReqRepDTO;
import com.jnj.rqc.mastermetadata.controller.UserExcessiveReqRptMdl;
import com.jnj.rqc.mastermetadata.dao.MasterMetaDataRepository;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.sharepointIntegration.DocumentUploadToSharepoint;
import com.jnj.rqc.userabs.dao.UserUtilsDao;
import com.jnj.rqc.userabs.models.AbsSecExcesvRestrictedAccsMdl;
import com.jnj.rqc.userabs.models.AbsSysLeveExcsvRestrMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMultiUserMdl;
import com.jnj.rqc.userabs.models.UserAbsConflictMdl;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.util.EmailUtil;

@Service
public class UserAccessRequestReportServiceImpl implements UserAccessRequestReportService {
	
	static final Logger log = LoggerFactory.getLogger(UserAccessRequestReportServiceImpl.class);
	private final MasterMetaDataRepository masterRepository;
	
	@Autowired
	private UserSearchService userSearchService;
	
	@Autowired
	private UserAccessDataService userAccessDataService;
	
	@Autowired
	private UserUtilsDao userUtilsDao;
	
	@Autowired
	private EmailUtil emailUtil;
	
	@Autowired
	private DocumentUploadToSharepoint documentUploadToSharepoint;
	
	@Autowired
	private MasterDataInMemoryService masterDataInMemoryService;
	
	@Autowired
	public UserAccessRequestReportServiceImpl(MasterMetaDataRepository masterRepository) {
		this.masterRepository = masterRepository;		
	}

	@Override
	public UserAccessReqRepDTO getUserAccessRequestResults() {
		UserAccessReqRepDTO reportDTO = new UserAccessReqRepDTO();
		log.debug("enter into the method");
		try {
            List<UserAccessReqRptMdl> allUserReqRepResults = masterRepository.getAllUserAccessReportDetails();
            allUserReqRepResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setUserAccReqReport(allUserReqRepResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}

	@Override
	public UserExcessiveReqRepDTO getUserExcessiveRequestResults() {
		UserExcessiveReqRepDTO reportDTO = new UserExcessiveReqRepDTO();
		log.debug("enter into the method");
		try {
            List<UserExcessiveReqRptMdl> allUserReqRepResults = masterRepository.getAllUserExcessiveReportDetails();
            allUserReqRepResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setUserExcReqReport(allUserReqRepResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}
	
	@Override
	public UserExcessiveReqRepDTO getUserExcessiveRequestResults(String criteria, String value) {
		UserExcessiveReqRepDTO reportDTO = new UserExcessiveReqRepDTO();
		log.debug("enter into the method");
		try {
            List<UserExcessiveReqRptMdl> allUserReqRepResults = masterRepository.getAllUserExcessiveReportDetails(criteria, value);
            allUserReqRepResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setUserExcReqReport(allUserReqRepResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}

	@Override
	public UserAccessReqRepDTO getUserAccessRequestResults(String criteria, String value) {
		UserAccessReqRepDTO reportDTO = new UserAccessReqRepDTO();
		log.debug("enter into the method");
		try {
            List<UserAccessReqRptMdl> allUserReqRepResults = masterRepository.getAllUserAccessReportDetails(criteria, value);
            allUserReqRepResults.forEach(            		
            		rep -> {
            			UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(rep.getUserId().toString(), 1);
            			//rep.setUserName(assocUser.getGivenNm()+" "+assocUser.getFmlyNm());
            			rep.setUserEmail(assocUser.getJnjEmailAddrTxt());
            		});
            reportDTO.setStatusCode(200);
            reportDTO.setUserAccReqReport(allUserReqRepResults);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            reportDTO.setStatusCode(500); 
        }
		log.debug("end of the method");
        return reportDTO;
	}

	@Override
	@Async
	public void getInAppSODReportResults(String reqUserId) {
		log.debug("enter into the method");
		String fileLocation = "";
		boolean isAnyException = false;
		boolean isfileUploaded = false;
		UserSearchModel reqUser = null;
		try {
			reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);
            List<AnaplanRoleModel> allUserReqRepResults = masterRepository.getExistingAnaplanRoleDetails();
            Map<String, List<AnaplanRoleModel>> ReqByUser = allUserReqRepResults.stream()
            	    .collect(Collectors.groupingBy(AnaplanRoleModel::getUserId));
            
            SXSSFWorkbook workbook = new SXSSFWorkbook(100);
            SXSSFSheet sheet = workbook.createSheet("In_App_SOD_Report");
            String[] headers = {"User WWID", "User Email", "First Name", "Last Name", "User Status (JJEDS)", "System Name 1", "Sector Name 1", "Region Name 1", "Position Name 1", "PV Name 1", 
            		"ADGroup Name 1", "Mod Date 1", "Stop Date 1", "System Name 2", "Sector Name 2", "Region Name 2", "Position Name 2", "PV Name 2", "ADGroup Name 2", "Mod Date 1", "Stop Date 1",
            		"SOD_Exists", "Conflict Description", "Line Manager WWID", "Line Manager Email", "Line Manager Full Name"};
            Row headerRow = sheet.createRow(0);
            //CellStyle unlockedCellStyle = workbook.createCellStyle();
            //unlockedCellStyle.setLocked(false); //true or false based on the cell.            
            for (int i = 0; i < headers.length; i++) {
              Cell cell = headerRow.createCell(i);
              cell.setCellValue(headers[i]);
              //cell.setCellStyle(unlockedCellStyle);
            }
            
            /*CellStyle style=null;
            
            XSSFFont font= workbook.createFont();
            font.setFontHeightInPoints((short)10);
            font.setFontName("Arial");
            font.setColor(IndexedColors.WHITE.getIndex());
            font.setBold(true);
            font.setItalic(false);
            
            style=headerRow.getRowStyle();
            style.setFillBackgroundColor(IndexedColors.DARK_BLUE.getIndex());
            //style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            //style.setAlignment(CellStyle.ALIGN_CENTER);
            style.setFont(font);*/
            
            int rowNum = 1;
            for (String userId : ReqByUser.keySet()) 
    	    {
            	//if(userId.equals("11002684")) {
            		UserSearchModel assocUser , mgrUser = null;
            		System.out.println("PROCESSING FOR>>>"+userId);
            		assocUser = userSearchService.getUserStatusJJEDSForReport(userId, 1);
            		if (null!= assocUser)
            			 mgrUser = userSearchService.getUserStatusJJEDSForReport(null!=assocUser.getJnjSupvrWwId()?assocUser.getJnjSupvrWwId():"", 1);
            		List<UserAbsConflictMdl> confLst = new LinkedList<>();            		
            		List<AnaplanRoleModel> userRoleDetails = ReqByUser.get(userId);
	    			List<String> uniqueADGrpNames = userRoleDetails.stream().map(r -> r.getAdGroupName()).distinct().collect(Collectors.toList());
					List<RoleADGrpMdl> systemRoleDetail=userUtilsDao.getAllMstRolesDataForADGrp(uniqueADGrpNames.stream().map(s -> "UPPER('" + s + "')").collect(Collectors.joining(", ")),"4");
					
					List<RoleADGrpMdl> allIds = new ArrayList<>();
					List<StrKeyValPair> systemPosList = new ArrayList<>();			
					allIds.addAll(systemRoleDetail);
					allIds.forEach(e ->{ //Added for removing duplicate System and Position combinations
						StrKeyValPair sysPosMdl = new StrKeyValPair(e.getSysId(), e.getPosId());				
						if(!systemPosList.contains(sysPosMdl)) {
							systemPosList.add(sysPosMdl);
						}
					});
					
					if(!systemPosList.isEmpty() && systemPosList.size() > 1) {								
						String query = buildQuery(systemPosList);				
						confLst = userUtilsDao.getAbsConflictsForPosVariants(query);
					}
					
					if(null !=confLst && !confLst.isEmpty()) {
						for (UserAbsConflictMdl conflict : confLst) 
			    	    {
							RoleADGrpMdl sysRoleObj1 = systemRoleDetail.stream().filter(carnet -> conflict.getPosv1().equalsIgnoreCase(carnet.getPosId())).findFirst().orElse(null);
							RoleADGrpMdl sysRoleObj2 = systemRoleDetail.stream().filter(carnet -> conflict.getPosv2().equalsIgnoreCase(carnet.getPosId())).findFirst().orElse(null);
							Predicate<AnaplanRoleModel> condition = p->p.getAdGroupName().equalsIgnoreCase(sysRoleObj1.getAdgrpName()) || p.getAdGroupName().equalsIgnoreCase(sysRoleObj2.getAdgrpName());
							userRoleDetails.removeIf(condition);
							//systemRoleDetail.removeIf(obj -> obj.getPosId().equalsIgnoreCase(conflict.getPosv2()));
			    	    }
					}
					
					for(AnaplanRoleModel role : userRoleDetails) {
						RoleADGrpMdl sysRoleObj1 = systemRoleDetail.stream().filter(carnet -> role.getAdGroupName().equalsIgnoreCase(carnet.getAdgrpName())).findFirst().orElse(null);
						Row row = sheet.createRow(rowNum++);
						row.createCell(0).setCellValue(userId);
						row.createCell(1).setCellValue(assocUser!=null?assocUser.getJnjEmailAddrTxt():"");
						row.createCell(2).setCellValue(assocUser!=null?assocUser.getGivenNm():"");
						row.createCell(3).setCellValue(assocUser!=null?assocUser.getFmlyNm():"");
						row.createCell(4).setCellValue(assocUser!=null?assocUser.getEmpStatTxt():"");
						row.createCell(5).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSysName():"");
						row.createCell(6).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSecName():"");
						row.createCell(7).setCellValue(sysRoleObj1!=null?sysRoleObj1.getRegName():"");
						row.createCell(8).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPosName():"");
						row.createCell(9).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPvName():"");
						row.createCell(10).setCellValue(role.getAdGroupName());
						row.createCell(11).setCellValue(role.getModDate());
						row.createCell(12).setCellValue(role.getStopDate());
						row.createCell(13).setCellValue("N/A");
						row.createCell(14).setCellValue("N/A");
						row.createCell(15).setCellValue("N/A");
						row.createCell(16).setCellValue("N/A");
						row.createCell(17).setCellValue("N/A");
						row.createCell(18).setCellValue("N/A");
						row.createCell(19).setCellValue("N/A");
						row.createCell(20).setCellValue("N/A");
						row.createCell(21).setCellValue("No");
						row.createCell(22).setCellValue(" ");					
						row.createCell(23).setCellValue(assocUser!=null?assocUser.getJnjSupvrWwId():"");
						row.createCell(24).setCellValue(mgrUser!=null?mgrUser.getJnjEmailAddrTxt():"");
						row.createCell(25).setCellValue(mgrUser!=null?mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm():"");
					}
					
					if(null !=confLst && !confLst.isEmpty()) {
						for (UserAbsConflictMdl conflict : confLst) 
			    	    {							
							RoleADGrpMdl sysRoleObj1 = systemRoleDetail.stream().filter(carnet -> conflict.getPosv1().equals(carnet.getPosId())).findFirst().orElse(null);
							RoleADGrpMdl sysRoleObj2 = systemRoleDetail.stream().filter(carnet -> conflict.getPosv2().equals(carnet.getPosId())).findFirst().orElse(null);
							List<AnaplanRoleModel> userRoleDetails1 = ReqByUser.get(userId);
							AnaplanRoleModel userRoleDetail1 = userRoleDetails1.stream().filter(carnet -> sysRoleObj1.getAdgrpName().equals(carnet.getAdGroupName())).findFirst().orElse(null);
							AnaplanRoleModel userRoleDetail2 = userRoleDetails1.stream().filter(carnet -> sysRoleObj2.getAdgrpName().equals(carnet.getAdGroupName())).findFirst().orElse(null);
							Row row = sheet.createRow(rowNum++);
							row.createCell(0).setCellValue(userId);
							row.createCell(1).setCellValue(assocUser!=null?assocUser.getJnjEmailAddrTxt():"");
							row.createCell(2).setCellValue(assocUser!=null?assocUser.getGivenNm():"");
							row.createCell(3).setCellValue(assocUser!=null?assocUser.getFmlyNm():"");
							row.createCell(4).setCellValue(assocUser!=null?assocUser.getEmpStatTxt():"");
							row.createCell(5).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSysName():"");
							row.createCell(6).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSecName():"");
							row.createCell(7).setCellValue(sysRoleObj1!=null?sysRoleObj1.getRegName():"");
							row.createCell(8).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPosName():"");
							row.createCell(9).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPvName():"");
							row.createCell(10).setCellValue(sysRoleObj1!=null?sysRoleObj1.getAdgrpName():"");
							row.createCell(11).setCellValue(userRoleDetail1!=null?userRoleDetail1.getModDate():"");
							row.createCell(12).setCellValue(userRoleDetail1!=null?userRoleDetail1.getStopDate():"");
							row.createCell(13).setCellValue(sysRoleObj2!=null?sysRoleObj2.getSysName():"");
							row.createCell(14).setCellValue(sysRoleObj2!=null?sysRoleObj2.getSecName():"");
							row.createCell(15).setCellValue(sysRoleObj2!=null?sysRoleObj2.getRegName():"");
							row.createCell(16).setCellValue(sysRoleObj2!=null?sysRoleObj2.getPosName():"");
							row.createCell(17).setCellValue(sysRoleObj2!=null?sysRoleObj2.getPvName():"");
							row.createCell(18).setCellValue(sysRoleObj2!=null?sysRoleObj2.getAdgrpName():"");
							row.createCell(19).setCellValue(userRoleDetail2!=null?userRoleDetail2.getModDate():"");
							row.createCell(20).setCellValue(userRoleDetail2!=null?userRoleDetail2.getStopDate():"");
							row.createCell(21).setCellValue("Yes");
							row.createCell(22).setCellValue(conflict.getConflict());
							row.createCell(23).setCellValue(assocUser!=null?assocUser.getJnjSupvrWwId():"");
							row.createCell(24).setCellValue(mgrUser!=null?mgrUser.getJnjEmailAddrTxt():"");
							row.createCell(25).setCellValue(mgrUser!=null?mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm():"");
			    	    }
					}
            	//}
    	    }
            //String fileLocation = "D:\\EDAL\\Reports\\InAppSOD\\InAppSODReport.xls";
            String formattedDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
            /*fileLocation = "\\\\awsdeynvaw0001\\Shared_Location\\Yeswanth\\reports_test\\In-App_SOD_Report-Anaplan_" + formattedDateTime + ".xlsx";
            File file = new File(fileLocation);
            file.setReadOnly();
            file.setWritable(false);
            FileOutputStream outputStream = new FileOutputStream(file);
            //FileOutputStream outputStream = new FileOutputStream(new File(fileLocation));
            workbook.write(outputStream);
            workbook.close();*/
            fileLocation = "https://jnj.sharepoint.com/teams/EDALProject/EDAL%20Reports/Compliance%20Reports/"+formattedDate+"/In-App_SOD_Report-Anaplan_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx";
            boolean folderStatus = documentUploadToSharepoint.folderCreation(formattedDate);
            if(folderStatus) {
            	log.debug("Folder created in the name of "+formattedDate);
            	isfileUploaded = documentUploadToSharepoint.excelDocumentUpload(workbook, formattedDate, "In-App_SOD_Report-Anaplan_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx");
            }
            else {
            	log.debug("Issue in folder creation...");
            }
        } catch (Exception e) {
        	isAnyException = true;
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		try {
			//UserSearchModel reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);
			String mailSubject = "";
			String mailMessage = "";
			if(!isAnyException && isfileUploaded) {			
	        mailSubject = "In APP SOD Report for Anaplan is Generated";
	        mailMessage = "Please Navigate below location to get latest report<br>"+fileLocation;
			}
			else {
			mailSubject = "In APP SOD Report Generation End up with Error";
		    mailMessage = "Please Re Generate the report<br>";
			}
			if (null!= reqUser)
				emailUtil.sendReportGenerationConfirmation(reqUser.getJnjEmailAddrTxt(), mailSubject, mailMessage);
		}
		catch (Exception e) {
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		log.debug("end of the method");
	}
	
	private List<Map<String, List<CrossAppRoleModel>>> getSystemWiseRoles() {
		List<Map<String, List<CrossAppRoleModel>>> allSystemUsersRolese = new ArrayList<Map<String, List<CrossAppRoleModel>>>();
		try {
			List<CrossAppRoleModel> allUserReqRepResults = new ArrayList<>();
			List<CrossAppRoleModel> allUserDDGRSourceResults = masterRepository.getExistingCrosAppRoleDetails("DDGR");
			List<CrossAppRoleModel> allUserCFINResults = masterRepository.getExistingCrosAppRoleDetails("CFIN");
			List<CrossAppRoleModel> allUserAnaplanResults = masterRepository.getExistingCrosAppRoleDetails("Anaplan");
			//Predicate<CrossAppRoleModel> conditionDDGR = p -> !(p.getAdGroupName().startsWith("JJC-BRAVO-PLAN")) || !(p.getAdGroupName().startsWith("JJC-BRAVO-ACTUALS"));
			Predicate<CrossAppRoleModel> conditionBravo = p->p.getAdGroupName().startsWith("JJC-BRAVO-PLAN") || p.getAdGroupName().startsWith("JJC-BRAVO-ACTUALS");
			Predicate<CrossAppRoleModel> conditionAOne = p->p.getAdGroupName().startsWith("JJC-FINANCE-MGMTADJ");
			//List<CrossAppRoleModel> allUserBravoResults= allUserDDGRResults.stream().filter(article -> article.getAdGroupName().startsWith("JJC-BRAVO-PLAN")).collect(Collectors.toList());
			List<CrossAppRoleModel> allUserBravoResults= allUserDDGRSourceResults.stream().filter(conditionBravo).collect(Collectors.toList());
			List<CrossAppRoleModel> allUserAOneResults= allUserDDGRSourceResults.stream().filter(conditionAOne).collect(Collectors.toList());
			List<CrossAppRoleModel> allUserDDGRResults2= allUserDDGRSourceResults.stream().filter(article -> !article.getAdGroupName().startsWith("JJC-BRAVO-PLAN")).collect(Collectors.toList());
			List<CrossAppRoleModel> allUserDDGRResults1= allUserDDGRResults2.stream().filter(article -> !article.getAdGroupName().startsWith("JJC-BRAVO-ACTUALS")).collect(Collectors.toList());
			List<CrossAppRoleModel> allUserDDGRResults= allUserDDGRResults1.stream().filter(article -> !article.getAdGroupName().startsWith("JJC-FINANCE-MGMTADJ")).collect(Collectors.toList());
			//List<CrossAppRoleModel> allUserDDGRResults1= allUserDDGRSourceResults.stream().filter(conditionDDGR).collect(Collectors.toList());
			Map<String, List<CrossAppRoleModel>> ReqByUserDDGRMap = allUserDDGRResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
			Map<String, List<CrossAppRoleModel>> ReqByUserBravoMap = allUserBravoResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
			Map<String, List<CrossAppRoleModel>> ReqByUserAOneMap = allUserAOneResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
			Map<String, List<CrossAppRoleModel>> ReqByUserCFINMap = allUserCFINResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
			Map<String, List<CrossAppRoleModel>> ReqByUserAnaplanMap = allUserAnaplanResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
			allUserReqRepResults.addAll(allUserDDGRResults);
			allUserReqRepResults.addAll(allUserBravoResults);
			allUserReqRepResults.addAll(allUserAOneResults);
			allUserReqRepResults.addAll(allUserCFINResults);
			allUserReqRepResults.addAll(allUserAnaplanResults);
            Map<String, List<CrossAppRoleModel>> ReqByUser = allUserReqRepResults.stream()
            	    .collect(Collectors.groupingBy(CrossAppRoleModel::getUserId));
            System.out.println("Collected all the system details....");            
            allSystemUsersRolese.add(ReqByUser);
            allSystemUsersRolese.add(ReqByUserDDGRMap);
            allSystemUsersRolese.add(ReqByUserBravoMap);
            allSystemUsersRolese.add(ReqByUserAOneMap);
            allSystemUsersRolese.add(ReqByUserCFINMap);
            allSystemUsersRolese.add(ReqByUserAnaplanMap);
		}
		catch (Exception e) {
	        log.error("Report Generation Exception on system wise Role grouping: " + e.getMessage());
	        e.printStackTrace();
    	}
		return allSystemUsersRolese;
	}
	
	@Override
	@Async
	public void getCrossAppSODReportResults(String reqUserId) {
		log.debug("enter into the method");
		String fileLocation = "";
		boolean isAnyException = false;
		boolean isfileUploaded = false;
		UserSearchModel reqUser = null;
		try {
			reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);          
            SXSSFWorkbook workbook = new SXSSFWorkbook(100);            
            SXSSFSheet sheet1 = workbook.createSheet("Cross_App_SOD_Report");
            String[] headersSheet1 = {"User WWID", "User Email", "First Name", "Last Name", "User Status (JJEDS)", "System Name 1", "Sector Name 1", "Region Name 1", "Position Name 1", "PV Name 1", "Role Name 1", "System Name 2", "Sector Name 2",
            		"Region Name 2", "Position Name 2", "PV Name 2", "Role Name 2", "Conflict Description", "Line Manager WWID", "Line Manager Email", "Line Manager Full Name"};
            Row headerRowSheet1 = sheet1.createRow(0);
            for (int i = 0; i < headersSheet1.length; i++) {
              Cell cell = headerRowSheet1.createCell(i);
              cell.setCellValue(headersSheet1[i]);
            }
            
            List<Map<String, List<CrossAppRoleModel>>> allSystemWiseRoles = getSystemWiseRoles();
            Map<String, List<CrossAppRoleModel>> ReqByUser = allSystemWiseRoles.get(0);
            Map<String, List<CrossAppRoleModel>> ReqByUserDDGRMap = allSystemWiseRoles.get(1);
            Map<String, List<CrossAppRoleModel>> ReqByUserBravoMap = allSystemWiseRoles.get(2);
            Map<String, List<CrossAppRoleModel>> ReqByUserAOneMap = allSystemWiseRoles.get(3);
            Map<String, List<CrossAppRoleModel>> ReqByUserCFINMap = allSystemWiseRoles.get(4);
            Map<String, List<CrossAppRoleModel>> ReqByUserAnaplanMap = allSystemWiseRoles.get(5);
            
            int rowNum = 1;
            for (String userId : ReqByUser.keySet()) 
    	    {
            	//if(userId.equals("11002684")) {
            		UserSearchModel assocUser , mgrUser = null;
            		assocUser = userSearchService.getUserStatusJJEDSForReport(userId, 1);
            		if (null!= assocUser)
            			 mgrUser = userSearchService.getUserStatusJJEDSForReport(null!=assocUser.getJnjSupvrWwId()?assocUser.getJnjSupvrWwId():"", 1);
            		List<UserAbsConflictMdl> confLst = new LinkedList<>();
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailDDGR = new ArrayList<>();
            		if(ReqByUserDDGRMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserDDGRMap.get(userId);
            			for (CrossAppRoleModel ddgrRole : userRoleDetails) {
            				systemRoleDetailDDGR.addAll(masterDataInMemoryService.findBySYS_IDAndAD_NAME("2",ddgrRole.getAdGroupName()));
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailBravo = new ArrayList<>();
            		if(ReqByUserBravoMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserBravoMap.get(userId);
            			for (CrossAppRoleModel BravoRole : userRoleDetails) {
            				systemRoleDetailBravo.addAll(masterDataInMemoryService.findBySYS_IDAndAD_NAME("3",BravoRole.getAdGroupName()));
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailAOne = new ArrayList<>();
            		if(ReqByUserAOneMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAOneMap.get(userId);
            			for (CrossAppRoleModel AOneRole : userRoleDetails) {
            				systemRoleDetailAOne.addAll(masterDataInMemoryService.findBySYS_IDAndAD_NAME("5",AOneRole.getAdGroupName()));
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailCFIN = new ArrayList<>();
            		if(ReqByUserCFINMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserCFINMap.get(userId);
            			for (CrossAppRoleModel cfinRole : userRoleDetails) {
            				systemRoleDetailCFIN.addAll(masterDataInMemoryService.findBySYS_IDAndAD_NAME("1",cfinRole.getAdGroupName()));
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailAnaplan = new ArrayList<>();
            		if(ReqByUserAnaplanMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAnaplanMap.get(userId);
            			for (CrossAppRoleModel anaplanRole : userRoleDetails) {
            				systemRoleDetailAnaplan.addAll(masterDataInMemoryService.findBySYS_IDAndAD_NAME("4",anaplanRole.getAdGroupName()));
            			}
            		}
            		
					
					List<RoleADGrpMultiUserMdl> allIds = new ArrayList<>();
					List<StrKeyValPair> systemPosList = new ArrayList<>();			
					allIds.addAll(systemRoleDetailDDGR);
					allIds.addAll(systemRoleDetailBravo);
					allIds.addAll(systemRoleDetailAOne);
					allIds.addAll(systemRoleDetailCFIN);
					allIds.addAll(systemRoleDetailAnaplan);
					allIds.forEach(e ->{ //Added for removing duplicate System and Position combinations
						StrKeyValPair sysPosMdl = new StrKeyValPair(e.getSysId(), e.getPosId());				
						if(!systemPosList.contains(sysPosMdl)) {
							systemPosList.add(sysPosMdl);
						}
					});
					
					if(!systemPosList.isEmpty() && systemPosList.size() > 1) {								
						String query = buildQuery(systemPosList);				
						confLst = userUtilsDao.getAbsConflictsForPosVariants(query);
					}
					
					if(null !=confLst && !confLst.isEmpty()) {
					for (UserAbsConflictMdl conflict : confLst) 
			    	    {							
							RoleADGrpMultiUserMdl sysRoleObj1 = allIds.stream().filter(carnet -> conflict.getPosv1().equals(carnet.getPosId())).findFirst().orElse(null);
							RoleADGrpMultiUserMdl sysRoleObj2 = allIds.stream().filter(carnet -> conflict.getPosv2().equals(carnet.getPosId())).findFirst().orElse(null);
							
							Row row = sheet1.createRow(rowNum++);
							row.createCell(0).setCellValue(userId);
							row.createCell(1).setCellValue(assocUser!=null?assocUser.getJnjEmailAddrTxt():"");
							row.createCell(2).setCellValue(assocUser!=null?assocUser.getGivenNm():"");
							row.createCell(3).setCellValue(assocUser!=null?assocUser.getFmlyNm():"");
							row.createCell(4).setCellValue(assocUser!=null?assocUser.getEmpStatTxt():"");
							row.createCell(5).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSysName():"");
							row.createCell(6).setCellValue(sysRoleObj1!=null?sysRoleObj1.getSecName():"");
							row.createCell(7).setCellValue(sysRoleObj1!=null?sysRoleObj1.getRegion():"");
							row.createCell(8).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPosName():"");
							row.createCell(9).setCellValue(sysRoleObj1!=null?sysRoleObj1.getPvName():"");
							row.createCell(10).setCellValue(sysRoleObj1!=null?sysRoleObj1.getAdgrpName():"");
							row.createCell(11).setCellValue(sysRoleObj2!=null?sysRoleObj2.getSysName():"");
							row.createCell(12).setCellValue(sysRoleObj2!=null?sysRoleObj2.getSecName():"");
							row.createCell(13).setCellValue(sysRoleObj2!=null?sysRoleObj2.getRegion():"");
							row.createCell(14).setCellValue(sysRoleObj2!=null?sysRoleObj2.getPosName():"");
							row.createCell(15).setCellValue(sysRoleObj2!=null?sysRoleObj2.getPvName():"");
							row.createCell(16).setCellValue(sysRoleObj2!=null?sysRoleObj2.getAdgrpName():"");
							row.createCell(17).setCellValue(conflict.getConflict());					
							row.createCell(18).setCellValue(assocUser!=null?assocUser.getJnjSupvrWwId():"");
							row.createCell(19).setCellValue(mgrUser!=null?mgrUser.getJnjEmailAddrTxt():"");
							row.createCell(20).setCellValue(mgrUser!=null?mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm():"");
							
			    	    }
					}            		
            	//}
    	    }
            String formattedDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
            /*fileLocation = "\\\\awsdeynvaw0001\\Shared_Location\\Yeswanth\\reports_test\\Cross-App_SOD_Report_" + formattedDateTime + ".xlsx";
            FileOutputStream outputStream = new FileOutputStream(new File(fileLocation));
            workbook.write(outputStream);
            workbook.close();*/
            fileLocation = "https://jnj.sharepoint.com/teams/EDALProject/EDAL%20Reports/Compliance%20Reports/"+formattedDate+"/Cross-App_SOD_Report_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx";
            boolean folderStatus = documentUploadToSharepoint.folderCreation(formattedDate);
            if(folderStatus) {
            	log.debug("Folder created in the name of "+formattedDate);
            	isfileUploaded = documentUploadToSharepoint.excelDocumentUpload(workbook, formattedDate, "Cross-App_SOD_Report_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx");
            }
            else {
            	log.debug("Issue in folder creation...");
            }
		}
		catch (Exception e) {
    	isAnyException = true;
        log.error("Report Generation Exception: " + e.getMessage());
        e.printStackTrace();
    	}
		try {
			//UserSearchModel reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);
			String mailSubject = "";
			String mailMessage = "";
			if(!isAnyException && isfileUploaded) {			
	        mailSubject = "Cross APP SOD Report is Generated";
	        mailMessage = "Please Navigate below location to get latest report<br>"+fileLocation;
			}
			else {
			mailSubject = "Cross APP SOD Report Generation End up with Error";
		    mailMessage = "Please Re Generate the report<br>";
			}
			if (null!= reqUser)
				emailUtil.sendReportGenerationConfirmation(reqUser.getJnjEmailAddrTxt(), mailSubject, mailMessage);
		}
		catch (Exception e) {
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		log.debug("end of the method");
	}
	
	@Override
	@Async
	public void getMultiUserReportResults(String reqUserId) {
		log.debug("enter the method to generate All Users Report...");
		String fileLocation = "";
		boolean isAnyException = false;
		boolean isfileUploaded = false;
		UserSearchModel reqUser = null;
		try {
			reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);           
            SXSSFWorkbook workbook = new SXSSFWorkbook(100);            
            SXSSFSheet sheet = workbook.createSheet("Multi_User_Report");
            String[] headers = {"User WWID", "User Email", "First Name", "Last Name", "User Status (JJEDS)", "System Name", "Sector Name", "Region Name", "Position Name", "PV Name", "Role Name",
            		"Restricted", "Line Manager WWID", "Line Manager Email", "Line Manager Full Name"};
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
              Cell cell = headerRow.createCell(i);
              cell.setCellValue(headers[i]);
            }
            
            List<Map<String, List<CrossAppRoleModel>>> allSystemWiseRoles = getSystemWiseRoles();
            Map<String, List<CrossAppRoleModel>> ReqByUser = allSystemWiseRoles.get(0);
            Map<String, List<CrossAppRoleModel>> ReqByUserDDGRMap = allSystemWiseRoles.get(1);
            Map<String, List<CrossAppRoleModel>> ReqByUserBravoMap = allSystemWiseRoles.get(2);
            Map<String, List<CrossAppRoleModel>> ReqByUserAOneMap = allSystemWiseRoles.get(3);
            Map<String, List<CrossAppRoleModel>> ReqByUserCFINMap = allSystemWiseRoles.get(4);
            Map<String, List<CrossAppRoleModel>> ReqByUserAnaplanMap = allSystemWiseRoles.get(5);
            
            int rowNum = 1;
            for (String userId : ReqByUser.keySet()) 
    	    {
            	//if(userId.equals("11002684")) {
            		UserSearchModel assocUser , mgrUser = null;
            		assocUser = userSearchService.getUserStatusJJEDSForReport(userId, 1);
            		if (null!= assocUser)
            			 mgrUser = userSearchService.getUserStatusJJEDSForReport(null!=assocUser.getJnjSupvrWwId()?assocUser.getJnjSupvrWwId():"", 1);            		
					
            		if(ReqByUserDDGRMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserDDGRMap.get(userId);
            			for (CrossAppRoleModel ddgrRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> roleDetailsList = masterDataInMemoryService.findBySYS_IDAndAD_NAME("2",ddgrRole.getAdGroupName());
            				RoleADGrpMultiUserMdl userRoleDetail = null;
            				if(roleDetailsList.size()>0)
            					userRoleDetail = roleDetailsList.get(0);
            				Row row = sheet.createRow(rowNum++);
            				rowCreationforAllUsersReport(userId, row, userRoleDetail, assocUser, mgrUser, ddgrRole.getAdGroupName());
            			}
            		}
            		
            		if(ReqByUserBravoMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserBravoMap.get(userId);
            			for (CrossAppRoleModel BravoRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> roleDetailsList = masterDataInMemoryService.findBySYS_IDAndAD_NAME("3",BravoRole.getAdGroupName());
            				RoleADGrpMultiUserMdl userRoleDetail = null;
            				if(roleDetailsList.size()>0)
            					userRoleDetail = roleDetailsList.get(0);
            				Row row = sheet.createRow(rowNum++);
            				rowCreationforAllUsersReport(userId, row, userRoleDetail, assocUser, mgrUser, BravoRole.getAdGroupName());
            			}
            		}
            		
            		if(ReqByUserAOneMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAOneMap.get(userId);
            			for (CrossAppRoleModel AOneRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> roleDetailsList = masterDataInMemoryService.findBySYS_IDAndAD_NAME("5",AOneRole.getAdGroupName());
            				RoleADGrpMultiUserMdl userRoleDetail = null;
            				if(roleDetailsList.size()>0)
            					userRoleDetail = roleDetailsList.get(0);
            				Row row = sheet.createRow(rowNum++);
            				rowCreationforAllUsersReport(userId, row, userRoleDetail, assocUser, mgrUser, AOneRole.getAdGroupName());
            			}
            		}
            		
            		if(ReqByUserCFINMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserCFINMap.get(userId);
            			for (CrossAppRoleModel cfinRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> roleDetailsList = masterDataInMemoryService.findBySYS_IDAndAD_NAME("1",cfinRole.getAdGroupName());
            				RoleADGrpMultiUserMdl userRoleDetail = null;
            				if(roleDetailsList.size()>0)
            					userRoleDetail = roleDetailsList.get(0);
            				Row row = sheet.createRow(rowNum++);
            				rowCreationforAllUsersReport(userId, row, userRoleDetail, assocUser, mgrUser, cfinRole.getAdGroupName());
            			}
            		}
            		
            		if(ReqByUserAnaplanMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAnaplanMap.get(userId);
            			for (CrossAppRoleModel anaplanRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> roleDetailsList = masterDataInMemoryService.findBySYS_IDAndAD_NAME("4",anaplanRole.getAdGroupName());
            				RoleADGrpMultiUserMdl userRoleDetail = null;
            				if(roleDetailsList.size()>0)
            					userRoleDetail = roleDetailsList.get(0);
            				Row row = sheet.createRow(rowNum++);
            				rowCreationforAllUsersReport(userId, row, userRoleDetail, assocUser, mgrUser, anaplanRole.getAdGroupName());
            			}
            		}
            	//}
    	    }
            String formattedDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
            /*fileLocation = "\\\\awsdeynvaw0001\\Shared_Location\\Yeswanth\\reports_test\\Multi_User_Report_" + formattedDateTime + ".xlsx";
            //String fileLocation = "D:\\EDAL\\Reports\\InAppSOD\\InAppSODReport.xls";
            //fileLocation = "D:\\Users\\rpandiya\\JNJ\\ERP APS DOCS - EDAL Project\\EDAL Reports\\Test_Report\\Multi_User_Report_" + formattedDateTime + ".xlsx";
            FileOutputStream outputStream = new FileOutputStream(new File(fileLocation));
            workbook.write(outputStream);
            workbook.close();*/
            fileLocation = "https://jnj.sharepoint.com/teams/EDALProject/EDAL%20Reports/Compliance%20Reports/"+formattedDate+"/Multi_User_Report_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx";
            boolean folderStatus = documentUploadToSharepoint.folderCreation(formattedDate);
            if(folderStatus) {
            	log.debug("Folder created in the name of "+formattedDate);
            	isfileUploaded = documentUploadToSharepoint.excelDocumentUpload(workbook, formattedDate, "Multi_User_Report_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx");
            }
            else {
            	log.debug("Issue in folder creation...");
            }
		}
		catch (Exception e) {
    	isAnyException = true;
        log.error("Report Generation Exception: " + e.getMessage());
        e.printStackTrace();
    	}
		try {
			//UserSearchModel reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);
			String mailSubject = "";
			String mailMessage = "";
			if(!isAnyException && isfileUploaded) {			
	        mailSubject = "Multi User Roles Report is Generated";
	        mailMessage = "Please Navigate below location to get latest report<br>"+fileLocation;
			}
			else {
			mailSubject = "Multi User Roles Report Generation End up with Error";
		    mailMessage = "Please Re Generate the report<br>";
			}
			if (null!= reqUser)
				emailUtil.sendReportGenerationConfirmation(reqUser.getJnjEmailAddrTxt(), mailSubject, mailMessage);
		}
		catch (Exception e) {
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		log.debug("end of the method");
	}
	
	private void rowCreationforAllUsersReport(String userId, Row row, RoleADGrpMultiUserMdl userRoleDetail, UserSearchModel assocUser, UserSearchModel mgrUser, String aDName) {
		log.debug("Enter the method to create Rows Based on System Roles for that user");
		try {
			row.createCell(0).setCellValue(userId);
			row.createCell(1).setCellValue(assocUser!=null?assocUser.getJnjEmailAddrTxt():"");
			row.createCell(2).setCellValue(assocUser!=null?assocUser.getGivenNm():"");
			row.createCell(3).setCellValue(assocUser!=null?assocUser.getFmlyNm():"");
			row.createCell(4).setCellValue(assocUser!=null?assocUser.getEmpStatTxt():"");
			row.createCell(5).setCellValue(userRoleDetail!=null?userRoleDetail.getSysName():"");
			row.createCell(6).setCellValue(userRoleDetail!=null?userRoleDetail.getSecName():"");
			row.createCell(7).setCellValue(userRoleDetail!=null?userRoleDetail.getRegion():"");
			row.createCell(8).setCellValue(userRoleDetail!=null?userRoleDetail.getPosName():"");
			row.createCell(9).setCellValue(userRoleDetail!=null?userRoleDetail.getPvName():"");
			row.createCell(10).setCellValue(aDName);
			row.createCell(11).setCellValue(userRoleDetail!=null?userRoleDetail.getIsRestricted():"");					
			row.createCell(12).setCellValue(assocUser!=null?assocUser.getJnjSupvrWwId():"");
			row.createCell(13).setCellValue(mgrUser!=null?mgrUser.getJnjEmailAddrTxt():"");
			row.createCell(14).setCellValue(mgrUser!=null?mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm():"");
		}
		catch (Exception e) {
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		log.debug("end of the method");
	}
	
	@Override
	@Async
	public void getThresholdReportResults(String reqUserId) {
		log.debug("enter into the method");
		String fileLocation = "";
		boolean isAnyException = false;
		boolean isfileUploaded = false;
		UserSearchModel reqUser = null;
		try {
			reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);           
            SXSSFWorkbook workbook = new SXSSFWorkbook(100);            
            SXSSFSheet sheet = workbook.createSheet("Threshold_Report");
            String[] headers = {"User WWID", "User Email", "First Name", "Last Name", "User Status (JJEDS)", "System Name", "Sector Name", "Threshold", "Threshold %", "Region Name", "Position Name", "CU Name", "Role Name",
            		"Restricted", "Line Manager WWID", "Line Manager Email", "Line Manager Full Name"};
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
              Cell cell = headerRow.createCell(i);
              cell.setCellValue(headers[i]);
            }
            
            List<Map<String, List<CrossAppRoleModel>>> allSystemWiseRoles = getSystemWiseRoles();
            Map<String, List<CrossAppRoleModel>> ReqByUser = allSystemWiseRoles.get(0);
            Map<String, List<CrossAppRoleModel>> ReqByUserDDGRMap = allSystemWiseRoles.get(1);
            Map<String, List<CrossAppRoleModel>> ReqByUserBravoMap = allSystemWiseRoles.get(2);
            Map<String, List<CrossAppRoleModel>> ReqByUserAOneMap = allSystemWiseRoles.get(3);
            Map<String, List<CrossAppRoleModel>> ReqByUserCFINMap = allSystemWiseRoles.get(4);
            Map<String, List<CrossAppRoleModel>> ReqByUserAnaplanMap = allSystemWiseRoles.get(5);
                        
            int rowNum = 1;
            for (String userId : ReqByUser.keySet()) 
    	    {
            	//if(userId.equals("152981261")) {
            		UserSearchModel assocUser , mgrUser = null;
            		assocUser = userSearchService.getUserStatusJJEDSForReport(userId, 1);
            		if (null!= assocUser)
            			 mgrUser = userSearchService.getUserStatusJJEDSForReport(null!=assocUser.getJnjSupvrWwId()?assocUser.getJnjSupvrWwId():"", 1);
            		
            		List<RoleADGrpMdl> nonMasterList = new ArrayList<>();
            		List<RoleADGrpMultiUserMdl> systemRoleDetailDDGR = new ArrayList<>();
            		List<RoleADGrpMdl> systemRoleDetailDDGRThr = new ArrayList<>();
            		if(ReqByUserDDGRMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserDDGRMap.get(userId);
            			for (CrossAppRoleModel ddgrRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> resFrmCache = masterDataInMemoryService.findBySYS_IDAndAD_NAME("2",ddgrRole.getAdGroupName());
            				if(resFrmCache.size()>0) {
	            				systemRoleDetailDDGR.add(resFrmCache.get(0));
	            				systemRoleDetailDDGRThr.add(objectConversion(userId,resFrmCache.get(0)));
            				}
            				else {
            					nonMasterList.add(objectCreationForNonMasterData("Datahub Reporting (DDGR)",ddgrRole.getAdGroupName()));
            				}
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailBravo = new ArrayList<>();
            		List<RoleADGrpMdl> systemRoleDetailBravoThr = new ArrayList<>();
            		if(ReqByUserBravoMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserBravoMap.get(userId);
            			for (CrossAppRoleModel BravoRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> resFrmCache = masterDataInMemoryService.findBySYS_IDAndAD_NAME("3",BravoRole.getAdGroupName());
            				if(resFrmCache.size()>0) {
	            				systemRoleDetailBravo.add(resFrmCache.get(0));
	            				systemRoleDetailBravoThr.add(objectConversion(userId,resFrmCache.get(0)));
            				}
            				else {
            					nonMasterList.add(objectCreationForNonMasterData("Bravo Express (Plan And Actual)",BravoRole.getAdGroupName()));
            				}
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailAOne = new ArrayList<>();
            		List<RoleADGrpMdl> systemRoleDetailAOneThr = new ArrayList<>();
            		if(ReqByUserAOneMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAOneMap.get(userId);
            			for (CrossAppRoleModel AOneRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> resFrmCache = masterDataInMemoryService.findBySYS_IDAndAD_NAME("5",AOneRole.getAdGroupName());
            				if(resFrmCache.size()>0) {
	            				systemRoleDetailAOne.add(resFrmCache.get(0));
	            				systemRoleDetailAOneThr.add(objectConversion(userId,resFrmCache.get(0)));
            				}
            				else {
            					nonMasterList.add(objectCreationForNonMasterData("Management A1 Adjustments",AOneRole.getAdGroupName()));
            				}
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailCFIN = new ArrayList<>();
            		List<RoleADGrpMdl> systemRoleDetailCFINThr = new ArrayList<>();
            		if(ReqByUserCFINMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserCFINMap.get(userId);
            			for (CrossAppRoleModel cfinRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> resFrmCache = masterDataInMemoryService.findBySYS_IDAndAD_NAME("1",cfinRole.getAdGroupName());
            				if(resFrmCache.size()>0) {
	            				systemRoleDetailCFIN.add(resFrmCache.get(0));
	            				systemRoleDetailCFINThr.add(objectConversion(userId,resFrmCache.get(0)));
            				}
            				else {
            					nonMasterList.add(objectCreationForNonMasterData("Central Finance (CFIN)",cfinRole.getAdGroupName()));
            				}
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> systemRoleDetailAnaplan = new ArrayList<>();
            		List<RoleADGrpMdl> systemRoleDetailAnaplanThr = new ArrayList<>();
            		if(ReqByUserAnaplanMap.containsKey(userId)) {
            			List<CrossAppRoleModel> userRoleDetails = ReqByUserAnaplanMap.get(userId);
            			for (CrossAppRoleModel anaplanRole : userRoleDetails) {
            				List<RoleADGrpMultiUserMdl> resFrmCache = masterDataInMemoryService.findBySYS_IDAndAD_NAME("4",anaplanRole.getAdGroupName());
            				if(resFrmCache.size()>0) {
	            				systemRoleDetailAnaplan.add(resFrmCache.get(0));
	            				systemRoleDetailAnaplanThr.add(objectConversion(userId,resFrmCache.get(0)));
            				}
            				else {
            					nonMasterList.add(objectCreationForNonMasterData("Anaplan",anaplanRole.getAdGroupName()));
            				}
            			}
            		}
            		
            		List<RoleADGrpMultiUserMdl> allIds = new ArrayList<>();	
					allIds.addAll(systemRoleDetailDDGR);
					allIds.addAll(systemRoleDetailBravo);
					allIds.addAll(systemRoleDetailAOne);
					allIds.addAll(systemRoleDetailCFIN);
					allIds.addAll(systemRoleDetailAnaplan);
            		
            		List<RoleADGrpMdl> systemRoleDetailSacThr = new ArrayList<>();					
					
					Map<String, List<RoleADGrpMdl>> newRoles = new HashMap<String, List<RoleADGrpMdl>>();
					newRoles.put("1", systemRoleDetailCFINThr);
					newRoles.put("2", systemRoleDetailDDGRThr);
					newRoles.put("3", systemRoleDetailBravoThr);
					newRoles.put("4", systemRoleDetailAnaplanThr);
					newRoles.put("5", systemRoleDetailAOneThr);
					newRoles.put("6", systemRoleDetailSacThr);
					
					Map<String, List<RoleADGrpMdl>> extRoles = new HashMap<String, List<RoleADGrpMdl>>();
					extRoles.put("1", new ArrayList<>());
					extRoles.put("2", new ArrayList<>());
					extRoles.put("3", new ArrayList<>());
					extRoles.put("4", new ArrayList<>());
					extRoles.put("5", new ArrayList<>());
					extRoles.put("6", new ArrayList<>());
					
					List<AbsSysLeveExcsvRestrMdl> restExcsvList = userAccessDataService.checkRestrtvExcessiveAccess(assocUser, extRoles, newRoles, true);
					System.out.println("Values collected here.... for >>>>>>>>>>>>"+userId);
					
					
					
					for(AbsSysLeveExcsvRestrMdl system : restExcsvList) {
						Map<String, HashMap<String, Integer>> mapForColMerge = new HashMap<String, HashMap<String, Integer>>();
						List<RoleADGrpMdl> roleList = system.getSelVarsNonRestricted();
						//remove RUs from roles
						List<RoleADGrpMdl> remRURoleList = roleList.stream().filter(e -> e.getPvName().startsWith("CU")).collect(Collectors.toList());
						Map<String, List<RoleADGrpMdl>> usrSectorLvlGrp = remRURoleList.stream().collect(Collectors.groupingBy(RoleADGrpMdl::getSecId));
						for(String sectorId : usrSectorLvlGrp.keySet()) {
							HashMap<String, Integer> mapForColMergePos = new HashMap<String, Integer>();
							for(RoleADGrpMdl role : usrSectorLvlGrp.get(sectorId)) {
								Predicate<RoleADGrpMultiUserMdl> condition = p->p.getSysId().equals(role.getSysId()) && p.getSecId().equals(role.getSecId()) && 
										p.getPvId().equals(role.getPvId()) && p.getAccId().equals(role.getAccId());
								List<RoleADGrpMultiUserMdl> masterRoleList = allIds.stream().filter(condition).collect(Collectors.toList());
								for(RoleADGrpMultiUserMdl masterRole:masterRoleList) {
									int rowVal = rowNum++;
									if(mapForColMerge.containsKey(role.getSecId())) {
										mapForColMergePos.put("endPosition", rowVal);
										mapForColMerge.put(role.getSecId(), mapForColMergePos);
									}
									else {
										mapForColMergePos.put("startPosition", rowVal);
										mapForColMergePos.put("endPosition", rowVal);
										mapForColMerge.put(role.getSecId(), mapForColMergePos);
									}
									Row row = sheet.createRow(rowVal);
									row.createCell(0).setCellValue(userId);
									row.createCell(1).setCellValue(assocUser!=null?assocUser.getJnjEmailAddrTxt():"");
									row.createCell(2).setCellValue(assocUser!=null?assocUser.getGivenNm():"");
									row.createCell(3).setCellValue(assocUser!=null?assocUser.getFmlyNm():"");
									row.createCell(4).setCellValue(assocUser!=null?assocUser.getEmpStatTxt():"");
									row.createCell(5).setCellValue(role.getSysName());
									row.createCell(6).setCellValue(role.getSecName());
									AbsSecExcesvRestrictedAccsMdl restAccsMdl = system.getSectorDataList().stream().filter(carnet -> role.getSecId().equals(carnet.getSecId())).findFirst().orElse(null);
									row.createCell(7).setCellValue(restAccsMdl.getExcsvPrcntg());
									row.createCell(8).setCellValue(restAccsMdl.getExcsvPrcntg());
									row.createCell(9).setCellValue(masterRole!=null?masterRole.getRegion():"");
									row.createCell(10).setCellValue(role.getPosName());
									row.createCell(11).setCellValue(role.getPvName());
									row.createCell(12).setCellValue(masterRole!=null?masterRole.getAdgrpName():"");
									row.createCell(13).setCellValue(role.getIsRestricted());					
									row.createCell(14).setCellValue(assocUser!=null?assocUser.getJnjSupvrWwId():"");
									row.createCell(15).setCellValue(mgrUser!=null?mgrUser.getJnjEmailAddrTxt():"");
									row.createCell(16).setCellValue(mgrUser!=null?mgrUser.getGivenNm()+" "+mgrUser.getFmlyNm():"");
								}
							}
						}
						 //sheet.addMergedRegion(new CellRangeAddress(1,12,7,7));
						System.out.println(">>>>>>>>>>>>>>>>>>>>>Column Merging>>>>>>>>>>>>"+userId);
						 for(String sectorId: mapForColMerge.keySet()) {
							 int stPos = mapForColMerge.get(sectorId).get("startPosition");
							 int endPos = mapForColMerge.get(sectorId).get("endPosition");
							 System.out.println("startPosition>>>"+stPos+"endPosition>>>>"+endPos);
							 if(stPos != endPos) {
								 sheet.addMergedRegion(new CellRangeAddress(mapForColMerge.get(sectorId).get("startPosition"),mapForColMerge.get(sectorId).get("endPosition"),8,8));
								 
							 }
						 }
					}
					System.out.println("Rows are composed for a user...");

					 /*Cell cell = sheet.getRow(1).getCell(7);
					 CellStyle cellStyle = workbook.createCellStyle();
					 cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
					 cellStyle.setAlignment(HorizontalAlignment.CENTER);
					 cell.setCellStyle(cellStyle);*/
            	//}
    	    }
            String formattedDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
            /*fileLocation = "\\\\awsdeynvaw0001\\Shared_Location\\Yeswanth\\reports_test\\Threshold_Report_" + formattedDateTime + ".xlsx";
            FileOutputStream outputStream = new FileOutputStream(new File(fileLocation));
            workbook.write(outputStream);
            workbook.close();*/
            fileLocation = "https://jnj.sharepoint.com/teams/EDALProject/EDAL%20Reports/Compliance%20Reports/"+formattedDate+"/Threshold_Report_" + formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx";
            boolean folderStatus = documentUploadToSharepoint.folderCreation(formattedDate);
            if(folderStatus) {
            	log.debug("Folder created in the name of "+formattedDate);
            	isfileUploaded = documentUploadToSharepoint.excelDocumentUpload(workbook, formattedDate, "Threshold_Report_" +formattedDateTime +"_"+reqUser.getGivenNm()+"_"+reqUser.getFmlyNm()+ ".xlsx");
            }
            else {
            	log.debug("Issue in folder creation...");
            }
		}
		catch (Exception e) {
    	isAnyException = true;
        log.error("Report Generation Exception: " + e.getMessage());
        e.printStackTrace();
    	}
		try {
			//UserSearchModel reqUser = userSearchService.getUserStatusJJEDS(reqUserId, 1);
			String mailSubject = "";
			String mailMessage = "";
			if(!isAnyException && isfileUploaded) {			
	        mailSubject = "Threshold Report is Generated";
	        mailMessage = "Please Navigate below location to get latest report<br>"+fileLocation;
			}
			else {
			mailSubject = "Threshold Report Generation End up with Error";
		    mailMessage = "Please Re Generate the report<br>";
			}
			if (null!= reqUser)
				emailUtil.sendReportGenerationConfirmation(reqUser.getJnjEmailAddrTxt(), mailSubject, mailMessage);
		}
		catch (Exception e) {
            log.error("Report Generation Exception: " + e.getMessage());
            e.printStackTrace();
        }
		log.debug("end of the method");
	}
	
	private RoleADGrpMdl objectCreationForNonMasterData(String system, String role){
			RoleADGrpMdl roleAdGrp = new RoleADGrpMdl();
			roleAdGrp.setSysName(system);
			roleAdGrp.setAdgrpName(role);
		return roleAdGrp;
	}
	
	private RoleADGrpMdl objectConversion(String userId, RoleADGrpMultiUserMdl role){
			RoleADGrpMdl roleAdGrp = new RoleADGrpMdl();
			roleAdGrp.setReqId(0);
			roleAdGrp.setUserId(userId);
			roleAdGrp.setSysId(role.getSysId());
			roleAdGrp.setSysName("");
			roleAdGrp.setPosId(role.getPosId());
			roleAdGrp.setPosName("");
			roleAdGrp.setPvId(role.getPvId());
			roleAdGrp.setPvName(role.getPvName());
			roleAdGrp.setAdgrpId(role.getAdgrpId());
			roleAdGrp.setAccId(role.getAccId());
			roleAdGrp.setAdgrpName(role.getAdgrpName());
			roleAdGrp.setReqBy(null);
			roleAdGrp.setReqDate(null);
			roleAdGrp.setUpdDate(null);
			roleAdGrp.setIsExisting(null);
		return roleAdGrp;
	}
	
	private String buildQuery(List<StrKeyValPair> data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT RISKID, RISKDESC, APP1, APPNAME1, POSV1, POSVNAME1, APP2, APPNAME2, POSV2, POSVNAME2, CONFLICT, RISK_LEVEL, nvl(MIT_ID, 0) as MIT_ID, MIT_DESC, CREATEDON ");
		sql.append(" FROM SOD_DB_USER.ZUSER_CONFLICT_MATRIX ");
		if(data.size() == 2) {
			sql.append(" WHERE ( APP1 = "+data.get(0).getKey()+ " AND  POSV1 = "+data.get(0).getVal() +" AND APP2 = "+data.get(1).getKey() +" AND POSV2 = "+data.get(1).getVal()+") "
					+ " OR ( APP2 = "+data.get(0).getKey()+" AND POSV2 = "+data.get(0).getVal() +" AND APP1 = "+data.get(1).getKey() +" AND POSV1 = "+data.get(1).getVal()+") ");
		}else {
			sql.append(" WHERE (");
			for (int i = 0; i < data.size(); i++) {
				for (int j = i+1; j < data.size(); j++) {
					sql.append(" ( APP1 = "+data.get(i).getKey()+ " AND  POSV1 = "+data.get(i).getVal() +" AND APP2 = "+data.get(j).getKey() +" AND POSV2 = "+data.get(j).getVal()+") "
							+ "OR ( APP2 = "+data.get(i).getKey()+" AND POSV2 = "+data.get(i).getVal() +" AND APP1 = "+data.get(j).getKey() +" AND POSV1 = "+data.get(j).getVal()+") ");
					if(i < (data.size() - 2)) {
						sql.append(" OR ");
					}
				}
			}
			sql.append(" )");
		}

		sql.append(" ORDER BY APP1, APP2, POSV1, POSV2 ");
		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}
	

}
