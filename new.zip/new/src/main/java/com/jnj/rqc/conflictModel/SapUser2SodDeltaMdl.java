package com.jnj.rqc.conflictModel;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SapUser2SodDeltaMdl {
	private String revUserId;
	private String userId;
	private String primaryReviewInfo1;
	private String additionalInfo1;
	private String additionalInfo2;
	private String mitigatingId;
	private String additionalInfo3;
	private String platformName;
	private String riskIdAndRiskDescription;
	private String reviewerDescription;
	private String userStatus;
	private Date dateEntered;
	private Date reportDate;

	public String getData() {
		return revUserId + "~" + userId + "~" + primaryReviewInfo1 + "~" + additionalInfo1 + "~" + additionalInfo2 + "~" + mitigatingId +
				"~" + additionalInfo3 + "~" + platformName + "~" + riskIdAndRiskDescription + "~" + reviewerDescription+"~"+userStatus+"~"+dateEntered+"~"+reportDate ;
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		SapUser2SodDeltaMdl other = (SapUser2SodDeltaMdl) obj;
		if (additionalInfo1 == null) {
			if (other.additionalInfo1 != null)
				return false;
		} else if (!additionalInfo1.equals(other.additionalInfo1))
			return false;
		if (additionalInfo2 == null) {
			if (other.additionalInfo2 != null)
				return false;
		} else if (!additionalInfo2.equals(other.additionalInfo2))
			return false;
		if (additionalInfo3 == null) {
			if (other.additionalInfo3 != null)
				return false;
		} else if (!additionalInfo3.equals(other.additionalInfo3))
			return false;
		if (mitigatingId == null) {
			if (other.mitigatingId != null)
				return false;
		} else if (!mitigatingId.equals(other.mitigatingId))
			return false;
		if (platformName == null) {
			if (other.platformName != null)
				return false;
		} else if (!platformName.equals(other.platformName))
			return false;
		if (primaryReviewInfo1 == null) {
			if (other.primaryReviewInfo1 != null)
				return false;
		} else if (!primaryReviewInfo1.equals(other.primaryReviewInfo1))
			return false;
		if (revUserId == null) {
			if (other.revUserId != null)
				return false;
		} else if (!revUserId.equals(other.revUserId))
			return false;
		if (reviewerDescription == null) {
			if (other.reviewerDescription != null)
				return false;
		} else if (!reviewerDescription.equals(other.reviewerDescription))
			return false;
		if (riskIdAndRiskDescription == null) {
			if (other.riskIdAndRiskDescription != null)
				return false;
		} else if (!riskIdAndRiskDescription.equals(other.riskIdAndRiskDescription))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((additionalInfo1 == null) ? 0 : additionalInfo1.hashCode());
		result = prime * result + ((additionalInfo2 == null) ? 0 : additionalInfo2.hashCode());
		result = prime * result + ((additionalInfo3 == null) ? 0 : additionalInfo3.hashCode());
		result = prime * result + ((mitigatingId == null) ? 0 : mitigatingId.hashCode());
		result = prime * result + ((platformName == null) ? 0 : platformName.hashCode());
		result = prime * result + ((primaryReviewInfo1 == null) ? 0 : primaryReviewInfo1.hashCode());
		result = prime * result + ((revUserId == null) ? 0 : revUserId.hashCode());
		result = prime * result + ((reviewerDescription == null) ? 0 : reviewerDescription.hashCode());
		result = prime * result + ((riskIdAndRiskDescription == null) ? 0 : riskIdAndRiskDescription.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}




	@Override
	public String toString() {
		return "SapUser2SodDeltaMdl [revUserId=" + revUserId + ", userId=" + userId + ", primaryReviewInfo1="
				+ primaryReviewInfo1 + ", additionalInfo1=" + additionalInfo1 + ", additionalInfo2=" + additionalInfo2
				+ ", mitigatingId=" + mitigatingId + ", additionalInfo3=" + additionalInfo3 + ", platformName="
				+ platformName + ", riskIdAndRiskDescription=" + riskIdAndRiskDescription + ", reviewerDescription="
				+ reviewerDescription + ", userStatus=" + userStatus + ", dateEntered=" + dateEntered + ", reportDate="
				+ reportDate + "]";
	}







}
