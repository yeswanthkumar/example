package com.jnj.rqc.userabs.models;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.models.UserSearchModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RolesRespDto {
	private int 	statusCode;
	private String	message;
	private String 	datetimeStamp;
	private String 	statusDesc;
	private String 	developerMessage;
	private UserSearchModel assocUser;
	private Map<String, List<RoleADGrpMdl>> roles;
}
