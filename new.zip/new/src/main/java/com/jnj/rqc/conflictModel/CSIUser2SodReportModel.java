package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CSIUser2SodReportModel {
	private String sodConflict;
	private String confDesc;
	private String reasonCode;
	private String definition;
	private String expression;
	private String userId;
	private String isSuper;
	private String group;
	private String type;
	private String logicalSystem;
	private String qry1;
	private String qry1Name;
	private String qry1Desc;
	private String norm1;
	private String causingTCode1;
	private String qryTCode1;
	private String qry2;
	private String qry2Name;
	private String qry2Desc;
	private String norm2;
	private String causingTCode2;
	private String qryTCode2;
	//Additional fields to store user info
	private String userName;
	private String userStatus;
}
