package com.jnj.rqc.masterdata.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZBussFuncMdl {
	private int bfid;
	private String bfname;
	private String bfdesc;
	private String isactive;
	private  String createdby;
	private Date createdon;
	private  String cchangedby;
	private Date changedon;





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		ZBussFuncMdl other = (ZBussFuncMdl) obj;
		if (bfdesc == null) {
			if (other.bfdesc != null)
				return false;
		} else if (!bfdesc.equals(other.bfdesc))
			return false;
		if (bfid != other.bfid)
			return false;
		if (bfname == null) {
			if (other.bfname != null)
				return false;
		} else if (!bfname.equals(other.bfname))
			return false;
		if (isactive == null) {
			if (other.isactive != null)
				return false;
		} else if (!isactive.equals(other.isactive))
			return false;
		return true;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfdesc == null) ? 0 : bfdesc.hashCode());
		result = prime * result + bfid;
		result = prime * result + ((bfname == null) ? 0 : bfname.hashCode());
		result = prime * result + ((isactive == null) ? 0 : isactive.hashCode());
		return result;
	}


	@Override
	public String toString() {
		return "ZBussFuncMdl [bfid=" + bfid + ", bfname=" + bfname + ", bfdesc=" + bfdesc + ", isactive=" + isactive
				+ ", createdby=" + createdby + ", createdon=" + createdon + ", cchangedby=" + cchangedby
				+ ", changedon=" + changedon + "]";
	}








}
