package com.jnj.rqc.mastermetadata.service;

import java.util.List;

import com.jnj.rqc.mastermetadata.controller.MitigationData;
import com.jnj.rqc.mastermetadata.controller.MitigationDataDTO;

public interface MitigationDataService {
	public MitigationDataDTO getAllMitigationData();
	public void insertMultipleRecords(List<MitigationData> records);
	public void deleteAllRows(List<MitigationData> records);
}
