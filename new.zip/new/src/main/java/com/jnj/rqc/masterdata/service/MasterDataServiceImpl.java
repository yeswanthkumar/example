package com.jnj.rqc.masterdata.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.masterdata.dao.MasterDataDao;
import com.jnj.rqc.masterdata.dto.ZAccessTypeMdl;
import com.jnj.rqc.masterdata.dto.ZAccessTypeRespDto;
import com.jnj.rqc.masterdata.dto.ZBussFuncMdl;
import com.jnj.rqc.masterdata.dto.ZBussFuncRespDto;
import com.jnj.rqc.masterdata.dto.ZPosVariantMdl;
import com.jnj.rqc.masterdata.dto.ZPosVariantRespDto;
import com.jnj.rqc.masterdata.dto.ZPositionMdl;
import com.jnj.rqc.masterdata.dto.ZPositionRespDto;
import com.jnj.rqc.masterdata.dto.ZRegionMdl;
import com.jnj.rqc.masterdata.dto.ZRegionRespDto;
import com.jnj.rqc.masterdata.dto.ZReqTypMdl;
import com.jnj.rqc.masterdata.dto.ZReqTypRespDto;
import com.jnj.rqc.masterdata.dto.ZSectorMdl;
import com.jnj.rqc.masterdata.dto.ZSectorRespDto;
import com.jnj.rqc.masterdata.dto.ZSystemMdl;
import com.jnj.rqc.masterdata.dto.ZSystemRespDto;
import com.jnj.rqc.userabs.models.BfSctrRegSystemDDMdl;
import com.jnj.rqc.userabs.models.BfSctrRegSystemMdl;
import com.jnj.rqc.userabs.models.BfSctrRegnDDMdl;
import com.jnj.rqc.userabs.models.BfSctrRegnMdl;
import com.jnj.rqc.userabs.models.BsnsFuncSctrsDDMdl;
import com.jnj.rqc.userabs.models.BsnsFuncSctrsMdl;
import com.jnj.rqc.userabs.models.ZBsFnSecRegSystemRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSecRegnsRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSectorsRespDto;
import com.jnj.rqc.userabs.models.ZPosnsAccessRespDto;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarMdl;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarRespDto;
import com.jnj.rqc.userabs.models.ZSysPosAccessMdl;
import com.jnj.rqc.userabs.models.ZSysPositionsMdl;
import com.jnj.rqc.userabs.models.ZSysPositionsRespDto;
import com.jnj.rqc.util.Utility;

@Service
public class MasterDataServiceImpl implements MasterDataService {
	static final Logger log = LoggerFactory.getLogger(MasterDataServiceImpl.class);

	@Autowired
	MasterDataDao masterDataDao;


	@Override
	public ZBussFuncRespDto getZBusssFunc(int bfid) {
		ZBussFuncRespDto bfRespDto = new ZBussFuncRespDto();
		List<ZBussFuncMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZBussFunc(bfid);
			//Addidng a BLANK Model with ID=0 and Name =  - Select -
			ZBussFuncMdl bMdl = new ZBussFuncMdl();
			bMdl.setBfid(0);
			bMdl.setBfname(" - Select - ");
			dataList.add(bMdl);
			//END
			bfRespDto.setBfList(dataList);
			bfRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			bfRespDto.setStatusCode(Constants.SERV_ERR);
			bfRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting Business Functions :"+e.getMessage(), e);
		}
		bfRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return bfRespDto;
	}


	@Override
	public ZReqTypRespDto getZReqTyp(int typid) {
		ZReqTypRespDto rqRespDto = new ZReqTypRespDto();
		List<ZReqTypMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZReqTyp(typid);
			rqRespDto.setReqtypList(dataList);
			rqRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			rqRespDto.setStatusCode(Constants.SERV_ERR);
			rqRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting Request Types :"+e.getMessage(), e);
		}
		rqRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return rqRespDto;
	}


	@Override
	public ZSectorRespDto getZSectors(int secid) {
		ZSectorRespDto secRespDto = new ZSectorRespDto();
		List<ZSectorMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZSectors(secid);
			secRespDto.setSectorList(dataList);
			secRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			secRespDto.setStatusCode(Constants.SERV_ERR);
			secRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting Sectors :"+e.getMessage(), e);
		}
		secRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return secRespDto;
	}



	/**
	 * Method  : MasterDataServiceImpl.java.getZRegions()
	 *		   :<b>@param regid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jan 31, 2023 4:37:00 PM
	 * Purpose :
	 * @return : ZRegionRespDto
	 */
	@Override
	public ZRegionRespDto getZRegions(int regid) {
		ZRegionRespDto regRespDto = new ZRegionRespDto();
		List<ZRegionMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZRegions(regid);
			regRespDto.setRegionList(dataList);
			regRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			regRespDto.setStatusCode(Constants.SERV_ERR);
			regRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting Regions :"+e.getMessage(), e);
		}
		regRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return regRespDto;
	}


	@Override
	public ZSystemRespDto getZSystems(int sysid) {
		ZSystemRespDto sysRespDto = new ZSystemRespDto();
		List<ZSystemMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZSystems(sysid);
			sysRespDto.setSystemList(dataList);
			sysRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			sysRespDto.setStatusCode(Constants.SERV_ERR);
			sysRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting Systems :"+e.getMessage(), e);
		}
		sysRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return sysRespDto;
	}


	@Override
	public ZPositionRespDto getZPositions(int posid) {
		ZPositionRespDto posRespDto = new ZPositionRespDto();
		List<ZPositionMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZPositions(posid);
			posRespDto.setPositionList(dataList);
			posRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			posRespDto.setStatusCode(Constants.SERV_ERR);
			posRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZPosition :"+e.getMessage(), e);
		}
		posRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return posRespDto;
	}


	@Override
	public ZAccessTypeRespDto getZAccessTypes(int accid) {
		ZAccessTypeRespDto acssRespDto = new ZAccessTypeRespDto();
		List<ZAccessTypeMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZAccessTypes(accid);
			acssRespDto.setAccTypList(dataList);
			acssRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			acssRespDto.setStatusCode(Constants.SERV_ERR);
			acssRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZPosition :"+e.getMessage(), e);
		}
		acssRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return acssRespDto;
	}


	/**
	 * Method  : MasterDataServiceImpl.java.getZPosVariants()
	 *		   :<b>@param posvarid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 9, 2023 4:56:25 PM
	 * Purpose :
	 * @return : ZAPosVariantRespDto
	*/
	@Override
	public ZPosVariantRespDto getZPosVariants(int posvarid) {
		ZPosVariantRespDto posvarRespDto = new ZPosVariantRespDto();
		List<ZPosVariantMdl> dataList = new ArrayList<>();
		try {
			dataList = masterDataDao.getAllZPosVariants(posvarid);
			posvarRespDto.setPosVarList(dataList);
			posvarRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			posvarRespDto.setStatusCode(Constants.SERV_ERR);
			posvarRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZPosition :"+e.getMessage(), e);
		}
		posvarRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return posvarRespDto;
	}



	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.service.MasterDataService#getZBfSectors(java.lang.String)
	 */
	@Override
	public ZBsnsFuncSectorsRespDto getZBfSectors(String bfId) {
		ZBsnsFuncSectorsRespDto bfSecRespDto = new ZBsnsFuncSectorsRespDto();
		List<BsnsFuncSctrsMdl> bfSectors = new ArrayList<>();
		List<BsnsFuncSctrsDDMdl> ddLst = new ArrayList<>();
		try {
			bfSectors = masterDataDao.getAllZBfSectors(bfId);
			if(bfSectors != null && !bfSectors.isEmpty()) {
				for(BsnsFuncSctrsMdl sec:bfSectors) {
					BsnsFuncSctrsDDMdl dd = new BsnsFuncSctrsDDMdl();
					dd.setSecid(sec.getSecid());
					dd.setSeccode(sec.getSeccode());
					dd.setSecname(sec.getSecname());
					dd.setSecimg(sec.getSecimg());
					dd.setSecloc(sec.getSecloc());
					dd.setSecdesc(sec.getSecdesc());
					if(!ddLst.contains(dd)) {
						ddLst.add(dd);
					}
				}
			}
			bfSecRespDto.setBfSectors(bfSectors);
			bfSecRespDto.setBfSectorsDD(ddLst);
			bfSecRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			bfSecRespDto.setStatusCode(Constants.SERV_ERR);
			bfSecRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZBusinessFunctionSectors :"+e.getMessage(), e);
		}
		bfSecRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return bfSecRespDto;
	}


	@Override
	public ZBsnsFuncSecRegnsRespDto getZBfSectRegns(String bfId, String[] secIds) {
		ZBsnsFuncSecRegnsRespDto bfSecRegRespDto = new ZBsnsFuncSecRegnsRespDto();
		List<BfSctrRegnMdl> bfSectRegns = new ArrayList<>();
		List<BfSctrRegnDDMdl> regnsDDLst = new ArrayList<>();
		try {
			bfSectRegns = masterDataDao.getAllZBfSecRegions(bfId, secIds);
			if(bfSectRegns != null && !bfSectRegns.isEmpty()) {
				for(BfSctrRegnMdl rgns : bfSectRegns) {
					BfSctrRegnDDMdl ddMdl = new BfSctrRegnDDMdl();
					ddMdl.setRegid(rgns.getRegid());
					ddMdl.setRegname(rgns.getRegname());
					ddMdl.setRegdesc(rgns.getRegdesc());
					ddMdl.setRegloc(rgns.getRegloc());
					ddMdl.setRegimg(rgns.getRegimg());
					if(!regnsDDLst.contains(ddMdl)) {
						regnsDDLst.add(ddMdl);
					}
				}
			}
			bfSecRegRespDto.setBfSecRegnsDD(regnsDDLst);
			bfSecRegRespDto.setBfSecRegns(bfSectRegns);
			bfSecRegRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			bfSecRegRespDto.setStatusCode(Constants.SERV_ERR);
			bfSecRegRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZBfSectRegns :"+e.getMessage(), e);
		}
		bfSecRegRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return bfSecRegRespDto;
	}


	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.service.MasterDataService#getZBfSectRegnSystems(java.lang.String, java.lang.String[], java.lang.String[])
	 */
	@Override
	public ZBsFnSecRegSystemRespDto getZBfSectRegnSystems(String bfId, String[] secIds, String[] regIds) {
		ZBsFnSecRegSystemRespDto bfSecRegRespDto = new ZBsFnSecRegSystemRespDto();
		List<BfSctrRegSystemMdl> bfSectRegnSystems = new ArrayList<>();
		List<BfSctrRegSystemDDMdl> ddLst = new ArrayList<>();
		try {
			bfSectRegnSystems = masterDataDao.getAllZBfSecRegSystems(bfId, secIds, regIds);
			if(bfSectRegnSystems != null && !bfSectRegnSystems.isEmpty()) {
				for(BfSctrRegSystemMdl regMdl : bfSectRegnSystems) {
					BfSctrRegSystemDDMdl mdl = new BfSctrRegSystemDDMdl();
					mdl.setSysid(regMdl.getSysid());
					mdl.setSysname(regMdl.getSysname());
					mdl.setSysdesc(regMdl.getSysdesc());
					if(!ddLst.contains(mdl)) {
						ddLst.add(mdl);
					}
				}
			}
			bfSecRegRespDto.setRegSystemsDD(ddLst);
			bfSecRegRespDto.setRegSystems(bfSectRegnSystems);
			bfSecRegRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			bfSecRegRespDto.setStatusCode(Constants.SERV_ERR);
			bfSecRegRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZBfSectRegnSystems :"+e.getMessage(), e);
		}
		bfSecRegRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return bfSecRegRespDto;
	}


	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.service.MasterDataService#getZSystemPositions(java.lang.String[])
	 */
	/*@Override
	public ZSysPositionsRespDto getZSystemPositions(String sysIds) {
		ZSysPositionsRespDto sysPosRespDto = new ZSysPositionsRespDto();
		List<ZSysPositionsMdl> sysPosns = new ArrayList<ZSysPositionsMdl>();
		List<ZPositionMdl> posnsLst = new ArrayList<ZPositionMdl>();
		try {
			sysPosns = masterDataDao.getAllZSystemPositions(sysIds);
			if(sysPosns != null && !sysPosns.isEmpty()) {
				for(ZSysPositionsMdl psMdl : sysPosns) {
					ZPositionMdl mdl = new ZPositionMdl();
					int id = Integer.parseInt(psMdl.getPosid());
					mdl.setPosid(id);
					mdl.setPosname(psMdl.getPosname());
					mdl.setPosdesc(psMdl.getPosdesc());
					if(!posnsLst.contains(mdl)) {
						posnsLst.add(mdl);
					}
				}
			}
			sysPosRespDto.setSysPositionsDD(posnsLst);
			sysPosRespDto.setSysPositions(sysPosns);
			sysPosRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			sysPosRespDto.setStatusCode(Constants.SERV_ERR);
			sysPosRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPosition :"+e.getMessage(), e);
		}
		sysPosRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return sysPosRespDto;
	}*/

	@Override
	public ZSysPositionsRespDto getZSystemPositions(String bfId, String[] secIds, String[] regIds, String sysIds) {
		ZSysPositionsRespDto sysPosRespDto = new ZSysPositionsRespDto();
		List<ZSysPositionsMdl> sysPosns = new ArrayList<>();
		List<ZPositionMdl> posnsLst = new ArrayList<>();
		try {
			sysPosns = masterDataDao.getAllZSystemPositions(bfId, secIds, regIds, sysIds);
			if(sysPosns != null && !sysPosns.isEmpty()) {
				for(ZSysPositionsMdl psMdl : sysPosns) {
					ZPositionMdl mdl = new ZPositionMdl();
					int id = Integer.parseInt(psMdl.getPosid());
					mdl.setPosid(id);
					mdl.setPosname(psMdl.getPosname());
					mdl.setPosdesc(psMdl.getPosdesc());
					if(!posnsLst.contains(mdl)) {
						posnsLst.add(mdl);
					}
				}
			}
			sysPosRespDto.setSysPositionsDD(posnsLst);
			sysPosRespDto.setSysPositions(sysPosns);
			sysPosRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			sysPosRespDto.setStatusCode(Constants.SERV_ERR);
			sysPosRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPosition :"+e.getMessage(), e);
		}
		sysPosRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return sysPosRespDto;
	}



	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.service.MasterDataService#getZPosnsAccessTypes(java.lang.String, java.lang.String[])
	 */

	@Override
	public ZPosnsAccessRespDto getZPosnsAccessTypes(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds) {
		ZPosnsAccessRespDto posAccRespDto = new ZPosnsAccessRespDto();
		List<ZSysPosAccessMdl> posnAccess = new ArrayList<>();
		List<ZAccessTypeMdl> accessLst = new ArrayList<>();
		try {
			posnAccess = masterDataDao.getAllZSysPosnsAccess(bfId, secIds, regIds, sysId, posIds);
			if(posnAccess != null && !posnAccess.isEmpty()) {
				for(ZSysPosAccessMdl aMdl: posnAccess) {
					ZAccessTypeMdl mdl = new ZAccessTypeMdl();
					mdl.setAccid(Integer.parseInt(aMdl.getAccid()));
					mdl.setAccname(aMdl.getAccname());
					mdl.setAccdesc(aMdl.getAccdesc());
					if(!accessLst.contains(mdl)) {
						accessLst.add(mdl);
					}
				}
			}
			posAccRespDto.setPosAccessDD(accessLst);
			posAccRespDto.setPosAccess(posnAccess);
			posAccRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			posAccRespDto.setStatusCode(Constants.SERV_ERR);
			posAccRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPositionACCESS :"+e.getMessage(), e);
		}
		posAccRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return posAccRespDto;
	}

	/*@Override
	public ZPosnsAccessRespDto getZPosnsAccessTypes(String sysId, String[] posIds) {
		ZPosnsAccessRespDto posAccRespDto = new ZPosnsAccessRespDto();
		List<ZSysPosAccessMdl> posnAccess = new ArrayList<ZSysPosAccessMdl>();
		List<ZAccessTypeMdl> accessLst = new ArrayList<ZAccessTypeMdl>();
		try {
			posnAccess = masterDataDao.getAllZSysPosnsAccess(sysId, posIds);
			if(posnAccess != null && !posnAccess.isEmpty()) {
				for(ZSysPosAccessMdl aMdl: posnAccess) {
					ZAccessTypeMdl mdl = new ZAccessTypeMdl();
					mdl.setAccid(Integer.parseInt(aMdl.getAccid()));
					mdl.setAccname(aMdl.getAccname());
					mdl.setAccdesc(aMdl.getAccdesc());
					if(!accessLst.contains(mdl)) {
						accessLst.add(mdl);
					}
				}
			}
			posAccRespDto.setPosAccessDD(accessLst);
			posAccRespDto.setPosAccess(posnAccess);
			posAccRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			posAccRespDto.setStatusCode(Constants.SERV_ERR);
			posAccRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPositionACCESS :"+e.getMessage(), e);
		}
		posAccRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return posAccRespDto;
	}*/




	@Override
	public ZSysPosAccPvarRespDto getZAccsPosVariants(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsIds) {
		ZSysPosAccPvarRespDto acsPosVarRespDto = new ZSysPosAccPvarRespDto();
		List<ZSysPosAccPvarMdl> posnAccessV = new ArrayList<>();
		List<ZPosVariantMdl> accVLst = new ArrayList<>();
		try {
			posnAccessV = masterDataDao.getAllZSysPosAccPvar(bfId, secIds, regIds, sysId, posIds, acsIds);
			if(posnAccessV != null && !posnAccessV.isEmpty()) {
				for(ZSysPosAccPvarMdl vMdl: posnAccessV) {
					ZPosVariantMdl mdl = new ZPosVariantMdl();
					mdl.setAccid(Integer.parseInt(vMdl.getAccid()));
					mdl.setPosvarid(Integer.parseInt(vMdl.getPosvarid()));
					mdl.setPosvarname(vMdl.getPosvarname());
					mdl.setPosvardesc(vMdl.getPosvardesc());
					if(!accVLst.contains(mdl)) {
						accVLst.add(mdl);
					}
				}
			}
			acsPosVarRespDto.setAccPvarDD(accVLst);
			acsPosVarRespDto.setAccPvar(posnAccessV);
			acsPosVarRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			acsPosVarRespDto.setStatusCode(Constants.SERV_ERR);
			acsPosVarRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPositionACCESS :"+e.getMessage(), e);
		}
		acsPosVarRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return acsPosVarRespDto;
	}
	/*public ZSysPosAccPvarRespDto getZAccsPosVariants(String sysId, String[] posIds, String[] acsIds ) {
		ZSysPosAccPvarRespDto acsPosVarRespDto = new ZSysPosAccPvarRespDto();
		List<ZSysPosAccPvarMdl> posnAccessV = new ArrayList<ZSysPosAccPvarMdl>();
		List<ZPosVariantMdl> accVLst = new ArrayList<ZPosVariantMdl>();
		try {
			posnAccessV = masterDataDao.getAllZSysPosAccPvar(sysId, posIds, acsIds);
			if(posnAccessV != null && !posnAccessV.isEmpty()) {
				for(ZSysPosAccPvarMdl vMdl: posnAccessV) {
					ZPosVariantMdl mdl = new ZPosVariantMdl();
					mdl.setAccid(Integer.parseInt(vMdl.getAccid()));
					mdl.setPosvarid(Integer.parseInt(vMdl.getPosvarid()));
					mdl.setPosvarname(vMdl.getPosvarname());
					mdl.setPosvardesc(vMdl.getPosvardesc());
					if(!accVLst.contains(mdl)) {
						accVLst.add(mdl);
					}
				}
			}
			acsPosVarRespDto.setAccPvarDD(accVLst);
			acsPosVarRespDto.setAccPvar(posnAccessV);
			acsPosVarRespDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			acsPosVarRespDto.setStatusCode(Constants.SERV_ERR);
			acsPosVarRespDto.setStatusDesc(e.getMessage());
			log.error("Error getting ZSystemPositionACCESS :"+e.getMessage(), e);
		}
		acsPosVarRespDto.setDatetimeStamp(Utility.fmtMMDDYYYYTime(new Date()));
		return acsPosVarRespDto;
	}*/



}
