package com.jnj.rqc.service;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.MultipartFile;

import com.jnj.rqc.common.models.SrcSysMemRoleModel;
import com.jnj.rqc.models.BstMetricsModel;
import com.jnj.rqc.models.MemRevieModel;
import com.jnj.rqc.models.UserRole;
import com.jnj.rqc.models.UsrJJEdsMdl;




/**
 * File    : <b>MemberReviewService.java</b>
 * @author : DChauras @Created : May 17, 2019 3:33:44 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
public interface MemberReviewService {
	public List<UserRole> createUserCSV(Path filePath, HttpSession session);
	public Map<String, List<String>> readPVCSUserData(Path filePath);
	public String saveFile(MultipartFile file) throws IOException;
	public List<MemRevieModel> processNagsData(String path, int mon, int year, HttpServletRequest request)throws Exception;
	public List<BstMetricsModel> processBstMetricsData(String path, HttpServletRequest request)throws Exception;
	public List<MemRevieModel> readNagsData(String path, int mon, int year);
	public List<BstMetricsModel> readMetricsData(String path);
	public String writePdfOrCsv(String type, int mon, int year, List<MemRevieModel> data);
	public String writeBstCsv(List<BstMetricsModel> data);

	public List<SrcSysMemRoleModel> processMemReport(String srcsystem) throws Exception;
	public String writeCsvReport(List<SrcSysMemRoleModel> data, String fileName);
	public UsrJJEdsMdl getJJEDSData(String winId);



}
