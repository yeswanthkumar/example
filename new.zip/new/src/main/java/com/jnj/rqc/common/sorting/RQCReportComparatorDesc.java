package com.jnj.rqc.common.sorting;

import java.util.Comparator;

import com.jnj.rqc.reportmodels.ReportDataModel;

public class RQCReportComparatorDesc implements Comparator<ReportDataModel> {

	@Override
	public int compare(ReportDataModel r1, ReportDataModel r2) {
		    return r2.getDtCreated().compareTo(r1.getDtCreated());
    }
}
