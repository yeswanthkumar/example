package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.service.SAPDialogUserDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.util.Utility;



/**
 * File    : <b>SAPNonDialogUserController.java</b>
 * @author : DChauras @Created : Feb 18, 2022 12:13:02 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class SAPNonDialogUserController {
	static final Logger log = LoggerFactory.getLogger(SAPNonDialogUserController.class);
	/*@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;

	@Autowired
	EmailUtil emailUtil;*/
	@Autowired
	SAPDialogUserDataService sAPDialogUserDataService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;


	String BASE_REGION = "REGION";

	@GetMapping("/loadDialogUser2Role")
	public String loadDialogUser2Role(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> regNames = Utility.loadSAPGaaProperty(BASE_REGION);
    	model.addAttribute("riskLvls", riskLvls );
    	model.addAttribute("regNames", regNames );
    	return "sapextraction/dialogUser2RolePage";
	}

    @PostMapping("/loadDialogUser2RoleData")
    public String loadDialogUser2RoleData(@RequestParam("regions") String regions, @RequestParam("pltNames") String pltNames, @RequestParam("environmentId") String environmentId,
    		@RequestParam("sysNames") String sysNames, Model model, HttpServletRequest request) {
    	log.info("Getting Non Dialog Data : region: "+regions+" Platform: "+pltNames+" environmentId: "+environmentId+" sysNames: "+sysNames);
    	String regParam = regions;
    	List<String> regNames = Utility.loadSAPGaaProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );

    	String selPlts = pltNames;
    	List<String> platformNames = Utility.loadSAPGaaProperty(regParam);
    	model.addAttribute("platformNames", platformNames );
    	model.addAttribute("selPlts", selPlts );

    	String envIdParam = environmentId;
    	List<String> envIdNames = Utility.loadSAPGaaProperty(regParam+"_"+selPlts);
    	model.addAttribute("envIdNames", envIdNames );
    	model.addAttribute("envIdParam", envIdParam );

    	String selSysNm = sysNames;
    	List<String> systemNames = Utility.loadSAPGaaProperty(regParam+"_"+selPlts+"_"+envIdParam);
    	model.addAttribute("systemNames", systemNames );
    	model.addAttribute("selSysNm", selSysNm );

    	if("0".equals(regions) || "0".equals(pltNames) || "0".equals(environmentId) || "0".equals(sysNames) /*|| "0".equals(clientId)*/ ) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region/Platform/Environment/System.");
            return "sapextraction/dialogUser2RolePage";
    	}

    	String templSysParam = regParam+"_"+selPlts+"_"+envIdParam+"_"+selSysNm;  //+"_"+clientId;
    	log.info("TemplateName: "+templSysParam);

    	List<SapGaaUser2RoleModel> userRoleData = sAPDialogUserDataService.readDiagUserToRoleData(templSysParam);
    	if(!userRoleData.isEmpty()) {
    		request.getSession().setAttribute("NONDIALOG_USER2ROLE", userRoleData);
    		model.addAttribute("NONDIALOG_USER2ROLE", userRoleData);
    		log.info("Total Non Dialog USER TO ROLE : "+userRoleData.size());
    		//TODO - Added flag for export
        	//model.addAttribute("EXPORT_ALLOWED", "Y");
        	//END flag
    	}
    	request.getSession().setAttribute("PLATFORM", selPlts);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	String msg  = "Status: Total (Non-Dialog user's) USER-ROLE Data: "+ ((userRoleData == null || userRoleData.isEmpty() ) ?  "0": userRoleData.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/dialogUser2RolePage";
    }


    @ResponseBody
    @GetMapping("/downNonDiagUser2RoleExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downNonDiagUser2RoleExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SAP Non-Dialog User to Role Excel ");
		String fileNm ="NDUsertoRole_Review_SAP_"+request.getSession().getAttribute("PLATFORM");
		List<SapGaaUser2RoleModel> actTrfData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("NONDIALOG_USER2ROLE");
		String filePath = sAPExtrGaaDataService.writeSapGaaUser2RoleXLS(actTrfData, fileNm, "NonDilogUser2Role");
		//String zipfilePath = Utility.createZip(Arrays.asList(filePath,invldFlPath), Constants.REPO_OUT_LOC+fileNm+"_"+Utility.fmtMDY(new Date())+".zip");
    	File fl = new File(filePath);
		log.info("Download Non-Dialog File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }





/*
	  @SuppressWarnings("all")
	 @ResponseBody
	 @GetMapping("/exportSAPUser2RoleData")
	 public ResponseEntity<InputStreamResource> exportSAPUser2RoleData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		String template = (String) request.getSession().getAttribute("TEMPLATE");
		log.info("Export SAP User to Role Data for: "+template);
		StringBuilder actions= new StringBuilder();
		actions.append("Export SAP User to Role Data for:"+template+"\n");
		actions.append("Checking Export Status\n");
		String[] tmplArr = template.split("_");
		synchronized (tmplArr) {
			List<TrfCntrlSchModel> result = sAPExtrRegionWiseService.getExistingTRForU2RSchedules(tmplArr[0], "E", "U");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
			if(result != null && result.size() > 0  ) {
				actions.append("User to Role Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
			}else {
				result = sAPExtrRegionWiseService.getExistingTRForU2RSchedules(tmplArr[0], "C", "U");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
				if(result == null || result.isEmpty()) {
					actions.append("User to Role Data CREATION is Not Scheduled for REGION: "+tmplArr[0]+", Cannot Export Data.\n");
				}else if(result.size() > 0 ) {
					String status=result.get(0).getSchStatus();
					if("C".equalsIgnoreCase(status)) {
						UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
						List<SapGaaUser2RoleModel> userAccessData = (List<SapGaaUser2RoleModel>)request.getSession().getAttribute("SAPUSER_ROLEDATA");
						actions.append("Total Records to be replaced : "+userAccessData.size()+" \n Clearing records from Table.\n");
						int delRec = sAPExtrRegionWiseService.deleteUser2RoleTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
						actions.append("Total records deleted : "+delRec+"\n\n");
						actions.append("Inserting "+userAccessData.size()+" Records\n");
						int insRecords = sAPExtrGaaDataService.insertUser2RoleTransactions(userAccessData, template, curUser.getJnjMsftUsrnmTxt());
						actions.append("Total Records inserted : "+insRecords+"\n" );
						try {
							//Building Summary
							TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
							sumMdl.setRegion(tmplArr[0]);
							sumMdl.setPlatform(tmplArr[1]);
							sumMdl.setEnvironment(tmplArr[2]);
							sumMdl.setSystem(tmplArr[3]);
							sumMdl.setCreatedRecCount(insRecords);
							sumMdl.setCreatedDt(new Date());
							sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
							sumMdl.setCollStatus("C");
							actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
							sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
							actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
						} catch (Exception e) {
							log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
						}
					}else {
						actions.append("User to Role Data CREATION is Scheduled/RUNNING for REGION: "+tmplArr[0]+", PLease wait for completion. Cannot Export Data.\n");
					}
				}
			}
		}
		String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
		String filePath = sAPExtrGaaDataService.writeLogData(actions, fileNm);
		File fl = new File(filePath);
		log.info("Download File name:"+fl.getName());
		InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
		return ResponseEntity.ok()
 		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
     	.contentType(MediaType.TEXT_PLAIN)
     	.contentLength(fl.length())
     	.body(resource);
     }


    @GetMapping("/loadSapUserAccessProvPage")
    public String loadSapUserAccessProvPage(Model model, HttpServletRequest request) {
    	List<String> riskLvls = Utility.loadRiskLevel();
    	List<String> regNames = Utility.loadSAPGaaProperty(BASE_REGION);
    	model.addAttribute("riskLvls", riskLvls );
    	model.addAttribute("regNames", regNames );
    	return "sapextraction/sapextruseraccesspage";
    }


    @PostMapping("/loadSapUserAccessProvPageData")
    public String loadSapUserAccessProvPageData(@RequestParam("regions") String regions, @RequestParam("pltNames") String pltNames, @RequestParam("environmentId") String environmentId,
    		@RequestParam("sysNames") String sysNames, @RequestParam("clientId") String clientId, Model model, HttpServletRequest request) {
    	log.info("region: "+regions+" Platform: "+pltNames+" environmentId: "+environmentId+" sysNames: "+sysNames+" clientId: "+clientId);
    	String regParam = regions;
    	List<String> regNames = Utility.loadSAPGaaProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );

    	String selPlts = pltNames;
    	List<String> platformNames = Utility.loadSAPGaaProperty(regParam);
    	model.addAttribute("platformNames", platformNames );
    	model.addAttribute("selPlts", selPlts );

    	String envIdParam = environmentId;
    	List<String> envIdNames = Utility.loadSAPGaaProperty(regParam+"_"+selPlts);
    	model.addAttribute("envIdNames", envIdNames );
    	model.addAttribute("envIdParam", envIdParam );

    	String selSysNm = sysNames;
    	List<String> systemNames = Utility.loadSAPGaaProperty(regParam+"_"+selPlts+"_"+envIdParam);
    	model.addAttribute("systemNames", systemNames );
    	model.addAttribute("selSysNm", selSysNm );

    	if("0".equals(regions) || "0".equals(pltNames) || "0".equals(environmentId) || "0".equals(sysNames) ) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region/Platform/Environment/System.");
            return "sapextraction/sapextruseraccesspage";
    	}

    	String templSysParam = regParam+"_"+selPlts+"_"+envIdParam+"_"+selSysNm;
    	log.info("TemplateName: "+templSysParam);

    	List<SAPUserAccessModel> userAccessData = sAPExtrGaaDataService.readSAPGaaUserAccessData(templSysParam);
    	request.getSession().setAttribute("SAP_USER_ACCESSDATA", userAccessData);
    	request.getSession().setAttribute("PLATFORM", selPlts);
    	request.getSession().setAttribute("TEMPLATE", templSysParam);
    	model.addAttribute("SAP_USER_ACCESSDATA", userAccessData);

    	//TODO - Added flag for export
    	model.addAttribute("EXPORT_ALLOWED", "Y");
    	//END flag
    	String msg  = "Status: Total USER-ACCESS Data: "+ ((userAccessData == null || userAccessData.isEmpty() ) ?  "0": userAccessData.size()+"");
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapextruseraccesspage";
    }

    @SuppressWarnings("all")
    @ResponseBody
    @GetMapping("/exportIndividualSystemData")
	public ResponseEntity<InputStreamResource> exportIndividualSystemData(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		String template = (String) request.getSession().getAttribute("TEMPLATE");
		log.info("Export Transfer Control Data for: "+template);
		StringBuilder actions= new StringBuilder();
		actions.append("Export Transfer Control Data for:"+template+"\n");
		actions.append("Checking Export Status\n");
		String[] tmplArr=template.split("_");
		synchronized (tmplArr) {
			List<TrfCntrlSchModel> result = sAPExtrRegionWiseService.getExistingTRForU2RSchedules(tmplArr[0], "E", "T");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
			if(result !=null && result.size() > 0) {
				actions.append("Transfer Control Data EXPORT Already Scheduled for REGION: "+tmplArr[0]+", Cannot Replace Data.\n");
			}else {
				result = sAPExtrRegionWiseService.getExistingTRForU2RSchedules(tmplArr[0], "C", "T");// Region=NA, Type='E=EXPORT', Data='T = TRANSFER'
				if(result == null || result.isEmpty()) {
					actions.append("Transfer Control Data CREATION is Not Scheduled for REGION: "+tmplArr[0]+", Cannot Export Data.\n");
				}else if(result.size() > 0 ) {
					String status=result.get(0).getSchStatus();
					if("C".equalsIgnoreCase(status)) {
						UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
						List<SAPUserAccessModel> userAccessData = (List<SAPUserAccessModel>)request.getSession().getAttribute("SAP_USER_ACCESSDATA");
						actions.append("Total Records to be replaced : "+userAccessData.size()+" \n Clearing records from Table.\n");
						int delRec = sAPExtrRegionWiseService.deleteTrfTransData(tmplArr[0], tmplArr[1], tmplArr[2], tmplArr[3]);
						actions.append("Total records deleted : "+delRec+"\n\n");
						actions.append("Inserting "+userAccessData.size()+" Records\n");
						int insRecords = sAPExtrGaaDataService.insertTransferTransactions(userAccessData, template, curUser.getJnjMsftUsrnmTxt());
						actions.append("Total Records inserted : "+insRecords+"\n" );
						try {
							//Building Summary
							TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
							sumMdl.setRegion(tmplArr[0]);
							sumMdl.setPlatform(tmplArr[1]);
							sumMdl.setEnvironment(tmplArr[2]);
							sumMdl.setSystem(tmplArr[3]);
							sumMdl.setCreatedRecCount(insRecords);
							sumMdl.setCreatedDt(new Date());
							sumMdl.setCreatedBy(curUser.getJnjMsftUsrnmTxt());
							sumMdl.setCollStatus("C");
							actions.append("\nInserting Summary for :"+template+" Total Records:"+insRecords);
							sAPExtrRegionWiseDao.saveTrfDataSummary(sumMdl);
							actions.append("\nSummary save Successfull for :"+template+" Total Records :"+insRecords);
						} catch (Exception e) {
							log.error("Error inserting Summary Data for :"+tmplArr+" Msg:"+e.getMessage(), e);
						}

					}else {
						actions.append("Transfer Control Data CREATION is Scheduled/RUNNING for REGION: "+tmplArr[0]+", PLease wait for completion. Cannot Export Data.\n");
					}
				}
			}
		}
		String fileNm ="ReplaceData_"+template+"_"+Utility.fmtMDY(new Date())+".txt";
		String filePath = sAPExtrGaaDataService.writeLogData(actions, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
	}

    @ResponseBody
    @GetMapping("/downSapUserAccessExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downSapUserAccessExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SAP GAA User Access Excel ");
		String fileNm ="Career_Change_SAP_"+request.getSession().getAttribute("PLATFORM");
		List<SAPUserAccessModel> userAccessData = (List<SAPUserAccessModel>)request.getSession().getAttribute("SAP_USER_ACCESSDATA");
		String filePath = sAPExtrGaaDataService.writeSapGaaUserAccessCSV(userAccessData, fileNm);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }
*/

  }
