package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.JDACrossAppMatrixModel;
import com.jnj.rqc.conflictModel.JDACrsAppRoleMdl;
import com.jnj.rqc.conflictModel.JDADBRiskModel;
import com.jnj.rqc.conflictModel.JDAMenuItemMdl;
import com.jnj.rqc.conflictModel.JDAPersonalSysMdl;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.models.StrKeyValPair;


public interface BelmontRoleConflictsDao {

	public List<MatrixModel> getCurrentRolesConflict(String[] roles, String wwid ) throws SQLException, DataAccessException ;
	public List<MatrixModel> getNewRolesConflict(String sql) throws SQLException, DataAccessException ;
	public List<JDAPersonalSysMdl> getUsersExistingRoles(String empWwid)throws SQLException, DataAccessException;
	public List<JDAPersonalSysMdl> getUsersExistingRoles(List<String>empIds)throws SQLException, DataAccessException;
	public List<SystemCodeModel> getSystemCodes()throws SQLException, DataAccessException;
	public List<JDAPersonalSysMdl> getUsersExistingRolesJDA(String wwid, int system) throws SQLException, DataAccessException;//WebUI
	public List<JDAPersonalSysMdl> getUsersExistingClientRolesJDA(String wwid, int system) throws SQLException, DataAccessException;//ClientSide
	public List<JDAMenuItemMdl> getJDAMenuItem(String role, int system)throws SQLException, DataAccessException ;
	public List<JDAMenuItemMdl> getNewRolesActionJDA(String data, int system)throws SQLException, DataAccessException ;

	public List<JDACrsAppRoleMdl> getCrossAppRoles(String empId) throws SQLException, DataAccessException;

	public List<JDADBRiskModel> loadJDAConflictMatrix()throws SQLException, DataAccessException;
	public List<StrKeyValPair> loadJDATechRoleMappings()throws SQLException, DataAccessException;
	public List<JDACrossAppMatrixModel> loadJDACrossAppConflicts()throws SQLException, DataAccessException;

}
