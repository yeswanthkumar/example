package com.jnj.rqc.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RQCTktData implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	int tktNo;
	 String wwid;
	 String evtDesc;
}
