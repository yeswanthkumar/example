package com.jnj.rqc.models;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserTerminationReportModel {
	String srcSys;
	String userId;
	String wwid;
	String firstName;
	String lastName;
	int totalDups;
	int uniqueRec;
	String status;
	String comments;
	String acHasIssue;
	Date dtUpdated;
	String recFromApp;
	String usrNmInSrcSys;

	@Override
	public String toString() {
		return "UserTerminationReportModel [srcSys=" + srcSys + ", userId=" + userId + ", wwid=" + wwid + ", firstName="
				+ firstName + ", lastName=" + lastName + ", totalDups=" + totalDups + ", uniqueRec=" + uniqueRec
				+ ", status=" + status +", acHasIssue=" +acHasIssue + ", comments=" + comments + ", dtUpdated=" + dtUpdated + ", usrNmInSrcSys= "+usrNmInSrcSys+"]";
	}


	public String getData() {
		//return  srcSys+"~"+userId+"~"+ wwid+"~"+firstName+", "+lastName+"~"+totalDups+"~"+uniqueRec+"~"+status+"~"+acHasIssue+"~"+comments;
		//return  srcSys+"~"+userId+"~"+ wwid+"~"+firstName+", "+lastName+"~"+totalDups+"~"+status+"~"+acHasIssue+"~"+recFromApp+"~"+comments;
		return  srcSys+"~"+userId+"~"+ wwid+"~"+firstName+", "+lastName+"~"+totalDups+"~"+status+"~"+recFromApp+"~"+usrNmInSrcSys+"~"+comments;
	}






}
