package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.MatrixModel;
import com.jnj.rqc.conflictModel.PersonalSysModel;
import com.jnj.rqc.dao.RoleConflictsDao;
import com.jnj.rqc.reportservice.RolesConflictPDFReportService;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.util.Utility;

/**
 * File    : <b>RqcSapConflictServiceImpl.java</b>
 * @author : DChauras @Created : Jan 9, 2020 5:18:29 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class RqcSapConflictServiceImpl implements RqcSapConflictService {
	static final Logger log = LoggerFactory.getLogger(RqcSapConflictServiceImpl.class);

	@Autowired
	RoleConflictsDao roleConflictsDao;

	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	RolesConflictPDFReportService rolesConflictPDFReportService;

	@SuppressWarnings("all")
	@Override
	public List<MatrixModel> getCurConflictDetails(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> existingRoleConflicts = new ArrayList<>();
		try{
				existingRoleConflicts =  roleConflictsDao.getCurrentRolesConflict(data, empWwid);
				if(existingRoleConflicts != null && !existingRoleConflicts.isEmpty()) {
					for(MatrixModel mtr: existingRoleConflicts) {
						mtr.setWwid(empWwid);
					}
				}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}
		return existingRoleConflicts;
	}

	@Override
	@SuppressWarnings("all")
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> newRoleConflicts = new ArrayList<>();
		try{
				if(data.length >1) {
					String sql = buildQuery(data);
					newRoleConflicts =  roleConflictsDao.getNewRolesConflict(sql);
					if(newRoleConflicts != null && !newRoleConflicts.isEmpty()) {
						for(MatrixModel mtr: newRoleConflicts) {
							mtr.setWwid(empWwid);
						}
					}
				}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		return newRoleConflicts;
	}

	@Override
	public List<MatrixModel> getNewConflictDetails(String empWwid, String[] data, String[] data2){
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> newRoleConflicts = new ArrayList<>();
		try{
				//if(data.length >1) {
					String sql = buildQuery(data, data2);
					newRoleConflicts =  roleConflictsDao.getNewRolesConflict(sql);
					if(newRoleConflicts != null && !newRoleConflicts.isEmpty()) {
						for(MatrixModel mtr: newRoleConflicts) {
							mtr.setWwid(empWwid);
						}
					}
				//}
		} catch (Exception e) {
			log.error("Error: "+e.getMessage(),e);
		}

		return newRoleConflicts;
	}


	private String buildQuery(String[] data) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_EXTR.CONFLICT_MATRIX");
		sql.append(" WHERE (");
		for (int i = 0; i < data.length; i++) {
			for (int j = i+1; j < data.length; j++) {
				sql.append(" ( ROLE1 = "+data[i] +" AND ROLE2 = "+data[j]+") OR (ROLE2 = "+data[i] +" AND ROLE1 = "+data[j]+") ");
				if(i < (data.length -2)) {
					sql.append(" OR ");
				}
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, ROLE1, ROLE2 ");

		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}

	private String buildQuery(String[] data, String[] data2) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ROLE1, ROLE2, APP1, APP2, CONFLICT, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_EXTR.CONFLICT_MATRIX");
		sql.append(" WHERE (");
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data2.length; j++) {
				sql.append(" ( ROLE1 = "+data[i] +" AND ROLE2 = "+data2[j]+") OR (ROLE2 = "+data[i] +" AND ROLE1 = "+data2[j]+") ");
				if(j < (data2.length -1)) {
					sql.append(" OR ");
				}
			}

			if(i < (data.length -1)) {
				sql.append(" OR ");
			}
		}
		sql.append(" )");
		sql.append(" ORDER BY APP1, APP2, ROLE1, ROLE2 ");

		log.info("QUERY===========\n"+sql.toString());
		return sql.toString();
	}



	@Override
	@SuppressWarnings("all")
	public List<PersonalSysModel> getUserExistingRoles(String empWwid){
		List<PersonalSysModel> result = new ArrayList<>();
		try{
			result = roleConflictsDao.getUsersExistingRoles(empWwid);
		} catch (Exception e) {
			log.error("Error getting User Roles: "+e.getMessage(),e);

		}
		return result;
	}


	@Override
	public String[] getRoleIdsPersonalSys(List<PersonalSysModel> psList) {
		String[] ids = new String[psList.size()];
		int i=0;
		for(PersonalSysModel ps:psList) {
			ids[i] = ps.getCode()+"";
			i++;
		}
		return ids;
	}

	@Override
	public List<MatrixModel> getUserLevelConflictingRoles(String empWwid, String[] data) {
		log.info("Emp ID Recd:"+empWwid +"  Data size: "+data.length);
		List<MatrixModel> newRoleConflicts = new ArrayList<>();
		try{
				if(data.length >1) {
					String sql = buildQuery(data);
					newRoleConflicts =  roleConflictsDao.getNewRolesConflict(sql);
					if(newRoleConflicts != null && !newRoleConflicts.isEmpty()) {
						for(MatrixModel mtr: newRoleConflicts) {
							mtr.setWwid(empWwid);
						}
					}
				}
		} catch (Exception e) {
			log.error("Error getting user conflicts: "+e.getMessage(),e);
		}

		return newRoleConflicts;
	}

	@Override
	public Map<String, SystemCodeModel> getSystemCodes() {
		Map<String, SystemCodeModel> sysMap = new HashMap<>();
		List<SystemCodeModel> sysCodeLst = new ArrayList<>();
		try{
			sysCodeLst = roleConflictsDao.getSystemCodes();
			if(sysCodeLst != null && !sysCodeLst.isEmpty()) {
				sysCodeLst.forEach(item ->{
					sysMap.put(item.getAccessRole().toUpperCase(), item);
				});
			}
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}

		return sysMap;
	}

	@Override
	public List<MatrixModel> getConflictMatrix() {
		List<MatrixModel> matrixMdl = new ArrayList<>();

		try{
			matrixMdl = roleConflictsDao.getConflictMatrix();
		} catch (Exception e) {
			log.error("Error loading SYSTEM_CODE: "+e.getMessage(),e);
		}
		return matrixMdl;
	}



	@Override
	public Map<String, List<String>> getSystemCodes(String data) {
		Map<String, List<String>> sysCdMap = getCodes(data.split(","));
		return sysCdMap;
	}

	@Override
	public Map<String, List<String>> getSystemCodes(String[] data) {
		Map<String, List<String>> sysCdMap = getCodes(data);
		return sysCdMap;
	}


	private Map<String, List<String>> getCodes(String[] data) {
		Map<String, List<String>> sysCdMap = new HashMap<>();
		List<String> sodLst = new ArrayList<>();
		List<String> invldRoles = new ArrayList<>();
		for(String rlName : data) {
			String sodCd = Utility.getSystemCode(rlName.trim().toUpperCase());
			if(sodCd==null) {
				invldRoles.add(rlName);
			}else {
				sodLst.add(sodCd);
			}
		}
		sysCdMap.put("SYSCDLST", sodLst);
		sysCdMap.put("INVLDLST", invldRoles);
		return sysCdMap;
	}



	@Override
	public String writeConfCSVReport(String fileNm, List<MatrixModel> roleConflictList) {
		String filePath = csvReportWriter.writeConfCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", roleConflictList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeUserRoleCSVReport(String fileNm, List<PersonalSysModel> userRoles) {
		String filePath = csvReportWriter.writeUserRolesCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", userRoles);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeUserRolePDFReport(String fileNm, List<PersonalSysModel> userRoles) {
		return rolesConflictPDFReportService.writeUserRolesReport(fileNm, userRoles);
	}

	@Override
	public String writeConfPDFReport(String title, String fileNm, List<MatrixModel> roleConflictList) {
		return rolesConflictPDFReportService.writeUserConflictsReport(title, fileNm, roleConflictList);
	}

	@Override
	public String writeSystemCodeCSVReport(String fileNm, List<SystemCodeModel> sysCdLst) {
		String filePath = csvReportWriter.writeSystemCdCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", sysCdLst);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeConflictMatrixCSVReport(String fileNm, List<MatrixModel> matrixList) {
		String filePath = csvReportWriter.writeConflictMatrixCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", matrixList);
		log.info("CSV File Path: "+filePath);
		return filePath;
	}


	@Override
	public Map<String, List<PersonalSysModel>> getMultiUserExistingRoles(List<String> empIds) {
		Map<String, List<PersonalSysModel>> outMap = new HashMap<>();
		try{
			List<PersonalSysModel> dataList = roleConflictsDao.getUsersExistingRoles(empIds);
			for(PersonalSysModel pmodel:dataList) {
				//String usrKey = pmodel.getUserId()+"_"+pmodel.getWwid();
				String usrKey = ""+pmodel.getWwid();
				if(outMap.containsKey(usrKey)) {
					List<PersonalSysModel> usrLst = outMap.get(usrKey);
					usrLst.add(pmodel);
					outMap.put(usrKey, usrLst);
				}else {
					List<PersonalSysModel> usrLst = new ArrayList<>();
					usrLst.add(pmodel);
					outMap.put(usrKey, usrLst);
				}
			}
		} catch (Exception e) {
			log.error("Error getting User Roles: "+e.getMessage(),e);
		}
		return outMap;
	}


	@Override
	public String writeMultiUserRolePDFCSVReport(String type, String fileNm, Map<String, List<PersonalSysModel>> userRoles) {
		List<PersonalSysModel> allData = new ArrayList<>();
		for(List<PersonalSysModel> lst : userRoles.values()) {
			allData.addAll(lst);
		}
		String filePath = "";

		if("CSV".equals(type)) {
			filePath = csvReportWriter.writeUserRolesCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", allData);
		}else {
			filePath = writeUserRolePDFReport(fileNm+"_"+Utility.fmtMDY(new Date())+".pdf", allData);
		}

		log.info("File Path: "+filePath);
		return filePath;
	}


	@Override
	public String writeMultiConfPDFCSVReport(String type, String fileNm, Map<String, List<MatrixModel>> userConflicts) {
		List<MatrixModel> allData = new ArrayList<>();
		for(List<MatrixModel> lst : userConflicts.values()) {
			allData.addAll(lst);
		}
		String filePath = "";
		if("CSV".equals(type)) {
			filePath = csvReportWriter.writeConfCSVReport(fileNm+"_"+Utility.fmtMDY(new Date())+".csv", allData);
		}else {
			filePath = writeConfPDFReport("User level SOD Conflicts between Application Role(s)", fileNm+"_"+Utility.fmtMDY(new Date())+".pdf", allData);
		}
		log.info("File Path: "+filePath);
		return filePath;
	}








}
