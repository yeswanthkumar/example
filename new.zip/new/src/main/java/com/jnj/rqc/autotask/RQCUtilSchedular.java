package com.jnj.rqc.autotask;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.jnj.rqc.common.models.SystemCodeModel;
import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.controllers.AnaplanDataHandler;
import com.jnj.rqc.controllers.CSMDataController;
import com.jnj.rqc.controllers.ExchangeDataController;
import com.jnj.rqc.controllers.SAPExtractionOneClickController;
import com.jnj.rqc.edal.handlers.DataSubmissionService;
import com.jnj.rqc.models.GrpUsrDateMdl;
import com.jnj.rqc.sch.SchAdminModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.service.RqcSapConflictService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.UserIdentityService;
import com.jnj.rqc.service.UserRoleActivityService;
import com.jnj.rqc.sodrefresh.controller.SodRefreshController;
import com.jnj.rqc.userabs.dao.SAPUserDao;
import com.jnj.rqc.userabs.iamgrcservice.IamGrcRequestSumbissionService;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.useridentity.models.EmailItem;
import com.jnj.rqc.util.Utility;



@Service
@EnableScheduling
public class RQCUtilSchedular {
	static final Logger log = LoggerFactory.getLogger(RQCUtilSchedular.class);
	public static String envName = Utility.getServerProp("ENVIRONMENT");
	private final Map<String, String> lastExecutionTimes = new HashMap<>();
    private final Map<String, String> fixedDelays = new HashMap<>();

	@Autowired
	UserRoleActivityService userRoleActivityService;
	@Autowired
	SAPExtractionOneClickController sAPExtractionOneClickController;
	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	private RqcSapConflictService RqcSapConflictService;
	@Autowired
	SodRefreshController sodRefreshController;
	@Autowired
	UserIdentityService userIdentityService;
	@Autowired
	ExchangeDataController exchangeDataController;
	@Autowired
	CSMDataController cSMDataController;
	@Autowired
    IamGrcRequestSumbissionService iamGrcRequestSumbissionService;
    @Autowired
    DataSubmissionService dataSubmissionService;
	@Autowired
    AnaplanDataHandler anaplanDataHandler;
    @Autowired
    UserAccessDataService userAccessDataService;
    
	@Autowired
	private SAPUserDao sAPUserDao;
	/**
	 * Method  : PVCSUserDetails.java.runMessage()
	 *		   :<b></b>
	 * @author : DChauras  @Created :Apr 15, 2019 10:24:32 AM
	 * Purpose : CRON executes 12 Hours Minutes
	 * @return : void
	 */
	@Scheduled(fixedDelay=43200000)
    public void runMessage()
    {
        log.info("<<<<<<<<<<  Starting Process GET DB Data("+envName+"):"+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        long start = System.currentTimeMillis();
        Map<String, SystemCodeModel>  systemCodeMap = RqcSapConflictService.getSystemCodes();
        Utility.setSYSTEMCODEMAP(systemCodeMap);
        //Utility.clearUserActCache();
       //start.userRoleActivityService.clearUserActCache();
       //userRoleActivityService.getUserData();
        //String email = Utility.getPlatformEmailAddress("JDE PLATFORMS DSI BWI");

        //TODO : LOAD ALL IDE REfrence Data
        //UserIdentityService.loadAllReferenceData();
        log.info("<<<<<<<<<<  END GET DB Data("+envName+") total time taken : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
    }



	/**
	 * Method  : PVCSUserDetails.java.dMessage()
	 *		   :<b></b>
	 * @author : DChauras  @Created :Apr 15, 2019 10:23:59 AM
	 * Purpose : CRON job, executes every day at 06:01:01 AM
	 * @return : void
	 */
	/*@Scheduled(cron="1 1 6 * * *")
	public void dMessage()
	{
		log.info("<<<<<<<<<<  Starting Process PVCSUserExtract @ "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
	}*/


	/**
	 * Method  : RQCUtilSchedular.java.trfCntrlRegionWiseScheduler()
	 *		   :<b></b>
	 * @author : DChauras  @Created :Aug 3, 2021 3:32:39 PM
	 * Purpose : Cron Job to clear User Data Cache every 4 hours
	 * @return : void
	 */
	@Scheduled(fixedDelay=14400000)
    public void clearUserDataCache() {
		log.info("STARTING - "+envName+" Clearing Server User Cache");
		Utility.clearUserData();//Clearing User Cache
		//TODO :Clear Existing Access Cache
		Utility.clearUserAccessData();
		log.info("COMPLETED - "+envName+" Clearing Server User Cache");
    }





	/**
	 * Method  : PVCSUserDetails.java.displayMessage()
	 *		   :<b></b>
	 * @author : DChauras  @Created :Apr 15, 2019 10:25:14 AM
	 * Purpose : CRON job executes at midnight
	 * @return : void
	 */
	/*@Scheduled(cron="0 0 0 * * ?")
	public void displayMessage()
	{
		log.info("<<<<<<<<<<  Display Date  >>>>>>>>>>:"+Utility.fmtMMDDYYYY(new Date()));
	}*/


	@Scheduled(cron = "0 01 09 * * FRI")
	public void sendTransferControlWeeklyReport()//Scheduling - still under discussion
	{
		log.info("<<<<<<<<<<<<<<<  START PROCESS TRANSFER DATA REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		List<String> emlTrfList = Utility.loadOneClickProperty("TRIGGER_WEEKLY_EMAIL");
		if(!(emlTrfList != null && !emlTrfList.isEmpty() && (emlTrfList.get(0).equals("Y")))) {
			log.info(" CURRENT SERVER ("+envName+")  CANNOT SEND TRANSFER CONTROL REPORT WEEKLY EMAIL, Please check property 'TRIGGER_WEEKLY_EMAIL'");
		}else {
			sAPExtractionOneClickController.processGenesisTransferReport();
		}
		log.info("<<<<<<<<<<<<<<<  END PROCESS TRANSFER DATA REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");


		log.info("<<<<<<<<<<<<<<<  START PROCESS USER TO ROLE DATA REPORT ("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		List<String> emlU2RList = Utility.loadOneClickPropertyU2R("TRIGGER_WEEKLY_EMAIL");
		if(!(emlU2RList != null && !emlU2RList.isEmpty() && (emlU2RList.get(0).equals("Y")))) {
			log.info(" CURRENT SERVER ("+envName+") CANNOT SEND USER TO ROLE REPORT WEEKLY EMAIL, Please check property 'TRIGGER_WEEKLY_EMAIL'");
		}else {
			sAPExtractionOneClickController.processGenesisUser2RoleReport("SCHEDULER", "0");
		}
		log.info("<<<<<<<<<<<<<<<  END PROCESS USER TO ROLE DATA REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");

		//sAPExtractionOneClickController.processGenesisUser2RoleDeltaReport(); //DELTA REPORT

	}

	@Scheduled(cron = "0 01 09 * * WED")
	public void sendTransferControlWeeklyReportWed()//Scheduling - still under discussion
	{
		log.info("<<<<<<<<<<<<<<<  START PROCESS USER TO ROLE DATA REPORT ("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		List<String> emlU2RList = Utility.loadOneClickPropertyU2R("TRIGGER_WEEKLY_EMAIL");
		if(!(emlU2RList != null && !emlU2RList.isEmpty() && (emlU2RList.get(0).equals("Y")))) {
			log.info(" CURRENT SERVER ("+envName+") CANNOT SEND USER TO ROLE REPORT WEEKLY EMAIL, Please check property 'TRIGGER_WEEKLY_EMAIL'");
		}else {
			sAPExtractionOneClickController.processGenesisUser2RoleReport("SCHEDULER", "0");
		}
		log.info("<<<<<<<<<<<<<<<  END PROCESS USER TO ROLE DATA REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");

		//sAPExtractionOneClickController.processGenesisUser2RoleDeltaReport(); //DELTA REPORT

	}

	@Scheduled(cron = "0 1 9 * * MON")
	public void sendUserToSodWeeklyReport()//Scheduling - still under discussion
	{
		log.info("<<<<<<<<<<<<<<<  START PROCESS USER TO SOD WEEKLY DATA REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		List<String> emlTrfList = Utility.loadOneClickProperty("TRIGGER_WEEKLY_EMAIL");
		if(!(emlTrfList != null && !emlTrfList.isEmpty() && (emlTrfList.get(0).equals("Y")))) {
			log.info(" CURRENT SERVER ("+envName+")  CANNOT SEND USER TO SOD WEEKLY EMAIL, Please check property 'TRIGGER_WEEKLY_EMAIL'");
		}else {
			sAPExtractionOneClickController.processGenesisUserToSodReport();
		}
		log.info("<<<<<<<<<<<<<<<  END PROCESS USER TO SOD WEEKLY REPORT("+envName+") @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
	}


	/**
	 * Method  : RQCUtilSchedular.java.processTrfCntrlRegionWise()
	 *		   :<b></b>
	 * @author : DChauras  @Created :May 10, 2021 10:53:50 AM
	 * Purpose : Method trfCntrlRegionWiseScheduler : Scheduler to check and process any scheduled job for Transfer Control - Data Creation (every 10 Min).
	 * @return : void
	 */
	@Scheduled(fixedDelay=600000)
    public void trfCntrlRegionWiseScheduler()
    {
        try{	/*Create Data*/
        		//CREATE/EXPORT FLAG
        		List<String> createExportList = Utility.loadOneClickProperty("CREATE_OR_EXPORT_DATA");
        		if(!(createExportList != null && !createExportList.isEmpty() && (createExportList.get(0).equals("Y")))) {
        			log.info(" CURRENT SERVER("+envName+") CANNOT SCHEDULE TRANSFER CONTROL CREATE/EXPORT, Please check property 'CREATE_OR_EXPORT_DATA'");
        			return;
        		}

        		log.info("<<<<<<<<<<  Starting Transfer Control Process on ("+envName+")Server: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        		List<SchAdminModel> schAdmList = sAPExtrRegionWiseService.getAllActiveSchedulers();
        		if(schAdmList == null || schAdmList.isEmpty()) {
        			log.info("****** (TRANSFER CONTROL - CREATE) No Active REGION to Schedule Processing: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info("("+envName+") SCHEDULER going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        		}else{
        			for(SchAdminModel schAdmMdl: schAdmList) {
        				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
        					/*START DATA CREATION*/
        					TrfCntrlSchModel activeSchedule = null;
        					log.info("****** (TRANSFER CONTROL - CREATE)  CHECK SUCCESSFUL FOR REGION : "+schAdmMdl.getRegion()+" ******");
        					synchronized (this) {
        						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentTrfSchedule(schAdmMdl.getRegion(), "S", "C");//Type C=Create/E=Export
        						if(currSchedule != null && !currSchedule.isEmpty() ) {
        							activeSchedule = currSchedule.get(0);
        							int recUpd = sAPExtrRegionWiseService.updateTrnferSchStatus(activeSchedule, "I", "C");
        							if(recUpd > 0) {
        								activeSchedule.setSchStatus("I");
        								log.info("("+envName+") TRANSFER CONTROL Schedule CREATE ("+activeSchedule.getRegion()+") Status updated to ==> IN-PROGRESS");
        							}
        						}
							}
        					if(activeSchedule != null) {
        						Date start = new Date();
        						log.info("****** STARTED "+envName+" Processing (CREATE) TRANSFER CONTROL DATA for REGION: "+schAdmMdl.getRegion()+"******");
        						List<SAPTrfCntrlSummaryMdl> summary =  sAPExtractionOneClickController.processSchTrfCntrlRegionWise(activeSchedule);
        						synchronized (this) {
        							int recUpd = sAPExtrRegionWiseService.updateTrnferSchStatus(activeSchedule, "C", "C");
        							log.info("CREATE - Scheduler status updated to Complete:"+recUpd);
        							//Email User
        							sAPExtrRegionWiseService.sendProcessEmail(activeSchedule, summary, "C", "T");
        						}
        						int totlaRecords=0;
        						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
        				    		totlaRecords = totlaRecords+sumMdl.getCount();
        				    	}
        						log.info("Total Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
        					}else {
        						log.info("****** ("+envName+") NO TRANSFER CONTROL Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
        					}
        				}else{
        					log.info("<<< NO ACTIVE Scheduler for ("+envName+") TRANSFER CONTROL Region : "+schAdmMdl.getRegion()+" >>>");
        				}
        			}
        		}
        		/*END DATA CREATION*/

       /************************************************/

        		/*START DATA EXPORT*/

        		if(schAdmList == null || schAdmList.isEmpty()) {
        			log.info("****** ("+envName+" TRANSFER CONTROL - EXPORT) No Active REGION to Schedule Processing: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info("SCHEDULER "+envName+" going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        		}else{
        			for(SchAdminModel schAdmMdl: schAdmList) {
        				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
        					TrfCntrlSchModel activeSchedule = null;
        					log.info("****** ("+envName+" TRANSFER CONTROL - EXPORT)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
        					synchronized (this) {
        						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentTrfSchedule(schAdmMdl.getRegion(), "S", "E");//Type E=Export/C=Create
        						if(currSchedule != null && !currSchedule.isEmpty() ) {
        							activeSchedule = currSchedule.get(0);
        							int recUpd = sAPExtrRegionWiseService.updateTrnferSchStatus(activeSchedule, "I", "E");
        							if(recUpd > 0) {
        								log.info(envName+ " TRANSFER CONTROL Schedule EXPORT ("+activeSchedule.getRegion()+") Status updated to : IN-PROGRESS");
        							}
        						}
							}
        					if(activeSchedule != null) {
        						Date start = new Date();
        						log.info("****** "+envName+" STARTED Processing (EXPORT) TRANSFER CONTROL DATA for REGION: "+schAdmMdl.getRegion()+"******");
        						List<SAPTrfCntrlSummaryMdl> summary =  sAPExtractionOneClickController.processExportTrfCntrlRegionWise(activeSchedule);
        						synchronized (this) {
        							int recUpd = sAPExtrRegionWiseService.updateTrnferSchStatus(activeSchedule, "C", "E");
        							log.info("EXPORT - Scheduler status updated to Complete: "+recUpd);
        							//Email User
        							sAPExtrRegionWiseService.sendProcessEmail(activeSchedule, summary, "E", "T");
        						}
        						int totlaRecords=0;
        						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
        				    		totlaRecords = totlaRecords+sumMdl.getCount();
        				    	}
        						log.info("Total Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
        					}else {
        						log.info("****** "+envName+" NO TRANSFER CONTROL Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
        					}
        				}else{
        					log.info("<<< "+envName+" NO ACTIVE Scheduler for TRANSFER CONTROL Region : "+schAdmMdl.getRegion()+" >>>");
        				}
        			}
        		}
        		/*END DATA EXPORT*/
        } catch (Exception e){
			log.error("Exception in trfCntrlRegionWiseScheduler ("+envName+"):" + e.getMessage(), e);
		}
    }


    /******   USER TO ROLE SCHEDULER - SAP ******/
    @SuppressWarnings("all")
    @Scheduled(fixedDelay=600000)
    public void userToRoleRegionWiseScheduler()
    {
        try{/*Create Data - User to Role */
        	//CREATE/EXPORT FLAG
    		List<String> createExportList = Utility.loadOneClickPropertyU2R("CREATE_OR_EXPORT_DATA");
    		if(!(createExportList != null && !createExportList.isEmpty() && (createExportList.get(0).equals("Y")))) {
    			log.info(" CURRENT SERVER "+envName+" CANNOT SCHEDULE USER TO ROLE CREATE/EXPORT, Please check property 'CREATE_OR_EXPORT_DATA'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting USER TO ROLE Process on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	List<SchAdminModel> schAdmList = sAPExtrRegionWiseService.getAllActiveSchedulers();
    		if(schAdmList != null && !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					/*START DATA CREATION USER TO ROLE*/
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** ("+envName+" USER TO ROLE - CREATE)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2RoleSchedule(schAdmMdl.getRegion(), "S", "C");//Type C=Create/E=Export
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2RoleSchStatus(activeSchedule, "I", "C");
    							if(recUpd > 0) {
    								log.info(envName+ " USER TO ROLE Schedule CREATE ("+activeSchedule.getRegion()+") Status updated to ==> IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** "+envName+" STARTED Processing (CREATE) USER TO ROLE DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processSchUser2RoleRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2RoleSchStatus(activeSchedule, "C", "C");
    							log.info(""+envName+" USER TO ROLE CREATE - Scheduler status updated to Complete");
    							//Email User
    							//sAPExtrRegionWiseService.sendUser2RoleEmail(activeSchedule, summary, "C", "U");
    							sAPExtrRegionWiseService.sendUser2RoleCompleteDataEmail(activeSchedule, summary, "C", "U");

    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO ROLE Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("****** "+envName+" NO USER TO ROLE Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< "+envName+" NO ACTIVE Scheduler for USER TO ROLE Region : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ("+envName+" USER TO ROLE - CREATE) No Active REGION to Schedule Processing: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info("("+envName+") USER TO ROLE Scheduler going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        	}
        		/*END DATA CREATION*/

       /*******EXPORT***********/

        	/*START DATA EXPORT*/

    		if(schAdmList != null || !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** ("+envName+" USER TO ROLE - EXPORT)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2RoleSchedule(schAdmMdl.getRegion(), "S", "E");//Type E=Export/C=Create
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2RoleSchStatus(activeSchedule, "I", "E");
    							if(recUpd > 0) {
    								log.info(envName+" USER TO ROLE Schedule EXPORT ("+activeSchedule.getRegion()+") Status updated to : IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** "+envName+" STARTED Processing (EXPORT) USER TO ROLE DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processExportUser2RoleRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2RoleSchStatus(activeSchedule, "C", "E");
    							log.info(envName+" USER TO ROLE EXPORT - Scheduler status updated to Complete");
    							//Email User
    							sAPExtrRegionWiseService.sendUser2RoleEmail(activeSchedule, summary, "E", "U");
    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO ROLE Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("****** "+envName+" NO  USER TO ROLE  Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< NO ACTIVE Scheduler for  USER TO ROLE  Region("+envName+") : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ( USER TO ROLE - EXPORT) No Active REGION to Schedule Processing ("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info(" ("+envName+")USER TO ROLE Scheduler going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        	}
        	/*END DATA EXPORT*/
        } catch (Exception e){
			log.error("Exception in userToRoleRegionWiseScheduler("+envName+"):" + e.getMessage(), e);
		}
    }


    /******   USER TO CRITICAL ROLE SCHEDULER  ******/

    @SuppressWarnings("all")
    @Scheduled(fixedDelay=900000)
    public void userToCriticalRoleRegionWiseScheduler()
    {
        try{/*Create Data - User to Critical Role */
        	//CREATE/EXPORT FLAG
    		List<String> createExportList = Utility.loadOneClickPropertyU2R("CREATE_OR_EXPORT_DATA");
    		if(!(createExportList != null && !createExportList.isEmpty() && (createExportList.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+")SERVER CANNOT SCHEDULE USER TO CRITICAL ROLE CREATE/EXPORT, Please check property 'CREATE_OR_EXPORT_DATA'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting USER TO CRITICAL ROLE Process on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	List<SchAdminModel> schAdmList = sAPExtrRegionWiseService.getAllActiveSchedulers();
    		if(schAdmList != null && !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					/*START DATA CREATION USER TO ROLE*/
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** (USER TO CRITICAL ROLE - CREATE)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2CriticalRoleSchedule(schAdmMdl.getRegion(), "S", "C");//Type C=Create/E=Export
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2CriticalRoleSchStatus(activeSchedule, "I", "C");
    							if(recUpd > 0) {
    								log.info("USER TO CRITICAL ROLE Schedule CREATE ("+activeSchedule.getRegion()+") Status updated to ==> IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** STARTED Processing (CREATE) USER TO CRITICAL ROLE DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processSchUser2CriticalRoleRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2CriticalRoleSchStatus(activeSchedule, "C", "C");
    							log.info("USER TO CRITICAL ROLE CREATE - Scheduler status updated to Complete");
    							//Email User
    							sAPExtrRegionWiseService.sendUser2CriticalRoleEmail(activeSchedule, summary, "C");
    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO CRITICAL ROLE Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("****** "+envName+" NO USER TO CRITICAL ROLE Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< ("+envName+") NO ACTIVE Scheduler for USER TO CRITICAL ROLE Region : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ("+envName+" USER TO CRITCAL ROLE - CREATE) No Active REGION to Schedule Processing: "+envName+" - "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info("("+envName+") USER TO CRITICAL ROLE Scheduler going to SLEEP ... Will check back in 10 Minutes..zzzzzzzzzz\n");
        	}
        		/*END DATA CREATION*/

       /*******EXPORT***********/

        	/*START DATA EXPORT*/

    		if(schAdmList != null || !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** (USER TO CRITICAL ROLE - EXPORT)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2CriticalRoleSchedule(schAdmMdl.getRegion(), "S", "E");//Type E=Export/C=Create
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2CriticalRoleSchStatus(activeSchedule, "I", "E");
    							if(recUpd > 0) {
    								log.info("USER TO CRITCAL ROLE Schedule EXPORT ("+activeSchedule.getRegion()+") Status updated to : IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** STARTED Processing (EXPORT) USER TO CRITCAL ROLE DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processExportUser2CriticalRoleRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2CriticalRoleSchStatus(activeSchedule, "C", "E");
    							log.info("USER TO CRITICAL ROLE EXPORT - Scheduler status updated to Complete");
    							//Email User
    							sAPExtrRegionWiseService.sendUser2CriticalRoleEmail(activeSchedule, summary, "E");
    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO CRITICAL ROLE Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("******("+envName+")NO  USER TO CRITICAL ROLE  Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< NO ACTIVE Scheduler for  USER TO CRITICAL ROLE  Region : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ( ( "+envName+" USER TO CRITICAL ROLE - EXPORT) No Active REGION to Schedule Processing: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info(" ("+envName+") USER TO CRITICAL ROLE Scheduler going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        	}
        	/*END DATA EXPORT*/
        } catch (Exception e){
			log.error("Exception in userToCriticalRoleRegionWiseScheduler("+envName+"):" + e.getMessage(), e);
		}
    }


    /******   USER TO SOD SCHEDULER  ******/

    @SuppressWarnings("all")
    @Scheduled(fixedDelay=900000)
    public void userToSodRegionWiseScheduler()
    {
        try{/*Create Data - User to Sod */
        	//CREATE/EXPORT FLAG
    		List<String> createExportList = Utility.loadOneClickPropertyU2R("CREATE_OR_EXPORT_DATA");
    		if(!(createExportList != null && !createExportList.isEmpty() && (createExportList.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT SCHEDULE USER TO SOD CREATE/EXPORT, Please check property 'CREATE_OR_EXPORT_DATA'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting USER TO SOD Process on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	List<SchAdminModel> schAdmList = sAPExtrRegionWiseService.getAllActiveSchedulers();
    		if(schAdmList != null && !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					/*START DATA CREATION USER TO SOD*/
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** (USER TO SOD - CREATE)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2SodSchedule(schAdmMdl.getRegion(), "S", "C");//Type C=Create/E=Export
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2SodSchStatus(activeSchedule, "I", "C");
    							if(recUpd > 0) {
    								log.info("USER TO SOD Schedule CREATE ("+activeSchedule.getRegion()+") Status updated to ==> IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** STARTED Processing (CREATE) USER TO SOD DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processSchUser2SodRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2SodSchStatus(activeSchedule, "C", "C");
    							log.info("USER TO SOD CREATE - Scheduler status updated to Complete");
    							//Email User
    							sAPExtrRegionWiseService.sendUser2SodEmail(activeSchedule, summary, "C");
    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO SOD Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("****** "+envName+" NO USER TO SOD Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< ("+envName+") NO ACTIVE Scheduler for USER TO SOD Region : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ("+envName+" USER TO SOD - CREATE) No Active REGION to Schedule Processing: "+envName+" - "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info("("+envName+") USER TO SOD Scheduler going to SLEEP ... Will check back in 10 Minutes..zzzzzzzzzz\n");
        	}
        		/*END DATA CREATION*/

       /*******EXPORT***********/

        	/*START DATA EXPORT*/

    		if(schAdmList != null || !schAdmList.isEmpty()) {
    			for(SchAdminModel schAdmMdl: schAdmList) {
    				if(schAdmMdl.getRunSch() == 1) {//Check if Scheduler Enabled Run_Sch=1
    					TrfCntrlSchModel activeSchedule = null;
    					log.info("****** (USER TO SOD - EXPORT)  CHECK REGION : "+schAdmMdl.getRegion()+" ******");
    					synchronized (this) {
    						List<TrfCntrlSchModel> currSchedule  = sAPExtrRegionWiseService.getCurrentUser2SodSchedule(schAdmMdl.getRegion(), "S", "E");//Type E=Export/C=Create
    						if(currSchedule != null && !currSchedule.isEmpty() ) {
    							activeSchedule = currSchedule.get(0);
    							int recUpd = sAPExtrRegionWiseService.updateUser2SodSchStatus(activeSchedule, "I", "E");
    							if(recUpd > 0) {
    								log.info("USER TO SOD Schedule EXPORT ("+activeSchedule.getRegion()+") Status updated to : IN-PROGRESS");
    							}
    						}
						}
    					if(activeSchedule != null) {
    						Date start = new Date();
    						log.info("****** STARTED Processing (EXPORT) USER TO SOD DATA for REGION: "+schAdmMdl.getRegion()+"******");
    						List<SAPTrfCntrlSummaryMdl> summary = sAPExtractionOneClickController.processExportUser2SodRegionWise(activeSchedule);
    						synchronized (this) {
    							int recUpd = sAPExtrRegionWiseService.updateUser2SodSchStatus(activeSchedule, "C", "E");
    							log.info("USER TO SOD EXPORT - Scheduler status updated to Complete");
    							//Email User
    							sAPExtrRegionWiseService.sendUser2SodEmail(activeSchedule, summary, "E");
    						}
    						int totlaRecords=0;
    						for(SAPTrfCntrlSummaryMdl sumMdl:summary) {
    				    		totlaRecords = totlaRecords+sumMdl.getCount();
    				    	}
    						log.info("Total USER TO SOD Records processed for Region("+activeSchedule.getRegion()+") :"+totlaRecords+" Total time: "+((System.currentTimeMillis() - start.getTime())/1000)+" Seconds");
    					}else {
    						log.info("******("+envName+")NO  USER TO SOD  Data scheduled to process for REGION: "+schAdmMdl.getRegion()+"******");
    					}
    				}else{
    					log.info("<<< NO ACTIVE Scheduler for  USER TO CRITICAL ROLE  Region : "+schAdmMdl.getRegion()+" >>>");
    				}
    			}
    		}else {
        			log.info("****** ( ( "+envName+" USER TO SOD - EXPORT) No Active REGION to Schedule Processing: "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " Please Activate Schedulers....! ******");
        			log.info(" ("+envName+") USER TO SOD Scheduler going to SLEEP ... Will check back in 5 Minutes..zzzzzzzzzz\n");
        	}
        	/*END DATA EXPORT*/
        } catch (Exception e){
			log.error("Exception in USER TO SOD ("+envName+"):" + e.getMessage(), e);
		}
    }





    @Scheduled(cron="1 1 8 * * *") //Runs at 06.01AM
    public void runSodRefresh() {
    	List<String> runSodRefresh = Utility.loadOneClickPropertyU2R("RUN_SOD_REFRESH");
		if(!(runSodRefresh != null && !runSodRefresh.isEmpty() && (runSodRefresh.get(0).equals("Y")))) {
			log.info(" CURRENT ("+envName+") SERVER CANNOT TRIGGER SOD_REFRESH, Please check property 'RUN_SOD_REFRESH'");
			return;
		}
    	log.info("====================Starting SOD_REFRESH @"+Utility.fmtMMDDYYYYTime(new Date())+"====================");
    	sodRefreshController.executeSODRefresh();
    	log.info("====================Ending SOD_REFRESH @"+Utility.fmtMMDDYYYYTime(new Date())+"====================");
    }


  //Triggers every 20 Minutes
    /*@SuppressWarnings("all")
    @Scheduled(fixedDelay=1200000)
    public void iamRequestScheduler()
    {
        try{
        	//Query Approved Requests, Ready to POST Data to IAM
        	List<String> iamFlgVal = Utility.loadOneClickPropertyU2R(Constants.IAM_ACTIVITY_FLG);
    		if(!(iamFlgVal != null && !iamFlgVal.isEmpty() && (iamFlgVal.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT SEND/RECEIVE REQUEST DATA TO/FROM IAM, Please check property 'TRIGGER_IAM_REQUEST'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting IAM REQUEST Processing on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");

        	List<UIRequestDispModel> allReqLst = userIdentityService.getAllApprovedRequests();
			if(allReqLst != null && !allReqLst.isEmpty()) {
				log.info("Submitting  ("+allReqLst.size()+") Requests to GRC/IAM.");
				exchangeDataController.submitApprovedReqToGRCIAM(allReqLst);
			}else {
    			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
    		}
    	} catch (Exception e){
        	log.error("Error getting request Data: "+e.getMessage(), e);
			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
		}
    }*/

   //Triggers every 20 Minutes
    /*@SuppressWarnings("all")
    @Scheduled(fixedDelay=1200000)
    public void iamRequestStatusScheduler()
    {
        try{
        	List<String> iamFlgVal = Utility.loadOneClickPropertyU2R(Constants.IAM_ACTIVITY_FLG);
    		if(!(iamFlgVal != null && !iamFlgVal.isEmpty() && (iamFlgVal.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT SEND/RECEIVE REQUEST DATA TO/FROM IAM, Please check property 'TRIGGER_IAM_REQUEST'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting Get IAM REQUEST Status on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");

        	List<UIRequestDispModel> allReqLst = userIdentityService.getAllReqSubmittedToIAM();
			if(allReqLst != null && !allReqLst.isEmpty()) {
				log.info("Getting Status for ("+allReqLst.size()+") Requests to GRC/IAM.");
				exchangeDataController.getSubmittedReqStatusGRCIAM(allReqLst);
			}else {
    			log.info("("+envName+") Queried Request Status Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
    		}
    	} catch (Exception e){
        	log.error("Error getting request Data: "+e.getMessage(), e);
			log.info("("+envName+") Queried Request Status Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
		}
    }*/



    @SuppressWarnings("all")
    @Scheduled(fixedDelay=14400000)
    public void processCSMData()
    {
        try{
        	List<String> csmFlag = Utility.loadOneClickPropertyU2R(Constants.CSM_FLAG);
    		if(!(csmFlag != null && !csmFlag.isEmpty() && (csmFlag.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT PROCESS CSM DATA TO/FROM LDAP, Please check property '"+Constants.CSM_FLAG+"'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting CSM Data process on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	 //List<GrpUsrDateMdl> iamDataList = cSMDataController.startProcessCSMData(2, null);
        	List<GrpUsrDateMdl> csmDataList = anaplanDataHandler.downloadExpDef();
        	if(null != csmDataList && !csmDataList.isEmpty()) {
        		 int records = anaplanDataHandler.saveCSMDataToDB(csmDataList);
        		 log.info("Total Records Saved : "+records);
        	 }
			log.info("("+envName+") Completed CSM Data process Total Records : ("+csmDataList.size()+")  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");

    	} catch (Exception e){
        	log.error("Error getting request Data: "+e.getMessage(), e);
			log.info("("+envName+") CSM Data process  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
		}
    }





   //Triggers every 20 Minutes
    /**
	 * Method  : RQCUtilSchedular.java.edalIAMRequestScheduler()
	 *		   :<b></b>
	 * @author : DChauras  @Created :May 2, 2023 9:52:10 AM
	 * Purpose : Submit request for IAM processing, Triggers every 20 minutes.
	 * @return : void
	 */
    @SuppressWarnings("all")
  @Scheduled(fixedDelay=600000)
   // @Scheduled(fixedDelay=1200000)
    public void edalIAMRequestScheduler()
    {
        try{
        	//Query Approved Requests, Ready to POST Data from EDAL => IAM.
        	List<String> edalIamActivity = Utility.loadOneClickPropertyU2R(Constants.EDALIAM_ACTIVITY_FLG);
    		if(!(edalIamActivity != null && !edalIamActivity.isEmpty() && (edalIamActivity.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT SEND/RECEIVE EDAL REQUEST DATA TO/FROM IAM, Please check property '"+Constants.EDALIAM_ACTIVITY_FLG+"'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting EDAL IAM REQUEST Processing on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	recordExecutionTime("edalIAMRequestScheduler");
        	List<AbsUserReqMdl> allReqLst  = iamGrcRequestSumbissionService.getApprovedRequestForSubmission();
			if(allReqLst != null && !allReqLst.isEmpty()) {
				log.info("Submitting  ("+allReqLst.size()+") Requests to GRC/IAM.");
				iamGrcRequestSumbissionService.submitApprRequestToDownstreams(allReqLst);
			}else {
    			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
    		}
    	} catch (Exception e){
        	log.error("Error getting request Data: "+e.getMessage(), e);
			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
		}
    }



    /**
	 * Method  : RQCUtilSchedular.java.edalIAMRequestStatusScheduler()
	 *		   :<b></b>
	 * @author : DChauras  @Created :May 2, 2023 9:50:46 AM
	 * Purpose : Check the Status of each request, triggers every 20 minutes.
	 * @return : void
	 */
    @SuppressWarnings("all")
  @Scheduled(fixedDelay=300000)
    public void edalIAMRequestStatusScheduler()
    {
        try{
        	List<String> edalIamStatusActivity = Utility.loadOneClickPropertyU2R(Constants.EDALIAM_ACTIVITY_FLG);
    		if(!(edalIamStatusActivity != null && !edalIamStatusActivity.isEmpty() && (edalIamStatusActivity.get(0).equals("Y")))) {
    			log.info(" CURRENT ("+envName+") SERVER CANNOT SEND/RECEIVE EDAL REQUEST DATA TO/FROM IAM, Please check property '"+Constants.EDALIAM_ACTIVITY_FLG+"'");
    			return;
    		}
        	log.info("<<<<<<<<<<  Starting Get EDAL IAM REQUEST Status on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
        	recordExecutionTime("edalstatusScheduler");
        	List<AbsUserReqMdl> allReqLst = iamGrcRequestSumbissionService.getAllEDALReqSubmittedToIAM();
			if(allReqLst != null && !allReqLst.isEmpty()) {
				log.info("Getting Status for ("+allReqLst.size()+") EDAL Requests to GRC/IAM.");
				dataSubmissionService.getSubmittedEdalReqStatusIam(allReqLst);
			}else {
    			log.info("("+envName+") Queried Request Status Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
    		}
    	} catch (Exception e){
        	log.error("Error getting request Data: "+e.getMessage(), e);
			log.info("("+envName+") Queried Request Status Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
		}
    }


    /**
    	 * Method  : RQCUtilSchedular.java.clearUserDataCache()
    	 *		   :<b></b>
    	 * @author : DChauras  @Created :Jun 9, 2023 1:43:49 PM
    	 * Purpose : Run View Dimension ID Load every 4 hours
    	 * @return : void
    	 */
    //@Scheduled(fixedDelay=60000) //1Min
    @Scheduled(fixedDelay=14400000)
    public void loadAnaplanViewDimensionData() {
    	log.info("<<<<<<<<<<  START ANAPLAN VIEW DIMENSION LOAD on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
    	long start = System.currentTimeMillis();
		try {
			List<EmailItem> dataLst = userAccessDataService.loadAllEmailDimensionsFromAnaPlan();
		} catch (Exception e) {
			log.error("ERROR LOADING EMAIL DIMENSIONS : "+e.getMessage(), e);
		}
		log.info("<<<<<<<<<<  COMPLETED ANAPLAN VIEW DIMENSION LOAD on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())  +" TOTAL TIME: "+((System.currentTimeMillis() - start)/1000)+ " seconds. >>>>>>>>>>");
    }
    @SuppressWarnings("all")
    @Scheduled(fixedDelay = 6 * 3600000) // 600000 means 10mins . 1800000 means 30mins   
      public void edalFetchExistingRolesCFINScheduler()
      {
          try{
          	//Query Approved Requests, Ready to POST Data from EDAL => IAM.
          	List<String> edalIamActivity = Utility.loadOneClickPropertyU2R(Constants.EDAL_FETCH_ALL_ROLES);
      		if(!(edalIamActivity != null && !edalIamActivity.isEmpty() && (edalIamActivity.get(0).equals("Y")))) {
      			log.info(" CURRENT ("+envName+") SERVER CANNOT Fetch records from CFIN, Please check property '"+Constants.EDAL_FETCH_ALL_ROLES+"'");
      			return;
      		}
          	log.info("<<<<<<<<<<  Starting EDAL to fetch records from CFIN on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
          	sAPUserDao.fetchExistingRolesCFIN(Constants.SAP_ADGRP_S4PFI);        	          	
      	} catch (Exception e){
          	log.error("Error getting request Data: "+e.getMessage(), e);
  			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
  		}
      }   
    @SuppressWarnings("all")
    @Scheduled(fixedDelay = 6 * 3600000)
      public void edalFetchExistingRolesDDGRScheduler()
      {
          try{
        	  List<String> edalIamActivity = Utility.loadOneClickPropertyU2R(Constants.EDAL_FETCH_ALL_ROLES);
      		if(!(edalIamActivity != null && !edalIamActivity.isEmpty() && (edalIamActivity.get(0).equals("Y")))) {
      			log.info(" CURRENT ("+envName+") SERVER CANNOT Fetch records from DDGR, Please check property '"+Constants.EDAL_FETCH_ALL_ROLES+"'");
      			return;
      		}
          	log.info("<<<<<<<<<<  Starting EDAL to fetch records from DDGR on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
          	sAPUserDao.fetchExistingRolesDDGR(Constants.SAP_ADGRP_BW4PFB);


      	} catch (Exception e){
          	log.error("Error getting request Data: "+e.getMessage(), e);
  			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
  		}
      } 
    @SuppressWarnings("all")
    @Scheduled(fixedDelay = 6 * 3600000)
      public void edalFetchExistingRolesAnaplanScheduler()
      {
        try{
        	List<String> edalIamActivity = Utility.loadOneClickPropertyU2R(Constants.EDAL_FETCH_ALL_ROLES);
      		if(!(edalIamActivity != null && !edalIamActivity.isEmpty() && (edalIamActivity.get(0).equals("Y")))) {
      			log.info(" CURRENT ("+envName+") SERVER CANNOT Fetch records from Anaplan, Please check property '"+Constants.EDAL_FETCH_ALL_ROLES+"'");
      			return;
      		}
          	log.info("<<<<<<<<<<  Starting EDAL to fetch records from Anaplan on Server("+envName+"): "+Utility.getServerName()+"  @@  "+Utility.fmtMMDDYYYYTime(new Date())+ " >>>>>>>>>>");
          	sAPUserDao.fetchExistingRolesAnaplan();

      	} catch (Exception e){
          	log.error("Error getting request Data: "+e.getMessage(), e);
  			log.info("("+envName+") Queried Request Count: 0  ...Going to Sleep Mode, Will check back in 10 Minutes..zzzzzzzzzz\n");
  		}
      } 
    public String getLastExecutionTime(String schedulerName) {
        return lastExecutionTimes.getOrDefault(schedulerName, "0");
    }

    public String getFixedDelay(String schedulerName) {
        return fixedDelays.getOrDefault(schedulerName, "0");
    }

    private void recordExecutionTime(String schedulerName) {       
        String fixedDeplay ="0";
        long currentTimestampMillis = Instant.now().toEpochMilli();        
        LocalDateTime dateTime = Instant.ofEpochMilli(currentTimestampMillis).atZone(ZoneId.systemDefault()).toLocalDateTime();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String formattedDateTime = dateTime.format(formatter);
        
        lastExecutionTimes.put(schedulerName, formattedDateTime);
        
        if("edalIAMRequestScheduler".equalsIgnoreCase(schedulerName)) {
        	fixedDeplay = "10 mins";
        }else if("edalstatusScheduler".equalsIgnoreCase(schedulerName)) {
        	fixedDeplay = "5 mins";
        }else {
        	fixedDeplay = "0";
        }
        fixedDelays.put(schedulerName, fixedDeplay);
    }
    
}
