package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class JDADBRiskModel {
	 String riskId;
	 String riskDesc;
	 String roleName;
	 String roleId;
	 String funcId;
	 String funcDesc;
	 String riskLevel;
	 String regulation;
	 String trgtCon;
	 String mitiCntrl;
	 String complMgr;
	 String rulesetGpo;



	public String getData() {
		return  riskId + "~" + riskDesc + "~" + roleId + "~" + roleName + "~" + funcId + "~" + funcDesc + "~" + riskLevel
				+ "~" + regulation + "~" + trgtCon + "~" + mitiCntrl + "~" + complMgr + "~" + rulesetGpo;
	}



	@Override
	public String toString() {
		return "JDADBRiskModel [riskId=" + riskId + ", riskDesc=" + riskDesc + ", roleName=" + roleName + ", roleId="
				+ roleId + ", funcId=" + funcId + ", funcDesc=" + funcDesc + ", riskLevel=" + riskLevel
				+ ", regulation=" + regulation + ", trgtCon=" + trgtCon + ", mitiCntrl=" + mitiCntrl + ", complMgr="
				+ complMgr + ", rulesetGpo=" + rulesetGpo + "]";
	}




}
