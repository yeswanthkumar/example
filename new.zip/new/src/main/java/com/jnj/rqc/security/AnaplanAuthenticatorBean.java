package com.jnj.rqc.security;


import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.anaplan.models.AnaplanRespMdl;
import com.jnj.rqc.anaplan.models.TokenInfo;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.util.Utility;





@Component ("AnaplanAuthenticatorBean")
public class AnaplanAuthenticatorBean
{
	static final Logger log = LoggerFactory.getLogger(AnaplanAuthenticatorBean.class);
	private String uri = "https://auth.anaplan.com/token/authenticate";
	private TokenInfo tokenInfo;
	private RestTemplate restHttpTemplate;
	private UserMenuDao userMenuDao;
	private static AnaplanAuthenticatorBean anaAuth;

	private AnaplanAuthenticatorBean() {
	}

	private AnaplanAuthenticatorBean(RestTemplate restHttpTemplate, UserMenuDao userMenuDao) {
		super();
		this.restHttpTemplate = restHttpTemplate;
		this.userMenuDao = userMenuDao;
	}

	public static AnaplanAuthenticatorBean initAnaplanAuth(RestTemplate restHttpTemplate, UserMenuDao userMenuDao) {
		log.info("Login to Anaplan System");
		if(!isTokenAlive()) {
			log.info("Login to Anaplan ");
			try{
				anaAuth = new AnaplanAuthenticatorBean(restHttpTemplate, userMenuDao);
				anaAuth.setUri(userMenuDao.getUtilsConstVals("ANAPLAN_AUTH_URI"));
				log.info(">>>>>>>>>>>>>>>>>>> ANAPLAN_AUTH_URI    :"+userMenuDao.getUtilsConstVals("ANAPLAN_AUTH_URI"));
				Base64 b = new Base64();
				String userDet = userMenuDao.getUtilsConstVals("ANAPLAN_USER_DATA");
				log.info(">>>>>>>>>>>>>>>>>>> userDet    :"+userDet);
	            String encoding = b.encodeAsString(userDet.getBytes());
	            HttpHeaders headers = new HttpHeaders();// set headers
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("Authorization", "Basic " + encoding);
				HttpEntity<String> entity = new HttpEntity<>(headers);

				//log.info("Submitting a POST request to : "+uri);
				ResponseEntity<String> authResp = restHttpTemplate.exchange(anaAuth.uri, HttpMethod.POST, entity, String.class);
				if (authResp != null && (authResp.getStatusCode() == HttpStatus.CREATED || authResp.getStatusCode() == HttpStatus.OK)) {
					log.info("Login successfully to ANAPLAN");
					Gson gson = new Gson();
					AnaplanRespMdl resp = new AnaplanRespMdl();
					resp = gson.fromJson(authResp.getBody(), AnaplanRespMdl.class);
					anaAuth.tokenInfo = resp.getTokenInfo();
				}else {
					anaAuth.tokenInfo  = null;
				}
			}catch(Exception ex) {
				log.error("Exception "+ ex.getMessage(), ex);
				anaAuth.tokenInfo  = null;
			}
		}
		return anaAuth;
    }


	private static boolean isTokenAlive() {
		boolean valid = false;
		if(anaAuth != null && anaAuth.getTokenInfo() != null) {
			long expAt = anaAuth.getTokenInfo().getExpiresAt();
			Date expDate = new Date(expAt);
			if( expDate.after(new Date())) {
				valid = true;
			}
		}
		return valid;
	}

	public TokenInfo getTokenInfo() {
		return anaAuth.tokenInfo;
	}

	public void setUri(String uri) {
		anaAuth.uri = uri;
	}


	private HttpHeaders getHeaders(String mediaTyp, String sessionId) {
		HttpHeaders headers = new HttpHeaders();
		if(Utility.isEmpty(mediaTyp) || "JSON".equals(mediaTyp)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}else if("TEXT".equals(mediaTyp)) {
			headers.setContentType(MediaType.TEXT_PLAIN);
		}

		if(!Utility.isEmpty(sessionId)) {
			headers.add("Cookie", "ss-id="+sessionId);
		}
		return headers;
	}



}