package com.jnj.rqc.userabs.iamgrcservice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.edal.handlers.DataSubmissionService;
import com.jnj.rqc.edal.handlers.IAMDataExchangeBean;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.userabs.models.AbsUserReqMdl;
import com.jnj.rqc.userabs.models.ReqDpendncMdl;
import com.jnj.rqc.userabs.models.RoleADGrpMdl;
import com.jnj.rqc.userabs.models.RolesRespDto;
import com.jnj.rqc.userabs.service.UserAccessDataService;
import com.jnj.rqc.useridentity.models.ConflictRequestedModel;
import com.jnj.rqc.useridentity.models.GRCAdGrpResponse;
import com.jnj.rqc.useridentity.models.GRCAdGrpServiceStatusRespDTO;
import com.jnj.rqc.useridentity.models.GRCRequestDTO;
import com.jnj.rqc.useridentity.models.GRCResponseDTO;
import com.jnj.rqc.useridentity.models.IAMRequestedRoleModel;
import com.jnj.rqc.useridentity.models.IamAdGrpRequestDTO;
import com.jnj.rqc.useridentity.models.IamAdGrpRequestObj;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceStatusRespDTO;
import com.jnj.rqc.useridentity.models.IamAdGrpServiceSubRespDTO;
import com.jnj.rqc.useridentity.models.SubmitRolen;
import com.jnj.rqc.useridentity.models.SubmitUsern;
import com.jnj.rqc.userreq.dao.AbsUserRequesDao;
import com.jnj.rqc.util.Utility;

@Service
public class IamGrcRequestSumbissionServiceImpl implements IamGrcRequestSumbissionService {
	static final Logger log = LoggerFactory.getLogger(IamGrcRequestSumbissionServiceImpl.class);

	@Autowired
	private AbsUserRequesDao absUserRequesDao;

	@Autowired
	private UserSearchService userSearchService;

	@Autowired
	private IAMDataExchangeBean iAMDataExchangeBean;

	@Autowired
	private DataSubmissionService dataSubmissionService;

	@Autowired
	private RestTemplate restHttpTemplate;

	@Autowired
	private UserMenuDao userMenuDao;

	@Autowired
	private UserAccessDataService userAccessDataService;

	@Override
	public List<AbsUserReqMdl> getApprovedRequestForSubmission() {
		List<AbsUserReqMdl> userReqs = new ArrayList<>();
		try{
			List<AbsUserReqMdl> allReqsList  = absUserRequesDao.getEligibleApprovedRequests();
			for(AbsUserReqMdl reqMdl : allReqsList ) {
				UserSearchModel reqByUser = userSearchService.getUserStatusJJEDS(reqMdl.getRequestedby(), 1);
				reqMdl.setRequestedbyname(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(reqMdl.getUserid(), 1);
				reqMdl.setUsername(assocUser.getFmlyNm()+" "+assocUser.getGivenNm()+"("+assocUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = userSearchService.getUserStatusJJEDS(reqMdl.getManagerid(), 1);
				reqMdl.setManagername(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}


	@Override
	public void submitApprRequestToDownstreams(List<AbsUserReqMdl> apprReqLst) {
		log.info("Start Submission Process Request");
   	 	long start = System.currentTimeMillis();
   	 	for(AbsUserReqMdl reqMdl : apprReqLst) {
   	 		boolean result = sendApprovedDataToAnaplanIamGrc(reqMdl);
   	 		if(result) {
   	 			updateIamGrcRequestStatus(reqMdl.getReqid(), Constants.PROVISIONING_WIP);//Status updating to : Submitted To IAM
   	 		}
   	 	}
   	 	log.info("<<<<<<<<<<  Total time taken to connect : "+((System.currentTimeMillis() - start)/1000)+ " seconds >>>>>>>>>>");
   	 	log.info("Session ID: "+iAMDataExchangeBean.getSessId());
	}


	@Override
	public boolean sendApprovedDataToAnaplanIamGrc(AbsUserReqMdl reqMdl) {
		//Get System Info for Request ID
		boolean result = false;
		try {
			Date start = new Date();
			log.info("Processing REQUEST ID: "+reqMdl.getReqid()+" STARTED at time: "+Utility.fmtMMDDYYYYTime(start));
			List<ReqDpendncMdl> reqDetLst = absUserRequesDao.getTktDependencies(reqMdl.getReqid()+"");
			if(reqDetLst != null && !reqDetLst.isEmpty()) {	
				for(ReqDpendncMdl detailNum : reqDetLst) {
					//Denied Excessive Access Variants)
					log.info("Variants Before remove:"+detailNum.getPosvarids());
					if("Y".equals(reqMdl.getIsExces())) {
						final List<String> deniedVariants = absUserRequesDao.getExcessiveAccessDeniedVariants(reqMdl.getReqid()+"", detailNum.getSysid());
						if(deniedVariants != null && !deniedVariants.isEmpty()) {
							List<String> filtData = (Arrays.asList(detailNum.getPosvarids().split(",")).stream()
									.filter(pid -> !deniedVariants.contains(pid))
									.collect(Collectors.toList())).stream().map(str -> str.toString())
									.collect(Collectors.toList());

							detailNum.setPosvarids(String.join(",", filtData));
							log.info("Variants After remove:"+detailNum.getPosvarids());
							detailNum.setAdids(absUserRequesDao.getAllADGrpBySystem(detailNum.getSysid(), detailNum.getPosids().split(","), detailNum.getAccids().split(","), detailNum.getPosvarids().split(",")));
						}
					}
					log.info("Variants before the conflicts check :"+detailNum.getPosvarids());
					  	if("Y".equals(reqMdl.getConflictFound())) {
					  		log.info("------------Variants conflict logic called :");
							final List<ConflictRequestedModel> deniedPositions = absUserRequesDao.getConflictsDeniedPositions(reqMdl.getReqid()+"", detailNum.getSysid());
							if(deniedPositions !=null && deniedPositions.size() > 0) {
								//for()
								//for()
								String app1 = deniedPositions.get(0).getApp1();
								String app2 = deniedPositions.get(0).getApp2();
								String pos1 = deniedPositions.get(0).getPosv1();
								String pos2 = deniedPositions.get(0).getPosv2();
								log.info("Variants conflict logic called app1 :"+app1);
								log.info("Variants conflict logic called pos1 :"+pos1);
								log.info("Variants conflict logic called app2 :"+app2);
								log.info("Variants conflict logic called pos2 :"+pos2);
								List<String> conflict = absUserRequesDao.getTktDependenciesByConflict(reqMdl.getReqid()+"" , app1, app2, pos1, pos2 );
								log.info("Variants conflict logic called pos2 :"+pos2);
								 String posVarid = detailNum.getPosvarids();
								 log.info("Variants conflict logic called conflict :"+conflict);
								 log.info("Variants conflict logic called posVarid :"+posVarid);
								 String adIds = detailNum.getAdids();
								 log.info("Variants conflict logic calledadIds :"+adIds);
								 List<String> conflictList = conflict.stream()
										 							 .flatMap(s -> Arrays.stream(s.split(",")))
										 							 .collect(Collectors.toList());
								 List<String> posVarID = Arrays.stream(posVarid.split(","))
										 						.filter(e -> !conflictList.contains(e))
										 						.collect(Collectors.toList());
								 log.info("Variants conflict logic after filter called posVarID :"+posVarID);
								 detailNum.setPosvarids(String.join(",", posVarID));
								 log.info("------------- getConflictFound Variants After remove:"+detailNum.getPosvarids());
								 detailNum.setAdids(absUserRequesDao.getAllADGrpBySystem(detailNum.getSysid(), detailNum.getPosids().split(","), detailNum.getAccids().split(","), detailNum.getPosvarids().split(",")));
						  	}
						}
					  	// duplicate request to filter
					/* if(reqMdl.getTypeid() == 1 ) {
					 RolesRespDto userExistRoleRespDto = userAccessDataService.getExistingRoles(reqMdl.getUserid());					  
					  Map<String, List<RoleADGrpMdl>> mapList = userExistRoleRespDto.getRoles();
					  if (mapList != null && !mapList.isEmpty()) {
						  log.info("Variants duplicate logic after filter called start");
						  List<String> pvIdExistingList = new ArrayList<String>();
						  List<String> adIdLst = new ArrayList<String>();
						    for (Map.Entry<String, List<RoleADGrpMdl>> entry : mapList.entrySet()) {
						        String key = entry.getKey();
						        List<RoleADGrpMdl> roleList = entry.getValue();						       
						        log.info("Variants duplicate Key: " + key);
						        for (RoleADGrpMdl role : roleList) {
						        	pvIdExistingList.add(role.getPvId());
						        	adIdLst.add(role.getAdgrpId());
						        	
						        } 
						    }
						    log.info("Variants duplicate logic after filter block pvIdExistingList :"+pvIdExistingList);
						    String posVarid = detailNum.getPosvarids();
						    String adIds = detailNum.getAdids();
						    log.info("Variants duplicate logic after filter block posVarid :"+posVarid);
						    log.info("Variants duplicate logic after filter block posVarid :"+adIds);
						    List<String> posVarID = Arrays.stream(posVarid.split(","))
			 						.filter(e -> !pvIdExistingList.contains(e))
			 						.collect(Collectors.toList()); 
						    
						    
						    detailNum.setPosvarids(String.join(",", posVarID));
						    log.info("Variants duplicate logic after filter block :"+detailNum.getPosvarids());
						    detailNum.setAdids(absUserRequesDao.getAllADGrpBySystem(detailNum.getSysid(), detailNum.getPosids().split(","), detailNum.getAccids().split(","), detailNum.getPosvarids().split(",")));
						    log.info("Variants duplicate logic after filter called end");
						}
					 } */
					  
					if(detailNum.getSysid().equals("1")) {
						//TODO Process GRC Data Send
						List<IAMRequestedRoleModel> respList = sendDataToGRC(reqMdl.getReqid(), reqMdl.getTypeid(), reqMdl.getUserid(), reqMdl.getRequestedby(), detailNum.getSysid(), reqMdl.getComments(),  detailNum);
						 if(respList != null && !respList.isEmpty()) {
							 int recsInserted = absUserRequesDao.saveIamReqstedDataHubAnaplanRoles(respList);
							 if(recsInserted == respList.size()) {
								 result = true;
							 }
						 }
					}else if(detailNum.getSysid().equals("2") || detailNum.getSysid().equals("3") || detailNum.getSysid().equals("4") || detailNum.getSysid().equals("5") || detailNum.getSysid().equals("6") ) {//Send to IAM for Data Hub and AnaPlan system
						 List<IAMRequestedRoleModel> respList = sendDataToIAM(reqMdl.getReqid(), reqMdl.getTypeid(), reqMdl.getUserid(), reqMdl.getRequestedby(), detailNum.getSysid(), reqMdl.getComments(),  detailNum);
						 if(respList != null && !respList.isEmpty()) {
							 int recsInserted = absUserRequesDao.saveIamReqstedDataHubAnaplanRoles(respList);
							 if(recsInserted == respList.size()) {
								 result = true;
							 }
						 }
					}/*else if(detailNum.getSysid().equals("5")) {

					}*/
				}
			}
			log.info("Processing REQUEST ID: "+reqMdl.getReqid()+" COMPLETED at time: "+Utility.fmtMMDDYYYYTime(start));
		}catch (Exception e) {
			log.error("Error processing data post to GRC/IAM :"+e.getMessage(), e);
		}
		return result;
	}

	private static boolean isConflict(List<String> conflict, String element) {
        for (String conflictElement : conflict) {
            String[] splitConflicts = conflictElement.split(",");
            for (String splitConflict : splitConflicts) {
                if (splitConflict.equals(element)) {
                    return true;
                }
            }
        }
        return false;
    }
/*
	@Override
	public List<IAMRequestedRoleModel> sendDataToGRC(int reqId, int reqType, String userId, String reqBy, String sysId, String comments, ReqDpendncMdl detailNum) {
		List<IAMRequestedRoleModel> rolesList = new ArrayList<>();
		try{
			Gson gson = new Gson();
			Base64 b = new Base64();
			UserSearchModel userObj = userSearchService.getUserStatusJJEDS(userId, 1);
			String userDet = userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH);
			String apiUrl  = userMenuDao.getUtilsConstVals(Constants.GRC_API_URL);
            String encoding = b.encodeAsString(userDet.getBytes());
            HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
			//userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH)
			String[] adIds = detailNum.getAdids().split(",");
			for(String adGrpId : adIds) {
				GRCRequestDTO reqDto = new GRCRequestDTO();
				List<SubmitUsern> userInfo = new ArrayList<>();
				List<SubmitRolen> roleInfo = new ArrayList<>();
				reqDto.setSUBMITUSERN(userInfo);//Setting Up User Data
				reqDto.setSUBMITROLEN(roleInfo);//Setting up Role Data
				reqDto.setUPDATED_BY_ID(reqBy);//Requestor
				reqDto.setREQJUSTIFICATION(comments);
				//User Data
				SubmitUsern userN = new SubmitUsern();
				userN.setUSERID(userObj.getWwId());
				userN.setFNAME(userObj.getGivenNm());
				userN.setLNAME(userObj.getFmlyNm());
				userN.setSNC_NAME("p:CN="+userObj.getJnjEmailAddrTxt());//"p:CN=dgandava@its.jnj.com"
				userN.setACCNO(userObj.getWwId());
				Calendar curDate = Calendar.getInstance();
				Calendar plus1YearDate = Calendar.getInstance();
				plus1YearDate.add(Calendar.YEAR, 1);
				userN.setVALID_FROM(Utility.fmtYyyyMMdt(curDate.getTime()));
				userN.setVALID_TO(Utility.fmtYyyyMMdt(plus1YearDate.getTime()));
				userN.setEMAIL(userObj.getJnjEmailAddrTxt());
				userN.setUSERALIAS(userObj.getJnjMsftUsrnmTxt());
				userN.setMANAGER(userObj.getJnjSupvrWwId());
				userN.setMANAGER_NAME(userObj.getJnjSupvrName());
				userInfo.add(userN);//Adding User Data
				String adGrpName = absUserRequesDao.getZadGrpById(adGrpId);

				SubmitRolen rolen = new SubmitRolen();
				rolen.setROLE_NAME(adGrpName);
				String grcSysId = userMenuDao.getUtilsConstVals("GRC_SYS_ID");
				rolen.setSYSTEM(grcSysId);
				String validFrm = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_FROM().replaceAll("-", "")+"000000":"" );
				String validTo = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_TO().replaceAll("-", "")+"235959":"" );
				rolen.setVALID_FROM(validFrm);
				rolen.setVALID_TO(validTo);
				if(reqType == 1) {//ADD
					rolen.setPROV_ACTION(6);
				}else if(reqType == 2) {//REMOVE
					rolen.setPROV_ACTION(9);
				}
				rolen.setCOMMENTS(comments);
				roleInfo.add(rolen);

				String reqElement = gson.toJson(reqDto);
				log.info("Sent to URL :---------------------->"+apiUrl);
				log.info("Sent to GRC REQ :---------------------->"+reqElement);
				log.info("Sent to GRC headers :---------------------->"+headers);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(apiUrl, HttpMethod.POST, reqEntity, String.class);
				log.info("Sent to GRC respEntity :---------------------->"+respEntity);
				GRCResponseDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					log.info("Resp Body for GRC REQ:"+reqId+ "ADGROUP name: "+adGrpName+"\n"+respEntity.getBody());
					respDto = gson.fromJson(respEntity.getBody(), GRCResponseDTO.class);
					if(respDto.getMESSAGE_TYPE() != null && respDto.getMESSAGE_TYPE().equals("S") ) {
						rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getREQNO(), "N"));
						log.info("resp.REQNO :"+respDto.getREQNO()+" MESSAGE: "+respDto.getMESSAGE());
					}else {
						log.info("ERROR Submitting CFIN Role to GRC System ==>Resp Body for GRC REQ:"+reqId+ "ADGROUP name: "+adGrpName+" - "+respDto.getMESSAGE_TYPE()+" - "+respDto.getMESSAGE());
						rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getMESSAGE(), "E"));
					}
				}
			}
		}catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return rolesList;
	}

*/
	@Override
	public boolean pingGRC(String reqBy) {		
		boolean status = false;
		try{
			Gson gson = new Gson();
			Base64 b = new Base64();			
			String userDet = userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH);
			String apiUrl  = userMenuDao.getUtilsConstVals(Constants.GRC_API_URL);
            String encoding = b.encodeAsString(userDet.getBytes());
            HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
			log.info("Sent to URL :---------------------->"+apiUrl);           
            log.info("Sent to GRC headers :---------------------->"+headers);
			HttpEntity<String> reqEntity = new HttpEntity<>(headers);			
			ResponseEntity<String> respEntity = restHttpTemplate.exchange(apiUrl+"?REQNO=1234", HttpMethod.GET, reqEntity,  String.class);
			log.info("Sent to GRC respEntity :---------------------->"+respEntity);				
			if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					status = true;
			}			
		}catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return status;
	}
	/*
	@Override
	public boolean pingGRC(String reqBy) {
		//List<IAMRequestedRoleModel> rolesList = new ArrayList<>();
		boolean status = false;
		try{
			Gson gson = new Gson();
			Base64 b = new Base64();
			//UserSearchModel userObj = userSearchService.getUserStatusJJEDS(userId, 1);
			String userDet = userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH);
			String apiUrl  = userMenuDao.getUtilsConstVals(Constants.GRC_API_URL);
            String encoding = b.encodeAsString(userDet.getBytes());
            HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
			//userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH)
			//String[] adIds = detailNum.getAdids().split(",");
			
				GRCRequestDTO reqDto = new GRCRequestDTO();
				List<SubmitUsern> userInfo = new ArrayList<>();
				List<SubmitRolen> roleInfo = new ArrayList<>();
				reqDto.setSUBMITUSERN(userInfo);//Setting Up User Data
				reqDto.setSUBMITROLEN(roleInfo);//Setting up Role Data
				reqDto.setUPDATED_BY_ID(reqBy);//Requestor
				reqDto.setREQJUSTIFICATION("ping test");
				//User Data
				SubmitUsern userN = new SubmitUsern();
				userN.setUSERID("ping");
				userN.setFNAME("test");
				userN.setLNAME("test");
				//userN.setSNC_NAME("p:CN="+userObj.getJnjEmailAddrTxt());//"p:CN=dgandava@its.jnj.com"
				//userN.setACCNO(userObj.getWwId());
				Calendar curDate = Calendar.getInstance();
				Calendar plus1YearDate = Calendar.getInstance();
				plus1YearDate.add(Calendar.YEAR, 1);
				userN.setVALID_FROM(Utility.fmtYyyyMMdt(curDate.getTime()));
				userN.setVALID_TO(Utility.fmtYyyyMMdt(plus1YearDate.getTime()));
				//userN.setEMAIL(userObj.getJnjEmailAddrTxt());
				//userN.setUSERALIAS(userObj.getJnjMsftUsrnmTxt());
				//userN.setMANAGER(userObj.getJnjSupvrWwId());
				//userN.setMANAGER_NAME(userObj.getJnjSupvrName());
				userInfo.add(userN);//Adding User Data
				
				String grcSysId = userMenuDao.getUtilsConstVals("GRC_SYS_ID");
				String validFrm = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_FROM().replaceAll("-", "")+"000000":"" );
				String validTo = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_TO().replaceAll("-", "")+"235959":"" );
				//for(String adGrpId : adIds) {
					//String adGrpName = absUserRequesDao.getZadGrpById(adGrpId);
	
					SubmitRolen rolen = new SubmitRolen();
					//rolen.setROLE_NAME(adGrpName);					
					rolen.setROLE_NAME("test");
					rolen.setSYSTEM(grcSysId);					
					rolen.setVALID_FROM(validFrm);
					rolen.setVALID_TO(validTo);
					//if(reqType == 1) {//ADD
						rolen.setPROV_ACTION(6);
					//}
					rolen.setCOMMENTS("test");
					roleInfo.add(rolen);
				//}

				String reqElement = gson.toJson(reqDto);
				log.info("Sent to URL :---------------------->"+apiUrl);

                log.info("Sent to GRC REQ :---------------------->"+reqElement);

                log.info("Sent to GRC headers :---------------------->"+headers);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(apiUrl, HttpMethod.POST, reqEntity, String.class);
				log.info("Sent to GRC respEntity :---------------------->"+respEntity);
				//GRCResponseDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					status = true;
				}			
		}catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return status;
	}
	*/
	@Override
	public List<IAMRequestedRoleModel> sendDataToGRC(int reqId, int reqType, String userId, String reqBy, String sysId, String comments, ReqDpendncMdl detailNum) {
		List<IAMRequestedRoleModel> rolesList = new ArrayList<>();
		try{
			Gson gson = new Gson();
			Base64 b = new Base64();
			UserSearchModel userObj = userSearchService.getUserStatusJJEDS(userId, 1);
			String userDet = userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH);
			String apiUrl  = userMenuDao.getUtilsConstVals(Constants.GRC_API_URL);
            String encoding = b.encodeAsString(userDet.getBytes());
            HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
			//userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH)
			String[] adIds;
			adIds = detailNum.getAdids().split(",");
			
			// duplicate logic start
			if (reqType == 1) {
			    RolesRespDto userExistRoleRespDto = userAccessDataService.getExistingRoles(userId);
			    Map<String, List<RoleADGrpMdl>> mapList = userExistRoleRespDto.getRoles();
			    List<String> adIdExistingList = new ArrayList<>();

			    // Extracting existing adIds from user roles
			    if (mapList != null && !mapList.isEmpty()) {
			        mapList.forEach((key, roleList) -> {
			            log.info("adgroup duplicate Key: " + key);
			            roleList.stream()
			                    .map(RoleADGrpMdl::getAdgrpId)
			                    .forEach(adIdExistingList::add);
			        });
			    }
			    log.info("existing adgroup values adIdExistingList : " + adIdExistingList);

			    // Filtering out existing adIds from adIds array
			    List<String> adIdList = new ArrayList<>(Arrays.asList(adIds));
			    adIdList.removeIf(adIdExistingList::contains);
			    adIds = adIdList.toArray(new String[0]);
			}
			 
			// duplicate logic end
			
			
				GRCRequestDTO reqDto = new GRCRequestDTO();
				List<SubmitUsern> userInfo = new ArrayList<>();
				List<SubmitRolen> roleInfo = new ArrayList<>();
				reqDto.setSUBMITUSERN(userInfo);//Setting Up User Data
				reqDto.setSUBMITROLEN(roleInfo);//Setting up Role Data
				reqDto.setUPDATED_BY_ID(reqBy);//Requestor
				reqDto.setREQJUSTIFICATION(comments);
				//User Data
				SubmitUsern userN = new SubmitUsern();
				userN.setUSERID(userObj.getWwId());
				userN.setFNAME(userObj.getGivenNm());
				userN.setLNAME(userObj.getFmlyNm());
				userN.setSNC_NAME("p:CN="+userObj.getJnjEmailAddrTxt());//"p:CN=dgandava@its.jnj.com"
				userN.setACCNO(userObj.getWwId());
				Calendar curDate = Calendar.getInstance();
				Calendar plus1YearDate = Calendar.getInstance();
				plus1YearDate.add(Calendar.YEAR, 1);
				userN.setVALID_FROM(Utility.fmtYyyyMMdt(curDate.getTime()));
				userN.setVALID_TO(Utility.fmtYyyyMMdt(plus1YearDate.getTime()));
				userN.setEMAIL(userObj.getJnjEmailAddrTxt());
				userN.setUSERALIAS(userObj.getJnjMsftUsrnmTxt());
				userN.setMANAGER(userObj.getJnjSupvrWwId());
				userN.setMANAGER_NAME(userObj.getJnjSupvrName());
				userInfo.add(userN);//Adding User Data
				
				String grcSysId = userMenuDao.getUtilsConstVals("GRC_SYS_ID");
				String validFrm = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_FROM().replaceAll("-", "")+"000000":"" );
				String validTo = (!Utility.isEmpty(userN.getVALID_FROM()) ? userN.getVALID_TO().replaceAll("-", "")+"235959":"" );
				for(String adGrpId : adIds) {
					String adGrpName = absUserRequesDao.getZadGrpById(adGrpId);
	
					SubmitRolen rolen = new SubmitRolen();
					rolen.setROLE_NAME(adGrpName);					
					rolen.setSYSTEM(grcSysId);					
					rolen.setVALID_FROM(validFrm);
					rolen.setVALID_TO(validTo);
					if(reqType == 1) {//ADD
						rolen.setPROV_ACTION(6);
					}else if(reqType == 2) {//REMOVE
						rolen.setPROV_ACTION(9);
					}
					rolen.setCOMMENTS(comments);
					roleInfo.add(rolen);
				}

				String reqElement = gson.toJson(reqDto);
				log.info("Sent to URL :---------------------->"+apiUrl);

                log.info("Sent to GRC REQ :---------------------->"+reqElement);

                log.info("Sent to GRC headers :---------------------->"+headers);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(apiUrl, HttpMethod.POST, reqEntity, String.class);
				log.info("Sent to GRC respEntity :---------------------->"+respEntity);
				GRCResponseDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					for(String adGrpId : adIds) {
						String adGrpName = absUserRequesDao.getZadGrpById(adGrpId);
						log.info("Resp Body for GRC REQ:"+reqId+ " ADGROUP name: "+adGrpName+"\n"+respEntity.getBody());
						respDto = gson.fromJson(respEntity.getBody(), GRCResponseDTO.class);
						if(respDto.getMESSAGE_TYPE() != null && respDto.getMESSAGE_TYPE().equals("S") ) {
							SubmitRolen roleResponse = respDto.getSUBMITROLEN().stream().filter(role -> adGrpName.equals(role.getROLE_NAME())).findAny().orElse(null);
							if(roleResponse != null) {
								rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getREQNO(), "N"));
								log.info("resp.REQNO :"+respDto.getREQNO()+" MESSAGE: "+respDto.getMESSAGE());
							}else {
								log.info("ERROR Submitting CFIN Role to GRC System ==>Resp Body for GRC REQ:"+reqId+ "ADGROUP name: "+adGrpName+" - "+respDto.getMESSAGE_TYPE()+" - "+respDto.getMESSAGE());
								rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, "Role is not existing in SAP", "E"));
							}
						
						}else {
							log.info("ERROR Submitting CFIN Role to GRC System ==>Resp Body for GRC REQ:"+reqId+ "ADGROUP name: "+adGrpName+" - "+respDto.getMESSAGE_TYPE()+" - "+respDto.getMESSAGE());
							rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getMESSAGE(), "E"));
						}
					}
				}			
		}catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return rolesList;
	}

	@Override
	public List<IAMRequestedRoleModel> sendDataToIAM(int reqId, int reqType, String userId, String reqBy, String sysId, String comments, ReqDpendncMdl detailNum) {
		List<IAMRequestedRoleModel> rolesList = new ArrayList<>();
		try{
			String iamSessionId = dataSubmissionService.getIamRequestSession();
			HttpHeaders headers = iAMDataExchangeBean.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();
			String[] adIds;
			adIds = detailNum.getAdids().split(",");
			// duplicate logic start
				if (reqType == 1) {
				    RolesRespDto userExistRoleRespDto = userAccessDataService.getExistingRoles(userId);
				    Map<String, List<RoleADGrpMdl>> mapList = userExistRoleRespDto.getRoles();
				    List<String> adIdExistingList = new ArrayList<>();

				    // Extracting existing adIds from user roles
				    if (mapList != null && !mapList.isEmpty()) {
				        mapList.forEach((key, roleList) -> {
				            log.info("adgroup duplicate Key: " + key);
				            roleList.stream()
				                    .map(RoleADGrpMdl::getAdgrpId)
				                    .forEach(adIdExistingList::add);
				        });
				    }
				    log.info("existing adgroup values adIdExistingList : " + adIdExistingList);

				    // Filtering out existing adIds from adIds array
				    List<String> adIdList = new ArrayList<>(Arrays.asList(adIds));
				    adIdList.removeIf(adIdExistingList::contains);
				    adIds = adIdList.toArray(new String[0]);
				}
				 
				// duplicate logic end
			for(String adGrpId : adIds) {
				String adGrpName = absUserRequesDao.getZadGrpById(adGrpId);
				IamAdGrpRequestDTO reqDto = new IamAdGrpRequestDTO();
				reqDto.setCCC_RequestType(Constants.GRP_MEMBERSHIP);
				reqDto.setCCC_Reason(comments);
				if(reqType == 1) {//ADD
					reqDto.setCCC_ActionType(Constants.TYPE_ADD);
				}else if(reqType == 2) {//REMOVE
					reqDto.setCCC_ActionType(Constants.TYPE_REMOVE);
				}
				reqDto.setCCC_Requestor(reqBy);
				//reqDto.setCCC_Requestor("SA-HCS-SOD_DB_USER");
				reqDto.setCCC_ResourceName(adGrpName);
				reqDto.setCCC_Recipient(userId);

				IamAdGrpRequestObj reqObj = new IamAdGrpRequestObj();//
				reqObj.setValues(reqDto);
				String reqElement = gson.toJson(reqObj);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				log.debug("---------> reqElement :"+reqElement);
				log.debug("---------> headers :"+headers);
				log.debug("---------> reqEntity :"+reqEntity);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM, HttpMethod.POST, reqEntity, String.class);
				IamAdGrpServiceSubRespDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					log.info("Resp Body: "+respEntity.getBody());
					respDto = gson.fromJson(respEntity.getBody(), IamAdGrpServiceSubRespDTO.class);
					log.info("resp.UID :"+respDto.getUid()+" URI: "+respDto.getUri());
				}else {
					respDto = new IamAdGrpServiceSubRespDTO();
					respDto.setUid("");
					respDto.setUri("");
				}
				rolesList.add(createIamRoleModel(reqId, userId, sysId, comments, reqBy, adGrpId, adGrpName, respDto.getUid(), "N"));
			}
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }

		return rolesList;
	}
	
	@Override
	public boolean pingIAM( String comments) {		
		boolean status = false;
		try{
			String iamSessionId = dataSubmissionService.getIamRequestSession();
			HttpHeaders headers = iAMDataExchangeBean.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();								
			HttpEntity<String> reqEntity = new HttpEntity<>(headers);
			String submUid = "944c7e5a-d265-4442-811a-686eb8d0280c";
			ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM+"/"+submUid, HttpMethod.GET, reqEntity, String.class);
			IamAdGrpServiceSubRespDTO respDto = null;
			if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
				log.info("Resp Body: "+respEntity.getBody());
				respDto = gson.fromJson(respEntity.getBody(), IamAdGrpServiceSubRespDTO.class);
				log.info("resp.UID :"+respDto.getUid()+" URI: "+respDto.getUri());
				status = true;
			}else {		
				status = false;
			}							
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }

		return status;
	}
	
	/*
	@Override
	public boolean pingIAM( String comments) {		
		boolean status = false;
		try{
			String iamSessionId = dataSubmissionService.getIamRequestSession();
			HttpHeaders headers = iAMDataExchangeBean.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();									
				IamAdGrpRequestDTO reqDto = new IamAdGrpRequestDTO();
				reqDto.setCCC_RequestType(Constants.GRP_MEMBERSHIP);
				reqDto.setCCC_Reason(comments);
					reqDto.setCCC_ActionType(Constants.TYPE_ADD);				
				reqDto.setCCC_Requestor("SA-HCS-SOD_DB_USER");
				reqDto.setCCC_ResourceName("test");
				reqDto.setCCC_Recipient("test");

				IamAdGrpRequestObj reqObj = new IamAdGrpRequestObj();
				reqObj.setValues(reqDto);
				String reqElement = gson.toJson(reqObj);
				HttpEntity<String> reqEntity = new HttpEntity<>(reqElement, headers);
				ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM, HttpMethod.POST, reqEntity, String.class);
				IamAdGrpServiceSubRespDTO respDto = null;
				if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
					log.info("Resp Body: "+respEntity.getBody());
					respDto = gson.fromJson(respEntity.getBody(), IamAdGrpServiceSubRespDTO.class);
					log.info("resp.UID :"+respDto.getUid()+" URI: "+respDto.getUri());
					status = true;
				}else {					
					status = false;
				}							
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }

		return status;
	} 
*/
	@Override
	public int updateIamGrcRequestStatus(int reqId, int status) {
		int updCount=0;
		try {
			updCount = absUserRequesDao.updateIamGrcRequestStatus(reqId, status);
		} catch (Exception e) {
			log.error("ERROR Updating Req status: "+e.getMessage(), e);
		}
		return updCount;
	}



	private  IAMRequestedRoleModel createIamRoleModel(int reqId, String userId, String sysId, String comments, String reqBy, String adGrpId, String adGrpName, String submUid, String submStatus) {
		IAMRequestedRoleModel mdl = new IAMRequestedRoleModel();
		mdl.setReqId(reqId);
		mdl.setUserId(userId);
		mdl.setSysId(sysId);
		mdl.setComments(comments);
		mdl.setSysName("");
		mdl.setReqBy(reqBy);
		mdl.setPosId("");
		mdl.setPosName("");
		mdl.setPvId("");
		mdl.setPvName("");
		mdl.setAdgrpId(adGrpId);
		mdl.setAdgrpName(adGrpName);
		mdl.setSubmUid(submUid);
		mdl.setSubmDate(new Date());
		mdl.setSubmStatus(submStatus);
		return mdl;
	}


	@Override
	public List<AbsUserReqMdl> getAllEDALReqSubmittedToIAM() {
		List<AbsUserReqMdl> userReqs = new ArrayList<>();
		try{
			List<AbsUserReqMdl> allReqs = absUserRequesDao.getAllEDALIamSubmittedRequests();
			for(AbsUserReqMdl reqMdl:allReqs ) {
				UserSearchModel reqByUser = userSearchService.getUserStatusJJEDS(reqMdl.getRequestedby(), 0);
				reqMdl.setRequestedbyname(reqByUser.getFmlyNm()+" "+reqByUser.getGivenNm()+"("+reqByUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel assocUser = userSearchService.getUserStatusJJEDS(reqMdl.getUserid(), 1);
				reqMdl.setUsername(assocUser.getFmlyNm()+" "+assocUser.getGivenNm()+"("+assocUser.getJnjMsftUsrnmTxt()+")");
				UserSearchModel mgrUser = userSearchService.getUserStatusJJEDS(reqMdl.getManagerid(), 1);
				reqMdl.setManagername(mgrUser.getFmlyNm()+" "+mgrUser.getGivenNm()+"("+mgrUser.getJnjMsftUsrnmTxt()+")");
				userReqs.add(reqMdl);
			}
		} catch (Exception e) {
			log.error("Error getting Request Data: "+e.getMessage(), e);
		}
		return userReqs;
	}



	@Override
	public boolean getEdalReqStatusFromIam(AbsUserReqMdl reqMdl) {
		boolean result = true;
		try {
			Date start = new Date();
			log.info("Getting EDAL REQUEST ID: "+reqMdl.getReqid()+" STARTED at time: "+Utility.fmtMMDDYYYYTime(start));
			List<IAMRequestedRoleModel> reqDetLst = absUserRequesDao.getEdalIamReqSubmittedRoles(reqMdl.getReqid()+"");

			if(reqDetLst != null && !reqDetLst.isEmpty()) {
				for(IAMRequestedRoleModel detailNum : reqDetLst) {
					if(detailNum.getSysId().equals("1")) {
						//Process GRC Data Send
						GRCAdGrpServiceStatusRespDTO respBody = getEdalStatusFromGRC(detailNum);
						int recsUpdated = 0;
						if(respBody != null && respBody.getResp() != null) {
							String status = "";
							String stMsg  = "";
							String errMsg = "";
							if( respBody.getResp().getROLE_STATUS().equalsIgnoreCase("APPROVED")) {
								status = Constants.ST_COMPLTED; stMsg  = reqMdl.getTypeid() == 2 ? "Role Removed" : "Role Assigned"; errMsg = "";
								//status = Constants.ST_COMPLTED; stMsg  = "Role Assigned"; errMsg = "";
							}else if(respBody.getResp().getROLE_STATUS().equalsIgnoreCase("PENDING") ) {
								status = Constants.ST_PENDING; stMsg  = ""; 	errMsg = "";
							}else if(respBody.getResp().getROLE_STATUS().equalsIgnoreCase("ERROR") ) {
								status = Constants.ST_ERROR; stMsg  = ""; 	errMsg = "Request Failed in GRC";
							}else if(respBody.getResp().getROLE_STATUS().equalsIgnoreCase("REJECTED") ) {
								status = Constants.ST_REJECTED; stMsg  = "Rejected in GRC"; errMsg = "Rejected in GRC";
							}else if(respBody.getResp().getROLE_STATUS().equalsIgnoreCase("CANCELLED") ) {
								status = Constants.ST_CANCELLED; stMsg  = "Cancelled by GRC"; errMsg = "Cancelled by GRC";
							}else if(respBody.getResp().getROLE_STATUS().equalsIgnoreCase("PARTIAL") ) {
								status = Constants.ST_PENDING; stMsg  = ""; errMsg = "";
							}
							recsUpdated = absUserRequesDao.updateEdalIamReqstedRolesStatus(status, stMsg, errMsg, new Date(), detailNum);
							log.info("GRC Updated ("+recsUpdated+") Records to ("+status+") Status.");
						}
					}else if(detailNum.getSysId().equals("2") || detailNum.getSysId().equals("3") || detailNum.getSysId().equals("4") || detailNum.getSysId().equals("5")){
						//GET Status from IAM
						IamAdGrpServiceStatusRespDTO iamRespBody = getEdalStatusFromIAM(detailNum);
						int recsUpdated = 0;
						if(iamRespBody != null && iamRespBody.getValues() != null) {
							String status = "";
							String stMsg  = "";
							String errMsg = "";
							if( iamRespBody.getValues().isCCC_IsComplete() && !iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_COMPLTED; stMsg  = "Role Assigned"; errMsg = "";
							}else if( !iamRespBody.getValues().isCCC_IsComplete() && !iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_PENDING; stMsg  = ""; 	errMsg = "";
							}else if(iamRespBody.getValues().isCCC_IsError() ) {
								status = Constants.ST_ERROR; stMsg  = ""; 	errMsg = iamRespBody.getValues().getCCC_ErrorMessage();
							}
							recsUpdated = absUserRequesDao.updateEdalIamReqstedRolesStatus(status, stMsg, errMsg, iamRespBody.getValues().getXDateUpdated(), detailNum);
							log.info("Updated ("+recsUpdated+") Records to ("+status+") Status.");
						}
					}
				}
			}
			log.info("Status for Edal REQUEST ID: "+reqMdl.getReqid()+" CAPTURED at time: "+Utility.fmtMMDDYYYYTime(start));
		}catch (Exception e) {
			log.error("Error processing data post to EDAL-IAM :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public IamAdGrpServiceStatusRespDTO getEdalStatusFromIAM(IAMRequestedRoleModel detailNum) {
		IamAdGrpServiceStatusRespDTO respBody = null;
		try{
			String iamSessionId = dataSubmissionService.getIamRequestSession();
			HttpHeaders headers = iAMDataExchangeBean.getHeaders("JSON", iamSessionId);
			Gson gson = new Gson();
			String submId = detailNum.getSubmUid().trim();
			String reqElement = "";
			HttpEntity<String> reqEntity = new HttpEntity<>(headers);
			ResponseEntity<String> respEntity = restHttpTemplate.exchange(Constants.cccWebReqUrlIAM+"/"+submId, HttpMethod.GET, reqEntity, String.class);

			if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
				log.info("Resp Body: "+respEntity.getBody());
				respBody = gson.fromJson(respEntity.getBody(), IamAdGrpServiceStatusRespDTO.class);
				log.info("resp.STATUS COMPLETE:"+respBody.getValues().isCCC_IsComplete()+" IS ERROR: "+respBody.getValues().isCCC_IsError());
			}else {
				respBody = new IamAdGrpServiceStatusRespDTO();
				respBody.setUri("");
			}
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return respBody;
	}


	//@Override
	public GRCAdGrpServiceStatusRespDTO getEdalStatusFromGRC(IAMRequestedRoleModel detailNum) {
		GRCAdGrpServiceStatusRespDTO respBody = new GRCAdGrpServiceStatusRespDTO();
		try{
			Base64 b = new Base64();
			String userDet = userMenuDao.getUtilsConstVals(Constants.GRC_API_AUTH);
			String apiUrl  = userMenuDao.getUtilsConstVals(Constants.GRC_API_URL);
            String encoding = b.encodeAsString(userDet.getBytes());
            HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
			Gson gson = new Gson();
			String submId = detailNum.getSubmUid().trim();
			HttpEntity<String> reqEntity = new HttpEntity<>(headers);
			//http://asgs200.jnj.com:8000/zacc_req_driver?REQNO=813360
			ResponseEntity<String> respEntity = restHttpTemplate.exchange(apiUrl+"?REQNO="+submId, HttpMethod.GET, reqEntity,  String.class);
			if (respEntity != null && respEntity.getStatusCode() == HttpStatus.OK) {
				log.info("Resp Body: "+respEntity.getBody());
				GRCAdGrpResponse[] resp = gson.fromJson(respEntity.getBody(), GRCAdGrpResponse[].class);
				if(resp.length > 0) {
					respBody.setResp(resp[0]);
				}
				log.info("resp.STATUS COMPLETE:"+resp[0].getREQUEST_NO()+" : "+resp[0].getROLE_STATUS());
			}
		 }catch(Exception e) {
    		 log.error("Error processing Details Data :"+e.getMessage(), e);
    	 }
		return respBody;
	}




	@Override
	public int getEdalRequestCount(String reqId) {
		int count=0;
		try {
			count  = absUserRequesDao.getRequestChildCount(reqId);
		} catch (Exception e) {
			log.error("ERROR Getting Count of Requests Child Items: "+e.getMessage(), e);
		}
		return count;
	}


	@Override
	public List<String> getCompltdReqStat(String reqId) {
		List<String> dataLst = new ArrayList<>();
		try {
			dataLst  = absUserRequesDao.getCompletedReqStatus(reqId);
		} catch (Exception e) {
			log.error("ERROR Getting Status of Requests Child Items: "+e.getMessage(), e);
		}
		return dataLst;
	}


	@Override
	public int updateIamRequestStatus(int reqId, int status) {
		int updCount=0;
		try {
			updCount  = absUserRequesDao.updateIamRequestStatus(reqId+"", status);
		} catch (Exception e) {
			log.error("ERROR Updating Req status: "+e.getMessage(), e);
		}
		return updCount;
	}


	/*@Override
	public ReqSrchConstDto getSearchConstants() {
		ReqSrchConstDto respDto = new ReqSrchConstDto();
		try {
			List<ReqSrchConstMdl> consLst = getAllSrchConstants();
			respDto.setSrchConst(consLst);
			respDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc(e.getMessage());
			log.error("ERROR search constants Data :"+e.getMessage(), e);
		}
		return respDto;
	}
*/

	/*@Override
	public List<ReqSrchConstMdl> getAllSrchConstants() throws Exception {
		List<ReqSrchConstMdl> consLst = new ArrayList<>();
		consLst = absUserRequesDao.getAllSrchConstants();
		return consLst;
	}*/


	/*@Override
	public ReqCountRespDto searchPendingReqCount(String userId) {
		ReqCountRespDto respDto = new ReqCountRespDto();
		respDto.setUserId(userId);
		int pendingReqCount = 0;
		try{
			pendingReqCount = absUserRequesDao.getCountOfPendingRequest(userId);
			respDto.setPendingReqCount(pendingReqCount);
			respDto.setStatusCode(Constants.SUCCESS);
		} catch (Exception e) {
			respDto.setStatusCode(Constants.SERV_ERR);
			respDto.setStatusDesc(e.getMessage());
			respDto.setPendingReqCount(pendingReqCount);
			log.error("ERROR Getting pending request counts Data :"+e.getMessage(), e);
		}
		return respDto;
	}*/





}
