package com.jnj.rqc.sch;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CriticalRoleModel {
	private String platform;
	private String role;
	private String createdBy;
	private Date createdDate;

	@Override
	public String toString() {
		return "CriticalRoleModel [platform=" + platform + ", role=" + role + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + "]";
	}


}


