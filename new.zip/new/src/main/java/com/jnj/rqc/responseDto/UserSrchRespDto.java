package com.jnj.rqc.responseDto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.models.UserSearchModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserSrchRespDto {
	private int statusCode;
	private String message;
	private String userID;
	private String datetimeStamp;
	private String statusDesc;
	private String developerMessage;
	private List<UserSearchModel> users;

}
