package com.jnj.rqc.daoImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.AppEmailRoutingDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.AppRoutingModel;




@Service
public class AppEmailRoutingDaoImpl  extends BaseDao implements AppEmailRoutingDao {
	static final Logger log = LoggerFactory.getLogger(AppEmailRoutingDaoImpl.class);



	@Override
	public List<AppRoutingModel> getAppRoutingData() throws SQLException, DataAccessException  {
		List<AppRoutingModel> routingData = new ArrayList<>();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ag.display AS GRP_DISPLAY, a1.display AS ROLE_DISPLAY, ag.appln_grp_descn AS CATEGORY, a1.appln_nm AS ROLE ");
		sql.append(" ,a2.appln_nm AS ROLE_ACTION, ace.email AS EMAIL");
		sql.append(" FROM tiptop.appln_grp ag ,tiptop.appln a1 ,tiptop.appln a2 ,tiptop.appln_catg_email ace ");
		sql.append(" WHERE a1.appln_id = a2.parnt_evnt AND a1.appln_nm != a2.appln_nm AND a1.appln_grp_id = a2.appln_grp_id ");
		sql.append(" AND a1.appln_grp_id = ag.appln_grp_id AND a2.appl_catg = ace.appln_catg_cd ");
		sql.append(" ORDER BY ag.appln_grp_descn ");

		routingData = getJdbcTemplate().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(AppRoutingModel.class));
		log.info("Total rows returned : "+((routingData !=null) ? routingData.size():"0"));
		return routingData;
	}



/*	@Override
	public List<RuleSetModel> getRuleSetData(String app1, String app2) throws SQLException, DataAccessException {
		log.info("APP1 :"+app1+"   APP2 :"+app2);
		List<RuleSetModel> dataList = new ArrayList<RuleSetModel>();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT APP1, APP2, substr(CONFLICT, 0, (instr(CONFLICT, '"+"\\"+"')-1)) as ROLE1, ");
		sql.append(" substr(CONFLICT, instr(CONFLICT, '"+"\\"+"')+1) as ROLE2, MITIGATING_CONTROL ");
		sql.append(" FROM SOD_EXTR.CONFLICT_MATRIX ");
		sql.append(" WHERE APP1=? and APP2 = ? ");

		dataList = getJdbcTemplate().query(sql.toString(), new Object[] {app1, app2}, new BeanPropertyRowMapper<RuleSetModel>(RuleSetModel.class));
		log.info("Total rows returned : "+((dataList !=null) ? dataList.size():"0"));
		return dataList;
	}
*/







/*

 *
 * @Override
	public List<AppRoles> getTktRoles(String[] ticketNo) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<AppRoles>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<AppRoles>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}


	@Override
	public List<AppRoles> getTktAppRoles(String[] ticketNo, List<Integer> appIds ) throws SQLException, DataAccessException {
		List<AppRoles> appData = new ArrayList<AppRoles>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT b.tickt_no, a.parnt_evnt, a.appln_nm appln_shrt_nm, a.appln_nm || ' ' || c.appln_grp_descn appln_nm, b.stat_cd, b.appln_id, " );
		sql.append(" b.aprvl_dt as aprvdate, b.schdd_dt as scheddate, b.impln_dt as impdate ");
		sql.append(" FROM appln a, cli_appln b, appln_grp c ");
		sql.append(" WHERE a.appln_id = b.appln_id " );
		sql.append(" AND b.tickt_no  in ( ");
		String vars="";
		for(int i=0; i<ticketNo.length; i++) {
			if(vars.equals("")) {
				vars+=" ? ";
			}else {
				vars+=", ? ";
			}
		}
		sql.append(" "+vars+" ) ");
		sql.append(" AND a.appln_grp_id = c.appln_grp_id and c.sftw_ind = 'N' AND a.parnt_evnt = a.appln_id ");
		if(appIds != null && !appIds.isEmpty()) {
			sql.append(" AND a.APPLN_GRP_ID in ( ");
			for(int j=0;j<appIds.size();j++) {
				if(j==0) {
					sql.append(" "+appIds.get(j));
				}else {
					sql.append(", "+appIds.get(j));
				}
			}
			sql.append(" ) ");
		}

		sql.append(" ORDER BY b.tickt_no ");

		appData = getJdbcTemplate().query(sql.toString(), ticketNo, new BeanPropertyRowMapper<AppRoles>(AppRoles.class));
		log.info("Total rows returned : "+((appData !=null && !appData.isEmpty()) ? appData.size():"0"));
		return appData;
	}




*/


}
