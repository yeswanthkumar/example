package com.jnj.rqc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableAsync;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


@EnableAsync
@SpringBootApplication
@EnableSwagger2
@ServletComponentScan
public class RQCUtilsApplication  extends SpringBootServletInitializer{
	static final Logger log = LoggerFactory.getLogger(RQCUtilsApplication.class);

	 @Override
	 protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		 return application.sources(RQCUtilsApplication.class);
	 }

	public static void main(String[] args) {
		log.info("Launch RQCUtilsApplication.........START");
		SpringApplication.run(RQCUtilsApplication.class, args);
		/*SpringApplication app = new SpringApplication(RQCUtilsApplication.class);
		app.setDefaultProperties(Collections.singletonMap("server.port", "8083"));
		app.run(args);
		 */
		log.info("Launch RQCUtilsApplication.........Complete");
	}

}
