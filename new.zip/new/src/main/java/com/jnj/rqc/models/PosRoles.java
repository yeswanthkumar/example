package com.jnj.rqc.models;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PosRoles {
	private int roleId;
	private String roleName;
	private String roleDescn;
	private List<RoleFunction> functions;

	public PosRoles(int roleId, String roleName, String roleDescn){
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleDescn = roleDescn;
	}

	@Override
	public String toString() {
		return "PosRoles [roleId=" + roleId + ", roleName=" + roleName + ", roleDescn=" + roleDescn + "]";
	}


}
