package com.jnj.rqc.sch;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TrfCntrlTransDataMdl {
	private String 	region;
	private String 	platform;
	private String 	environment;
	private String 	system;
	private String 	description;
	private String 	details;
	private String 	userNtId;
	private String 	wwid;
	private String 	createdBy;
	private Date 	createdDt;

	@Override
	public String toString() {
		return "TrfCntrlTransDataMdl [region=" + region + ", platform=" + platform + ", environment=" + environment
				+ ", system=" + system + ", description=" + description + ", details=" + details + ", userNtId="
				+ userNtId + ", wwid=" + wwid + ", createdBy=" + createdBy + ", createdDt=" + createdDt + "]";
	}





}


