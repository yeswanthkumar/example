package com.jnj.rqc;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.jnj.rqc.common.models.SAPTrfMdl;
import com.jnj.rqc.util.Utility;




public class ManualLoadTrnfCntrlData {
	public static DateFormat dtFmtTime  = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	public static void main(String[] args) throws IOException {
		String dirPath ="D:\\Users\\DChauras\\RQC\\SOD_AUTOMATION_Anand\\MANUAL_UPLOAD\\08172021";
		File folder = new File(dirPath);
    	File[] files = folder.listFiles();
    	for(File fl : files) {
    		String path = fl.getAbsolutePath();
    		System.out.println("\nSTARTED Processing file :"+path+"  @:"+fmtMMDDYYYYTime(new Date()));
    		List<SAPTrfMdl> trfLst = readExcel(path);
    		System.out.println("Total Rows extracted:"+trfLst.size());
    		Connection conn = getConnection();
    		int totalRec =  insertData(trfLst, conn);
    		System.out.println("Total Records Inserted: "+totalRec);
    		System.out.println("COMPLETED Processing file :"+path+"  @:"+fmtMMDDYYYYTime(new Date())+"\n");
    	}
    }



	private static int insertData(List<SAPTrfMdl> trfLst, Connection conn) {
		int insRec=0;
		PreparedStatement ps= null;
		try{
			String qry=" Insert into ERP_TRANSFER_DATA (SAP_PLATFORM, SAP_SYSTEM, DESCRIPTION_DETAILS, DETAILS, USER_NTID, WWID)  Values  (?, ?, ?, ?, ?, ?) ";
			ps=conn.prepareStatement(qry);
			for(SAPTrfMdl data: trfLst) {
				ps.setString(1, data.getSapPlatform());
				ps.setString(2, data.getSystemClient());
				ps.setString(3, data.getDescription());
				ps.setString(4, data.getDetails());
				ps.setString(5, data.getSapId());
				ps.setString(6, data.getWwid());
				ps.addBatch();
			}
			int[] affectedRecords = ps.executeBatch();
			insRec=affectedRecords.length;
		} catch (Exception e) {
			System.out.println("Error Inserting Data:"+e.getMessage());
			e.printStackTrace();
		}finally {
			try {
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
					System.out.println("Error"+e.getMessage());
					e.printStackTrace();
			}
		}
		return insRec;
	}


	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//DEV :usrnm=GENESIS_EP_DEV, pwd=Ad5Bp45_fev, url=jdbc:oracle:thin:@ITSUSRALSP02176.jnj.com:1521/DVDB5439.jnj.com
			//con = DriverManager.getConnection("jdbc:oracle:thin:@ITSUSRALSP02176.jnj.com:1521/DVDB5439.jnj.com","GENESIS_EP_DEV","Ad5Bp45_fev");
			//PROD : usrnm=GENESIS_EP_PRD, pwd=Amdb4cX_L83, url=jdbc:oracle:thin:@ITSUSRALSP03025.jnj.com:1521/CRAP0190.jnj.com
			con = DriverManager.getConnection("jdbc:oracle:thin:@ITSUSRALSP03025.jnj.com:1521/CRAP0190.jnj.com","GENESIS_EP_PRD","Amdb4cX_L83");
		} catch (Exception e) {
			System.out.println("Error Getting connection :"+e.getMessage()+"\n");
			e.printStackTrace();
		}
		return con;
	}

	public static String fmtMMDDYYYYTime(Date date) {
		if(date == null) {
			date = new Date();
		}
		return dtFmtTime.format(date);
	}


	private static List<SAPTrfMdl> readExcel(String path){
		System.out.println("Loding file :"+path);
		List<SAPTrfMdl> trfLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			System.out.println("Total number of Rows(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				SAPTrfMdl rskMdl	= new SAPTrfMdl();
				String platform	 		= Utility.getCellValue(rw.getCell(0));
				rskMdl.setSapPlatform(platform);
				String systm 		= Utility.getCellValue(rw.getCell(1));
				rskMdl.setSystemClient(systm);
				String desc 			= Utility.getCellValue(rw.getCell(2));
				rskMdl.setDescription(desc);
				String dtls  		= Utility.getCellValue(rw.getCell(3));
				rskMdl.setDetails(dtls);
				String ntId 			= Utility.getCellValue(rw.getCell(4));
				rskMdl.setSapId(ntId);
				rskMdl.setNtId(ntId);
				String wwid	  	= Utility.getCellValue(rw.getCell(5));
				rskMdl.setWwid(wwid);
				trfLst.add(rskMdl);
				i++;
			}
		}
		System.out.println("Total Records to Process : "+trfLst.size());
		return trfLst;
	}



}





/*		Connection con ;
		try {
				String sql = "Select USERNAME as USER_ID FROM DBA_AUD.USER_AUDT ";
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@hcswmp02.jnj.com:1524:HCSOP11","dchauras","Emerald2021#");
				 if(con != null) {
					 System.out.println("Connected");
				 }
				 Statement stmt = con.createStatement();
				 ResultSet rs = stmt.executeQuery(sql) ;
				 int i = 1;
				 while(rs.next()) {
					 System.out.println(i+". "+rs.getString(1));
					 i++;
				 }
				 try {
					rs.close();
					stmt.close();
					con.close();
				} catch (Exception ee) {
					System.out.println("ERROR:"+ee.getMessage());
				}

			} catch(Exception e) {
				System.out.println("ERROR:"+e.getMessage());
				e.printStackTrace();
			}*/


		//String str = "ABC/AR";
		/*int chunkSize=5;
		String[] str= {"1","2","3","4","5","6","7","8","9"};

		List<String[]> lst = getArrayLst(str, chunkSize);

		for(String[] arr : lst) {
			System.out.println("Str[]: "+arr.toString());
		}
*/







		/*Connection con ;
		try {
				String sql = "Select * from sod_extr.system_code";
				 Class.forName("oracle.jdbc.driver.OracleDriver");
				 con = DriverManager.getConnection("jdbc:oracle:thin:@ITSUSRALSP06534.JNJ.COM:1521/MRAP0751.JNJ.COM","tiptop","smile4fun!");
				 Statement stmt = con.createStatement();
				 ResultSet rs = stmt.executeQuery(sql) ;
				 int i = 1;
				 while(rs.next()) {
					 System.out.println(i+". "+rs.getString(1)+" - "+rs.getString(2)+" - "+rs.getString(3));
					 i++;
				 }
				 try {
					rs.close();
					stmt.close();
					con.close();
				} catch (Exception ee) {
					System.out.println("ERROR:"+ee.getMessage());
				}

			} catch(Exception e) {
				System.out.println("ERROR:"+e.getMessage());
				e.printStackTrace();
			}
		 */


		/*String str = "CN=VALERIE HAYDEN,OU=18701,OU=Employees,O=JNJ,DC=jjedsed,DC=jnj,DC=com";

		String [] arr =str.split(",");

		String mgrNm = arr[0].split("=")[1];
		String mgrWwid = arr[1].split("=")[1];
		System.out.println("mgrNm:"+mgrNm);
		System.out.println("mgrWwid:"+mgrWwid);*/

		/*String fl= "D:/Users/DChauras/RQC/TERMINATIONS/USER_DATA/WMS_MLC_User data.xls";

		Path path = Paths.get(fl);
		System.out.println(path.toFile());
		System.out.println("Last Modified:"+((System.currentTimeMillis() - path.toFile().lastModified())/(1000*60)));

		long start =  path.toFile().lastModified();
		long end =System.currentTimeMillis();
		long diff = (System.currentTimeMillis() - path.toFile().lastModified());
		System.out.println("Difference:"+TimeUnit.MILLISECONDS.toMinutes(diff));
		*/


		/*int [] first = {1,2,3, 4};
        int [] second = {5,6,7,8};

        int [] combined = ArrayUtils.addAll(first, second);

        System.out.println("First array : " + Arrays.toString(first));
        System.out.println("Second array : " + Arrays.toString(second));
        System.out.println("Combined array : " + Arrays.toString(combined));

	*/

		//String fileName="D:/Users/DChauras/STSNewWorkSpace/xlsCache/Dharm_LatestReview.xlsx";
		//String nm =fileName.substring(fileName.lastIndexOf(".")+1);
		//System.out.println("File Ext:"+nm);

		/*DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		int month = 4;
		int year = 2019;

		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.MONTH, 4);
		cal.set(Calendar.YEAR, year);
		System.out.println(formatter.format(cal.getTime()));

		cal.set(Calendar.YEAR, (cal.get(Calendar.YEAR)-1));
		cal.set(Calendar.MONTH, (cal.get(Calendar.MONTH) - 3));

		System.out.println(formatter.format(cal.getTime()));*/

		//String [] header = "ACCOUNT NAME, ACC FIRST COLLECTED, ACC LAST CCOLLECTED, WWID, FULL NAME, NETWORK ID, EMAIL ADDRESS, TITLE, DEPARTMENT, GRP SHORT NAME, GROUP NAME, GROUP, ROLE, DATE ADDED, SODCODE, TICKET NUMBER".split(",");
		//System.out.println("Length:"+header.length);




		/*//String str ="PROJECTDATABASED:\\PDB\\PRJ\\AEPQC_BASE_UNIX(#1)";
		String str = "USER\"JARMENI4\"|CHANGECONTROL_PROMOTE|CHANGECONTROL|CHANGECONTROL_GET";
		String str1 = (str.substring(5)).replaceAll("\"", "");
		System.out.println(str1);*/
/*
	}



	public static List<String[]> getArrayLst(String[] str, int chunkSize){
		List<String[]> lst = new ArrayList<String[]>();
		int totalSize = str.length;
		if(totalSize < chunkSize ){
		   chunkSize = totalSize;
		}
		int from = 0;
		int to = chunkSize;

		while(from < totalSize){
		    String[] partArray = Arrays.copyOfRange(str, from, to);
		    lst.add(partArray);
		    from+= chunkSize;
		    to = from + chunkSize;
		    if(to > totalSize){
		        to = totalSize;
		    }
		}

		return lst;
	}

}
*/