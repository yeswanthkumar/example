package com.jnj.rqc.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UsrJJEdsMdl {
		private String wwid;
		private String ntId;
		private String fullName;
		private String email;
		private String title;
		private String dept;
		private Date termDt;

		@Override
		public String toString() {
			return "UsrJJEdsMdl [wwid=" + wwid + ", ntId=" + ntId + ", fullName=" + fullName + ", email=" + email
					+ ", title=" + title + ", dept=" + dept + ", termDt=" + termDt + "]";
		}



}
