package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.UserSearchDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.JJEDsUserLookupMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>UserSearchServiceImpl.java</b>
 * @author : DChauras @Created : Dec 11, 2019 5:14:24 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class UserSearchServiceImpl implements UserSearchService {
	static final Logger log = LoggerFactory.getLogger(UserSearchServiceImpl.class);

	@Autowired
	UserSearchDao userSearchDao;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;



	@Override
	public List<JJEDsUserLookupMdl> getAllUserData(List<String> usrIds) {
		List<JJEDsUserLookupMdl> finalData = new LinkedList<>();
		for(String userId:usrIds) {
			UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(userId, 0);
			JJEDsUserLookupMdl exlMdl = new JJEDsUserLookupMdl();
			if(srchUsr != null) {
				exlMdl.setWwId(srchUsr.getWwId());
				exlMdl.setJnjMsftUsrnmTxt(srchUsr.getJnjMsftUsrnmTxt());
				exlMdl.setUserName(srchUsr.getGivenNm()+" "+srchUsr.getFmlyNm());
				exlMdl.setEmpStatTxt(srchUsr.getEmpStatTxt());
				exlMdl.setTermnnDt(srchUsr.getTermnnDt());
				exlMdl.setJnjEmailAddrTxt(srchUsr.getJnjEmailAddrTxt());

				//Search Supervisor
				if(!Utility.isEmpty(srchUsr.getJnjSupvrWwId())) {
					exlMdl.setJnjSupvrWwId(srchUsr.getJnjSupvrWwId());
					UserSearchModel usrMgr = sAPExtrGaaDataService.getUserStatusJJEDS(srchUsr.getJnjSupvrWwId(), 0);
					if(usrMgr != null) {
						exlMdl.setJnjSupvrNtId(usrMgr.getJnjMsftUsrnmTxt());
						exlMdl.setJnjSupvrName(usrMgr.getGivenNm()+" "+usrMgr.getFmlyNm());
						exlMdl.setJnjSupvrEmail(usrMgr.getJnjEmailAddrTxt());
					}
				}else {
					exlMdl.setJnjSupvrWwId("");
					exlMdl.setJnjSupvrName("NOT FOUND");
				}
			}else {
				exlMdl.setJnjMsftUsrnmTxt(userId);
				exlMdl.setUserName("NO DATA FOUND");
			}
			finalData.add(exlMdl);
		}
		return finalData;
	}



	@Override
	public List<String> readUserIdExcel(String path){
		log.info("Loding file :"+path);
		List<String> idLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			System.out.println("Total number of Rows(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				String usrId	= Utility.getCellValue(rw.getCell(0));
				if(!Utility.isEmpty(usrId)) {
					if(!idLst.contains(usrId)) {
						idLst.add(usrId);
					}
					i++;
				}
			}
		}
		System.out.println("Total Records to Process : "+idLst.size());
		return idLst;
	}




	@Override
	@SuppressWarnings("all")
	public List<UserSearchModel> getUserData(int srchParam, String data, int status) {
		List<UserSearchModel> result = new ArrayList<>();
		try{
			data = data.toUpperCase().trim();
			List<Object> dataParams = Arrays.asList(data.split(","));
			//dataParams = dataParams.stream().map(String :: trim).collect(Collectors.toList());

			if(srchParam == 1) {
				result = userSearchDao.getAllUsersByWWId(dataParams, status);
			}else
				if(srchParam == 2){
					result = userSearchDao.getAllUsersByNTId(dataParams, status);
			}else
				if(srchParam == 3){
					result = userSearchDao.getAllUsersByFmlyNm(dataParams);
			}else
				if(srchParam == 4){
					result = userSearchDao.getAllUsersByFirstNm(dataParams);
			}else
				if(srchParam == 5){
					result = userSearchDao.getAllUsersByEmail(dataParams, status);
			}

		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	@SuppressWarnings("all")
	public List<UserSearchModel> getUserDataForReport(int srchParam, String data, int status) {
		List<UserSearchModel> result = new ArrayList<>();
		try{
			data = data.toUpperCase().trim();
			List<Object> dataParams = Arrays.asList(data.split(","));
			//dataParams = dataParams.stream().map(String :: trim).collect(Collectors.toList());

			if(srchParam == 1) {
				result = userSearchDao.getAllUsersByWWIdReport(dataParams, status);
			}else
				if(srchParam == 2){
					result = userSearchDao.getAllUsersByNTId(dataParams, status);
			}else
				if(srchParam == 3){
					result = userSearchDao.getAllUsersByFmlyNm(dataParams);
			}else
				if(srchParam == 4){
					result = userSearchDao.getAllUsersByFirstNm(dataParams);
			}else
				if(srchParam == 5){
					result = userSearchDao.getAllUsersByEmail(dataParams, status);
			}

		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}
		return result;
	}

	@Override
	@SuppressWarnings("all")
	public List<UserSearchModel> getUserDataByFN(String firstName, String lastName, int status) {
		List<UserSearchModel> result = new ArrayList<>();
		try{
			String fName = firstName.toUpperCase().trim();
			String lName = lastName.toUpperCase().trim();
			result = userSearchDao.getAllUsersByFirstNmLstNm(fName, lName, status);
		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}
		return result;
	}


	@Override
	@SuppressWarnings("all")
	public List<UserSearchModel> getUserDataByNtId(String data, int status) {
		List<UserSearchModel> result = new ArrayList<>();
		try{
			data = data.toUpperCase().trim();
			List<Object> dataParams = Arrays.asList(data.split(","));
			result = userSearchDao.getAllUsersByNTId(dataParams, status);
		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}
		return result;
	}



	@Override
	public String writeUserCSVReport(List<UserSearchModel> data) {
		String filePath = csvReportWriter.writeUserCSVReport(data, "JJEDSUserData"+Utility.fmtMDY(new Date())+".csv");
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public String writeAllUserCSVReport(List<JJEDsUserLookupMdl> data) {
		String filePath = csvReportWriter.writeAllUserCSVReport(data, "JJEDSUserData_"+Utility.fmtMDY(new Date())+".csv");
		log.info("CSV File Path: "+filePath);
		return filePath;
	}

	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadUserProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}


	@Override
	public UserSearchModel getUserStatusJJEDS(String userId, int active) {
		userId= userId.toUpperCase();
		UserSearchModel srchUsr = Utility.getUser(userId);
		if(srchUsr == null){
			List<UserSearchModel> usrList = getUserListFromJJEDS(userId, active);
			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(userId, srchUsr);
			}/*else {
				Utility.setUser(userId, srchUsr);
			}*/
		}
		return srchUsr;
	}
	
	@Override
	public UserSearchModel getUserStatusJJEDSForReport(String userId, int active) {
		userId= userId.toUpperCase();
		UserSearchModel srchUsr = Utility.getUser(userId);
		if(srchUsr == null){
			List<UserSearchModel> usrList = getUserListFromJJEDSReport(userId, active);
			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(userId, srchUsr);
			}/*else {
				Utility.setUser(userId, srchUsr);
			}*/
		}
		return srchUsr;
	}

	@Override
	public List<UserSearchModel> getUserListFromJJEDS(String userId, int active) {
		List<UserSearchModel> usrList= null;
		userId= userId.toUpperCase();
		if(userId.toUpperCase().equals(userId.toLowerCase())) {
			usrList = getUserData(1, userId, active);
		}else {
			usrList = getUserData(2, userId, active);
		}
		return usrList;
	}
	
	@Override
	public List<UserSearchModel> getUserListFromJJEDSReport(String userId, int active) {
		List<UserSearchModel> usrList= null;
		userId= userId.toUpperCase();
		if(userId.toUpperCase().equals(userId.toLowerCase())) {
			usrList = getUserDataForReport(1, userId, active);
		}else {
			usrList = getUserDataForReport(2, userId, active);
		}
		return usrList;
	}



	@Override
	public UserSearchModel getUserStatusByEmailJJEDS(String emailId, int active) {
		emailId= emailId.toUpperCase();
		UserSearchModel srchUsr = Utility.getUser(emailId);
		if(srchUsr == null){
			List<UserSearchModel> usrList = getUserData(5, emailId, active);
			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(emailId, srchUsr);
			}
		}
		return srchUsr;
	}







	/*public void insertUserData(List<UserActivityModel> dataList, String system) {
		try {
			log.info("Total Rows received for system: "+system+" = "+dataList.size());
			String result = userRoleActivityDao.insertUserActivityData(dataList);
			log.info("Data insert for system :"+system+"  ... "+result);
		} catch (Exception e) {
			log.error("Error inserting User data for system: "+system+" Message: "+e.getMessage());
			e.printStackTrace();
		}
	}*/


	/* (non-Javadoc)
	 * @see com.jnj.rqc.service.UserRoleActivityService#clearUserActCache()
	 */
	/*public boolean clearUserActCache(){
		boolean clearData = false;
		try {
			clearData = userRoleActivityDao.clearUserCache();
		} catch (Exception e) {
			log.info("ERROR Clearing User Cache :"+e.getMessage());
			e.printStackTrace();
		}

		return clearData;
	}*/






}
