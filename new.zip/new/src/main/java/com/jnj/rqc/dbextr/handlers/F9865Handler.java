package com.jnj.rqc.dbextr.handlers;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dao.DBExtrDao;
import com.jnj.rqc.dbextr.factory.IDBExtProcessor;
import com.jnj.rqc.dbextr.models.F9865Mdl;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class F9865Handler implements IDBExtProcessor {
	static final Logger log = LoggerFactory.getLogger(F9865Handler.class);

	@Autowired
	DBExtrDao dBExtrDao;

	@Override
	public String process() throws SQLException, DataAccessException{
		log.info("Retrieving Data for: OBJ7333.F9865 ");
		String filePath = "";
		List<F9865Mdl> dataList = getF9865Data();
		if(dataList != null && !dataList.isEmpty()) {
				filePath = createCSVReport("F9865", dataList);
		}
		return filePath;
	}


	private List<F9865Mdl> getF9865Data() throws SQLException, DataAccessException{
		List<F9865Mdl> dataList = dBExtrDao.getF9865Data();
		return dataList;
	}


	private String createCSVReport(String fileName, List<F9865Mdl> data) {
		 String filePath = "";
		 try{
			 fileName = fileName+"_"+Utility.fmtMDY(new Date())+".csv";
			 File csvFile = new File(fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing CCRA_CONVERSION CSV file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 String headerStr = "SWFMNM,SWFMID,SWMD,SWFMPT,SWRLS,SWENTRYPT,SWSY,SWFUNO,SWOBNM,SWAPPLID,SWHELPID1,SWHFNAME,"+
					 			"SWJDEVERS,SWMRGMOD,SWMRGOPT,SWFMC1,SWFMC2,SWFMC3,SWFMC4,SWFMC5,SWUSER,SWPID,SWJOBN,SWUPMJ,SWUPMT";
			 String [] header = headerStr.split(",");
			 writer.writeNext(header);
			 data.forEach(cd ->{
				 String [] record = cd.getData().split("~");
		    	 writer.writeNext(record);
		     });
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing CSV:"+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }



}
