package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.CSIFunctionActionModel;
import com.jnj.rqc.conflictModel.CSIFunctionPermModel;
import com.jnj.rqc.conflictModel.CSISodCriticalActRiskModel;
import com.jnj.rqc.conflictModel.CSISodRiskModel;
import com.jnj.rqc.conflictModel.RoleToSodModel;
import com.jnj.rqc.conflictModel.UserToSodModel;
import com.jnj.rqc.dao.MemberReviewDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.CSIDataService;
import com.jnj.rqc.util.Utility;



@Service
public class CSIDataServiceImpl implements CSIDataService{

	static final Logger log = LoggerFactory.getLogger(CSIDataServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	MemberReviewDao memberReviewDao;
	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;



	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadCSIProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}



	@Override
	public Map<String, List<UserToSodModel>> readUserToSodData(String path, String empId, String roleIds){
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		Map<String, List<UserToSodModel>> dataMap = new HashMap<>();
		List<UserToSodModel> dataLst = new ArrayList<>();
		List<UserToSodModel> outLst = new ArrayList<>();
		List<UserToSodModel> sodLst = new ArrayList<>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				UserToSodModel usr2Sod	= new UserToSodModel();
				String sodConflict 		= Utility.getCellValue(rw.getCell(0));
				usr2Sod.setSodConflict(sodConflict);
				String description 		= Utility.getCellValue(rw.getCell(1));
				usr2Sod.setDescription(description);
				String norm 			= Utility.getCellValue(rw.getCell(2));
				usr2Sod.setNorm(norm);
				String newNorm  		= Utility.getCellValue(rw.getCell(3));
				usr2Sod.setNewNorm(newNorm);
				String reasonCode 		= Utility.getCellValue(rw.getCell(4));
				usr2Sod.setReasonCode(reasonCode);
				String reasonCodeNorm  	= Utility.getCellValue(rw.getCell(5));
				usr2Sod.setReasonCodeNorm(reasonCodeNorm);
				String controlId  		= Utility.getCellValue(rw.getCell(6));
				usr2Sod.setControlId(controlId);
				String controlMeasure	= Utility.getCellValue(rw.getCell(7));
				usr2Sod.setControlMeasure(controlMeasure);
				String definition  		= Utility.getCellValue(rw.getCell(8));
				usr2Sod.setDefinition(definition);
				String expression		= Utility.getCellValue(rw.getCell(9));
				usr2Sod.setExpression(expression);
				String variant	 		= Utility.getCellValue(rw.getCell(10));
				usr2Sod.setVariant(variant);
				String userId 			= Utility.getCellValue(rw.getCell(11));
				usr2Sod.setUserId(userId);
				String userDescription	= Utility.getCellValue(rw.getCell(12));
				usr2Sod.setUserDescription(userDescription);
				String isSuper 			= Utility.getCellValue(rw.getCell(13));
				usr2Sod.setIsSuper(isSuper);
				String group 			= Utility.getCellValue(rw.getCell(14));
				usr2Sod.setGroup(group);
				String type 			= Utility.getCellValue(rw.getCell(15));
				usr2Sod.setType(type);
				String status 			= Utility.getCellValue(rw.getCell(16));
				usr2Sod.setStatus(status);
				String userStatus 		= Utility.getCellValue(rw.getCell(17));
				usr2Sod.setUserStatus(userStatus);
				String logicalSystem	= Utility.getCellValue(rw.getCell(18));
				usr2Sod.setLogicalSystem(logicalSystem);
				String query1 			= Utility.getCellValue(rw.getCell(19));
				usr2Sod.setQuery1(query1);
				String queryName1		= Utility.getCellValue(rw.getCell(20));
				usr2Sod.setQueryName1(queryName1);
				String queryDescription1= Utility.getCellValue(rw.getCell(21));
				usr2Sod.setQueryDescription1(queryDescription1);
				String norm1 			= Utility.getCellValue(rw.getCell(22));
				usr2Sod.setNorm1(norm1);
				String normId1 			= Utility.getCellValue(rw.getCell(23));
				usr2Sod.setNormId1(normId1);
				String authorization1 	= Utility.getCellValue(rw.getCell(24));
				usr2Sod.setAuthorization1(authorization1);
				String tCode1 			= Utility.getCellValue(rw.getCell(25));
				usr2Sod.setTCode1(tCode1);
				String executed1 		= Utility.getCellValue(rw.getCell(26));
				usr2Sod.setExecuted1(executed1);
				String causingTCodes1	= Utility.getCellValue(rw.getCell(27));
				usr2Sod.setCausingTCodes1(causingTCodes1);
				String queryTCodes1 	= Utility.getCellValue(rw.getCell(28));
				usr2Sod.setQueryTCodes1(queryTCodes1);
				String query2 			= Utility.getCellValue(rw.getCell(29));
				usr2Sod.setQuery2(query2);
				String queryName2 		= Utility.getCellValue(rw.getCell(30));
				usr2Sod.setQueryName2(queryName2);
				String queryDescription2= Utility.getCellValue(rw.getCell(31));
				usr2Sod.setQueryDescription2(queryDescription2);
				String norm2 			= Utility.getCellValue(rw.getCell(32));
				usr2Sod.setNorm2(norm2);
				String normId2 			= Utility.getCellValue(rw.getCell(33));
				usr2Sod.setNormId2(normId2);
				String authorization2 	= Utility.getCellValue(rw.getCell(34));
				usr2Sod.setAuthorization2(authorization2);
				String tCode2 			= Utility.getCellValue(rw.getCell(35));
				usr2Sod.setTCode2(tCode2);
				String executed2 		= Utility.getCellValue(rw.getCell(36));
				usr2Sod.setExecuted2(executed2);
				String causingTCodes2 	= Utility.getCellValue(rw.getCell(37));
				usr2Sod.setCausingTCodes2(causingTCodes2);
				String queryTCodes2 	= Utility.getCellValue(rw.getCell(38));
				usr2Sod.setQueryTCodes2(queryTCodes2);

				//Date addDate = Utility.strToDt(memAdDt, dtErrMsg);
				dataLst.add(usr2Sod);
				i++;
			}
		}

		//Filter User level Data
		if(empId != null && empId.length() > 0) {
			String[] empArr = empId.split(",");
			for(String usrid : empArr) {
				for(UserToSodModel usr:dataLst) {
					if(usr.getUserId().equals(usrid)) {
						outLst.add(usr);
					}
				}
			}
		}else {
			outLst.addAll(dataLst);
		}

		//Filter User level Data
		if(roleIds != null && roleIds.length() > 0) {
			String[] roles = roleIds.split(",");
			for(String role : roles) {
				for(UserToSodModel usr:dataLst) {
					if(usr.getQueryName1().equals(role) || usr.getQueryName2().equals(role)) {
						sodLst.add(usr);
					}
				}
			}
		}
		if(!sodLst.isEmpty()) {
			dataMap.put("NEWROLESSODLIST", sodLst);
		}
		dataMap.put("USER2SOD", outLst);
		log.info("Total Records for Processed(outLst) : "+outLst.size());
		return dataMap;
	}


	@Override
	public List<RoleToSodModel> readRoleToSodData(String path, String roleId){
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<RoleToSodModel> dataLst = new ArrayList<>();
		List<RoleToSodModel> outLst = new ArrayList<>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				RoleToSodModel role2Sod	= new RoleToSodModel();
				String sodConflict 		= Utility.getCellValue(rw.getCell(0));
				role2Sod.setSodConflict(sodConflict);
				String description 		= Utility.getCellValue(rw.getCell(1));
				role2Sod.setDescription(description);
				String normId 			= Utility.getCellValue(rw.getCell(2));
				role2Sod.setNormId(normId);
				String newNormId  		= Utility.getCellValue(rw.getCell(3));
				role2Sod.setNewNormId(newNormId);
				String reasonCode 		= Utility.getCellValue(rw.getCell(4));
				role2Sod.setReasonCode(reasonCode);
				String normReasonCode  	= Utility.getCellValue(rw.getCell(5));
				role2Sod.setNormReasonCode(normReasonCode);
				String definition  		= Utility.getCellValue(rw.getCell(6));
				role2Sod.setDefinition(definition);
				String expression		= Utility.getCellValue(rw.getCell(7));
				role2Sod.setExpression(expression);
				String variant	 		= Utility.getCellValue(rw.getCell(8));
				role2Sod.setVariant(variant);
				String role 			= Utility.getCellValue(rw.getCell(9));
				role2Sod.setRole(role);
				String roleDescription	= Utility.getCellValue(rw.getCell(10));
				role2Sod.setRoleDescription(roleDescription);
				String c 			= Utility.getCellValue(rw.getCell(11));
				role2Sod.setC(c);
				String isSuper 			= Utility.getCellValue(rw.getCell(12));
				role2Sod.setIsSuper(isSuper);
				String logicalSystem	= Utility.getCellValue(rw.getCell(13));
				role2Sod.setLogicalSystem(logicalSystem);
				String query1 			= Utility.getCellValue(rw.getCell(14));
				role2Sod.setQuery1(query1);
				String queryName1		= Utility.getCellValue(rw.getCell(15));
				role2Sod.setQueryName1(queryName1);
				String queryDescription1= Utility.getCellValue(rw.getCell(16));
				role2Sod.setQueryDescription1(queryDescription1);
				String norm1 			= Utility.getCellValue(rw.getCell(17));
				role2Sod.setNorm1(norm1);
				String normId1 			= Utility.getCellValue(rw.getCell(18));
				role2Sod.setNormId1(normId1);
				String authorization1 	= Utility.getCellValue(rw.getCell(19));
				role2Sod.setAuthorization1(authorization1);
				String tCode1 			= Utility.getCellValue(rw.getCell(20));
				role2Sod.setTCode1(tCode1);
				String executed1 		= Utility.getCellValue(rw.getCell(21));
				role2Sod.setExecuted1(executed1);
				String query2 			= Utility.getCellValue(rw.getCell(22));
				role2Sod.setQuery2(query2);
				String queryName2 		= Utility.getCellValue(rw.getCell(23));
				role2Sod.setQueryName2(queryName2);
				String queryDescription2= Utility.getCellValue(rw.getCell(24));
				role2Sod.setQueryDescription2(queryDescription2);
				String norm2 			= Utility.getCellValue(rw.getCell(25));
				role2Sod.setNorm2(norm2);
				String normId2 			= Utility.getCellValue(rw.getCell(26));
				role2Sod.setNormId2(normId2);
				String authorization2 	= Utility.getCellValue(rw.getCell(27));
				role2Sod.setAuthorization2(authorization2);
				String tCode2 			= Utility.getCellValue(rw.getCell(28));
				role2Sod.setTCode2(tCode2);
				String executed2 		= Utility.getCellValue(rw.getCell(29));
				role2Sod.setExecuted2(executed2);

				//Date addDate = Utility.strToDt(memAdDt, dtErrMsg);
				dataLst.add(role2Sod);
				i++;
			}
		}

		//Filter User level Data
		if(roleId != null && roleId.length() > 0) {
			String[] roleArr = roleId.split(",");
			for(String rlNm:roleArr) {
				for(RoleToSodModel rls:dataLst) {
					if(rls.getRole().equals(rlNm.trim())) {
						outLst.add(rls);
					}
				}
			}

		}else {
			outLst.addAll(dataLst);
		}

		log.info("Total Records for Processed(outLst) : "+outLst.size());
		return outLst;
	}



	@Override
	public String writeCSIUser2SodCsvReport(List<UserToSodModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSIUser2SodCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}


	@Override
	public String writeCSIRole2SodCsvReport(List<RoleToSodModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSIRole2SodCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}


	//SOD RISK DATA

	@Override
	public List<CSISodRiskModel> readSodRiskData(String path){
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<CSISodRiskModel> dataLst = new ArrayList<>();
		//List<CSISodRiskModel> outLst = new ArrayList<CSISodRiskModel>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				CSISodRiskModel sodRsk	= new CSISodRiskModel();

				String application 		= Utility.getCellValue(rw.getCell(0));
				sodRsk.setApplication(application);
				if(application == null || application.length() <=0) {
					i++;
					continue;
				}
				String source 			= Utility.getCellValue(rw.getCell(1));
				sodRsk.setSource(source);
				String domain 			= Utility.getCellValue(rw.getCell(2));
				sodRsk.setDomain(domain);
				String bussPurpose 		= Utility.getCellValue(rw.getCell(3));
				sodRsk.setBussPurpose(bussPurpose);
				String riskId 			= Utility.getCellValue(rw.getCell(4));
				sodRsk.setRiskId(riskId);
				String funcId1 		 	= Utility.getCellValue(rw.getCell(5));
				sodRsk.setFuncId1(funcId1);
				String funcDesc1  		= Utility.getCellValue(rw.getCell(6));
				sodRsk.setFuncDesc1(funcDesc1);
				String funcId2			= Utility.getCellValue(rw.getCell(7));
				sodRsk.setFuncId2(funcId2);
				String funcDesc2	 	= Utility.getCellValue(rw.getCell(8));
				sodRsk.setFuncDesc2(funcDesc2);
				String funcId3 			= Utility.getCellValue(rw.getCell(9));
				sodRsk.setFuncId3(funcId3);
				String funcDesc3		= Utility.getCellValue(rw.getCell(10));
				sodRsk.setFuncDesc3(funcDesc3);
				String shrtDescRisk 	= Utility.getCellValue(rw.getCell(11));
				sodRsk.setShrtDescRisk(shrtDescRisk);
				String longDescRisk		= Utility.getCellValue(rw.getCell(12));
				sodRsk.setLongDescRisk(longDescRisk);
				String riskLevel		= Utility.getCellValue(rw.getCell(13));
				sodRsk.setRiskLevel(riskLevel);
				String regulation		= Utility.getCellValue(rw.getCell(14));
				sodRsk.setRegulation(regulation);
				String status			= Utility.getCellValue(rw.getCell(15));
				sodRsk.setStatus(status);
				String changeCmnt		= Utility.getCellValue(rw.getCell(16));
				sodRsk.setChangeCmnt(changeCmnt);

				dataLst.add(sodRsk);
				i++;
			}
		}

		//Filter User level Data
		/*if(roleId != null && roleId.length() > 0) {
			for(RoleToSodModel rls:dataLst) {
				if(rls.getRole().equals(roleId)) {
					outLst.add(rls);
				}
			}
		}else {
			outLst.addAll(dataLst);
		}*/

		log.info("Total Records for Processed(outLst) : "+dataLst.size());
		return dataLst;
	}

	@Override
	public List<CSISodCriticalActRiskModel> readSodCriticalActRiskData(String path){
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<CSISodCriticalActRiskModel> dataLst = new ArrayList<>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				CSISodCriticalActRiskModel sodRsk	= new CSISodCriticalActRiskModel();

				String disp 		= Utility.getCellValue(rw.getCell(0));
				sodRsk.setDisp(disp);
				/*if(application == null || application.length() <=0) {
					i++;
					continue;
				}*/

				String bussProc 			= Utility.getCellValue(rw.getCell(1));
				sodRsk.setBussProc(bussProc);
				String riskId 			= Utility.getCellValue(rw.getCell(2));
				sodRsk.setRiskId(riskId);
				String funcId1 		= Utility.getCellValue(rw.getCell(3));
				sodRsk.setFuncId1(funcId1);
				String funcDesc1 			= Utility.getCellValue(rw.getCell(4));
				sodRsk.setFuncDesc1(funcDesc1);
				String shrtDescRisk		 	= Utility.getCellValue(rw.getCell(5));
				sodRsk.setShrtDescRisk(shrtDescRisk);
				String longDescRisk  		= Utility.getCellValue(rw.getCell(6));
				sodRsk.setLongDescRisk(longDescRisk);
				String riskLevel			= Utility.getCellValue(rw.getCell(7));
				sodRsk.setRiskLevel(riskLevel);
				String changeCmnt	 	= Utility.getCellValue(rw.getCell(8));
				sodRsk.setChangeCmnt(changeCmnt);
				String status 			= Utility.getCellValue(rw.getCell(9));
				sodRsk.setStatus(status);

				dataLst.add(sodRsk);
				i++;
			}
		}

		//Filter User level Data
		/*if(roleId != null && roleId.length() > 0) {
			for(RoleToSodModel rls:dataLst) {
				if(rls.getRole().equals(roleId)) {
					outLst.add(rls);
				}
			}
		}else {
			outLst.addAll(dataLst);
		}*/

		log.info("Total Records for Processed(outLst) : "+dataLst.size());
		return dataLst;
	}



	@Override
	public String writeCSISodRiskCsvReport(List<CSISodRiskModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSISodRiskCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}



	@Override
	public String writeCSISodCriticalActRiskCsvReport(List<CSISodCriticalActRiskModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSISodCriticalActRiskCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}



	@Override
	public List<CSIFunctionActionModel> readSodFunctionActData(String path) {
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<CSIFunctionActionModel> dataLst = new ArrayList<>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				CSIFunctionActionModel funcAct	= new CSIFunctionActionModel();

				String disp 		= Utility.getCellValue(rw.getCell(0));
				funcAct.setDisp(disp);
				if(null == disp || disp.length() <=0) {
					continue;
				}

				String appScp 			= Utility.getCellValue(rw.getCell(1));
				funcAct.setAppScp(appScp);
				String funcId 			= Utility.getCellValue(rw.getCell(2));
				funcAct.setFuncId(funcId);
				String funcDesc 		= Utility.getCellValue(rw.getCell(3));
				funcAct.setFuncDesc(funcDesc);
				String tCode 			= Utility.getCellValue(rw.getCell(4));
				funcAct.setTCode(tCode);
				String tCodeDesc	 	= Utility.getCellValue(rw.getCell(5));
				funcAct.setTCodeDesc(tCodeDesc);
				String status  		= Utility.getCellValue(rw.getCell(6));
				funcAct.setStatus(status);
				String source		= Utility.getCellValue(rw.getCell(7));
				funcAct.setSource(source);
				String changeCmnt	 	= Utility.getCellValue(rw.getCell(8));
				funcAct.setChangeCmnt(changeCmnt);

				dataLst.add(funcAct);
				i++;
			}
		}

		//Filter User level Data
		/*if(roleId != null && roleId.length() > 0) {
			for(RoleToSodModel rls:dataLst) {
				if(rls.getRole().equals(roleId)) {
					outLst.add(rls);
				}
			}
		}else {
			outLst.addAll(dataLst);
		}*/

		log.info("Total Records for Processed(outLst) : "+dataLst.size());
		return dataLst;
	}


	@Override
	public List<CSIFunctionPermModel> readSodFunctionPermData(String path) {
		log.info("Loding file :"+path);
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);

		List<CSIFunctionPermModel> dataLst = new ArrayList<>();
		int i = 0;

		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows: "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				CSIFunctionPermModel funcPerm	= new CSIFunctionPermModel();

				String disp 		= Utility.getCellValue(rw.getCell(0));
				funcPerm.setDisp(disp);
				if(null == disp || disp.length() <=0) {
					continue;
				}

				String appScp 			= Utility.getCellValue(rw.getCell(1));
				funcPerm.setAppScp(appScp);
				String funcId 			= Utility.getCellValue(rw.getCell(2));
				funcPerm.setFuncId(funcId);
				String funcDesc 		= Utility.getCellValue(rw.getCell(3));
				funcPerm.setFuncDesc(funcDesc);
				String tCode 			= Utility.getCellValue(rw.getCell(4));
				funcPerm.setTCode(tCode);
				String tCodeDesc	 	= Utility.getCellValue(rw.getCell(5));
				funcPerm.setTCodeDesc(tCodeDesc);
				String authObj 			= Utility.getCellValue(rw.getCell(6));
				funcPerm.setAuthObj(authObj);
				String authObjDesc 			= Utility.getCellValue(rw.getCell(7));
				funcPerm.setAuthObjDesc(authObjDesc);
				String field 			= Utility.getCellValue(rw.getCell(8));
				funcPerm.setField(field);
				String fieldDesc 			= Utility.getCellValue(rw.getCell(9));
				funcPerm.setFieldDesc(fieldDesc);
				String fromVal 			= Utility.getCellValue(rw.getCell(10));
				funcPerm.setFromVal(fromVal);
				String toVal 			= Utility.getCellValue(rw.getCell(11));
				funcPerm.setToVal(toVal);
				String logicalOptr 			= Utility.getCellValue(rw.getCell(12));
				funcPerm.setLogicalOptr(logicalOptr);
				String status  		= Utility.getCellValue(rw.getCell(13));
				funcPerm.setStatus(status);
				String source		= Utility.getCellValue(rw.getCell(14));
				funcPerm.setSource(source);
				String changeCmnt	 	= Utility.getCellValue(rw.getCell(15));
				funcPerm.setChangeCmnt(changeCmnt);

				dataLst.add(funcPerm);
				i++;
			}
		}

		//Filter User level Data
		/*if(roleId != null && roleId.length() > 0) {
			for(RoleToSodModel rls:dataLst) {
				if(rls.getRole().equals(roleId)) {
					outLst.add(rls);
				}
			}
		}else {
			outLst.addAll(dataLst);
		}*/

		log.info("Total Records for Processed(outLst) : "+dataLst.size());
		return dataLst;
	}




	@Override
	public String writeCSISodFunctionActCsvReport(List<CSIFunctionActionModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSISodFunctionActCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}



	@Override
	public String writeCSISodFunctionPermCsvReport(List<CSIFunctionPermModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeCSISodFuncPermissionCSV(data, "CSI_"+fileName+".csv");
		return filePath;
	}



}
