package com.jnj.rqc.dbextr.models;


import lombok.Data;


@Data
public class F9861Mdl {
	private String sIOBNM;
	private String sIMKEY;
	private String sIENHV;
	private String sIUSER;
	private String sIDM;
	private String sIJDEVERS;
	private String sIMSAR;
	private String sISTCE;
	private String sIDVP;
	private String sIMRGMOD;
	private String sIMRGOPT;
	private String sIRLS;
	private String sIPATHCD;
	private String sIMODCMT;
	private String sIPID;
	private String sIJOBN;
	private String sIUPMJ;
	private String sIUPMT;


	public String getData() {
		return  sIOBNM + "~" +sIMKEY + "~" + sIENHV + "~" +sIUSER + "~" + sIDM + "~"+sIJDEVERS+"~"+sIMSAR+"~"+sISTCE+"~"+sIDVP+"~"+sIMRGMOD
				+"~"+sIMRGOPT+"~"+sIRLS+"~"+sIPATHCD+"~"+sIMODCMT+"~"+ sIPID+"~"+sIJOBN+"~"+sIUPMJ+"~"+sIUPMT;
	}

}
