package com.jnj.rqc.reportmodels;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReportDataModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private String ticktNo;
	private String reqNm;
	private String reqWwid;
	private String assocNm;
	private String assocWwid;
	private String assocNtId;
	private String mgrWwid;
	private String mgrNm;
	private Date   dtCreated;
	private String busnJstn;
	private String addCmnts;
	private List<AppRoles>roles;
	private List<ReqLogModel> reqLogs;

	@Override
	public String toString() {
		return "ReportDataModel [ticktNo=" + ticktNo + ", reqNm=" + reqNm + ", reqWwid=" + reqWwid + ", assocNm="
				+ assocNm + ", assocWwid=" + assocWwid + ", assocNtId=" + assocNtId + ", mgrWwid=" + mgrWwid
				+ ", mgrNm=" + mgrNm + ", dtCreated=" + dtCreated + ", busnJstn=" + busnJstn + ", addCmnts=" + addCmnts
				+ "]";
	}

	public String getData() {
		return dtCreated + "~" +ticktNo + "~" + reqNm + "~" + reqWwid + "~"	+ assocNm + "~" + assocWwid + "~" + assocNtId + "~" + mgrWwid+ "~" + mgrNm + "~" + busnJstn + "~" + addCmnts;
	}




}
