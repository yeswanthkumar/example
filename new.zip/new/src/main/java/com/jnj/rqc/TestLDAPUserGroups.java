package com.jnj.rqc;

import static javax.naming.directory.SearchControls.SUBTREE_SCOPE;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

//import org.acegisecurity.GrantedAuthority;
//import org.acegisecurity.GrantedAuthorityImpl;

import com.sun.jndi.ldap.LdapCtxFactory;

class TestLDAPUserGroups
{

	public static void main(String[] args)
	{

	    String username = "dchauras";
	    String password = "Shlok3012#";
	    String serverName ="nadir"; //"jnjdir";
	    String domainName = "jnj.com";

	    System.out.println("Authenticating " + username + "@" + domainName  + " through " + serverName + "." + domainName);

	    // bind by using the specified username/password
	    Hashtable<String,String> props = new Hashtable<>();
	    //String principalName = username + "@" + domainName;
	    props.put(Context.SECURITY_PRINCIPAL, "dchauras@na.jnj.com");
	    props.put(Context.SECURITY_CREDENTIALS, password);
	    DirContext context;

	    try {
	        context = LdapCtxFactory.getLdapCtxInstance("ldap://" + serverName + "." + domainName+":3268" + '/', props);
	        System.out.println("Authentication succeeded!");

	        // locate this user's record
	        SearchControls controls = new SearchControls();
	        controls.setSearchScope(SUBTREE_SCOPE);
//jnjMSUsername
	        NamingEnumeration<SearchResult> renum = context.search(
	                toDC(domainName), "(& (sAMAccountName=" + "dchauras"+ ")(objectClass=user))", controls);


	        if (!renum.hasMore())
	        {
	            System.out.println("Cannot locate user information for "+ username);
	            System.exit(1);
	        }

	        while(renum.hasMoreElements()) {
	        	SearchResult result = renum.next();
	        	Attributes attrs = result.getAttributes();
	        	if (attrs != null) {
	        		try {
	        			String cn = attrs.get("cn").get().toString();
	                    System.out.println(" cn : " + cn);
	                    NamingEnumeration<?> memberOf = attrs.get("memberOf").getAll();
	                    while (memberOf.hasMoreElements()) {
	                        String member =(String)memberOf.next();
	        		        String [] groupname = member.split(",");
	        		        String userGroup = groupname[0];
	        		        userGroup = userGroup.replaceAll("CN=", "").trim();
	        		        System.out.println(" User Group  :  "+userGroup);
	                    }

					} catch (Exception e) {
						// TODO: handle exception
					}

	        	}
	        }
	        context.close();
	    } catch (AuthenticationException a)
	    {
	        System.out.println("Authentication failed: " + a);
	        System.exit(1);
	    } catch (NamingException e)
	    {
	        System.out.println("Failed to bind to LDAP / get account information: " + e);
	        System.exit(1);
	    }
	}
	private static String toDC(String domainName)
	{
	    StringBuilder buf = new StringBuilder();
	    for (String token : domainName.split("\\."))
	    {
	        if (token.length() == 0)
	            continue; // defensive check
	        if (buf.length() > 0)
	            buf.append(",");
	        buf.append("DC=").append(token);
	    }
	    return buf.toString();
	}

}