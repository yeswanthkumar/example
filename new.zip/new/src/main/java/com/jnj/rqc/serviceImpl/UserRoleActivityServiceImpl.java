package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.TMUploadDataMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.UserRoleActivityDao;
import com.jnj.rqc.models.UserActivityModel;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.models.UserTerminationReportModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.service.UserRoleActivityService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.termdata.models.TermDataSmryModel;
import com.jnj.rqc.util.Utility;

/**
 * File    : <b>UserRoleActivityServiceImpl.java</b>
 * @author : DChauras @Created : Jul 31, 2019 2:16:07 PM
 * Purpose : Class is designed to collect User Data from all SOX systems
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Service
public class UserRoleActivityServiceImpl implements UserRoleActivityService {
	static final Logger log = LoggerFactory.getLogger(UserRoleActivityServiceImpl.class);

	@Autowired
	UserRoleActivityDao userRoleActivityDao;
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	CSVReportWriter cSVReportWriter;


	@Override
	public Map<String, List<UserTerminationReportModel>> processTerminationReport(Map<String, List<UserActivityModel>> userData) {
		Map<String, List<UserTerminationReportModel>> outPutMap = new HashMap<>();
		Date start = new Date();
		int counter=0;
		log.info("STARTED : Processing Termination Reports @ "+Utility.fmtMMDDYYYYTime(start));
		for(String systemNm : userData.keySet()) {
			counter++;
			log.info(counter+". START SYSTEM : "+systemNm+" - "+ Utility.fmtMMDDYYYYTime(new Date()));
			try{
				List<String> allUsers = userRoleActivityDao.getActiveUniqueIdsForSystem(systemNm);
				int totalRecs= (allUsers != null && !allUsers.isEmpty())? allUsers.size():0;
				log.info("Total UNIQUE User ID's for System :"+systemNm+" = "+totalRecs);
				if(allUsers != null && !allUsers.isEmpty()) {
					Date dtUpdated = new Date();
					List<UserTerminationReportModel> termMdlLst = null;
					if(outPutMap.containsKey(systemNm)) {
						termMdlLst = outPutMap.get(systemNm);
					}else {
						termMdlLst = new ArrayList<>();
					}
					int j=0;

					for(String rec : allUsers) {
						String id = rec.split("~")[0].trim();
						String name = rec.split("~")[1].trim();
						log.info("Getting User Info for Record "+(++j)+ " of "+totalRecs+"... for System : "+systemNm);
						List<UserSearchModel> usrList= null;
						if(id.toUpperCase().equals(id.toLowerCase())) {
							usrList = userSearchService.getUserData(1, id, 0);
						}else {
							usrList = userSearchService.getUserData(2, id, 0);
						}
						if(usrList != null && !usrList.isEmpty() ) {
							if(usrList.size() > 1 ) {
								for(UserSearchModel srchUsr : usrList) {
									UserTerminationReportModel tMdl = null;
									String cmnts = "Multiple Usernames found in JJEDS. A total of "+usrList.size()+" users with similar names were identified.";
									if(name.equalsIgnoreCase(srchUsr.getFmlyNm().trim()+", "+srchUsr.getGivenNm().trim())) {
										tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "Y", "Y",name);
									}else {
										tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "Y", "N", name);
									}
									termMdlLst.add(tMdl);
								}
							}else {
								UserSearchModel srchUsr= usrList.get(0);
								String cmnts=srchUsr.getEmpStatTxt()+" valid user found.";
								UserTerminationReportModel tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "N", "Y", name);
								termMdlLst.add(tMdl);
							}
						}else {
							String cmnts = "No direct matches or similar accounts found in JJEDS. This could be a system account.";
							UserTerminationReportModel tMdl = buildTermRepMdl(systemNm, id, "N/A",  "N/A", "N/A", 0, 1, "N/A", cmnts, dtUpdated, "N", "Y", name);
							termMdlLst.add(tMdl);
						}
						outPutMap.put(systemNm, termMdlLst);
					}
					log.info("SYSTEM :"+systemNm+"  Records Processed:"+outPutMap.get(systemNm).size()+" Unique IDs Received from system: "+allUsers.size());
				}
			} catch (Exception e) {
				log.error("ERROR Computing Termination Data for System ("+systemNm+") : "+e.getMessage(), e);
			}
			log.info("END SYSTEM : "+systemNm+" - "+ Utility.fmtMMDDYYYYTime(new Date())+"\n");
		}

		Date end = new Date();
		log.info("COMPLETED : Processing Termination Reports @ "+Utility.fmtMMDDYYYYTime(end)+"  Totla Time:"+((end.getDate()-start.getTime())/1000)+" Seconds");

		// TODO Auto-generated method stub
		return outPutMap;
	}

	@Override
	public Map<String, List<UserTerminationReportModel>> processNonSoxTerminationReport(Map<String, List<UserActivityModel>> userData) {
		Map<String, List<UserTerminationReportModel>> outPutMap = new HashMap<>();
		Date start = new Date();
		int counter=0;
		log.info("STARTED : Processing Non-SOX Termination Reports @ "+Utility.fmtMMDDYYYYTime(start));
		for(String systemNm : userData.keySet()) {
			counter++;
			log.info(counter+". START Non-SOX SYSTEM : "+systemNm+" - "+ Utility.fmtMMDDYYYYTime(new Date()));
			try{
				List<String> allUsers = userRoleActivityDao.getActiveUniqueIdsForNonSoxSystem(systemNm);
				int totalRecs= (allUsers != null && !allUsers.isEmpty())? allUsers.size():0;
				log.info("Total UNIQUE User ID's for Non-SOX System :"+systemNm+" = "+totalRecs);
				if(allUsers != null && !allUsers.isEmpty()) {
					Date dtUpdated = new Date();
					List<UserTerminationReportModel> termMdlLst = null;
					if(outPutMap.containsKey(systemNm)) {
						termMdlLst = outPutMap.get(systemNm);
					}else {
						termMdlLst = new ArrayList<>();
					}
					int j=0;
					for(String rec : allUsers){
						String id = rec.split("~")[0].trim();
						String name = rec.split("~")[1].trim();
						log.info("Getting User Info for Record "+(++j)+ " of "+totalRecs+"... for System : "+systemNm);
						List<UserSearchModel> usrList= null;
						if(id.toUpperCase().equals(id.toLowerCase())) {
							usrList = userSearchService.getUserData(1, id, 0);
						}else {
							usrList = userSearchService.getUserData(2, id, 0);
						}
						if(usrList != null && !usrList.isEmpty() ) {
							if(usrList.size() > 1 ) {
								for(UserSearchModel srchUsr : usrList) {
									UserTerminationReportModel tMdl = null;
									String cmnts = "Multiple Usernames found in JJEDS. A total of "+usrList.size()+" users with similar names were identified.";
									if(name.equalsIgnoreCase(srchUsr.getFmlyNm().trim()+", "+srchUsr.getGivenNm().trim())) {
										tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "Y", "Y",name);
									}else {
										tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "Y", "N", name);
									}
									termMdlLst.add(tMdl);
								}
							}else {
								UserSearchModel srchUsr= usrList.get(0);
								String cmnts=srchUsr.getEmpStatTxt()+" valid user found.";
								UserTerminationReportModel tMdl = buildTermRepMdl(systemNm, id,srchUsr.getWwId(),srchUsr.getGivenNm().trim(), srchUsr.getFmlyNm().trim(),usrList.size(), 1, srchUsr.getEmpStatTxt(), cmnts, dtUpdated, "N", "Y", name);
								termMdlLst.add(tMdl);
							}
						}else {
							String cmnts = "No direct matches or similar accounts found in JJEDS. This could be a system account.";
							UserTerminationReportModel tMdl = buildTermRepMdl(systemNm, id, "N/A",  "N/A", "N/A", 0, 1, "N/A", cmnts, dtUpdated, "N", "Y", name);
							termMdlLst.add(tMdl);
						}
						outPutMap.put(systemNm, termMdlLst);
					}
					log.info("SYSTEM :"+systemNm+"  Records Processed:"+outPutMap.get(systemNm).size()+" Unique IDs Received from system: "+allUsers.size());
				}
			} catch (Exception e) {
				log.error("ERROR Computing Termination Data for System ("+systemNm+") : "+e.getMessage(), e);
			}
			log.info("END SYSTEM : "+systemNm+" - "+ Utility.fmtMMDDYYYYTime(new Date())+"\n");
		}

		Date end = new Date();
		log.info("COMPLETED : Processing Termination Reports @ "+Utility.fmtMMDDYYYYTime(end)+"  Totla Time:"+((end.getTime()-start.getTime())/1000)+" Seconds");

		// TODO Auto-generated method stub
		return outPutMap;
	}


	private UserTerminationReportModel buildTermRepMdl(String systemNm, String id, String wwId, String givenNm,	String fmlyNm, int dups, int uniq, String empStatTxt, String cmnts, Date dtUpdated, String hasIssue, String appAcc, String nameInSrcSys) {
		UserTerminationReportModel tMdl = new UserTerminationReportModel();
		tMdl.setSrcSys(systemNm);
		tMdl.setUserId(id);
		tMdl.setWwid(wwId);
		tMdl.setFirstName(givenNm);
		tMdl.setLastName(fmlyNm);
		tMdl.setTotalDups(dups);
		tMdl.setUniqueRec(uniq);
		tMdl.setStatus(empStatTxt);
		tMdl.setComments(cmnts);
		tMdl.setDtUpdated(dtUpdated);
		tMdl.setAcHasIssue(hasIssue);
		tMdl.setRecFromApp(appAcc);
		tMdl.setUsrNmInSrcSys(nameInSrcSys);
		return tMdl;
	}



	@Override
	public Map<String, List<UserActivityModel>> getUserData(List<TermDataSmryModel> sysList) {
		Map<String, List<UserActivityModel>> dataMap = new HashMap<>();
		try {

			log.info("Clearing Cache");
			int clearCnt = clearUserActCache();
			log.info("Total records cleared :"+clearCnt);

			List<UserActivityModel> ccraList = userRoleActivityDao.getCcraUserData(sysList);
			dataMap.put("CCRA", ccraList);
			insertUserData(ccraList, "CCRA");

			List<UserActivityModel> coreList = userRoleActivityDao.getCoreUserData(sysList);
			dataMap.put("CORE", coreList);
			insertUserData(coreList,"CORE");

			/* Commented on 09/06/2022 on Alex request - System Decomissioned */
			/*List<UserActivityModel> gpsList = userRoleActivityDao.getGpsUserData(sysList);
			dataMap.put("GPS", gpsList);
			insertUserData(gpsList, "GPS");
			*/

			/* Commented on 09/06/2022 on Alex request - System Decomissioned */
			//HCSOP02 - op11
			/*List<UserActivityModel> op2List = userRoleActivityDao.getHcsop02UserData(sysList);
			dataMap.put("HCSOP02", op2List);
			insertUserData(op2List, "HCSOP02");
			*/

			/* Commented on 09/06/2022 on Alex request - System Decomissioned */
			//HCSOP17 - op11
			/*List<UserActivityModel> op17List = userRoleActivityDao.getHcsop17UserData(sysList);
			dataMap.put("HCSOP17", op17List);
			insertUserData(op17List, "HCSOP17");
			*/

			//HCSOP50- op11
			List<UserActivityModel> op50List = userRoleActivityDao.getHcsop50UserData(sysList);
			dataMap.put("HCSOP50", op50List);
			insertUserData(op50List, "HCSOP50");

			//HCSOP53- op11
			List<UserActivityModel> op53List = userRoleActivityDao.getHcsop53UserData(sysList);
			dataMap.put("HCSOP53", op53List);
			insertUserData(op53List, "HCSOP53");

			/* Commented on 09/06/2022 on Alex request - System Decomissioned */
			//HCSOP40 -op11
			/*List<UserActivityModel> op40List = userRoleActivityDao.getHcsop40UserData(sysList);
			dataMap.put("HCSOP40", op40List);
			insertUserData(op40List, "HCSOP40");
			*/

			//ICS
			List<UserActivityModel> icsList = userRoleActivityDao.getIcsUserData(sysList);
			dataMap.put("ICS", icsList);
			insertUserData(icsList, "ICS");

			//MDM
			List<UserActivityModel> mdmList = userRoleActivityDao.getMdmUserData(sysList);
			dataMap.put("MDM", mdmList);
			insertUserData(mdmList,"MDM");

			//WMS-MLC
			List<UserActivityModel> wmsMlcList = userRoleActivityDao.getWmsMlcUserData(sysList);
			dataMap.put("WMSMLC", wmsMlcList);
			insertUserData(wmsMlcList, "WMSMLC");
			//Utility.addUserActCache(wmsMlcList);

			//WMS SDC
			List<UserActivityModel> wmsSdcList = userRoleActivityDao.getWmsSdcUserData(sysList);
			dataMap.put("WMSSDC", wmsSdcList);
			insertUserData(wmsSdcList, "WMSSDC");


			/*DECOMISSIONED
				List<UserActivityModel> carsIsList = userRoleActivityDao.getCarsIsUserData();
				insertUserData(carsIsList,"CARSIS");
				List<UserActivityModel> carsMaList = userRoleActivityDao.getCarsMaUserData();
				insertUserData(carsMaList,"CARSMA");
			*/

		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}

		return dataMap;
	}


	/**
	 * Method  : UserRoleActivityServiceImpl.java.getNonSoxUserData()
	 *		   :<b>@param sysList
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Jul 6, 2022 1:40:57 PM
	 * Purpose : Non-Sox Data
	 * @return : Map<String,List<UserActivityModel>>
	 */
	@Override
	public Map<String, List<UserActivityModel>> getNonSoxUserData(List<TermDataSmryModel> sysList) {
		Map<String, List<UserActivityModel>> dataMap = new HashMap<>();
		try {

			log.info("Clearing Non-Sox Cache");
			int clearCnt = clearNonSoxUserActCache();
			log.info("Total records cleared :"+clearCnt);

			//1. 340BR2
			List<UserActivityModel> br2340List = userRoleActivityDao.get340BR2UserData(sysList);
			dataMap.put("340BR2", br2340List);
			insertNonSoxUserData(br2340List, "340BR2");

			//2. EMSNextGEN
			List<UserActivityModel> emsNxtList = userRoleActivityDao.getEmsNextGenUserData(sysList);
			dataMap.put("EMSNEXTGEN", emsNxtList);
			insertNonSoxUserData(emsNxtList, "EMSNEXTGEN");

			//3. FALCON
			List<UserActivityModel> falconList = userRoleActivityDao.getFalconUserData(sysList);
			dataMap.put("FALCON", falconList);
			insertNonSoxUserData(falconList, "FALCON");

			//4. FOM
			List<UserActivityModel> fomList = userRoleActivityDao.getFomUserData(sysList);
			dataMap.put("FOM", fomList);
			insertNonSoxUserData(fomList, "FOM");

			//5.	FTCC Bulldog
			List<UserActivityModel> ftccList = userRoleActivityDao.getFTCCUserData(sysList);
			dataMap.put("FTCC", ftccList);
			insertNonSoxUserData(ftccList, "FTCC");

			//6.	PVCS
			List<UserActivityModel> pvcsList = userRoleActivityDao.getPVCSUserData(sysList);
			dataMap.put("PVCS", pvcsList);
			insertNonSoxUserData(pvcsList, "PVCS");

			//7.	RMSJAPAN
			List<UserActivityModel> rmsjapanList = userRoleActivityDao.getRMSJAPANUserData(sysList);
			dataMap.put("RMSJAPAN", rmsjapanList);
			insertNonSoxUserData(rmsjapanList, "RMSJAPAN");

			//8.	TM
			List<UserActivityModel> tmList = userRoleActivityDao.getTMUserData(sysList);
			dataMap.put("TM", tmList);
			insertNonSoxUserData(tmList, "TM");
		} catch (Exception e) {
			log.error("Error: "+e.getMessage());
			e.printStackTrace();
		}

		return dataMap;
	}





	@Override
	public void insertUserData(List<UserActivityModel> dataList, String system) {
		try {
			log.info("Total Rows received for system: "+system+" = "+dataList.size());
			String result = userRoleActivityDao.insertUserActivityData(dataList);
			log.info("Data insert for system :"+system+"  ... "+result);
		} catch (Exception e) {
			log.error("Error inserting User data for system: "+system+" Message: "+e.getMessage());
			e.printStackTrace();
		}
	}


	@Override
	public int clearUserActCache(){
		int clearData = 0;
		try {
			clearData = userRoleActivityDao.clearUserCache();
		} catch (Exception e) {
			log.info("ERROR Clearing User Cache :"+e.getMessage());
			e.printStackTrace();
		}

		return clearData;
	}


	@Override
	public Map<String, String> generateTermExcelFiles(Map<String, List<UserActivityModel>> userData, String fileDir, HttpServletRequest request) {
		Map<String, String> fileMap = new HashMap<>();
		String outFile = "";
		String dirPath = Constants.TERM_OUT_LOC+"T_"+fileDir;
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("DIRLOCZ", dirPath);
		for (Map.Entry<String, List<UserActivityModel>> fileData : userData.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_"+fileDir+".csv";
			outFile = createCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;

	}

	@Override
	public Map<String, String> generateTermReportFiles(Map<String, List<UserTerminationReportModel>> userData, String fileDir, HttpServletRequest request){
		Map<String, String> fileMap = new HashMap<>();
		String outFile = "";
		String dirPath = Constants.TERM_OUT_LOC+"REP_"+fileDir;
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("DIRLOCREP", dirPath);
		for (Map.Entry<String, List<UserTerminationReportModel>> fileData : userData.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_TERM_"+fileDir+".csv";
			outFile = createReportCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;

	}

	@Override
	public Map<String, String> generateNonSoxTermReportFiles(Map<String, List<UserTerminationReportModel>> userData, String fileDir, HttpServletRequest request){
		Map<String, String> fileMap = new HashMap<>();
		String outFile = "";
		String dirPath = Constants.TERM_OUT_LOC+"REP_"+fileDir;
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("NDIRLOCREP", dirPath);
		for (Map.Entry<String, List<UserTerminationReportModel>> fileData : userData.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_TERM_"+fileDir+"_NonSox.csv";
			outFile = createReportCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;

	}

	public String createReportCSV(List<UserTerminationReportModel> data, String fileName) {
		String filePath = cSVReportWriter.writeUserTermCSVReport(data, fileName);
		return filePath;
	}

	public String createCSV(List<UserActivityModel> data, String fileName) {
		String filePath = cSVReportWriter.writeTerminationMonthlyCSVReport(data, fileName);
		return filePath;
	}

	//NON-SOX Processing

	@Override
	public int clearNonSoxUserActCache(){
		int clearData = 0;
		try {
			clearData = userRoleActivityDao.clearNonSoxUserCache();
		} catch (Exception e) {
			log.info("ERROR Clearing Non-Sox User Cache :"+e.getMessage());
			e.printStackTrace();
		}

		return clearData;
	}


	@Override
	public void insertNonSoxUserData(List<UserActivityModel> dataList, String system) {
		try {
			log.info("Total Rows received for system: "+system+" = "+dataList.size());
			String result = userRoleActivityDao.insertNonSoxUserActivityData(dataList);
			log.info("Data insert for system :"+system+"  ... "+result);
		} catch (Exception e) {
			log.error("Error inserting User data for system: "+system+" Message: "+e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public Map<String, String> generateNonSoxTermExcelFiles(Map<String, List<UserActivityModel>> userData, String fileDir, HttpServletRequest request) {
		Map<String, String> fileMap = new HashMap<>();
		String outFile = "";
		String dirPath = Constants.TERM_OUT_LOC+"T_"+fileDir+"_NonSox";
		Utility.createDirectory(dirPath);
		request.getSession().setAttribute("NDIRLOCZ", dirPath);
		for (Map.Entry<String, List<UserActivityModel>> fileData : userData.entrySet()) {
			String fileName = dirPath+"/"+fileData.getKey()+"_"+fileDir+".csv";
			outFile = createCSV(fileData.getValue(), fileName);
			fileMap.put(fileData.getKey(), outFile);
		}
		return fileMap;

	}


	@Override
	public List<TMUploadDataMdl> readTMExcel(String path, HttpServletRequest request){
		log.info("Loding file :"+path);
		List<TMUploadDataMdl> tmLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows(Header inc.): "+rowTotal);
			request.getSession().setAttribute("TMFILE_TOTALCOUNT", rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}

				String role 	= Utility.getCellValue(rw.getCell(2));
				if(null == role || role.startsWith("CAR") || role.startsWith("UNA") || role.startsWith("GEN") || role.startsWith("KL ") || role.startsWith("SHT")) {
					i++;
					continue;
				}
				TMUploadDataMdl dtaMdl	= new TMUploadDataMdl();

				String usrId	= Utility.getCellValue(rw.getCell(0));
				dtaMdl.setUserId(usrId);
				String nam	= Utility.getCellValue(rw.getCell(1));
				dtaMdl.setName(nam);
				dtaMdl.setRole(role);
				//if(!tmLst.contains(dtaMdl)) {
				tmLst.add(dtaMdl);
				//}
				i++;
			}
		}
		log.info("Total TM Records to Process : "+tmLst.size());
		return tmLst;
	}



}
