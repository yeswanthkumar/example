package com.jnj.rqc.dbextr.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.useridentity.models.UserRoleADGrpMdl;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ADGroupRespDto {
	private int statusCode;
	private String message;
	private String datetimeStamp;
	private String statusDesc;
	private String developerMessage;
	private String type;
	private List<UserRoleADGrpMdl> tables;
	private String type2;//SEC/PER/POS
	private List<KeyValPair> tables2;

}
