package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.common.sorting.RQCReportComparator;
import com.jnj.rqc.models.KeyValPair;
import com.jnj.rqc.reportmodels.ReportDataModel;
import com.jnj.rqc.service.RqcReportService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;

/**
 * File    : <b>RqcReportController.java</b>
 * @author : DChauras @Created : Feb 14, 2020 4:28:55 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Controller
public class RqcReportController {
	static final Logger log = LoggerFactory.getLogger(RqcReportController.class);

	@Autowired
	private RqcReportService rqcReportService;

	@Autowired
	UserSearchService userSearchService;

	@GetMapping("/rqcReport")
    public String loadReportForm(Model model) {
    	log.info("Routing to RQC Report page.");
    	List<KeyValPair> statusValues = Utility.getStatusParams();
    	Set<String> appList = Utility.getAppList();
    	model.addAttribute("stVal", statusValues);
    	model.addAttribute("appLst", appList);
		return "reports/rqcReportInfo";
    }


	@PostMapping("/searchRQCReport")
    public String searchRQCDetails(@RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, @RequestParam("stType") int stType, @RequestParam("applName")String applName, Model model, HttpServletRequest request) {
		log.info("Status :"+stType+"  Start Date :"+startDate+"  endDate: "+endDate);
    	model.addAttribute("stDate",startDate);
    	model.addAttribute("enDate",endDate);
    	model.addAttribute("stParam", stType);
    	model.addAttribute("appNmPrm", applName);


    	List<KeyValPair> statusValues = Utility.getStatusParams();
    	Set<String> appList = Utility.getAppList();
		model.addAttribute("stVal", statusValues);
		model.addAttribute("appLst", appList);

		if(startDate.isEmpty() || endDate.isEmpty()) {
			log.info("Missing required Data");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values : "+(startDate.isEmpty() ?"Start Date":"End Date"));
            return "reports/rqcReportInfo";
    	}

		Date stDt = Utility.fmtStrToDate(startDate);
		Date enDt = Utility.fmtStrToDate(endDate);
    	if(stDt.after(enDt)) {
			log.info("Invalid Dates, Start Date GREATER THAN End Date");
            model.addAttribute("message", "True");
            model.addAttribute("error", "Invalid Dates values : Start Date cannot be greater than End Date");
            return "reports/rqcReportInfo";
    	}

		try{
			Map<String, ReportDataModel> repMap = rqcReportService.processRQCReport(startDate, endDate, stType, applName);

    		HttpSession session = request.getSession();
    		if(repMap != null && !repMap.isEmpty()) {
    			ArrayList<ReportDataModel> valueList = new ArrayList<>(repMap.values());
    			Collections.sort(valueList, new RQCReportComparator());
    			session.setAttribute("REPORTData", valueList);
    			session.setAttribute("DateRange", (startDate.replaceAll("/", "")+"_"+endDate.replaceAll("/", "")));
    			model.addAttribute("REPORTData", valueList);

    		}

    		model.addAttribute("message", "True");
    		log.debug("RQC Report total count : "+((repMap==null)?  "0":repMap.size()));

    		String msg  = "Status: RQC Report total count : "+ ((repMap == null || repMap.isEmpty() ) ?  "0": repMap.size()+"");
    		model.addAttribute("success", msg);
    	} catch (Exception e) {
            log.error("Error getting Report Data :"+e.getMessage(), e);
        	e.printStackTrace();
        }
        return "reports/rqcReportInfo";
    }



	@ResponseBody
    @GetMapping("/downloadTktExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictExcel(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading Excel Ticket Data");
		String fileNm ="RQCReport_"+request.getSession().getAttribute("DateRange");
		//List<Foo> newList = srcCollection.stream().collect(toList());
		List<ReportDataModel> repDataList = (List<ReportDataModel>) ((Collection)request.getSession().getAttribute("REPORTData")).stream().collect(Collectors.toList());

		String filePath = rqcReportService.createRQCCsvReport(fileNm, repDataList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

/*

	@ResponseBody
    @GetMapping("/downloadRQCReportPDF/{type}")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downloadExistingRoleConflictPDF(@PathVariable String type, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Path Variable received :"+ type);
		String fileNm ="";
		String title="";
		List<MatrixModel> roleConflictList = null;

		if("sod2".equals(type)) {
			fileNm ="ConflictsInRolesRequested.pdf";
			title="Requested New Role(s) SOD Conflicts with each other";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("newRoleConflictList");
		}else {
			fileNm = "ExistingAndRequestedRoleConflicts.pdf";
			title = "Existing Role(s) SOD Conflicts with Requested New Role(s)";
			roleConflictList = (List<MatrixModel>)request.getSession().getAttribute("curRoleConflictList");
		}
		String filePath = RqcSapConflictService.writeConfPDFReport(title, fileNm, roleConflictList);
    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }
*/

}
