package com.jnj.rqc.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodReportMdl;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dao.UserMenuDao;
import com.jnj.rqc.models.U2REmailLogMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.sch.TrfCntrlSchExportModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;


/**
 * File    : <b>SAPExtractionOneClickController.java</b>
 * @author : DChauras @Created : Apr 29, 2021 12:16:30 PM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */
@Controller
public class SAPExtractionOneClickController {
	static final Logger log = LoggerFactory.getLogger(SAPExtractionOneClickController.class);

	@Autowired
	UserSearchService userSearchService;

	@Autowired
	UserMenuDao userMenuDao;

	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;

	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	String BASE_REGION = "REGION";


	//TRIGGER Weekly Email
	@GetMapping("/triggerTransferControlWeeklyReport")
	public String triggerTransferControlWeeklyReport(Model model, HttpServletRequest request)
	{	String envName = Utility.getServerProp("ENVIRONMENT");
		log.info("<<<<<<<<<<<<<<<  ("+envName+") START MANUAL PROCESS TRANSFER DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
			processGenesisTransferReport();
		log.info("<<<<<<<<<<<<<<<  ("+envName+") END MANUAL PROCESS TRANSFER DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		return "home";
	}

	@GetMapping("/triggerUser2RoleWeeklyReport")
	public String triggerUser2RoleWeeklyReport(Model model, HttpServletRequest request){
		String envName = Utility.getServerProp("ENVIRONMENT");
		return "sapextraction/triggerWeeklyUserToRoleReport";
	}

	@PostMapping("/startUser2RoleWeeklyReport")
	public String startUser2RoleWeeklyReport(@RequestParam(name = "finalChk", required = false, defaultValue="0") String finalChk , Model model, HttpServletRequest request){
		log.info("finalChk :"+finalChk);
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		model.addAttribute("finalChkPrm", finalChk);
		String envName = Utility.getServerProp("ENVIRONMENT");
		log.info("<<<<<<<<<<<<<<<  ("+envName+") START PROCESS MANUAL USER TO ROLE DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		List<String> processedSystemsLst = processGenesisUser2RoleReport("MANUAL-"+curUser.getWwId(), finalChk);
		log.info("<<<<<<<<<<<<<<<  ("+envName+") END PROCESS USER TO ROLE DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		model.addAttribute("SYS_PROCD", processedSystemsLst);
		model.addAttribute("message", "True");
        model.addAttribute("success", "Total PLATFORMS processed : "+(processedSystemsLst.isEmpty()? "0":processedSystemsLst.size()));


		return "sapextraction/triggerWeeklyUserToRoleReport";
	}



	@GetMapping("/viewU2RWeeklyReport")
	public String viewU2RWeeklyReport(Model model, HttpServletRequest request){
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		String envName = Utility.getServerProp("ENVIRONMENT");
		List<U2REmailLogMdl>  reportList = sAPExtrGaaDataService.getWeeklyU2RReportDetails();

		model.addAttribute("REPORT_LOG", reportList);
    	//model.addAttribute("bussFunctions", bussFunctions);
    	//model.addAttribute("AUTH_USER", curUser);
    	return "sapextraction/viewWeeklyUserToRoleData";
	}


	@PostMapping("/viewU2RWeeklyReportData")
	public String viewU2RWeeklyReportData(@RequestParam("weeklyRep") int weeklyRep, Model model, HttpServletRequest request){
		//UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
				//String envName = Utility.getServerProp("ENVIRONMENT");
		log.info("Selected Report : "+ weeklyRep);
		int seqIdParam = weeklyRep;
		model.addAttribute("seqIdParam", seqIdParam);
		List<U2REmailLogMdl>  reportList = sAPExtrGaaDataService.getWeeklyU2RReportDetails();
		model.addAttribute("REPORT_LOG", reportList);
		if(weeklyRep != 0 ) {
			List<U2REmailLogMdl>  dataList = sAPExtrGaaDataService.getWeeklyU2RReportData(weeklyRep);
			model.addAttribute("REPORT_DATA", dataList);
			model.addAttribute("message", "True");
	        model.addAttribute("success", "Total Platforms  : "+(dataList.size()));
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid NTID's/ID not found, Please correct the NTID/WWID and Search again.");
		}
		//model.addAttribute("bussFunctions", bussFunctions);
    	//model.addAttribute("AUTH_USER", curUser);
    	return "sapextraction/viewWeeklyUserToRoleData";
	}

	@GetMapping("/updWeeklyStatus/{platforminfo}")
	public String updWeeklyStatus(@PathVariable("platforminfo") String platforminfo, Model model, HttpServletRequest request){
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		log.info("platforminfo :"+platforminfo);
		String[] plInf = platforminfo.split("~");
		int seqIdParam = Utility.strToNum(plInf[0]);
		String platform=plInf[1];
		model.addAttribute("seqIdParam", seqIdParam);
		List<U2REmailLogMdl>  reportList = sAPExtrGaaDataService.getWeeklyU2RReportDetails();
		model.addAttribute("REPORT_LOG", reportList);
		if(seqIdParam != 0 && platform != null && platform.length() > 0) {
			int recUpdated = sAPExtrGaaDataService.updWeeklyReportStatus(seqIdParam, platform, curUser.getFmlyNm()+" "+curUser.getGivenNm()+" - "+curUser.getWwId());
			List<U2REmailLogMdl>  dataList = sAPExtrGaaDataService.getWeeklyU2RReportData(seqIdParam);
			model.addAttribute("REPORT_DATA", dataList);
			model.addAttribute("message", "True");
	        model.addAttribute("success", "Total Platforms  : "+(dataList.size()));
		}else {
			model.addAttribute("message", "True");
	        model.addAttribute("error", "Invalid NTID's/ID not found, Please correct the NTID/WWID and Search again.");
		}
		return "sapextraction/viewWeeklyUserToRoleData";
	}



	@ResponseBody
    @GetMapping("/downUser2RoleWeeklyReportData")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> downUser2RoleWeeklyData(@RequestParam("createdFiles") String createdFiles, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading User to Role Weekly Report Files : "+createdFiles);
		String[] dataRecd =createdFiles.split("~");
		String platform = dataRecd[0];
		String fileNms  = dataRecd[1];
		String zipfilePath = Utility.createZip(Arrays.asList(fileNms.split(";")), Constants.REPO_OUT_LOC+platform+"_"+Utility.fmtMDY(new Date())+".zip");
    	File fl = new File(zipfilePath);
		log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }



	@GetMapping("/triggerUser2SodWeeklyReport")
	public String triggerUser2SodWeeklyReport(Model model, HttpServletRequest request){
		String envName = Utility.getServerProp("ENVIRONMENT");
		log.info("<<<<<<<<<<<<<<<  ("+envName+") START PROCESS MANUAL USER TO ROLE DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		processGenesisUserToSodReport();
		log.info("<<<<<<<<<<<<<<<  ("+envName+") END PROCESS USER TO ROLE DATA REPORT @(DateTime): "+Utility.fmtMMDDYYYYTime(new Date())+" >>>>>>>>>>>>>>> ");
		return "home";
	}


	//END

	// START USER TO SOD - DELTA
	  @SuppressWarnings("all")
	  @GetMapping("/processUser2SodDeltaReport")
	  public String processGenesisUser2SodDeltaReport() {
		  Calendar startTime = Calendar.getInstance(), endTime = null;
		  String envName = Utility.getServerProp("ENVIRONMENT");
		  Map<String, List<SapUser2SodDeltaMdl>> allDataMap = new HashMap<>();

		  log.info("STARTED: GENESIS USER TO SOD (DELTA) Report DATA COLLECTION @"+Utility.fmtMMDDYYYYTime(startTime.getTime()));
		  try{
			  Date repDate = new Date();
			  //Clear Data First
			  String clearedData = sAPExtrGaaDataService.clearUser2SodDelta();
			  log.info("Cleared Old Data  "+clearedData);
			Map<String, SapU2RDeltaSummaryMdl> sumMap = new HashMap<>();
			List<SapU2RDeltaSummaryMdl> inDataLst = sAPExtrGaaDataService.getUser2SodSummaryDeltaData("IN");//String type=IN/COL
			List<SapU2RDeltaSummaryMdl> colDataLst = sAPExtrGaaDataService.getUser2SodSummaryDeltaData("COL");//String type=IN/COL
			if(inDataLst != null && !inDataLst.isEmpty()) {
				String sKey="";
				for(SapU2RDeltaSummaryMdl sumMdl : inDataLst) {
					sKey = sumMdl.getUserId().toUpperCase().trim();
					sumMdl.setUserId(sKey);
					sumMdl.setReportDate(repDate);
					sumMap.put(sKey, sumMdl);
				}
			}

			if(colDataLst != null && !colDataLst.isEmpty()) {
				String sKey="";
				for(SapU2RDeltaSummaryMdl colMdl : colDataLst) {
					sKey = colMdl.getUserId().toUpperCase().trim();
		   			SapU2RDeltaSummaryMdl inMdl= sumMap.get(sKey);
		   			if(inMdl == null) {
		   				inMdl=new SapU2RDeltaSummaryMdl();
		   				inMdl.setReportDate(repDate);
		   				inMdl.setUserId(sKey);
		   				inMdl.setRolesIn(0);
		   			}
		   			inMdl.setRolesCol(colMdl.getRolesCol());
		   			sumMap.put(sKey, inMdl);
				}
			}

			if(!sumMap.isEmpty()) {
				//Save Summary Data
				List<String> deltaUsrList = new ArrayList<>();
				List<SapU2RDeltaSummaryMdl> allSumData = new ArrayList<>();
				for(Map.Entry<String, SapU2RDeltaSummaryMdl> entry:sumMap.entrySet()) {
					SapU2RDeltaSummaryMdl sumModel = entry.getValue();
					allSumData.add(sumModel);
					if(sumModel.getRolesIn() != sumModel.getRolesCol()) {
						deltaUsrList.add(entry.getKey());
					}
				}
				int insSumCount= sAPExtrRegionWiseDao.insertUser2SodDeltaSummary(allSumData);
				log.info("Total USER TO SOD Summary Delta Records inserted ="+insSumCount);

				//Getting USER To Role Data
				allDataMap = sAPExtrGaaDataService.getGenesisUser2SodData(deltaUsrList);
				/////////////
		  		int emlCounter=0;
		   		if(allDataMap != null && !allDataMap.isEmpty()) {
		   			for(Map.Entry<String, List<SapUser2SodDeltaMdl>> pltData : allDataMap.entrySet()) {
		   				String platform = pltData.getKey();
		   				List<SapUser2SodDeltaMdl> pltDataList = pltData.getValue();
		   				log.info("Total Records for Platform : "+platform+" = "+pltDataList.size());
		   				if(pltDataList != null && !pltDataList.isEmpty()) {
		   					try {
		   						log.info("Saving User2Sod Delta Records for "+platform+" = "+pltDataList.size());
		   						int deltaInserted = sAPExtrRegionWiseDao.insertUser2SodDeltaReport(pltDataList);
		   						log.info("Total Delta Records Saved for "+platform+" = "+deltaInserted);
		   						//Sending Emails
		   						String filePath = excelReportWriter.writeSapUser2SodDeltaExcel(pltDataList, "UserToSod_"+platform+"_DataNotPickedup"+"_"+Utility.fmtMDY(new Date()), "USER2SOD DELTA");
		   						String toEmail=Utility.getPlatformEmailAddress(platform);
		   						log.info(emlCounter+". Sending "+envName+" - GENESIS USER TO SOD DELTA Report email for Platform: "+platform+" - To Email Address : "+toEmail);
		   						emailUtil.sendGenesisU2RReportEmail("("+envName+") ERP USER TO SOD DELTA Report Data for Platform: "+platform, filePath, toEmail, "DS");
							} catch (Exception e) {
								log.error("ERROR saving Delta records for Platform "+ platform+ "("+pltDataList.size()+")  "+e.getMessage(), e);
							}
		   				}
		   			}
		   		}
			}else {
				log.info("USER TO ROLE DATA NOT EXPORTED TO GENESIS....Please EXPORT Data");
		   		}
		   	} catch (Exception e) {
	   			log.error("Error:"+e.getMessage(), e);
	   		}
	       	return "sapextraction/user2Soddeltapage";
	   	}


	// END USER TO SOD - DELTA


	//START CRITICAL ROLES

	@GetMapping("/sapUser2CriticalRoleOneClickPage")
    public String sapUser2CriticalRoleOneClickPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2CriticalRoleScheduls(regNames);
    	String msg = "Status: No Schedules found for USER TO CRITICAL ROLE Data ";
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		msg = "Status: Schedules found for USER TO CRITICAL ROLE Data : ( "+schdList.size()+" )";
    		//Exportable Data
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_U2CR_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_U2CR_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2CriticalRoleSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2CriticalRole1Click";
    }

    @PostMapping("/sapUser2CriticalRoleOneClickData")
    public String sapUser2CriticalRoleOneClickData(@RequestParam("regions") String regions, Model model, HttpServletRequest request) {
    	log.info("USER TO CRITICAL ROLE - Selected Region: "+regions);
    	String regParam = regions;
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	if("0".equals(regions) || curUser == null) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Not Logged In/Session Expired.");
            return "sapextraction/sapExtrUser2CriticalRole1Click";
    	}
    	boolean result = false;
    	String msg  = "";
    	//Prevent Duplicate Scheduling
    	synchronized (this){
    		 List<TrfCntrlSchModel> schList = sAPExtrRegionWiseService.getExistingCriticalSchedules(regions, "C");// Region=NA, Type='C=Create'
    		if(schList == null || schList.size() <= 0) {
    			result = sAPExtrRegionWiseService.saveScheduleUser2CriticalRole(regions, curUser, "C") ;
    			msg  = "Status: Scheduling USER To CRITICAL Role Data :  ("+ ((result ) ?  "Successful": "Failed")+" )";
    		}else {
    			msg  = "Status: Scheduling USER To CRITICAL Role Data : ("+schList.size()+") Schedule's Already Exists... duplicate sceduling not allowed." ;
    		}
    	}

    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2CriticalRoleScheduls(regNames);
    	regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    	List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);//Checking Export option
    	boolean expEnabled = checkExportEnabled(expList);
		if(expEnabled) {
			model.addAttribute(Constants.ENABLE_U2CR_EXPORT, "Y");
		}
		model.addAttribute("regNames", regNames );
    	model.addAttribute(Constants.ALL_U2CR_SCH, expList);

    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2CriticalRole1Click";
    }

    @GetMapping("/shcdUser2CriticalRoleExport")
    @SuppressWarnings("all")
    public String shcdUser2CriticalRoleExport(@RequestParam("regToExport") String regToExport, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Export User2Critical Role Confirmation:"+regToExport);
		List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	//Saving Export Schedule
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		if(regToExport == null ||regToExport.length()== 0 || curUser == null) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Not Logged In/Session Expired.");
            return "sapextraction/sapExtrUser2CriticalRole1Click";
    	}

		String[] regArr = regToExport.split(",");
		//
		String msg = "Status: Scheduling USER To CRITICAL Role Data Export :";
		String failedRegns="";
		String succRegns="";

		synchronized (this){
    		for(String rgn:regArr) {//Iterating all regions received
    			 List<TrfCntrlSchModel> schList = sAPExtrRegionWiseService.getExistingCriticalSchedules(rgn, "E");// Region=NA, Type='E=EXPORT'
    			if(schList == null || schList.size() <= 0) {
    				boolean result = sAPExtrRegionWiseService.saveScheduleUser2CriticalRole(rgn, curUser, "E") ;
    				succRegns=succRegns+" "+rgn+" ";
    			}else {
    				failedRegns=failedRegns+" "+rgn+" ";
    			}
    		}
		}

		if(succRegns.length() > 1) {
			msg = msg+ " Succesfull for Regions ("+succRegns+")";
		}
		if(failedRegns.length() > 1) {
			msg = msg+" Failed/Already exists for Regions ("+failedRegns+")";
		}

		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2CriticalRoleScheduls(regNames);
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_U2CR_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_U2CR_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2CriticalRoleSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
		return "sapextraction/sapExtrUser2CriticalRole1Click";
    }





	//END CRITICAL ROLES


	//SAP ESTRACTION TRANSFER CONTROL (One CLICK) - REGION WISE

    @GetMapping("/sapExtrTrfCntrl1ClickPage")
    public String sapExtrTrfCntrl1ClickPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllTrfCntlScheduls(regNames);
    	String msg = "Status: No Schedules found for Transfer Control Data ";
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		msg = "Status: Schedules found for Transfer Control Data : ( "+schdList.size()+" )";
    		//Exportable Data
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_TRF_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getTransferSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrTrfControl1Click";
    }

    /**
	 * Method  : SAPExtractionOneClickController.java.sapExtrTrfCntrl1ClickSchedule()
	 *		   :<b>@param regions
	 *		   :<b>@param model
	 *		   :<b>@param request
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 10, 2021 11:27:47 AM
	 * Purpose : Schedule Region-Wise Transfer Control Process
	 * @return : String
	 */
    @PostMapping("/sapExtrTrfCntrl1ClickSchedule")
    public String sapExtrTrfCntrl1ClickSchedule(@RequestParam("regions") String regions,  Model model, HttpServletRequest request) {
    	log.info("Transfer Control - Selected Region: "+regions);
    	String regParam = regions;
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	if("0".equals(regions) || curUser == null) {
    		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllTrfCntlScheduls(regNames);
    		if(schdList != null && !schdList.isEmpty()) {
        		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
        		model.addAttribute("regNames", regNames );
    		}
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Session is expired...Please re-login");
            return "sapextraction/sapExtrTrfControl1Click";
    	}
    	//Prevent Duplicate Scheduling
    	boolean result=false;
    	String msg="";
    	synchronized (this){
    		int schCount = sAPExtrRegionWiseService.getExistingScheduleCount(regions, "C", "T");// Region=NA, Type='C=Create', Data='U = User2Role'
    		if(schCount <= 0) {
    			result = sAPExtrRegionWiseService.saveScheduleTrfContol(regions, curUser, "C") ;
    			msg  = "Status: Scheduling Transfer Control Data :  ("+ ((result ) ?  "Successful": "Failed")+" )";
    		}else {
    			msg  = "Status: Scheduling Transfer Control Data : ("+schCount+") Schedule Already Exists... duplicate scheduling not allowed." ;
    		}
    	}
    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllTrfCntlScheduls(regNames);
    	regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    	List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);//Checking Export option
    	boolean expEnabled = checkExportEnabled(expList);
		if(expEnabled) {
			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
		}
		model.addAttribute("regNames", regNames );
    	model.addAttribute(Constants.ALL_TRF_SCH, expList);
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrTrfControl1Click";
    }


	/**
	 * Method  : SAPExtractionOneClickController.java.down1ClickTrfCntrlDataExcel()
	 *		   :<b>@param redirectAttributes
	 *		   :<b>@param request
	 *		   :<b>@param response
	 *		   :<b>@return
	 *		   :<b>@throws IOException</b>
	 * @author : DChauras  @Created :Aug 10, 2021 5:56:58 PM
	 * Purpose :
	 * @return : ResponseEntity<InputStreamResource>
	 */
    @ResponseBody
    @GetMapping("/down1ClickTrfCntrlDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> down1ClickTrfCntrlDataExcel(@RequestParam("regToDownload") String regToDownload, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SAP Transfer Control Excel for Region: "+regToDownload);
		String filePath="";
		String fileNm = regToDownload+"_Career_Change_RegionWiseData_"+Utility.fmtMDY(new Date());
		List<TrfCntrlTransDataMdl> trfCntrlData = sAPExtrGaaDataService.getAllTrfControlExportableData(regToDownload);
		try {
			filePath = excelReportWriter.writeTrfCntrlTransReport(fileNm, "RegionWiseData", Constants.TRF_CNTRL_TRANSDATA, trfCntrlData);
		} catch (Exception e) {
			log.error("ERROR Writing Excel file:"+e.getMessage(), e);
		}

    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


    @GetMapping("/shcdTrfExport")
    @SuppressWarnings("all")
    public String shcdTrfExport(@RequestParam("regToExport") String regToExport, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Export Confirmation:"+regToExport);
		List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	//Saving Export Schedule
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		String[] regArr = regToExport.split(",");

		synchronized (this){
    		for(String rgn:regArr) {//Iterating all regions received
    			int schCount = sAPExtrRegionWiseService.getExistingScheduleCount(rgn, "E", "T");// Region=NA, Type='E=EXPORT', Data='U = User2Role'
    			if(schCount <= 0) {
    				boolean result = sAPExtrRegionWiseService.saveScheduleTrfContol(rgn, curUser, "E") ;
    			}
    		}
    	}
		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllTrfCntlScheduls(regNames);
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_TRF_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getTransferSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	String msg = "Status: Transfer Export Scheduled Successfully for Region: "+regToExport;
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
		return "sapextraction/sapExtrTrfControl1Click";
    }



    private List<TrfCntrlSchExportModel> getAllExportableSchedules(List<TrfCntrlSchModel> schdList){
    	List<TrfCntrlSchExportModel> finalList = new ArrayList<>();

    	List<TrfCntrlSchModel> createList = new ArrayList<>();//Temp List : Holds Create Data schedules
    	List<TrfCntrlSchModel> exportList = new ArrayList<>();//Temp List : holds Export Data schedules
    	for(TrfCntrlSchModel trfMdl: schdList) {
    		if(trfMdl.getType().equals("C")) {
    			createList.add(trfMdl);
    		}else if(trfMdl.getType().equals("E")) {
    			exportList.add(trfMdl);
    		}
    	}

    	for(TrfCntrlSchModel mdl : createList) {
    		boolean exp = true;
    		if(mdl.getSchStatus().equals("C")/*Completed creation of Data*/) {
    			String rgn = mdl.getRegion();
    			if(!exportList.isEmpty()) {
    				for(TrfCntrlSchModel eMdl : exportList) {
    					if(rgn.equals(eMdl.getRegion())) {
    						exp = false;
    						break;
    					}
    				}
    			}
    			finalList.add(buildTrfExpModel(mdl, exp));
    		}else {
    			finalList.add(buildTrfExpModel(mdl, false));
    		}
    	}

    	if(!exportList.isEmpty()) {
			for(TrfCntrlSchModel eMdl : exportList) {
				finalList.add(buildTrfExpModel(eMdl, false));
			}
		}
    	return finalList;
    }

    private TrfCntrlSchExportModel buildTrfExpModel(TrfCntrlSchModel trfMdl, boolean expReady) {
    	TrfCntrlSchExportModel exMdl = new TrfCntrlSchExportModel();
		exMdl.setRegion(trfMdl.getRegion());
		exMdl.setType(trfMdl.getType());
		exMdl.setSchDt(trfMdl.getSchDt());
		exMdl.setSchStatus(trfMdl.getSchStatus());
		exMdl.setDetails(trfMdl.getDetails());
		exMdl.setCreatedDt(trfMdl.getCreatedDt());
		exMdl.setCreatedBy(trfMdl.getCreatedBy());
		exMdl.setCompletedDt(trfMdl.getCompletedDt());
		exMdl.setExport((expReady)?"Y":"N");
		return exMdl;
    }

    private boolean checkExportEnabled(List<TrfCntrlSchExportModel> expList) {
    	boolean exportEnable = false;
    	for(TrfCntrlSchExportModel exp : expList) {
    		if(exp.getExport().equals("Y")) {
    			exportEnable = true;
    			break;
    		}
    	}
    	return exportEnable;
    }


	/**
	 * Method  : SAPExtractionOneClickController.java.processSchTrfCntrlRegionWise()
	 *		   :<b>@param activeSchedule
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 11, 2021 5:10:06 PM
	 * Purpose : This Method will be Called by the Scheduler to Extract Data for Given Region
	 * @return : String
	 */
    public List<SAPTrfCntrlSummaryMdl> processSchTrfCntrlRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: CREATE - Processing for Region:"+activeSchedule.getRegion() +" @ "+startTime);
    	Map<String, List<SAPUserAccessModel>> regTrfCntrlData = sAPExtrGaaDataService.startTrfContolRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: CREATE - Processing for Region:"+activeSchedule.getRegion() +" @ "+endTime+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseTrfCntrlSummary(regTrfCntrlData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("CREATE - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }


    	/**
    	 * Method  : SAPExtractionOneClickController.java.processExportTrfCntrlRegionWise()
    	 *		   :<b>@param activeSchedule
    	 *		   :<b>@return</b>
    	 * @author : DChauras  @Created :May 20, 2021 2:20:15 PM
    	 * Purpose : Export Data to Genesis,
    	 * @return : List<SAPTrfCntrlSummaryMdl>
    	 */
    public List<SAPTrfCntrlSummaryMdl> processExportTrfCntrlRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: EXPORT - Processing for Region:"+activeSchedule.getRegion() +" @ "+startTime);
    	Map<String, List<SAPUserAccessModel>> regTrfCntrlData = sAPExtrGaaDataService.startExportTrfContolRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: EXPORT - Processing for Region:"+activeSchedule.getRegion() +" @ "+endTime+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseTrfCntrlSummary(regTrfCntrlData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("EXPORT - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }


    public List<SAPTrfCntrlSummaryMdl> processExportUser2RoleRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: USER TO ROLE EXPORT - Processing for Region:"+activeSchedule.getRegion() +" @ "+startTime);
    	Map<String, List<SapGaaUser2RoleModel>> regUser2RoleData = sAPExtrGaaDataService.startExportUser2RoleRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: EXPORT USER TO ROLE - Processing for Region:"+activeSchedule.getRegion() +" @ "+endTime+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(regUser2RoleData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("EXPORT - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }

	//CRITCAL ROLES
    public List<SAPTrfCntrlSummaryMdl> processExportUser2CriticalRoleRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: USER TO ROLE EXPORT - Processing for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	Map<String, List<SapGaaUser2RoleModel>> regUser2RoleData = sAPExtrGaaDataService.startExportUser2CriticalRoleRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: EXPORT USER TO CRITICAL ROLE - Processing for Region:"+activeSchedule.getRegion() +" @ "+endTime+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(regUser2RoleData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("EXPORT - Total User to Critical Role Records Processed:"+totlaRecords);
    	return regSummary;
    }


    @GetMapping("/getTrfExportConfirmation")
    @SuppressWarnings("all")
    public String getTrfExportConfirmation(RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Export Confirmation");
		//TODO : Any additional Data that needs to be captured
		return "sapextraction/trfExportConfirmation";
    }

    @GetMapping("/export1ClickTrfCntrlDataToGenesis")
	@SuppressWarnings("all")
    public String export1ClickTrfCntrlDataToGenesis(Model model, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Exporting SAP Transfer Control Data to Genesis ");
		Map<String, LinkedList<SAPUserAccessModel>> trfCntrlData = (Map<String, LinkedList<SAPUserAccessModel>>)request.getSession().getAttribute("REG_TRF_CNTRL_DATA");
		int recCount = Utility.getGenesisRecordCount(trfCntrlData);
		int recInserted = sAPExtrGaaDataService.exportTrfCntrlDataGenesis(trfCntrlData, request);
		if(recCount == recInserted) {
			String msg  = "Total records inserted: "+recInserted;
	    	model.addAttribute("message", "true");
	    	model.addAttribute("success", msg);
		}else {
			String msg  = "Error inserting Data to Genesis ";
	    	model.addAttribute("message", "true");
	    	model.addAttribute("error", msg);
		}
		return "sapextraction/trfExportConfirmation";
    }

  //SAP ESTRACTION TRANSFER CONTROL (One CLICK) - REGION WISE



  //USER To ROLE (One CLICK) - REGION WISE

    @GetMapping("/sapUser2RoleOneClickPage")
    public String sapUser2RoleOneClickPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2RoleScheduls(regNames);
    	String msg = "Status: No Schedules found for USER TO ROLE Data ";
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		msg = "Status: Schedules found for USER TO ROLE Data : ( "+schdList.size()+" )";
    		//Exportable Data
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_TRF_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2RoleSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2Role1Click";
    }

    @PostMapping("/sapExtrUser2Role1ClickData")
    public String sapExtrUser2Role1ClickData(@RequestParam("regions") String regions, Model model, HttpServletRequest request) {
    	log.info("USER TO ROLE - Selected Region: "+regions);
    	String regParam = regions;
    	List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	if("0".equals(regions) || curUser == null) {
    		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2RoleScheduls(regNames);
    		if(schdList != null  && !schdList.isEmpty()) {
    			regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    			model.addAttribute("regNames", regNames );
    		}
    		model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Not Logged In");
            return "sapextraction/sapExtrUser2Role1Click";
    	}
    	boolean result = false;
    	String msg  = "";
    	//Prevent Duplicate Scheduling
    	synchronized (this){
    		int schCount = sAPExtrRegionWiseService.getExistingScheduleCount(regions, "C", "U");// Region=NA, Type='C=Create', Data='U = User2Role'
    		if(schCount <= 0) {
    			result = sAPExtrRegionWiseService.saveScheduleUser2Role(regions, curUser, "C") ;
    			msg  = "Status: Scheduling USER To Role Data :  ("+ ((result ) ?  "Successful": "Failed")+" )";
    		}else {
    			msg  = "Status: Scheduling USER To Role Data : ("+schCount+") Schedule Already Exists... duplicate sceduling not allowed." ;
    		}
    	}

    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2RoleScheduls(regNames);
    	regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    	List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);//Checking Export option
    	boolean expEnabled = checkExportEnabled(expList);
		if(expEnabled) {
			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
		}
		model.addAttribute("regNames", regNames );
    	model.addAttribute(Constants.ALL_TRF_SCH, expList);

    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2Role1Click";
    }

    @ResponseBody
    @GetMapping("/down1ClickUser2RoleDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> down1ClickUser2RoleDataExcel(@RequestParam("regToDownload") String regToDownload, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SAP User To Role Excel for Region: "+regToDownload);
		String filePath="";
		String fileNm =regToDownload+"_User_2_Role_RegionWiseData_"+Utility.fmtMDY(new Date());
		List<SapGaaUser2RoleTransModel> usr2RoleData = sAPExtrGaaDataService.getAllUser2RoleExportableData(regToDownload);
		try {
			filePath = excelReportWriter.writeUser2RoleTransReport(fileNm, "RegionWiseData", Constants.USER2ROLE_TRANSDATA, usr2RoleData);
		} catch (Exception e) {
			log.error("ERROR Writing Excel file:"+e.getMessage(), e);
		}

    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }


    @ResponseBody
    @GetMapping("/down1ClickUser2SodDataExcel")
	@SuppressWarnings("all")
    public ResponseEntity<InputStreamResource> down1ClickUser2SodDataExcel(@RequestParam("regToDownload") String regToDownload, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpServletResponse response) throws IOException{
		log.info("Downloading SAP User To SOD Excel for Region: "+regToDownload);
		String filePath="";
		String fileNm =regToDownload+"_User2SOD_RegionWiseData_"+Utility.fmtMDY(new Date());
		List<SapUser2SodTrnsModel> usr2SodData = sAPExtrGaaDataService.getAllUser2SodExportableData(regToDownload);
		try {
			filePath = excelReportWriter.writeSapUser2SodTrnsExcel(usr2SodData, fileNm, "RegionWise-USER2SOD");
		} catch (Exception e) {
			log.error("ERROR Writing Excel file:"+e.getMessage(), e);
		}

    	File fl = new File(filePath);
    	log.info("Download File name:"+fl.getName());
    	InputStreamResource resource = new InputStreamResource(new FileInputStream(fl));
    	return ResponseEntity.ok()
    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fl.getName())
        	.contentType(MediaType.TEXT_PLAIN)
        	.contentLength(fl.length())
        	.body(resource);
    }

    @GetMapping("/shcdUser2RoleExport")
    @SuppressWarnings("all")
    public String shcdUser2RoleExport(@RequestParam("regToExport") String regToExport, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Export User2Role Confirmation:"+regToExport);
		List<String> regNames = Utility.loadOneClickProperty(BASE_REGION);
    	//Saving Export Schedule
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		String[] regArr = regToExport.split(",");
		//
		String msg = "Status: Scheduling USER To Role Data Export :";
		String failedRegns="";
		String succRegns="";
		synchronized (this){
    		for(String rgn:regArr) {//Iterating all regions received
    			int schCount = sAPExtrRegionWiseService.getExistingScheduleCount(rgn, "E", "U");// Region=NA, Type='E=EXPORT', Data='U = User2Role'
    			if(schCount <= 0) {
    				boolean result = sAPExtrRegionWiseService.saveScheduleUser2Role(rgn, curUser, "E") ;
    				succRegns=succRegns+" "+rgn+" ";
    			}else {
    				failedRegns=failedRegns+" "+rgn+" ";
    			}
    		}
		}

		if(succRegns.length() > 1) {
			msg = msg+ " Succesfull for Regions ("+succRegns+")";
		}
		if(failedRegns.length() > 1) {
			msg = msg+" Failed/Already exists for Regions ("+failedRegns+")";
		}

		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2RoleScheduls(regNames);
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_TRF_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_TRF_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2RoleSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
		return "sapextraction/sapExtrUser2Role1Click";
    }



    public List<SAPTrfCntrlSummaryMdl> processSchUser2RoleRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: CREATE - Processing User to Role for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	Map<String, List<SapGaaUser2RoleModel>> user2RoleData = sAPExtrGaaDataService.startUser2RoleRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: CREATE - Processing for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(user2RoleData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("CREATE - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }

  //SAP ESTRACTION USER TO ROLE (One CLICK) - REGION WISE


    @SuppressWarnings("all")
	public void processGenesisTransferReport() {
		Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: GENESIS Transfer Report @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	try {
			Map <String, Map<String, List<SapDataTransferReportMdl>>> dataTrfReportMap = sAPExtrGaaDataService.getGenesisTransferReportData();
	    	endTime=Calendar.getInstance();
	    	log.info("COMPLETED: GENESIS Transfer Report @ "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" seconds.");
	    	/* EMAILING Data*/
	    	//emailUtil.sendGenesisTrfReportEmail("(LOCAL SERVER) Weekly Email - TEST REVIEW for PLATFORM : TEST PLATFORM", "D:\\tmp\\rqcutilsextract\\UserRolesList_09212021.csv", "ve1@its.jnj.com", "T");
	    	if(dataTrfReportMap != null && !dataTrfReportMap.isEmpty()) {
	    		Map<String, List<SapDataTransferReportMdl>> SIGNED_ITEMS_MAP = dataTrfReportMap.get("SIGNED_ITEMS");
	    		Map<String, List<SapDataTransferReportMdl>> OTHER_ITEMS_MAP  = dataTrfReportMap.get("OTHER_ITEMS");
	    		List<String> sysIDs = (Utility.getCache(Constants.TRF_REPORT_SO_SYSTEMS) !=null? (List<String>)Utility.getCache(Constants.TRF_REPORT_SO_SYSTEMS):new ArrayList<>());
	    		if(!sysIDs.isEmpty()) {
	    			log.info("Total Systems for Email :"+sysIDs.size());
	    			int emlCounter = 0;
	    			String envName = Utility.getServerProp("ENVIRONMENT");
	    			for(String platformName : sysIDs) {
	    				String fileNames = "";
	    				String reviewName = "";
	    				log.info("Building Excel Document for System :"+platformName);
	    				if(SIGNED_ITEMS_MAP != null && SIGNED_ITEMS_MAP.containsKey(platformName)) {
	    					List<SapDataTransferReportMdl> platformDataSO = SIGNED_ITEMS_MAP.get(platformName);
	    					reviewName = platformDataSO.get(0).getReviewName();
	    					//String signedOfFile = csvReportWriter.writeGenesisSignedOfCSV(platformDataSO, platformName+"_SignedOf"+"_"+Utility.fmtMDY(new Date())+".csv");
	    					String signedOfFile =  excelReportWriter.writeGenesisSignedOfExcel(platformDataSO, platformName+"_SignedOf"+"_"+Utility.fmtMDY(new Date()), "SignedOf");
		    				fileNames = signedOfFile;
	    				}

	    				if(OTHER_ITEMS_MAP != null && OTHER_ITEMS_MAP.containsKey(platformName)) {
	    					List<SapDataTransferReportMdl> platformDataOT = OTHER_ITEMS_MAP.get(platformName);
	    					//String otherFile    = csvReportWriter.writeGenesisSignedOfCSV(platformDataOT, platformName+"_NotSignedOf"+"_"+Utility.fmtMDY(new Date())+".csv");
	    					String otherFile    = excelReportWriter.writeGenesisSignedOfExcel(platformDataOT, platformName+"_NotSignedOf"+"_"+Utility.fmtMDY(new Date()), "NotSignedOf");
	    					if(fileNames.length() > 0) {
		    					fileNames=fileNames+";"+otherFile;
		    				}else {
		    					fileNames = otherFile;
		    				}

	    				}
	    				emlCounter++;
   	    				String toEmail=Utility.getPlatformEmailAddress(platformName);
   	    				log.info("Sending ("+envName+") GENESIS TRANSFER CONTROL Report email ("+reviewName+") for Platform: "+platformName+" - To Email "+toEmail);
   	    				//emailUtil.sendGenesisTrfReportEmail("("+envName+") ERP TRANSFER CONTROL Data Report for Platform: "+platformName, fileNames, toEmail, "T");
   	    				emailUtil.sendGenesisTrfReportEmail("("+envName+") Weekly Email - "+reviewName+" for PLATFORM : "+platformName, fileNames, toEmail, "T");
	    			}
	    			log.info("Total number of emails sent rrom ("+envName+") GENESIS TRANSFER CONTROL Report: "+emlCounter);
	    		}
	    	}else {
	    		log.info("NO DATA FOUND for GENESIS Transfer Control Report @ "+Utility.fmtMMDDYYYYTime(endTime.getTime()));
	    	}
    		//List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(user2RoleData);
	    	int totlaRecords=0;
	    	/*for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
	    		totlaRecords = totlaRecords+sumMdl.getCount();
	    	}*/
	    	//log.info("CREATE - Total Records Processed:"+totlaRecords);
    	} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
	}





    @SuppressWarnings("all")
   	public List<String> processGenesisUser2RoleReport(String triggeredBy, String finalEml ) {
   		Calendar startTime = Calendar.getInstance(), endTime = null;
   		String envName = Utility.getServerProp("ENVIRONMENT");
   		List<String> sysIDs=new ArrayList<>();
       	log.info(envName+" STARTED: GENESIS USER TO ROLE Report DATA COLLECTION @"+Utility.fmtMMDDYYYYTime(startTime.getTime()));
       	try{
       		sysIDs = sAPExtrGaaDataService.getGenesisUser2RoleReportSystems();
       		log.info(envName+" - Total Systems for GENESIS USER TO ROLE Report Email :"+sysIDs.size());
       		if(sysIDs != null && !sysIDs.isEmpty()) {
       			int seq = sAPExtrGaaDataService.getU2RReportSeq(finalEml);
       			seq++;
       			int logCount = sAPExtrGaaDataService.saveU2RRepPlatformEmailLog(seq, sysIDs, triggeredBy, (("1".equals(finalEml))? "FINAL-"+Constants.U2R_REPORT:Constants.U2R_REPORT));
       			log.info(envName+" - Total Systems for GENESIS USER TO ROLE Report Email LOG:"+logCount);
       			int totalSystems = sysIDs.size();
       			int emlCounter=0;
       			for(String platform : sysIDs) {
       				emlCounter++;
       				Calendar iStartTime = Calendar.getInstance();
       				log.info(envName+" START  ("+emlCounter+" Of "+totalSystems+") Colleting Data for GENESIS USER TO ROLE Report Platform ("+platform+") @ "+Utility.fmtMMDDYYYYTime(iStartTime.getTime()));
       				Map <String, List<SapUser2RoleReportMdl>> user2RoleReportMap = sAPExtrGaaDataService.getGenesisUser2RoleReportPlatformData(platform);
       				endTime=Calendar.getInstance();
       				log.info(envName+" COMPLETED ("+emlCounter+" Of "+totalSystems+") GENESIS USER TO ROLE Report DATA COLLECTION( "+platform+" ) @"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - iStartTime.getTimeInMillis())/1000)+" seconds.");
       				if(user2RoleReportMap != null && !user2RoleReportMap.isEmpty()) {
       					List<SapUser2RoleReportMdl> SIGNED_ITEMS_LST = user2RoleReportMap.get("SIGNED_ITEMS");
       	   	    		List<SapUser2RoleReportMdl> OTHER_ITEMS_LST  = user2RoleReportMap.get("OTHER_ITEMS");
       					String fileNames="";

       					if(SIGNED_ITEMS_LST != null && !SIGNED_ITEMS_LST.isEmpty()) {
   	    					if(SIGNED_ITEMS_LST.size() < 25000) {
   	    						String signedOfFile = excelReportWriter.writeGenesisU2RSignedOfExcel(SIGNED_ITEMS_LST, "UserToRole_"+platform+"_SignedOf"+"_"+Utility.fmtMDY(new Date()), "SignedOf");
   	   	    					fileNames = signedOfFile;
   	    					}else {
   	    						String signedOfFile =csvReportWriter.writeGenesisU2RSignedOfCSV(SIGNED_ITEMS_LST, "UserToRole_"+platform+"_SignedOf"+"_"+Utility.fmtMDY(new Date()));
   	    						fileNames = signedOfFile;
   	    					}
       					}

   	    				if(OTHER_ITEMS_LST != null && !OTHER_ITEMS_LST.isEmpty()) {
   	    					String otherFile 	= "";
   	    					if(OTHER_ITEMS_LST.size() < 25000) {
   	    						otherFile 	= excelReportWriter.writeGenesisU2RSignedOfExcel(OTHER_ITEMS_LST, "UserToRole_"+platform+"_NotSignedOf"+"_"+Utility.fmtMDY(new Date()), "NotSignedOf");
   	    					}else {
   	    						otherFile 	= csvReportWriter.writeGenesisU2RSignedOfCSV(OTHER_ITEMS_LST, "UserToRole_"+platform+"_NotSignedOf"+"_"+Utility.fmtMDY(new Date()));
   	    					}
   	    					if(fileNames.length() > 0) {
   		    					fileNames=fileNames+";"+otherFile;
   		    				}else {
   		    					fileNames = otherFile;
   		    				}
   	    				}
   	    				String toEmail=Utility.getPlatformEmailAddress(platform);
   	    				log.info(emlCounter+". Sending ("+emlCounter+" Of "+totalSystems+") "+envName+" - GENESIS USER TO ROLE Report email for Platform: "+platform+" - To Email Address : "+toEmail);
   	    				//emailUtil.sendGenesisU2RReportEmail("("+envName+") Weekly Email - ERP USER TO ROLE Review for Platform: "+platform, fileNames, toEmail, "U");
   	    				//Update Email Log Status
   	    				int recordsUpdated = sAPExtrRegionWiseDao.updateU2RRepPlatformEmailLog(seq, platform, (("1".equals(finalEml))? "FINAL-"+Constants.U2R_REPORT:Constants.U2R_REPORT), toEmail, fileNames);
   	    				if(recordsUpdated > 0) {
   	    					log.info("Email Log Updated for Platform:"+platform);
   	    				}
   	    			}
       			}
       			//Add EMAIL ROUTING here
       			String toEmlIds = userMenuDao.getUtilsConstVals(Constants.TOEMAIL_DIST_LIST_PERIODIC_REPORTS);
       			String ccEmlIds = userMenuDao.getUtilsConstVals(Constants.CCEMAIL_DIST_LIST_PERIODIC_REPORTS);
       			emailUtil.sendGenesisWeeklyReportEmail("("+envName+") Weekly Email - "+(("1".equals(finalEml))? "FINAL ":"")+"ERP USER TO ROLE Review", "", toEmlIds, ccEmlIds, "U");
       			log.info("Total number of emails sent for "+envName+" - GENESIS USER TO ROLE Weekly Report "+emlCounter);
       		}else {
       			log.info("NO DATA FOUND for GENESIS GENESIS USER TO ROLE Report @ "+Utility.fmtMMDDYYYYTime(endTime.getTime()));
       		}
       	} catch (Exception e) {
   			log.error("Error:"+e.getMessage(), e);
   		}
       	return sysIDs;
   	}


    //USER TO ROLE - DELTA REPORT

    @SuppressWarnings("all")
    @GetMapping("/processUser2RoleDeltaReport")
   	public String processGenesisUser2RoleDeltaReport() {
   		Calendar startTime = Calendar.getInstance(), endTime = null;
   		String envName = Utility.getServerProp("ENVIRONMENT");
   		Map<String, List<SapUser2RoleDeltaMdl>> allDataMap = new HashMap<>();

       	log.info("STARTED: GENESIS USER TO ROLE (DELTA) Report DATA COLLECTION @"+Utility.fmtMMDDYYYYTime(startTime.getTime()));
       	try{
       		Date repDate = new Date();
       		//Clear Data First
       		String clearedData = sAPExtrGaaDataService.clearUser2RoleDelta();
       		log.info("Cleared Old Data  "+clearedData);
       		Map<String, SapU2RDeltaSummaryMdl> sumMap = new HashMap<>();
       		List<SapU2RDeltaSummaryMdl> inDataLst = sAPExtrGaaDataService.getUser2RoleSummaryDeltaData("IN");//String type=IN/COL
       		List<SapU2RDeltaSummaryMdl> colDataLst = sAPExtrGaaDataService.getUser2RoleSummaryDeltaData("COL");//String type=IN/COL
       		if(inDataLst != null && !inDataLst.isEmpty()) {
       			String sKey="";
       			for(SapU2RDeltaSummaryMdl sumMdl : inDataLst) {
       				sKey = sumMdl.getUserId().toUpperCase().trim();
       				sumMdl.setUserId(sKey);
       				sumMdl.setReportDate(repDate);
       				sumMap.put(sKey, sumMdl);
       			}
       		}

       		if(colDataLst != null && !colDataLst.isEmpty()) {
       			String sKey="";
       			for(SapU2RDeltaSummaryMdl colMdl : colDataLst) {
       				sKey = colMdl.getUserId().toUpperCase().trim();
           			SapU2RDeltaSummaryMdl inMdl= sumMap.get(sKey);
           			if(inMdl == null) {
           				inMdl=new SapU2RDeltaSummaryMdl();
           				inMdl.setReportDate(repDate);
           				inMdl.setUserId(sKey);
           				inMdl.setRolesIn(0);
           			}
           			inMdl.setRolesCol(colMdl.getRolesCol());
           			sumMap.put(sKey, inMdl);
       			}
       		}

       		if(!sumMap.isEmpty()) {
       			//Save Summary Data
       			List<String> deltaUsrList = new ArrayList<>();
       			List<SapU2RDeltaSummaryMdl> allSumData = new ArrayList<>();
       			for(Map.Entry<String, SapU2RDeltaSummaryMdl> entry:sumMap.entrySet()) {
       				SapU2RDeltaSummaryMdl sumModel = entry.getValue();
       				allSumData.add(sumModel);
       				if(sumModel.getRolesIn() != sumModel.getRolesCol()) {
       					deltaUsrList.add(entry.getKey());
       				}
       			}
       			int insSumCount= sAPExtrRegionWiseDao.insertUser2RoleDeltaSummary(allSumData);
       			log.info("Total Summary Delta Records inserted ="+insSumCount);

       			//Getting USER To Role Data
       			allDataMap = sAPExtrGaaDataService.getGenesisUser2RoleData(deltaUsrList);
       			/////////////
       	  		int emlCounter=0;
           		if(allDataMap != null && !allDataMap.isEmpty()) {
           			for(Map.Entry<String, List<SapUser2RoleDeltaMdl>> pltData : allDataMap.entrySet()) {
           				String platform = pltData.getKey();
           				List<SapUser2RoleDeltaMdl> pltDataList = pltData.getValue();
           				log.info("Total Records for Platform : "+platform+" = "+pltDataList.size());
           				if(pltDataList != null && !pltDataList.isEmpty()) {
           					try {
           						log.info("Saving Delta Records for "+platform+" = "+pltDataList.size());
           						int deltaInserted = sAPExtrRegionWiseDao.insertUser2RoleDeltaReport(pltDataList);
           						log.info("Total Delta Records Saved for "+platform+" = "+deltaInserted);
           						//Sending Emails
           						String filePath = csvReportWriter.writeGenesisU2RDeltaCSV(pltDataList, "UserToRole_"+platform+"_DataNotPickedup"+"_"+Utility.fmtMDY(new Date())+".csv");
           						String toEmail=Utility.getPlatformEmailAddress(platform);
           						log.info(emlCounter+". Sending "+envName+" - GENESIS USER TO ROLE DELTA Report email for Platform: "+platform+" - To Email Address : "+toEmail);
           						emailUtil.sendGenesisU2RReportEmail("("+envName+") ERP USER TO ROLE DELTA Report Data for Platform: "+platform, filePath, toEmail, "D");
    						} catch (Exception e) {
    							log.error("ERROR saving Delta records for Platform "+ platform+ "("+pltDataList.size()+")  "+e.getMessage(), e);
    						}
           				}
           			}
           		}
       		}else {
       			log.info("USER TO ROLE DATA NOT EXPORTED TO GENESIS....Please EXPORT Data");
       		}


       	} catch (Exception e) {
   			log.error("Error:"+e.getMessage(), e);
   		}

       	return "sapextraction/user2roledeltapage";
   	}

    //START - USER TO SOD WEEKLY REPORT EMAIL
    @SuppressWarnings("all")
   	public void processGenesisUserToSodReport() {
   		Calendar startTime = Calendar.getInstance(), endTime = null;
   		String envName = Utility.getServerProp("ENVIRONMENT");
       	log.info(envName+" STARTED: GENESIS USER TO SOD Report DATA COLLECTION @"+Utility.fmtMMDDYYYYTime(startTime.getTime()));
       	try {
   			Map <String, Map<String, List<SapUser2SodReportMdl>>> user2SodeReportMap = sAPExtrGaaDataService.getGenesisUser2SodReportData();
   	    	endTime=Calendar.getInstance();
   	    	log.info(envName+" COMPLETED: GENESIS USER TO SOD REPORT DATA COLLECTION @"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" seconds.");
   	    	/* EMAILING Data*/
   	    	if(user2SodeReportMap != null && !user2SodeReportMap.isEmpty()) {
   	    		Map<String, List<SapUser2SodReportMdl>> SIGNED_ITEMS_MAP = user2SodeReportMap.get("SIGNED_ITEMS");
   	    		Map<String, List<SapUser2SodReportMdl>> OTHER_ITEMS_MAP  = user2SodeReportMap.get("OTHER_ITEMS");
   	    		List<String> sysIDs = (Utility.getCache(Constants.U2S_REPORT_SO_SYSTEMS) !=null? (List<String>)Utility.getCache(Constants.U2S_REPORT_SO_SYSTEMS):new ArrayList<>());
   	    		if(!sysIDs.isEmpty()) {
   	    			int emlCounter=0;
   	    			log.info(envName+" - Total Systems for GENESIS USER TO SOD Report Email :"+sysIDs.size());
   	    			for(String platformName : sysIDs) {
   	    				String fileNames="";
   	    				if(SIGNED_ITEMS_MAP != null && SIGNED_ITEMS_MAP.containsKey(platformName)) {
   	    					List<SapUser2SodReportMdl> platformDataSO = SIGNED_ITEMS_MAP.get(platformName);
   	    					String signedOfFile = excelReportWriter.writeGenesisU2SSignedOfExcel(platformDataSO, "UserToSod_"+platformName+"_SignedOf"+"_"+Utility.fmtMDY(new Date()), "SignedOf");
   	    					fileNames = signedOfFile;
   	    				}
   	    				if(OTHER_ITEMS_MAP != null && OTHER_ITEMS_MAP.containsKey(platformName)) {
   	    					List<SapUser2SodReportMdl> platformDataOT = OTHER_ITEMS_MAP.get(platformName);
   	    					String otherFile 	= excelReportWriter.writeGenesisU2SSignedOfExcel(platformDataOT, "UserToSod_"+platformName+"_NotSignedOf"+"_"+Utility.fmtMDY(new Date()), "NotSignedOf");
   		    				if(fileNames.length() > 0) {
   		    					fileNames=fileNames+";"+otherFile;
   		    				}else {
   		    					fileNames = otherFile;
   		    				}
   	    				}
   	    				emlCounter++;
   	    				String toEmail=Utility.getPlatformEmailAddress(platformName);
   	    				log.info(emlCounter+". Sending "+envName+" - GENESIS USER TO SOD Report email for Platform: "+platformName+" - To Email Address : "+toEmail);
   	    				emailUtil.sendGenesisU2RReportEmail("("+envName+") Weekly Email - ERP USER TO SOD Review for Platform: "+platformName, fileNames, toEmail, "US");
   	    			}
   	    			log.info("Total number of emails sent for "+envName+" - GENESIS USER TO SOD Report "+emlCounter);
   	    		}
   	    	}else {
   	    		log.info("NO DATA FOUND for GENESIS USER TO SOD Weekly Report @ "+Utility.fmtMMDDYYYYTime(endTime.getTime()));
   	    	}

       		//List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(user2RoleData);
   	    	int totlaRecords=0;
   	    	/*for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
   	    		totlaRecords = totlaRecords+sumMdl.getCount();
   	    	}*/
   	    	//log.info("CREATE - Total Records Processed:"+totlaRecords);
       	} catch (Exception e) {
   			log.error("Error:"+e.getMessage(), e);
   		}
   	}

  //END - USER TO SOD WEEKLY REPORT EMAIL




//USER TO CRITICAL ROLES

    public List<SAPTrfCntrlSummaryMdl> processSchUser2CriticalRoleRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: CREATE - Processing User to Critical Role for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	Map<String, List<SapGaaUser2RoleModel>> user2RoleData = sAPExtrGaaDataService.startUser2CriticalRoleRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: CREATE - Processing for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2RoleSummary(user2RoleData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("CREATE - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }



    // START - SAP USER2SOD

	@GetMapping("/sapExtrUser2Sod1ClickPage")
    public String sapExtrUser2Sod1ClickPage(Model model, HttpServletRequest request) {
    	List<String> regNames = Utility.loadUser2SodProperty(BASE_REGION);
    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2SodScheduls(regNames);
    	String msg = "Status: No Schedules found for USER TO SOD Data ";
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		msg = "Status: Schedules found for USER TO SOD Data : ( "+schdList.size()+" )";
    		//Exportable Data
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_U2SOD_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_U2SOD_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2SodSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2Sod1Click";
    }

    @PostMapping("/sapExtrUser2Sod1Clickata")
    public String sapExtrUser2Sod1Clickata(@RequestParam("regions") String regions, Model model, HttpServletRequest request) {
    	log.info("USER TO SOD - Selected Region: "+regions);
    	String regParam = regions;
    	List<String> regNames = Utility.loadUser2SodProperty(BASE_REGION);
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("regParam", regParam );
    	UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
    	if("0".equals(regions) || curUser == null) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Not Logged In/Session Expired.");
            return "sapextraction/sapExtrUser2Sod1Click";
    	}
    	boolean result = false;
    	String msg  = "";
    	//Prevent Duplicate Scheduling
    	synchronized (this){
    		 List<TrfCntrlSchModel> schList = sAPExtrRegionWiseService.getExistingU2SSchedules(regions, "C");// Region=NA, Type='C=Create'
    		if(schList == null || schList.size() <= 0) {
    			result = sAPExtrRegionWiseService.saveScheduleUser2Sod(regions, curUser, "C") ;
    			msg  = "Status: Scheduling USER To SOD Data :  ("+ ((result ) ?  "Successful": "Failed")+" )";
    		}else {
    			msg  = "Status: Scheduling USER To SOD Data : ("+schList.size()+") Schedule's Already Exists... duplicate sceduling not allowed." ;
    		}
    	}

    	List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2SodScheduls(regNames);
    	regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    	List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);//Checking Export option
    	boolean expEnabled = checkExportEnabled(expList);
		if(expEnabled) {
			model.addAttribute(Constants.ENABLE_U2SOD_EXPORT, "Y");
		}
		model.addAttribute("regNames", regNames );
    	model.addAttribute(Constants.ALL_U2SOD_SCH, expList);

    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
    	return "sapextraction/sapExtrUser2Sod1Click";
    }




    @GetMapping("/shcdUser2SodExport")
    @SuppressWarnings("all")
    public String shcdUser2SodExport(@RequestParam("regToExport") String regToExport, HttpServletRequest request, HttpServletResponse response, Model model) throws IOException{
		log.info("Export User2Sod Confirmation:"+regToExport);
		List<String> regNames = Utility.loadUser2SodProperty(BASE_REGION);
    	//Saving Export Schedule
		UserSearchModel curUser = (UserSearchModel)request.getSession().getAttribute(Constants.AUTH_USER);
		if(regToExport == null ||regToExport.length()== 0 || curUser == null) {
			model.addAttribute("message", "True");
            model.addAttribute("error", "Missing required values: Region Name/User Not Logged In/Session Expired.");
            return "sapextraction/sapExtrUser2Sod1Click";
    	}

		String[] regArr = regToExport.split(",");
		//
		String msg = "Status: Scheduling USER To SOD Data Export :";
		String failedRegns="";
		String succRegns="";

		synchronized (this){
    		for(String rgn:regArr) {//Iterating all regions received
    			 List<TrfCntrlSchModel> schList = sAPExtrRegionWiseService.getExistingU2SSchedules(rgn, "E");// Region=NA, Type='E=EXPORT'
    			if(schList == null || schList.size() <= 0) {
    				boolean result = sAPExtrRegionWiseService.saveScheduleUser2Sod(rgn, curUser, "E") ;
    				succRegns=succRegns+" "+rgn+" ";
    			}else {
    				failedRegns=failedRegns+" "+rgn+" ";
    			}
    		}
		}

		if(succRegns.length() > 1) {
			msg = msg+ " Succesfull for Regions ("+succRegns+") ";
		}
		if(failedRegns.length() > 1) {
			msg = msg+" Failed/Already exists for Regions ("+failedRegns+")";
		}

		List<TrfCntrlSchModel> schdList = sAPExtrRegionWiseService.getAllUser2SodScheduls(regNames);
    	if(schdList != null && !schdList.isEmpty()) {
    		regNames = sAPExtrRegionWiseService.allowRegionsForSch(regNames, schdList);//Method to remove regions from Duplicate Scheduling
    		List<TrfCntrlSchExportModel> expList = getAllExportableSchedules(schdList);
    		model.addAttribute(Constants.ALL_U2SOD_SCH, expList);
    		boolean expEnabled = checkExportEnabled(expList);
    		if(expEnabled) {
    			model.addAttribute(Constants.ENABLE_U2SOD_EXPORT, "Y");
    		}
    	}
    	List<TrfCntrlSummaryMdl> summaryList = sAPExtrRegionWiseService.getUser2SodSummary();
    	if(summaryList != null && !summaryList.isEmpty()) {
    		model.addAttribute("SUMMARY", summaryList);
    	}
    	model.addAttribute("regNames", regNames );
    	model.addAttribute("message", "True");
    	model.addAttribute("success", msg);
		return "sapextraction/sapExtrUser2Sod1Click";
    }


    public List<SAPTrfCntrlSummaryMdl> processSchUser2SodRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: CREATE - Processing USER TO SOD Data for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	Map<String, List<SapUser2SodModel>> user2SodData = sAPExtrGaaDataService.startUser2SodRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: CREATE - Processing for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2SodSummary(user2SodData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("CREATE - Total Records Processed:"+totlaRecords);
    	return regSummary;
    }


    public List<SAPTrfCntrlSummaryMdl> processExportUser2SodRegionWise(TrfCntrlSchModel activeSchedule) {
    	Calendar startTime = Calendar.getInstance(), endTime = null;
    	log.info("STARTED: USER TO SOD - Processing for Region:"+activeSchedule.getRegion() +" @ "+Utility.fmtMMDDYYYYTime(startTime.getTime()));
    	Map<String, List<SapUser2SodModel>> regUser2SodData = sAPExtrGaaDataService.startExportUser2SodRegionSch(activeSchedule);
    	endTime=Calendar.getInstance();
    	log.info("COMPLETED: EXPORT USER TO CRITICAL ROLE - Processing for Region:"+activeSchedule.getRegion() +" @ "+endTime+" Total time: "+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000));
    	List<SAPTrfCntrlSummaryMdl> regSummary = Utility.getRegionWiseUser2SodSummary(regUser2SodData);
    	int totlaRecords=0;
    	for(SAPTrfCntrlSummaryMdl sumMdl:regSummary) {
    		totlaRecords = totlaRecords+sumMdl.getCount();
    	}
    	log.info("EXPORT - Total User to Critical Role Records Processed:"+totlaRecords);
    	return regSummary;
    }



    //END - SAP USER2SOD




}
