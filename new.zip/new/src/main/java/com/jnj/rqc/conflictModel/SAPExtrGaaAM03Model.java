package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class SAPExtrGaaAM03Model {
	private String MANDT;
	private String BNAME;
	private String BCODE;

	private String GLTGV;
	private String GLTGB;

	private String USTYP;
	private String CLASS;
	private String LOCNT;
	private String UFLAG;
	private String ACCNT;
	private String ANAME;
	private String ERDAT;

	@Override
	public String toString() {
		return "SAPExtrGaaAM03Model [MANDT=" + MANDT + ", BNAME=" + BNAME + ", BCODE=" + BCODE + ", GLTGV=" + GLTGV
				+ ", GLTGB=" + GLTGB + ", USTYP=" + USTYP + ", CLASS=" + CLASS + ", LOCNT=" + LOCNT + ", UFLAG=" + UFLAG
				+ ", ACCNT=" + ACCNT + ", ANAME=" + ANAME + ", ERDAT=" + ERDAT + "]";
	}



}
