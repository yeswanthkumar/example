package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class U2RFinalSummaryMdl {
	private String 	region;
	private String 	Platform;
	private String 	environment;
	private String 	system;
	private int 	actvCount;
	private int 	invlCount;
	private int 	total;

	@Override
	public String toString() {
		return "U2RFinalSummaryMdl [region=" + region + ", Platform=" + Platform + ", environment=" + environment
				+ ", system=" + system + ", actvCount=" + actvCount + ", invlCount=" + invlCount + ", total=" + total
				+ "]";
	}










}
