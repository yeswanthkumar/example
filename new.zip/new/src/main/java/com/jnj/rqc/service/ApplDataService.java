package com.jnj.rqc.service;

import java.util.List;
import java.util.Map;

import com.jnj.rqc.models.AppDataModel;

public interface ApplDataService {

	public Map<String, List<AppDataModel>> getApplicationData(int tktNum);

}
