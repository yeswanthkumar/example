package com.jnj.rqc.masterdata.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.masterdata.dto.ZAccessTypeMdl;
import com.jnj.rqc.masterdata.dto.ZBussFuncMdl;
import com.jnj.rqc.masterdata.dto.ZPosVariantMdl;
import com.jnj.rqc.masterdata.dto.ZPositionMdl;
import com.jnj.rqc.masterdata.dto.ZRegionMdl;
import com.jnj.rqc.masterdata.dto.ZReqTypMdl;
import com.jnj.rqc.masterdata.dto.ZSectorMdl;
import com.jnj.rqc.masterdata.dto.ZSystemMdl;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.userabs.models.BfSctrRegSystemMdl;
import com.jnj.rqc.userabs.models.BfSctrRegnMdl;
import com.jnj.rqc.userabs.models.BsnsFuncSctrsMdl;
import com.jnj.rqc.userabs.models.RawSysDpendncMdl;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarMdl;
import com.jnj.rqc.userabs.models.ZSysPosAccessMdl;
import com.jnj.rqc.userabs.models.ZSysPositionsMdl;
import com.jnj.rqc.util.Utility;


@Service
public class MasterDataDaoImpl extends BaseDao implements MasterDataDao{
	static final Logger log = LoggerFactory.getLogger(MasterDataDaoImpl.class);

	/*@Override
	public List<ZBussFuncMdl> getAllZBussFunc(int bfid) throws SQLException, DataAccessException {
		List<ZBussFuncMdl> dataList = new ArrayList<ZBussFuncMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT BFID, BFNAME, BFDESC, ISACTIVE FROM SOD_DB_USER.ZBUSFUNC WHERE ISACTIVE='Y' ");
		if(bfid > 0) {
			sql.append(" AND BFID = '"+bfid+"' ");
		}
		sql.append(" ORDER BY BFID, BFNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZBussFuncMdl>(ZBussFuncMdl.class));
		log.info("ZBussFuncMdl Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/
	@Override
	public List<ZBussFuncMdl> getAllZBussFunc(int bfid) throws SQLException, DataAccessException {
		List<ZBussFuncMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT BF_ID as BFID, BF_NAME as BFNAME, BF_NAME as BFDESC, 'Y' as ISACTIVE FROM SOD_DB_USER.ZMASTER_DATA ");
		if(bfid > 0) {
			sql.append(" WHERE BF_ID = '"+bfid+"' ");
		}
		sql.append(" ORDER BY BF_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZBussFuncMdl.class));
		log.info("ZBussFuncMdl Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	@Override
	public List<ZReqTypMdl> getAllZReqTyp(int typid) throws SQLException, DataAccessException {
		List<ZReqTypMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT TYPEID, TYPENAME, TYPEDESC, ISACTIVE FROM SOD_DB_USER.ZREQTYPE WHERE ISACTIVE='Y' ");
		if(typid > 0) {
			sql.append(" AND TYPEID = '"+typid+"' ");
		}
		sql.append(" ORDER BY TYPEID, TYPENAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZReqTypMdl.class));
		log.info("ZREQTYP Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	/*
	@Override
	public List<ZSectorMdl> getAllZSectors(int secid) throws SQLException, DataAccessException {
		List<ZSectorMdl> dataList = new ArrayList<ZSectorMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT SECID, SECCODE, SECNAME, SECDESC, SECIMG, SECLOC, ISACTIVE FROM SOD_DB_USER.ZSECTOR WHERE ISACTIVE='Y' ");
		if(secid > 0) {
			sql.append(" AND SECID = '"+secid+"' ");
		}
		sql.append(" ORDER BY SECID, SECNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZSectorMdl>(ZSectorMdl.class));
		log.info("ZSECTOR Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	*/

	@Override
	public List<ZSectorMdl> getAllZSectors(int secid) throws SQLException, DataAccessException {
		List<ZSectorMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select distinct a.SEC_ID as SECID, a.SEC_NAME as SECNAME, b.SECDESC, b.SECCODE, b.SECIMG, b.SECLOC, b.ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA a, SOD_DB_USER.ZSECTOR b ");
		sql.append(" WHERE a.SEC_ID = b.SECID(+) ");
		if(secid > 0) {
			sql.append(" AND a.SEC_ID = '"+secid+"' ");
		}
		sql.append(" ORDER BY SEC_ID, SEC_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZSectorMdl.class));
		log.info("ZSECTOR Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}




	/**
	 * Method  : MasterDataDaoImpl.java.getAllZRegions()
	 *		   :<b>@param regid
	 *		   :<b>@return
	 *		   :<b>@throws SQLException
	 *		   :<b>@throws DataAccessException</b>
	 * @author : DChauras  @Created :Jan 31, 2023 4:42:28 PM
	 * Purpose :
	 * @return : List<ZRegionMdl>
	*/

	@Override
	public List<ZRegionMdl> getAllZRegions(int regid) throws SQLException, DataAccessException {
		List<ZRegionMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT a.REG_ID as REGID, a.REG_NAME as REGNAME, b.REGDESC, b.REGIMG, b.REGLOC, b.ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA a, SOD_DB_USER.ZREGION b ");
		sql.append(" WHERE a.REG_ID = b.REGID(+) ");
		if(regid > 0) {
			sql.append(" AND a.REG_ID = '"+regid+"' ");
		}
		sql.append(" ORDER BY REG_ID, REG_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZRegionMdl.class));
		log.info("ZREGION Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}


	/*
	@Override
	public List<ZRegionMdl> getAllZRegions(int regid) throws SQLException, DataAccessException {
		List<ZRegionMdl> dataList = new ArrayList<ZRegionMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT REGID, REGNAME, REGDESC, REGIMG, REGLOC, ISACTIVE FROM SOD_DB_USER.ZREGION WHERE ISACTIVE='Y' ");
		if(regid > 0) {
			sql.append(" AND REGID = '"+regid+"' ");
		}
		sql.append(" ORDER BY REGID, REGNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZRegionMdl>(ZRegionMdl.class));
		log.info("ZREGION Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	 */

	@Override
	public List<ZSystemMdl> getAllZSystems(int sysid) throws SQLException, DataAccessException {
		List<ZSystemMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, SYS_NAME as SYSNAME, SYS_NAME as SYSDESC, 'Y' as ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		if(sysid > 0) {
			sql.append(" WHERE SYS_ID = '"+sysid+"' ");
		}
		sql.append(" ORDER BY SYS_ID, SYS_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZSystemMdl.class));
		log.info("ZSYSTEM Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	/*
	@Override
	public List<ZSystemMdl> getAllZSystems(int sysid) throws SQLException, DataAccessException {
		List<ZSystemMdl> dataList = new ArrayList<ZSystemMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT SYSID, SYSNAME, SYSDESC, ISACTIVE FROM SOD_DB_USER.ZSYSTEM WHERE ISACTIVE='Y' ");
		if(sysid > 0) {
			sql.append(" AND SYSID = '"+sysid+"' ");
		}
		sql.append(" ORDER BY SYSID, SYSNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZSystemMdl>(ZSystemMdl.class));
		log.info("ZSYSTEM Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	*/

	@Override
	public List<ZPositionMdl> getAllZPositions(int posid) throws SQLException, DataAccessException {
		List<ZPositionMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT POS_ID as POSID, POS_NAME as POSNAME, POS_NAME as POSDESC, 'Y' as ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		if(posid > 0) {
			sql.append(" WHERE POS_ID = '"+posid+"' ");
		}
		sql.append(" ORDER BY POS_ID, POS_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZPositionMdl.class));
		log.info("ZPOSITION Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	/*
	@Override
	public List<ZPositionMdl> getAllZPositions(int posid) throws SQLException, DataAccessException {
		List<ZPositionMdl> dataList = new ArrayList<ZPositionMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT POSID, POSNAME, POSDESC, ISACTIVE FROM SOD_DB_USER.ZPOSITION WHERE ISACTIVE='Y' ");
		if(posid > 0) {
			sql.append(" AND POSID = '"+posid+"' ");
		}
		sql.append(" ORDER BY POSID, POSNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZPositionMdl>(ZPositionMdl.class));
		log.info("ZPOSITION Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	*/

	@Override
	public List<ZAccessTypeMdl> getAllZAccessTypes(int accid) throws SQLException, DataAccessException {
		List<ZAccessTypeMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT ACS_ID ACCID, ACS_NAME as ACCNAME, ACS_NAME as ACCDESC, 'Y' as ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		if(accid > 0) {
			sql.append(" WHERE ACS_ID = '"+accid+"' ");
		}
		sql.append(" ORDER BY ACS_ID, ACS_NAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZAccessTypeMdl.class));
		log.info("ZACCESSTYPE Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	/*
	@Override
	public List<ZAccessTypeMdl> getAllZAccessTypes(int accid) throws SQLException, DataAccessException {
		List<ZAccessTypeMdl> dataList = new ArrayList<ZAccessTypeMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ACCID, ACCNAME, ACCDESC, ISACTIVE FROM SOD_DB_USER.ZACCESSTYPE WHERE ISACTIVE='Y' ");
		if(accid > 0) {
			sql.append(" AND ACCID = '"+accid+"' ");
		}
		sql.append(" ORDER BY ACCID, ACCNAME ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZAccessTypeMdl>(ZAccessTypeMdl.class));
		log.info("ZACCESSTYPE Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	*/

	@Override
	public List<ZPosVariantMdl> getAllZPosVariants(int posvarid) throws SQLException, DataAccessException {
		List<ZPosVariantMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT PV_ID as POSVARID, PV_NAME as POSVARNAME, PV_NAME as POSVARDESC, ACS_ID as ACCID, 'Y' as ISACTIVE ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		if(posvarid > 0) {
			sql.append(" WHERE PV_ID = '"+posvarid+"' ");
		}
		sql.append(" ORDER BY PV_ID, ACS_ID ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<>(ZPosVariantMdl.class));
		log.info("ZACCESSTYPE Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	/*
	@Override
	public List<ZPosVariantMdl> getAllZPosVariants(int posvarid) throws SQLException, DataAccessException {
		List<ZPosVariantMdl> dataList = new ArrayList<ZPosVariantMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT POSVARID, ACCID, POSVARNAME, POSVARDESC, ISACTIVE FROM SOD_DB_USER.ZPOSVARIANT WHERE ISACTIVE='Y' ");
		if(posvarid > 0) {
			sql.append(" AND POSVARID = '"+posvarid+"' ");
		}
		sql.append(" ORDER BY POSVARID, ACCID ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {}, new BeanPropertyRowMapper<ZPosVariantMdl>(ZPosVariantMdl.class));
		log.info("ZACCESSTYPE Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	*/




	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.dao.MasterDataDao#getAllZBfSectors(java.lang.String)
	 */
	@Override
	public List<BsnsFuncSctrsMdl> getAllZBfSectors(String bfId) throws SQLException, DataAccessException {
		List<BsnsFuncSctrsMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		Object[] inParams ;
		sql.append(" SELECT DISTINCT a.BF_ID as BFID, a.SEC_ID as SECID, b.SECCODE, a.SEC_NAME as SECNAME, a.SEC_NAME as SECDESC, b.SECIMG, b.SECLOC ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA a, SOD_DB_USER.ZSECTOR b ");
		sql.append(" WHERE a.SEC_ID = b.SECID ");
		if(StringUtils.isNotEmpty(bfId)) {
			sql.append(" AND a.BF_ID = ? ");
			inParams = new Object[] {bfId};
		}else {
			inParams = new Object[] {};
		}
		sql.append(" ORDER BY 1, 2 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParams, new BeanPropertyRowMapper<>(BsnsFuncSctrsMdl.class));
		log.info("ZBusiness SECTOR's Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	/*@Override
	public List<BsnsFuncSctrsMdl> getAllZBfSectors(String bfId) throws SQLException, DataAccessException {
		List<BsnsFuncSctrsMdl> dataList = new LinkedList<BsnsFuncSctrsMdl>();
		StringBuilder sql = new StringBuilder();
		Object[] inParams ;
		sql.append(" Select a.BFID, b.SECID, b.SECCODE, b.SECNAME, b.SECDESC, b.SECIMG, b.SECLOC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_BF_SEC a, SOD_DB_USER.ZSECTOR b ");
		sql.append(" WHERE a.SECID = b.SECID  AND b.ISACTIVE = 'Y' ");
		if(StringUtils.isNotEmpty(bfId)) {
			sql.append(" AND a.BFID = ? ");
			inParams = new Object[] {bfId};
		}else {
			inParams = new Object[] {};
		}
		sql.append(" ORDER BY 1, 2 ");

		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParams, new BeanPropertyRowMapper<BsnsFuncSctrsMdl>(BsnsFuncSctrsMdl.class));
		log.info("ZBusiness SECTOR's Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/



	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.dao.MasterDataDao#getAllZBfSecRegions(java.lang.String, java.lang.String[])
	 */

	@Override
	public List<BfSctrRegnMdl> getAllZBfSecRegions(String bfId, String[] secIds) throws SQLException, DataAccessException {
		List<BfSctrRegnMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+secIds.length)] ;
		sql.append(" Select DISTINCT a.BF_ID as BFID, a.SEC_ID as SECID, b.REGID, b.REGNAME, b.REGDESC, b.REGIMG, b.REGLOC ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA a, SOD_DB_USER.ZREGION b ");
		sql.append(" WHERE a.REG_ID = b.REGID ");
		sql.append(" AND a.BF_ID = ? ");
		inParam[prmPos] =  bfId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.SEC_ID", secIds, inParam, sql);
		sql.append(" ORDER BY 1,2,3 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(BfSctrRegnMdl.class));
		log.info("ZBusiness SECTOR Regions Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}



	/*@Override
	public List<BfSctrRegnMdl> getAllZBfSecRegions(String bfId, String[] secIds) throws SQLException, DataAccessException {
		List<BfSctrRegnMdl> dataList = new LinkedList<BfSctrRegnMdl>();
		StringBuilder sql = new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+secIds.length)] ;
		sql.append(" Select a.BFID, a.SECID, b.REGID, b.REGNAME, b.REGDESC, b.REGIMG, b.REGLOC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_SEC_REG a, SOD_DB_USER.ZREGION b ");
		sql.append(" WHERE a.ISACTIVE = 'Y' AND b.ISACTIVE = 'Y' AND a.REGID = b.REGID " );
		sql.append(" AND a.BFID = ? ");
		inParam[prmPos] =  bfId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.SECID", secIds, inParam, sql);
		sql.append(" ORDER BY 1,2,3 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<BfSctrRegnMdl>(BfSctrRegnMdl.class));
		log.info("ZBusiness SECTOR Regions Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/



	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.dao.MasterDataDao#getAllZBfSecRegSystems(java.lang.String, java.lang.String[], java.lang.String[])
	 */
	@Override
	public List<BfSctrRegSystemMdl> getAllZBfSecRegSystems(String bfId, String[] secIds, String[] regIds) throws SQLException, DataAccessException {
		List<BfSctrRegSystemMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length)] ;
		sql.append(" SELECT DISTINCT a.BF_ID as BFID, a.SEC_ID as SECID, a.REG_ID as REGID, a.SYS_ID as SYSID, b.SYSNAME, b.SYSDESC ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA a, SOD_DB_USER.ZSYSTEM b ");
		sql.append(" WHERE a.SYS_ID = b.SYSID ");
		if(StringUtils.isNotEmpty(bfId)) {
			sql.append(" AND  a.BF_ID = ? ");
			inParam[prmPos] = bfId;
			prmPos++;
		}
		prmPos = Utility.buildQuery(prmPos, "a.SEC_ID", secIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.REG_ID", regIds, inParam, sql);
		sql.append(" ORDER BY 4, 2, 3, 1 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(BfSctrRegSystemMdl.class));
		log.info("ZBusiness SECTOR Region Systems Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	/*@Override
	public List<BfSctrRegSystemMdl> getAllZBfSecRegSystems(String bfId, String[] secIds, String[] regIds) throws SQLException, DataAccessException {
		List<BfSctrRegSystemMdl> dataList = new LinkedList<BfSctrRegSystemMdl>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length)] ;
		sql.append(" SELECT a.BFID, a.SECID, a.REGID, b.SYSID, b.SYSNAME, b.SYSDESC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_REG_SYS a, SOD_DB_USER.ZSYSTEM b ");
		sql.append(" WHERE a.ISACTIVE = b.ISACTIVE AND a.SYSID = b.SYSID ");
		if(StringUtils.isNotEmpty(bfId)) {
			sql.append(" AND  a.BFID = ? ");
			inParam[prmPos] = bfId;
			prmPos++;
		}
		prmPos = Utility.buildQuery(prmPos, "SECID", secIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "REGID", regIds, inParam, sql);
		sql.append(" ORDER BY 1, 2, 3, 4 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<BfSctrRegSystemMdl>(BfSctrRegSystemMdl.class));
		log.info("ZBusiness SECTOR Region Systems Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/


	@Override
	public List<ZSysPositionsMdl> getAllZSystemPositions(String bfId, String[] secIds, String[] regIds, String sysId) throws SQLException, DataAccessException {
		List<ZSysPositionsMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1)] ;
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, POS_ID as POSID, POS_NAME as POSNAME, POS_DESC as POSDESC ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		sql.append(" ORDER BY 1, 3 "); //JEHV-349 Sort by ascending order by position name
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(ZSysPositionsMdl.class));
		log.info("ZSystem Position Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.dao.MasterDataDao#getAllZSystemPositions(java.lang.String)
	 */
	/*@Override
	public List<ZSysPositionsMdl> getAllZSystemPositions(String sysId) throws SQLException, DataAccessException {
		List<ZSysPositionsMdl> dataList = new LinkedList<ZSysPositionsMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, POS_ID as POSID, POS_NAME as POSNAME, POS_NAME as POSDESC ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? ");
		sql.append(" ORDER BY 1, 2 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {sysId}, new BeanPropertyRowMapper<ZSysPositionsMdl>(ZSysPositionsMdl.class));
		log.info("ZSystem Position Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/



	/*@Override
	public List<ZSysPositionsMdl> getAllZSystemPositions(String sysId) throws SQLException, DataAccessException {
		List<ZSysPositionsMdl> dataList = new LinkedList<ZSysPositionsMdl>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT a.SYSID, a.POSID, b.POSNAME, b.POSDESC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_SYS_POS a, SOD_DB_USER.ZPOSITION b ");
		sql.append(" WHERE a.ISACTIVE = 'Y' AND b.ISACTIVE = 'Y' ");
		sql.append(" AND a.POSID = b.POSID ");
		sql.append(" AND a.SYSID = ? ");
		sql.append(" ORDER BY 1, 2 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {sysId}, new BeanPropertyRowMapper<ZSysPositionsMdl>(ZSysPositionsMdl.class));
		log.info("ZSystem Position Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/


	/* (non-Javadoc)
	 * @see com.jnj.rqc.masterdata.dao.MasterDataDao#getAllZSysPosnsAccess(java.lang.String, java.lang.String[])
	 */
	@Override
	public List<ZSysPosAccessMdl> getAllZSysPosnsAccess(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds) throws SQLException, DataAccessException {
		List<ZSysPosAccessMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1+posIds.length)] ;
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, POS_ID as POSID, ACS_ID as ACCID, ACS_NAME as ACCNAME, ACS_NAME as ACCDESC ") ;
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		sql.append(" ORDER BY 1, 2, 3 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(ZSysPosAccessMdl.class));
		log.info("ZSystem Position's Access Type Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}


	/*@Override
	public List<ZSysPosAccessMdl> getAllZSysPosnsAccess(String sysId, String[] posIds) throws SQLException, DataAccessException {
		List<ZSysPosAccessMdl> dataList = new LinkedList<ZSysPosAccessMdl>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+posIds.length)] ;
		sql.append(" SELECT a.SYSID, a.POSID, a.ACCID, b.ACCNAME, b.ACCDESC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_POS_ACC a, SOD_DB_USER.ZACCESSTYPE b ");
		sql.append(" WHERE a.ISACTIVE = b.ISACTIVE  AND a.ACCID = b.ACCID ");
		sql.append(" AND a.SYSID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.POSID", posIds, inParam, sql);
		sql.append(" ORDER BY 1, 2, 3 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<ZSysPosAccessMdl>(ZSysPosAccessMdl.class));
		log.info("ZSystem Position's Access Type Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/

	@Override
	public List<ZSysPosAccPvarMdl> getAllZSysPosAccPvar(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException {
		List<ZSysPosAccPvarMdl> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+secIds.length+regIds.length+1+posIds.length+acsIds.length)] ;
		sql.append(" SELECT DISTINCT SYS_ID as SYSID, POS_ID as POSID, POS_NAME as POSNAME, ACS_ID as ACCID, PV_ID as POSVARID, PV_NAME as POSVARNAME, PV_NAME as POSVARDESC, AD_ID as adid, AD_NAME as adname ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE BF_ID = ? ");
		inParam[prmPos] = bfId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "SEC_ID", secIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "REG_ID", regIds, inParam, sql);
		sql.append(" AND SYS_ID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "POS_ID", posIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "ACS_ID", acsIds, inParam, sql);
		sql.append(" ORDER BY 1,3,4,6 ");


		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(ZSysPosAccPvarMdl.class));
		log.info("ZSystem Posn's AccessType Pos Variants Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	/*@Override
	public List<ZSysPosAccPvarMdl> getAllZSysPosAccPvar(String sysId, String[] posIds, String[] acsIds) throws SQLException, DataAccessException {
		List<ZSysPosAccPvarMdl> dataList = new LinkedList<ZSysPosAccPvarMdl>();
		StringBuilder sql = new StringBuilder();
		int prmPos=0;
		Object[] inParam = new Object[(1+posIds.length+acsIds.length)] ;
		sql.append(" SELECT a.SYSID, a.POSID, a.ACCID, a.POSVARID, b.POSVARNAME, b.POSVARDESC ");
		sql.append(" FROM SOD_DB_USER.ZMAP_ACC_PVAR a, SOD_DB_USER.ZPOSVARIANT b ");
		sql.append(" WHERE a.ISACTIVE = 'Y' AND b.ISACTIVE = 'Y' AND a.POSVARID = b.POSVARID ");
		sql.append(" AND a.SYSID = ? ");
		inParam[prmPos] = sysId;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "a.POSID", posIds, inParam, sql);
		prmPos = Utility.buildQuery(prmPos, "a.ACCID", acsIds, inParam, sql);
		sql.append(" ORDER BY 1,2,3,4 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<ZSysPosAccPvarMdl>(ZSysPosAccPvarMdl.class));
		log.info("ZSystem Posn's AccessType Pos Variants Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/


	@Override
	public List<RawSysDpendncMdl> getSelectedExcsvPosVariants(String sysid, String[] posvarids) throws SQLException, DataAccessException {
		List<RawSysDpendncMdl> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+posvarids.length)] ;
		sql.append(" Select POS_ID as POSID, POS_NAME as POSNAME, ACS_ID as ACCID, ACS_NAME as ACCNAME, PV_ID as POSVARID, PV_NAME POSVARNAME ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" Where SYS_ID = ? ");
		inParam[prmPos] =  sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "PV_ID", posvarids, inParam, sql);
		sql.append(" ORDER BY 1, 3, 5 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<>(RawSysDpendncMdl.class));
		log.info("ACCESSIVE Variant Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}
	/*@Override
	public List<RawSysDpendncMdl> getSelectedExcsvPosVariants(String sysid, String[] posvarids) throws SQLException, DataAccessException {
		List<RawSysDpendncMdl> dataList = new ArrayList<RawSysDpendncMdl>();
		StringBuilder sql = new StringBuilder();
		int prmPos = 0;
		Object[] inParam = new Object[(1+posvarids.length)] ;
		sql.append(" Select d.POSID, d.POSNAME, a.ACCID, c.ACCNAME, a.POSVARID, a.POSVARNAME ");
		sql.append(" FROM SOD_DB_USER.ZPOSVARIANT a, ZMAP_ACC_PVAR b, ZACCESSTYPE c, ZPOSITION  d ");
		sql.append(" Where a.POSVARID = b.POSVARID AND b.ACCID = c.ACCID AND b.POSID = d.POSID ");
		sql.append(" AND b.SYSID = ? ");
		inParam[prmPos] =  sysid;
		prmPos++;
		prmPos = Utility.buildQuery(prmPos, "b.POSVARID", posvarids, inParam, sql);
		sql.append(" ORDER BY 1, 3, 5 ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), inParam, new BeanPropertyRowMapper<RawSysDpendncMdl>(RawSysDpendncMdl.class));
		log.info("ACCESSIVE Variant Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}*/

	@Override
	public List<StrKeyValPair> getStatusForVariants(String reqId, String sysid, String posid, String accid, String posvarid) throws SQLException, DataAccessException {
		List<StrKeyValPair> dataList = new LinkedList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" Select ACCEPT_DENY as key, RESOLUTION_CMNTS as val from SOD_DB_USER.ZREQ_EXCSVACCESS_APPROVAL ");
		sql.append(" Where reqid = ? and sysid = ? and posid = ? and accid = ? and posvarid = ? ");
		dataList  = getJdbcTemplateSRADUtils().query(sql.toString(), new Object[] {reqId, sysid, posid, accid, posvarid}, new BeanPropertyRowMapper<>(StrKeyValPair.class));
		log.info("getStatusForVariants Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}

	@Override
	public List<String> getZPosVariantName(String sysId, String posvarid) throws SQLException, DataAccessException {
		List<String> dataList = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT PV_NAME as POSVARNAME ");
		sql.append(" FROM SOD_DB_USER.ZMASTER_DATA ");
		sql.append(" WHERE SYS_ID = ? AND PV_ID = ? ");
		dataList  = getJdbcTemplateSRADUtils().queryForList(sql.toString(), new Object[] {sysId, posvarid}, String.class);
		log.info("ZPOSVAR Record count:"+(dataList.isEmpty()?"0":dataList.size()));
		return dataList;
	}



}
