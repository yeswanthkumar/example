package com.jnj.rqc.masterdata.service;

import com.jnj.rqc.masterdata.dto.ZAccessTypeRespDto;
import com.jnj.rqc.masterdata.dto.ZBussFuncRespDto;
import com.jnj.rqc.masterdata.dto.ZPosVariantRespDto;
import com.jnj.rqc.masterdata.dto.ZPositionRespDto;
import com.jnj.rqc.masterdata.dto.ZRegionRespDto;
import com.jnj.rqc.masterdata.dto.ZReqTypRespDto;
import com.jnj.rqc.masterdata.dto.ZSectorRespDto;
import com.jnj.rqc.masterdata.dto.ZSystemRespDto;
import com.jnj.rqc.userabs.models.ZBsFnSecRegSystemRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSecRegnsRespDto;
import com.jnj.rqc.userabs.models.ZBsnsFuncSectorsRespDto;
import com.jnj.rqc.userabs.models.ZPosnsAccessRespDto;
import com.jnj.rqc.userabs.models.ZSysPosAccPvarRespDto;
import com.jnj.rqc.userabs.models.ZSysPositionsRespDto;


public interface MasterDataService {

	/**
	 * Method  : MasterDataService.java.getZBusssFunc()
	 *		   :<b>@param bfid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:27:46 PM
	 * Purpose :
	 * @return : ZBussFuncRespDto
	*/
	public ZBussFuncRespDto getZBusssFunc(int bfid);

	/**
	 * Method  : MasterDataService.java.getZReqTyp()
	 *		   :<b>@param typid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:27:50 PM
	 * Purpose :
	 * @return : ZReqTypRespDto
	*/
	public ZReqTypRespDto getZReqTyp(int typid);

	/**
	 * Method  : MasterDataService.java.getZSectors()
	 *		   :<b>@param secid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:27:59 PM
	 * Purpose :
	 * @return : ZSectorRespDto
	*/
	public ZSectorRespDto getZSectors(int secid);

	/**
	 * Method  : MasterDataService.java.getZRegions()
	 *		   :<b>@param regid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:28:05 PM
	 * Purpose :
	 * @return : ZRegionRespDto
	*/
	public ZRegionRespDto getZRegions(int regid);

	/**
	 * Method  : MasterDataService.java.getZSystems()
	 *		   :<b>@param sysid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:28:12 PM
	 * Purpose :
	 * @return : ZSystemRespDto
	*/
	public ZSystemRespDto getZSystems(int sysid);

	/**
	 * Method  : MasterDataService.java.getZPositions()
	 *		   :<b>@param posid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 1, 2023 3:55:47 PM
	 * Purpose :
	 * @return : ZPositionRespDto
	*/
	public ZPositionRespDto getZPositions(int posid);

	/**
	 * Method  : MasterDataService.java.getZAccessTypes()
	 *		   :<b>@param accid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 3, 2023 3:45:37 PM
	 * Purpose :
	 * @return : ZAccessTypeRespDto
	*/
	public ZAccessTypeRespDto getZAccessTypes(int accid);

	/**
	 * Method  : MasterDataService.java.getZPosVariants()
	 *		   :<b>@param posvarid
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Feb 9, 2023 4:57:05 PM
	 * Purpose :Get all Position Variants for given Access Type
	 * @return : ZAPosVariantRespDto
	*/
	public ZPosVariantRespDto getZPosVariants(int posvarid);

	/**
	 * Method  : MasterDataService.java.getZBfSectors()
	 *		   :<b>@param bfId
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 9, 2023 10:52:45 AM
	 * Purpose : Get All Sectors for Given Business function.
	 * @return : ZBsnsFuncSectorsRespDto
	*/
	public ZBsnsFuncSectorsRespDto getZBfSectors(String bfId);

	/**
	 * Method  : MasterDataService.java.getZBfSectRegns()
	 *		   :<b>@param bfId
	 *		   :<b>@param secIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 10, 2023 12:10:27 PM
	 * Purpose : Get All regions for given Function ID and String[] secIds.
	 * @return : ZBsnsFuncSecRegnsRespDto
	*/
	public ZBsnsFuncSecRegnsRespDto getZBfSectRegns(String bfId, String[] secIds);

	/**
	 * Method  : MasterDataService.java.getZBfSectRegnSystems()
	 *		   :<b>@param bfId
	 *		   :<b>@param secIds
	 *		   :<b>@param regIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 10, 2023 5:18:42 PM
	 * Purpose : Get All Systems for given BFID, SECTORS and REGIONS
	 * @return : ZBsFnSecRegSystemRespDto
	*/
	public ZBsFnSecRegSystemRespDto getZBfSectRegnSystems(String bfId, String[] secIds, String[] regIds);

	/**
	 * Method  : MasterDataService.java.getZSystemPositions()
	 *		   :<b>@param sysIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2023 4:23:44 PM
	 * Purpose : Get All Positions for given System's
	 * @return : ZSysPositionsRespDto
	*/
	//public ZSysPositionsRespDto getZSystemPositions(String sysIds);
	public ZSysPositionsRespDto getZSystemPositions(String bfId, String[] secIds, String[] regIds, String sysId);

	/**
	 * Method  : MasterDataService.java.getZPosnsAccessTypes()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 13, 2023 5:58:52 PM
	 * Purpose : Get All Access Types for given System and Positions
	 * @return : ZPosnsAccessRespDto
	*/
	//public ZPosnsAccessRespDto getZPosnsAccessTypes(String sysId, String[] posIds);
	public ZPosnsAccessRespDto getZPosnsAccessTypes(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds);
	/**
	 * Method  : MasterDataService.java.getZAccsPosVariants()
	 *		   :<b>@param sysId
	 *		   :<b>@param posIds
	 *		   :<b>@param acsIds
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :Mar 16, 2023 11:57:48 AM
	 * Purpose :
	 * @return : ZSysPosAccPvarRespDto
	*/
	//public ZSysPosAccPvarRespDto getZAccsPosVariants(String sysId, String[] posIds, String[] acsIds);
	public ZSysPosAccPvarRespDto getZAccsPosVariants(String bfId, String[] secIds, String[] regIds, String sysId, String[] posIds, String[] acsIds);


}
