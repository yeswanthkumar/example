package com.jnj.rqc.dbextr.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MstInParams {
	String bfId;
	String secIds;
	String regIds;
	String sysId;
	String posIds;
	String acsTypIds;
	String posVarnts;
}
