package com.jnj.rqc.serviceImpl;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SAPUserAccessModel;
import com.jnj.rqc.conflictModel.SapDataTransferReportMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleModel;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dao.JDEExtrDao;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;
import com.jnj.rqc.service.JDEExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.Utility;

import au.com.bytecode.opencsv.CSVWriter;


@Service
public class JDEExtrDataServiceImpl implements JDEExtrDataService{

	static final Logger log = LoggerFactory.getLogger(JDEExtrDataServiceImpl.class);

	@Autowired
	Environment environment;
	@Autowired
	CSVReportWriter csvReportWriter;

	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	UserSearchService userSearchService;
	@Autowired
	GenesisDao genesisDao;
	@Autowired
	JDEExtrDao jDEExtrDao;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;


	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;



	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadJDEProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}

	@Override
	public List<SAPUserAccessModel> readTransferCntrlData(String templSysParam) {
		LinkedList<SAPUserAccessModel> allUserData = new LinkedList<>();
		try{
			log.info("Get User Data for System: "+templSysParam);
			List<SAPUserAccessModel> userLst = jDEExtrDao.getJDEUserData(templSysParam);//Get All Users for the given System
			log.info("Total Records of User Data from USR02 ("+(userLst !=null? userLst.size():"0")+" for System: "+templSysParam+")");
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			for(SAPUserAccessModel usrMdl:userLst) {
				usrMdl.setSapPlatform(Utility.getSapClientName(systemInfo[1]));
				usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
				usrMdl.setDescription("Access has been granted in the "+Utility.getSapClientName(systemInfo[3])+"-"+systemInfo[2]+" System application. If the user no longer needs access to this system then please select REVOKE");
				String pltInfo =Utility.getSapClientName(systemInfo[3]).equals(systemInfo[3])? "Access is Granted in "+systemInfo[3]:"Access is Granted in "+Utility.getSapClientName(systemInfo[3]) ;
				usrMdl.setDetails(pltInfo);
				usrMdl.setNtId(usrMdl.getNtId().trim());
				if(usrMdl.getNtId().length() > 16) {
					usrMdl.setNtId(usrMdl.getNtId().substring(0,15));//JDE has ID issue, some IDS are bigger than 16 Characters
				}
				usrMdl.setSapId(usrMdl.getNtId());
				if(!allUserData.contains(usrMdl)) {
					allUserData.add(usrMdl);
				}
			}
			log.info("All User ROLE Data for "+systemInfo[1]+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}

	@Override
	public List<SapGaaUser2RoleModel> readUser2RoleActData(String templSysParam) {
		log.info("templSysParam :"+templSysParam);
		//Separating ACTIVE/TRANSFERS from others records
    	List<SapGaaUser2RoleModel> activeTrfData = new LinkedList<>();
    	List<SapGaaUser2RoleModel> incompleteData = new LinkedList<>();

		List<SapGaaUser2RoleModel> userRoleData = readUser2RoleData(templSysParam, "R");//Added Parameter for Raw Data Saving
		//START -  SAVE ALL RAW DATA
		sAPExtrGaaDataService.saveUser2RoleAllRawData(userRoleData, templSysParam);
		//END -  SAVE ALL RAW DATA

		if(userRoleData != null && !userRoleData.isEmpty()) {
			for(SapGaaUser2RoleModel mdl:userRoleData) {
	    		if(mdl.getUserStatus().equals("ACTIVE") || mdl.getUserStatus().equals("TRANSFERRED")) {
	    			if(!activeTrfData.contains(mdl)) {//NO DUPLICATES
	    				activeTrfData.add(mdl);
	    			}
	    		}else {
	    			if(!incompleteData.contains(mdl)) {//NO DUPLICATES
	    				String usrId = mdl.getUserId();
	    				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usrId, 0);
						if(srchUsr != null) {
							mdl.setUserStatus(srchUsr.getEmpStatTxt());
						}else {
							mdl.setUserStatus("NO DATA FOUND");
						}
	    				incompleteData.add(mdl);
	    			}
	    		}
	    	}
		}

		if(incompleteData != null && !incompleteData.isEmpty()) {
			sAPExtrGaaDataService.sendInvldDataEmail(templSysParam, incompleteData);
		}
		return activeTrfData;
	}

	@Override
	public List<SapGaaUser2RoleModel> readUser2RoleData(String templSysParam, String calledBy) {
		LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
		try{
			log.info("Get User Data for System: "+templSysParam);
			List<SapGaaUser2RoleModel> userLst = jDEExtrDao.getJDEUser2RoleData(templSysParam);//Get All Users for the given System

			// START - Store Raw Data into USER2ROLE_RAWDATA
			if("R".equals(calledBy)) {
				saveUser2RoleRawData(userLst, templSysParam);
			}
			// END - Store Raw Data into USER2ROLE_RAWDATA

			log.info("Total Records for User2Role Data  ("+(userLst !=null? userLst.size():"0")+") for System: "+templSysParam);
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			int cnt=0;
			for(SapGaaUser2RoleModel usrMdl : userLst) {
				log.info("Processing User to Role Record ("+(++cnt)+" Of "+userLst.size()+")");
				String usrID = usrMdl.getUserId().trim();
				UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usrID, 1);
				usrMdl.setRevUserId("");
				usrMdl.setUserId(((srchUsr != null)?srchUsr.getWwId():usrID));
				usrMdl.setFirstName((srchUsr != null)?srchUsr.getGivenNm():"");
				usrMdl.setLastName((srchUsr != null)?srchUsr.getFmlyNm():"");
				usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
				//Logic added to replace role desc for roles not found
				String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
				if(rlDesc==null || rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
					rlDesc = (usrMdl.getRoleId() == null)? "":usrMdl.getRoleId().trim(); //FIX added on 08/04/2022 to Fix NULL Pointer in ROLE ID
				}
				//END
				usrMdl.setPrimaryReviewInfo2(rlDesc);
				usrMdl.setPrimaryReviewInfo3(" Within "+Utility.getSapClientName(systemInfo[3]));
				usrMdl.setAdditionalInfo1(Utility.getSapClientName(systemInfo[3]));
				usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
				usrMdl.setAdditionalInfo3((usrMdl.getRoleId() == null)? "":usrMdl.getRoleId().trim()); //FIX added on 08/04/2022 to Fix NULL Pointer in ROLE ID
				usrMdl.setUserStatus((srchUsr != null)?srchUsr.getEmpStatTxt():"NOT FOUND");
				allUserData.add(usrMdl);

			}
			log.info("All User ROLE Data for "+systemInfo[1]+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}


	/*@SuppressWarnings("all")
	@Override
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam){
		log.info("templSysParam :"+templSysParam);
		List<SapGaaUser2RoleModel> urseRoleData = readSAPGaaAM03Data(templSysParam);
		return urseRoleData;
	}
	*/

	@SuppressWarnings("all")
	@Override
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam){
		log.info("templSysParam :"+templSysParam);
		LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
		Map<String, List<String>> usrRoleMap = new HashMap<>();
		Map<String, String> roleNameValue = new HashMap<>();
		try {
			List<String> userLst = jDEExtrDao.getAllValidUsers(templSysParam);//Get All Users for the given System
			log.info("Total Users for ("+templSysParam+") ="+userLst.size());
			if(userLst != null && !userLst.isEmpty()) {
				for(String usr:userLst) {
					List<String> usrRoles = jDEExtrDao.getUsersRoles(usr, templSysParam);
					if(usrRoles != null && !usrRoles.isEmpty()) {
						for (String usrRole : usrRoles) {
							roleNameValue.put(usrRole, "");
						}

						if(usrRoleMap.containsKey(usr)) {
							List<String> roleList = usrRoleMap.get(usr);
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}else {
							List<String> roleList = new ArrayList<>();
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}
					}

				}

				log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));

				//Getting Role Descriptions for All Unique Role Names
				log.info("Getting Role Description for  : "+roleNameValue.size()+" Records.");
				for(String rlNm : roleNameValue.keySet()) {
					String roleDesc = jDEExtrDao.getRoleDescription(rlNm, templSysParam);
					if(roleDesc != null && roleDesc.length() > 0 ) {
						roleNameValue.put(rlNm, roleDesc);
					}
				}
				log.info("Completed Role Description for  : "+roleNameValue.size()+" Records.");
				//Preparing USER ROLE DATA
				//for(String usr:userLst) { Modified the Logic to Prepare Role Data only for Users Having Assigned ROLES
				//String userIdStr = usrRoleMap.keySet().stream()
                 //       .collect(Collectors.joining(","));

				log.info("Getting Users First Name/Last Name for "+templSysParam+" : "+usrRoleMap.size()+" Users.");
				for(String usr : usrRoleMap.keySet()) {
					UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usr, 1);
					String[] sysInfoArr = templSysParam.split("_");
					List<String> usrRolesLst = usrRoleMap.get(usr);
					if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
						for(String rls:usrRolesLst) {
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId(rls);
							usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls)));
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							//Logic added to replace role desc for roles not found
							String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
							if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
								rlDesc = usrMdl.getRoleId();
							}
							//END
							usrMdl.setPrimaryReviewInfo2(rlDesc);
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}else {//No Roles for the USER
						SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
						usrMdl.setRevUserId("");
						usrMdl.setUserId(usr);
						usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
						usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
						usrMdl.setRoleId("");
						usrMdl.setRoleDesc("");//No Roles Found
						usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
						usrMdl.setPrimaryReviewInfo2("");
						usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
						usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
						usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
						usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
						usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
						allUserData.add(usrMdl);
					}
				}//END - Preparing Role Data here
			}
			log.info("All USER-ROLE Data(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}




	//Region Wise User2Role
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String>templSysParam){
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		Map<String, List<SapGaaUser2RoleModel>> allUser2RoleData = new HashMap<>();
		Calendar startTime, endTime = null;
		for(String sysTempl :templSysParam) {
			LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<>();
			Map<String, List<String>> usrRoleMap = new HashMap<>();
			Map<String, String> roleNameValue = new HashMap<>();
			try{
				List<String> userLst = jDEExtrDao.getAllValidUsers(sysTempl);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					for(String usr:userLst) {
						List<String> usrRoles = jDEExtrDao.getUsersRoles(usr, sysTempl);
						if(usrRoles != null && !usrRoles.isEmpty()) {
							for (String usrRole : usrRoles) {
								roleNameValue.put(usrRole, "");
							}

							if(usrRoleMap.containsKey(usr)) {
								List<String> roleList = usrRoleMap.get(usr);
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}else {
								List<String> roleList = new ArrayList<>();
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}
						}
					}
					log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));
					//Getting Role Descriptions for All Unique Role Names
					for(String rlNm : roleNameValue.keySet()) {
						String roleDesc = jDEExtrDao.getRoleDescription(rlNm, sysTempl);
						if(roleDesc != null && roleDesc.length() > 0 ) {
							roleNameValue.put(rlNm, roleDesc);
						}
					}

					for(String usr : usrRoleMap.keySet()) {
						UserSearchModel srchUsr = sAPExtrGaaDataService.getUserStatusJJEDS(usr, 1);
						String[] sysInfoArr = sysTempl.split("_");
						List<String> usrRolesLst = usrRoleMap.get(usr);
						if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
							for(String rls:usrRolesLst) {
								SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
								usrMdl.setRevUserId("");
								usrMdl.setUserId(usr);
								usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
								usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
								usrMdl.setRoleId(rls);
								usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls)));
								usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
								//Logic added to replace role desc for roles not found
								String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
								if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
									rlDesc = usrMdl.getRoleId();
								}
								//END
								usrMdl.setPrimaryReviewInfo2(rlDesc);
								usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
								usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
								usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
								usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
								usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
								allUserData.add(usrMdl);
							}
						}else {//No Roles for the USER
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId("");
							usrMdl.setRoleDesc("");//No Roles Found
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							usrMdl.setPrimaryReviewInfo2("");
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}//END - Preparing Role Data here
				}
				allUser2RoleData.put(sysTempl, allUserData);
			} catch (Exception e) {
				log.error("Error:"+e.getMessage(), e);
			}
		}
		return allUser2RoleData;
	}


	@Override
	public String writeSapGaaUser2RoleCSV(List<SapGaaUser2RoleModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeSapGaaUser2RoleCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public String writeJdeUserAccessCSV(List<SAPUserAccessModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public String writeRegTrfCntrlCSV(Map<String, LinkedList<SAPUserAccessModel>> data, String fileName) {
		String filePath = "";
		List<SAPUserAccessModel> trfList = new ArrayList<>();
		for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry :data.entrySet() ) {
			trfList.addAll(entry.getValue());
		}
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(trfList, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	//GETTING REGION-WISE DATA

	@Override
	public Map<String, LinkedList<SAPUserAccessModel>> readSAPTrfContolRegionData(List<String> templSysParam) {
		Map<String, LinkedList<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		int i=1;
		Calendar startTime, endTime = null;

		for(String sysTemp:templSysParam) {//For loop - PER SYSTEM - START
			LinkedList<SAPUserAccessModel> allUserData = new LinkedList<>();
			startTime = Calendar.getInstance();
			log.info("****START  Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
			Map<String, List<String>> usrRoleMap = new HashMap<>();
			Map<String, String> roleNameValue = new HashMap<>();
			try{
				List<SAPUserAccessModel> userLst = jDEExtrDao.getJDEUserData(sysTemp);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Started");
					for(SAPUserAccessModel usr:userLst) {
						String prsnNum = jDEExtrDao.getUsersPersonNumber(usr.getSapId(), sysTemp);
						usr.setPersonNumber(prsnNum);
						String wwid = jDEExtrDao.getUsersWwId(prsnNum, sysTemp);
						usr.setWwid(wwid);
					}
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Completed");
				}
				//Preparing USER ACCESS DATA
				String[] systemInfo = sysTemp.split("_");
				for(SAPUserAccessModel usrMdl:userLst) {
					usrMdl.setSapPlatform("SAP "+systemInfo[1]);
					usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
					usrMdl.setDescription("Access has been granted in the SAP "+systemInfo[1]+"-"+(Utility.getSapClientName(systemInfo[2]))+" System application. If the user no longer needs access to this system then please select REVOKE");
					String pltInfo = Utility.getSapPlatformInfo(systemInfo[1]).equals(systemInfo[1])? "Access is Granted in SAP "+systemInfo[1]:Utility.getSapPlatformInfo(systemInfo[1]) ;
					usrMdl.setDetails(pltInfo);
					allUserData.add(usrMdl);
				}
				log.info("All User ROLE Data for System: "+sysTemp+" (size) :"+allUserData.size()+" Completed");
			} catch (Exception e) {
				log.error("Error (System: "+sysTemp+"):"+e.getMessage(), e);
			}
			endTime=Calendar.getInstance();
			log.info("****END  Compute Data for System : "+templSysParam+" - Start time: "+endTime+" Total time taken: "+((endTime.getTimeInMillis() -startTime.getTimeInMillis()/1000) )+" Seconds  *****");
			regionDataMap.put(sysTemp, allUserData);
		}////For loop - PER SYSTEM - END
		return regionDataMap;
	}



	@Override
	public int exportTrfCntrlDataGenesis(Map<String, LinkedList<SAPUserAccessModel>> regDataMap, HttpServletRequest request) {
		int totalRecords = 0;
		String region = "";
		try{
			for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry:regDataMap.entrySet()) {
				String sysDetail=entry.getKey();
				region=sysDetail.split("_")[0];
				List<SAPUserAccessModel> dataList = entry.getValue();
				log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
				if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
					int recordsIns = genesisDao.insertTrfCntrlData(dataList);
					totalRecords = totalRecords+recordsIns;
				}else {
					int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
					int startPos = 0;
					int endPos = Constants.GEN_BATCH_SIZE;
					for(int i=0; i<pgCnt;i++) {
						List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
						int recordsIns = genesisDao.insertTrfCntrlData(insData);
						totalRecords = totalRecords +recordsIns;
						startPos = startPos + Constants.GEN_BATCH_SIZE;
						endPos = endPos + Constants.GEN_BATCH_SIZE;
						if(endPos >dataList.size()) {
							endPos = dataList.size();
						}
					}
				}
			}
			log.info("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}






	/**
	 * Method  : SAPExtrGaaDataService.java.readTrfContolRegionSch()
	 *		   :<b>@param activeSchedule
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 12, 2021 2:34:36 PM
	 * Purpose :REGION WISE TRANSFER CONTROL DATA - Initiated by Scheduler
	 * @return : Map<String,List<SAPUserAccessModel>>
	 */
	@Override
	public Map<String, List<SAPUserAccessModel>> startTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("All Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
				List<SAPUserAccessModel> trfUserData = readTransferCntrlData(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				//
				if(trfUserData != null && !trfUserData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
					//Write Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					String[] systemInfo = sysTemp.split("_");
					sumMdl.setRegion(systemInfo[0]);
					sumMdl.setPlatform(systemInfo[1]);
					sumMdl.setEnvironment(systemInfo[2]);
					sumMdl.setSystem(systemInfo[3]);
					sumMdl.setCreatedRecCount(trfUserData.size());
					sumMdl.setCreatedDt(new Date());
					sumMdl.setCreatedBy(activeSchedule.getCreatedBy());
					sumMdl.setCollStatus("C");
					sAPExtrRegionWiseDao.saveTrfDataSummary(sumMdl);
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, trfUserData);
			}
		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	@Override
	public Map<String, List<SAPUserAccessModel>> startExportTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("EXPORT- All Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
				List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

				if(trfUserData != null && !trfUserData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
					//Write Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					String[] systemInfo = sysTemp.split("_");
					sumMdl.setRegion(systemInfo[0]);
					sumMdl.setPlatform(systemInfo[1]);
					sumMdl.setEnvironment(systemInfo[2]);
					sumMdl.setSystem(systemInfo[3]);
					sumMdl.setExpRecCount(totalInsertedRecords);
					sumMdl.setExpStatus("C");
					sumMdl.setExpDt(new Date());
					sumMdl.setExpBy(activeSchedule.getCreatedBy());
					sumMdl.setCollStatus("C");
					sAPExtrRegionWiseDao.updateTrfExportSummary(sumMdl);
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, trfUserData);
			}
		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("EXPORT- USER TO ROLE All Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
				List<SapGaaUser2RoleModel> user2RleData = readUser2RoleExportDataTable(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

				if(user2RleData != null && !user2RleData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					int totalInsertedRecords = exportUser2RoleDataToGenesis(user2RleData, sysTemp);
					//Write Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					String[] systemInfo = sysTemp.split("_");
					sumMdl.setRegion(systemInfo[0]);
					sumMdl.setPlatform(systemInfo[1]);
					sumMdl.setEnvironment(systemInfo[2]);
					sumMdl.setSystem(systemInfo[3]);
					sumMdl.setExpRecCount(totalInsertedRecords);
					sumMdl.setExpStatus("C");
					sumMdl.setExpDt(new Date());
					sumMdl.setExpBy(activeSchedule.getCreatedBy());
					sumMdl.setCollStatus("C");
					sAPExtrRegionWiseDao.updateUser2RoleExportSummary(sumMdl);
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, user2RleData);
			}
		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}





	/**
	 * Method  : SAPExtrGaaDataServiceImpl.java.readExpotDatable()
	 *		   :<b>@param templSysParam
	 *		   :<b>@return</b>
	 * @author : DChauras  @Created :May 20, 2021 3:23:31 PM
	 * Purpose : Getting Transfer Control Data to Export to Genesis
	 * @return : List<SAPUserAccessModel>
	 */
	private List<SAPUserAccessModel> readTrfExportDataTable(String templSysParam) {

		List<SAPUserAccessModel> userLst = new LinkedList<>();
		try{
			List<TrfCntrlTransDataMdl> dataLst = sAPExtrRegionWiseDao.getExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}


	private List<SapGaaUser2RoleModel> readUser2RoleExportDataTable(String templSysParam) {

		List<SapGaaUser2RoleModel> userLst = new LinkedList<>();
		try{
			List<SapGaaUser2RoleTransModel> dataLst = sAPExtrRegionWiseDao.getUser2RoleExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisUser2RoleData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}


	private List<SAPUserAccessModel> buidlGenesisData(List<TrfCntrlTransDataMdl> dataLst) {
		List<SAPUserAccessModel> dList= new ArrayList<>();

		SAPUserAccessModel sapUser = null;
		for(TrfCntrlTransDataMdl trnsMdl : dataLst) {
			sapUser = new SAPUserAccessModel();
			sapUser.setSapId(trnsMdl.getUserNtId());
			//sapUser.setGltgb(gltgb);
			sapUser.setNtId(trnsMdl.getUserNtId());
			//sapUser.setPersonNumber(personNumber);
			sapUser.setWwid(trnsMdl.getWwid());
			sapUser.setSapPlatform(trnsMdl.getPlatform());
			sapUser.setSystemClient(trnsMdl.getSystem());
			sapUser.setDescription(trnsMdl.getDescription());
			sapUser.setDetails(trnsMdl.getDetails());
			dList.add(sapUser);
		}
		return dList;
	}


	private List<SapGaaUser2RoleModel> buidlGenesisUser2RoleData(List<SapGaaUser2RoleTransModel> dataLst) {
		List<SapGaaUser2RoleModel> dList= new ArrayList<>();

		SapGaaUser2RoleModel sapUser = null;
		for(SapGaaUser2RoleTransModel trnsMdl : dataLst) {
			sapUser = new SapGaaUser2RoleModel();
			sapUser.setRevUserId("");
			sapUser.setUserId(trnsMdl.getUserId());
			sapUser.setPrimaryReviewInfo1(trnsMdl.getPrimaryReviewInfo1());
			sapUser.setPrimaryReviewInfo2(trnsMdl.getPrimaryReviewInfo2());
			sapUser.setPrimaryReviewInfo3(trnsMdl.getPrimaryReviewInfo3());
			sapUser.setAdditionalInfo1(trnsMdl.getAdditionalInfo1());
			sapUser.setAdditionalInfo2(trnsMdl.getAdditionalInfo2());
			sapUser.setAdditionalInfo3(trnsMdl.getAdditionalInfo3());
			dList.add(sapUser);
		}
		return dList;
	}



	@Override
	public int insertTransferTransactions(List<SAPUserAccessModel> trfUserData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(trfUserData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(trfUserData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(trfUserData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = trfUserData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >trfUserData.size()) {
						endPos = trfUserData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional Transfer Control Data"+e.getMessage(), e);
		}

		return totalRecords;
	}



	@Override
	public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(user2RoleData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2RoleData.size()) {
						endPos = user2RoleData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to ROLE Data"+e.getMessage(), e);
		}

		return totalRecords;
	}




	@Override
	public int exportTrfCntrlDataToGenesis(List<SAPUserAccessModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertTrfCntrlData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertTrfCntrlData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR Total Records inserted for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}



	@Override
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2RoleData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2RoleData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User2 Role Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Role records to Genesis for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("ERROR exporting User to Role records to Genesis  for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}




	private List<TrfCntrlTransDataMdl> buidlTrfTransData(List<SAPUserAccessModel> insData, String templetParam, String usrScheduled){
		List<TrfCntrlTransDataMdl> dList= new ArrayList<>();
		String[] systemInfo = templetParam.split("_");
		TrfCntrlTransDataMdl trfMdl = null;
		String wwid="";
		for(SAPUserAccessModel sapMdl : insData) {
			trfMdl = new TrfCntrlTransDataMdl();
			trfMdl.setRegion(systemInfo[0]);
			trfMdl.setPlatform(systemInfo[1]);
			trfMdl.setEnvironment(systemInfo[2]);
			trfMdl.setSystem(systemInfo[3]);
			trfMdl.setDescription(sapMdl.getDescription());
			trfMdl.setDetails(sapMdl.getDetails());
			trfMdl.setUserNtId(sapMdl.getSapId());
			//TODO - Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getWwid() != null && sapMdl.getWwid().length() > 16) {
				wwid =sapMdl.getWwid().substring(0, 15);
			}else {
				wwid = sapMdl.getWwid();
			}
			//TODO - END
			trfMdl.setWwid(wwid);
			trfMdl.setCreatedBy(usrScheduled);
			trfMdl.setCreatedDt(new Date());
			dList.add(trfMdl);
		}
		return dList;
	}

	private List<SapGaaUser2RoleTransModel> buidlUser2RoleTransData(List<SapGaaUser2RoleModel> insData, String templetParam, String usrScheduled){
		List<SapGaaUser2RoleTransModel> dList= new ArrayList<>();
		String[] systemInfo = templetParam.split("_");
		SapGaaUser2RoleTransModel usrMdl = null;
		String wwid="";
		for(SapGaaUser2RoleModel sapMdl : insData) {
			usrMdl = new SapGaaUser2RoleTransModel();
			usrMdl.setRegion(systemInfo[0]);
			usrMdl.setPlatform(systemInfo[1]);
			usrMdl.setEnvironment(systemInfo[2]);
			usrMdl.setSystem(systemInfo[3]);
			usrMdl.setRevUserId("");
			//Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getUserId() != null && sapMdl.getUserId().length() > 16) {
				wwid =sapMdl.getUserId().substring(0, 15);
			}else {
				wwid = sapMdl.getUserId();
			}
			//END
			usrMdl.setUserId(wwid);
			usrMdl.setFirstName(sapMdl.getFirstName());
			usrMdl.setLastName(sapMdl.getLastName());
			usrMdl.setRoleId(sapMdl.getRoleId());
			usrMdl.setRoleDesc(sapMdl.getRoleDesc());
			usrMdl.setPrimaryReviewInfo1(sapMdl.getPrimaryReviewInfo1());
			usrMdl.setPrimaryReviewInfo2(sapMdl.getPrimaryReviewInfo2());
			usrMdl.setPrimaryReviewInfo3(sapMdl.getPrimaryReviewInfo3());

			usrMdl.setAdditionalInfo1(sapMdl.getAdditionalInfo1());
			usrMdl.setAdditionalInfo2(sapMdl.getAdditionalInfo2());
			usrMdl.setAdditionalInfo3(sapMdl.getAdditionalInfo3());
			usrMdl.setCreatedBy(usrScheduled);
			usrMdl.setCreatedDt(new Date());
			dList.add(usrMdl);
		}
		return dList;
	}



	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("All USER To ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		//List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam)
    	Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<>();
		Calendar startTime, endTime = null;
		try{
			for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
				List<SapGaaUser2RoleModel> user2RoleData = readSapUserToRoleData(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				//
				if(user2RoleData != null && !user2RoleData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
					//Write Summary
					TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
					String[] systemInfo = sysTemp.split("_");
					sumMdl.setRegion(systemInfo[0]);
					sumMdl.setPlatform(systemInfo[1]);
					sumMdl.setEnvironment(systemInfo[2]);
					sumMdl.setSystem(systemInfo[3]);
					sumMdl.setCreatedRecCount(user2RoleData.size());
					sumMdl.setCreatedDt(new Date());
					sumMdl.setCreatedBy(activeSchedule.getCreatedBy());
					sumMdl.setCollStatus("C");
					sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, user2RoleData);
			}
		} catch (Exception e) {
			log.error("ERROR PROCESSING USER to ROLE DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}



	@Override
	public Map <String, Map<String, List<SapDataTransferReportMdl>>> getGenesisTransferReportData() {
		Map <String, Map<String, List<SapDataTransferReportMdl>>> allDataMap = new HashMap<>();
		Map<String, List<SapDataTransferReportMdl>> repSignedOffMap = new HashMap<>();
		Map<String, List<SapDataTransferReportMdl>> repOthersfMap = new HashMap<>();

		try{
			List<SapDataTransferReportMdl> repLst = genesisDao.getGenesisTransferCtrlReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapDataTransferReportMdl repMdl : repLst ) {
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapDataTransferReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(repMdl.getSapPlatfrom())) {
							sOfLst = repSignedOffMap.get(repMdl.getSapPlatfrom());
							sOfLst.add(repMdl);
							repSignedOffMap.put(repMdl.getSapPlatfrom(), sOfLst);
						}else {
							sOfLst = new ArrayList<> ();
							sOfLst.add(repMdl);
							repSignedOffMap.put(repMdl.getSapPlatfrom(), sOfLst);
						}
					}else {//Other Items
						List<SapDataTransferReportMdl> othLst = null;
						if(repOthersfMap.containsKey(repMdl.getSapPlatfrom())) {
							othLst = repOthersfMap.get(repMdl.getSapPlatfrom());
							othLst.add(repMdl);
							repOthersfMap.put(repMdl.getSapPlatfrom(), othLst);
						}else {
							othLst = new ArrayList<> ();
							othLst.add(repMdl);
							repOthersfMap.put(repMdl.getSapPlatfrom(), othLst);
						}
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersfMap);
			}
		} catch (Exception e) {
			log.error("Error Collecting Genesis Transfer Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}


	@Override
	public String writeLogData(StringBuilder data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 writer.writeNext(new String[]{ data.toString()});
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing Log Data: "+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	//RAW DATA COLLECTION STARTS HERE

	private void saveUser2RoleRawData(List<SapGaaUser2RoleModel> userLst, String templSysParam){
		List<User2RoleRawDataMdl> allUserData = new ArrayList<>();
		String[] sysInfoArr = templSysParam.split("_");
		for(SapGaaUser2RoleModel usrRlMdl : userLst){
			User2RoleRawDataMdl usrMdl = new User2RoleRawDataMdl();
			usrMdl.setRegion(sysInfoArr[0]);
			usrMdl.setPlatform(sysInfoArr[1]);
			usrMdl.setEnvironment(sysInfoArr[2]);
			usrMdl.setSystem(sysInfoArr[3]);
			usrMdl.setUserId(usrRlMdl.getUserId());
			usrMdl.setRoleId(usrRlMdl.getRoleId());
			usrMdl.setRoleDesc(Utility.isEmpty(usrRlMdl.getRoleDesc()) ? usrRlMdl.getRoleId() :usrRlMdl.getRoleDesc());
			allUserData.add(usrMdl);
		}
		//Insert Data
		if(!allUserData.isEmpty()) {
			int totalRec = sAPExtrGaaDataService.insertUser2RoleRawData(allUserData);
			log.info("TOTAL RAW DATA for System ("+templSysParam+") :"+allUserData.size()+"  INSERTED: "+totalRec);
		}
	}







}
