package com.jnj.rqc.userabs.models;


import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAbsConflictMdl implements Serializable{
	private static final long serialVersionUID = -6140363082779451983L;

	private String userid;
	private String reqid;
	private String riskid;
	private String riskdesc;
	private String app1;
	private String appName1;
	private String posv1;
	private String posvName1;
	private String app2;
	private String appName2;
	private String posv2;
	private String posvName2;
	private String conflict;
	private String riskLevel;
	private String mitId;
	private String mitDesc;
	private Date   createdon;
	private String status;
	private String acceptDeny;
	private String comments;
	private String resolvedby;
	private Date   resolvedon;
	private String isExisting;
	private String isExisting2;
}

