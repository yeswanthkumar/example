package com.jnj.rqc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.jnj.rqc.models.AppRoutingModel;

public interface AppEmailRoutingDao {
	public List<AppRoutingModel> getAppRoutingData() throws SQLException, DataAccessException ;

	//public List<RuleSetModel> getRuleSetData(String app1, String app2) throws SQLException, DataAccessException ;
	//public List<AppRoles> getTktAppRoles(String[] ticketNo,  List<Integer> appIds) throws SQLException, DataAccessException ;
	//public List<ReqLogModel> getTktReqLogs(String[] ticketNo) throws SQLException, DataAccessException ;

}
