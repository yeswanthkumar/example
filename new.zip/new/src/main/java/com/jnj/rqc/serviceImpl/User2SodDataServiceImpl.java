package com.jnj.rqc.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.CSIUser2SodReportModel;
import com.jnj.rqc.conflictModel.JDEUser2SodReportModel;
import com.jnj.rqc.conflictModel.MercuryUser2SodReportModel;
import com.jnj.rqc.conflictModel.SapMitiCntrlModel;
import com.jnj.rqc.conflictModel.SapPlatformReviwerMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.constants.Constants;
import com.jnj.rqc.dao.GenesisDao;
import com.jnj.rqc.dao.SAPExtrGaaDao;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dao.User2SodDao;
import com.jnj.rqc.dbextr.models.TableRespDto;
import com.jnj.rqc.models.StrKeyValPair;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.reportwriter.CSVReportWriter;
import com.jnj.rqc.reportwriter.ExcelReportWriter;
import com.jnj.rqc.reportwriter.PDFReportWriter;
import com.jnj.rqc.service.HANADataService;
import com.jnj.rqc.service.HCSExtrDataService;
import com.jnj.rqc.service.JDEExtrDataService;
import com.jnj.rqc.service.SAPExtrGaaDataService;
import com.jnj.rqc.service.SAPExtrRegionWiseService;
import com.jnj.rqc.service.User2SodDataService;
import com.jnj.rqc.service.UserSearchService;
import com.jnj.rqc.util.EmailUtil;
import com.jnj.rqc.util.Utility;




/**
 * File    : <b>User2SodDataServiceImpl.java</b>
 * @author : DChauras @Created : Dec 8, 2021 11:01:55 AM
 * Purpose :
 * <b>Main Methods</b>
 * <li>
 * <ul><b></b></ul>
 * <ul><b></b></ul>
 * </li>
 */

@Service
public class User2SodDataServiceImpl implements User2SodDataService{

	static final Logger log = LoggerFactory.getLogger(User2SodDataServiceImpl.class);

	@Autowired
	Environment environment;

	@Autowired
	CSVReportWriter csvReportWriter;
	@Autowired
	PDFReportWriter pdfReportWriter;
	@Autowired
	ExcelReportWriter excelReportWriter;

	@Autowired
	SAPExtrGaaDao sAPExtrGaaDao;
	@Autowired
	SAPExtrRegionWiseDao sAPExtrRegionWiseDao;
	@Autowired
	SAPExtrRegionWiseService sAPExtrRegionWiseService;
	@Autowired
	JDEExtrDataService jDEExtrDataService;
	@Autowired
	UserSearchService userSearchService;
	@Autowired
	HANADataService hANADataService;
	@Autowired
	GenesisDao genesisDao;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	HCSExtrDataService hCSExtrDataService;
	@Autowired
	SAPExtrGaaDataService sAPExtrGaaDataService;
	@Autowired
	User2SodDao user2SodDao;


	@Override
	public TableRespDto getEnvData(String propName) {
		List<String> envNms= new ArrayList<>();
		envNms = Utility.loadUser2SodProperty(propName);
		TableRespDto tableRespDto = new TableRespDto();
		tableRespDto.setStatusCode(0);
		tableRespDto.setDatetimeStamp(Utility.esDtToUsFormat(new Date()));
		tableRespDto.setTables(envNms);

		return tableRespDto;
	}


	@SuppressWarnings("all")
	@Override
	public Map<String, List<SapUser2SodModel>> prepareUser2SodData(String templSysParam){
		log.info("templSysParam :"+templSysParam);
		Map<String, List<SapUser2SodModel>> dataMap = new HashMap<>();
		String[] systemDetails = templSysParam.split("_");
		String platform = systemDetails[1].trim().toUpperCase();
		if("JDEPLATFORM".equals(platform)) {
			dataMap = prepareJDEData(templSysParam);
		}else if(("MERCURY".equals(platform) || "MARS".equals(platform))) {//Added Mars to Mercury Route on -03/15/2022
			dataMap = prepareMercuryData(templSysParam);
		}else {
			dataMap = prepareSAPData(templSysParam);
		}
		return dataMap;
	}


	public Map<String, List<SapUser2SodModel>> prepareJDEData(String systemTemplate){
		Map<String, List<SapUser2SodModel>> dataMap = new HashMap<>();
		List<SapUser2SodModel> validU2SList = new ArrayList<>();
		List<SapUser2SodModel> inValidU2SList = new ArrayList<>();
		String[] systemDetails = systemTemplate.split("_");
		String sysName = systemDetails[3].trim().toUpperCase();
		List<JDEUser2SodReportModel> jdeReportData = readJDEReportExcel(systemTemplate);//All records from CSI Report
		//Filter VALID/INVALID RECORDS
		Map<String, UserSearchModel> usrMap = new HashMap<>();
		if(jdeReportData != null && !jdeReportData.isEmpty()) {
			for(JDEUser2SodReportModel jdeRecord : jdeReportData) {
				String usrId = jdeRecord.getUserId().trim();
				UserSearchModel srchUser = null;
				if(usrMap.containsKey(usrId)) {//START - Performance Improvement
					srchUser = usrMap.get(usrId);
				}else {
					srchUser = sAPExtrGaaDataService.getUserStatusJJEDS(usrId, 0);///Additional Check to make sure Pick Active IDS
					usrMap.put(usrId, srchUser);
				}//END - Performance Improvement
				if(srchUser != null){
					jdeRecord.setUserStatus(srchUser.getEmpStatTxt());
					jdeRecord.setFullName(srchUser.getGivenNm()+" "+srchUser.getFmlyNm());
				}else {
					jdeRecord.setUserStatus("NO DATA FOUND");
					jdeRecord.setFullName("USER NOT FOUND");
				}

				SapUser2SodModel dataRecord = new SapUser2SodModel();
				dataRecord.setRevUserId(jdeRecord.getReviewerId());
				dataRecord.setUserId(jdeRecord.getUserId());
				dataRecord.setPrimaryReviewInfo1(jdeRecord.getFullName()+" existing access has SOD conflicts that is caused by two conflicting Objects such as "
				+jdeRecord.getSrcObj()+" - "+jdeRecord.getSrcObjDesc()+"  V/S "+jdeRecord.getTgtObj()+" - "+jdeRecord.getTgtObjDesc()+" within "+sysName);

				dataRecord.setPrimaryReviewInfo1(Utility.fixLen4000(dataRecord.getPrimaryReviewInfo1()));
				dataRecord.setAdditionalInfo1(Utility.fixLen4000("Conflicting Source Role - "+jdeRecord.getSrcRole()+" - "+jdeRecord.getSrcRoleDesc()));
				dataRecord.setAdditionalInfo2(Utility.fixLen4000("Conflicting Target Role - "+jdeRecord.getTgtRole()+" - "+jdeRecord.getTgtRoleDesc()));
				dataRecord.setMitigatingId("NA");
				dataRecord.setAdditionalInfo3(Utility.fixLen4000(jdeRecord.getMitigatingCntrl()));
				dataRecord.setPlatformName(sysName);
				dataRecord.setRiskIdAndRiskDescription("Risk Level : "+jdeRecord.getRiskLevel());
				dataRecord.setReviewerDescription("This review will recertify the user with existing Segregation of Duty and associated Mitigation controls for the user remains valid or any adjustments required");
				dataRecord.setUserStatus(jdeRecord.getUserStatus());

				if("ACTIVE".equalsIgnoreCase(dataRecord.getUserStatus()) || "TRANSFERRED".equalsIgnoreCase(dataRecord.getUserStatus())) {
					if(!validU2SList.contains(dataRecord)) {
						validU2SList.add(dataRecord);
					}
				}else {
					if(!inValidU2SList.contains(dataRecord)) {
						inValidU2SList.add(dataRecord);
					}
				}
			}
		}
		usrMap = null;//Free Memory
		dataMap.put("VAL_U2S", validU2SList);
		dataMap.put("INV_U2S", inValidU2SList);
		return dataMap;
	}

	public Map<String, List<SapUser2SodModel>> prepareSAPData(String systemTemplate){
		Map<String, List<SapUser2SodModel>> dataMap = new HashMap<>();
		List<CSIUser2SodReportModel> csiValidList = new ArrayList<>();
		List<CSIUser2SodReportModel> csiInvalidList = new ArrayList<>();
		List<SapUser2SodModel> validU2SList = new ArrayList<>();
		List<SapUser2SodModel> inValidU2SList = new ArrayList<>();
		String[] systemDetails = systemTemplate.split("_");
		String platform = systemDetails[1].trim().toUpperCase();
		List<CSIUser2SodReportModel> csiReportData = readCSIReportExcel(systemTemplate);//All records from CSI Report
		//Filter VALID/INVALID RECORDS
		Map<String, UserSearchModel> usrMap = new HashMap<>();
		if(csiReportData != null && !csiReportData.isEmpty()) {
			for(CSIUser2SodReportModel csiRecord : csiReportData) {
				String usrId = csiRecord.getUserId().trim();
				UserSearchModel srchUser = null;
				if(usrMap.containsKey(usrId)) {//START - Performance Improvement
					srchUser = usrMap.get(usrId);
				}else {
					srchUser = sAPExtrGaaDataService.getUserStatusJJEDS(usrId, 0);///Additional Check to make sure Pick Active IDS
					usrMap.put(usrId, srchUser);
				}//END - Performance Improvement

				if(srchUser != null){
					csiRecord.setUserName(srchUser.getGivenNm()+" "+srchUser.getFmlyNm());
					csiRecord.setUserStatus(srchUser.getEmpStatTxt());
				}else {
					csiRecord.setUserName("USER NOT FOUND IN JJEDS");
					csiRecord.setUserStatus("NO DATA FOUND");
				}

				if("ACTIVE".equalsIgnoreCase(csiRecord.getUserStatus()) || "TRANSFERRED".equalsIgnoreCase(csiRecord.getUserStatus())) {
					csiValidList.add(csiRecord);
				}else {
					csiInvalidList.add(csiRecord);
				}
			}
		}
		usrMap = null;

		//START - Prepare NAGS Data for ValidList
		if(csiValidList != null && !csiValidList.isEmpty()) {
			validU2SList = prepareNagsData(csiValidList, platform);
		}

		if(csiInvalidList != null && !csiInvalidList.isEmpty()) {
			inValidU2SList = prepareNagsData(csiInvalidList, platform);
			/*if(incompleteData != null && !incompleteData.isEmpty()) {
			sendInvldDataEmail(templSysParam, incompleteData);
			}*/
		}
		//END of Preparing NAGS Data
		dataMap.put("VAL_U2S", validU2SList);
		dataMap.put("INV_U2S", inValidU2SList);
		return dataMap;
	}

	public Map<String, List<SapUser2SodModel>> prepareMercuryData(String systemTemplate){
		Map<String, List<SapUser2SodModel>> dataMap = new HashMap<>();
		List<MercuryUser2SodReportModel> csiValidList = new ArrayList<>();
		List<MercuryUser2SodReportModel> csiInvalidList = new ArrayList<>();
		List<SapUser2SodModel> validU2SList = new ArrayList<>();
		List<SapUser2SodModel> inValidU2SList = new ArrayList<>();
		String[] systemDetails = systemTemplate.split("_");
		String platform = systemDetails[1].trim().toUpperCase();
		List<MercuryUser2SodReportModel> merReportData = readCSIMercuryReportExcel(systemTemplate);//All records from CSI Report
		Map<String, UserSearchModel> usrMap = new HashMap<>();
		if(merReportData != null && !merReportData.isEmpty()) {
			for(MercuryUser2SodReportModel csiRecord : merReportData) {
				String usrId = csiRecord.getUserId().trim();
				UserSearchModel srchUser = null;
				if(usrMap.containsKey(usrId)) {//START - Performance Improvement
					srchUser = usrMap.get(usrId);
				}else {
					srchUser = sAPExtrGaaDataService.getUserStatusJJEDS(usrId, 0);///Additional Check to make sure Pick Active IDS
					usrMap.put(usrId, srchUser);
				}//END - Performance Improvement

				if(srchUser != null){
					csiRecord.setUserName(srchUser.getGivenNm()+" "+srchUser.getFmlyNm());
					csiRecord.setUserStatus(srchUser.getEmpStatTxt());
				}else {
					csiRecord.setUserName("USER NOT FOUND IN JJEDS");
					csiRecord.setUserStatus("NO DATA FOUND");
				}

				if("ACTIVE".equalsIgnoreCase(csiRecord.getUserStatus()) || "TRANSFERRED".equalsIgnoreCase(csiRecord.getUserStatus())) {
					csiValidList.add(csiRecord);
				}else {
					csiInvalidList.add(csiRecord);
				}
			}
		}
		usrMap = null;

		//START - Prepare NAGS Data for ValidList
		if(csiValidList != null && !csiValidList.isEmpty()) {
			validU2SList = prepareMercuryNagsData(csiValidList, platform);
		}

		if(csiInvalidList != null && !csiInvalidList.isEmpty()) {
			inValidU2SList = prepareMercuryNagsData(csiInvalidList, platform);
			/*if(incompleteData != null && !incompleteData.isEmpty()) {
			sendInvldDataEmail(templSysParam, incompleteData);
			}*/
		}
		//END of Preparing NAGS Data
		dataMap.put("VAL_U2S", validU2SList);
		dataMap.put("INV_U2S", inValidU2SList);
		return dataMap;
	}

	private List<SapUser2SodModel> prepareNagsData(List<CSIUser2SodReportModel> csiDataLst, String platform){
		List<SapUser2SodModel> user2SodList = new ArrayList<>();
		if(csiDataLst != null && !csiDataLst.isEmpty()) {
			Map<String, SapMitiCntrlModel> mitiControlMap = loadSapMitiCntrlMap();//Mitigating Control Map
			Map<String, SapPlatformReviwerMdl> reviwerMap = loadDBReviewersData(0); //LOAD Reviewers for Platform

			for(CSIUser2SodReportModel repMdl : csiDataLst) {
				SapUser2SodModel u2sMdl = new SapUser2SodModel();
				u2sMdl.setUserId(repMdl.getUserId().trim().toUpperCase());
				String sdConfl = (repMdl.getSodConflict() == null)? "":repMdl.getSodConflict().trim().toUpperCase();
				String key =platform+"~"+sdConfl;
				//Deviation needed for Mercury we will have to lookup different file
				SapPlatformReviwerMdl reviwerMdl = (reviwerMap.containsKey(key))? reviwerMap.get(key) : null;
				if(reviwerMdl != null && reviwerMdl.getReviewerId() != null && reviwerMdl.getReviewerId().length() > 0){
					//Added on 01/18/2022 for WWID Comparison
					String tmpUserId="";
					if(u2sMdl.getUserId().toUpperCase().equals(u2sMdl.getUserId().toLowerCase())) {
						tmpUserId = u2sMdl.getUserId();
					}else {
						UserSearchModel userSrch = sAPExtrGaaDataService.getUserStatusJJEDS(u2sMdl.getUserId(), 1);
						if(userSrch != null) {
							tmpUserId = userSrch.getWwId();
						}
					}
					//END

					if(reviwerMdl.getReviewerId().equalsIgnoreCase(tmpUserId)) {
						UserSearchModel revUser = sAPExtrGaaDataService.getUserStatusJJEDS(u2sMdl.getUserId(), 1);
						if(revUser != null) {
							u2sMdl.setRevUserId(revUser.getJnjSupvrWwId());
						}else {
							u2sMdl.setRevUserId("0");
						}
					}else {
						u2sMdl.setRevUserId(reviwerMdl.getReviewerId());
					}
				}else {
					u2sMdl.setRevUserId("0");
				}
				u2sMdl.setPrimaryReviewInfo1(repMdl.getUserName() +" existing access has SOD conflicts that is caused by two conflicting functions such as :"+
				repMdl.getQry1Name()+" - "+repMdl.getQry1Desc() +" V/S "+repMdl.getQry2Name()+" - "+repMdl.getQry2Desc());

				if(sdConfl.startsWith("TRANS")) {
					u2sMdl.setPrimaryReviewInfo1(u2sMdl.getPrimaryReviewInfo1()+" RISK ID : "+repMdl.getReasonCode()+" Within "+repMdl.getLogicalSystem());
				}else {
					u2sMdl.setPrimaryReviewInfo1(u2sMdl.getPrimaryReviewInfo1()+" RISK ID : "+sdConfl+" (RISK LEVEL: "+repMdl.getReasonCode().split(":")[0]+") Within "+repMdl.getLogicalSystem());
				}
				u2sMdl.setPrimaryReviewInfo1(Utility.fixLen4000(u2sMdl.getPrimaryReviewInfo1()));

				u2sMdl.setAdditionalInfo1("Conflicting Transaction – "+Utility.fixLen4000(repMdl.getCausingTCode1()));
				u2sMdl.setAdditionalInfo2("Conflicting Transaction – "+Utility.fixLen4000(repMdl.getCausingTCode2()));

				if(mitiControlMap.containsKey(sdConfl)) {
					SapMitiCntrlModel mitiCMdl = mitiControlMap.get(sdConfl);
					u2sMdl.setMitigatingId(mitiCMdl.getControlId());
					u2sMdl.setAdditionalInfo3(Utility.fixLen4000(mitiCMdl.getControlDesc()));
				}else {
					u2sMdl.setMitigatingId("NA");
					u2sMdl.setAdditionalInfo3("NA");
				}
				u2sMdl.setPlatformName("SAP "+platform.toUpperCase());
				u2sMdl.setRiskIdAndRiskDescription(sdConfl+" "+repMdl.getConfDesc());
				u2sMdl.setReviewerDescription("This review will recertify the user with existing Segregation of Duty and associated Mitigation controls for the user remains valid or any adjustments required");
				u2sMdl.setUserStatus(repMdl.getUserStatus());
				if(!user2SodList.contains(u2sMdl)) {
					user2SodList.add(u2sMdl);
				}
			}
		}
		return user2SodList;
	}


	private List<SapUser2SodModel> prepareMercuryNagsData(List<MercuryUser2SodReportModel> csiDataLst, String platform){
		List<SapUser2SodModel> user2SodList = new ArrayList<>();
		if(csiDataLst != null && !csiDataLst.isEmpty()) {
			Map<String, SapMitiCntrlModel> mitiControlMap = loadSapMitiCntrlMap();//Mitigating Control Map
			Map<String, String> reviwerMap = loadMercuryDBReviewersData(0);
			for(MercuryUser2SodReportModel repMdl : csiDataLst) {
				SapUser2SodModel u2sMdl = new SapUser2SodModel();
				u2sMdl.setUserId(repMdl.getUserId().trim().toUpperCase());
				String sdConfl = (repMdl.getSodConflict() == null)? "":repMdl.getSodConflict().trim().toUpperCase();
				String key = (repMdl.getApprListId() == null)? "":repMdl.getApprListId().trim().toUpperCase();


				String revrId = (reviwerMap.containsKey(key))? reviwerMap.get(key) : null;//Will always return WWID
				if(revrId != null && revrId.length() > 0){
					//Added on 01/18/2022 for WWID Comparison
					String tmpUserId="";
					if(u2sMdl.getUserId().toUpperCase().equals(u2sMdl.getUserId().toLowerCase())) {
						tmpUserId = u2sMdl.getUserId();
					}else {
						UserSearchModel userSrch = sAPExtrGaaDataService.getUserStatusJJEDS(u2sMdl.getUserId(), 1);
						if(userSrch != null) {
							tmpUserId = userSrch.getWwId();
						}
					}
					//END
					if(revrId.equalsIgnoreCase(tmpUserId)) {
						UserSearchModel revUser = sAPExtrGaaDataService.getUserStatusJJEDS(u2sMdl.getUserId(), 1);
						if(revUser != null) {
							u2sMdl.setRevUserId(revUser.getJnjSupvrWwId());
						}else {
							u2sMdl.setRevUserId("0");
						}
					}else {
						u2sMdl.setRevUserId(revrId);
					}
				}else {
					u2sMdl.setRevUserId("0");
				}
				u2sMdl.setPrimaryReviewInfo1(repMdl.getUserName() +" existing access has SOD conflicts that is caused by two conflicting functions such as :"+
				repMdl.getQry1Name()+" - "+repMdl.getQry1Desc() +" V/S "+repMdl.getQry2Name()+" - "+repMdl.getQry2Desc());

				if(sdConfl.startsWith("TRANS")) {
					u2sMdl.setPrimaryReviewInfo1(u2sMdl.getPrimaryReviewInfo1()+" RISK ID : "+repMdl.getReasonCode()+" Within "+repMdl.getLogicalSystem());
				}else {
					u2sMdl.setPrimaryReviewInfo1(u2sMdl.getPrimaryReviewInfo1()+" RISK ID : "+sdConfl+" (RISK LEVEL: "+repMdl.getReasonCode().split(":")[0]+") Within "+repMdl.getLogicalSystem());
				}
				u2sMdl.setPrimaryReviewInfo1(Utility.fixLen4000(u2sMdl.getPrimaryReviewInfo1()));

				u2sMdl.setAdditionalInfo1("Conflicting Transaction – "+Utility.fixLen4000(repMdl.getCausingTCode1()));
				u2sMdl.setAdditionalInfo2("Conflicting Transaction – "+Utility.fixLen4000(repMdl.getCausingTCode2()));

				if(mitiControlMap.containsKey(sdConfl)) {
					SapMitiCntrlModel mitiCMdl = mitiControlMap.get(sdConfl);
					u2sMdl.setMitigatingId(mitiCMdl.getControlId());
					u2sMdl.setAdditionalInfo3(Utility.fixLen4000(mitiCMdl.getControlDesc()));
				}else {
					u2sMdl.setMitigatingId("NA");
					u2sMdl.setAdditionalInfo3("NA");
				}
				u2sMdl.setPlatformName("SAP "+platform.toUpperCase());
				u2sMdl.setRiskIdAndRiskDescription(sdConfl+" "+repMdl.getConfDesc());
				u2sMdl.setReviewerDescription("This review will recertify the user with existing Segregation of Duty and associated Mitigation controls for the user remains valid or any adjustments required");
				u2sMdl.setUserStatus(repMdl.getUserStatus());
				if(!user2SodList.contains(u2sMdl)) {
					user2SodList.add(u2sMdl);
				}
			}
		}
		return user2SodList;
	}


	@Override
	public Map<String, SapMitiCntrlModel> loadSapMitiCntrlMap() {
		Map<String, SapMitiCntrlModel> mitiMap = Utility.getSapMitiCntrlMap();//Mitigating Control Map
		if(mitiMap == null || mitiMap.isEmpty()) {
			try {
				List<SapMitiCntrlModel> dataLst = user2SodDao.loadMitiCntrlDBData();
				if(dataLst != null && !dataLst.isEmpty()) {
					for(SapMitiCntrlModel cntrlMdl:dataLst) {
						mitiMap.put(cntrlMdl.getRiskId(), cntrlMdl);
					}
					Utility.setSapMitiCntrlMap(mitiMap);
				}
			} catch (Exception e) {
				log.error("Error Loading Mitigating Control Data :"+e.getMessage(), e);
			}
		}


		/*if(mitiMap == null || mitiMap.isEmpty()) {
			mitiMap = new HashMap<String, SapMitiCntrlModel>();
			String baseDir = Utility.getUser2SodProperty("BASE_DIRECTORY");
			String qualPath = baseDir+"GRAC_SOD_MIT_CTL_REPORT.xlsx";
			log.info("Loding file :"+qualPath);
			Workbook nFile = Utility.loadFile(qualPath);
			Sheet dsheet = nFile.getSheetAt(0);
			int i = 0;
			if(dsheet != null) {
				int rowTotal = dsheet.getLastRowNum();
				if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
				    rowTotal++;
				}
				log.info("Total number of SAP Mitigating Control Rows(Header): "+rowTotal);

				for(Row rw:dsheet) {
					if(i<1) {//Skipping Header Row
						i++;
						continue;
					}
					String riskId			= (Utility.getCellValue(rw.getCell(1)) != null) ? Utility.getCellValue(rw.getCell(1)).trim() : "";
					String cntrlId			= (Utility.getCellValue(rw.getCell(3)) != null) ? Utility.getCellValue(rw.getCell(3)).trim():"" ;
					String cntrlDesc 		= Utility.getCellValue(rw.getCell(4));
					if(cntrlDesc != null) {
						cntrlDesc = (cntrlDesc.replaceAll("\"", "")).trim();
					}
					SapMitiCntrlModel mdl = new SapMitiCntrlModel();
					mdl.setRiskId(riskId);
					mdl.setControlId(cntrlId);
					mdl.setControlDesc(cntrlDesc);
					mitiMap.put(mdl.getRiskId(), mdl);
					i++;
				}
			}
		}
		log.info("Total Rows in MITIGATING CNTRL  : "+mitiMap.size());
		Utility.setSapMitiCntrlMap(mitiMap);
	 */

		log.info("Total Rows in MITIGATING CNTRL  : "+mitiMap.size());
		return mitiMap;
	}


	@Override
	public List<SapPlatformReviwerMdl> loadPlatformReviewers(String path){
		log.info("Loding file :"+path);
		List<SapPlatformReviwerMdl> revLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows in Reviewer Details (Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				String platform			= Utility.getCellValue(rw.getCell(0));
				String riskId			= Utility.getCellValue(rw.getCell(1));
				String reviewerId 		= Utility.getCellValue(rw.getCell(2));
				SapPlatformReviwerMdl revMdl = new SapPlatformReviwerMdl();
				revMdl.setPlatform(platform.trim().toUpperCase());
				revMdl.setRiskId(riskId.trim().toUpperCase());

				if(reviewerId.toUpperCase().equals(reviewerId.toLowerCase())) {
					revMdl.setReviewerId(reviewerId);
				}else {
					UserSearchModel ursMdl = sAPExtrGaaDataService.getUserStatusJJEDS(reviewerId, 1);
					if(ursMdl != null) {
						revMdl.setReviewerId(ursMdl.getWwId());
					}else {
						revMdl.setReviewerId("Reviewer Not Found");
					}
				}
				if(!revLst.contains(revMdl)) {
					revLst.add(revMdl);
				}

				i++;
			}
		}
		System.out.println("Total Reviewers for : "+revLst.size());
		return revLst;
	}


	@Override
	public List<StrKeyValPair> loadMercuryPlatformReviewers(String path){
		log.info("Loding file :"+path);
		List<StrKeyValPair> revLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(path);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Rows in Reviewer Details (Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				String apprListId		= Utility.getCellValue(rw.getCell(0));
				String reviewerId 		= Utility.getCellValue(rw.getCell(1));
				StrKeyValPair revMdl = new StrKeyValPair();
				revMdl.setKey(apprListId.trim().toUpperCase());
				revMdl.setVal(reviewerId.trim().toUpperCase());

				if(reviewerId.toUpperCase().equals(reviewerId.toLowerCase())) {
					revMdl.setVal(reviewerId);
				}else {
					UserSearchModel ursMdl = sAPExtrGaaDataService.getUserStatusJJEDS(reviewerId, 1);
					if(ursMdl != null) {
						revMdl.setVal(ursMdl.getWwId());
					}else {
						revMdl.setVal("0");
					}
				}
				if(!revLst.contains(revMdl)) {
					revLst.add(revMdl);
				}
				i++;
			}
		}
		System.out.println("Total Mercury Reviewers for : "+revLst.size());
		return revLst;
	}




	@Override
	public Map<String, SapPlatformReviwerMdl> loadDBReviewersData(int reload) {
		Map<String, SapPlatformReviwerMdl> revMap = Utility.getSapReviewersDataMap();
		if(reload > 0 || revMap == null || revMap.isEmpty()) {
			try {
				List<SapPlatformReviwerMdl> dataLst = user2SodDao.loadReviewerDBData();
				if(dataLst != null && !dataLst.isEmpty()) {
					for(SapPlatformReviwerMdl revMdl:dataLst) {
						revMap.put(revMdl.getPlatform()+"~"+revMdl.getRiskId(), revMdl);
					}
					Utility.setSapReviewersDataMap(revMap);
				}
			} catch (Exception e) {
				log.error("Error Loading Mitigating Control Data :"+e.getMessage(), e);
			}
		}else {
			log.info("Reviewermap.size : "+revMap.size());
		}
		return revMap;
	}

	@Override
	public Map<String, String> loadMercuryDBReviewersData(int reload) {
		Map<String, String> revMap = Utility.getMercuryReviewersDataMap();
		if(reload > 0 || revMap == null || revMap.isEmpty()) {
			try {
				List<StrKeyValPair> dataLst = user2SodDao.loadMercuryReviewerDBData();
				if(dataLst != null && !dataLst.isEmpty()) {
					for(StrKeyValPair revMdl:dataLst) {
						revMap.put(revMdl.getKey(), revMdl.getVal());
					}
					Utility.setMercuryReviewersDataMap(revMap);
				}
			} catch (Exception e) {
				log.error("Error Loading Mercury Reviewer Data :"+e.getMessage(), e);
			}
		}else {
			log.info("Mercury Reviewermap.size : "+revMap.size());
		}
		return revMap;
	}


	@Override
	public List<CSIUser2SodReportModel> readCSIReportExcel(String path){
		String baseDir = Utility.getUser2SodProperty("BASE_DIRECTORY");
		String repDir = Utility.getUser2SodProperty("REPORT_DIRECTORY");
		String qualPath = baseDir+repDir+path+"_CSIREPORT.xlsx";
		log.info("Loding file :"+qualPath);

		List<CSIUser2SodReportModel> u2sRepLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(qualPath);
		Sheet dsheet = null;
		if(nFile != null) {
			dsheet = nFile.getSheetAt(0);
		}
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Records ("+path+") CSI Report USER2SOD(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				//Only conside Rows with DEFINITION ="Bi"
				String definition 		= Utility.getCellValue(rw.getCell(8)).trim();
				if(!definition.startsWith("Bi")) {
					i++;
					continue;
				}
				//END
				CSIUser2SodReportModel dtaMdl	= new CSIUser2SodReportModel();
				String sodConflict			= Utility.getCellValue(rw.getCell(0));
				dtaMdl.setSodConflict(sodConflict);
				String confDesc			= Utility.getCellValue(rw.getCell(1));
				dtaMdl.setConfDesc(confDesc);
				String reasonCode 			= Utility.getCellValue(rw.getCell(4));
				dtaMdl.setReasonCode(reasonCode);
				dtaMdl.setDefinition(definition);
				String expression 		= Utility.getCellValue(rw.getCell(9));
				dtaMdl.setExpression(expression);
				String userId 	= Utility.getCellValue(rw.getCell(11));
				dtaMdl.setUserId(userId);
				String isSuper 	= Utility.getCellValue(rw.getCell(13));
				dtaMdl.setIsSuper(isSuper);
				String group		= Utility.getCellValue(rw.getCell(14));
				dtaMdl.setGroup(group);
				String type	= Utility.getCellValue(rw.getCell(15));
				dtaMdl.setType(type);
				String logicalSystem	= Utility.getCellValue(rw.getCell(18));
				dtaMdl.setLogicalSystem(logicalSystem);
				String qry1	= Utility.getCellValue(rw.getCell(19));
				dtaMdl.setQry1(qry1);
				String qry1Name	= Utility.getCellValue(rw.getCell(20));
				dtaMdl.setQry1Name(qry1Name);
				String qry1Desc	= Utility.getCellValue(rw.getCell(21));
				dtaMdl.setQry1Desc(qry1Desc);
				String norm1	= Utility.getCellValue(rw.getCell(22));
				dtaMdl.setNorm1(norm1);
				String causingTCode1	= Utility.getCellValue(rw.getCell(27));
				dtaMdl.setCausingTCode1(causingTCode1);
				String qryTCode1	= Utility.getCellValue(rw.getCell(28));
				dtaMdl.setQryTCode1(qryTCode1);

				String qry2	= Utility.getCellValue(rw.getCell(29));
				dtaMdl.setQry2(qry2);
				String qry2Name	= Utility.getCellValue(rw.getCell(30));
				dtaMdl.setQry2Name(qry2Name);
				String qry2Desc	= Utility.getCellValue(rw.getCell(31));
				dtaMdl.setQry2Desc(qry2Desc);
				String norm2	= Utility.getCellValue(rw.getCell(32));
				dtaMdl.setNorm2(norm2);
				String causingTCode2	= Utility.getCellValue(rw.getCell(37));
				dtaMdl.setCausingTCode2(causingTCode2);
				String qryTCode2	= Utility.getCellValue(rw.getCell(38));
				dtaMdl.setQryTCode2(qryTCode2);


				//if(!u2sLst.contains(dtaMdl)) {
					u2sRepLst.add(dtaMdl);
				//}
				i++;
			}
		}
		System.out.println("Total User to Sod Records to Process : "+u2sRepLst.size());
		return u2sRepLst;
	}


	@Override
	public List<JDEUser2SodReportModel> readJDEReportExcel(String path){
		String baseDir = Utility.getUser2SodProperty("BASE_DIRECTORY");
		String repDir = Utility.getUser2SodProperty("REPORT_DIRECTORY");
		String qualPath = baseDir+repDir+path+"_CSIREPORT.xlsx";
		log.info("Loding file :"+qualPath);

		List<JDEUser2SodReportModel> jdeRepLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(qualPath);
		Sheet dsheet = null;
		if(nFile != null) {
			dsheet = nFile.getSheetAt(0);
		}
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Records ("+path+") JDE CSI Report USER2SOD(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				JDEUser2SodReportModel dtaMdl	= new JDEUser2SodReportModel();
				String revId			= Utility.getCellValue(rw.getCell(0));
				dtaMdl.setReviewerId(revId);
				String userId 			= Utility.getCellValue(rw.getCell(1));
				dtaMdl.setUserId(userId);
				//String fullNm			= Utility.getCellValue(rw.getCell(2));
			//	dtaMdl.setFullName(fullNm);
				String srcRl 			= Utility.getCellValue(rw.getCell(2));
				dtaMdl.setSrcRole(srcRl);
				String srcRlDsc 		= Utility.getCellValue(rw.getCell(3));
				dtaMdl.setSrcRoleDesc(srcRlDsc);
				String srcObj 		= Utility.getCellValue(rw.getCell(4));
				dtaMdl.setSrcObj(srcObj);
				String srcObjDesc 		= Utility.getCellValue(rw.getCell(5));
				dtaMdl.setSrcObjDesc(srcObjDesc);
				String tgtRl 		= Utility.getCellValue(rw.getCell(6));
				dtaMdl.setTgtRole(tgtRl);
				String tgtRlDsc 		= Utility.getCellValue(rw.getCell(7));
				dtaMdl.setTgtRoleDesc(tgtRlDsc);
				String tgtObj 		= Utility.getCellValue(rw.getCell(8));
				dtaMdl.setTgtObj(tgtObj);
				String tgtObjDsc 		= Utility.getCellValue(rw.getCell(9));
				dtaMdl.setTgtObjDesc(tgtObjDsc);
				String riskLevel	= Utility.getCellValue(rw.getCell(10));
				dtaMdl.setRiskLevel(riskLevel);
				String mitiCntrl	= Utility.getCellValue(rw.getCell(11));
				dtaMdl.setMitigatingCntrl(mitiCntrl);
				//if(!u2sLst.contains(dtaMdl)) {
				jdeRepLst.add(dtaMdl);
				//}
				i++;
			}
		}
		System.out.println("Total User to Sod Records for JDE : "+jdeRepLst.size());
		return jdeRepLst;
	}

	@Override
	public List<MercuryUser2SodReportModel> readCSIMercuryReportExcel(String path){
		String baseDir = Utility.getUser2SodProperty("BASE_DIRECTORY");
		String repDir = Utility.getUser2SodProperty("REPORT_DIRECTORY");
		String qualPath = baseDir+repDir+path+"_CSIREPORT.xlsx";
		log.info("Loding file :"+qualPath);

		List<MercuryUser2SodReportModel> u2sRepLst = new ArrayList<>();
		Workbook nFile = Utility.loadFile(qualPath);
		Sheet dsheet = null;
		if(nFile != null) {
			dsheet = nFile.getSheetAt(0);
		}
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
			log.info("Total number of Records ("+path+") MERCURY/MARS CSI Report USER2SOD(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				//Only conside Rows with DEFINITION ="Bi"
				String definition 		= Utility.getCellValue(rw.getCell(8)).trim();
				if(!definition.startsWith("Bi")) {
					i++;
					continue;
				}
				//END
				MercuryUser2SodReportModel dtaMdl	= new MercuryUser2SodReportModel();
				String sodConflict			= Utility.getCellValue(rw.getCell(0));
				dtaMdl.setSodConflict(sodConflict);
				String confDesc			= Utility.getCellValue(rw.getCell(1));
				dtaMdl.setConfDesc(confDesc);
				String reasonCode 			= Utility.getCellValue(rw.getCell(4));
				dtaMdl.setReasonCode(reasonCode);

				dtaMdl.setDefinition(definition);

				String expression 		= Utility.getCellValue(rw.getCell(9));
				dtaMdl.setExpression(expression);
				String userId 	= Utility.getCellValue(rw.getCell(11));
				dtaMdl.setUserId(userId);
				String isSuper 	= Utility.getCellValue(rw.getCell(13));
				dtaMdl.setIsSuper(isSuper);
				String group		= Utility.getCellValue(rw.getCell(14));
				dtaMdl.setGroup(group);
				String type	= Utility.getCellValue(rw.getCell(15));
				dtaMdl.setType(type);
				String logicalSystem	= Utility.getCellValue(rw.getCell(18));
				dtaMdl.setLogicalSystem(logicalSystem);
				String qry1	= Utility.getCellValue(rw.getCell(19));
				dtaMdl.setQry1(qry1);
				String qry1Name	= Utility.getCellValue(rw.getCell(20));
				dtaMdl.setQry1Name(qry1Name);
				String qry1Desc	= Utility.getCellValue(rw.getCell(21));
				dtaMdl.setQry1Desc(qry1Desc);
				String norm1	= Utility.getCellValue(rw.getCell(22));
				dtaMdl.setNorm1(norm1);
				String causingTCode1	= Utility.getCellValue(rw.getCell(27));
				dtaMdl.setCausingTCode1(causingTCode1);
				String qryTCode1	= Utility.getCellValue(rw.getCell(28));
				dtaMdl.setQryTCode1(qryTCode1);

				String qry2	= Utility.getCellValue(rw.getCell(29));
				dtaMdl.setQry2(qry2);
				String qry2Name	= Utility.getCellValue(rw.getCell(30));
				dtaMdl.setQry2Name(qry2Name);
				String qry2Desc	= Utility.getCellValue(rw.getCell(31));
				dtaMdl.setQry2Desc(qry2Desc);
				String norm2	= Utility.getCellValue(rw.getCell(32));
				dtaMdl.setNorm2(norm2);
				String causingTCode2	= Utility.getCellValue(rw.getCell(37));
				dtaMdl.setCausingTCode2(causingTCode2);
				String qryTCode2	= Utility.getCellValue(rw.getCell(38));
				dtaMdl.setQryTCode2(qryTCode2);

				String role	= Utility.getCellValue(rw.getCell(39));
				dtaMdl.setRole(role);
				String apprListId	= Utility.getCellValue(rw.getCell(40));
				dtaMdl.setApprListId(apprListId);
				//if(!u2sLst.contains(dtaMdl)) {
					u2sRepLst.add(dtaMdl);
				//}
				i++;
			}
		}
		System.out.println("Total User to Sod Records to Process : "+u2sRepLst.size());
		return u2sRepLst;
	}





	@Override
	public String writeSapUser2SodExcel(List<SapUser2SodModel> data, String fileName) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeSapUser2SodExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), "USER TO SOD");
		} catch (Exception e) {
			log.error("Error Writing Excel ("+fileName+") : "+e.getMessage(), e);
		}

		return filePath;
	}


	@Override
	public List<SapMitiCntrlModel> readMitigatingCntrlExcel(String qPath) {
		List<SapMitiCntrlModel> mitiList = new ArrayList<>();
		log.info("Loding file :"+qPath);
		Workbook nFile = Utility.loadFile(qPath);
		Sheet dsheet = nFile.getSheetAt(0);
		int i = 0;
		if(dsheet != null) {
			int rowTotal = dsheet.getLastRowNum();
			if ((rowTotal > 0) || (dsheet.getPhysicalNumberOfRows() > 0)) {
				rowTotal++;
			}
			log.info("Total number of SAP Mitigating Control Rows(Header): "+rowTotal);

			for(Row rw:dsheet) {
				if(i<1) {//Skipping Header Row
					i++;
					continue;
				}
				String riskId			= (Utility.getCellValue(rw.getCell(1)) != null) ? Utility.getCellValue(rw.getCell(1)).trim() : "";
				if(riskId.length() <=1) {
					i++;
					continue;
				}
				String cntrlId			= (Utility.getCellValue(rw.getCell(3)) != null) ? Utility.getCellValue(rw.getCell(3)).trim():"" ;
				String cntrlDesc 		= Utility.getCellValue(rw.getCell(4));
				if(cntrlDesc != null) {
					cntrlDesc = (cntrlDesc.replaceAll("\"", "")).trim();
				}
				SapMitiCntrlModel mdl = new SapMitiCntrlModel();
				mdl.setRiskId(riskId.trim().toUpperCase());
				mdl.setControlId(cntrlId);
				mdl.setControlDesc(cntrlDesc);
				if(!mitiList.contains(mdl)) {
					mitiList.add(mdl);
				}
				i++;
			}
		}
		log.info("Total Rows in MITIGATING CNTRL  : "+mitiList.size());
		return mitiList;
	}


	@Override
	public String writeMitiCntrlExcel(List<SapMitiCntrlModel> data, String fileName) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeMitiCntrlExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), "MITIGATING CONTROL");
		} catch (Exception e) {
			log.error("Error Writing Excel ("+fileName+") : "+e.getMessage(), e);
		}
		return filePath;
	}

	@Override
	public String writeReviewerExcel(List<SapPlatformReviwerMdl> data, String fileName) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeSapReviewerExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), "REVIEWER DATA");
		} catch (Exception e) {
			log.error("Error Writing Excel ("+fileName+") : "+e.getMessage(), e);
		}
		return filePath;
	}




	@Override
	public String writeMerReviewerExcel(List<StrKeyValPair> data, String fileName) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeMercuryReviewerExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), "REVIEWER DATA");
		} catch (Exception e) {
			log.error("Error Writing Excel ("+fileName+") : "+e.getMessage(), e);
		}
		return filePath;
	}


	@Override
	public int saveReviewersData(List<SapPlatformReviwerMdl> revrData){
		int result = 0;
		try {
				result = user2SodDao.insertUser2SodRevrData(revrData);
				loadDBReviewersData(1);//Refresh Cache after adding new data
		} catch (Exception e) {
			log.error("Error inserting Reviver Data :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public int saveMercuryReviewersData(List<StrKeyValPair> revrData){
		int result = 0;
		try {
				result = user2SodDao.insertMercuryUser2SodRevrData(revrData);
				loadDBReviewersData(1);//Refresh Cache after adding new data
		} catch (Exception e) {
			log.error("Error inserting Reviver Data :"+e.getMessage(), e);
		}
		return result;
	}

	@Override
	public int insertUser2SodTransactions(List<SapUser2SodModel> user2SodData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2SodData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2SodTransData(user2SodData, sysTemp, createdUser);
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2SodData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapUser2SodModel> insData = user2SodData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2SodTransData(insData, sysTemp, createdUser);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2SodData.size()) {
						endPos = user2SodData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to SOD Data"+e.getMessage(), e);
		}

		return totalRecords;
	}





/*


	@Override
	public void sendInvldDataEmail(String sysTemp, List<SapGaaUser2RoleModel> dataList) {
		String envName = Utility.getServerProp("ENVIRONMENT");
		try {
			log.info(envName+" Preparing INCOMPLETE/INVALID Records email for Systems ("+sysTemp+") ");
			String[] sysArr=sysTemp.split("_");
			String invldFlNm ="INCOMPLETE_UsertoRole_Review_SAP_"+sysTemp;
			//String invldFlPath = writeSapGaaUser2RoleCSV(dataList, invldFlNm);//CSV
			String invldFlPath = writeSapGaaUser2RoleXLS(dataList, invldFlNm,"InvalidData");
			String toEmail=Utility.getPlatformEmailAddress(sysArr[1]);
			log.info(envName+" Sending INCOMPLETE/INVALID Records email for Systems ("+sysTemp+") to:"+toEmail);
			emailUtil.sendPlatformEmail("("+envName+") - INCOMPLETE/INVALID ERP USER TO ROLE Data for Platform: "+sysArr[1]+" - ("+sysTemp+") ", invldFlPath, toEmail, "U");
		} catch (Exception e) {
			log.error("ERROR Sending "+envName+"INVALID/INCOMPLETE Data Email :"+e.getMessage(), e);
		}

	}


	@SuppressWarnings("all")
	@Override
	public List<SapGaaUser2RoleModel> readSapUserToRoleData(String templSysParam){
		log.info("templSysParam :"+templSysParam);
		LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<SapGaaUser2RoleModel>();
		Map<String, List<String>> usrRoleMap = new HashMap<String, List<String>>();
		Map<String, String> roleNameValue = new HashMap<String, String>();
		try {
			List<String> userLst = sAPExtrGaaDao.getAllValidUsers(templSysParam);//Get All Users for the given System
			log.info("Total Users for ("+templSysParam+") ="+userLst.size());
			if(userLst != null && !userLst.isEmpty()) {
				for(String usr:userLst) {
					List<String> usrRoles = sAPExtrGaaDao.getUsersRoles(usr, templSysParam);
					if(usrRoles != null && !usrRoles.isEmpty()) {
						for(int i=0;i<usrRoles.size();i++) {
							roleNameValue.put(usrRoles.get(i), "");
						}

						if(usrRoleMap.containsKey(usr)) {
							List<String> roleList = usrRoleMap.get(usr);
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}else {
							List<String> roleList = new ArrayList<String>();
							roleList.addAll(usrRoles);
							usrRoleMap.put(usr, roleList);
						}
					}
				}

				log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));

				//Getting Role Descriptions for All Unique Role Names
				log.info("Getting Role Description for  : "+roleNameValue.size()+" Records.");
				for(String rlNm : roleNameValue.keySet()) {
					String roleDesc = sAPExtrGaaDao.getRoleDescription(rlNm, templSysParam);
					if(roleDesc != null && roleDesc.length() > 0 ) {
						roleNameValue.put(rlNm, roleDesc);
					}
				}
				log.info("Completed Role Description for  : "+roleNameValue.size()+" Records.");

				log.info("Getting Active Users First Name/Last Name for "+templSysParam+" : "+usrRoleMap.size()+" Users.");
				for(String usr : usrRoleMap.keySet()) {
					UserSearchModel srchUsr = getUserStatusJJEDS(usr, 1);
					String[] sysInfoArr = templSysParam.split("_");
					List<String> usrRolesLst = usrRoleMap.get(usr);
					if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
						for(String rls:usrRolesLst) {
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId(rls);
							usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls)));
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							//Logic added to replace role desc for roles not found
							String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
							if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
								rlDesc = usrMdl.getRoleId();
							}
							//END
							usrMdl.setPrimaryReviewInfo2(rlDesc);
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}else {//No Roles for the USER
						SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
						usrMdl.setRevUserId("");
						usrMdl.setUserId(usr);
						usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
						usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
						usrMdl.setRoleId("");
						usrMdl.setRoleDesc("");//No Roles Found
						usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
						usrMdl.setPrimaryReviewInfo2("");
						usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
						usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
						usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
						usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
						usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
						allUserData.add(usrMdl);
					}
				}//END - Preparing Role Data here
			}
			log.info("All USER-ROLE Data(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}




	//Region Wise User2Role
	public Map<String, List<SapGaaUser2RoleModel>> readSapUser2RoleRegionData(List<String>templSysParam){
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		Map<String, List<SapGaaUser2RoleModel>> allUser2RoleData = new HashMap<String, List<SapGaaUser2RoleModel>>();
		Calendar startTime, endTime = null;
		for(String sysTempl :templSysParam) {
			LinkedList<SapGaaUser2RoleModel> allUserData = new LinkedList<SapGaaUser2RoleModel>();
			Map<String, List<String>> usrRoleMap = new HashMap<String, List<String>>();
			Map<String, String> roleNameValue = new HashMap<String, String>();
			try{
				List<String> userLst = sAPExtrGaaDao.getAllValidUsers(sysTempl);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					for(String usr:userLst) {
						List<String> usrRoles = sAPExtrGaaDao.getUsersRoles(usr, sysTempl);
						if(usrRoles != null && !usrRoles.isEmpty()) {
							for(int i=0;i<usrRoles.size();i++) {
								roleNameValue.put(usrRoles.get(i), "");
							}

							if(usrRoleMap.containsKey(usr)) {
								List<String> roleList = usrRoleMap.get(usr);
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}else {
								List<String> roleList = new ArrayList<String>();
								roleList.addAll(usrRoles);
								usrRoleMap.put(usr, roleList);
							}
						}
					}
					log.info("Total User Records with Valid Roles(SAP) : "+((usrRoleMap !=null) ? usrRoleMap.size():"0"));
					//Getting Role Descriptions for All Unique Role Names
					for(String rlNm : roleNameValue.keySet()) {
						String roleDesc = sAPExtrGaaDao.getRoleDescription(rlNm, sysTempl);
						if(roleDesc != null && roleDesc.length() > 0 ) {
							roleNameValue.put(rlNm, roleDesc);
						}
					}

					for(String usr : usrRoleMap.keySet()) {
						UserSearchModel srchUsr = getUserStatusJJEDS(usr, 1);
						String[] sysInfoArr = sysTempl.split("_");
						List<String> usrRolesLst = usrRoleMap.get(usr);
						if(usrRolesLst != null && !usrRolesLst.isEmpty()) {
							for(String rls:usrRolesLst) {
								SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
								usrMdl.setRevUserId("");
								usrMdl.setUserId(usr);
								usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
								usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
								usrMdl.setRoleId(rls);
								usrMdl.setRoleDesc((roleNameValue.get(rls) == null ? "":roleNameValue.get(rls)));
								usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
								//Logic added to replace role desc for roles not found
								String rlDesc = usrMdl.getRoleDesc()== null? "":usrMdl.getRoleDesc().trim();
								if( rlDesc=="" || rlDesc == "0" || rlDesc.length()<=5) {
									rlDesc = usrMdl.getRoleId();
								}
								//END
								usrMdl.setPrimaryReviewInfo2(rlDesc);
								usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
								usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
								usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
								usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
								usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
								allUserData.add(usrMdl);
							}
						}else {//No Roles for the USER
							SapGaaUser2RoleModel usrMdl = new SapGaaUser2RoleModel();
							usrMdl.setRevUserId("");
							usrMdl.setUserId(usr);
							usrMdl.setFirstName((srchUsr==null?"":srchUsr.getGivenNm()));
							usrMdl.setLastName((srchUsr==null?"":srchUsr.getFmlyNm()));
							usrMdl.setRoleId("");
							usrMdl.setRoleDesc("");//No Roles Found
							usrMdl.setPrimaryReviewInfo1(usrMdl.getFirstName()+" "+usrMdl.getLastName()+ " has access to perform transactions or activities assigned in role/Position Description");
							usrMdl.setPrimaryReviewInfo2("");
							usrMdl.setPrimaryReviewInfo3("Within "+Utility.getSapClientName(sysInfoArr[3]));
							usrMdl.setAdditionalInfo1("SAP "+sysInfoArr[1]);
							usrMdl.setAdditionalInfo2("This review will recertify the access of the listed user remains valid or any adjustments required");
							usrMdl.setAdditionalInfo3(usrMdl.getRoleId());
							usrMdl.setUserStatus((srchUsr==null?"":srchUsr.getEmpStatTxt()));
							allUserData.add(usrMdl);
						}
					}//END - Preparing Role Data here
				}
				allUser2RoleData.put(sysTempl, allUserData);
			} catch (Exception e) {
				log.error("Error:"+e.getMessage(), e);
			}
		}
		return allUser2RoleData;
	}

	public List<SAPUserAccessModel> readSAPGaaUserAccessData(String templSysParam) {
		LinkedList<SAPUserAccessModel> allUserData = new LinkedList<SAPUserAccessModel>();

		Map<String, List<String>> usrRoleMap = new HashMap<String, List<String>>();
		Map<String, String> roleNameValue = new HashMap<String, String>();
		try {
			log.info("Getting User Data from USR02 for System: "+templSysParam);
			List<SAPUserAccessModel> userLst = sAPExtrGaaDao.getValidUsersWithDate(templSysParam);//Get All Users for the given System
			log.info("Total Records for User Data from USR02 ("+(userLst !=null? userLst.size():"0")+" for System: "+templSysParam);
			if(userLst != null && !userLst.isEmpty()) {
				//log.info("Populating WWID for Template Name : "+templSysParam+" Started");
				int i=0;
				for(SAPUserAccessModel usr:userLst) {
					String usrSapId = usr.getSapId();
					log.info((++i)+". Populating WWID for Template Name : "+templSysParam+" usrSapId: "+usrSapId);
					if(usrSapId.toUpperCase().equals(usrSapId.toLowerCase())) {
						usr.setWwid(usrSapId);
					}else {
						UserSearchModel ursMdl = getUserStatusJJEDS(usrSapId, 1);//Changes Recommended by Prem & Vinod on 08/20/2021
						usr.setWwid((ursMdl!=null)? ursMdl.getWwId() : "" );
						//Changes Recommended by Prem & Vinod on 08/20/2021
						//String prsnNum = sAPExtrGaaDao.getUsersPersonNumber(usr.getSapId(), templSysParam);
						//usr.setPersonNumber(prsnNum);
						//String wwid = sAPExtrGaaDao.getUsersWwId(usr.getPersonNumber(), templSysParam);
						//usr.setWwid(wwid);
					}
				}
				//log.info("Populating Person Number and WWID for Template Name : "+templSysParam +" Completed");
			}
			//Preparing USER ACCESS DATA
			String[] systemInfo = templSysParam.split("_");
			for(SAPUserAccessModel usrMdl:userLst) {
				usrMdl.setSapPlatform("SAP "+systemInfo[1]);
				usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
				usrMdl.setDescription("Access has been granted in the SAP "+systemInfo[1]+"-"+Utility.getSapClientName(systemInfo[2])+" System application. If the user no longer needs access to this system then please select REVOKE");
				String pltInfo =Utility.getSapPlatformInfo(systemInfo[1]).equals(systemInfo[1])? "Access is Granted in SAP "+systemInfo[1]:Utility.getSapPlatformInfo(systemInfo[1]) ;
				usrMdl.setDetails(pltInfo);
				if(!allUserData.contains(usrMdl)) {
					allUserData.add(usrMdl);
				}
			}
			log.info("All User ROLE Data for "+systemInfo[1]+"(size) :"+allUserData.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return allUserData;
	}


	@Override
	public String writeSapGaaUserAccessCSV(List<SAPUserAccessModel> data, String fileName) {
		String filePath = "";
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(data, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	@Override
	public String writeRegTrfCntrlCSV(Map<String, LinkedList<SAPUserAccessModel>> data, String fileName) {
		String filePath = "";
		List<SAPUserAccessModel> trfList = new ArrayList<SAPUserAccessModel>();
		for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry :data.entrySet() ) {
			trfList.addAll(entry.getValue());
		}
		filePath = csvReportWriter.writeSapGaaUserAccessCSV(trfList, fileName+"_"+Utility.fmtMDY(new Date())+".csv");
		return filePath;
	}

	//GETTING REGION-WISE DATA

	@Override
	public Map<String, LinkedList<SAPUserAccessModel>> readSAPTrfContolRegionData(List<String> templSysParam) {
		Map<String, LinkedList<SAPUserAccessModel>> regionDataMap = new HashMap<String, LinkedList<SAPUserAccessModel>>();
		log.info("System information received (Tranfer Control): "+ templSysParam.size()+" ("+templSysParam+"");
		int i=1;
		Calendar startTime, endTime = null;

		for(String sysTemp:templSysParam) {//For loop - PER SYSTEM - START
			LinkedList<SAPUserAccessModel> allUserData = new LinkedList<SAPUserAccessModel>();
			startTime = Calendar.getInstance();
			log.info("****START  Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
			Map<String, List<String>> usrRoleMap = new HashMap<String, List<String>>();
			Map<String, String> roleNameValue = new HashMap<String, String>();
			try{
				List<SAPUserAccessModel> userLst = sAPExtrGaaDao.getValidUsersWithDate(sysTemp);//Get All Users for the given System
				if(userLst != null && !userLst.isEmpty()) {
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Started");
					for(SAPUserAccessModel usr:userLst) {
						String prsnNum = sAPExtrGaaDao.getUsersPersonNumber(usr.getSapId(), sysTemp);
						usr.setPersonNumber(prsnNum);
						String wwid = sAPExtrGaaDao.getUsersWwId(prsnNum, sysTemp);
						usr.setWwid(wwid);
					}
					log.info("Populating Person Number and WWID for Template Name : "+templSysParam+" Completed");
				}
				//Preparing USER ACCESS DATA
				String[] systemInfo = sysTemp.split("_");
				for(SAPUserAccessModel usrMdl:userLst) {
					usrMdl.setSapPlatform("SAP "+systemInfo[1]);
					usrMdl.setSystemClient(Utility.getSapClientName(systemInfo[3]));
					usrMdl.setDescription("Access has been granted in the SAP "+systemInfo[1]+"-"+(Utility.getSapClientName(systemInfo[2]))+" System application. If the user no longer needs access to this system then please select REVOKE");
					String pltInfo = Utility.getSapPlatformInfo(systemInfo[1]).equals(systemInfo[1])? "Access is Granted in SAP "+systemInfo[1]:Utility.getSapPlatformInfo(systemInfo[1]) ;
					usrMdl.setDetails(pltInfo);
					allUserData.add(usrMdl);
				}
				log.info("All User ROLE Data for System: "+sysTemp+" (size) :"+allUserData.size()+" Completed");
			} catch (Exception e) {
				log.error("Error (System: "+sysTemp+"):"+e.getMessage(), e);
			}
			endTime=Calendar.getInstance();
			log.info("****END  Compute Data for System : "+templSysParam+" - Start time: "+endTime+" Total time taken: "+((endTime.getTimeInMillis() -startTime.getTimeInMillis()/1000) )+" Seconds  *****");
			regionDataMap.put(sysTemp, allUserData);
		}////For loop - PER SYSTEM - END
		return regionDataMap;
	}



	@Override
	public int exportTrfCntrlDataGenesis(Map<String, LinkedList<SAPUserAccessModel>> regDataMap, HttpServletRequest request) {
		int totalRecords = 0;
		String region = "";
		try{
			for(Map.Entry<String, LinkedList<SAPUserAccessModel>> entry:regDataMap.entrySet()) {
				String sysDetail=entry.getKey();
				region=sysDetail.split("_")[0];
				List<SAPUserAccessModel> dataList = entry.getValue();
				log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
				if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
					int recordsIns = genesisDao.insertTrfCntrlData(dataList);
					totalRecords = totalRecords+recordsIns;
				}else {
					int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
					int startPos = 0;
					int endPos = Constants.GEN_BATCH_SIZE;
					for(int i=0; i<pgCnt;i++) {
						List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
						int recordsIns = genesisDao.insertTrfCntrlData(insData);
						totalRecords = totalRecords +recordsIns;
						startPos = startPos + Constants.GEN_BATCH_SIZE;
						endPos = endPos + Constants.GEN_BATCH_SIZE;
						if(endPos >dataList.size()) {
							endPos = dataList.size();
						}
					}
				}
			}
			log.info("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("Total Records inserted for Region : "+region +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}






	@Override
	public Map<String, List<SAPUserAccessModel>> startTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<String, List<SAPUserAccessModel>>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP SYSTEMS
			List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
			log.info("TOTAL SAP Platforms in Region "+activeSchedule.getRegion()+" ("+((templSysParams != null && templSysParams.size() > 0)?templSysParams.size():0)+") ");
			if(templSysParams != null && !templSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = readSAPGaaUserAccessData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" Records: ("+trfUserData.size()+") - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> jdeTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_JDE");
			log.info("TOTAL JDE Platforms in Region "+activeSchedule.getRegion()+" ("+((jdeTemplSysParams != null && jdeTemplSysParams.size() > 0)?jdeTemplSysParams.size():0)+") ");
			if(jdeTemplSysParams != null && !jdeTemplSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:jdeTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = jDEExtrDataService.readTransferCntrlData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" Records("+trfUserData.size()+") - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			List<String> hanaTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_HANA");
			log.info("TOTAL HANA Platforms in Region "+activeSchedule.getRegion()+" ("+((hanaTemplSysParams != null && hanaTemplSysParams.size() > 0)?hanaTemplSysParams.size():0)+") ");
			if(hanaTemplSysParams != null && !hanaTemplSysParams.isEmpty()) {
				int i=0;
				for(String sysTemp:hanaTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+(++i)+". "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SAPUserAccessModel> trfUserData = hANADataService.readUserTrfContrlData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertTransferTransactions(trfUserData, sysTemp, activeSchedule.getCreatedBy());
						log.info(sysTemp+" Queried Records Count: "+trfUserData.size()+" Inserted Records Count: "+totalInsertedRecords);
						//Writing Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						saveSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "T");
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - HANA SYSTEMS

		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	private void saveCriticalSystemSummary(String sysTemp, int totalRecords, String user, String status) {
		try{
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setCreatedRecCount(totalRecords);
			sumMdl.setCreatedDt(new Date());
			sumMdl.setCreatedBy(user);
			sumMdl.setCollStatus(status);
			sAPExtrRegionWiseDao.saveUser2CriticalRoleDataSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Saving Critical Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	private void saveSystemSummary(String sysTemp, int totalRecords, String user, String status, String transType ) {
		try{
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setCreatedRecCount(totalRecords);
			sumMdl.setCreatedDt(new Date());
			sumMdl.setCreatedBy(user);
			sumMdl.setCollStatus(status);
			if("T".equals(transType)) {
				sAPExtrRegionWiseDao.saveTrfDataSummary(sumMdl);
			}else {
				sAPExtrRegionWiseDao.saveUser2RoleDataSummary(sumMdl);
			}

		} catch (Exception e) {
			log.info("Error Saving Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}


	@Override
	public Map<String, List<SAPUserAccessModel>> startExportTrfContolRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion());
    	log.info("EXPORT- All Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SAPUserAccessModel>> regionDataMap = new HashMap<String, List<SAPUserAccessModel>>();
		Calendar startTime, endTime = null;
		try{
			//START - EXPORT SAP SYSTEMS
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT SAP SYSTEMS

			//START - EXPORT JDE SYSTEMS
			List<String> jdeTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_JDE");
			if(jdeTemplSysParams != null && !jdeTemplSysParams.isEmpty()) {
				for(String sysTemp:jdeTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT JDE SYSTEMS

			//START - EXPORT HANA SYSTEMS
			List<String> hanaTemplSysParams = Utility.loadOneClickProperty(activeSchedule.getRegion()+"_HANA");
			if(hanaTemplSysParams != null && !hanaTemplSysParams.isEmpty()) {
				for(String sysTemp:hanaTemplSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					List<SAPUserAccessModel> trfUserData = readTrfExportDataTable(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					if(trfUserData != null && !trfUserData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
						int totalInsertedRecords = exportTrfCntrlDataToGenesis(trfUserData, sysTemp);
						//Writing Summary
						updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "T");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}else {
						updateSystemSummary(sysTemp, 0, activeSchedule.getCreatedBy(), "C", "C", "T");
					}
					regionDataMap.put(sysTemp, trfUserData);
				}
			}
			//END - EXPORT HANA SYSTEMS
		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

	private void updateSystemSummary(String sysTemp, int totalRecords, String user, String expStat, String collStat, String trnsType) {
		try {
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setExpRecCount(totalRecords);
			sumMdl.setExpStatus(expStat);
			sumMdl.setExpDt(new Date());
			sumMdl.setExpBy(user);
			sumMdl.setCollStatus(collStat);
			if("T".equals(trnsType)) {
				sAPExtrRegionWiseDao.updateTrfExportSummary(sumMdl);
			}else {
				sAPExtrRegionWiseDao.updateUser2RoleExportSummary(sumMdl);
			}

		} catch (Exception e) {
			log.info("Error Updating Export Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}

	private void updateCritSystemSummary(String sysTemp, int totalRecords, String user, String expStat, String collStat) {
		try {
			TrfCntrlSummaryMdl sumMdl = new TrfCntrlSummaryMdl();
			String[] systemInfo = sysTemp.split("_");
			sumMdl.setRegion(systemInfo[0]);
			sumMdl.setPlatform(systemInfo[1]);
			sumMdl.setEnvironment(systemInfo[2]);
			sumMdl.setSystem(systemInfo[3]);
			sumMdl.setExpRecCount(totalRecords);
			sumMdl.setExpStatus(expStat);
			sumMdl.setExpDt(new Date());
			sumMdl.setExpBy(user);
			sumMdl.setCollStatus(collStat);
			sAPExtrRegionWiseDao.updateUser2CriticalRoleExportSummary(sumMdl);
		} catch (Exception e) {
			log.info("Error Updating Export Summary for :"+sysTemp+" MSG:"+e.getMessage(), e);
		}
	}

	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule) {
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<String, List<SapGaaUser2RoleModel>>();
		Calendar startTime, endTime ;
		startTime = Calendar.getInstance();
		log.info("STARTING USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
		try{
			//START - SAP SYSTEMS
			List<String> templSysParamsSAP = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			log.info("Processing SAP USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
			if(templSysParamsSAP != null && !templSysParamsSAP.isEmpty()) {
				log.info("EXPORT - USER TO CRITICAL ROLE SAP Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsSAP.size()+") ");
				procUser2CriticalRoleExportTemplate(templSysParamsSAP, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion());
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			log.info("Processing JDE USER TO CRITICAL ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				log.info("EXPORT - USER TO CRITICAL ROLE JDE Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
				procUser2CriticalRoleExportTemplate(templSysParamsJDE, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion());
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHANA.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHANA, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion());
			}
			//END - HANA SYSTEMS

			endTime= Calendar.getInstance();
			log.info("COMPLETED USER TO CRITICAL ROLE EXPORT TO GENESIS End Time:"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" in Region "+activeSchedule.getRegion()+" (Total time :"+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" seconds)");
		} catch (Exception e) {
			log.error("ERROR PROCESSING CRITICAL DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}




	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startExportUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {

		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<String, List<SapGaaUser2RoleModel>>();
		Calendar startTime, endTime ;
		startTime = Calendar.getInstance();
		log.info("STARTING USER TO ROLE EXPORT TO GENESIS Start Time:"+Utility.fmtMMDDYYYYTime(startTime.getTime())+" in Region "+activeSchedule.getRegion());
		try{
			//START - SAP SYSTEMS
			List<String> templSysParamsSAP = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			if(templSysParamsSAP != null && !templSysParamsSAP.isEmpty()) {
				log.info("EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsSAP.size()+") ");
				procUser2RoleExportTemplate(templSysParamsSAP, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE SAP Platform in Region "+activeSchedule.getRegion());
			}
			//END - SAP SYSTEMS

			//START - JDE SYSTEMS
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				log.info("EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
				procUser2RoleExportTemplate(templSysParamsJDE, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE JDE Platform in Region "+activeSchedule.getRegion());
			}
			//END - JDE SYSTEMS

			//START - HANA SYSTEMS
			List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHANA.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHANA, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HANA Platform in Region "+activeSchedule.getRegion());
			}
			//END - HANA SYSTEMS

			//START - HCS/BRAVO SYSTEMS
			List<String> templSysParamsHCSBRAVO = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HCSBRAVO");
			if(templSysParamsHCSBRAVO != null && !templSysParamsHCSBRAVO.isEmpty()) {
				log.info("EXPORT - USER TO ROLE HCS/BRAVO Platform in Region "+activeSchedule.getRegion()+" ("+templSysParamsHCSBRAVO.size()+") ");
				procUser2RoleExportTemplate(templSysParamsHCSBRAVO, activeSchedule, regionDataMap);
			}else {
				log.info("NO DATA TO EXPORT - USER TO ROLE HCS/BRAVO Platform in Region "+activeSchedule.getRegion());
			}
			//END - HCS/BRAVO SYSTEMS


			endTime= Calendar.getInstance();
			log.info("COMPLETED USER TO ROLE EXPORT TO GENESIS End Time:"+Utility.fmtMMDDYYYYTime(endTime.getTime())+" in Region "+activeSchedule.getRegion()+" (Total time :"+((endTime.getTimeInMillis()-startTime.getTimeInMillis())/1000)+" seconds)");

  			for(String sysTemp:templSysParamsHANA) {//For loop - PER SYSTEM - START
				startTime = Calendar.getInstance();
				log.info("****START Compute Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
				List<SapGaaUser2RoleModel> user2RleData = readUser2RoleExportDataTable(sysTemp);
				endTime = Calendar.getInstance();
				log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");

				if(user2RleData != null && !user2RleData.isEmpty()) {
					//Insert in Trans Tables
					startTime = Calendar.getInstance();
					log.info("****START EXPORT Transaction Transfer Data for System : "+sysTemp+" - Start time: "+startTime+"  *****");
					int totalInsertedRecords = exportUser2RoleDataToGenesis(user2RleData, sysTemp);
					//Write Summary
					updateSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "C", "U");
					endTime = Calendar.getInstance();
					log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
				}
				regionDataMap.put(sysTemp, user2RleData);
			}

		} catch (Exception e) {
			log.error("ERROR PROCESSING DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}


	private void procUser2CriticalRoleExportTemplate(List<String>regTemplate, TrfCntrlSchModel regSchedule, Map<String, List<SapGaaUser2RoleModel>> regDataMap) throws Exception {
		Calendar startTime, endTime = null;
		for(String sysTemp:regTemplate) {
			startTime = Calendar.getInstance();
			log.info("****START Reading Data from USER_CRITICAL_ROLE_TRANSDATA for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
			List<SapGaaUser2RoleModel> user2RleData = readUser2CriticalRoleExportDataTable(sysTemp);
			endTime = Calendar.getInstance();
			log.info("****END Reading Data from USER_CRITICAL_ROLE_TRANSDATA for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
			if(user2RleData != null && !user2RleData.isEmpty()){
				Calendar insStartTime, insEndTime = null;
				insStartTime = Calendar.getInstance();
				log.info("****START EXPORT Transaction USER TO CRITICAL ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(insStartTime.getTime())+"  *****");
				int totalInsertedRecords = exportUser2CriticalRoleDataToGenesis(user2RleData, sysTemp);
				//Write Summary
				updateCritSystemSummary(sysTemp, totalInsertedRecords, regSchedule.getCreatedBy(), "C", "C");
				insEndTime = Calendar.getInstance();
				log.info("****END  INSERT Transaction USER TO ROLE Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(insEndTime.getTime())+" Total time: ("+((insEndTime.getTimeInMillis() - insStartTime.getTimeInMillis())/1000)+" Sec) *****");
			}
			regDataMap.put(sysTemp, user2RleData);
		}
	}

	private void procUser2RoleExportTemplate(List<String>regTemplate, TrfCntrlSchModel regSchedule, Map<String, List<SapGaaUser2RoleModel>> regDataMap) throws Exception {
		Calendar startTime, endTime = null;
		for(String sysTemp:regTemplate) {
			startTime = Calendar.getInstance();
			log.info("****START Reading Data from USER_ROLE_TRANSDATA for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
			List<SapGaaUser2RoleModel> user2RleData = readUser2RoleExportDataTable(sysTemp);
			endTime = Calendar.getInstance();
			log.info("****END Reading Data from USER_ROLE_TRANSDATA for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
			if(user2RleData != null && !user2RleData.isEmpty()){
				Calendar insStartTime, insEndTime = null;
				insStartTime = Calendar.getInstance();
				log.info("****START EXPORT Transaction USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(insStartTime.getTime())+"  *****");
				int totalInsertedRecords = exportUser2RoleDataToGenesis(user2RleData, sysTemp);
				//Write Summary
				updateSystemSummary(sysTemp, totalInsertedRecords, regSchedule.getCreatedBy(), "C", "C", "U");
				insEndTime = Calendar.getInstance();
				log.info("****END  INSERT Transaction USER TO ROLE Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(insEndTime.getTime())+" Total time: ("+((insEndTime.getTimeInMillis() - insStartTime.getTimeInMillis())/1000)+" Sec) *****");
			}
			regDataMap.put(sysTemp, user2RleData);
		}
	}





	private List<SAPUserAccessModel> readTrfExportDataTable(String templSysParam) {

		List<SAPUserAccessModel> userLst = new LinkedList<SAPUserAccessModel>();
		try{
			List<TrfCntrlTransDataMdl> dataLst = sAPExtrRegionWiseDao.getExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisData(dataLst);
			}
			log.info("Total UNIQUE records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}


	private List<SapGaaUser2RoleModel> readUser2RoleExportDataTable(String templSysParam) {
		List<SapGaaUser2RoleModel> userLst = new LinkedList<SapGaaUser2RoleModel>();
		try{
			List<SapGaaUser2RoleTransModel> dataLst = sAPExtrRegionWiseDao.getUser2RoleExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisUser2RoleData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}

	private List<SapGaaUser2RoleModel> readUser2CriticalRoleExportDataTable(String templSysParam) {
		List<SapGaaUser2RoleModel> userLst = new LinkedList<SapGaaUser2RoleModel>();
		try{
			List<SapGaaUser2RoleTransModel> dataLst = sAPExtrRegionWiseDao.getUser2CriticalRoleExportDataForRegPlatform(templSysParam);//Get All Users for the given System
			if(dataLst != null && dataLst.size() > 0) {
				userLst = buidlGenesisUser2RoleData(dataLst);
			}
			log.info("Total records to Export for "+templSysParam+"(size) :"+userLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return userLst;
	}

	private List<SAPUserAccessModel> buidlGenesisData(List<TrfCntrlTransDataMdl> dataLst) {
		List<SAPUserAccessModel> dList= new ArrayList<SAPUserAccessModel>();

		SAPUserAccessModel sapUser = null;
		for(TrfCntrlTransDataMdl trnsMdl : dataLst) {
			sapUser = new SAPUserAccessModel();
			sapUser.setSapId(trnsMdl.getUserNtId());
			//sapUser.setGltgb(gltgb);
			sapUser.setNtId(trnsMdl.getUserNtId());
			//sapUser.setPersonNumber(personNumber);
			sapUser.setWwid(trnsMdl.getWwid());
			sapUser.setSapPlatform(trnsMdl.getPlatform());
			sapUser.setSystemClient(trnsMdl.getSystem());
			sapUser.setDescription(trnsMdl.getDescription());
			sapUser.setDetails(trnsMdl.getDetails());
			if(!dList.contains(sapUser)){
				dList.add(sapUser);
			}
		}
		return dList;
	}


	private List<SapGaaUser2RoleModel> buidlGenesisUser2RoleData(List<SapGaaUser2RoleTransModel> dataLst) {
		List<SapGaaUser2RoleModel> dList= new ArrayList<SapGaaUser2RoleModel>();

		SapGaaUser2RoleModel sapUser = null;
		for(SapGaaUser2RoleTransModel trnsMdl : dataLst) {
			sapUser = new SapGaaUser2RoleModel();
			sapUser.setRevUserId("");
			sapUser.setUserId(trnsMdl.getUserId());
			sapUser.setPrimaryReviewInfo1(trnsMdl.getPrimaryReviewInfo1());
			sapUser.setPrimaryReviewInfo2(trnsMdl.getPrimaryReviewInfo2());
			sapUser.setPrimaryReviewInfo3(trnsMdl.getPrimaryReviewInfo3());
			sapUser.setAdditionalInfo1(trnsMdl.getAdditionalInfo1());
			sapUser.setAdditionalInfo2(trnsMdl.getAdditionalInfo2());
			sapUser.setAdditionalInfo3(trnsMdl.getAdditionalInfo3());
			dList.add(sapUser);
		}
		return dList;
	}



	public int insertTransferTransactions(List<SAPUserAccessModel> trfUserData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(trfUserData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(trfUserData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(trfUserData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = trfUserData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertTrfCntrlTransData(buidlTrfTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >trfUserData.size()) {
						endPos = trfUserData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional Transfer Control Data"+e.getMessage(), e);
		}

		return totalRecords;
	}



	@Override
	public int insertUser2RoleTransactions(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(user2RoleData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2RoleTransData(buidlUser2RoleTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2RoleData.size()) {
						endPos = user2RoleData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to ROLE Data"+e.getMessage(), e);
		}

		return totalRecords;
	}


	public int insertUser2CriticalRoleTrans(List<SapGaaUser2RoleModel> user2RoleData, String sysTemp, String createdUser) {
		int totalRecords = 0;
		try{
			if(user2RoleData.size() <= Constants.GEN_BATCH_SIZE) {
				int recordsIns = sAPExtrRegionWiseDao.insertUser2CriticalRoleTransData(buidlUser2RoleTransData(user2RoleData, sysTemp, createdUser));
				totalRecords = totalRecords+recordsIns;
			}else {
				int pgCnt = Utility.getPageCount(user2RoleData.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = user2RoleData.subList(startPos, endPos);
					int recordsIns = sAPExtrRegionWiseDao.insertUser2CriticalRoleTransData(buidlUser2RoleTransData(insData, sysTemp, createdUser));
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >user2RoleData.size()) {
						endPos = user2RoleData.size();
					}
				}
			}
		} catch (Exception e) {
			log.error("Error inserting Transactional USER to CRITICAL ROLE Data"+e.getMessage(), e);
		}

		return totalRecords;
	}



	@Override
	public int exportTrfCntrlDataToGenesis(List<SAPUserAccessModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertTrfCntrlData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SAPUserAccessModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertTrfCntrlData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR Total Records inserted for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("Error exporting Transfer records to Genesis"+e.getMessage(), e);
		}
		return totalRecords;
	}



	@Override
	public int exportUser2RoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2RoleData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2RoleData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User2 Role Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Role records to Genesis for System : "+sysDetail +" ( "+totalRecords+" )");
			log.error("ERROR exporting User to Role records to Genesis  for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}


	@Override
	public int exportUser2CriticalRoleDataToGenesis(List<SapGaaUser2RoleModel> dataList, String sysDetail) {
		int totalRecords = 0;
		try{
			log.info("Inserting User to Role Data for "+sysDetail+"  Total Records: "+dataList.size());
			if(dataList.size() <= Constants.GEN_BATCH_SIZE) {
				totalRecords = genesisDao.insertUser2RoleData(dataList);
			}else {
				int pgCnt = Utility.getPageCount(dataList.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<SapGaaUser2RoleModel> insData = dataList.subList(startPos, endPos);
					int recordsIns = genesisDao.insertUser2RoleData(insData);
					totalRecords = totalRecords +recordsIns;
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >dataList.size()) {
						endPos = dataList.size();
					}
				}
			}
			log.info("Total Records inserted for User to Critical Role Region : "+sysDetail +" ( "+totalRecords+" )");
		} catch (Exception e) {
			log.error("ERROR exporting User to Critical Role records to Genesis for System: "+sysDetail +" ( "+totalRecords+" ) "+e.getMessage(), e);
		}
		return totalRecords;
	}







	private List<TrfCntrlTransDataMdl> buidlTrfTransData(List<SAPUserAccessModel> insData, String templetParam, String usrScheduled){
		List<TrfCntrlTransDataMdl> dList= new ArrayList<TrfCntrlTransDataMdl>();
		String[] systemInfo = templetParam.split("_");
		TrfCntrlTransDataMdl trfMdl = null;
		String wwid="";
		for(SAPUserAccessModel sapMdl : insData) {
			trfMdl = new TrfCntrlTransDataMdl();
			trfMdl.setRegion(systemInfo[0]);
			trfMdl.setPlatform(systemInfo[1]);
			trfMdl.setEnvironment(systemInfo[2]);
			trfMdl.setSystem(systemInfo[3]);
			trfMdl.setDescription(sapMdl.getDescription());
			trfMdl.setDetails(sapMdl.getDetails());
			trfMdl.setUserNtId(sapMdl.getSapId());
			//TODO - Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getWwid() != null && sapMdl.getWwid().length() > 16) {
				wwid =sapMdl.getWwid().substring(0, 15);
			}else {
				wwid = sapMdl.getWwid();
			}
			//TODO - END
			trfMdl.setWwid(wwid);
			trfMdl.setCreatedBy(usrScheduled);
			trfMdl.setCreatedDt(new Date());
			dList.add(trfMdl);
		}
		return dList;
	}

	private List<SapGaaUser2RoleTransModel> buidlUser2RoleTransData(List<SapGaaUser2RoleModel> insData, String templetParam, String usrScheduled){
		List<SapGaaUser2RoleTransModel> dList= new ArrayList<SapGaaUser2RoleTransModel>();
		String[] systemInfo = templetParam.split("_");
		SapGaaUser2RoleTransModel usrMdl = null;
		String wwid="";
		for(SapGaaUser2RoleModel sapMdl : insData) {
			usrMdl = new SapGaaUser2RoleTransModel();
			usrMdl.setRegion(systemInfo[0]);
			usrMdl.setPlatform(systemInfo[1]);
			usrMdl.setEnvironment(systemInfo[2]);
			usrMdl.setSystem(systemInfo[3]);
			usrMdl.setRevUserId("");
			//Added this method to prevent INVALID -WWIDS getting in DB need to remove
			if(sapMdl.getUserId() != null && sapMdl.getUserId().length() > 16) {
				wwid =sapMdl.getUserId().substring(0, 15);
			}else {
				wwid = sapMdl.getUserId();
			}
			//END
			usrMdl.setUserId(wwid);
			usrMdl.setFirstName(sapMdl.getFirstName());
			usrMdl.setLastName(sapMdl.getLastName());
			usrMdl.setRoleId(sapMdl.getRoleId());
			usrMdl.setRoleDesc(sapMdl.getRoleDesc());
			usrMdl.setPrimaryReviewInfo1(sapMdl.getPrimaryReviewInfo1());
			usrMdl.setPrimaryReviewInfo2(sapMdl.getPrimaryReviewInfo2());
			usrMdl.setPrimaryReviewInfo3(sapMdl.getPrimaryReviewInfo3());

			usrMdl.setAdditionalInfo1(sapMdl.getAdditionalInfo1());
			usrMdl.setAdditionalInfo2(sapMdl.getAdditionalInfo2());
			usrMdl.setAdditionalInfo3(sapMdl.getAdditionalInfo3());
			usrMdl.setCreatedBy(usrScheduled);
			usrMdl.setCreatedDt(new Date());
			dList.add(usrMdl);
		}
		return dList;
	}

	//Region Wise USER-ROLE Processing
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startUser2RoleRegionSch(TrfCntrlSchModel activeSchedule) {
		List<String> templSysParams = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
    	log.info("All USER To ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<String, List<SapGaaUser2RoleModel>>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP DATA
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = readSapUserToRoleActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - SAP DATA

			//START - JDE DATA
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				for(String sysTemp:templSysParamsJDE) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = jDEExtrDataService.readUser2RoleActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - JDE DATA

			//START - HANA DATA
			List<String> templSysParamsHANA = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HANA");
			if(templSysParamsHANA != null && !templSysParamsHANA.isEmpty()) {
				for(String sysTemp:templSysParamsHANA) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = hANADataService.readHanaUserGrantActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - HANA DATA

			//START - HCS/BRAVO DATA
			List<String> templSysParamsHCS = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_HCSBRAVO");
			if(templSysParamsHCS != null && !templSysParamsHCS.isEmpty()) {
				for(String sysTemp:templSysParamsHCS) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> user2RoleData = hCSExtrDataService.readHcsBravoActData(sysTemp);
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(user2RoleData != null && !user2RoleData.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2RoleTransactions(user2RoleData, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C", "U");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, user2RoleData);
				}
			}
			//END - HCS/BRAVO DATA

		} catch (Exception e) {
			log.error("ERROR PROCESSING USER to ROLE DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

//USER TO CRITICAL ROLES REGION WISE
	@Override
	public Map<String, List<SapGaaUser2RoleModel>> startUser2CriticalRoleRegionSch(TrfCntrlSchModel activeSchedule) {
		log.info("Processing All Platforms USER To Critical ROLE in Region "+activeSchedule.getRegion());
		Map<String, List<SapGaaUser2RoleModel>> regionDataMap = new HashMap<String, List<SapGaaUser2RoleModel>>();
		Calendar startTime, endTime = null;
		try{
			//START - SAP DATA
			List<String> templSysParams = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion());
			log.info("Processing SAP USER To Critical ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParams.size()+") ");
			if(templSysParams != null && !templSysParams.isEmpty()) {
				for(String sysTemp:templSysParams) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> userToRoleData = readSapUserToRoleActData(sysTemp);
					//Start - Filtering Critical Roles
					List<SapGaaUser2RoleModel> criticalRolesLst = getCriticalUser2RoleInfo(userToRoleData);
			    	log.info("Total Records for User to Critical Roles :"+((criticalRolesLst == null || criticalRolesLst.isEmpty())? 0:criticalRolesLst.size()));
					//End - Filtering Critical Roles
					endTime = Calendar.getInstance();
					log.info("****END  Compute Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(criticalRolesLst != null && !criticalRolesLst.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Critical Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2CriticalRoleTrans(criticalRolesLst, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveCriticalSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction User to Critical Roles Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, criticalRolesLst);
				}
			}
			//END - SAP DATA

			//START - JDE DATA
			List<String> templSysParamsJDE = Utility.loadOneClickPropertyU2R(activeSchedule.getRegion()+"_JDE");
			log.info("Processing JDE USER To Critical ROLE Platforms in Region "+activeSchedule.getRegion()+" ("+templSysParamsJDE.size()+") ");
			if(templSysParamsJDE != null && !templSysParamsJDE.isEmpty()) {
				for(String sysTemp:templSysParamsJDE) {//For loop - PER SYSTEM - START
					startTime = Calendar.getInstance();
					log.info("****START Compute USER TO CRITICAL ROLE Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
					List<SapGaaUser2RoleModel> userToRoleData = jDEExtrDataService.readUser2RoleActData(sysTemp);
					//Start - Filtering Critical Roles
					List<SapGaaUser2RoleModel> criticalRolesLst = getCriticalUser2RoleInfo(userToRoleData);
			    	log.info("Total Records for User to Critical Roles :"+((criticalRolesLst == null || criticalRolesLst.isEmpty())? 0:criticalRolesLst.size()));
					//End - Filtering Critical Roles
					endTime = Calendar.getInstance();
					log.info("****END  Compute Critical Data for System : "+sysTemp+" - End time: "+Utility.fmtMMDDYYYYTime(endTime.getTime())+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					//
					if(criticalRolesLst != null && !criticalRolesLst.isEmpty()) {
						//Insert in Trans Tables
						startTime = Calendar.getInstance();
						log.info("****START INSERT User to Critical Role  Data for System : "+sysTemp+" - Start time: "+Utility.fmtMMDDYYYYTime(startTime.getTime())+"  *****");
						int totalInsertedRecords = insertUser2CriticalRoleTrans(criticalRolesLst, sysTemp, activeSchedule.getCreatedBy());
						//Write Summary
						saveCriticalSystemSummary(sysTemp, totalInsertedRecords, activeSchedule.getCreatedBy(), "C");
						endTime = Calendar.getInstance();
						log.info("****END  INSERT Transaction Transfer Data for System : "+sysTemp+" - End time: "+endTime+" Total time: ("+((endTime.getTimeInMillis() - startTime.getTimeInMillis())/1000)+" Sec) *****");
					}
					regionDataMap.put(sysTemp, criticalRolesLst);
				}
			}
			//END - JDE DATA

			//START - HANA DATA

			//START - HANA DATA
		} catch (Exception e) {
			log.error("ERROR PROCESSING USER to CRITICAL ROLE DATA for REGION : "+activeSchedule.getRegion()+" - "+e.getMessage(), e);
		}
	 	return regionDataMap;
	}

	@Override
	public Map <String, Map<String, List<SapDataTransferReportMdl>>> getGenesisTransferReportData() {
		Map <String, Map<String, List<SapDataTransferReportMdl>>> allDataMap = new HashMap<String, Map<String, List<SapDataTransferReportMdl>>>();
		Map<String, List<SapDataTransferReportMdl>> repSignedOffMap = new HashMap<String, List<SapDataTransferReportMdl>>();
		Map<String, List<SapDataTransferReportMdl>> repOthersfMap = new HashMap<String, List<SapDataTransferReportMdl>>();
		List<String> sysIDs=new ArrayList<String>();
		try{
			List<SapDataTransferReportMdl> repLst = genesisDao.getGenesisTransferCtrlReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapDataTransferReportMdl repMdl : repLst ) {
					String pltForm = repMdl.getSapPlatfrom().toUpperCase().trim();
					if(!sysIDs.contains(pltForm)) {sysIDs.add(pltForm);}//Adding all Systems to List
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapDataTransferReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(pltForm)) {
							sOfLst = repSignedOffMap.get(pltForm);
							sOfLst.add(repMdl);
							repSignedOffMap.put(pltForm, sOfLst);
						}else {
							sOfLst = new ArrayList<SapDataTransferReportMdl> ();
							sOfLst.add(repMdl);
							repSignedOffMap.put(pltForm, sOfLst);
						}
					}else {//Other Items
						List<SapDataTransferReportMdl> othLst = null;
						if(repOthersfMap.containsKey(pltForm)) {
							othLst = repOthersfMap.get(pltForm);
							othLst.add(repMdl);
							repOthersfMap.put(pltForm, othLst);
						}else {
							othLst = new ArrayList<SapDataTransferReportMdl> ();
							othLst.add(repMdl);
							repOthersfMap.put(pltForm, othLst);
						}
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersfMap);
			}
			Utility.setCache(Constants.TRF_REPORT_SO_SYSTEMS, sysIDs);//Adding Cache
		} catch (Exception e) {
			log.error("Error Collecting Genesis Transfer Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}


	@Override
	public Map <String, Map<String, List<SapUser2RoleReportMdl>>> getGenesisUser2RoleReportData() {
		Map <String, Map<String, List<SapUser2RoleReportMdl>>> allDataMap = new HashMap<String, Map<String, List<SapUser2RoleReportMdl>>>();
		Map<String, List<SapUser2RoleReportMdl>> repSignedOffMap = new HashMap<String, List<SapUser2RoleReportMdl>>();
		Map<String, List<SapUser2RoleReportMdl>> repOthersfMap = new HashMap<String, List<SapUser2RoleReportMdl>>();
		List<String> sysIDs=new ArrayList<String>();
		try{
			List<SapUser2RoleReportMdl> repLst = genesisDao.getGenesisUser2RoleReportData();
			if(repLst != null && !repLst.isEmpty() ) {
				for(SapUser2RoleReportMdl repMdl : repLst ) {
					String pltForm = repMdl.getGroupPlatform().toUpperCase().trim();
					if(!sysIDs.contains(pltForm)) {sysIDs.add(pltForm);}//Adding all Systems to List
					if(repMdl.getReviewStatus().indexOf("Item Signed-Off") > 0) {//Signed Off Items
						List<SapUser2RoleReportMdl> sOfLst = null;
						if(repSignedOffMap.containsKey(pltForm)) {
							sOfLst = repSignedOffMap.get(pltForm);
							sOfLst.add(repMdl);
						}else {
							sOfLst = new ArrayList<SapUser2RoleReportMdl> ();
							sOfLst.add(repMdl);
						}
						repSignedOffMap.put(pltForm, sOfLst);
					}else {//Other Items
						List<SapUser2RoleReportMdl> othLst = null;
						if(repOthersfMap.containsKey(pltForm)) {
							othLst = repOthersfMap.get(pltForm);
							othLst.add(repMdl);
						}else {
							othLst = new ArrayList<SapUser2RoleReportMdl> ();
							othLst.add(repMdl);
						}
						repOthersfMap.put(pltForm, othLst);
					}
				}
				allDataMap.put("SIGNED_ITEMS", repSignedOffMap);
				allDataMap.put("OTHER_ITEMS", repOthersfMap);
			}
			Utility.setCache(Constants.U2R_REPORT_SO_SYSTEMS, sysIDs);//Adding Cache
		} catch (Exception e) {
			log.error("Error Collecting Genesis USER TO ROLE Report Data :"+e.getMessage(), e);
		}
		return allDataMap;
	}

	public String writeLogData(StringBuilder data, String fileName) {
		 String filePath = "";
		 try {
			 File csvFile = new File(Constants.REPO_OUT_LOC+fileName);
			 filePath = csvFile.getAbsolutePath();
			 log.info("Writing file :"+filePath);
			 CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
			 writer.writeNext(new String[]{ data.toString()});
			 writer.close();
		} catch (Exception e) {
			log.info("Error writing Log Data: "+e.getMessage());
			e.printStackTrace();
		}
		 return filePath;
	 }


	@Override
	public Map <String, List<SapUser2RoleDeltaMdl>> getGenesisUser2RoleData(List<String> users) {
		Map <String, List<SapUser2RoleDeltaMdl>> allDataMap = new HashMap<String, List<SapUser2RoleDeltaMdl>>();
		Map<String, String> usrMap=new HashMap<String, String>();
		Date reportDate = new Date();
		try{
			List<SapUser2RoleDeltaMdl> repLst = new ArrayList<SapUser2RoleDeltaMdl>();;
			if(users.size() <= Constants.GEN_BATCH_SIZE) {
				repLst = genesisDao.getGenesisUser2RoleData(users);
			}else {
				int pgCnt = Utility.getPageCount(users.size(), Constants.GEN_BATCH_SIZE);
				int startPos = 0;
				int endPos = Constants.GEN_BATCH_SIZE;
				for(int i=0; i<pgCnt;i++) {
					List<String> qryLst = users.subList(startPos, endPos);
					repLst.addAll(genesisDao.getGenesisUser2RoleData(qryLst));
					startPos = startPos + Constants.GEN_BATCH_SIZE;
					endPos = endPos + Constants.GEN_BATCH_SIZE;
					if(endPos >users.size()) {
						endPos = users.size();
					}
				}
			}
			for(String id:users) {
				UserSearchModel srchUsr=this.getUserStatusJJEDS(id, 0);
				if(srchUsr != null) {
					usrMap.put(id, srchUsr.getEmpStatTxt());
				}else {
					usrMap.put(id, "NOT FOUND");
				}
			}

			if(repLst != null && !repLst.isEmpty() ) {
				List<SapUser2RoleDeltaMdl> dataLst = null;
				for(SapUser2RoleDeltaMdl repMdl : repLst ) {
					String pltForm = repMdl.getAdditionalInfo1().toUpperCase().trim();
					String usrId = repMdl.getUserId().trim();
					repMdl.setUserStatus(usrMap.get(usrId));
					repMdl.setReportDate(reportDate);
					if(allDataMap.containsKey(pltForm)) {
						dataLst = allDataMap.get(pltForm);
						dataLst.add(repMdl);
					}else {
						dataLst = new ArrayList<SapUser2RoleDeltaMdl>();;
						dataLst.add(repMdl);
					}
					allDataMap.put(pltForm, dataLst);
				}
			}
			log.info("Total Platforms returned for USER2ROLE Delta: "+(!allDataMap.isEmpty()? allDataMap.size():"0"));
		} catch (Exception e) {
			log.error("ERROR Collecting Genesis USER TO ROLE Data for Delta comparison :"+e.getMessage(), e);
		}
		return allDataMap;
	}



	@Override
	public List<SapU2RDeltaSummaryMdl> getUser2RoleSummaryDeltaData(String type){
		List<SapU2RDeltaSummaryMdl> allDataLst = new ArrayList<SapU2RDeltaSummaryMdl>();
		try{
			allDataLst = genesisDao.getGenesisUserWiseCounts(type);
			log.info("USER2ROLE Delta summary size: "+(!allDataLst.isEmpty()? allDataLst.size():"0"));
		} catch (Exception e) {
			log.error("ERROR getting USER2ROLE Delta summary :"+e.getMessage(), e);
		}
		return allDataLst;
	}

	@Override
	public int checkDeltaRecord(SapUser2RoleDeltaMdl rec2Check) {
		int recCount=0;
		try{
			recCount = genesisDao.checkUser2RoleReportRecord(rec2Check.getUserId(), rec2Check.getPrimaryReviewInfo3(), rec2Check.getAdditionalInfo3());
		} catch (Exception e) {
			log.error("ERROR Collecting Genesis USER TO ROLE Data for Delta comparison :"+e.getMessage(), e);
		}
		return recCount;
	}



	@Override
	public List<SapGaaUser2RoleModel> getCriticalUser2RoleInfo(List<SapGaaUser2RoleModel> activeTrfData) {
		List<SapGaaUser2RoleModel> critalU2RLst = new ArrayList<SapGaaUser2RoleModel>();
		Map<String, String> userToCriticalRoleMatrix = sAPExtrRegionWiseService.loadAllCriticalRoles();
		if(activeTrfData != null && !activeTrfData.isEmpty()) {
			for(SapGaaUser2RoleModel crMdl : activeTrfData) {
				String crKey=crMdl.getAdditionalInfo1().toUpperCase().trim()+"_"+crMdl.getAdditionalInfo3().toUpperCase().trim();
				if(userToCriticalRoleMatrix.containsKey(crKey)) {
					critalU2RLst.add(crMdl);
				}
			}
		}
		return critalU2RLst;
	}



	@Override
	public String clearUser2RoleDelta() {
		String result= "";
		try{
			result = sAPExtrRegionWiseDao.clearDeltaData();
			log.info("Cleared Delta User2Role: "+result);
		} catch (Exception e) {
			log.error("ERROR Clearing USER2ROLE Delta :"+e.getMessage(), e);
		}
		return result;
	}


	@Override
	public String writeSapGaaUser2RoleXLS(List<SapGaaUser2RoleModel> data, String fileName, String sheetNm) {
		String filePath = "";
		try {
			filePath = excelReportWriter.writeSapGaaUser2RoleExcel(data, fileName+"_"+Utility.fmtMDY(new Date()), sheetNm);
		} catch (Exception e) {
			log.error("Error Writing Excel:"+e.getMessage(), e);
		}

		return filePath;
	}


	@Override
	public List<TrfCntrlTransDataMdl> getAllTrfControlExportableData(String regn) {
		List<TrfCntrlTransDataMdl> dataLst = new ArrayList<TrfCntrlTransDataMdl>();
		try{
			dataLst = sAPExtrRegionWiseDao.getAllTRFCntrlExportableData(regn);
			log.info("Total records to Download for Region("+regn+") :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn){
		List<SapGaaUser2RoleTransModel> dataLst = new ArrayList<SapGaaUser2RoleTransModel>();
		try{
			dataLst = sAPExtrRegionWiseDao.getAllUser2RoleExportableData(regn);
			log.info("Total records to Download for Region("+regn+") :"+dataLst.size());
		} catch (Exception e) {
			log.error("Error:"+e.getMessage(), e);
		}
		return dataLst;
	}

	@Override
	public UserSearchModel getUserStatusJJEDS(String userId, int active) {
		List<UserSearchModel> usrList= null;
		userId= userId.toUpperCase();
		UserSearchModel srchUsr = Utility.getUser(userId);
		if(srchUsr == null){
			if(userId.toUpperCase().equals(userId.toLowerCase())) {
				usrList = userSearchService.getUserData(1, userId, active);
			}else {
				usrList = userSearchService.getUserData(2, userId, active);
			}

			if(usrList != null && !usrList.isEmpty()) {
				srchUsr = usrList.get(0);
				Utility.setUser(userId, srchUsr);
			}
		}
		return srchUsr;
	}






	*/







}
