package com.jnj.rqc.models;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Assigner {
	int logSeq;
	String ticktNo;
	int cliId;
	String assigneeName;
	Date rowAddTms;
	String Cmnts;
}
