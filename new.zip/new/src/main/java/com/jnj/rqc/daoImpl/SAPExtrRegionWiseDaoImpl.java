package com.jnj.rqc.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.jnj.rqc.conflictModel.SAPTrfCntrlSummaryMdl;
import com.jnj.rqc.conflictModel.SapGaaUser2RoleTransModel;
import com.jnj.rqc.conflictModel.SapU2RDeltaSummaryMdl;
import com.jnj.rqc.conflictModel.SapUser2RoleDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodDeltaMdl;
import com.jnj.rqc.conflictModel.SapUser2SodModel;
import com.jnj.rqc.conflictModel.SapUser2SodTrnsModel;
import com.jnj.rqc.conflictModel.User2RoleRawDataMdl;
import com.jnj.rqc.dao.SAPExtrRegionWiseDao;
import com.jnj.rqc.dbconfig.BaseDao;
import com.jnj.rqc.models.U2REmailLogMdl;
import com.jnj.rqc.models.UserSearchModel;
import com.jnj.rqc.sch.CriticalRoleModel;
import com.jnj.rqc.sch.SchAdminModel;
import com.jnj.rqc.sch.TrfCntrlSchModel;
import com.jnj.rqc.sch.TrfCntrlSummaryMdl;
import com.jnj.rqc.sch.TrfCntrlTransDataMdl;
import com.jnj.rqc.util.Utility;




@Service
public class SAPExtrRegionWiseDaoImpl  extends BaseDao implements SAPExtrRegionWiseDao {
	static final Logger log = LoggerFactory.getLogger(SAPExtrRegionWiseDaoImpl.class);

	@Override
	public List<SchAdminModel> getActiveSchedulers() throws SQLException, DataAccessException {
		log.info("Getting All ACTIVE Schedulees");
		String sql = " Select REGION, RUN_SCH, CREATED_DT, CREATED_BY FROM SOD_DB_USER.SCH_ADMIN WHERE RUN_SCH= '1' ";
		final List<SchAdminModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(SchAdminModel.class));
		log.info("Total Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}

	@Override
	public List<TrfCntrlSchModel> getSchedulerStatus(String region) throws SQLException, DataAccessException {
		log.info("Getting All Schedules for REGION: "+ region);
		String sql = " Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
					 " From SOD_DB_USER.TRF_CNTRL_SCH " +
					 " Where REGION = ? ";  //AND SCH_STATUS IN ('S','I');";
		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {region}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Total Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}

	@Override
	public List<TrfCntrlSchModel> getAllTrfCntrlSchedules(List<String> regions) throws SQLException, DataAccessException {
		log.info("Getting All Schedules for REGION: "+ (!regions.isEmpty()? regions:""));
		StringBuilder sql = new StringBuilder();
		sql.append(" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " );
		sql.append(" From SOD_DB_USER.TRF_CNTRL_SCH " );
		Object[] params = null;
		if(regions != null && !regions.isEmpty()) {
			params = regions.toArray();
			sql.append(" WHERE REGION IN (");
			for(int i=0;i<regions.size(); i++) {
				sql.append(" ?");
				if(i<(regions.size() -1)) {
					sql.append(", ");
				}
			}
			sql.append(" ) ");
		}else {
			params = new Object[] {};
		}
		sql.append(" ORDER By REGION, TYPE ");

		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql.toString(), params, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Total Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}


	/* Returns only Active Schedules for given region
	 * @see com.jnj.rqc.dao.SAPExtrRegionWiseDao#getCurrentTrfSchedule(java.lang.String)
	 */
	@Override
	public List<TrfCntrlSchModel> getCurActTrfSchedule(String region, String status, String sType) throws SQLException, DataAccessException {
		log.info("Getting Current TRANSFER CNTRL Schedules for REGION: "+ region);
		String sql = " Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
					 " From SOD_DB_USER.TRF_CNTRL_SCH " +
					 " Where REGION = ?  AND SCH_STATUS = ? AND TYPE= ? ";  //AND SCH_STATUS IN ('S','I');";
		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, status, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Current TRANSFER CNTRL Schedules returned : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}


	@Override
	public List<TrfCntrlSchModel> getCurActUser2RoleSchedule(String region, String status, String sType) throws SQLException, DataAccessException {
		log.info("Getting Current USER2ROLE Schedules for REGION: "+ region);
		String sql = " Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
					 " From SOD_DB_USER.USER_ROLE_SCH " +
					 " Where REGION = ?  AND SCH_STATUS = ? AND TYPE= ? ";  //AND SCH_STATUS IN ('S','I');";
		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, status, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Current USER2ROLE Schedules returned : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}


	@Override
	public List<TrfCntrlSchModel> getCurActUser2CriticalRoleSchedule(String region, String status, String sType) throws SQLException, DataAccessException {
		log.info("Getting Current USER2CRITICALROLE Schedules for REGION: "+ region);
		String sql = " Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
					 " From SOD_DB_USER.USER_CRITICAL_ROLE_SCH " +
					 " Where REGION = ?  AND SCH_STATUS = ? AND TYPE= ? ";  //AND SCH_STATUS IN ('S','I');";
		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, status, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Current USER2CRITICALROLE Schedules returned : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}

	@Override
	public List<TrfCntrlSchModel> getCurActUser2SodSchedule(String region, String status, String sType) throws SQLException, DataAccessException {
		log.info("Getting Current USER2CRITICALROLE Schedules for REGION: "+ region);
		String sql = " Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
					 " From SOD_DB_USER.USER2SOD_SCH " +
					 " Where REGION = ?  AND SCH_STATUS = ? AND TYPE= ? ";  //AND SCH_STATUS IN ('S','I');";
		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, status, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Current USER2SOD Schedules returned : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}


	@Override
	public boolean saveSchedule(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException {
		log.info("Saving Schedule for Region : "+region +" User: "+user.getJnjMsftUsrnmTxt());
		String det ="";
		if("C".equals(sType)) {
			det = "Scheduling Regionwise Transfer Control Data process for region: "+region;
		}else if("E".equals(sType)) {
			det = "Scheduling Regionwise Transfer Control Data Export for region: "+region;
		}
		String sql = " Insert into SOD_DB_USER.TRF_CNTRL_SCH ( REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT )"+
					 " Values ( ?, ?, ?, ?, ?, ?, ?, ? )";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {region, sType, new Date(), "S", det, new Date(), user.getJnjMsftUsrnmTxt(), null});
		return (result > 0 ? true : false);
	}


	@Override
	public int countScheduleforRegion(String region, String sType, String dataType) throws SQLException, DataAccessException {
		log.info("Cheking "+("T".equals(dataType)? " TRANSFER CONTROL ":" USER TO ROLE ")+" Schedule for Region : "+region +" Type: "+sType+" ");
		String sql="";
		String msg="";
		if("T".equals(dataType)) {
			sql = " SELECT count(*) from SOD_DB_USER.TRF_CNTRL_SCH WHERE REGION= ? and TYPE=? ";
			msg= "Total Schedule records for Transfer Control :";
		}else {
			sql = " SELECT count(*) from SOD_DB_USER.USER_ROLE_SCH WHERE REGION= ? and TYPE=? ";
			msg= "Total Schedule records for User to Role :";
		}

		int result = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {region, sType}, Integer.class);
		log.info(msg+" "+result);
		return result;
	}

	@Override
	public int countU2SSchforRegion(String region, String sType, String dataType) throws SQLException, DataAccessException {
		log.info("Cheking  USER TO SOD Schedule for Region : "+region +" Type: "+sType+" ");
		String sql=" SELECT count(*) from SOD_DB_USER.USER2SOD_SCH WHERE REGION= ? and TYPE=? ";
		int result = getJdbcTemplateSRADUtils().queryForObject(sql, new Object[] {region, sType}, Integer.class);
		log.info("Total Schedule records for User to Sod ("+region+"): "+result);
		return result;
	}


	@Override
	public boolean saveScheduleUser2Role(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException {
		log.info("Saving Schedule USER To ROLE for Region : "+region +" User: "+user.getJnjMsftUsrnmTxt());
		String det ="";
		if("C".equals(sType)) {
			det = "Scheduling Regionwise USER To ROLE Data process for region: "+region;
		}else if("E".equals(sType)) {
			det = "Scheduling Regionwise USER To ROLE Data Export for region: "+region;
		}
		String sql = " Insert into SOD_DB_USER.USER_ROLE_SCH ( REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT )"+
					 " Values ( ?, ?, ?, ?, ?, ?, ?, ? )";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {region, sType, new Date(), "S", det, new Date(), user.getJnjMsftUsrnmTxt(), null});
		return (result > 0 ? true : false);
	}


	@Override
	public boolean saveScheduleUser2CriticalRole(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException {
		log.info("Saving Schedule USER To CRITICAL ROLE for Region : "+region +" User: "+user.getJnjMsftUsrnmTxt());
		String det ="";
		if("C".equals(sType)) {
			det = "Scheduling Regionwise USER To CRITICAL ROLE Data Creation for region: "+region;
		}else if("E".equals(sType)) {
			det = "Scheduling Regionwise USER To CRITICAL ROLE Data Export for region: "+region;
		}
		String sql = " Insert into SOD_DB_USER.USER_CRITICAL_ROLE_SCH ( REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT )"+
					 " Values ( ?, ?, ?, ?, ?, ?, ?, ? )";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {region, sType, new Date(), "S", det, new Date(), user.getJnjMsftUsrnmTxt(), null});
		return (result > 0 ? true : false);
	}


	@Override
	public boolean saveScheduleUser2Sod(String region, UserSearchModel user, String sType) throws SQLException, DataAccessException {
		log.info("Saving Schedule USER To SOD for Region : "+region +" User: "+user.getJnjMsftUsrnmTxt());
		String det ="";
		if("C".equals(sType)) {
			det = "Scheduling Regionwise USER To SOD Data Creation for region: "+region;
		}else if("E".equals(sType)) {
			det = "Scheduling Regionwise USER To SOD Data Export for region: "+region;
		}
		String sql = " Insert into SOD_DB_USER.USER2SOD_SCH ( REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT )"+
					 " Values ( ?, ?, ?, ?, ?, ?, ?, ? )";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {region, sType, new Date(), "S", det, new Date(), user.getJnjMsftUsrnmTxt(), null});
		return (result > 0 ? true : false);
	}



	@Override
	public int updateTransferSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException {
		log.info("Update TRANSFER CNTRL Status for Region : "+region +" User: "+user+" Status : "+status);
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.TRF_CNTRL_SCH SET SCH_STATUS = ? ");
		if("C".equals(status)) {
			sql.append(" , COMPLETED_DT = ? ");
		}
		sql.append(" WHERE REGION = ?  AND CREATED_BY = ? AND TYPE= ? ");
		Object[] inputArr = null;
		if("C".equals(status)) {
			inputArr = new Object[] {status, new Date(), region, user, sType};
		}else {
			inputArr = new Object[] {status, region, user, sType};
		}
		log.debug("SQL:"+sql.toString());
		int result = getJdbcTemplateSRADUtils().update(sql.toString(), inputArr);
		return result;
	}


	@Override
	public int updateUser2RoleSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException {
		log.debug("Update USER2ROLE Status for Region : "+region +" User: "+user+" Status : "+status);
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.USER_ROLE_SCH SET SCH_STATUS = ? ");
		if("C".equals(status)) {
			sql.append(" , COMPLETED_DT = ? ");
		}
		sql.append(" WHERE REGION = ?  AND CREATED_BY = ? AND TYPE= ? ");
		Object[] inputArr = null;
		if("C".equals(status)) {
			inputArr = new Object[] {status, new Date(), region, user, sType};
		}else {
			inputArr = new Object[] {status, region, user, sType};
		}
		log.debug("SQL:"+sql.toString());
		int result = getJdbcTemplateSRADUtils().update(sql.toString(), inputArr);
		return result;
	}


	@Override
	public int updateUser2CriticalRoleSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException {
		log.debug("Update USER2CRITICAL ROLE Status for Region : "+region +" User: "+user+" Status : "+status);
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.USER_CRITICAL_ROLE_SCH SET SCH_STATUS = ? ");
		if("C".equals(status)) {
			sql.append(" , COMPLETED_DT = ? ");
		}
		sql.append(" WHERE REGION = ?  AND CREATED_BY = ? AND TYPE= ? ");
		Object[] inputArr = null;
		if("C".equals(status)) {
			inputArr = new Object[] {status, new Date(), region, user, sType};
		}else {
			inputArr = new Object[] {status, region, user, sType};
		}
		log.debug("SQL:"+sql.toString());
		int result = getJdbcTemplateSRADUtils().update(sql.toString(), inputArr);
		return result;
	}

	@Override
	public int updateUser2SodSchStatus(String region, String status, String user, String sType) throws SQLException, DataAccessException {
		log.debug("Update USER2SOD Status for Region : "+region +" User: "+user+" Status : "+status);
		StringBuilder sql = new StringBuilder();
		sql.append(" UPDATE SOD_DB_USER.USER2SOD_SCH SET SCH_STATUS = ? ");
		if("C".equals(status)) {
			sql.append(" , COMPLETED_DT = ? ");
		}
		sql.append(" WHERE REGION = ?  AND CREATED_BY = ? AND TYPE= ? ");
		Object[] inputArr = null;
		if("C".equals(status)) {
			inputArr = new Object[] {status, new Date(), region, user, sType};
		}else {
			inputArr = new Object[] {status, region, user, sType};
		}
		log.debug("SQL:"+sql.toString());
		int result = getJdbcTemplateSRADUtils().update(sql.toString(), inputArr);
		return result;
	}

	@Override
	public boolean saveTrfDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving Data Summary for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " INSERT INTO SOD_DB_USER.TRF_CNTRL_SUMMARY(" +
					"  REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY ) "
					+ " VALUES " +
					" ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCreatedRecCount()
				, sumMdl.getCreatedDt(), sumMdl.getCreatedBy(), sumMdl.getCollStatus(), null, null, 0, null});
		return (result > 0 ? true : false);
	}

	@Override
	public boolean saveUser2RoleDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving User to Role Data Summary for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " INSERT INTO SOD_DB_USER.USER_ROLE_SUMMARY(" +
					"  REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY ) "
					+ " VALUES " +
					" ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCreatedRecCount()
				, sumMdl.getCreatedDt(), sumMdl.getCreatedBy(), sumMdl.getCollStatus(), null, null, 0, null});
		return (result > 0 ? true : false);
	}

	@Override
	public boolean saveUser2SodDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving User to Sod Data Summary for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " INSERT INTO SOD_DB_USER.USER2SOD_SUMMARY(" +
					"  REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY ) "
					+ " VALUES " +
					" ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCreatedRecCount()
				, sumMdl.getCreatedDt(), sumMdl.getCreatedBy(), sumMdl.getCollStatus(), null, null, 0, null});
		return (result > 0 ? true : false);
	}

	@Override
	public boolean saveUser2CriticalRoleDataSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving User to Critical Role Data Summary for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " INSERT INTO SOD_DB_USER.USER_CRITICAL_ROLE_SUMMARY(" +
					"  REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY ) "
					+ " VALUES " +
					" ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCreatedRecCount()
				, sumMdl.getCreatedDt(), sumMdl.getCreatedBy(), sumMdl.getCollStatus(), null, null, 0, null});
		return (result > 0 ? true : false);
	}
	@Override
	public boolean updateTrfExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving Data Summary for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " UPDATE SOD_DB_USER.TRF_CNTRL_SUMMARY " +
					"  SET EXP_STATUS = ?, EXP_DT = ?, EXP_REC_COUNT = ?, EXP_BY = ? "+
					" WHERE REGION =? AND PLATFORM = ? AND ENVIRONMENT = ? AND SYSTEM = ? AND COLL_STATUS = ? ";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getExpStatus(), sumMdl.getExpDt(), sumMdl.getExpRecCount(), sumMdl.getExpBy(),
											sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCollStatus()});
		return (result > 0 ? true : false);
	}

	@Override
	public boolean updateUser2RoleExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving Data Summary User2 Role for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " UPDATE SOD_DB_USER.USER_ROLE_SUMMARY " +
					"  SET EXP_STATUS = ?, EXP_DT = ?, EXP_REC_COUNT = ?, EXP_BY = ? "+
					" WHERE REGION =? AND PLATFORM = ? AND ENVIRONMENT = ? AND SYSTEM = ? AND COLL_STATUS = ? ";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getExpStatus(), sumMdl.getExpDt(), sumMdl.getExpRecCount(), sumMdl.getExpBy(),
											sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCollStatus()});
		return (result > 0 ? true : false);
	}


	@Override
	public boolean updateUser2CriticalRoleExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving Data Summary User2 Critical Role for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " UPDATE SOD_DB_USER.USER_CRITICAL_ROLE_SUMMARY " +
					"  SET EXP_STATUS = ?, EXP_DT = ?, EXP_REC_COUNT = ?, EXP_BY = ? "+
					" WHERE REGION =? AND PLATFORM = ? AND ENVIRONMENT = ? AND SYSTEM = ? AND COLL_STATUS = ? ";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getExpStatus(), sumMdl.getExpDt(), sumMdl.getExpRecCount(), sumMdl.getExpBy(),
											sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCollStatus()});
		return (result > 0 ? true : false);
	}


	@Override
	public boolean updateUser2SodExportSummary(TrfCntrlSummaryMdl sumMdl) throws SQLException, DataAccessException {
		log.info("Saving Summary Data for User2Sod  for  : "+sumMdl.getRegion()+" "+sumMdl.getPlatform()+" "+sumMdl.getEnvironment()+" "+sumMdl.getSystem() +" By > User: "+sumMdl.getCreatedBy());
		String sql = " UPDATE SOD_DB_USER.USER2SOD_SUMMARY " +
					"  SET EXP_STATUS = ?, EXP_DT = ?, EXP_REC_COUNT = ?, EXP_BY = ? "+
					" WHERE REGION =? AND PLATFORM = ? AND ENVIRONMENT = ? AND SYSTEM = ? AND COLL_STATUS = ? ";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {sumMdl.getExpStatus(), sumMdl.getExpDt(), sumMdl.getExpRecCount(), sumMdl.getExpBy(),
											sumMdl.getRegion(), sumMdl.getPlatform(), sumMdl.getEnvironment(), sumMdl.getSystem(), sumMdl.getCollStatus()});
		return (result > 0 ? true : false);
	}

	@Override
	public String clearDeltaData()throws SQLException, DataAccessException{
		String sql1 = " DELETE USER_2_ROLE_DELTA_SUMMARY";
		String sql2 = " DELETE USER_2_ROLE_DELTA";

	 	int count1 =  getJdbcTemplateSRADUtils().update(sql1);
	 	int count2 =  getJdbcTemplateSRADUtils().update(sql2);
	 	String result = "Total Summary records deleted : "+count1+" Delta records deleted : "+count2;
	 	return result;
	}

	@Override
	public String clearUser2SodDeltaData()throws SQLException, DataAccessException{
		String sql1 = " DELETE USER2SOD_DELTA_SUMMARY";
		String sql2 = " DELETE USER2SOD_DELTA";///TODO Need to change

	 	int count1 =  getJdbcTemplateSRADUtils().update(sql1);
	 	int count2 =  getJdbcTemplateSRADUtils().update(sql2);
	 	String result = "Total Summary records deleted : "+count1+" Delta records deleted : "+count2;
	 	return result;
	}



	@Override
	public int deleteTrfTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException {
		log.info("Deleting Transfer Data for : "+region+" "+platform+" "+env+" "+sysm );
		String sql1 = " DELETE FROM SOD_DB_USER.TRF_CNTRL_TRANSDATA  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		String sql2 = " DELETE FROM SOD_DB_USER.TRF_CNTRL_SUMMARY  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		int result1 = getJdbcTemplateSRADUtils().update(sql1, new Object[] {region, platform, env, sysm});
		int result2 = getJdbcTemplateSRADUtils().update(sql2, new Object[] {region, platform, env, sysm});
		log.info("TRANSFER CONTROL Deleted ("+result1+" records from transaction Table and Deleted ("+result2+") Records from Summary table");
		return result1;
	}


	@Override
	public int deleteUser2RoleTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException {
		log.info("Deleting User To Role Data for : "+region+" "+platform+" "+env+" "+sysm );
		String sql1 = " DELETE FROM SOD_DB_USER.USER_ROLE_TRANSDATA  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		String sql2 = " DELETE FROM SOD_DB_USER.USER_ROLE_SUMMARY  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		int result1 = getJdbcTemplateSRADUtils().update(sql1, new Object[] {region, platform, env, sysm});
		int result2 = getJdbcTemplateSRADUtils().update(sql2, new Object[] {region, platform, env, sysm});
		log.info("USER TO ROLE Deleted ("+result1+") records from transaction Table and Deleted ("+result2+") Records from Summary table");
		return result1;
	}

	@Override
	public int deleteUser2SodTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException {
		log.info("Deleting User To Sod Data for : "+region+" "+platform+" "+env+" "+sysm );
		String sql1 = " DELETE FROM SOD_DB_USER.USER2SOD_TRANSDATA  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		String sql2 = " DELETE FROM SOD_DB_USER.USER2SOD_SUMMARY  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		int result1 = getJdbcTemplateSRADUtils().update(sql1, new Object[] {region, platform, env, sysm});
		int result2 = getJdbcTemplateSRADUtils().update(sql2, new Object[] {region, platform, env, sysm});
		log.info("USER TO SOD Deleted ("+result1+") records from transaction Table and Deleted ("+result2+") Records from Summary table");
		return result1;
	}

	@Override
	public int insertTrfCntrlTransData(List<TrfCntrlTransDataMdl> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into SOD_DB_USER.TRF_CNTRL_TRANSDATA ( Region, Platform, Environment, System, description, details, User_NT_ID, WWID, created_dt, created_by) "
				+ " Values  ( ?, ?, ?, ?, ?, ?, ?, ?, ?,? ) ";
		log.debug("Inserting Data to Transaction Data Table(SOD_DB_USER.TRF_CNTRL_TRANSDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRegion());
						ps.setString(2, dataList.get(i).getPlatform());
						ps.setString(3, dataList.get(i).getEnvironment());
						ps.setString(4, dataList.get(i).getSystem());
						ps.setString(5, dataList.get(i).getDescription());
						ps.setString(6, dataList.get(i).getDetails());
						ps.setString(7, dataList.get(i).getUserNtId());
						ps.setString(8, dataList.get(i).getWwid());
						ps.setDate(9, new java.sql.Date(new Date().getTime()));
						ps.setString(10, dataList.get(i).getCreatedBy());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}


	@Override
	public int insertUser2RoleTransData(List<SapGaaUser2RoleTransModel> dataList)throws SQLException, DataAccessException{
		String qry="Insert into USER_ROLE_TRANSDATA " +
				"   (REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
				"    PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, CREATED_DT, CREATED_BY)" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Role Transaction Data to  Table(SOD_DB_USER.USER_ROLE_TRANSDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRegion());
						ps.setString(2, dataList.get(i).getPlatform());
						ps.setString(3, dataList.get(i).getEnvironment());
						ps.setString(4, dataList.get(i).getSystem());
						ps.setString(5, dataList.get(i).getUserId());
						ps.setString(6, dataList.get(i).getFirstName());
						ps.setString(7, dataList.get(i).getLastName());
						ps.setString(8, dataList.get(i).getRoleId());
						ps.setString(9, dataList.get(i).getRoleDesc());
						ps.setString(10, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(11, dataList.get(i).getPrimaryReviewInfo2());
						ps.setString(12, dataList.get(i).getPrimaryReviewInfo3());
						ps.setString(13, dataList.get(i).getAdditionalInfo1());
						ps.setString(14, dataList.get(i).getAdditionalInfo2());
						ps.setString(15, dataList.get(i).getAdditionalInfo3());
						ps.setString(16, dataList.get(i).getUserStatus());
						ps.setDate(17, new java.sql.Date(new Date().getTime()));
						ps.setString(18, dataList.get(i).getCreatedBy());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}

	@Override
	public int insertUser2SodTransData(List<SapUser2SodModel> dataList, String templSystem, String crtdBy)throws SQLException, DataAccessException{
		String qry= "Insert into USER2SOD_TRANSDATA " +
					" (REGION, PLATFORM, ENVIRONMENT, SYSTEM, REVIEWER_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID,"+
					"   ADDITIONAL_INFO3, PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION, REVIEWER_DESCRIPTION, DATE_ENTERED, CREATED_BY )"+
					" Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
		log.debug("Inserting User to Sod Transaction Data to  Table(SOD_DB_USER.USER2SOD_TRANSDATA), \n Query: "+qry);
		String[] systemInfo = templSystem.split("_");
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, systemInfo[0]);
						ps.setString(2, systemInfo[1]);
						ps.setString(3, systemInfo[2]);
						ps.setString(4, systemInfo[3]);
						ps.setString(5, dataList.get(i).getRevUserId());
						ps.setString(6, dataList.get(i).getUserId());
						ps.setString(7, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(8, dataList.get(i).getAdditionalInfo1());
						ps.setString(9, dataList.get(i).getAdditionalInfo2());
						ps.setString(10, dataList.get(i).getMitigatingId());
						ps.setString(11, Utility.fixLen4000(dataList.get(i).getAdditionalInfo3()));
						ps.setString(12, dataList.get(i).getPlatformName());
						ps.setString(13, dataList.get(i).getRiskIdAndRiskDescription());
						ps.setString(14, dataList.get(i).getReviewerDescription());
						ps.setDate(15, new java.sql.Date(new Date().getTime()));
						ps.setString(16, crtdBy);
					}

					@Override
					public int getBatchSize() {
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}




	@Override
	public int insertUser2CriticalRoleTransData(List<SapGaaUser2RoleTransModel> dataList)throws SQLException, DataAccessException{
		String qry="Insert into USER_CRITICAL_ROLE_TRANSDATA " +
				"   (REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
				"    PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, CREATED_DT, CREATED_BY)" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Critical Role Transaction Data to  Table(SOD_DB_USER.USER_CRITICAL_ROLE_TRANSDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRegion());
						ps.setString(2, dataList.get(i).getPlatform());
						ps.setString(3, dataList.get(i).getEnvironment());
						ps.setString(4, dataList.get(i).getSystem());
						ps.setString(5, dataList.get(i).getUserId());
						ps.setString(6, dataList.get(i).getFirstName());
						ps.setString(7, dataList.get(i).getLastName());
						ps.setString(8, dataList.get(i).getRoleId());
						ps.setString(9, dataList.get(i).getRoleDesc());
						ps.setString(10, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(11, dataList.get(i).getPrimaryReviewInfo2());
						ps.setString(12, dataList.get(i).getPrimaryReviewInfo3());
						ps.setString(13, dataList.get(i).getAdditionalInfo1());
						ps.setString(14, dataList.get(i).getAdditionalInfo2());
						ps.setString(15, dataList.get(i).getAdditionalInfo3());
						ps.setString(16, dataList.get(i).getUserStatus());
						ps.setDate(17, new java.sql.Date(new Date().getTime()));
						ps.setString(18, dataList.get(i).getCreatedBy());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}

	@Override
	public List<TrfCntrlTransDataMdl> getExportDataForRegPlatform(String templSysParam)throws SQLException, DataAccessException {
		log.info("Query Transfer Control Data to Export for Platform : "+ templSysParam);
		String[] tempArr=templSysParam.split("_");
		String sql = " SELECT Distinct Region, Platform, Environment, System, description, details, User_NT_ID, WWID, created_dt, created_by " +
					 " From SOD_DB_USER.TRF_CNTRL_TRANSDATA " +
					 " Where Region = ? AND Platform = ? AND Environment = ? AND  System = ? "+
					 " ORDER By Region, Platform, Environment, System ";
		final List<TrfCntrlTransDataMdl> trfData = getJdbcTemplateSRADUtils().query(sql, new Object[] {tempArr[0], tempArr[1], tempArr[2], tempArr[3]}, new BeanPropertyRowMapper<>(TrfCntrlTransDataMdl.class));
		log.info("Total Records for Export : "+((trfData !=null)? trfData.size(): 0)+"  .......END");
		return trfData;
	}

	@Override
	public List<TrfCntrlTransDataMdl> getAllTRFCntrlExportableData(String regn)throws SQLException, DataAccessException {
		log.info("Query All Transfer Control Data Created: ");
		String sql = " SELECT Region, Platform, Environment, System, description, details, User_NT_ID, WWID, created_dt, created_by " +
					 " From SOD_DB_USER.TRF_CNTRL_TRANSDATA  WHERE REGION = ? " +
					 " ORDER By Region, Platform, Environment, System ";
		final List<TrfCntrlTransDataMdl> trfData = getJdbcTemplateSRADUtils().query(sql, new Object[] {regn}, new BeanPropertyRowMapper<>(TrfCntrlTransDataMdl.class));
		log.info("Total Records for Export : "+((trfData !=null)? trfData.size(): 0)+"  .......END");
		return trfData;
	}

	@Override
	public List<SapGaaUser2RoleTransModel> getAllUser2RoleExportableData(String regn) throws SQLException, DataAccessException{
		log.info("Query User to Role Data For Region: "+regn);
		String sql = " SELECT  REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID as USER_ID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
					 " PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, CREATED_DT, CREATED_BY " +
					 " From SOD_DB_USER.USER_ROLE_TRANSDATA WHERE REGION = ?" +
					 " ORDER By Region, Platform, Environment, System ";
		final List<SapGaaUser2RoleTransModel> usrData = getJdbcTemplateSRADUtils().query(sql, new Object[] {regn}, new BeanPropertyRowMapper<>(SapGaaUser2RoleTransModel.class));
		log.info("Total Records for User to Role "+((usrData !=null)? usrData.size(): 0)+"  .......END");
		return usrData;
	}

	@Override
	public List<SapUser2SodTrnsModel> getAllUser2SodExportableData(String regn) throws SQLException, DataAccessException{
		log.info("Query User to Role Data For Region: "+regn);
		String sql = " SELECT DISTINCT REGION, PLATFORM, ENVIRONMENT, SYSTEM, REVIEWER_USER_ID as revUserId, USER_ID as userId, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID, ADDITIONAL_INFO3, "+
					 " PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION as riskIdAndRiskDescription, REVIEWER_DESCRIPTION as reviewerDescription "+
					 " From SOD_DB_USER.USER2SOD_TRANSDATA WHERE REGION = ?" +
					 " ORDER By Region, Platform, Environment, System ";
		final List<SapUser2SodTrnsModel> usrData = getJdbcTemplateSRADUtils().query(sql, new Object[] {regn}, new BeanPropertyRowMapper<>(SapUser2SodTrnsModel.class));
		log.info("Total Records for User to Sod "+((usrData !=null)? usrData.size(): 0)+"  .......END");
		return usrData;
	}

	@Override
	public List<SapGaaUser2RoleTransModel> getUser2RoleExportDataForRegPlatform(String templSysParam)throws SQLException, DataAccessException {
		log.info("Query User to Role Data to Export for Platform : "+ templSysParam);
		String[] tempArr=templSysParam.split("_");
		String sql = " SELECT  DISTINCT REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID as USER_ID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
					 " PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, SYSDATE AS CREATED_DT, CREATED_BY " +
					 " From SOD_DB_USER.USER_ROLE_TRANSDATA " +
					 " Where Region = ? AND Platform = ? AND Environment = ? AND  System = ? "+
					 " ORDER By Region, Platform, Environment, System ";
		final List<SapGaaUser2RoleTransModel> usrData = getJdbcTemplateSRADUtils().query(sql, new Object[] {tempArr[0], tempArr[1], tempArr[2], tempArr[3]}, new BeanPropertyRowMapper<>(SapGaaUser2RoleTransModel.class));
		log.info("Total Records for Export for "+templSysParam+" : "+((usrData !=null)? usrData.size(): 0)+"  .......END");
		return usrData;
	}


	@Override
	public List<SapGaaUser2RoleTransModel> getUser2CriticalRoleExportDataForRegPlatform(String templSysParam)throws SQLException, DataAccessException {
		log.info("Query User to Critical Role Data to Export for Platform : "+ templSysParam);
		String[] tempArr=templSysParam.split("_");
		String sql = " SELECT  DISTINCT REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID as USER_ID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
					 " PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, SYSDATE AS CREATED_DT, CREATED_BY " +
					 " From SOD_DB_USER.USER_CRITICAL_ROLE_TRANSDATA " +
					 " Where Region = ? AND Platform = ? AND Environment = ? AND  System = ? "+
					 " ORDER By Region, Platform, Environment, System ";
		final List<SapGaaUser2RoleTransModel> usrData = getJdbcTemplateSRADUtils().query(sql, new Object[] {tempArr[0], tempArr[1], tempArr[2], tempArr[3]}, new BeanPropertyRowMapper<>(SapGaaUser2RoleTransModel.class));
		log.info("Total Records Critical Roles for Export for "+templSysParam+" : "+((usrData !=null)? usrData.size(): 0)+"  .......END");
		return usrData;
	}

	@Override
	public List<SapUser2SodModel> getUser2SodExportDataForRegPlatform(String templSysParam)throws SQLException, DataAccessException {
		log.info("Query User to Sod Data to Export for Platform : "+ templSysParam);
		String[] tempArr=templSysParam.split("_");
		String sql = " SELECT DISTINCT REVIEWER_USER_ID as revUserId, USER_ID as userId, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID, ADDITIONAL_INFO3, "+
					 " PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION as riskIdAndRiskDescription, REVIEWER_DESCRIPTION as reviewerDescription "+
					 " From SOD_DB_USER.USER2SOD_TRANSDATA " +
					 " Where Region = ? AND Platform = ? AND Environment = ? AND  System = ? "+
					 " ORDER By Region, Platform, Environment, System ";
		final List<SapUser2SodModel> usrData = getJdbcTemplateSRADUtils().query(sql, new Object[] {tempArr[0], tempArr[1], tempArr[2], tempArr[3]}, new BeanPropertyRowMapper<>(SapUser2SodModel.class));
		log.info("Total Records User To Sod Export for "+templSysParam+" : "+((usrData !=null)? usrData.size(): 0)+"  .......END");
		return usrData;
	}

	@Override
	public List<TrfCntrlSummaryMdl> getTrfContrlSummary() throws SQLException, DataAccessException {
		log.info("Getting Summary of Transfers");
		String sql = " Select REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY "+
					 " FROM SOD_DB_USER.TRF_CNTRL_SUMMARY ORDER BY REGION, PLATFORM, ENVIRONMENT, SYSTEM ";
		final List<TrfCntrlSummaryMdl> summary = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(TrfCntrlSummaryMdl.class));
		log.info("Total Schedules : "+((summary !=null)? summary.size(): 0)+"  .......END");
		return summary;

	}



	@Override
	public List<TrfCntrlSchModel> getAllUser2RoleSchedules(List<String> regions) throws SQLException, DataAccessException {
		log.info("Getting All USER2ROLE Schedules for REGION: "+ (!regions.isEmpty()? regions:""));
		StringBuilder sql = new StringBuilder();
		sql.append(" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " );
		sql.append(" From SOD_DB_USER.USER_ROLE_SCH " );
		Object[] params = null;
		if(regions != null && !regions.isEmpty()) {
			params = regions.toArray();
			sql.append(" WHERE REGION IN (");
			for(int i=0;i<regions.size(); i++) {
				sql.append(" ?");
				if(i<(regions.size() -1)) {
					sql.append(", ");
				}
			}
			sql.append(" ) ");
		}else {
			params = new Object[] {};
		}
		sql.append(" ORDER By REGION, TYPE ");

		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql.toString(), params, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Total USER2ROLE Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}


	@Override
	public List<TrfCntrlSchModel> getAllUser2CriticalRoleSchedules(List<String> regions) throws SQLException, DataAccessException {
		log.info("Getting All USER2CRITICALROLE Schedules for REGION: "+ (!regions.isEmpty()? regions:""));
		StringBuilder sql = new StringBuilder();
		sql.append(" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " );
		sql.append(" From SOD_DB_USER.USER_CRITICAL_ROLE_SCH " );
		Object[] params = null;
		if(regions != null && !regions.isEmpty()) {
			params = regions.toArray();
			sql.append(" WHERE REGION IN (");
			for(int i=0;i<regions.size(); i++) {
				sql.append(" ?");
				if(i<(regions.size() -1)) {
					sql.append(", ");
				}
			}
			sql.append(" ) ");
		}else {
			params = new Object[] {};
		}
		sql.append(" ORDER By REGION, TYPE ");

		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql.toString(), params, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Total USER2CRITCALROLE Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}

	@Override
	public List<TrfCntrlSchModel> getAllUser2SodSchedules(List<String> regions) throws SQLException, DataAccessException {
		log.info("Getting All USER2SOD Schedules for REGION: "+ (!regions.isEmpty()? regions:""));
		StringBuilder sql = new StringBuilder();
		sql.append(" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " );
		sql.append(" From SOD_DB_USER.USER2SOD_SCH " );
		Object[] params = null;
		if(regions != null && !regions.isEmpty()) {
			params = regions.toArray();
			sql.append(" WHERE REGION IN (");
			for(int i=0;i<regions.size(); i++) {
				sql.append(" ?");
				if(i<(regions.size() -1)) {
					sql.append(", ");
				}
			}
			sql.append(" ) ");
		}else {
			params = new Object[] {};
		}
		sql.append(" ORDER By REGION, TYPE ");

		final List<TrfCntrlSchModel> schedules = getJdbcTemplateSRADUtils().query(sql.toString(), params, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		log.info("Total USER2SOD Schedules : "+((schedules !=null)? schedules.size(): 0)+"  .......END");
		return schedules;
	}

	@Override
	public List<TrfCntrlSummaryMdl> getUser2RoleSummary() throws SQLException, DataAccessException {
		log.info("Getting Summary of USER TO ROLE");
		String sql = " Select REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY "+
					 " FROM SOD_DB_USER.USER_ROLE_SUMMARY ORDER BY REGION, PLATFORM, ENVIRONMENT, SYSTEM ";
		final List<TrfCntrlSummaryMdl> summary = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(TrfCntrlSummaryMdl.class));
		log.info("Total Schedules : "+((summary !=null)? summary.size(): 0)+"  .......END");
		return summary;

	}


	@Override
	public List<TrfCntrlSummaryMdl> getUser2CriticalRoleSummary() throws SQLException, DataAccessException {
		log.info("Getting Summary of USER TO ROLE");
		String sql = " Select REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY "+
					 " FROM SOD_DB_USER.USER_CRITICAL_ROLE_SUMMARY ORDER BY REGION, PLATFORM, ENVIRONMENT, SYSTEM ";
		final List<TrfCntrlSummaryMdl> summary = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(TrfCntrlSummaryMdl.class));
		log.info("Total Critical Roles Summary : "+((summary !=null)? summary.size(): 0)+"  .......END");
		return summary;

	}

	@Override
	public List<TrfCntrlSummaryMdl> getUser2SodSummary() throws SQLException, DataAccessException {
		log.info("Getting Summary of USER TO SOD");
		String sql = " Select REGION, PLATFORM, ENVIRONMENT, SYSTEM, CREATED_REC_COUNT, CREATED_DT, CREATED_BY, COLL_STATUS, EXP_STATUS, EXP_DT, EXP_REC_COUNT, EXP_BY "+
					 " FROM SOD_DB_USER.USER2SOD_SUMMARY ORDER BY REGION, PLATFORM, ENVIRONMENT, SYSTEM ";
		final List<TrfCntrlSummaryMdl> summary = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(TrfCntrlSummaryMdl.class));
		log.info("Total USER 2 SOD Summary : "+((summary !=null)? summary.size(): 0)+"  .......END");
		return summary;

	}



	//SAVING USER TO ROLE DELTA INFORMATION

	@Override
	public int insertUser2RoleDeltaReport(List<SapUser2RoleDeltaMdl> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER_2_ROLE_DELTA " +
				"   (REVIEWER_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, DATE_ENTERED, REPORT_DATE)" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Role Transaction Data to  Table(SOD_DB_USER.USER_ROLE_TRANSDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRevUserId());
						ps.setString(2, dataList.get(i).getUserId());
						ps.setString(3, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(4, dataList.get(i).getPrimaryReviewInfo2());
						ps.setString(5, dataList.get(i).getPrimaryReviewInfo3());
						ps.setString(6, dataList.get(i).getAdditionalInfo1());
						ps.setString(7, dataList.get(i).getAdditionalInfo2());
						ps.setString(8, dataList.get(i).getAdditionalInfo3());
						ps.setDate(9, new java.sql.Date(dataList.get(i).getDateEntered().getTime()));
						ps.setDate(10, new java.sql.Date(dataList.get(i).getReportDate().getTime()));
						//ps.setString(18, dataList.get(i).getCreatedBy());
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}


	@Override
	public int insertUser2SodDeltaReport(List<SapUser2SodDeltaMdl> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER2SOD_DELTA " +
				"   (REVIEWER_USER_ID, USER_ID, PRIMARY_REVIEW_INFO1, ADDITIONAL_INFO1, ADDITIONAL_INFO2, MITIGATING_ID, ADDITIONAL_INFO3, PLATFORM_NAME, RISK_ID_AND_RISK_DESCRIPTION, REVIEWER_DESCRIPTION, USER_STATUS, DATE_ENTERED, REPORT_DATE )" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Sod Transaction Data to  Table(SOD_DB_USER.USER2SOD_DELTA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRevUserId());
						ps.setString(2, dataList.get(i).getUserId());
						ps.setString(3, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(4, dataList.get(i).getAdditionalInfo1());
						ps.setString(5, dataList.get(i).getAdditionalInfo2());
						ps.setString(6, dataList.get(i).getMitigatingId());
						ps.setString(7, dataList.get(i).getAdditionalInfo3());
						ps.setString(8, dataList.get(i).getPlatformName());
						ps.setString(9, dataList.get(i).getRiskIdAndRiskDescription());
						ps.setString(10, dataList.get(i).getReviewerDescription());
						ps.setString(11, dataList.get(i).getUserStatus());
						ps.setDate(12, new java.sql.Date(dataList.get(i).getDateEntered().getTime()));
						ps.setDate(13, new java.sql.Date(dataList.get(i).getReportDate().getTime()));
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}



	@Override
	public int insertUser2RoleDeltaSummary(List<SapU2RDeltaSummaryMdl> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER_2_ROLE_DELTA_SUMMARY " +
				"   (USER_ID, ROLES_IN, ROLES_COL, REPORT_DATE) " +
				" 	 Values  (?, ?, ?, ?)";
		log.debug("Inserting User to Role Summary Data to  Table(USER_2_ROLE_DELTA_SUMMARY), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getUserId());
						ps.setInt(2, dataList.get(i).getRolesIn());
						ps.setInt(3, dataList.get(i).getRolesCol());
						ps.setDate(4, new java.sql.Date(dataList.get(i).getReportDate().getTime()));
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}

	@Override
	public int insertUser2SodDeltaSummary(List<SapU2RDeltaSummaryMdl> dataList)throws SQLException, DataAccessException{
		String qry=" Insert into USER2SOD_DELTA_SUMMARY " +
				"   (USER_ID, ROLES_IN, ROLES_COL, REPORT_DATE) " +
				" 	 Values  (?, ?, ?, ?)";
		log.debug("Inserting User to Sod Summary Data to  Table(USER2SOD_DELTA_SUMMARY), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getUserId());
						ps.setInt(2, dataList.get(i).getRolesIn());
						ps.setInt(3, dataList.get(i).getRolesCol());
						ps.setDate(4, new java.sql.Date(dataList.get(i).getReportDate().getTime()));
					}

					@Override
					public int getBatchSize() {
						// TODO Auto-generated method stub
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}




	@Override
	public List<CriticalRoleModel> getAllCriticalRoles() throws SQLException, DataAccessException {
		log.info("Getting All CRITICAL ROLES");
		String sql = " Select PLATFORM, ROLE,  CREATED_BY, CREATED_DATE " +
					 " From SOD_DB_USER.CRITICAL_ROLES " +
					 " ORDER BY PLATFORM ";
		final List<CriticalRoleModel> criticalRoles = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(CriticalRoleModel.class));
		log.info("Total Critical Roles : "+((criticalRoles !=null)? criticalRoles.size(): 0)+"  .......END");
		return criticalRoles;
	}

	@Override
	public List<TrfCntrlSchModel> getCriticalScheduleforRegion(String region, String sType) throws SQLException, DataAccessException {
		log.info("Cheking "+("C".equals(sType)? " USER TO CRITICAL ROLE CREATION ":" USER TO CRITICAL ROLE EXPORT ")+" Schedule for Region : "+region);
		String sql=" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
				  " From SOD_DB_USER.USER_CRITICAL_ROLE_SCH WHERE REGION= ? and TYPE=? ";
		List<TrfCntrlSchModel> result = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		return result;
	}


	@Override
	public List<TrfCntrlSchModel> getUserToSodScheduleforRegion(String region, String sType) throws SQLException, DataAccessException {
		log.info("Cheking "+("C".equals(sType)? " USER TO SOD CREATION ":" USER TO SOD EXPORT ")+" Schedule for Region : "+region);
		String sql=" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
				  " From SOD_DB_USER.USER2SOD_SCH WHERE REGION= ? and TYPE=? ";
		List<TrfCntrlSchModel> result = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		return result;
	}

	@Override
	public List<TrfCntrlSchModel> getTRFOrU2RScheduleforRegion(String region, String sType, String process) throws SQLException, DataAccessException {
		log.info("Cheking "+("C".equals(sType)? " CREATION ":" EXPORT ")+" Schedule for Region : "+region);
		String sql = "";
		if("T".equals(process)) {
			sql=" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
				" From SOD_DB_USER.TRF_CNTRL_SCH WHERE REGION= ? and TYPE=? ";
		}else {
			sql=" Select REGION, TYPE, SCH_DT, SCH_STATUS, DETAILS, CREATED_DT, CREATED_BY, COMPLETED_DT " +
				" From SOD_DB_USER.USER_ROLE_SCH WHERE REGION= ? and TYPE=? ";
		}

		List<TrfCntrlSchModel> result = getJdbcTemplateSRADUtils().query(sql, new Object[] {region, sType}, new BeanPropertyRowMapper<>(TrfCntrlSchModel.class));
		return result;
	}


	@Override
	public int delUser2CriticalRoleTransactionData(String region, String platform, String env, String sysm) throws SQLException, DataAccessException {
		log.info("Deleting User To Critical Role Data for : "+region+" "+platform+" "+env+" "+sysm );
		String sql1 = " DELETE FROM SOD_DB_USER.USER_CRITICAL_ROLE_TRANSDATA  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		String sql2 = " DELETE FROM SOD_DB_USER.USER_CRITICAL_ROLE_SUMMARY  WHERE REGION = ? AND PLATFORM = ? AND ENVIRONMENT = ? AND  SYSTEM = ? ";
		int result1 = getJdbcTemplateSRADUtils().update(sql1, new Object[] {region, platform, env, sysm});
		int result2 = getJdbcTemplateSRADUtils().update(sql2, new Object[] {region, platform, env, sysm});
		log.info("USER TO CRITICAL ROLE Deleted ("+result1+") records from transaction Table and Deleted ("+result2+") Records from Summary table");
		return result1;
	}


	//USER TO ROLE RAW DATA INSERTION

	@Override
	public int insertUser2RoleRawData(List<User2RoleRawDataMdl> dataList)throws SQLException, DataAccessException{
		String qry="Insert into SOD_DB_USER.USER2ROLE_RAWDATA " +
				"   (REGION, PLATFORM, ENVIRONMENT, SYSTEM, USER_ID, ROLE_ID, ROLE_DESC, CREATED_DT )" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Role RAW Data to  Table(SOD_DB_USER.USER2ROLE_RAWDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRegion());
						ps.setString(2, dataList.get(i).getPlatform());
						ps.setString(3, dataList.get(i).getEnvironment());
						ps.setString(4, dataList.get(i).getSystem());
						String id= dataList.get(i).getUserId();
						if(id.length() > 16) {
							id=id.substring(0,15);
						}
						ps.setString(5, id);
						ps.setString(6, dataList.get(i).getRoleId());
						ps.setString(7, dataList.get(i).getRoleDesc());
						ps.setDate(8, new java.sql.Date(new Date().getTime()));
					}

					@Override
					public int getBatchSize() {
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}

	@Override
	public int insertUser2RoleTransRawData(List<SapGaaUser2RoleTransModel> dataList)throws SQLException, DataAccessException{
		String qry="Insert into SOD_DB_USER.USER2ROLE_ALLDATA " +
				"   (REGION, PLATFORM, ENVIRONMENT, SYSTEM, WWID, FIRST_NAME, LAST_NAME, ROLE_ID, ROLE_DESC, PRIMARY_REVIEW_INFO1, " +
				"    PRIMARY_REVIEW_INFO2, PRIMARY_REVIEW_INFO3, ADDITIONAL_INFO1, ADDITIONAL_INFO2, ADDITIONAL_INFO3, USER_STATUS, CREATED_DT, CREATED_BY)" +
				" 	 Values  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		log.debug("Inserting User to Role Transaction Data to  Table(SOD_DB_USER.USER_ROLE_TRANSDATA), \n Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, dataList.get(i).getRegion());
						ps.setString(2, dataList.get(i).getPlatform());
						ps.setString(3, dataList.get(i).getEnvironment());
						ps.setString(4, dataList.get(i).getSystem());
						ps.setString(5, dataList.get(i).getUserId());
						ps.setString(6, dataList.get(i).getFirstName());
						ps.setString(7, dataList.get(i).getLastName());
						ps.setString(8, dataList.get(i).getRoleId());
						ps.setString(9, dataList.get(i).getRoleDesc());
						ps.setString(10, dataList.get(i).getPrimaryReviewInfo1());
						ps.setString(11, dataList.get(i).getPrimaryReviewInfo2());
						ps.setString(12, dataList.get(i).getPrimaryReviewInfo3());
						ps.setString(13, dataList.get(i).getAdditionalInfo1());
						ps.setString(14, dataList.get(i).getAdditionalInfo2());
						ps.setString(15, dataList.get(i).getAdditionalInfo3());
						ps.setString(16, dataList.get(i).getUserStatus());
						ps.setDate(17, new java.sql.Date(new Date().getTime()));
						ps.setString(18, dataList.get(i).getCreatedBy());
					}

					@Override
					public int getBatchSize() {
						return dataList.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == dataList.size() ? "Success-"+dataList.size() : "Failed-"+(dataList.size() - status.length)));
		return  status.length;
	}


	@Override
	public List<SAPTrfCntrlSummaryMdl> getRawDataRegnSummary(String regId) throws SQLException, DataAccessException {
		String sql=	" Select REGION, PLATFORM,ENVIRONMENT, SYSTEM, count(*) AS COUNT " +
					" From SOD_DB_USER.USER2ROLE_ALLDATA " +
					" WHERE REGION = ? "+
					" GROUP BY REGION, PLATFORM,ENVIRONMENT, SYSTEM " +
					" ORDER BY REGION, PLATFORM,ENVIRONMENT, SYSTEM ";

		List<SAPTrfCntrlSummaryMdl> result = getJdbcTemplateSRADUtils().query(sql, new Object[] {regId}, new BeanPropertyRowMapper<>(SAPTrfCntrlSummaryMdl.class));
		return result;
	}

	@Override
	public int getUer2RoleSeq(String reportName) throws SQLException, DataAccessException{
		String sql = " SELECT MAX(SEQ_ID) FROM SOD_DB_USER.USER2ROLE_EMAILLOG " +
					 " WHERE REPORT_NAME = '"+reportName+"' ";
	int seq = getJdbcTemplateSRADUtils().queryForObject(sql, Integer.class);
	return seq;

	}

	@Override
	public int saveU2RRepPlatformEmailLog(int seq, List<String> sysIDs, String reportNm, String triggeredBy)throws SQLException, DataAccessException{
		String qry=" INSERT INTO SOD_DB_USER.USER2ROLE_EMAILLOG (SEQ_ID, REPORT_NAME, PLATFORM, TRIGGERED_BY, EMAIL_SEND, CREATED_DT, STATUS )  Values  (?, ?, ?, ?, ?, ?, ?) ";
		log.debug("Inserting Data to USER2ROLE_EMAILLOG Query: "+qry);
		int[] status = getJdbcTemplateSRADUtils().batchUpdate(qry,
	            new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setInt(1, seq);
						ps.setString(2, reportNm);
						ps.setString(3, sysIDs.get(i));
						ps.setString(4, triggeredBy);
						ps.setString(5, "N");
						ps.setDate(6, new java.sql.Date(new Date().getTime()));
						ps.setString(7, "NEW");
					}

					@Override
					public int getBatchSize() {
						return sysIDs.size();
					}
				});
			log.info("Total Records inserted : "+(status.length == sysIDs.size() ? "Success-"+sysIDs.size() : "Failed-"+(sysIDs.size() - status.length)));
		return  status.length;
	}

	@Override
	public int updateU2RRepPlatformEmailLog(int seq, String sysID, String reportNm, String toEmail, String fileNames) throws SQLException, DataAccessException {
		String sql =" UPDATE SOD_DB_USER.USER2ROLE_EMAILLOG "+
					" SET EMAIL_SEND = ?, SEND_DT = ?, EMAIL_ADDRESS= ? , GEN_FILES = ? "+
					" WHERE SEQ_ID = ? AND REPORT_NAME =? AND PLATFORM = ?";
		int recUpdated = getJdbcTemplateSRADUtils().update(sql, new Object[] {"Y", new Date(), toEmail, fileNames, seq, reportNm, sysID});
		log.info("Total Email Log Records Updated: "+recUpdated);
		return recUpdated;
	}

	@Override
	public List<U2REmailLogMdl> getU2RWeeklyLogDetails() throws SQLException, DataAccessException {
		String sql =" Select DISTINCT SEQ_ID, REPORT_NAME, TO_DATE(TO_CHAR(CREATED_DT, 'MM/DD/YYYY'), 'MM/DD/YYYY') AS CREATED_DT FROM SOD_DB_USER.USER2ROLE_EMAILLOG ORDER BY SEQ_ID DESC ";
		List<U2REmailLogMdl> repList = getJdbcTemplateSRADUtils().query(sql, new Object[] {}, new BeanPropertyRowMapper<>(U2REmailLogMdl.class));
		log.info("Total Email Log Records Count: "+((repList != null && repList.size() > 0)? ""+repList.size():"0"));
		return repList;
	}

	@Override
	public List<U2REmailLogMdl> getU2RWeeklyLogData(int seqId) throws SQLException, DataAccessException {
		String sql =" SELECT SEQ_ID, REPORT_NAME, PLATFORM, EMAIL_ADDRESS, TRIGGERED_BY, EMAIL_SEND, CREATED_DT, SEND_DT, GEN_FILES, STATUS, STATUS_UPD_BY, STATUS_UPD_DT " +
					" FROM SOD_DB_USER.USER2ROLE_EMAILLOG  WHERE SEQ_ID = ? ORDER BY PLATFORM ";
		List<U2REmailLogMdl> repList = getJdbcTemplateSRADUtils().query(sql, new Object[] {seqId}, new BeanPropertyRowMapper<>(U2REmailLogMdl.class));
		log.info("Total Weekly Email Data Records Count: "+((repList != null && repList.size() > 0)? ""+repList.size():"0"));
		return repList;
	}

	@Override
	public int updateWeeklyRptStatus(int seqIdParam, String platform, String userId) throws SQLException, DataAccessException {
		log.info("Update SOD_DB_USER.USER2ROLE_EMAILLOG Status for seqIdParam : "+seqIdParam +" platform: "+platform+" Status : COMPLETE");
		String sql = "UPDATE SOD_DB_USER.USER2ROLE_EMAILLOG SET STATUS = 'COMPLETE', STATUS_UPD_BY = ?, STATUS_UPD_DT = sysdate "+
					 " WHERE SEQ_ID = ? AND PLATFORM = ? ";
		int result = getJdbcTemplateSRADUtils().update(sql, new Object[] {userId, seqIdParam, platform});
		return result;
	}

}
