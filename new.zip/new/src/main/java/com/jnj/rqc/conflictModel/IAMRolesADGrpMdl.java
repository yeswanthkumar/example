package com.jnj.rqc.conflictModel;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class IAMRolesADGrpMdl {
	private String client;
	private String user;
	private String ldapADGroup;
	private String mdate;//Modified date
	private String stopdate;


	@Override
	public String toString() {
		return "IAMRolesADGrpMdl [client=" + client + ", user=" + user + ", ldapADGroup="
				+ ldapADGroup + ", mdate=" + mdate + "stopdate="+stopdate+"]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (getClass() != obj.getClass()))
			return false;
		IAMRolesADGrpMdl other = (IAMRolesADGrpMdl) obj;
		if (ldapADGroup == null) {
			if (other.ldapADGroup != null)
				return false;
		} else if (!ldapADGroup.equals(other.ldapADGroup))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ldapADGroup == null) ? 0 : ldapADGroup.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}








}
