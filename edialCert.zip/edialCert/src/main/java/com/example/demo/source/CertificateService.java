package com.example.demo.source;

import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

@Service
public class CertificateService {

    public String generateEncodedCert(String certFile) throws IOException {
        byte[] certBytes;

        try (FileInputStream fileInputStream = new FileInputStream(certFile);
             BufferedInputStream bis = new BufferedInputStream(fileInputStream)) {

            certBytes = new byte[(int) new File(certFile).length()];
            bis.read(certBytes);
        }

        return Base64.getEncoder().encodeToString(certBytes);
    }
}
