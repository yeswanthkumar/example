package com.example.demo.source;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

@Service
public class APIService {

    private final CustomProperties customProperties;
    private final CertificateService certificateService;

    public APIService(CustomProperties customProperties, CertificateService certificateService) {
        this.customProperties = customProperties;
        this.certificateService = certificateService;
    }

    public void communicateWithAPI() {
        String apiUrl = customProperties.getApiUrl();
        String certFilePath = customProperties.getCertFilePath();
        String privateKeyFilePath = customProperties.getPrivateKeyFilePath();

        try {
            String yourCACertificate = certificateService.generateEncodedCert(certFilePath);
            Pair<String, String> encodedStrings = generateStrings(privateKeyFilePath);
            String encodedString = encodedStrings.getLeft();
            String encodedSignedString = encodedStrings.getRight();

            HttpClient httpClient = HttpClient.newBuilder().build();

            try {
                // Prepare the JSON payload
                String jsonPayload = String.format("{\"encodedData\": \"%s\", \"encodedSignedData\": \"%s\"}", encodedString, encodedSignedString);

                // Prepare the POST request with headers
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI(apiUrl))
                        .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                        .header("authorization", "CACertificate " + yourCACertificate)
                        .header("Content-Type", "application/json")
                        .build();

                // Send the request and retrieve the response
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                // Process the response
                int statusCode = response.statusCode();
                String responseBody = response.body();
                System.out.println("Status Code: " + statusCode);
                System.out.println("Response: " + responseBody);

            } catch (IOException | InterruptedException | URISyntaxException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private Pair<String, String> generateStrings(String privateKeyFile) throws Exception {
        byte[] privKeyBytes;

        try (FileInputStream fileInputStream = new FileInputStream(privateKeyFile);
             BufferedInputStream bis = new BufferedInputStream(fileInputStream)) {

            privKeyBytes = new byte[(int) new File(privateKeyFile).length()];
            bis.read(privKeyBytes);
        }

        RSAPrivateKey privKey = (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(
                new PKCS8EncodedKeySpec(privKeyBytes));

        SecureRandom random = new SecureRandom();
        random.setSeed(System.currentTimeMillis());

        byte bytes[] = new byte[100];
        random.nextBytes(bytes);

        byte[] decodedSignedData = sign(privKey, bytes);

        String encodedData = Base64.getEncoder().encodeToString(bytes);
        String encodedSignedData = Base64.getEncoder().encodeToString(decodedSignedData);

        return new ImmutablePair<>(encodedData, encodedSignedData);
    }

    private byte[] sign(PrivateKey privateKey, byte[] dataBytes) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Signature sig = Signature.getInstance("SHA512withRSA");

        sig.initSign(privateKey);
        sig.update(dataBytes);

        return sig.sign();
    }
    
}
