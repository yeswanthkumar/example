package com.example.demo.source;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ApiController {

    private final APIService apiService;

    public ApiController(APIService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/call-api")
    public String callApi() {
        apiService.communicateWithAPI();
        return "API call initiated";
    }
}
